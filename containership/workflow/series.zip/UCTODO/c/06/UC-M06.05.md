# UC-M06.05 — Policy-as-code admission evaluator

**To-Do Pack 2.0.0 · Baseline UC-2.2.0 · 100 parent checks × 10 subtasks = 1,000 to-dos**

[Master index](../../INDEX.md) · [Workstream index](../../w/06.md)

| Field | Preserved source value |
|---|---|
| Workstream | 06. Control plane, identity and policy |
| Milestone | C |
| Priority | P0 |
| Source assessment | PARTIAL |
| Scope | core or selected profile |
| Dependencies | [UC-M03.08](../03/UC-M03.08.md), [UC-M04.08](../04/UC-M04.08.md), [UC-M06.03](../06/UC-M06.03.md) |
| Source checklist pack | 1.0.0 |
| Original reference labels | [S4], [S6]. |

## Original requirement

Evaluate signed provenance, runtime class, resource budgets, device access and network requirements before any executable action.

**Original acceptance criterion:** A denied policy leaves no child process or externally visible partial workload; policy evidence is recorded.

**Source trace:** Original checklist `UC100/c/06/UC-M06.05.md` inside [s/checklists.zip](../../s/checklists.zip); exact parent records in [data/parents.jsonl](../../data/parents.jsonl). Original roadmap lines 568–578 are preserved in [s/roadmap.md](../../s/roadmap.md).

## How to use these lists

Every parent statement below is preserved verbatim. Its ten child tasks are proposed decomposition, not implemented capabilities or executed tests. Child IDs append `-T01` through `-T10` to the original parent ID. All begin unchecked / `TODO`. Design/review evidence does not establish runtime enforcement; observe the actual selected target where the parent requires it.

The source dependency graph and selected release profile determine applicability. The numbered child sequence is a local working order, not an added hard dependency graph. An unselected optional feature needs a recorded not-applicable rationale; missing prerequisites for selected work remain blockers. Numerical budgets, backends and trust mechanisms remain decisions unless fixed by the source. Test hostile cases only with synthetic inputs in authorized disposable environments.

## 01. Policy input model

**Source delivery:** Collect provenance, isolation, resources, devices and networking into typed admission inputs.

**Source invariant:** Policy evaluates validated facts rather than unchecked cargo declarations.

**Source negative case:** A manifest falsely declares an enforced isolation capability.

**Source bounded quantities:** Input fields and evidence references.

### UC-M06.05-C001 · Contract

**Original checklist item:** Specify policy input model inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M06.05-C001-T01 · Scope statement:** Draft the operation boundary for “Policy input model” within Policy-as-code admission evaluator; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M06.05-C001-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Policy input model”; record each producer, representation and missing-value meaning.
- [ ] **UC-M06.05-C001-T03 · Output inventory:** List the outputs of “Policy input model” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M06.05-C001-T04 · Field dictionary:** Create a field-and-term dictionary for “Policy input model”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M06.05-C001-T05 · Prerequisite contract:** Map “Policy input model” to the source component prerequisites (UC-M03.08, UC-M04.08, UC-M06.03); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M06.05-C001-T06 · Authority map:** Identify who may produce, change and consume “Policy input model”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M06.05-C001-T07 · Invariant clause:** Add a normative clause for “Policy input model” that preserves “Policy evaluates validated facts rather than unchecked cargo declarations”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M06.05-C001-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Policy input model”; include the source counterexample “A manifest falsely declares an enforced isolation capability” and the intended safe disposition.
- [ ] **UC-M06.05-C001-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Input fields and evidence references” in the “Policy input model” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M06.05-C001-T10 · Contract review:** Review the “Policy input model” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M06.05-C002 · Delivery

**Original checklist item:** Collect provenance, isolation, resources, devices and networking into typed admission inputs.

- [ ] **UC-M06.05-C002-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Policy input model”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M06.05-C002-T02 · Change plan:** Break the source delivery for “Policy input model” into concrete edit targets and reviewable outputs; keep the UC-M06.05 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M06.05-C002-T03 · Core artifact:** Create the “Policy input model” output artifact for this source instruction: Collect provenance, isolation, resources, devices and networking into typed admission inputs.
- [ ] **UC-M06.05-C002-T04 · Concrete realization:** Populate the “Policy input model” artifact from identified observations; keep unknown, failed and unexecuted results distinct and exclude unapproved sensitive material.
- [ ] **UC-M06.05-C002-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Policy input model” needed to preserve “Policy evaluates validated facts rather than unchecked cargo declarations”; record an enforcement gap where only a model exists.
- [ ] **UC-M06.05-C002-T06 · Dependency connection:** Connect the “Policy input model” implementation to validated provenance, exercised host capabilities and pre-execution reservations; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M06.05-C002-T07 · Resource behavior:** Account for “Input fields and evidence references” in “Policy input model”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M06.05-C002-T08 · Delivery check:** Run the smallest real “Policy input model” path and its adverse fixture “A manifest falsely declares an enforced isolation capability”; retain actual output, state effects and final disposition.
- [ ] **UC-M06.05-C002-T09 · Patch review:** Review the “Policy input model” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M06.05-C002-T10 · Delivery handoff:** Publish the “Policy input model” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M06.05-C003 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Policy evaluates validated facts rather than unchecked cargo declarations. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M06.05-C003-T01 · Named property:** Create a stable property/check name under this parent for “Policy input model”; copy its required invariant exactly: “Policy evaluates validated facts rather than unchecked cargo declarations”.
- [ ] **UC-M06.05-C003-T02 · Observable terms:** Define each term in the “Policy input model” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M06.05-C003-T03 · Precondition set:** List the preconditions under which “Policy evaluates validated facts rather than unchecked cargo declarations” must hold for “Policy input model”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M06.05-C003-T04 · Transition coverage:** Map the “Policy input model” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M06.05-C003-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Policy input model”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M06.05-C003-T06 · Satisfying fixture:** Create a concrete “Policy input model” case that satisfies “Policy evaluates validated facts rather than unchecked cargo declarations”; record its expected observation before running the assertion or review.
- [ ] **UC-M06.05-C003-T07 · Violating fixture:** Create the source counterexample “A manifest falsely declares an enforced isolation capability” for “Policy input model”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M06.05-C003-T08 · Enforcement evidence:** Exercise the “Policy input model” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M06.05-C003-T09 · Regression linkage:** Link the “Policy input model” property to changes in validated provenance, exercised host capabilities and pre-execution reservations; record which dependency or contract changes require rerunning it.
- [ ] **UC-M06.05-C003-T10 · Property disposition:** Compare the satisfying and violating “Policy input model” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M06.05-C004 · Integration

**Original checklist item:** Integrate policy input model with validated provenance, exercised host capabilities and pre-execution reservations; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M06.05-C004-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Policy input model” across validated provenance, exercised host capabilities and pre-execution reservations; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M06.05-C004-T02 · Field mapping:** Map every “Policy input model” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M06.05-C004-T03 · Prerequisite identities:** Record the actual prerequisites for “Policy input model” (source dependency list: UC-M03.08, UC-M04.08, UC-M06.03); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M06.05-C004-T04 · Ownership agreement:** Specify who owns “Policy input model” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M06.05-C004-T05 · Handoff implementation:** Connect “Policy input model” through the mapped seam using the real adapter or explicit specification reference; preserve “Policy evaluates validated facts rather than unchecked cargo declarations” across the handoff.
- [ ] **UC-M06.05-C004-T06 · Absent-input case:** Omit one required “Policy input model” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M06.05-C004-T07 · Stale-input case:** Supply an outdated “Policy input model” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M06.05-C004-T08 · Incompatible-input case:** Supply an incompatible “Policy input model” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M06.05-C004-T09 · Valid integration trace:** Run a valid “Policy input model” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M06.05-C004-T10 · Seam review:** Reconcile the “Policy input model” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M06.05-C005 · Valid-case test

**Original checklist item:** Run a valid-path fixture for policy input model; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M06.05-C005-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Policy input model” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M06.05-C005-T02 · Expected-result oracle:** Specify the “Policy input model” expected result independently of the implementation output; include the property “Policy evaluates validated facts rather than unchecked cargo declarations” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M06.05-C005-T03 · Fixture material:** Create the concrete “Policy input model” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M06.05-C005-T04 · Target preparation:** Prepare the “Policy input model” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M06.05-C005-T05 · Initial-state record:** Record the initial “Policy input model” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M06.05-C005-T06 · Valid-path execution:** Execute the “Policy input model” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M06.05-C005-T07 · Outcome comparison:** Compare every declared “Policy input model” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M06.05-C005-T08 · State and bounds check:** Inspect the “Policy input model” ownership/state effects and actual use of “Input fields and evidence references”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M06.05-C005-T09 · Repeatability check:** Repeat the same “Policy input model” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M06.05-C005-T10 · Positive evidence:** Attach the “Policy input model” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M06.05-C006 · Negative test

**Original checklist item:** Negative case: A manifest falsely declares an enforced isolation capability. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M06.05-C006-T01 · Adverse-case definition:** Create a test record for the exact “Policy input model” source counterexample: “A manifest falsely declares an enforced isolation capability”; state which precondition or invariant it challenges.
- [ ] **UC-M06.05-C006-T02 · Safe fixture boundary:** Define the contained test boundary for “Policy input model”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M06.05-C006-T03 · Valid control:** Construct a valid “Policy input model” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M06.05-C006-T04 · Minimal adverse input:** Derive the “Policy input model” adverse fixture from the control with the smallest documented change needed to reproduce “A manifest falsely declares an enforced isolation capability”; retain that change as reproducible data.
- [ ] **UC-M06.05-C006-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Policy input model”; require “Policy evaluates validated facts rather than unchecked cargo declarations” and forbid a false-success verdict.
- [ ] **UC-M06.05-C006-T06 · Adverse execution:** Exercise the “Policy input model” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M06.05-C006-T07 · Effect inspection:** Inspect “Policy input model” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M06.05-C006-T08 · Refusal versus failure:** Confirm the “Policy input model” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M06.05-C006-T09 · Reset and retention:** Restore only the disposable “Policy input model” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M06.05-C006-T10 · Negative regression:** Register the “Policy input model” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M06.05-C007 · Change / failure test

**Original checklist item:** Exercise policy input model when policy or capability evidence changes before an approved queued request starts; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M06.05-C007-T01 · Scenario record:** Write the “Policy input model” change/failure scenario exactly as supplied: policy or capability evidence changes before an approved queued request starts; identify the property that must remain true: “Policy evaluates validated facts rather than unchecked cargo declarations”.
- [ ] **UC-M06.05-C007-T02 · Baseline capture:** Create a known-valid “Policy input model” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M06.05-C007-T03 · Injection map:** Locate the “Policy input model” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M06.05-C007-T04 · Disposition oracle:** Define the legal intermediate and final “Policy input model” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M06.05-C007-T05 · Controlled trigger:** Introduce the controlled “Policy input model” scenario in the disposable fixture: policy or capability evidence changes before an approved queued request starts; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M06.05-C007-T06 · Intermediate inspection:** Inspect the “Policy input model” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M06.05-C007-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Policy input model”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M06.05-C007-T08 · Stale-evidence cleanup:** Invalidate superseded “Policy input model” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M06.05-C007-T09 · Repeat and compare:** Repeat the selected “Policy input model” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M06.05-C007-T10 · Failure evidence:** Publish the “Policy input model” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M06.05-C008 · Bounds

**Original checklist item:** Choose, document and test limits for input fields and evidence references; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M06.05-C008-T01 · Quantity inventory:** Create a measurement inventory for “Policy input model”: “Input fields and evidence references”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M06.05-C008-T02 · Measurement method:** Choose how to observe each “Policy input model” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M06.05-C008-T03 · Budget decision:** Select justified resource and input limits for “Policy input model”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M06.05-C008-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Policy input model” cases for “Input fields and evidence references”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M06.05-C008-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Policy input model” limit; preserve “Policy evaluates validated facts rather than unchecked cargo declarations”.
- [ ] **UC-M06.05-C008-T06 · Normal measurement:** Run or review the normal “Policy input model” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M06.05-C008-T07 · At-limit measurement:** Exercise the “Policy input model” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M06.05-C008-T08 · Over-limit measurement:** Exercise the “Policy input model” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M06.05-C008-T09 · Uncovered-scope report:** List the “Policy input model” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M06.05-C008-T10 · Limit evidence:** Publish the selected “Policy input model” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M06.05-C009 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for policy input model with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M06.05-C009-T01 · Event inventory:** List the “Policy input model” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M06.05-C009-T02 · Diagnostic schema:** Define nonsecret fields for “Policy input model” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M06.05-C009-T03 · Failure mapping:** Map each documented “Policy input model” refusal or error to a diagnostic outcome; include “A manifest falsely declares an enforced isolation capability” and prohibit conversion into a success message.
- [ ] **UC-M06.05-C009-T04 · Emission path:** Add the “Policy input model” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M06.05-C009-T05 · Redaction check:** Test “Policy input model” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M06.05-C009-T06 · Output budget:** Set and exercise bounded “Policy input model” message size, rate and retention compatible with “Input fields and evidence references”; define truncation behavior that preserves the final reason.
- [ ] **UC-M06.05-C009-T07 · Success/refusal fixtures:** Capture “Policy input model” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M06.05-C009-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Policy input model” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M06.05-C009-T09 · Operator review:** Read the “Policy input model” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M06.05-C009-T10 · Diagnostic evidence:** Publish redacted “Policy input model” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M06.05-C010 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for policy input model; label unexecuted checks as untested.

- [ ] **UC-M06.05-C010-T01 · Evidence inventory:** List the “Policy input model” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M06.05-C010-T02 · Artifact references:** Record the exact “Policy input model” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M06.05-C010-T03 · Fixture references:** Attach the “Policy input model” fixture IDs, input identities and oracle definition; preserve the source counterexample “A manifest falsely declares an enforced isolation capability” as a distinct evidence case.
- [ ] **UC-M06.05-C010-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Policy input model”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M06.05-C010-T05 · Environment record:** Record the actual “Policy input model” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M06.05-C010-T06 · Expected versus observed:** Pair every “Policy input model” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M06.05-C010-T07 · Failure and limit records:** Attach “Policy input model” change/failure and bounds evidence where required; include uncovered “Input fields and evidence references” and unresolved violations of “Policy evaluates validated facts rather than unchecked cargo declarations”.
- [ ] **UC-M06.05-C010-T08 · Evidence hygiene:** Check the “Policy input model” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M06.05-C010-T09 · Reproduction review:** Have the “Policy input model” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M06.05-C010-T10 · Acceptance linkage:** Link the “Policy input model” evidence to its parent and UC-M06.05 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 02. Policy identity

**Source delivery:** Version and identify the policy applied to each admission decision.

**Source invariant:** An outcome is attributable to a specific policy version.

**Source negative case:** A mutable policy changes after an unexplained approval.

**Source bounded quantities:** Policy bytes and version retention.

### UC-M06.05-C011 · Contract

**Original checklist item:** Specify policy identity inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M06.05-C011-T01 · Scope statement:** Draft the operation boundary for “Policy identity” within Policy-as-code admission evaluator; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M06.05-C011-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Policy identity”; record each producer, representation and missing-value meaning.
- [ ] **UC-M06.05-C011-T03 · Output inventory:** List the outputs of “Policy identity” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M06.05-C011-T04 · Field dictionary:** Create a field-and-term dictionary for “Policy identity”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M06.05-C011-T05 · Prerequisite contract:** Map “Policy identity” to the source component prerequisites (UC-M03.08, UC-M04.08, UC-M06.03); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M06.05-C011-T06 · Authority map:** Identify who may produce, change and consume “Policy identity”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M06.05-C011-T07 · Invariant clause:** Add a normative clause for “Policy identity” that preserves “An outcome is attributable to a specific policy version”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M06.05-C011-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Policy identity”; include the source counterexample “A mutable policy changes after an unexplained approval” and the intended safe disposition.
- [ ] **UC-M06.05-C011-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Policy bytes and version retention” in the “Policy identity” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M06.05-C011-T10 · Contract review:** Review the “Policy identity” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M06.05-C012 · Delivery

**Original checklist item:** Version and identify the policy applied to each admission decision.

- [ ] **UC-M06.05-C012-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Policy identity”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M06.05-C012-T02 · Change plan:** Break the source delivery for “Policy identity” into concrete edit targets and reviewable outputs; keep the UC-M06.05 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M06.05-C012-T03 · Core artifact:** Implement the smallest selected-profile change for “Policy identity” that realizes this source instruction: Version and identify the policy applied to each admission decision.
- [ ] **UC-M06.05-C012-T04 · Concrete realization:** Trace “Policy identity” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M06.05-C012-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Policy identity” needed to preserve “An outcome is attributable to a specific policy version”; record an enforcement gap where only a model exists.
- [ ] **UC-M06.05-C012-T06 · Dependency connection:** Connect the “Policy identity” implementation to validated provenance, exercised host capabilities and pre-execution reservations; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M06.05-C012-T07 · Resource behavior:** Account for “Policy bytes and version retention” in “Policy identity”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M06.05-C012-T08 · Delivery check:** Run the smallest real “Policy identity” path and its adverse fixture “A mutable policy changes after an unexplained approval”; retain actual output, state effects and final disposition.
- [ ] **UC-M06.05-C012-T09 · Patch review:** Review the “Policy identity” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M06.05-C012-T10 · Delivery handoff:** Publish the “Policy identity” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M06.05-C013 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: An outcome is attributable to a specific policy version. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M06.05-C013-T01 · Named property:** Create a stable property/check name under this parent for “Policy identity”; copy its required invariant exactly: “An outcome is attributable to a specific policy version”.
- [ ] **UC-M06.05-C013-T02 · Observable terms:** Define each term in the “Policy identity” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M06.05-C013-T03 · Precondition set:** List the preconditions under which “An outcome is attributable to a specific policy version” must hold for “Policy identity”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M06.05-C013-T04 · Transition coverage:** Map the “Policy identity” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M06.05-C013-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Policy identity”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M06.05-C013-T06 · Satisfying fixture:** Create a concrete “Policy identity” case that satisfies “An outcome is attributable to a specific policy version”; record its expected observation before running the assertion or review.
- [ ] **UC-M06.05-C013-T07 · Violating fixture:** Create the source counterexample “A mutable policy changes after an unexplained approval” for “Policy identity”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M06.05-C013-T08 · Enforcement evidence:** Exercise the “Policy identity” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M06.05-C013-T09 · Regression linkage:** Link the “Policy identity” property to changes in validated provenance, exercised host capabilities and pre-execution reservations; record which dependency or contract changes require rerunning it.
- [ ] **UC-M06.05-C013-T10 · Property disposition:** Compare the satisfying and violating “Policy identity” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M06.05-C014 · Integration

**Original checklist item:** Integrate policy identity with validated provenance, exercised host capabilities and pre-execution reservations; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M06.05-C014-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Policy identity” across validated provenance, exercised host capabilities and pre-execution reservations; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M06.05-C014-T02 · Field mapping:** Map every “Policy identity” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M06.05-C014-T03 · Prerequisite identities:** Record the actual prerequisites for “Policy identity” (source dependency list: UC-M03.08, UC-M04.08, UC-M06.03); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M06.05-C014-T04 · Ownership agreement:** Specify who owns “Policy identity” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M06.05-C014-T05 · Handoff implementation:** Connect “Policy identity” through the mapped seam using the real adapter or explicit specification reference; preserve “An outcome is attributable to a specific policy version” across the handoff.
- [ ] **UC-M06.05-C014-T06 · Absent-input case:** Omit one required “Policy identity” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M06.05-C014-T07 · Stale-input case:** Supply an outdated “Policy identity” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M06.05-C014-T08 · Incompatible-input case:** Supply an incompatible “Policy identity” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M06.05-C014-T09 · Valid integration trace:** Run a valid “Policy identity” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M06.05-C014-T10 · Seam review:** Reconcile the “Policy identity” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M06.05-C015 · Valid-case test

**Original checklist item:** Run a valid-path fixture for policy identity; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M06.05-C015-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Policy identity” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M06.05-C015-T02 · Expected-result oracle:** Specify the “Policy identity” expected result independently of the implementation output; include the property “An outcome is attributable to a specific policy version” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M06.05-C015-T03 · Fixture material:** Create the concrete “Policy identity” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M06.05-C015-T04 · Target preparation:** Prepare the “Policy identity” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M06.05-C015-T05 · Initial-state record:** Record the initial “Policy identity” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M06.05-C015-T06 · Valid-path execution:** Execute the “Policy identity” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M06.05-C015-T07 · Outcome comparison:** Compare every declared “Policy identity” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M06.05-C015-T08 · State and bounds check:** Inspect the “Policy identity” ownership/state effects and actual use of “Policy bytes and version retention”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M06.05-C015-T09 · Repeatability check:** Repeat the same “Policy identity” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M06.05-C015-T10 · Positive evidence:** Attach the “Policy identity” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M06.05-C016 · Negative test

**Original checklist item:** Negative case: A mutable policy changes after an unexplained approval. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M06.05-C016-T01 · Adverse-case definition:** Create a test record for the exact “Policy identity” source counterexample: “A mutable policy changes after an unexplained approval”; state which precondition or invariant it challenges.
- [ ] **UC-M06.05-C016-T02 · Safe fixture boundary:** Define the contained test boundary for “Policy identity”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M06.05-C016-T03 · Valid control:** Construct a valid “Policy identity” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M06.05-C016-T04 · Minimal adverse input:** Derive the “Policy identity” adverse fixture from the control with the smallest documented change needed to reproduce “A mutable policy changes after an unexplained approval”; retain that change as reproducible data.
- [ ] **UC-M06.05-C016-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Policy identity”; require “An outcome is attributable to a specific policy version” and forbid a false-success verdict.
- [ ] **UC-M06.05-C016-T06 · Adverse execution:** Exercise the “Policy identity” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M06.05-C016-T07 · Effect inspection:** Inspect “Policy identity” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M06.05-C016-T08 · Refusal versus failure:** Confirm the “Policy identity” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M06.05-C016-T09 · Reset and retention:** Restore only the disposable “Policy identity” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M06.05-C016-T10 · Negative regression:** Register the “Policy identity” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M06.05-C017 · Change / failure test

**Original checklist item:** Exercise policy identity when policy or capability evidence changes before an approved queued request starts; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M06.05-C017-T01 · Scenario record:** Write the “Policy identity” change/failure scenario exactly as supplied: policy or capability evidence changes before an approved queued request starts; identify the property that must remain true: “An outcome is attributable to a specific policy version”.
- [ ] **UC-M06.05-C017-T02 · Baseline capture:** Create a known-valid “Policy identity” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M06.05-C017-T03 · Injection map:** Locate the “Policy identity” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M06.05-C017-T04 · Disposition oracle:** Define the legal intermediate and final “Policy identity” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M06.05-C017-T05 · Controlled trigger:** Introduce the controlled “Policy identity” scenario in the disposable fixture: policy or capability evidence changes before an approved queued request starts; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M06.05-C017-T06 · Intermediate inspection:** Inspect the “Policy identity” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M06.05-C017-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Policy identity”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M06.05-C017-T08 · Stale-evidence cleanup:** Invalidate superseded “Policy identity” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M06.05-C017-T09 · Repeat and compare:** Repeat the selected “Policy identity” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M06.05-C017-T10 · Failure evidence:** Publish the “Policy identity” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M06.05-C018 · Bounds

**Original checklist item:** Choose, document and test limits for policy bytes and version retention; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M06.05-C018-T01 · Quantity inventory:** Create a measurement inventory for “Policy identity”: “Policy bytes and version retention”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M06.05-C018-T02 · Measurement method:** Choose how to observe each “Policy identity” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M06.05-C018-T03 · Budget decision:** Select justified resource and input limits for “Policy identity”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M06.05-C018-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Policy identity” cases for “Policy bytes and version retention”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M06.05-C018-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Policy identity” limit; preserve “An outcome is attributable to a specific policy version”.
- [ ] **UC-M06.05-C018-T06 · Normal measurement:** Run or review the normal “Policy identity” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M06.05-C018-T07 · At-limit measurement:** Exercise the “Policy identity” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M06.05-C018-T08 · Over-limit measurement:** Exercise the “Policy identity” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M06.05-C018-T09 · Uncovered-scope report:** List the “Policy identity” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M06.05-C018-T10 · Limit evidence:** Publish the selected “Policy identity” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M06.05-C019 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for policy identity with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M06.05-C019-T01 · Event inventory:** List the “Policy identity” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M06.05-C019-T02 · Diagnostic schema:** Define nonsecret fields for “Policy identity” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M06.05-C019-T03 · Failure mapping:** Map each documented “Policy identity” refusal or error to a diagnostic outcome; include “A mutable policy changes after an unexplained approval” and prohibit conversion into a success message.
- [ ] **UC-M06.05-C019-T04 · Emission path:** Add the “Policy identity” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M06.05-C019-T05 · Redaction check:** Test “Policy identity” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M06.05-C019-T06 · Output budget:** Set and exercise bounded “Policy identity” message size, rate and retention compatible with “Policy bytes and version retention”; define truncation behavior that preserves the final reason.
- [ ] **UC-M06.05-C019-T07 · Success/refusal fixtures:** Capture “Policy identity” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M06.05-C019-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Policy identity” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M06.05-C019-T09 · Operator review:** Read the “Policy identity” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M06.05-C019-T10 · Diagnostic evidence:** Publish redacted “Policy identity” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M06.05-C020 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for policy identity; label unexecuted checks as untested.

- [ ] **UC-M06.05-C020-T01 · Evidence inventory:** List the “Policy identity” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M06.05-C020-T02 · Artifact references:** Record the exact “Policy identity” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M06.05-C020-T03 · Fixture references:** Attach the “Policy identity” fixture IDs, input identities and oracle definition; preserve the source counterexample “A mutable policy changes after an unexplained approval” as a distinct evidence case.
- [ ] **UC-M06.05-C020-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Policy identity”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M06.05-C020-T05 · Environment record:** Record the actual “Policy identity” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M06.05-C020-T06 · Expected versus observed:** Pair every “Policy identity” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M06.05-C020-T07 · Failure and limit records:** Attach “Policy identity” change/failure and bounds evidence where required; include uncovered “Policy bytes and version retention” and unresolved violations of “An outcome is attributable to a specific policy version”.
- [ ] **UC-M06.05-C020-T08 · Evidence hygiene:** Check the “Policy identity” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M06.05-C020-T09 · Reproduction review:** Have the “Policy identity” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M06.05-C020-T10 · Acceptance linkage:** Link the “Policy identity” evidence to its parent and UC-M06.05 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 03. Provenance rules

**Source delivery:** Evaluate required authenticated build and image provenance.

**Source invariant:** Missing required provenance cannot be replaced by a checksum match.

**Source negative case:** An intact image lacks an approved build relationship.

**Source bounded quantities:** Attestation count and verification cost.

### UC-M06.05-C021 · Contract

**Original checklist item:** Specify provenance rules inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M06.05-C021-T01 · Scope statement:** Draft the operation boundary for “Provenance rules” within Policy-as-code admission evaluator; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M06.05-C021-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Provenance rules”; record each producer, representation and missing-value meaning.
- [ ] **UC-M06.05-C021-T03 · Output inventory:** List the outputs of “Provenance rules” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M06.05-C021-T04 · Field dictionary:** Create a field-and-term dictionary for “Provenance rules”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M06.05-C021-T05 · Prerequisite contract:** Map “Provenance rules” to the source component prerequisites (UC-M03.08, UC-M04.08, UC-M06.03); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M06.05-C021-T06 · Authority map:** Identify who may produce, change and consume “Provenance rules”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M06.05-C021-T07 · Invariant clause:** Add a normative clause for “Provenance rules” that preserves “Missing required provenance cannot be replaced by a checksum match”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M06.05-C021-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Provenance rules”; include the source counterexample “An intact image lacks an approved build relationship” and the intended safe disposition.
- [ ] **UC-M06.05-C021-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Attestation count and verification cost” in the “Provenance rules” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M06.05-C021-T10 · Contract review:** Review the “Provenance rules” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M06.05-C022 · Delivery

**Original checklist item:** Evaluate required authenticated build and image provenance.

- [ ] **UC-M06.05-C022-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Provenance rules”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M06.05-C022-T02 · Change plan:** Break the source delivery for “Provenance rules” into concrete edit targets and reviewable outputs; keep the UC-M06.05 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M06.05-C022-T03 · Core artifact:** Implement the smallest selected-profile change for “Provenance rules” that realizes this source instruction: Evaluate required authenticated build and image provenance.
- [ ] **UC-M06.05-C022-T04 · Concrete realization:** Trace “Provenance rules” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M06.05-C022-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Provenance rules” needed to preserve “Missing required provenance cannot be replaced by a checksum match”; record an enforcement gap where only a model exists.
- [ ] **UC-M06.05-C022-T06 · Dependency connection:** Connect the “Provenance rules” implementation to validated provenance, exercised host capabilities and pre-execution reservations; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M06.05-C022-T07 · Resource behavior:** Account for “Attestation count and verification cost” in “Provenance rules”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M06.05-C022-T08 · Delivery check:** Run the smallest real “Provenance rules” path and its adverse fixture “An intact image lacks an approved build relationship”; retain actual output, state effects and final disposition.
- [ ] **UC-M06.05-C022-T09 · Patch review:** Review the “Provenance rules” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M06.05-C022-T10 · Delivery handoff:** Publish the “Provenance rules” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M06.05-C023 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Missing required provenance cannot be replaced by a checksum match. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M06.05-C023-T01 · Named property:** Create a stable property/check name under this parent for “Provenance rules”; copy its required invariant exactly: “Missing required provenance cannot be replaced by a checksum match”.
- [ ] **UC-M06.05-C023-T02 · Observable terms:** Define each term in the “Provenance rules” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M06.05-C023-T03 · Precondition set:** List the preconditions under which “Missing required provenance cannot be replaced by a checksum match” must hold for “Provenance rules”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M06.05-C023-T04 · Transition coverage:** Map the “Provenance rules” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M06.05-C023-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Provenance rules”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M06.05-C023-T06 · Satisfying fixture:** Create a concrete “Provenance rules” case that satisfies “Missing required provenance cannot be replaced by a checksum match”; record its expected observation before running the assertion or review.
- [ ] **UC-M06.05-C023-T07 · Violating fixture:** Create the source counterexample “An intact image lacks an approved build relationship” for “Provenance rules”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M06.05-C023-T08 · Enforcement evidence:** Exercise the “Provenance rules” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M06.05-C023-T09 · Regression linkage:** Link the “Provenance rules” property to changes in validated provenance, exercised host capabilities and pre-execution reservations; record which dependency or contract changes require rerunning it.
- [ ] **UC-M06.05-C023-T10 · Property disposition:** Compare the satisfying and violating “Provenance rules” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M06.05-C024 · Integration

**Original checklist item:** Integrate provenance rules with validated provenance, exercised host capabilities and pre-execution reservations; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M06.05-C024-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Provenance rules” across validated provenance, exercised host capabilities and pre-execution reservations; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M06.05-C024-T02 · Field mapping:** Map every “Provenance rules” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M06.05-C024-T03 · Prerequisite identities:** Record the actual prerequisites for “Provenance rules” (source dependency list: UC-M03.08, UC-M04.08, UC-M06.03); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M06.05-C024-T04 · Ownership agreement:** Specify who owns “Provenance rules” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M06.05-C024-T05 · Handoff implementation:** Connect “Provenance rules” through the mapped seam using the real adapter or explicit specification reference; preserve “Missing required provenance cannot be replaced by a checksum match” across the handoff.
- [ ] **UC-M06.05-C024-T06 · Absent-input case:** Omit one required “Provenance rules” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M06.05-C024-T07 · Stale-input case:** Supply an outdated “Provenance rules” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M06.05-C024-T08 · Incompatible-input case:** Supply an incompatible “Provenance rules” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M06.05-C024-T09 · Valid integration trace:** Run a valid “Provenance rules” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M06.05-C024-T10 · Seam review:** Reconcile the “Provenance rules” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M06.05-C025 · Valid-case test

**Original checklist item:** Run a valid-path fixture for provenance rules; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M06.05-C025-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Provenance rules” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M06.05-C025-T02 · Expected-result oracle:** Specify the “Provenance rules” expected result independently of the implementation output; include the property “Missing required provenance cannot be replaced by a checksum match” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M06.05-C025-T03 · Fixture material:** Create the concrete “Provenance rules” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M06.05-C025-T04 · Target preparation:** Prepare the “Provenance rules” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M06.05-C025-T05 · Initial-state record:** Record the initial “Provenance rules” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M06.05-C025-T06 · Valid-path execution:** Execute the “Provenance rules” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M06.05-C025-T07 · Outcome comparison:** Compare every declared “Provenance rules” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M06.05-C025-T08 · State and bounds check:** Inspect the “Provenance rules” ownership/state effects and actual use of “Attestation count and verification cost”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M06.05-C025-T09 · Repeatability check:** Repeat the same “Provenance rules” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M06.05-C025-T10 · Positive evidence:** Attach the “Provenance rules” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M06.05-C026 · Negative test

**Original checklist item:** Negative case: An intact image lacks an approved build relationship. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M06.05-C026-T01 · Adverse-case definition:** Create a test record for the exact “Provenance rules” source counterexample: “An intact image lacks an approved build relationship”; state which precondition or invariant it challenges.
- [ ] **UC-M06.05-C026-T02 · Safe fixture boundary:** Define the contained test boundary for “Provenance rules”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M06.05-C026-T03 · Valid control:** Construct a valid “Provenance rules” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M06.05-C026-T04 · Minimal adverse input:** Derive the “Provenance rules” adverse fixture from the control with the smallest documented change needed to reproduce “An intact image lacks an approved build relationship”; retain that change as reproducible data.
- [ ] **UC-M06.05-C026-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Provenance rules”; require “Missing required provenance cannot be replaced by a checksum match” and forbid a false-success verdict.
- [ ] **UC-M06.05-C026-T06 · Adverse execution:** Exercise the “Provenance rules” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M06.05-C026-T07 · Effect inspection:** Inspect “Provenance rules” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M06.05-C026-T08 · Refusal versus failure:** Confirm the “Provenance rules” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M06.05-C026-T09 · Reset and retention:** Restore only the disposable “Provenance rules” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M06.05-C026-T10 · Negative regression:** Register the “Provenance rules” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M06.05-C027 · Change / failure test

**Original checklist item:** Exercise provenance rules when policy or capability evidence changes before an approved queued request starts; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M06.05-C027-T01 · Scenario record:** Write the “Provenance rules” change/failure scenario exactly as supplied: policy or capability evidence changes before an approved queued request starts; identify the property that must remain true: “Missing required provenance cannot be replaced by a checksum match”.
- [ ] **UC-M06.05-C027-T02 · Baseline capture:** Create a known-valid “Provenance rules” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M06.05-C027-T03 · Injection map:** Locate the “Provenance rules” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M06.05-C027-T04 · Disposition oracle:** Define the legal intermediate and final “Provenance rules” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M06.05-C027-T05 · Controlled trigger:** Introduce the controlled “Provenance rules” scenario in the disposable fixture: policy or capability evidence changes before an approved queued request starts; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M06.05-C027-T06 · Intermediate inspection:** Inspect the “Provenance rules” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M06.05-C027-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Provenance rules”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M06.05-C027-T08 · Stale-evidence cleanup:** Invalidate superseded “Provenance rules” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M06.05-C027-T09 · Repeat and compare:** Repeat the selected “Provenance rules” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M06.05-C027-T10 · Failure evidence:** Publish the “Provenance rules” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M06.05-C028 · Bounds

**Original checklist item:** Choose, document and test limits for attestation count and verification cost; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M06.05-C028-T01 · Quantity inventory:** Create a measurement inventory for “Provenance rules”: “Attestation count and verification cost”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M06.05-C028-T02 · Measurement method:** Choose how to observe each “Provenance rules” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M06.05-C028-T03 · Budget decision:** Select justified resource and input limits for “Provenance rules”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M06.05-C028-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Provenance rules” cases for “Attestation count and verification cost”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M06.05-C028-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Provenance rules” limit; preserve “Missing required provenance cannot be replaced by a checksum match”.
- [ ] **UC-M06.05-C028-T06 · Normal measurement:** Run or review the normal “Provenance rules” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M06.05-C028-T07 · At-limit measurement:** Exercise the “Provenance rules” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M06.05-C028-T08 · Over-limit measurement:** Exercise the “Provenance rules” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M06.05-C028-T09 · Uncovered-scope report:** List the “Provenance rules” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M06.05-C028-T10 · Limit evidence:** Publish the selected “Provenance rules” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M06.05-C029 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for provenance rules with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M06.05-C029-T01 · Event inventory:** List the “Provenance rules” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M06.05-C029-T02 · Diagnostic schema:** Define nonsecret fields for “Provenance rules” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M06.05-C029-T03 · Failure mapping:** Map each documented “Provenance rules” refusal or error to a diagnostic outcome; include “An intact image lacks an approved build relationship” and prohibit conversion into a success message.
- [ ] **UC-M06.05-C029-T04 · Emission path:** Add the “Provenance rules” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M06.05-C029-T05 · Redaction check:** Test “Provenance rules” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M06.05-C029-T06 · Output budget:** Set and exercise bounded “Provenance rules” message size, rate and retention compatible with “Attestation count and verification cost”; define truncation behavior that preserves the final reason.
- [ ] **UC-M06.05-C029-T07 · Success/refusal fixtures:** Capture “Provenance rules” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M06.05-C029-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Provenance rules” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M06.05-C029-T09 · Operator review:** Read the “Provenance rules” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M06.05-C029-T10 · Diagnostic evidence:** Publish redacted “Provenance rules” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M06.05-C030 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for provenance rules; label unexecuted checks as untested.

- [ ] **UC-M06.05-C030-T01 · Evidence inventory:** List the “Provenance rules” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M06.05-C030-T02 · Artifact references:** Record the exact “Provenance rules” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M06.05-C030-T03 · Fixture references:** Attach the “Provenance rules” fixture IDs, input identities and oracle definition; preserve the source counterexample “An intact image lacks an approved build relationship” as a distinct evidence case.
- [ ] **UC-M06.05-C030-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Provenance rules”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M06.05-C030-T05 · Environment record:** Record the actual “Provenance rules” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M06.05-C030-T06 · Expected versus observed:** Pair every “Provenance rules” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M06.05-C030-T07 · Failure and limit records:** Attach “Provenance rules” change/failure and bounds evidence where required; include uncovered “Attestation count and verification cost” and unresolved violations of “Missing required provenance cannot be replaced by a checksum match”.
- [ ] **UC-M06.05-C030-T08 · Evidence hygiene:** Check the “Provenance rules” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M06.05-C030-T09 · Reproduction review:** Have the “Provenance rules” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M06.05-C030-T10 · Acceptance linkage:** Link the “Provenance rules” evidence to its parent and UC-M06.05 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 04. Isolation rules

**Source delivery:** Compare required isolation with exercised backend capability evidence.

**Source invariant:** Policy cannot approve a required boundary that the host lacks.

**Source negative case:** A host-process backend requests an isolated-guest approval.

**Source bounded quantities:** Capability comparisons and evidence freshness.

### UC-M06.05-C031 · Contract

**Original checklist item:** Specify isolation rules inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M06.05-C031-T01 · Scope statement:** Draft the operation boundary for “Isolation rules” within Policy-as-code admission evaluator; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M06.05-C031-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Isolation rules”; record each producer, representation and missing-value meaning.
- [ ] **UC-M06.05-C031-T03 · Output inventory:** List the outputs of “Isolation rules” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M06.05-C031-T04 · Field dictionary:** Create a field-and-term dictionary for “Isolation rules”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M06.05-C031-T05 · Prerequisite contract:** Map “Isolation rules” to the source component prerequisites (UC-M03.08, UC-M04.08, UC-M06.03); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M06.05-C031-T06 · Authority map:** Identify who may produce, change and consume “Isolation rules”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M06.05-C031-T07 · Invariant clause:** Add a normative clause for “Isolation rules” that preserves “Policy cannot approve a required boundary that the host lacks”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M06.05-C031-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Isolation rules”; include the source counterexample “A host-process backend requests an isolated-guest approval” and the intended safe disposition.
- [ ] **UC-M06.05-C031-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Capability comparisons and evidence freshness” in the “Isolation rules” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M06.05-C031-T10 · Contract review:** Review the “Isolation rules” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M06.05-C032 · Delivery

**Original checklist item:** Compare required isolation with exercised backend capability evidence.

- [ ] **UC-M06.05-C032-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Isolation rules”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M06.05-C032-T02 · Change plan:** Break the source delivery for “Isolation rules” into concrete edit targets and reviewable outputs; keep the UC-M06.05 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M06.05-C032-T03 · Core artifact:** Create the “Isolation rules” fixture or harness for this source instruction: Compare required isolation with exercised backend capability evidence.
- [ ] **UC-M06.05-C032-T04 · Concrete realization:** Connect the “Isolation rules” harness to its actual intended target, set the expected oracle before running it, and distinguish a mock/control run from a target run.
- [ ] **UC-M06.05-C032-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Isolation rules” needed to preserve “Policy cannot approve a required boundary that the host lacks”; record an enforcement gap where only a model exists.
- [ ] **UC-M06.05-C032-T06 · Dependency connection:** Connect the “Isolation rules” implementation to validated provenance, exercised host capabilities and pre-execution reservations; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M06.05-C032-T07 · Resource behavior:** Account for “Capability comparisons and evidence freshness” in “Isolation rules”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M06.05-C032-T08 · Delivery check:** Run the smallest real “Isolation rules” path and its adverse fixture “A host-process backend requests an isolated-guest approval”; retain actual output, state effects and final disposition.
- [ ] **UC-M06.05-C032-T09 · Patch review:** Review the “Isolation rules” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M06.05-C032-T10 · Delivery handoff:** Publish the “Isolation rules” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M06.05-C033 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Policy cannot approve a required boundary that the host lacks. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M06.05-C033-T01 · Named property:** Create a stable property/check name under this parent for “Isolation rules”; copy its required invariant exactly: “Policy cannot approve a required boundary that the host lacks”.
- [ ] **UC-M06.05-C033-T02 · Observable terms:** Define each term in the “Isolation rules” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M06.05-C033-T03 · Precondition set:** List the preconditions under which “Policy cannot approve a required boundary that the host lacks” must hold for “Isolation rules”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M06.05-C033-T04 · Transition coverage:** Map the “Isolation rules” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M06.05-C033-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Isolation rules”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M06.05-C033-T06 · Satisfying fixture:** Create a concrete “Isolation rules” case that satisfies “Policy cannot approve a required boundary that the host lacks”; record its expected observation before running the assertion or review.
- [ ] **UC-M06.05-C033-T07 · Violating fixture:** Create the source counterexample “A host-process backend requests an isolated-guest approval” for “Isolation rules”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M06.05-C033-T08 · Enforcement evidence:** Exercise the “Isolation rules” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M06.05-C033-T09 · Regression linkage:** Link the “Isolation rules” property to changes in validated provenance, exercised host capabilities and pre-execution reservations; record which dependency or contract changes require rerunning it.
- [ ] **UC-M06.05-C033-T10 · Property disposition:** Compare the satisfying and violating “Isolation rules” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M06.05-C034 · Integration

**Original checklist item:** Integrate isolation rules with validated provenance, exercised host capabilities and pre-execution reservations; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M06.05-C034-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Isolation rules” across validated provenance, exercised host capabilities and pre-execution reservations; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M06.05-C034-T02 · Field mapping:** Map every “Isolation rules” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M06.05-C034-T03 · Prerequisite identities:** Record the actual prerequisites for “Isolation rules” (source dependency list: UC-M03.08, UC-M04.08, UC-M06.03); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M06.05-C034-T04 · Ownership agreement:** Specify who owns “Isolation rules” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M06.05-C034-T05 · Handoff implementation:** Connect “Isolation rules” through the mapped seam using the real adapter or explicit specification reference; preserve “Policy cannot approve a required boundary that the host lacks” across the handoff.
- [ ] **UC-M06.05-C034-T06 · Absent-input case:** Omit one required “Isolation rules” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M06.05-C034-T07 · Stale-input case:** Supply an outdated “Isolation rules” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M06.05-C034-T08 · Incompatible-input case:** Supply an incompatible “Isolation rules” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M06.05-C034-T09 · Valid integration trace:** Run a valid “Isolation rules” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M06.05-C034-T10 · Seam review:** Reconcile the “Isolation rules” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M06.05-C035 · Valid-case test

**Original checklist item:** Run a valid-path fixture for isolation rules; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M06.05-C035-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Isolation rules” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M06.05-C035-T02 · Expected-result oracle:** Specify the “Isolation rules” expected result independently of the implementation output; include the property “Policy cannot approve a required boundary that the host lacks” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M06.05-C035-T03 · Fixture material:** Create the concrete “Isolation rules” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M06.05-C035-T04 · Target preparation:** Prepare the “Isolation rules” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M06.05-C035-T05 · Initial-state record:** Record the initial “Isolation rules” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M06.05-C035-T06 · Valid-path execution:** Execute the “Isolation rules” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M06.05-C035-T07 · Outcome comparison:** Compare every declared “Isolation rules” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M06.05-C035-T08 · State and bounds check:** Inspect the “Isolation rules” ownership/state effects and actual use of “Capability comparisons and evidence freshness”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M06.05-C035-T09 · Repeatability check:** Repeat the same “Isolation rules” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M06.05-C035-T10 · Positive evidence:** Attach the “Isolation rules” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M06.05-C036 · Negative test

**Original checklist item:** Negative case: A host-process backend requests an isolated-guest approval. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M06.05-C036-T01 · Adverse-case definition:** Create a test record for the exact “Isolation rules” source counterexample: “A host-process backend requests an isolated-guest approval”; state which precondition or invariant it challenges.
- [ ] **UC-M06.05-C036-T02 · Safe fixture boundary:** Define the contained test boundary for “Isolation rules”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M06.05-C036-T03 · Valid control:** Construct a valid “Isolation rules” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M06.05-C036-T04 · Minimal adverse input:** Derive the “Isolation rules” adverse fixture from the control with the smallest documented change needed to reproduce “A host-process backend requests an isolated-guest approval”; retain that change as reproducible data.
- [ ] **UC-M06.05-C036-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Isolation rules”; require “Policy cannot approve a required boundary that the host lacks” and forbid a false-success verdict.
- [ ] **UC-M06.05-C036-T06 · Adverse execution:** Exercise the “Isolation rules” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M06.05-C036-T07 · Effect inspection:** Inspect “Isolation rules” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M06.05-C036-T08 · Refusal versus failure:** Confirm the “Isolation rules” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M06.05-C036-T09 · Reset and retention:** Restore only the disposable “Isolation rules” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M06.05-C036-T10 · Negative regression:** Register the “Isolation rules” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M06.05-C037 · Change / failure test

**Original checklist item:** Exercise isolation rules when policy or capability evidence changes before an approved queued request starts; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M06.05-C037-T01 · Scenario record:** Write the “Isolation rules” change/failure scenario exactly as supplied: policy or capability evidence changes before an approved queued request starts; identify the property that must remain true: “Policy cannot approve a required boundary that the host lacks”.
- [ ] **UC-M06.05-C037-T02 · Baseline capture:** Create a known-valid “Isolation rules” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M06.05-C037-T03 · Injection map:** Locate the “Isolation rules” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M06.05-C037-T04 · Disposition oracle:** Define the legal intermediate and final “Isolation rules” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M06.05-C037-T05 · Controlled trigger:** Introduce the controlled “Isolation rules” scenario in the disposable fixture: policy or capability evidence changes before an approved queued request starts; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M06.05-C037-T06 · Intermediate inspection:** Inspect the “Isolation rules” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M06.05-C037-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Isolation rules”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M06.05-C037-T08 · Stale-evidence cleanup:** Invalidate superseded “Isolation rules” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M06.05-C037-T09 · Repeat and compare:** Repeat the selected “Isolation rules” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M06.05-C037-T10 · Failure evidence:** Publish the “Isolation rules” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M06.05-C038 · Bounds

**Original checklist item:** Choose, document and test limits for capability comparisons and evidence freshness; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M06.05-C038-T01 · Quantity inventory:** Create a measurement inventory for “Isolation rules”: “Capability comparisons and evidence freshness”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M06.05-C038-T02 · Measurement method:** Choose how to observe each “Isolation rules” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M06.05-C038-T03 · Budget decision:** Select justified resource and input limits for “Isolation rules”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M06.05-C038-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Isolation rules” cases for “Capability comparisons and evidence freshness”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M06.05-C038-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Isolation rules” limit; preserve “Policy cannot approve a required boundary that the host lacks”.
- [ ] **UC-M06.05-C038-T06 · Normal measurement:** Run or review the normal “Isolation rules” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M06.05-C038-T07 · At-limit measurement:** Exercise the “Isolation rules” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M06.05-C038-T08 · Over-limit measurement:** Exercise the “Isolation rules” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M06.05-C038-T09 · Uncovered-scope report:** List the “Isolation rules” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M06.05-C038-T10 · Limit evidence:** Publish the selected “Isolation rules” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M06.05-C039 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for isolation rules with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M06.05-C039-T01 · Event inventory:** List the “Isolation rules” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M06.05-C039-T02 · Diagnostic schema:** Define nonsecret fields for “Isolation rules” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M06.05-C039-T03 · Failure mapping:** Map each documented “Isolation rules” refusal or error to a diagnostic outcome; include “A host-process backend requests an isolated-guest approval” and prohibit conversion into a success message.
- [ ] **UC-M06.05-C039-T04 · Emission path:** Add the “Isolation rules” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M06.05-C039-T05 · Redaction check:** Test “Isolation rules” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M06.05-C039-T06 · Output budget:** Set and exercise bounded “Isolation rules” message size, rate and retention compatible with “Capability comparisons and evidence freshness”; define truncation behavior that preserves the final reason.
- [ ] **UC-M06.05-C039-T07 · Success/refusal fixtures:** Capture “Isolation rules” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M06.05-C039-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Isolation rules” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M06.05-C039-T09 · Operator review:** Read the “Isolation rules” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M06.05-C039-T10 · Diagnostic evidence:** Publish redacted “Isolation rules” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M06.05-C040 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for isolation rules; label unexecuted checks as untested.

- [ ] **UC-M06.05-C040-T01 · Evidence inventory:** List the “Isolation rules” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M06.05-C040-T02 · Artifact references:** Record the exact “Isolation rules” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M06.05-C040-T03 · Fixture references:** Attach the “Isolation rules” fixture IDs, input identities and oracle definition; preserve the source counterexample “A host-process backend requests an isolated-guest approval” as a distinct evidence case.
- [ ] **UC-M06.05-C040-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Isolation rules”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M06.05-C040-T05 · Environment record:** Record the actual “Isolation rules” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M06.05-C040-T06 · Expected versus observed:** Pair every “Isolation rules” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M06.05-C040-T07 · Failure and limit records:** Attach “Isolation rules” change/failure and bounds evidence where required; include uncovered “Capability comparisons and evidence freshness” and unresolved violations of “Policy cannot approve a required boundary that the host lacks”.
- [ ] **UC-M06.05-C040-T08 · Evidence hygiene:** Check the “Isolation rules” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M06.05-C040-T09 · Reproduction review:** Have the “Isolation rules” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M06.05-C040-T10 · Acceptance linkage:** Link the “Isolation rules” evidence to its parent and UC-M06.05 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 05. Resource admission rules

**Source delivery:** Evaluate aggregate reservations before allowing executable actions.

**Source invariant:** A policy approval respects hard workload and tenant budgets.

**Source negative case:** Two simultaneous approvals exceed the remaining quota.

**Source bounded quantities:** Reservations and concurrent evaluations.

### UC-M06.05-C041 · Contract

**Original checklist item:** Specify resource admission rules inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M06.05-C041-T01 · Scope statement:** Draft the operation boundary for “Resource admission rules” within Policy-as-code admission evaluator; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M06.05-C041-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Resource admission rules”; record each producer, representation and missing-value meaning.
- [ ] **UC-M06.05-C041-T03 · Output inventory:** List the outputs of “Resource admission rules” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M06.05-C041-T04 · Field dictionary:** Create a field-and-term dictionary for “Resource admission rules”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M06.05-C041-T05 · Prerequisite contract:** Map “Resource admission rules” to the source component prerequisites (UC-M03.08, UC-M04.08, UC-M06.03); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M06.05-C041-T06 · Authority map:** Identify who may produce, change and consume “Resource admission rules”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M06.05-C041-T07 · Invariant clause:** Add a normative clause for “Resource admission rules” that preserves “A policy approval respects hard workload and tenant budgets”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M06.05-C041-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Resource admission rules”; include the source counterexample “Two simultaneous approvals exceed the remaining quota” and the intended safe disposition.
- [ ] **UC-M06.05-C041-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Reservations and concurrent evaluations” in the “Resource admission rules” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M06.05-C041-T10 · Contract review:** Review the “Resource admission rules” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M06.05-C042 · Delivery

**Original checklist item:** Evaluate aggregate reservations before allowing executable actions.

- [ ] **UC-M06.05-C042-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Resource admission rules”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M06.05-C042-T02 · Change plan:** Break the source delivery for “Resource admission rules” into concrete edit targets and reviewable outputs; keep the UC-M06.05 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M06.05-C042-T03 · Core artifact:** Implement the smallest selected-profile change for “Resource admission rules” that realizes this source instruction: Evaluate aggregate reservations before allowing executable actions.
- [ ] **UC-M06.05-C042-T04 · Concrete realization:** Trace “Resource admission rules” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M06.05-C042-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Resource admission rules” needed to preserve “A policy approval respects hard workload and tenant budgets”; record an enforcement gap where only a model exists.
- [ ] **UC-M06.05-C042-T06 · Dependency connection:** Connect the “Resource admission rules” implementation to validated provenance, exercised host capabilities and pre-execution reservations; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M06.05-C042-T07 · Resource behavior:** Account for “Reservations and concurrent evaluations” in “Resource admission rules”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M06.05-C042-T08 · Delivery check:** Run the smallest real “Resource admission rules” path and its adverse fixture “Two simultaneous approvals exceed the remaining quota”; retain actual output, state effects and final disposition.
- [ ] **UC-M06.05-C042-T09 · Patch review:** Review the “Resource admission rules” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M06.05-C042-T10 · Delivery handoff:** Publish the “Resource admission rules” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M06.05-C043 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: A policy approval respects hard workload and tenant budgets. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M06.05-C043-T01 · Named property:** Create a stable property/check name under this parent for “Resource admission rules”; copy its required invariant exactly: “A policy approval respects hard workload and tenant budgets”.
- [ ] **UC-M06.05-C043-T02 · Observable terms:** Define each term in the “Resource admission rules” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M06.05-C043-T03 · Precondition set:** List the preconditions under which “A policy approval respects hard workload and tenant budgets” must hold for “Resource admission rules”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M06.05-C043-T04 · Transition coverage:** Map the “Resource admission rules” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M06.05-C043-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Resource admission rules”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M06.05-C043-T06 · Satisfying fixture:** Create a concrete “Resource admission rules” case that satisfies “A policy approval respects hard workload and tenant budgets”; record its expected observation before running the assertion or review.
- [ ] **UC-M06.05-C043-T07 · Violating fixture:** Create the source counterexample “Two simultaneous approvals exceed the remaining quota” for “Resource admission rules”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M06.05-C043-T08 · Enforcement evidence:** Exercise the “Resource admission rules” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M06.05-C043-T09 · Regression linkage:** Link the “Resource admission rules” property to changes in validated provenance, exercised host capabilities and pre-execution reservations; record which dependency or contract changes require rerunning it.
- [ ] **UC-M06.05-C043-T10 · Property disposition:** Compare the satisfying and violating “Resource admission rules” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M06.05-C044 · Integration

**Original checklist item:** Integrate resource admission rules with validated provenance, exercised host capabilities and pre-execution reservations; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M06.05-C044-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Resource admission rules” across validated provenance, exercised host capabilities and pre-execution reservations; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M06.05-C044-T02 · Field mapping:** Map every “Resource admission rules” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M06.05-C044-T03 · Prerequisite identities:** Record the actual prerequisites for “Resource admission rules” (source dependency list: UC-M03.08, UC-M04.08, UC-M06.03); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M06.05-C044-T04 · Ownership agreement:** Specify who owns “Resource admission rules” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M06.05-C044-T05 · Handoff implementation:** Connect “Resource admission rules” through the mapped seam using the real adapter or explicit specification reference; preserve “A policy approval respects hard workload and tenant budgets” across the handoff.
- [ ] **UC-M06.05-C044-T06 · Absent-input case:** Omit one required “Resource admission rules” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M06.05-C044-T07 · Stale-input case:** Supply an outdated “Resource admission rules” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M06.05-C044-T08 · Incompatible-input case:** Supply an incompatible “Resource admission rules” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M06.05-C044-T09 · Valid integration trace:** Run a valid “Resource admission rules” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M06.05-C044-T10 · Seam review:** Reconcile the “Resource admission rules” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M06.05-C045 · Valid-case test

**Original checklist item:** Run a valid-path fixture for resource admission rules; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M06.05-C045-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Resource admission rules” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M06.05-C045-T02 · Expected-result oracle:** Specify the “Resource admission rules” expected result independently of the implementation output; include the property “A policy approval respects hard workload and tenant budgets” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M06.05-C045-T03 · Fixture material:** Create the concrete “Resource admission rules” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M06.05-C045-T04 · Target preparation:** Prepare the “Resource admission rules” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M06.05-C045-T05 · Initial-state record:** Record the initial “Resource admission rules” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M06.05-C045-T06 · Valid-path execution:** Execute the “Resource admission rules” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M06.05-C045-T07 · Outcome comparison:** Compare every declared “Resource admission rules” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M06.05-C045-T08 · State and bounds check:** Inspect the “Resource admission rules” ownership/state effects and actual use of “Reservations and concurrent evaluations”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M06.05-C045-T09 · Repeatability check:** Repeat the same “Resource admission rules” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M06.05-C045-T10 · Positive evidence:** Attach the “Resource admission rules” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M06.05-C046 · Negative test

**Original checklist item:** Negative case: Two simultaneous approvals exceed the remaining quota. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M06.05-C046-T01 · Adverse-case definition:** Create a test record for the exact “Resource admission rules” source counterexample: “Two simultaneous approvals exceed the remaining quota”; state which precondition or invariant it challenges.
- [ ] **UC-M06.05-C046-T02 · Safe fixture boundary:** Define the contained test boundary for “Resource admission rules”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M06.05-C046-T03 · Valid control:** Construct a valid “Resource admission rules” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M06.05-C046-T04 · Minimal adverse input:** Derive the “Resource admission rules” adverse fixture from the control with the smallest documented change needed to reproduce “Two simultaneous approvals exceed the remaining quota”; retain that change as reproducible data.
- [ ] **UC-M06.05-C046-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Resource admission rules”; require “A policy approval respects hard workload and tenant budgets” and forbid a false-success verdict.
- [ ] **UC-M06.05-C046-T06 · Adverse execution:** Exercise the “Resource admission rules” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M06.05-C046-T07 · Effect inspection:** Inspect “Resource admission rules” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M06.05-C046-T08 · Refusal versus failure:** Confirm the “Resource admission rules” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M06.05-C046-T09 · Reset and retention:** Restore only the disposable “Resource admission rules” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M06.05-C046-T10 · Negative regression:** Register the “Resource admission rules” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M06.05-C047 · Change / failure test

**Original checklist item:** Exercise resource admission rules when policy or capability evidence changes before an approved queued request starts; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M06.05-C047-T01 · Scenario record:** Write the “Resource admission rules” change/failure scenario exactly as supplied: policy or capability evidence changes before an approved queued request starts; identify the property that must remain true: “A policy approval respects hard workload and tenant budgets”.
- [ ] **UC-M06.05-C047-T02 · Baseline capture:** Create a known-valid “Resource admission rules” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M06.05-C047-T03 · Injection map:** Locate the “Resource admission rules” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M06.05-C047-T04 · Disposition oracle:** Define the legal intermediate and final “Resource admission rules” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M06.05-C047-T05 · Controlled trigger:** Introduce the controlled “Resource admission rules” scenario in the disposable fixture: policy or capability evidence changes before an approved queued request starts; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M06.05-C047-T06 · Intermediate inspection:** Inspect the “Resource admission rules” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M06.05-C047-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Resource admission rules”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M06.05-C047-T08 · Stale-evidence cleanup:** Invalidate superseded “Resource admission rules” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M06.05-C047-T09 · Repeat and compare:** Repeat the selected “Resource admission rules” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M06.05-C047-T10 · Failure evidence:** Publish the “Resource admission rules” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M06.05-C048 · Bounds

**Original checklist item:** Choose, document and test limits for reservations and concurrent evaluations; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M06.05-C048-T01 · Quantity inventory:** Create a measurement inventory for “Resource admission rules”: “Reservations and concurrent evaluations”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M06.05-C048-T02 · Measurement method:** Choose how to observe each “Resource admission rules” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M06.05-C048-T03 · Budget decision:** Select justified resource and input limits for “Resource admission rules”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M06.05-C048-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Resource admission rules” cases for “Reservations and concurrent evaluations”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M06.05-C048-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Resource admission rules” limit; preserve “A policy approval respects hard workload and tenant budgets”.
- [ ] **UC-M06.05-C048-T06 · Normal measurement:** Run or review the normal “Resource admission rules” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M06.05-C048-T07 · At-limit measurement:** Exercise the “Resource admission rules” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M06.05-C048-T08 · Over-limit measurement:** Exercise the “Resource admission rules” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M06.05-C048-T09 · Uncovered-scope report:** List the “Resource admission rules” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M06.05-C048-T10 · Limit evidence:** Publish the selected “Resource admission rules” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M06.05-C049 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for resource admission rules with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M06.05-C049-T01 · Event inventory:** List the “Resource admission rules” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M06.05-C049-T02 · Diagnostic schema:** Define nonsecret fields for “Resource admission rules” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M06.05-C049-T03 · Failure mapping:** Map each documented “Resource admission rules” refusal or error to a diagnostic outcome; include “Two simultaneous approvals exceed the remaining quota” and prohibit conversion into a success message.
- [ ] **UC-M06.05-C049-T04 · Emission path:** Add the “Resource admission rules” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M06.05-C049-T05 · Redaction check:** Test “Resource admission rules” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M06.05-C049-T06 · Output budget:** Set and exercise bounded “Resource admission rules” message size, rate and retention compatible with “Reservations and concurrent evaluations”; define truncation behavior that preserves the final reason.
- [ ] **UC-M06.05-C049-T07 · Success/refusal fixtures:** Capture “Resource admission rules” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M06.05-C049-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Resource admission rules” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M06.05-C049-T09 · Operator review:** Read the “Resource admission rules” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M06.05-C049-T10 · Diagnostic evidence:** Publish redacted “Resource admission rules” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M06.05-C050 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for resource admission rules; label unexecuted checks as untested.

- [ ] **UC-M06.05-C050-T01 · Evidence inventory:** List the “Resource admission rules” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M06.05-C050-T02 · Artifact references:** Record the exact “Resource admission rules” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M06.05-C050-T03 · Fixture references:** Attach the “Resource admission rules” fixture IDs, input identities and oracle definition; preserve the source counterexample “Two simultaneous approvals exceed the remaining quota” as a distinct evidence case.
- [ ] **UC-M06.05-C050-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Resource admission rules”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M06.05-C050-T05 · Environment record:** Record the actual “Resource admission rules” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M06.05-C050-T06 · Expected versus observed:** Pair every “Resource admission rules” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M06.05-C050-T07 · Failure and limit records:** Attach “Resource admission rules” change/failure and bounds evidence where required; include uncovered “Reservations and concurrent evaluations” and unresolved violations of “A policy approval respects hard workload and tenant budgets”.
- [ ] **UC-M06.05-C050-T08 · Evidence hygiene:** Check the “Resource admission rules” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M06.05-C050-T09 · Reproduction review:** Have the “Resource admission rules” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M06.05-C050-T10 · Acceptance linkage:** Link the “Resource admission rules” evidence to its parent and UC-M06.05 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 06. Device and network rules

**Source delivery:** Allow only explicitly granted devices and network behavior for the selected profile.

**Source invariant:** A policy exception cannot silently broaden unrelated access.

**Source negative case:** A block-device request includes an unexpected network device.

**Source bounded quantities:** Device rules and endpoint grants.

### UC-M06.05-C051 · Contract

**Original checklist item:** Specify device and network rules inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M06.05-C051-T01 · Scope statement:** Draft the operation boundary for “Device and network rules” within Policy-as-code admission evaluator; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M06.05-C051-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Device and network rules”; record each producer, representation and missing-value meaning.
- [ ] **UC-M06.05-C051-T03 · Output inventory:** List the outputs of “Device and network rules” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M06.05-C051-T04 · Field dictionary:** Create a field-and-term dictionary for “Device and network rules”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M06.05-C051-T05 · Prerequisite contract:** Map “Device and network rules” to the source component prerequisites (UC-M03.08, UC-M04.08, UC-M06.03); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M06.05-C051-T06 · Authority map:** Identify who may produce, change and consume “Device and network rules”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M06.05-C051-T07 · Invariant clause:** Add a normative clause for “Device and network rules” that preserves “A policy exception cannot silently broaden unrelated access”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M06.05-C051-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Device and network rules”; include the source counterexample “A block-device request includes an unexpected network device” and the intended safe disposition.
- [ ] **UC-M06.05-C051-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Device rules and endpoint grants” in the “Device and network rules” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M06.05-C051-T10 · Contract review:** Review the “Device and network rules” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M06.05-C052 · Delivery

**Original checklist item:** Allow only explicitly granted devices and network behavior for the selected profile.

- [ ] **UC-M06.05-C052-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Device and network rules”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M06.05-C052-T02 · Change plan:** Break the source delivery for “Device and network rules” into concrete edit targets and reviewable outputs; keep the UC-M06.05 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M06.05-C052-T03 · Core artifact:** Implement the smallest selected-profile change for “Device and network rules” that realizes this source instruction: Allow only explicitly granted devices and network behavior for the selected profile.
- [ ] **UC-M06.05-C052-T04 · Concrete realization:** Trace “Device and network rules” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M06.05-C052-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Device and network rules” needed to preserve “A policy exception cannot silently broaden unrelated access”; record an enforcement gap where only a model exists.
- [ ] **UC-M06.05-C052-T06 · Dependency connection:** Connect the “Device and network rules” implementation to validated provenance, exercised host capabilities and pre-execution reservations; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M06.05-C052-T07 · Resource behavior:** Account for “Device rules and endpoint grants” in “Device and network rules”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M06.05-C052-T08 · Delivery check:** Run the smallest real “Device and network rules” path and its adverse fixture “A block-device request includes an unexpected network device”; retain actual output, state effects and final disposition.
- [ ] **UC-M06.05-C052-T09 · Patch review:** Review the “Device and network rules” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M06.05-C052-T10 · Delivery handoff:** Publish the “Device and network rules” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M06.05-C053 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: A policy exception cannot silently broaden unrelated access. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M06.05-C053-T01 · Named property:** Create a stable property/check name under this parent for “Device and network rules”; copy its required invariant exactly: “A policy exception cannot silently broaden unrelated access”.
- [ ] **UC-M06.05-C053-T02 · Observable terms:** Define each term in the “Device and network rules” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M06.05-C053-T03 · Precondition set:** List the preconditions under which “A policy exception cannot silently broaden unrelated access” must hold for “Device and network rules”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M06.05-C053-T04 · Transition coverage:** Map the “Device and network rules” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M06.05-C053-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Device and network rules”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M06.05-C053-T06 · Satisfying fixture:** Create a concrete “Device and network rules” case that satisfies “A policy exception cannot silently broaden unrelated access”; record its expected observation before running the assertion or review.
- [ ] **UC-M06.05-C053-T07 · Violating fixture:** Create the source counterexample “A block-device request includes an unexpected network device” for “Device and network rules”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M06.05-C053-T08 · Enforcement evidence:** Exercise the “Device and network rules” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M06.05-C053-T09 · Regression linkage:** Link the “Device and network rules” property to changes in validated provenance, exercised host capabilities and pre-execution reservations; record which dependency or contract changes require rerunning it.
- [ ] **UC-M06.05-C053-T10 · Property disposition:** Compare the satisfying and violating “Device and network rules” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M06.05-C054 · Integration

**Original checklist item:** Integrate device and network rules with validated provenance, exercised host capabilities and pre-execution reservations; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M06.05-C054-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Device and network rules” across validated provenance, exercised host capabilities and pre-execution reservations; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M06.05-C054-T02 · Field mapping:** Map every “Device and network rules” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M06.05-C054-T03 · Prerequisite identities:** Record the actual prerequisites for “Device and network rules” (source dependency list: UC-M03.08, UC-M04.08, UC-M06.03); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M06.05-C054-T04 · Ownership agreement:** Specify who owns “Device and network rules” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M06.05-C054-T05 · Handoff implementation:** Connect “Device and network rules” through the mapped seam using the real adapter or explicit specification reference; preserve “A policy exception cannot silently broaden unrelated access” across the handoff.
- [ ] **UC-M06.05-C054-T06 · Absent-input case:** Omit one required “Device and network rules” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M06.05-C054-T07 · Stale-input case:** Supply an outdated “Device and network rules” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M06.05-C054-T08 · Incompatible-input case:** Supply an incompatible “Device and network rules” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M06.05-C054-T09 · Valid integration trace:** Run a valid “Device and network rules” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M06.05-C054-T10 · Seam review:** Reconcile the “Device and network rules” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M06.05-C055 · Valid-case test

**Original checklist item:** Run a valid-path fixture for device and network rules; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M06.05-C055-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Device and network rules” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M06.05-C055-T02 · Expected-result oracle:** Specify the “Device and network rules” expected result independently of the implementation output; include the property “A policy exception cannot silently broaden unrelated access” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M06.05-C055-T03 · Fixture material:** Create the concrete “Device and network rules” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M06.05-C055-T04 · Target preparation:** Prepare the “Device and network rules” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M06.05-C055-T05 · Initial-state record:** Record the initial “Device and network rules” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M06.05-C055-T06 · Valid-path execution:** Execute the “Device and network rules” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M06.05-C055-T07 · Outcome comparison:** Compare every declared “Device and network rules” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M06.05-C055-T08 · State and bounds check:** Inspect the “Device and network rules” ownership/state effects and actual use of “Device rules and endpoint grants”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M06.05-C055-T09 · Repeatability check:** Repeat the same “Device and network rules” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M06.05-C055-T10 · Positive evidence:** Attach the “Device and network rules” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M06.05-C056 · Negative test

**Original checklist item:** Negative case: A block-device request includes an unexpected network device. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M06.05-C056-T01 · Adverse-case definition:** Create a test record for the exact “Device and network rules” source counterexample: “A block-device request includes an unexpected network device”; state which precondition or invariant it challenges.
- [ ] **UC-M06.05-C056-T02 · Safe fixture boundary:** Define the contained test boundary for “Device and network rules”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M06.05-C056-T03 · Valid control:** Construct a valid “Device and network rules” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M06.05-C056-T04 · Minimal adverse input:** Derive the “Device and network rules” adverse fixture from the control with the smallest documented change needed to reproduce “A block-device request includes an unexpected network device”; retain that change as reproducible data.
- [ ] **UC-M06.05-C056-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Device and network rules”; require “A policy exception cannot silently broaden unrelated access” and forbid a false-success verdict.
- [ ] **UC-M06.05-C056-T06 · Adverse execution:** Exercise the “Device and network rules” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M06.05-C056-T07 · Effect inspection:** Inspect “Device and network rules” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M06.05-C056-T08 · Refusal versus failure:** Confirm the “Device and network rules” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M06.05-C056-T09 · Reset and retention:** Restore only the disposable “Device and network rules” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M06.05-C056-T10 · Negative regression:** Register the “Device and network rules” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M06.05-C057 · Change / failure test

**Original checklist item:** Exercise device and network rules when policy or capability evidence changes before an approved queued request starts; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M06.05-C057-T01 · Scenario record:** Write the “Device and network rules” change/failure scenario exactly as supplied: policy or capability evidence changes before an approved queued request starts; identify the property that must remain true: “A policy exception cannot silently broaden unrelated access”.
- [ ] **UC-M06.05-C057-T02 · Baseline capture:** Create a known-valid “Device and network rules” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M06.05-C057-T03 · Injection map:** Locate the “Device and network rules” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M06.05-C057-T04 · Disposition oracle:** Define the legal intermediate and final “Device and network rules” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M06.05-C057-T05 · Controlled trigger:** Introduce the controlled “Device and network rules” scenario in the disposable fixture: policy or capability evidence changes before an approved queued request starts; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M06.05-C057-T06 · Intermediate inspection:** Inspect the “Device and network rules” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M06.05-C057-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Device and network rules”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M06.05-C057-T08 · Stale-evidence cleanup:** Invalidate superseded “Device and network rules” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M06.05-C057-T09 · Repeat and compare:** Repeat the selected “Device and network rules” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M06.05-C057-T10 · Failure evidence:** Publish the “Device and network rules” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M06.05-C058 · Bounds

**Original checklist item:** Choose, document and test limits for device rules and endpoint grants; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M06.05-C058-T01 · Quantity inventory:** Create a measurement inventory for “Device and network rules”: “Device rules and endpoint grants”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M06.05-C058-T02 · Measurement method:** Choose how to observe each “Device and network rules” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M06.05-C058-T03 · Budget decision:** Select justified resource and input limits for “Device and network rules”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M06.05-C058-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Device and network rules” cases for “Device rules and endpoint grants”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M06.05-C058-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Device and network rules” limit; preserve “A policy exception cannot silently broaden unrelated access”.
- [ ] **UC-M06.05-C058-T06 · Normal measurement:** Run or review the normal “Device and network rules” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M06.05-C058-T07 · At-limit measurement:** Exercise the “Device and network rules” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M06.05-C058-T08 · Over-limit measurement:** Exercise the “Device and network rules” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M06.05-C058-T09 · Uncovered-scope report:** List the “Device and network rules” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M06.05-C058-T10 · Limit evidence:** Publish the selected “Device and network rules” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M06.05-C059 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for device and network rules with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M06.05-C059-T01 · Event inventory:** List the “Device and network rules” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M06.05-C059-T02 · Diagnostic schema:** Define nonsecret fields for “Device and network rules” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M06.05-C059-T03 · Failure mapping:** Map each documented “Device and network rules” refusal or error to a diagnostic outcome; include “A block-device request includes an unexpected network device” and prohibit conversion into a success message.
- [ ] **UC-M06.05-C059-T04 · Emission path:** Add the “Device and network rules” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M06.05-C059-T05 · Redaction check:** Test “Device and network rules” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M06.05-C059-T06 · Output budget:** Set and exercise bounded “Device and network rules” message size, rate and retention compatible with “Device rules and endpoint grants”; define truncation behavior that preserves the final reason.
- [ ] **UC-M06.05-C059-T07 · Success/refusal fixtures:** Capture “Device and network rules” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M06.05-C059-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Device and network rules” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M06.05-C059-T09 · Operator review:** Read the “Device and network rules” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M06.05-C059-T10 · Diagnostic evidence:** Publish redacted “Device and network rules” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M06.05-C060 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for device and network rules; label unexecuted checks as untested.

- [ ] **UC-M06.05-C060-T01 · Evidence inventory:** List the “Device and network rules” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M06.05-C060-T02 · Artifact references:** Record the exact “Device and network rules” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M06.05-C060-T03 · Fixture references:** Attach the “Device and network rules” fixture IDs, input identities and oracle definition; preserve the source counterexample “A block-device request includes an unexpected network device” as a distinct evidence case.
- [ ] **UC-M06.05-C060-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Device and network rules”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M06.05-C060-T05 · Environment record:** Record the actual “Device and network rules” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M06.05-C060-T06 · Expected versus observed:** Pair every “Device and network rules” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M06.05-C060-T07 · Failure and limit records:** Attach “Device and network rules” change/failure and bounds evidence where required; include uncovered “Device rules and endpoint grants” and unresolved violations of “A policy exception cannot silently broaden unrelated access”.
- [ ] **UC-M06.05-C060-T08 · Evidence hygiene:** Check the “Device and network rules” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M06.05-C060-T09 · Reproduction review:** Have the “Device and network rules” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M06.05-C060-T10 · Acceptance linkage:** Link the “Device and network rules” evidence to its parent and UC-M06.05 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 07. Pre-execution decision barrier

**Source delivery:** Make the policy decision before starting children, mounting or publishing workloads.

**Source invariant:** A denied policy leaves no executable child or visible partial workload.

**Source negative case:** A compiler starts before policy refusal completes.

**Source bounded quantities:** Preflight work and validation deadline.

### UC-M06.05-C061 · Contract

**Original checklist item:** Specify pre-execution decision barrier inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M06.05-C061-T01 · Scope statement:** Draft the operation boundary for “Pre-execution decision barrier” within Policy-as-code admission evaluator; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M06.05-C061-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Pre-execution decision barrier”; record each producer, representation and missing-value meaning.
- [ ] **UC-M06.05-C061-T03 · Output inventory:** List the outputs of “Pre-execution decision barrier” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M06.05-C061-T04 · Field dictionary:** Create a field-and-term dictionary for “Pre-execution decision barrier”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M06.05-C061-T05 · Prerequisite contract:** Map “Pre-execution decision barrier” to the source component prerequisites (UC-M03.08, UC-M04.08, UC-M06.03); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M06.05-C061-T06 · Authority map:** Identify who may produce, change and consume “Pre-execution decision barrier”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M06.05-C061-T07 · Invariant clause:** Add a normative clause for “Pre-execution decision barrier” that preserves “A denied policy leaves no executable child or visible partial workload”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M06.05-C061-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Pre-execution decision barrier”; include the source counterexample “A compiler starts before policy refusal completes” and the intended safe disposition.
- [ ] **UC-M06.05-C061-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Preflight work and validation deadline” in the “Pre-execution decision barrier” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M06.05-C061-T10 · Contract review:** Review the “Pre-execution decision barrier” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M06.05-C062 · Delivery

**Original checklist item:** Make the policy decision before starting children, mounting or publishing workloads.

- [ ] **UC-M06.05-C062-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Pre-execution decision barrier”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M06.05-C062-T02 · Change plan:** Break the source delivery for “Pre-execution decision barrier” into concrete edit targets and reviewable outputs; keep the UC-M06.05 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M06.05-C062-T03 · Core artifact:** Implement the smallest selected-profile change for “Pre-execution decision barrier” that realizes this source instruction: Make the policy decision before starting children, mounting or publishing workloads.
- [ ] **UC-M06.05-C062-T04 · Concrete realization:** Trace “Pre-execution decision barrier” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M06.05-C062-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Pre-execution decision barrier” needed to preserve “A denied policy leaves no executable child or visible partial workload”; record an enforcement gap where only a model exists.
- [ ] **UC-M06.05-C062-T06 · Dependency connection:** Connect the “Pre-execution decision barrier” implementation to validated provenance, exercised host capabilities and pre-execution reservations; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M06.05-C062-T07 · Resource behavior:** Account for “Preflight work and validation deadline” in “Pre-execution decision barrier”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M06.05-C062-T08 · Delivery check:** Run the smallest real “Pre-execution decision barrier” path and its adverse fixture “A compiler starts before policy refusal completes”; retain actual output, state effects and final disposition.
- [ ] **UC-M06.05-C062-T09 · Patch review:** Review the “Pre-execution decision barrier” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M06.05-C062-T10 · Delivery handoff:** Publish the “Pre-execution decision barrier” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M06.05-C063 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: A denied policy leaves no executable child or visible partial workload. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M06.05-C063-T01 · Named property:** Create a stable property/check name under this parent for “Pre-execution decision barrier”; copy its required invariant exactly: “A denied policy leaves no executable child or visible partial workload”.
- [ ] **UC-M06.05-C063-T02 · Observable terms:** Define each term in the “Pre-execution decision barrier” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M06.05-C063-T03 · Precondition set:** List the preconditions under which “A denied policy leaves no executable child or visible partial workload” must hold for “Pre-execution decision barrier”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M06.05-C063-T04 · Transition coverage:** Map the “Pre-execution decision barrier” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M06.05-C063-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Pre-execution decision barrier”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M06.05-C063-T06 · Satisfying fixture:** Create a concrete “Pre-execution decision barrier” case that satisfies “A denied policy leaves no executable child or visible partial workload”; record its expected observation before running the assertion or review.
- [ ] **UC-M06.05-C063-T07 · Violating fixture:** Create the source counterexample “A compiler starts before policy refusal completes” for “Pre-execution decision barrier”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M06.05-C063-T08 · Enforcement evidence:** Exercise the “Pre-execution decision barrier” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M06.05-C063-T09 · Regression linkage:** Link the “Pre-execution decision barrier” property to changes in validated provenance, exercised host capabilities and pre-execution reservations; record which dependency or contract changes require rerunning it.
- [ ] **UC-M06.05-C063-T10 · Property disposition:** Compare the satisfying and violating “Pre-execution decision barrier” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M06.05-C064 · Integration

**Original checklist item:** Integrate pre-execution decision barrier with validated provenance, exercised host capabilities and pre-execution reservations; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M06.05-C064-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Pre-execution decision barrier” across validated provenance, exercised host capabilities and pre-execution reservations; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M06.05-C064-T02 · Field mapping:** Map every “Pre-execution decision barrier” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M06.05-C064-T03 · Prerequisite identities:** Record the actual prerequisites for “Pre-execution decision barrier” (source dependency list: UC-M03.08, UC-M04.08, UC-M06.03); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M06.05-C064-T04 · Ownership agreement:** Specify who owns “Pre-execution decision barrier” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M06.05-C064-T05 · Handoff implementation:** Connect “Pre-execution decision barrier” through the mapped seam using the real adapter or explicit specification reference; preserve “A denied policy leaves no executable child or visible partial workload” across the handoff.
- [ ] **UC-M06.05-C064-T06 · Absent-input case:** Omit one required “Pre-execution decision barrier” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M06.05-C064-T07 · Stale-input case:** Supply an outdated “Pre-execution decision barrier” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M06.05-C064-T08 · Incompatible-input case:** Supply an incompatible “Pre-execution decision barrier” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M06.05-C064-T09 · Valid integration trace:** Run a valid “Pre-execution decision barrier” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M06.05-C064-T10 · Seam review:** Reconcile the “Pre-execution decision barrier” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M06.05-C065 · Valid-case test

**Original checklist item:** Run a valid-path fixture for pre-execution decision barrier; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M06.05-C065-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Pre-execution decision barrier” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M06.05-C065-T02 · Expected-result oracle:** Specify the “Pre-execution decision barrier” expected result independently of the implementation output; include the property “A denied policy leaves no executable child or visible partial workload” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M06.05-C065-T03 · Fixture material:** Create the concrete “Pre-execution decision barrier” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M06.05-C065-T04 · Target preparation:** Prepare the “Pre-execution decision barrier” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M06.05-C065-T05 · Initial-state record:** Record the initial “Pre-execution decision barrier” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M06.05-C065-T06 · Valid-path execution:** Execute the “Pre-execution decision barrier” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M06.05-C065-T07 · Outcome comparison:** Compare every declared “Pre-execution decision barrier” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M06.05-C065-T08 · State and bounds check:** Inspect the “Pre-execution decision barrier” ownership/state effects and actual use of “Preflight work and validation deadline”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M06.05-C065-T09 · Repeatability check:** Repeat the same “Pre-execution decision barrier” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M06.05-C065-T10 · Positive evidence:** Attach the “Pre-execution decision barrier” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M06.05-C066 · Negative test

**Original checklist item:** Negative case: A compiler starts before policy refusal completes. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M06.05-C066-T01 · Adverse-case definition:** Create a test record for the exact “Pre-execution decision barrier” source counterexample: “A compiler starts before policy refusal completes”; state which precondition or invariant it challenges.
- [ ] **UC-M06.05-C066-T02 · Safe fixture boundary:** Define the contained test boundary for “Pre-execution decision barrier”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M06.05-C066-T03 · Valid control:** Construct a valid “Pre-execution decision barrier” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M06.05-C066-T04 · Minimal adverse input:** Derive the “Pre-execution decision barrier” adverse fixture from the control with the smallest documented change needed to reproduce “A compiler starts before policy refusal completes”; retain that change as reproducible data.
- [ ] **UC-M06.05-C066-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Pre-execution decision barrier”; require “A denied policy leaves no executable child or visible partial workload” and forbid a false-success verdict.
- [ ] **UC-M06.05-C066-T06 · Adverse execution:** Exercise the “Pre-execution decision barrier” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M06.05-C066-T07 · Effect inspection:** Inspect “Pre-execution decision barrier” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M06.05-C066-T08 · Refusal versus failure:** Confirm the “Pre-execution decision barrier” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M06.05-C066-T09 · Reset and retention:** Restore only the disposable “Pre-execution decision barrier” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M06.05-C066-T10 · Negative regression:** Register the “Pre-execution decision barrier” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M06.05-C067 · Change / failure test

**Original checklist item:** Exercise pre-execution decision barrier when policy or capability evidence changes before an approved queued request starts; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M06.05-C067-T01 · Scenario record:** Write the “Pre-execution decision barrier” change/failure scenario exactly as supplied: policy or capability evidence changes before an approved queued request starts; identify the property that must remain true: “A denied policy leaves no executable child or visible partial workload”.
- [ ] **UC-M06.05-C067-T02 · Baseline capture:** Create a known-valid “Pre-execution decision barrier” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M06.05-C067-T03 · Injection map:** Locate the “Pre-execution decision barrier” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M06.05-C067-T04 · Disposition oracle:** Define the legal intermediate and final “Pre-execution decision barrier” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M06.05-C067-T05 · Controlled trigger:** Introduce the controlled “Pre-execution decision barrier” scenario in the disposable fixture: policy or capability evidence changes before an approved queued request starts; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M06.05-C067-T06 · Intermediate inspection:** Inspect the “Pre-execution decision barrier” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M06.05-C067-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Pre-execution decision barrier”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M06.05-C067-T08 · Stale-evidence cleanup:** Invalidate superseded “Pre-execution decision barrier” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M06.05-C067-T09 · Repeat and compare:** Repeat the selected “Pre-execution decision barrier” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M06.05-C067-T10 · Failure evidence:** Publish the “Pre-execution decision barrier” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M06.05-C068 · Bounds

**Original checklist item:** Choose, document and test limits for preflight work and validation deadline; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M06.05-C068-T01 · Quantity inventory:** Create a measurement inventory for “Pre-execution decision barrier”: “Preflight work and validation deadline”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M06.05-C068-T02 · Measurement method:** Choose how to observe each “Pre-execution decision barrier” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M06.05-C068-T03 · Budget decision:** Select justified resource and input limits for “Pre-execution decision barrier”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M06.05-C068-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Pre-execution decision barrier” cases for “Preflight work and validation deadline”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M06.05-C068-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Pre-execution decision barrier” limit; preserve “A denied policy leaves no executable child or visible partial workload”.
- [ ] **UC-M06.05-C068-T06 · Normal measurement:** Run or review the normal “Pre-execution decision barrier” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M06.05-C068-T07 · At-limit measurement:** Exercise the “Pre-execution decision barrier” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M06.05-C068-T08 · Over-limit measurement:** Exercise the “Pre-execution decision barrier” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M06.05-C068-T09 · Uncovered-scope report:** List the “Pre-execution decision barrier” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M06.05-C068-T10 · Limit evidence:** Publish the selected “Pre-execution decision barrier” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M06.05-C069 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for pre-execution decision barrier with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M06.05-C069-T01 · Event inventory:** List the “Pre-execution decision barrier” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M06.05-C069-T02 · Diagnostic schema:** Define nonsecret fields for “Pre-execution decision barrier” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M06.05-C069-T03 · Failure mapping:** Map each documented “Pre-execution decision barrier” refusal or error to a diagnostic outcome; include “A compiler starts before policy refusal completes” and prohibit conversion into a success message.
- [ ] **UC-M06.05-C069-T04 · Emission path:** Add the “Pre-execution decision barrier” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M06.05-C069-T05 · Redaction check:** Test “Pre-execution decision barrier” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M06.05-C069-T06 · Output budget:** Set and exercise bounded “Pre-execution decision barrier” message size, rate and retention compatible with “Preflight work and validation deadline”; define truncation behavior that preserves the final reason.
- [ ] **UC-M06.05-C069-T07 · Success/refusal fixtures:** Capture “Pre-execution decision barrier” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M06.05-C069-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Pre-execution decision barrier” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M06.05-C069-T09 · Operator review:** Read the “Pre-execution decision barrier” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M06.05-C069-T10 · Diagnostic evidence:** Publish redacted “Pre-execution decision barrier” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M06.05-C070 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for pre-execution decision barrier; label unexecuted checks as untested.

- [ ] **UC-M06.05-C070-T01 · Evidence inventory:** List the “Pre-execution decision barrier” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M06.05-C070-T02 · Artifact references:** Record the exact “Pre-execution decision barrier” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M06.05-C070-T03 · Fixture references:** Attach the “Pre-execution decision barrier” fixture IDs, input identities and oracle definition; preserve the source counterexample “A compiler starts before policy refusal completes” as a distinct evidence case.
- [ ] **UC-M06.05-C070-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Pre-execution decision barrier”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M06.05-C070-T05 · Environment record:** Record the actual “Pre-execution decision barrier” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M06.05-C070-T06 · Expected versus observed:** Pair every “Pre-execution decision barrier” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M06.05-C070-T07 · Failure and limit records:** Attach “Pre-execution decision barrier” change/failure and bounds evidence where required; include uncovered “Preflight work and validation deadline” and unresolved violations of “A denied policy leaves no executable child or visible partial workload”.
- [ ] **UC-M06.05-C070-T08 · Evidence hygiene:** Check the “Pre-execution decision barrier” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M06.05-C070-T09 · Reproduction review:** Have the “Pre-execution decision barrier” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M06.05-C070-T10 · Acceptance linkage:** Link the “Pre-execution decision barrier” evidence to its parent and UC-M06.05 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 08. Deterministic decision output

**Source delivery:** Return allow/deny, reasons and required constraints in a stable result.

**Source invariant:** The same identified inputs and policy yield explainable consistent decisions.

**Source negative case:** An unknown field causes different decisions in CLI and API paths.

**Source bounded quantities:** Decision bytes and rule evaluation time.

### UC-M06.05-C071 · Contract

**Original checklist item:** Specify deterministic decision output inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M06.05-C071-T01 · Scope statement:** Draft the operation boundary for “Deterministic decision output” within Policy-as-code admission evaluator; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M06.05-C071-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Deterministic decision output”; record each producer, representation and missing-value meaning.
- [ ] **UC-M06.05-C071-T03 · Output inventory:** List the outputs of “Deterministic decision output” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M06.05-C071-T04 · Field dictionary:** Create a field-and-term dictionary for “Deterministic decision output”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M06.05-C071-T05 · Prerequisite contract:** Map “Deterministic decision output” to the source component prerequisites (UC-M03.08, UC-M04.08, UC-M06.03); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M06.05-C071-T06 · Authority map:** Identify who may produce, change and consume “Deterministic decision output”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M06.05-C071-T07 · Invariant clause:** Add a normative clause for “Deterministic decision output” that preserves “The same identified inputs and policy yield explainable consistent decisions”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M06.05-C071-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Deterministic decision output”; include the source counterexample “An unknown field causes different decisions in CLI and API paths” and the intended safe disposition.
- [ ] **UC-M06.05-C071-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Decision bytes and rule evaluation time” in the “Deterministic decision output” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M06.05-C071-T10 · Contract review:** Review the “Deterministic decision output” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M06.05-C072 · Delivery

**Original checklist item:** Return allow/deny, reasons and required constraints in a stable result.

- [ ] **UC-M06.05-C072-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Deterministic decision output”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M06.05-C072-T02 · Change plan:** Break the source delivery for “Deterministic decision output” into concrete edit targets and reviewable outputs; keep the UC-M06.05 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M06.05-C072-T03 · Core artifact:** Implement the smallest selected-profile change for “Deterministic decision output” that realizes this source instruction: Return allow/deny, reasons and required constraints in a stable result.
- [ ] **UC-M06.05-C072-T04 · Concrete realization:** Trace “Deterministic decision output” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M06.05-C072-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Deterministic decision output” needed to preserve “The same identified inputs and policy yield explainable consistent decisions”; record an enforcement gap where only a model exists.
- [ ] **UC-M06.05-C072-T06 · Dependency connection:** Connect the “Deterministic decision output” implementation to validated provenance, exercised host capabilities and pre-execution reservations; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M06.05-C072-T07 · Resource behavior:** Account for “Decision bytes and rule evaluation time” in “Deterministic decision output”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M06.05-C072-T08 · Delivery check:** Run the smallest real “Deterministic decision output” path and its adverse fixture “An unknown field causes different decisions in CLI and API paths”; retain actual output, state effects and final disposition.
- [ ] **UC-M06.05-C072-T09 · Patch review:** Review the “Deterministic decision output” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M06.05-C072-T10 · Delivery handoff:** Publish the “Deterministic decision output” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M06.05-C073 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: The same identified inputs and policy yield explainable consistent decisions. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M06.05-C073-T01 · Named property:** Create a stable property/check name under this parent for “Deterministic decision output”; copy its required invariant exactly: “The same identified inputs and policy yield explainable consistent decisions”.
- [ ] **UC-M06.05-C073-T02 · Observable terms:** Define each term in the “Deterministic decision output” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M06.05-C073-T03 · Precondition set:** List the preconditions under which “The same identified inputs and policy yield explainable consistent decisions” must hold for “Deterministic decision output”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M06.05-C073-T04 · Transition coverage:** Map the “Deterministic decision output” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M06.05-C073-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Deterministic decision output”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M06.05-C073-T06 · Satisfying fixture:** Create a concrete “Deterministic decision output” case that satisfies “The same identified inputs and policy yield explainable consistent decisions”; record its expected observation before running the assertion or review.
- [ ] **UC-M06.05-C073-T07 · Violating fixture:** Create the source counterexample “An unknown field causes different decisions in CLI and API paths” for “Deterministic decision output”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M06.05-C073-T08 · Enforcement evidence:** Exercise the “Deterministic decision output” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M06.05-C073-T09 · Regression linkage:** Link the “Deterministic decision output” property to changes in validated provenance, exercised host capabilities and pre-execution reservations; record which dependency or contract changes require rerunning it.
- [ ] **UC-M06.05-C073-T10 · Property disposition:** Compare the satisfying and violating “Deterministic decision output” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M06.05-C074 · Integration

**Original checklist item:** Integrate deterministic decision output with validated provenance, exercised host capabilities and pre-execution reservations; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M06.05-C074-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Deterministic decision output” across validated provenance, exercised host capabilities and pre-execution reservations; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M06.05-C074-T02 · Field mapping:** Map every “Deterministic decision output” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M06.05-C074-T03 · Prerequisite identities:** Record the actual prerequisites for “Deterministic decision output” (source dependency list: UC-M03.08, UC-M04.08, UC-M06.03); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M06.05-C074-T04 · Ownership agreement:** Specify who owns “Deterministic decision output” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M06.05-C074-T05 · Handoff implementation:** Connect “Deterministic decision output” through the mapped seam using the real adapter or explicit specification reference; preserve “The same identified inputs and policy yield explainable consistent decisions” across the handoff.
- [ ] **UC-M06.05-C074-T06 · Absent-input case:** Omit one required “Deterministic decision output” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M06.05-C074-T07 · Stale-input case:** Supply an outdated “Deterministic decision output” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M06.05-C074-T08 · Incompatible-input case:** Supply an incompatible “Deterministic decision output” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M06.05-C074-T09 · Valid integration trace:** Run a valid “Deterministic decision output” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M06.05-C074-T10 · Seam review:** Reconcile the “Deterministic decision output” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M06.05-C075 · Valid-case test

**Original checklist item:** Run a valid-path fixture for deterministic decision output; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M06.05-C075-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Deterministic decision output” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M06.05-C075-T02 · Expected-result oracle:** Specify the “Deterministic decision output” expected result independently of the implementation output; include the property “The same identified inputs and policy yield explainable consistent decisions” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M06.05-C075-T03 · Fixture material:** Create the concrete “Deterministic decision output” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M06.05-C075-T04 · Target preparation:** Prepare the “Deterministic decision output” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M06.05-C075-T05 · Initial-state record:** Record the initial “Deterministic decision output” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M06.05-C075-T06 · Valid-path execution:** Execute the “Deterministic decision output” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M06.05-C075-T07 · Outcome comparison:** Compare every declared “Deterministic decision output” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M06.05-C075-T08 · State and bounds check:** Inspect the “Deterministic decision output” ownership/state effects and actual use of “Decision bytes and rule evaluation time”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M06.05-C075-T09 · Repeatability check:** Repeat the same “Deterministic decision output” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M06.05-C075-T10 · Positive evidence:** Attach the “Deterministic decision output” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M06.05-C076 · Negative test

**Original checklist item:** Negative case: An unknown field causes different decisions in CLI and API paths. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M06.05-C076-T01 · Adverse-case definition:** Create a test record for the exact “Deterministic decision output” source counterexample: “An unknown field causes different decisions in CLI and API paths”; state which precondition or invariant it challenges.
- [ ] **UC-M06.05-C076-T02 · Safe fixture boundary:** Define the contained test boundary for “Deterministic decision output”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M06.05-C076-T03 · Valid control:** Construct a valid “Deterministic decision output” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M06.05-C076-T04 · Minimal adverse input:** Derive the “Deterministic decision output” adverse fixture from the control with the smallest documented change needed to reproduce “An unknown field causes different decisions in CLI and API paths”; retain that change as reproducible data.
- [ ] **UC-M06.05-C076-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Deterministic decision output”; require “The same identified inputs and policy yield explainable consistent decisions” and forbid a false-success verdict.
- [ ] **UC-M06.05-C076-T06 · Adverse execution:** Exercise the “Deterministic decision output” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M06.05-C076-T07 · Effect inspection:** Inspect “Deterministic decision output” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M06.05-C076-T08 · Refusal versus failure:** Confirm the “Deterministic decision output” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M06.05-C076-T09 · Reset and retention:** Restore only the disposable “Deterministic decision output” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M06.05-C076-T10 · Negative regression:** Register the “Deterministic decision output” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M06.05-C077 · Change / failure test

**Original checklist item:** Exercise deterministic decision output when policy or capability evidence changes before an approved queued request starts; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M06.05-C077-T01 · Scenario record:** Write the “Deterministic decision output” change/failure scenario exactly as supplied: policy or capability evidence changes before an approved queued request starts; identify the property that must remain true: “The same identified inputs and policy yield explainable consistent decisions”.
- [ ] **UC-M06.05-C077-T02 · Baseline capture:** Create a known-valid “Deterministic decision output” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M06.05-C077-T03 · Injection map:** Locate the “Deterministic decision output” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M06.05-C077-T04 · Disposition oracle:** Define the legal intermediate and final “Deterministic decision output” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M06.05-C077-T05 · Controlled trigger:** Introduce the controlled “Deterministic decision output” scenario in the disposable fixture: policy or capability evidence changes before an approved queued request starts; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M06.05-C077-T06 · Intermediate inspection:** Inspect the “Deterministic decision output” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M06.05-C077-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Deterministic decision output”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M06.05-C077-T08 · Stale-evidence cleanup:** Invalidate superseded “Deterministic decision output” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M06.05-C077-T09 · Repeat and compare:** Repeat the selected “Deterministic decision output” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M06.05-C077-T10 · Failure evidence:** Publish the “Deterministic decision output” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M06.05-C078 · Bounds

**Original checklist item:** Choose, document and test limits for decision bytes and rule evaluation time; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M06.05-C078-T01 · Quantity inventory:** Create a measurement inventory for “Deterministic decision output”: “Decision bytes and rule evaluation time”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M06.05-C078-T02 · Measurement method:** Choose how to observe each “Deterministic decision output” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M06.05-C078-T03 · Budget decision:** Select justified resource and input limits for “Deterministic decision output”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M06.05-C078-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Deterministic decision output” cases for “Decision bytes and rule evaluation time”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M06.05-C078-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Deterministic decision output” limit; preserve “The same identified inputs and policy yield explainable consistent decisions”.
- [ ] **UC-M06.05-C078-T06 · Normal measurement:** Run or review the normal “Deterministic decision output” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M06.05-C078-T07 · At-limit measurement:** Exercise the “Deterministic decision output” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M06.05-C078-T08 · Over-limit measurement:** Exercise the “Deterministic decision output” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M06.05-C078-T09 · Uncovered-scope report:** List the “Deterministic decision output” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M06.05-C078-T10 · Limit evidence:** Publish the selected “Deterministic decision output” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M06.05-C079 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for deterministic decision output with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M06.05-C079-T01 · Event inventory:** List the “Deterministic decision output” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M06.05-C079-T02 · Diagnostic schema:** Define nonsecret fields for “Deterministic decision output” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M06.05-C079-T03 · Failure mapping:** Map each documented “Deterministic decision output” refusal or error to a diagnostic outcome; include “An unknown field causes different decisions in CLI and API paths” and prohibit conversion into a success message.
- [ ] **UC-M06.05-C079-T04 · Emission path:** Add the “Deterministic decision output” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M06.05-C079-T05 · Redaction check:** Test “Deterministic decision output” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M06.05-C079-T06 · Output budget:** Set and exercise bounded “Deterministic decision output” message size, rate and retention compatible with “Decision bytes and rule evaluation time”; define truncation behavior that preserves the final reason.
- [ ] **UC-M06.05-C079-T07 · Success/refusal fixtures:** Capture “Deterministic decision output” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M06.05-C079-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Deterministic decision output” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M06.05-C079-T09 · Operator review:** Read the “Deterministic decision output” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M06.05-C079-T10 · Diagnostic evidence:** Publish redacted “Deterministic decision output” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M06.05-C080 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for deterministic decision output; label unexecuted checks as untested.

- [ ] **UC-M06.05-C080-T01 · Evidence inventory:** List the “Deterministic decision output” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M06.05-C080-T02 · Artifact references:** Record the exact “Deterministic decision output” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M06.05-C080-T03 · Fixture references:** Attach the “Deterministic decision output” fixture IDs, input identities and oracle definition; preserve the source counterexample “An unknown field causes different decisions in CLI and API paths” as a distinct evidence case.
- [ ] **UC-M06.05-C080-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Deterministic decision output”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M06.05-C080-T05 · Environment record:** Record the actual “Deterministic decision output” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M06.05-C080-T06 · Expected versus observed:** Pair every “Deterministic decision output” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M06.05-C080-T07 · Failure and limit records:** Attach “Deterministic decision output” change/failure and bounds evidence where required; include uncovered “Decision bytes and rule evaluation time” and unresolved violations of “The same identified inputs and policy yield explainable consistent decisions”.
- [ ] **UC-M06.05-C080-T08 · Evidence hygiene:** Check the “Deterministic decision output” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M06.05-C080-T09 · Reproduction review:** Have the “Deterministic decision output” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M06.05-C080-T10 · Acceptance linkage:** Link the “Deterministic decision output” evidence to its parent and UC-M06.05 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 09. Policy change handling

**Source delivery:** Revalidate pending work when relevant policy or capability evidence changes.

**Source invariant:** Queued work cannot execute under an obsolete weaker approval.

**Source negative case:** A policy tightens while an old approved request waits to start.

**Source bounded quantities:** Pending decisions and invalidation fan-out.

### UC-M06.05-C081 · Contract

**Original checklist item:** Specify policy change handling inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M06.05-C081-T01 · Scope statement:** Draft the operation boundary for “Policy change handling” within Policy-as-code admission evaluator; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M06.05-C081-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Policy change handling”; record each producer, representation and missing-value meaning.
- [ ] **UC-M06.05-C081-T03 · Output inventory:** List the outputs of “Policy change handling” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M06.05-C081-T04 · Field dictionary:** Create a field-and-term dictionary for “Policy change handling”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M06.05-C081-T05 · Prerequisite contract:** Map “Policy change handling” to the source component prerequisites (UC-M03.08, UC-M04.08, UC-M06.03); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M06.05-C081-T06 · Authority map:** Identify who may produce, change and consume “Policy change handling”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M06.05-C081-T07 · Invariant clause:** Add a normative clause for “Policy change handling” that preserves “Queued work cannot execute under an obsolete weaker approval”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M06.05-C081-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Policy change handling”; include the source counterexample “A policy tightens while an old approved request waits to start” and the intended safe disposition.
- [ ] **UC-M06.05-C081-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Pending decisions and invalidation fan-out” in the “Policy change handling” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M06.05-C081-T10 · Contract review:** Review the “Policy change handling” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M06.05-C082 · Delivery

**Original checklist item:** Revalidate pending work when relevant policy or capability evidence changes.

- [ ] **UC-M06.05-C082-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Policy change handling”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M06.05-C082-T02 · Change plan:** Break the source delivery for “Policy change handling” into concrete edit targets and reviewable outputs; keep the UC-M06.05 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M06.05-C082-T03 · Core artifact:** Implement the smallest selected-profile change for “Policy change handling” that realizes this source instruction: Revalidate pending work when relevant policy or capability evidence changes.
- [ ] **UC-M06.05-C082-T04 · Concrete realization:** Trace “Policy change handling” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M06.05-C082-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Policy change handling” needed to preserve “Queued work cannot execute under an obsolete weaker approval”; record an enforcement gap where only a model exists.
- [ ] **UC-M06.05-C082-T06 · Dependency connection:** Connect the “Policy change handling” implementation to validated provenance, exercised host capabilities and pre-execution reservations; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M06.05-C082-T07 · Resource behavior:** Account for “Pending decisions and invalidation fan-out” in “Policy change handling”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M06.05-C082-T08 · Delivery check:** Run the smallest real “Policy change handling” path and its adverse fixture “A policy tightens while an old approved request waits to start”; retain actual output, state effects and final disposition.
- [ ] **UC-M06.05-C082-T09 · Patch review:** Review the “Policy change handling” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M06.05-C082-T10 · Delivery handoff:** Publish the “Policy change handling” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M06.05-C083 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Queued work cannot execute under an obsolete weaker approval. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M06.05-C083-T01 · Named property:** Create a stable property/check name under this parent for “Policy change handling”; copy its required invariant exactly: “Queued work cannot execute under an obsolete weaker approval”.
- [ ] **UC-M06.05-C083-T02 · Observable terms:** Define each term in the “Policy change handling” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M06.05-C083-T03 · Precondition set:** List the preconditions under which “Queued work cannot execute under an obsolete weaker approval” must hold for “Policy change handling”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M06.05-C083-T04 · Transition coverage:** Map the “Policy change handling” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M06.05-C083-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Policy change handling”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M06.05-C083-T06 · Satisfying fixture:** Create a concrete “Policy change handling” case that satisfies “Queued work cannot execute under an obsolete weaker approval”; record its expected observation before running the assertion or review.
- [ ] **UC-M06.05-C083-T07 · Violating fixture:** Create the source counterexample “A policy tightens while an old approved request waits to start” for “Policy change handling”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M06.05-C083-T08 · Enforcement evidence:** Exercise the “Policy change handling” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M06.05-C083-T09 · Regression linkage:** Link the “Policy change handling” property to changes in validated provenance, exercised host capabilities and pre-execution reservations; record which dependency or contract changes require rerunning it.
- [ ] **UC-M06.05-C083-T10 · Property disposition:** Compare the satisfying and violating “Policy change handling” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M06.05-C084 · Integration

**Original checklist item:** Integrate policy change handling with validated provenance, exercised host capabilities and pre-execution reservations; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M06.05-C084-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Policy change handling” across validated provenance, exercised host capabilities and pre-execution reservations; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M06.05-C084-T02 · Field mapping:** Map every “Policy change handling” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M06.05-C084-T03 · Prerequisite identities:** Record the actual prerequisites for “Policy change handling” (source dependency list: UC-M03.08, UC-M04.08, UC-M06.03); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M06.05-C084-T04 · Ownership agreement:** Specify who owns “Policy change handling” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M06.05-C084-T05 · Handoff implementation:** Connect “Policy change handling” through the mapped seam using the real adapter or explicit specification reference; preserve “Queued work cannot execute under an obsolete weaker approval” across the handoff.
- [ ] **UC-M06.05-C084-T06 · Absent-input case:** Omit one required “Policy change handling” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M06.05-C084-T07 · Stale-input case:** Supply an outdated “Policy change handling” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M06.05-C084-T08 · Incompatible-input case:** Supply an incompatible “Policy change handling” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M06.05-C084-T09 · Valid integration trace:** Run a valid “Policy change handling” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M06.05-C084-T10 · Seam review:** Reconcile the “Policy change handling” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M06.05-C085 · Valid-case test

**Original checklist item:** Run a valid-path fixture for policy change handling; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M06.05-C085-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Policy change handling” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M06.05-C085-T02 · Expected-result oracle:** Specify the “Policy change handling” expected result independently of the implementation output; include the property “Queued work cannot execute under an obsolete weaker approval” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M06.05-C085-T03 · Fixture material:** Create the concrete “Policy change handling” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M06.05-C085-T04 · Target preparation:** Prepare the “Policy change handling” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M06.05-C085-T05 · Initial-state record:** Record the initial “Policy change handling” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M06.05-C085-T06 · Valid-path execution:** Execute the “Policy change handling” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M06.05-C085-T07 · Outcome comparison:** Compare every declared “Policy change handling” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M06.05-C085-T08 · State and bounds check:** Inspect the “Policy change handling” ownership/state effects and actual use of “Pending decisions and invalidation fan-out”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M06.05-C085-T09 · Repeatability check:** Repeat the same “Policy change handling” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M06.05-C085-T10 · Positive evidence:** Attach the “Policy change handling” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M06.05-C086 · Negative test

**Original checklist item:** Negative case: A policy tightens while an old approved request waits to start. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M06.05-C086-T01 · Adverse-case definition:** Create a test record for the exact “Policy change handling” source counterexample: “A policy tightens while an old approved request waits to start”; state which precondition or invariant it challenges.
- [ ] **UC-M06.05-C086-T02 · Safe fixture boundary:** Define the contained test boundary for “Policy change handling”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M06.05-C086-T03 · Valid control:** Construct a valid “Policy change handling” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M06.05-C086-T04 · Minimal adverse input:** Derive the “Policy change handling” adverse fixture from the control with the smallest documented change needed to reproduce “A policy tightens while an old approved request waits to start”; retain that change as reproducible data.
- [ ] **UC-M06.05-C086-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Policy change handling”; require “Queued work cannot execute under an obsolete weaker approval” and forbid a false-success verdict.
- [ ] **UC-M06.05-C086-T06 · Adverse execution:** Exercise the “Policy change handling” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M06.05-C086-T07 · Effect inspection:** Inspect “Policy change handling” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M06.05-C086-T08 · Refusal versus failure:** Confirm the “Policy change handling” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M06.05-C086-T09 · Reset and retention:** Restore only the disposable “Policy change handling” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M06.05-C086-T10 · Negative regression:** Register the “Policy change handling” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M06.05-C087 · Change / failure test

**Original checklist item:** Exercise policy change handling when policy or capability evidence changes before an approved queued request starts; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M06.05-C087-T01 · Scenario record:** Write the “Policy change handling” change/failure scenario exactly as supplied: policy or capability evidence changes before an approved queued request starts; identify the property that must remain true: “Queued work cannot execute under an obsolete weaker approval”.
- [ ] **UC-M06.05-C087-T02 · Baseline capture:** Create a known-valid “Policy change handling” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M06.05-C087-T03 · Injection map:** Locate the “Policy change handling” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M06.05-C087-T04 · Disposition oracle:** Define the legal intermediate and final “Policy change handling” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M06.05-C087-T05 · Controlled trigger:** Introduce the controlled “Policy change handling” scenario in the disposable fixture: policy or capability evidence changes before an approved queued request starts; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M06.05-C087-T06 · Intermediate inspection:** Inspect the “Policy change handling” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M06.05-C087-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Policy change handling”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M06.05-C087-T08 · Stale-evidence cleanup:** Invalidate superseded “Policy change handling” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M06.05-C087-T09 · Repeat and compare:** Repeat the selected “Policy change handling” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M06.05-C087-T10 · Failure evidence:** Publish the “Policy change handling” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M06.05-C088 · Bounds

**Original checklist item:** Choose, document and test limits for pending decisions and invalidation fan-out; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M06.05-C088-T01 · Quantity inventory:** Create a measurement inventory for “Policy change handling”: “Pending decisions and invalidation fan-out”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M06.05-C088-T02 · Measurement method:** Choose how to observe each “Policy change handling” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M06.05-C088-T03 · Budget decision:** Select justified resource and input limits for “Policy change handling”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M06.05-C088-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Policy change handling” cases for “Pending decisions and invalidation fan-out”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M06.05-C088-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Policy change handling” limit; preserve “Queued work cannot execute under an obsolete weaker approval”.
- [ ] **UC-M06.05-C088-T06 · Normal measurement:** Run or review the normal “Policy change handling” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M06.05-C088-T07 · At-limit measurement:** Exercise the “Policy change handling” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M06.05-C088-T08 · Over-limit measurement:** Exercise the “Policy change handling” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M06.05-C088-T09 · Uncovered-scope report:** List the “Policy change handling” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M06.05-C088-T10 · Limit evidence:** Publish the selected “Policy change handling” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M06.05-C089 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for policy change handling with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M06.05-C089-T01 · Event inventory:** List the “Policy change handling” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M06.05-C089-T02 · Diagnostic schema:** Define nonsecret fields for “Policy change handling” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M06.05-C089-T03 · Failure mapping:** Map each documented “Policy change handling” refusal or error to a diagnostic outcome; include “A policy tightens while an old approved request waits to start” and prohibit conversion into a success message.
- [ ] **UC-M06.05-C089-T04 · Emission path:** Add the “Policy change handling” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M06.05-C089-T05 · Redaction check:** Test “Policy change handling” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M06.05-C089-T06 · Output budget:** Set and exercise bounded “Policy change handling” message size, rate and retention compatible with “Pending decisions and invalidation fan-out”; define truncation behavior that preserves the final reason.
- [ ] **UC-M06.05-C089-T07 · Success/refusal fixtures:** Capture “Policy change handling” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M06.05-C089-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Policy change handling” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M06.05-C089-T09 · Operator review:** Read the “Policy change handling” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M06.05-C089-T10 · Diagnostic evidence:** Publish redacted “Policy change handling” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M06.05-C090 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for policy change handling; label unexecuted checks as untested.

- [ ] **UC-M06.05-C090-T01 · Evidence inventory:** List the “Policy change handling” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M06.05-C090-T02 · Artifact references:** Record the exact “Policy change handling” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M06.05-C090-T03 · Fixture references:** Attach the “Policy change handling” fixture IDs, input identities and oracle definition; preserve the source counterexample “A policy tightens while an old approved request waits to start” as a distinct evidence case.
- [ ] **UC-M06.05-C090-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Policy change handling”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M06.05-C090-T05 · Environment record:** Record the actual “Policy change handling” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M06.05-C090-T06 · Expected versus observed:** Pair every “Policy change handling” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M06.05-C090-T07 · Failure and limit records:** Attach “Policy change handling” change/failure and bounds evidence where required; include uncovered “Pending decisions and invalidation fan-out” and unresolved violations of “Queued work cannot execute under an obsolete weaker approval”.
- [ ] **UC-M06.05-C090-T08 · Evidence hygiene:** Check the “Policy change handling” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M06.05-C090-T09 · Reproduction review:** Have the “Policy change handling” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M06.05-C090-T10 · Acceptance linkage:** Link the “Policy change handling” evidence to its parent and UC-M06.05 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 10. Admission evidence tests

**Source delivery:** Exercise each required deny reason and verify absence of side effects.

**Source invariant:** Recorded decisions correspond to the policy actually enforced.

**Source negative case:** A denied workload still leaves a mount or running child.

**Source bounded quantities:** Rule coverage and negative test runtime.

### UC-M06.05-C091 · Contract

**Original checklist item:** Specify admission evidence tests inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M06.05-C091-T01 · Scope statement:** Draft the operation boundary for “Admission evidence tests” within Policy-as-code admission evaluator; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M06.05-C091-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Admission evidence tests”; record each producer, representation and missing-value meaning.
- [ ] **UC-M06.05-C091-T03 · Output inventory:** List the outputs of “Admission evidence tests” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M06.05-C091-T04 · Field dictionary:** Create a field-and-term dictionary for “Admission evidence tests”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M06.05-C091-T05 · Prerequisite contract:** Map “Admission evidence tests” to the source component prerequisites (UC-M03.08, UC-M04.08, UC-M06.03); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M06.05-C091-T06 · Authority map:** Identify who may produce, change and consume “Admission evidence tests”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M06.05-C091-T07 · Invariant clause:** Add a normative clause for “Admission evidence tests” that preserves “Recorded decisions correspond to the policy actually enforced”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M06.05-C091-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Admission evidence tests”; include the source counterexample “A denied workload still leaves a mount or running child” and the intended safe disposition.
- [ ] **UC-M06.05-C091-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Rule coverage and negative test runtime” in the “Admission evidence tests” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M06.05-C091-T10 · Contract review:** Review the “Admission evidence tests” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M06.05-C092 · Delivery

**Original checklist item:** Exercise each required deny reason and verify absence of side effects.

- [ ] **UC-M06.05-C092-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Admission evidence tests”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M06.05-C092-T02 · Change plan:** Break the source delivery for “Admission evidence tests” into concrete edit targets and reviewable outputs; keep the UC-M06.05 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M06.05-C092-T03 · Core artifact:** Create the “Admission evidence tests” fixture or harness for this source instruction: Exercise each required deny reason and verify absence of side effects.
- [ ] **UC-M06.05-C092-T04 · Concrete realization:** Connect the “Admission evidence tests” harness to its actual intended target, set the expected oracle before running it, and distinguish a mock/control run from a target run.
- [ ] **UC-M06.05-C092-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Admission evidence tests” needed to preserve “Recorded decisions correspond to the policy actually enforced”; record an enforcement gap where only a model exists.
- [ ] **UC-M06.05-C092-T06 · Dependency connection:** Connect the “Admission evidence tests” implementation to validated provenance, exercised host capabilities and pre-execution reservations; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M06.05-C092-T07 · Resource behavior:** Account for “Rule coverage and negative test runtime” in “Admission evidence tests”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M06.05-C092-T08 · Delivery check:** Run the smallest real “Admission evidence tests” path and its adverse fixture “A denied workload still leaves a mount or running child”; retain actual output, state effects and final disposition.
- [ ] **UC-M06.05-C092-T09 · Patch review:** Review the “Admission evidence tests” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M06.05-C092-T10 · Delivery handoff:** Publish the “Admission evidence tests” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M06.05-C093 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Recorded decisions correspond to the policy actually enforced. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M06.05-C093-T01 · Named property:** Create a stable property/check name under this parent for “Admission evidence tests”; copy its required invariant exactly: “Recorded decisions correspond to the policy actually enforced”.
- [ ] **UC-M06.05-C093-T02 · Observable terms:** Define each term in the “Admission evidence tests” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M06.05-C093-T03 · Precondition set:** List the preconditions under which “Recorded decisions correspond to the policy actually enforced” must hold for “Admission evidence tests”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M06.05-C093-T04 · Transition coverage:** Map the “Admission evidence tests” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M06.05-C093-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Admission evidence tests”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M06.05-C093-T06 · Satisfying fixture:** Create a concrete “Admission evidence tests” case that satisfies “Recorded decisions correspond to the policy actually enforced”; record its expected observation before running the assertion or review.
- [ ] **UC-M06.05-C093-T07 · Violating fixture:** Create the source counterexample “A denied workload still leaves a mount or running child” for “Admission evidence tests”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M06.05-C093-T08 · Enforcement evidence:** Exercise the “Admission evidence tests” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M06.05-C093-T09 · Regression linkage:** Link the “Admission evidence tests” property to changes in validated provenance, exercised host capabilities and pre-execution reservations; record which dependency or contract changes require rerunning it.
- [ ] **UC-M06.05-C093-T10 · Property disposition:** Compare the satisfying and violating “Admission evidence tests” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M06.05-C094 · Integration

**Original checklist item:** Integrate admission evidence tests with validated provenance, exercised host capabilities and pre-execution reservations; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M06.05-C094-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Admission evidence tests” across validated provenance, exercised host capabilities and pre-execution reservations; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M06.05-C094-T02 · Field mapping:** Map every “Admission evidence tests” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M06.05-C094-T03 · Prerequisite identities:** Record the actual prerequisites for “Admission evidence tests” (source dependency list: UC-M03.08, UC-M04.08, UC-M06.03); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M06.05-C094-T04 · Ownership agreement:** Specify who owns “Admission evidence tests” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M06.05-C094-T05 · Handoff implementation:** Connect “Admission evidence tests” through the mapped seam using the real adapter or explicit specification reference; preserve “Recorded decisions correspond to the policy actually enforced” across the handoff.
- [ ] **UC-M06.05-C094-T06 · Absent-input case:** Omit one required “Admission evidence tests” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M06.05-C094-T07 · Stale-input case:** Supply an outdated “Admission evidence tests” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M06.05-C094-T08 · Incompatible-input case:** Supply an incompatible “Admission evidence tests” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M06.05-C094-T09 · Valid integration trace:** Run a valid “Admission evidence tests” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M06.05-C094-T10 · Seam review:** Reconcile the “Admission evidence tests” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M06.05-C095 · Valid-case test

**Original checklist item:** Run a valid-path fixture for admission evidence tests; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M06.05-C095-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Admission evidence tests” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M06.05-C095-T02 · Expected-result oracle:** Specify the “Admission evidence tests” expected result independently of the implementation output; include the property “Recorded decisions correspond to the policy actually enforced” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M06.05-C095-T03 · Fixture material:** Create the concrete “Admission evidence tests” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M06.05-C095-T04 · Target preparation:** Prepare the “Admission evidence tests” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M06.05-C095-T05 · Initial-state record:** Record the initial “Admission evidence tests” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M06.05-C095-T06 · Valid-path execution:** Execute the “Admission evidence tests” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M06.05-C095-T07 · Outcome comparison:** Compare every declared “Admission evidence tests” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M06.05-C095-T08 · State and bounds check:** Inspect the “Admission evidence tests” ownership/state effects and actual use of “Rule coverage and negative test runtime”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M06.05-C095-T09 · Repeatability check:** Repeat the same “Admission evidence tests” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M06.05-C095-T10 · Positive evidence:** Attach the “Admission evidence tests” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M06.05-C096 · Negative test

**Original checklist item:** Negative case: A denied workload still leaves a mount or running child. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M06.05-C096-T01 · Adverse-case definition:** Create a test record for the exact “Admission evidence tests” source counterexample: “A denied workload still leaves a mount or running child”; state which precondition or invariant it challenges.
- [ ] **UC-M06.05-C096-T02 · Safe fixture boundary:** Define the contained test boundary for “Admission evidence tests”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M06.05-C096-T03 · Valid control:** Construct a valid “Admission evidence tests” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M06.05-C096-T04 · Minimal adverse input:** Derive the “Admission evidence tests” adverse fixture from the control with the smallest documented change needed to reproduce “A denied workload still leaves a mount or running child”; retain that change as reproducible data.
- [ ] **UC-M06.05-C096-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Admission evidence tests”; require “Recorded decisions correspond to the policy actually enforced” and forbid a false-success verdict.
- [ ] **UC-M06.05-C096-T06 · Adverse execution:** Exercise the “Admission evidence tests” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M06.05-C096-T07 · Effect inspection:** Inspect “Admission evidence tests” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M06.05-C096-T08 · Refusal versus failure:** Confirm the “Admission evidence tests” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M06.05-C096-T09 · Reset and retention:** Restore only the disposable “Admission evidence tests” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M06.05-C096-T10 · Negative regression:** Register the “Admission evidence tests” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M06.05-C097 · Change / failure test

**Original checklist item:** Exercise admission evidence tests when policy or capability evidence changes before an approved queued request starts; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M06.05-C097-T01 · Scenario record:** Write the “Admission evidence tests” change/failure scenario exactly as supplied: policy or capability evidence changes before an approved queued request starts; identify the property that must remain true: “Recorded decisions correspond to the policy actually enforced”.
- [ ] **UC-M06.05-C097-T02 · Baseline capture:** Create a known-valid “Admission evidence tests” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M06.05-C097-T03 · Injection map:** Locate the “Admission evidence tests” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M06.05-C097-T04 · Disposition oracle:** Define the legal intermediate and final “Admission evidence tests” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M06.05-C097-T05 · Controlled trigger:** Introduce the controlled “Admission evidence tests” scenario in the disposable fixture: policy or capability evidence changes before an approved queued request starts; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M06.05-C097-T06 · Intermediate inspection:** Inspect the “Admission evidence tests” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M06.05-C097-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Admission evidence tests”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M06.05-C097-T08 · Stale-evidence cleanup:** Invalidate superseded “Admission evidence tests” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M06.05-C097-T09 · Repeat and compare:** Repeat the selected “Admission evidence tests” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M06.05-C097-T10 · Failure evidence:** Publish the “Admission evidence tests” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M06.05-C098 · Bounds

**Original checklist item:** Choose, document and test limits for rule coverage and negative test runtime; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M06.05-C098-T01 · Quantity inventory:** Create a measurement inventory for “Admission evidence tests”: “Rule coverage and negative test runtime”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M06.05-C098-T02 · Measurement method:** Choose how to observe each “Admission evidence tests” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M06.05-C098-T03 · Budget decision:** Select justified resource and input limits for “Admission evidence tests”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M06.05-C098-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Admission evidence tests” cases for “Rule coverage and negative test runtime”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M06.05-C098-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Admission evidence tests” limit; preserve “Recorded decisions correspond to the policy actually enforced”.
- [ ] **UC-M06.05-C098-T06 · Normal measurement:** Run or review the normal “Admission evidence tests” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M06.05-C098-T07 · At-limit measurement:** Exercise the “Admission evidence tests” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M06.05-C098-T08 · Over-limit measurement:** Exercise the “Admission evidence tests” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M06.05-C098-T09 · Uncovered-scope report:** List the “Admission evidence tests” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M06.05-C098-T10 · Limit evidence:** Publish the selected “Admission evidence tests” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M06.05-C099 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for admission evidence tests with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M06.05-C099-T01 · Event inventory:** List the “Admission evidence tests” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M06.05-C099-T02 · Diagnostic schema:** Define nonsecret fields for “Admission evidence tests” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M06.05-C099-T03 · Failure mapping:** Map each documented “Admission evidence tests” refusal or error to a diagnostic outcome; include “A denied workload still leaves a mount or running child” and prohibit conversion into a success message.
- [ ] **UC-M06.05-C099-T04 · Emission path:** Add the “Admission evidence tests” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M06.05-C099-T05 · Redaction check:** Test “Admission evidence tests” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M06.05-C099-T06 · Output budget:** Set and exercise bounded “Admission evidence tests” message size, rate and retention compatible with “Rule coverage and negative test runtime”; define truncation behavior that preserves the final reason.
- [ ] **UC-M06.05-C099-T07 · Success/refusal fixtures:** Capture “Admission evidence tests” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M06.05-C099-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Admission evidence tests” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M06.05-C099-T09 · Operator review:** Read the “Admission evidence tests” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M06.05-C099-T10 · Diagnostic evidence:** Publish redacted “Admission evidence tests” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M06.05-C100 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for admission evidence tests; label unexecuted checks as untested.

- [ ] **UC-M06.05-C100-T01 · Evidence inventory:** List the “Admission evidence tests” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M06.05-C100-T02 · Artifact references:** Record the exact “Admission evidence tests” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M06.05-C100-T03 · Fixture references:** Attach the “Admission evidence tests” fixture IDs, input identities and oracle definition; preserve the source counterexample “A denied workload still leaves a mount or running child” as a distinct evidence case.
- [ ] **UC-M06.05-C100-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Admission evidence tests”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M06.05-C100-T05 · Environment record:** Record the actual “Admission evidence tests” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M06.05-C100-T06 · Expected versus observed:** Pair every “Admission evidence tests” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M06.05-C100-T07 · Failure and limit records:** Attach “Admission evidence tests” change/failure and bounds evidence where required; include uncovered “Rule coverage and negative test runtime” and unresolved violations of “Recorded decisions correspond to the policy actually enforced”.
- [ ] **UC-M06.05-C100-T08 · Evidence hygiene:** Check the “Admission evidence tests” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M06.05-C100-T09 · Reproduction review:** Have the “Admission evidence tests” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M06.05-C100-T10 · Acceptance linkage:** Link the “Admission evidence tests” evidence to its parent and UC-M06.05 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

