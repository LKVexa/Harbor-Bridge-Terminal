# UC-M06.03 — Least-privilege authorization

**To-Do Pack 2.0.0 · Baseline UC-2.2.0 · 100 parent checks × 10 subtasks = 1,000 to-dos**

[Master index](../../INDEX.md) · [Workstream index](../../w/06.md)

| Field | Preserved source value |
|---|---|
| Workstream | 06. Control plane, identity and policy |
| Milestone | C |
| Priority | P0 |
| Source assessment | MISSING |
| Scope | core or selected profile |
| Dependencies | [UC-M06.02](../06/UC-M06.02.md) |
| Source checklist pack | 1.0.0 |
| Original reference labels | [S4], [S6]. |

## Original requirement

Define distinct permissions for read, build, execute, seal, sign, trust enrollment and destructive lifecycle actions.

**Original acceptance criterion:** A read-only operator cannot escalate through an indirect command or optional argument.

**Source trace:** Original checklist `UC100/c/06/UC-M06.03.md` inside [s/checklists.zip](../../s/checklists.zip); exact parent records in [data/parents.jsonl](../../data/parents.jsonl). Original roadmap lines 546–556 are preserved in [s/roadmap.md](../../s/roadmap.md).

## How to use these lists

Every parent statement below is preserved verbatim. Its ten child tasks are proposed decomposition, not implemented capabilities or executed tests. Child IDs append `-T01` through `-T10` to the original parent ID. All begin unchecked / `TODO`. Design/review evidence does not establish runtime enforcement; observe the actual selected target where the parent requires it.

The source dependency graph and selected release profile determine applicability. The numbered child sequence is a local working order, not an added hard dependency graph. An unselected optional feature needs a recorded not-applicable rationale; missing prerequisites for selected work remain blockers. Numerical budgets, backends and trust mechanisms remain decisions unless fixed by the source. Test hostile cases only with synthetic inputs in authorized disposable environments.

## 01. Permission vocabulary

**Source delivery:** Define separate read, build, execute, seal, sign, enroll and destructive-action permissions.

**Source invariant:** One broad convenience permission does not silently imply all authority.

**Source negative case:** Read permission is treated as permission to execute a helper.

**Source bounded quantities:** Permission count and policy size.

### UC-M06.03-C001 · Contract

**Original checklist item:** Specify permission vocabulary inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M06.03-C001-T01 · Scope statement:** Draft the operation boundary for “Permission vocabulary” within Least-privilege authorization; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M06.03-C001-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Permission vocabulary”; record each producer, representation and missing-value meaning.
- [ ] **UC-M06.03-C001-T03 · Output inventory:** List the outputs of “Permission vocabulary” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M06.03-C001-T04 · Field dictionary:** Create a field-and-term dictionary for “Permission vocabulary”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M06.03-C001-T05 · Prerequisite contract:** Map “Permission vocabulary” to the source component prerequisites (UC-M06.02); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M06.03-C001-T06 · Authority map:** Identify who may produce, change and consume “Permission vocabulary”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M06.03-C001-T07 · Invariant clause:** Add a normative clause for “Permission vocabulary” that preserves “One broad convenience permission does not silently imply all authority”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M06.03-C001-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Permission vocabulary”; include the source counterexample “Read permission is treated as permission to execute a helper” and the intended safe disposition.
- [ ] **UC-M06.03-C001-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Permission count and policy size” in the “Permission vocabulary” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M06.03-C001-T10 · Contract review:** Review the “Permission vocabulary” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M06.03-C002 · Delivery

**Original checklist item:** Define separate read, build, execute, seal, sign, enroll and destructive-action permissions.

- [ ] **UC-M06.03-C002-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Permission vocabulary”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M06.03-C002-T02 · Change plan:** Break the source delivery for “Permission vocabulary” into concrete edit targets and reviewable outputs; keep the UC-M06.03 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M06.03-C002-T03 · Core artifact:** Create the “Permission vocabulary” model, schema or inventory that realizes this source instruction: Define separate read, build, execute, seal, sign, enroll and destructive-action permissions.
- [ ] **UC-M06.03-C002-T04 · Concrete realization:** Populate “Permission vocabulary” with one concrete worked case; map every required entity or field to its source and flag any unmapped entry.
- [ ] **UC-M06.03-C002-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Permission vocabulary” needed to preserve “One broad convenience permission does not silently imply all authority”; record an enforcement gap where only a model exists.
- [ ] **UC-M06.03-C002-T06 · Dependency connection:** Connect the “Permission vocabulary” implementation to all command/API entry points, resource scopes and privileged broker actions; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M06.03-C002-T07 · Resource behavior:** Account for “Permission count and policy size” in “Permission vocabulary”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M06.03-C002-T08 · Delivery check:** Run the smallest real “Permission vocabulary” path and its adverse fixture “Read permission is treated as permission to execute a helper”; retain actual output, state effects and final disposition.
- [ ] **UC-M06.03-C002-T09 · Patch review:** Review the “Permission vocabulary” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M06.03-C002-T10 · Delivery handoff:** Publish the “Permission vocabulary” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M06.03-C003 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: One broad convenience permission does not silently imply all authority. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M06.03-C003-T01 · Named property:** Create a stable property/check name under this parent for “Permission vocabulary”; copy its required invariant exactly: “One broad convenience permission does not silently imply all authority”.
- [ ] **UC-M06.03-C003-T02 · Observable terms:** Define each term in the “Permission vocabulary” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M06.03-C003-T03 · Precondition set:** List the preconditions under which “One broad convenience permission does not silently imply all authority” must hold for “Permission vocabulary”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M06.03-C003-T04 · Transition coverage:** Map the “Permission vocabulary” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M06.03-C003-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Permission vocabulary”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M06.03-C003-T06 · Satisfying fixture:** Create a concrete “Permission vocabulary” case that satisfies “One broad convenience permission does not silently imply all authority”; record its expected observation before running the assertion or review.
- [ ] **UC-M06.03-C003-T07 · Violating fixture:** Create the source counterexample “Read permission is treated as permission to execute a helper” for “Permission vocabulary”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M06.03-C003-T08 · Enforcement evidence:** Exercise the “Permission vocabulary” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M06.03-C003-T09 · Regression linkage:** Link the “Permission vocabulary” property to changes in all command/API entry points, resource scopes and privileged broker actions; record which dependency or contract changes require rerunning it.
- [ ] **UC-M06.03-C003-T10 · Property disposition:** Compare the satisfying and violating “Permission vocabulary” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M06.03-C004 · Integration

**Original checklist item:** Integrate permission vocabulary with all command/API entry points, resource scopes and privileged broker actions; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M06.03-C004-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Permission vocabulary” across all command/API entry points, resource scopes and privileged broker actions; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M06.03-C004-T02 · Field mapping:** Map every “Permission vocabulary” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M06.03-C004-T03 · Prerequisite identities:** Record the actual prerequisites for “Permission vocabulary” (source dependency list: UC-M06.02); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M06.03-C004-T04 · Ownership agreement:** Specify who owns “Permission vocabulary” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M06.03-C004-T05 · Handoff implementation:** Connect “Permission vocabulary” through the mapped seam using the real adapter or explicit specification reference; preserve “One broad convenience permission does not silently imply all authority” across the handoff.
- [ ] **UC-M06.03-C004-T06 · Absent-input case:** Omit one required “Permission vocabulary” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M06.03-C004-T07 · Stale-input case:** Supply an outdated “Permission vocabulary” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M06.03-C004-T08 · Incompatible-input case:** Supply an incompatible “Permission vocabulary” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M06.03-C004-T09 · Valid integration trace:** Run a valid “Permission vocabulary” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M06.03-C004-T10 · Seam review:** Reconcile the “Permission vocabulary” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M06.03-C005 · Valid-case test

**Original checklist item:** Run a valid-path fixture for permission vocabulary; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M06.03-C005-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Permission vocabulary” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M06.03-C005-T02 · Expected-result oracle:** Specify the “Permission vocabulary” expected result independently of the implementation output; include the property “One broad convenience permission does not silently imply all authority” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M06.03-C005-T03 · Fixture material:** Create the concrete “Permission vocabulary” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M06.03-C005-T04 · Target preparation:** Prepare the “Permission vocabulary” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M06.03-C005-T05 · Initial-state record:** Record the initial “Permission vocabulary” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M06.03-C005-T06 · Valid-path execution:** Execute the “Permission vocabulary” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M06.03-C005-T07 · Outcome comparison:** Compare every declared “Permission vocabulary” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M06.03-C005-T08 · State and bounds check:** Inspect the “Permission vocabulary” ownership/state effects and actual use of “Permission count and policy size”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M06.03-C005-T09 · Repeatability check:** Repeat the same “Permission vocabulary” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M06.03-C005-T10 · Positive evidence:** Attach the “Permission vocabulary” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M06.03-C006 · Negative test

**Original checklist item:** Negative case: Read permission is treated as permission to execute a helper. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M06.03-C006-T01 · Adverse-case definition:** Create a test record for the exact “Permission vocabulary” source counterexample: “Read permission is treated as permission to execute a helper”; state which precondition or invariant it challenges.
- [ ] **UC-M06.03-C006-T02 · Safe fixture boundary:** Define the contained test boundary for “Permission vocabulary”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M06.03-C006-T03 · Valid control:** Construct a valid “Permission vocabulary” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M06.03-C006-T04 · Minimal adverse input:** Derive the “Permission vocabulary” adverse fixture from the control with the smallest documented change needed to reproduce “Read permission is treated as permission to execute a helper”; retain that change as reproducible data.
- [ ] **UC-M06.03-C006-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Permission vocabulary”; require “One broad convenience permission does not silently imply all authority” and forbid a false-success verdict.
- [ ] **UC-M06.03-C006-T06 · Adverse execution:** Exercise the “Permission vocabulary” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M06.03-C006-T07 · Effect inspection:** Inspect “Permission vocabulary” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M06.03-C006-T08 · Refusal versus failure:** Confirm the “Permission vocabulary” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M06.03-C006-T09 · Reset and retention:** Restore only the disposable “Permission vocabulary” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M06.03-C006-T10 · Negative regression:** Register the “Permission vocabulary” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M06.03-C007 · Change / failure test

**Original checklist item:** Exercise permission vocabulary when an indirect option or newly added command attempts an action denied by the normal path; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M06.03-C007-T01 · Scenario record:** Write the “Permission vocabulary” change/failure scenario exactly as supplied: an indirect option or newly added command attempts an action denied by the normal path; identify the property that must remain true: “One broad convenience permission does not silently imply all authority”.
- [ ] **UC-M06.03-C007-T02 · Baseline capture:** Create a known-valid “Permission vocabulary” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M06.03-C007-T03 · Injection map:** Locate the “Permission vocabulary” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M06.03-C007-T04 · Disposition oracle:** Define the legal intermediate and final “Permission vocabulary” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M06.03-C007-T05 · Controlled trigger:** Introduce the controlled “Permission vocabulary” scenario in the disposable fixture: an indirect option or newly added command attempts an action denied by the normal path; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M06.03-C007-T06 · Intermediate inspection:** Inspect the “Permission vocabulary” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M06.03-C007-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Permission vocabulary”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M06.03-C007-T08 · Stale-evidence cleanup:** Invalidate superseded “Permission vocabulary” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M06.03-C007-T09 · Repeat and compare:** Repeat the selected “Permission vocabulary” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M06.03-C007-T10 · Failure evidence:** Publish the “Permission vocabulary” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M06.03-C008 · Bounds

**Original checklist item:** Choose, document and test limits for permission count and policy size; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M06.03-C008-T01 · Quantity inventory:** Create a measurement inventory for “Permission vocabulary”: “Permission count and policy size”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M06.03-C008-T02 · Measurement method:** Choose how to observe each “Permission vocabulary” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M06.03-C008-T03 · Budget decision:** Select justified resource and input limits for “Permission vocabulary”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M06.03-C008-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Permission vocabulary” cases for “Permission count and policy size”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M06.03-C008-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Permission vocabulary” limit; preserve “One broad convenience permission does not silently imply all authority”.
- [ ] **UC-M06.03-C008-T06 · Normal measurement:** Run or review the normal “Permission vocabulary” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M06.03-C008-T07 · At-limit measurement:** Exercise the “Permission vocabulary” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M06.03-C008-T08 · Over-limit measurement:** Exercise the “Permission vocabulary” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M06.03-C008-T09 · Uncovered-scope report:** List the “Permission vocabulary” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M06.03-C008-T10 · Limit evidence:** Publish the selected “Permission vocabulary” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M06.03-C009 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for permission vocabulary with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M06.03-C009-T01 · Event inventory:** List the “Permission vocabulary” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M06.03-C009-T02 · Diagnostic schema:** Define nonsecret fields for “Permission vocabulary” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M06.03-C009-T03 · Failure mapping:** Map each documented “Permission vocabulary” refusal or error to a diagnostic outcome; include “Read permission is treated as permission to execute a helper” and prohibit conversion into a success message.
- [ ] **UC-M06.03-C009-T04 · Emission path:** Add the “Permission vocabulary” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M06.03-C009-T05 · Redaction check:** Test “Permission vocabulary” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M06.03-C009-T06 · Output budget:** Set and exercise bounded “Permission vocabulary” message size, rate and retention compatible with “Permission count and policy size”; define truncation behavior that preserves the final reason.
- [ ] **UC-M06.03-C009-T07 · Success/refusal fixtures:** Capture “Permission vocabulary” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M06.03-C009-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Permission vocabulary” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M06.03-C009-T09 · Operator review:** Read the “Permission vocabulary” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M06.03-C009-T10 · Diagnostic evidence:** Publish redacted “Permission vocabulary” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M06.03-C010 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for permission vocabulary; label unexecuted checks as untested.

- [ ] **UC-M06.03-C010-T01 · Evidence inventory:** List the “Permission vocabulary” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M06.03-C010-T02 · Artifact references:** Record the exact “Permission vocabulary” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M06.03-C010-T03 · Fixture references:** Attach the “Permission vocabulary” fixture IDs, input identities and oracle definition; preserve the source counterexample “Read permission is treated as permission to execute a helper” as a distinct evidence case.
- [ ] **UC-M06.03-C010-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Permission vocabulary”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M06.03-C010-T05 · Environment record:** Record the actual “Permission vocabulary” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M06.03-C010-T06 · Expected versus observed:** Pair every “Permission vocabulary” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M06.03-C010-T07 · Failure and limit records:** Attach “Permission vocabulary” change/failure and bounds evidence where required; include uncovered “Permission count and policy size” and unresolved violations of “One broad convenience permission does not silently imply all authority”.
- [ ] **UC-M06.03-C010-T08 · Evidence hygiene:** Check the “Permission vocabulary” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M06.03-C010-T09 · Reproduction review:** Have the “Permission vocabulary” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M06.03-C010-T10 · Acceptance linkage:** Link the “Permission vocabulary” evidence to its parent and UC-M06.03 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 02. Resource scoping

**Source delivery:** Scope permissions to tenants, workspaces, workloads and generations where required.

**Source invariant:** A permission for one resource does not authorize another.

**Source negative case:** A tenant-scoped operator stops a different tenant's workload.

**Source bounded quantities:** Scope rules and resource lookup cost.

### UC-M06.03-C011 · Contract

**Original checklist item:** Specify resource scoping inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M06.03-C011-T01 · Scope statement:** Draft the operation boundary for “Resource scoping” within Least-privilege authorization; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M06.03-C011-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Resource scoping”; record each producer, representation and missing-value meaning.
- [ ] **UC-M06.03-C011-T03 · Output inventory:** List the outputs of “Resource scoping” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M06.03-C011-T04 · Field dictionary:** Create a field-and-term dictionary for “Resource scoping”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M06.03-C011-T05 · Prerequisite contract:** Map “Resource scoping” to the source component prerequisites (UC-M06.02); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M06.03-C011-T06 · Authority map:** Identify who may produce, change and consume “Resource scoping”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M06.03-C011-T07 · Invariant clause:** Add a normative clause for “Resource scoping” that preserves “A permission for one resource does not authorize another”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M06.03-C011-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Resource scoping”; include the source counterexample “A tenant-scoped operator stops a different tenant's workload” and the intended safe disposition.
- [ ] **UC-M06.03-C011-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Scope rules and resource lookup cost” in the “Resource scoping” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M06.03-C011-T10 · Contract review:** Review the “Resource scoping” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M06.03-C012 · Delivery

**Original checklist item:** Scope permissions to tenants, workspaces, workloads and generations where required.

- [ ] **UC-M06.03-C012-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Resource scoping”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M06.03-C012-T02 · Change plan:** Break the source delivery for “Resource scoping” into concrete edit targets and reviewable outputs; keep the UC-M06.03 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M06.03-C012-T03 · Core artifact:** Implement the smallest selected-profile change for “Resource scoping” that realizes this source instruction: Scope permissions to tenants, workspaces, workloads and generations where required.
- [ ] **UC-M06.03-C012-T04 · Concrete realization:** Trace “Resource scoping” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M06.03-C012-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Resource scoping” needed to preserve “A permission for one resource does not authorize another”; record an enforcement gap where only a model exists.
- [ ] **UC-M06.03-C012-T06 · Dependency connection:** Connect the “Resource scoping” implementation to all command/API entry points, resource scopes and privileged broker actions; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M06.03-C012-T07 · Resource behavior:** Account for “Scope rules and resource lookup cost” in “Resource scoping”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M06.03-C012-T08 · Delivery check:** Run the smallest real “Resource scoping” path and its adverse fixture “A tenant-scoped operator stops a different tenant's workload”; retain actual output, state effects and final disposition.
- [ ] **UC-M06.03-C012-T09 · Patch review:** Review the “Resource scoping” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M06.03-C012-T10 · Delivery handoff:** Publish the “Resource scoping” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M06.03-C013 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: A permission for one resource does not authorize another. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M06.03-C013-T01 · Named property:** Create a stable property/check name under this parent for “Resource scoping”; copy its required invariant exactly: “A permission for one resource does not authorize another”.
- [ ] **UC-M06.03-C013-T02 · Observable terms:** Define each term in the “Resource scoping” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M06.03-C013-T03 · Precondition set:** List the preconditions under which “A permission for one resource does not authorize another” must hold for “Resource scoping”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M06.03-C013-T04 · Transition coverage:** Map the “Resource scoping” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M06.03-C013-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Resource scoping”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M06.03-C013-T06 · Satisfying fixture:** Create a concrete “Resource scoping” case that satisfies “A permission for one resource does not authorize another”; record its expected observation before running the assertion or review.
- [ ] **UC-M06.03-C013-T07 · Violating fixture:** Create the source counterexample “A tenant-scoped operator stops a different tenant's workload” for “Resource scoping”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M06.03-C013-T08 · Enforcement evidence:** Exercise the “Resource scoping” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M06.03-C013-T09 · Regression linkage:** Link the “Resource scoping” property to changes in all command/API entry points, resource scopes and privileged broker actions; record which dependency or contract changes require rerunning it.
- [ ] **UC-M06.03-C013-T10 · Property disposition:** Compare the satisfying and violating “Resource scoping” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M06.03-C014 · Integration

**Original checklist item:** Integrate resource scoping with all command/API entry points, resource scopes and privileged broker actions; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M06.03-C014-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Resource scoping” across all command/API entry points, resource scopes and privileged broker actions; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M06.03-C014-T02 · Field mapping:** Map every “Resource scoping” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M06.03-C014-T03 · Prerequisite identities:** Record the actual prerequisites for “Resource scoping” (source dependency list: UC-M06.02); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M06.03-C014-T04 · Ownership agreement:** Specify who owns “Resource scoping” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M06.03-C014-T05 · Handoff implementation:** Connect “Resource scoping” through the mapped seam using the real adapter or explicit specification reference; preserve “A permission for one resource does not authorize another” across the handoff.
- [ ] **UC-M06.03-C014-T06 · Absent-input case:** Omit one required “Resource scoping” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M06.03-C014-T07 · Stale-input case:** Supply an outdated “Resource scoping” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M06.03-C014-T08 · Incompatible-input case:** Supply an incompatible “Resource scoping” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M06.03-C014-T09 · Valid integration trace:** Run a valid “Resource scoping” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M06.03-C014-T10 · Seam review:** Reconcile the “Resource scoping” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M06.03-C015 · Valid-case test

**Original checklist item:** Run a valid-path fixture for resource scoping; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M06.03-C015-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Resource scoping” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M06.03-C015-T02 · Expected-result oracle:** Specify the “Resource scoping” expected result independently of the implementation output; include the property “A permission for one resource does not authorize another” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M06.03-C015-T03 · Fixture material:** Create the concrete “Resource scoping” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M06.03-C015-T04 · Target preparation:** Prepare the “Resource scoping” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M06.03-C015-T05 · Initial-state record:** Record the initial “Resource scoping” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M06.03-C015-T06 · Valid-path execution:** Execute the “Resource scoping” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M06.03-C015-T07 · Outcome comparison:** Compare every declared “Resource scoping” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M06.03-C015-T08 · State and bounds check:** Inspect the “Resource scoping” ownership/state effects and actual use of “Scope rules and resource lookup cost”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M06.03-C015-T09 · Repeatability check:** Repeat the same “Resource scoping” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M06.03-C015-T10 · Positive evidence:** Attach the “Resource scoping” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M06.03-C016 · Negative test

**Original checklist item:** Negative case: A tenant-scoped operator stops a different tenant's workload. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M06.03-C016-T01 · Adverse-case definition:** Create a test record for the exact “Resource scoping” source counterexample: “A tenant-scoped operator stops a different tenant's workload”; state which precondition or invariant it challenges.
- [ ] **UC-M06.03-C016-T02 · Safe fixture boundary:** Define the contained test boundary for “Resource scoping”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M06.03-C016-T03 · Valid control:** Construct a valid “Resource scoping” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M06.03-C016-T04 · Minimal adverse input:** Derive the “Resource scoping” adverse fixture from the control with the smallest documented change needed to reproduce “A tenant-scoped operator stops a different tenant's workload”; retain that change as reproducible data.
- [ ] **UC-M06.03-C016-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Resource scoping”; require “A permission for one resource does not authorize another” and forbid a false-success verdict.
- [ ] **UC-M06.03-C016-T06 · Adverse execution:** Exercise the “Resource scoping” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M06.03-C016-T07 · Effect inspection:** Inspect “Resource scoping” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M06.03-C016-T08 · Refusal versus failure:** Confirm the “Resource scoping” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M06.03-C016-T09 · Reset and retention:** Restore only the disposable “Resource scoping” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M06.03-C016-T10 · Negative regression:** Register the “Resource scoping” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M06.03-C017 · Change / failure test

**Original checklist item:** Exercise resource scoping when an indirect option or newly added command attempts an action denied by the normal path; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M06.03-C017-T01 · Scenario record:** Write the “Resource scoping” change/failure scenario exactly as supplied: an indirect option or newly added command attempts an action denied by the normal path; identify the property that must remain true: “A permission for one resource does not authorize another”.
- [ ] **UC-M06.03-C017-T02 · Baseline capture:** Create a known-valid “Resource scoping” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M06.03-C017-T03 · Injection map:** Locate the “Resource scoping” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M06.03-C017-T04 · Disposition oracle:** Define the legal intermediate and final “Resource scoping” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M06.03-C017-T05 · Controlled trigger:** Introduce the controlled “Resource scoping” scenario in the disposable fixture: an indirect option or newly added command attempts an action denied by the normal path; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M06.03-C017-T06 · Intermediate inspection:** Inspect the “Resource scoping” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M06.03-C017-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Resource scoping”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M06.03-C017-T08 · Stale-evidence cleanup:** Invalidate superseded “Resource scoping” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M06.03-C017-T09 · Repeat and compare:** Repeat the selected “Resource scoping” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M06.03-C017-T10 · Failure evidence:** Publish the “Resource scoping” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M06.03-C018 · Bounds

**Original checklist item:** Choose, document and test limits for scope rules and resource lookup cost; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M06.03-C018-T01 · Quantity inventory:** Create a measurement inventory for “Resource scoping”: “Scope rules and resource lookup cost”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M06.03-C018-T02 · Measurement method:** Choose how to observe each “Resource scoping” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M06.03-C018-T03 · Budget decision:** Select justified resource and input limits for “Resource scoping”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M06.03-C018-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Resource scoping” cases for “Scope rules and resource lookup cost”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M06.03-C018-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Resource scoping” limit; preserve “A permission for one resource does not authorize another”.
- [ ] **UC-M06.03-C018-T06 · Normal measurement:** Run or review the normal “Resource scoping” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M06.03-C018-T07 · At-limit measurement:** Exercise the “Resource scoping” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M06.03-C018-T08 · Over-limit measurement:** Exercise the “Resource scoping” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M06.03-C018-T09 · Uncovered-scope report:** List the “Resource scoping” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M06.03-C018-T10 · Limit evidence:** Publish the selected “Resource scoping” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M06.03-C019 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for resource scoping with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M06.03-C019-T01 · Event inventory:** List the “Resource scoping” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M06.03-C019-T02 · Diagnostic schema:** Define nonsecret fields for “Resource scoping” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M06.03-C019-T03 · Failure mapping:** Map each documented “Resource scoping” refusal or error to a diagnostic outcome; include “A tenant-scoped operator stops a different tenant's workload” and prohibit conversion into a success message.
- [ ] **UC-M06.03-C019-T04 · Emission path:** Add the “Resource scoping” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M06.03-C019-T05 · Redaction check:** Test “Resource scoping” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M06.03-C019-T06 · Output budget:** Set and exercise bounded “Resource scoping” message size, rate and retention compatible with “Scope rules and resource lookup cost”; define truncation behavior that preserves the final reason.
- [ ] **UC-M06.03-C019-T07 · Success/refusal fixtures:** Capture “Resource scoping” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M06.03-C019-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Resource scoping” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M06.03-C019-T09 · Operator review:** Read the “Resource scoping” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M06.03-C019-T10 · Diagnostic evidence:** Publish redacted “Resource scoping” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M06.03-C020 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for resource scoping; label unexecuted checks as untested.

- [ ] **UC-M06.03-C020-T01 · Evidence inventory:** List the “Resource scoping” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M06.03-C020-T02 · Artifact references:** Record the exact “Resource scoping” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M06.03-C020-T03 · Fixture references:** Attach the “Resource scoping” fixture IDs, input identities and oracle definition; preserve the source counterexample “A tenant-scoped operator stops a different tenant's workload” as a distinct evidence case.
- [ ] **UC-M06.03-C020-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Resource scoping”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M06.03-C020-T05 · Environment record:** Record the actual “Resource scoping” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M06.03-C020-T06 · Expected versus observed:** Pair every “Resource scoping” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M06.03-C020-T07 · Failure and limit records:** Attach “Resource scoping” change/failure and bounds evidence where required; include uncovered “Scope rules and resource lookup cost” and unresolved violations of “A permission for one resource does not authorize another”.
- [ ] **UC-M06.03-C020-T08 · Evidence hygiene:** Check the “Resource scoping” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M06.03-C020-T09 · Reproduction review:** Have the “Resource scoping” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M06.03-C020-T10 · Acceptance linkage:** Link the “Resource scoping” evidence to its parent and UC-M06.03 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 03. Deny-by-default evaluation

**Source delivery:** Require explicit permission for sensitive operations and unknown action types.

**Source invariant:** An unrecognized operation is not implicitly allowed.

**Source negative case:** A newly added command bypasses the permission table.

**Source bounded quantities:** Action types and authorization latency.

### UC-M06.03-C021 · Contract

**Original checklist item:** Specify deny-by-default evaluation inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M06.03-C021-T01 · Scope statement:** Draft the operation boundary for “Deny-by-default evaluation” within Least-privilege authorization; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M06.03-C021-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Deny-by-default evaluation”; record each producer, representation and missing-value meaning.
- [ ] **UC-M06.03-C021-T03 · Output inventory:** List the outputs of “Deny-by-default evaluation” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M06.03-C021-T04 · Field dictionary:** Create a field-and-term dictionary for “Deny-by-default evaluation”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M06.03-C021-T05 · Prerequisite contract:** Map “Deny-by-default evaluation” to the source component prerequisites (UC-M06.02); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M06.03-C021-T06 · Authority map:** Identify who may produce, change and consume “Deny-by-default evaluation”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M06.03-C021-T07 · Invariant clause:** Add a normative clause for “Deny-by-default evaluation” that preserves “An unrecognized operation is not implicitly allowed”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M06.03-C021-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Deny-by-default evaluation”; include the source counterexample “A newly added command bypasses the permission table” and the intended safe disposition.
- [ ] **UC-M06.03-C021-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Action types and authorization latency” in the “Deny-by-default evaluation” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M06.03-C021-T10 · Contract review:** Review the “Deny-by-default evaluation” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M06.03-C022 · Delivery

**Original checklist item:** Require explicit permission for sensitive operations and unknown action types.

- [ ] **UC-M06.03-C022-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Deny-by-default evaluation”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M06.03-C022-T02 · Change plan:** Break the source delivery for “Deny-by-default evaluation” into concrete edit targets and reviewable outputs; keep the UC-M06.03 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M06.03-C022-T03 · Core artifact:** Implement the smallest selected-profile change for “Deny-by-default evaluation” that realizes this source instruction: Require explicit permission for sensitive operations and unknown action types.
- [ ] **UC-M06.03-C022-T04 · Concrete realization:** Trace “Deny-by-default evaluation” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M06.03-C022-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Deny-by-default evaluation” needed to preserve “An unrecognized operation is not implicitly allowed”; record an enforcement gap where only a model exists.
- [ ] **UC-M06.03-C022-T06 · Dependency connection:** Connect the “Deny-by-default evaluation” implementation to all command/API entry points, resource scopes and privileged broker actions; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M06.03-C022-T07 · Resource behavior:** Account for “Action types and authorization latency” in “Deny-by-default evaluation”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M06.03-C022-T08 · Delivery check:** Run the smallest real “Deny-by-default evaluation” path and its adverse fixture “A newly added command bypasses the permission table”; retain actual output, state effects and final disposition.
- [ ] **UC-M06.03-C022-T09 · Patch review:** Review the “Deny-by-default evaluation” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M06.03-C022-T10 · Delivery handoff:** Publish the “Deny-by-default evaluation” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M06.03-C023 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: An unrecognized operation is not implicitly allowed. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M06.03-C023-T01 · Named property:** Create a stable property/check name under this parent for “Deny-by-default evaluation”; copy its required invariant exactly: “An unrecognized operation is not implicitly allowed”.
- [ ] **UC-M06.03-C023-T02 · Observable terms:** Define each term in the “Deny-by-default evaluation” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M06.03-C023-T03 · Precondition set:** List the preconditions under which “An unrecognized operation is not implicitly allowed” must hold for “Deny-by-default evaluation”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M06.03-C023-T04 · Transition coverage:** Map the “Deny-by-default evaluation” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M06.03-C023-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Deny-by-default evaluation”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M06.03-C023-T06 · Satisfying fixture:** Create a concrete “Deny-by-default evaluation” case that satisfies “An unrecognized operation is not implicitly allowed”; record its expected observation before running the assertion or review.
- [ ] **UC-M06.03-C023-T07 · Violating fixture:** Create the source counterexample “A newly added command bypasses the permission table” for “Deny-by-default evaluation”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M06.03-C023-T08 · Enforcement evidence:** Exercise the “Deny-by-default evaluation” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M06.03-C023-T09 · Regression linkage:** Link the “Deny-by-default evaluation” property to changes in all command/API entry points, resource scopes and privileged broker actions; record which dependency or contract changes require rerunning it.
- [ ] **UC-M06.03-C023-T10 · Property disposition:** Compare the satisfying and violating “Deny-by-default evaluation” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M06.03-C024 · Integration

**Original checklist item:** Integrate deny-by-default evaluation with all command/API entry points, resource scopes and privileged broker actions; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M06.03-C024-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Deny-by-default evaluation” across all command/API entry points, resource scopes and privileged broker actions; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M06.03-C024-T02 · Field mapping:** Map every “Deny-by-default evaluation” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M06.03-C024-T03 · Prerequisite identities:** Record the actual prerequisites for “Deny-by-default evaluation” (source dependency list: UC-M06.02); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M06.03-C024-T04 · Ownership agreement:** Specify who owns “Deny-by-default evaluation” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M06.03-C024-T05 · Handoff implementation:** Connect “Deny-by-default evaluation” through the mapped seam using the real adapter or explicit specification reference; preserve “An unrecognized operation is not implicitly allowed” across the handoff.
- [ ] **UC-M06.03-C024-T06 · Absent-input case:** Omit one required “Deny-by-default evaluation” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M06.03-C024-T07 · Stale-input case:** Supply an outdated “Deny-by-default evaluation” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M06.03-C024-T08 · Incompatible-input case:** Supply an incompatible “Deny-by-default evaluation” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M06.03-C024-T09 · Valid integration trace:** Run a valid “Deny-by-default evaluation” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M06.03-C024-T10 · Seam review:** Reconcile the “Deny-by-default evaluation” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M06.03-C025 · Valid-case test

**Original checklist item:** Run a valid-path fixture for deny-by-default evaluation; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M06.03-C025-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Deny-by-default evaluation” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M06.03-C025-T02 · Expected-result oracle:** Specify the “Deny-by-default evaluation” expected result independently of the implementation output; include the property “An unrecognized operation is not implicitly allowed” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M06.03-C025-T03 · Fixture material:** Create the concrete “Deny-by-default evaluation” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M06.03-C025-T04 · Target preparation:** Prepare the “Deny-by-default evaluation” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M06.03-C025-T05 · Initial-state record:** Record the initial “Deny-by-default evaluation” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M06.03-C025-T06 · Valid-path execution:** Execute the “Deny-by-default evaluation” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M06.03-C025-T07 · Outcome comparison:** Compare every declared “Deny-by-default evaluation” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M06.03-C025-T08 · State and bounds check:** Inspect the “Deny-by-default evaluation” ownership/state effects and actual use of “Action types and authorization latency”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M06.03-C025-T09 · Repeatability check:** Repeat the same “Deny-by-default evaluation” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M06.03-C025-T10 · Positive evidence:** Attach the “Deny-by-default evaluation” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M06.03-C026 · Negative test

**Original checklist item:** Negative case: A newly added command bypasses the permission table. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M06.03-C026-T01 · Adverse-case definition:** Create a test record for the exact “Deny-by-default evaluation” source counterexample: “A newly added command bypasses the permission table”; state which precondition or invariant it challenges.
- [ ] **UC-M06.03-C026-T02 · Safe fixture boundary:** Define the contained test boundary for “Deny-by-default evaluation”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M06.03-C026-T03 · Valid control:** Construct a valid “Deny-by-default evaluation” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M06.03-C026-T04 · Minimal adverse input:** Derive the “Deny-by-default evaluation” adverse fixture from the control with the smallest documented change needed to reproduce “A newly added command bypasses the permission table”; retain that change as reproducible data.
- [ ] **UC-M06.03-C026-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Deny-by-default evaluation”; require “An unrecognized operation is not implicitly allowed” and forbid a false-success verdict.
- [ ] **UC-M06.03-C026-T06 · Adverse execution:** Exercise the “Deny-by-default evaluation” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M06.03-C026-T07 · Effect inspection:** Inspect “Deny-by-default evaluation” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M06.03-C026-T08 · Refusal versus failure:** Confirm the “Deny-by-default evaluation” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M06.03-C026-T09 · Reset and retention:** Restore only the disposable “Deny-by-default evaluation” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M06.03-C026-T10 · Negative regression:** Register the “Deny-by-default evaluation” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M06.03-C027 · Change / failure test

**Original checklist item:** Exercise deny-by-default evaluation when an indirect option or newly added command attempts an action denied by the normal path; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M06.03-C027-T01 · Scenario record:** Write the “Deny-by-default evaluation” change/failure scenario exactly as supplied: an indirect option or newly added command attempts an action denied by the normal path; identify the property that must remain true: “An unrecognized operation is not implicitly allowed”.
- [ ] **UC-M06.03-C027-T02 · Baseline capture:** Create a known-valid “Deny-by-default evaluation” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M06.03-C027-T03 · Injection map:** Locate the “Deny-by-default evaluation” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M06.03-C027-T04 · Disposition oracle:** Define the legal intermediate and final “Deny-by-default evaluation” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M06.03-C027-T05 · Controlled trigger:** Introduce the controlled “Deny-by-default evaluation” scenario in the disposable fixture: an indirect option or newly added command attempts an action denied by the normal path; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M06.03-C027-T06 · Intermediate inspection:** Inspect the “Deny-by-default evaluation” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M06.03-C027-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Deny-by-default evaluation”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M06.03-C027-T08 · Stale-evidence cleanup:** Invalidate superseded “Deny-by-default evaluation” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M06.03-C027-T09 · Repeat and compare:** Repeat the selected “Deny-by-default evaluation” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M06.03-C027-T10 · Failure evidence:** Publish the “Deny-by-default evaluation” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M06.03-C028 · Bounds

**Original checklist item:** Choose, document and test limits for action types and authorization latency; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M06.03-C028-T01 · Quantity inventory:** Create a measurement inventory for “Deny-by-default evaluation”: “Action types and authorization latency”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M06.03-C028-T02 · Measurement method:** Choose how to observe each “Deny-by-default evaluation” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M06.03-C028-T03 · Budget decision:** Select justified resource and input limits for “Deny-by-default evaluation”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M06.03-C028-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Deny-by-default evaluation” cases for “Action types and authorization latency”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M06.03-C028-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Deny-by-default evaluation” limit; preserve “An unrecognized operation is not implicitly allowed”.
- [ ] **UC-M06.03-C028-T06 · Normal measurement:** Run or review the normal “Deny-by-default evaluation” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M06.03-C028-T07 · At-limit measurement:** Exercise the “Deny-by-default evaluation” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M06.03-C028-T08 · Over-limit measurement:** Exercise the “Deny-by-default evaluation” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M06.03-C028-T09 · Uncovered-scope report:** List the “Deny-by-default evaluation” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M06.03-C028-T10 · Limit evidence:** Publish the selected “Deny-by-default evaluation” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M06.03-C029 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for deny-by-default evaluation with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M06.03-C029-T01 · Event inventory:** List the “Deny-by-default evaluation” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M06.03-C029-T02 · Diagnostic schema:** Define nonsecret fields for “Deny-by-default evaluation” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M06.03-C029-T03 · Failure mapping:** Map each documented “Deny-by-default evaluation” refusal or error to a diagnostic outcome; include “A newly added command bypasses the permission table” and prohibit conversion into a success message.
- [ ] **UC-M06.03-C029-T04 · Emission path:** Add the “Deny-by-default evaluation” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M06.03-C029-T05 · Redaction check:** Test “Deny-by-default evaluation” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M06.03-C029-T06 · Output budget:** Set and exercise bounded “Deny-by-default evaluation” message size, rate and retention compatible with “Action types and authorization latency”; define truncation behavior that preserves the final reason.
- [ ] **UC-M06.03-C029-T07 · Success/refusal fixtures:** Capture “Deny-by-default evaluation” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M06.03-C029-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Deny-by-default evaluation” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M06.03-C029-T09 · Operator review:** Read the “Deny-by-default evaluation” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M06.03-C029-T10 · Diagnostic evidence:** Publish redacted “Deny-by-default evaluation” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M06.03-C030 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for deny-by-default evaluation; label unexecuted checks as untested.

- [ ] **UC-M06.03-C030-T01 · Evidence inventory:** List the “Deny-by-default evaluation” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M06.03-C030-T02 · Artifact references:** Record the exact “Deny-by-default evaluation” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M06.03-C030-T03 · Fixture references:** Attach the “Deny-by-default evaluation” fixture IDs, input identities and oracle definition; preserve the source counterexample “A newly added command bypasses the permission table” as a distinct evidence case.
- [ ] **UC-M06.03-C030-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Deny-by-default evaluation”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M06.03-C030-T05 · Environment record:** Record the actual “Deny-by-default evaluation” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M06.03-C030-T06 · Expected versus observed:** Pair every “Deny-by-default evaluation” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M06.03-C030-T07 · Failure and limit records:** Attach “Deny-by-default evaluation” change/failure and bounds evidence where required; include uncovered “Action types and authorization latency” and unresolved violations of “An unrecognized operation is not implicitly allowed”.
- [ ] **UC-M06.03-C030-T08 · Evidence hygiene:** Check the “Deny-by-default evaluation” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M06.03-C030-T09 · Reproduction review:** Have the “Deny-by-default evaluation” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M06.03-C030-T10 · Acceptance linkage:** Link the “Deny-by-default evaluation” evidence to its parent and UC-M06.03 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 04. Read-only profile

**Source delivery:** Implement a read-only operator profile with no mutating side effects.

**Source invariant:** Read access cannot escalate through optional flags or indirect operations.

**Source negative case:** A read command's repair option mutates a seal.

**Source bounded quantities:** Read-only commands and negative test count.

### UC-M06.03-C031 · Contract

**Original checklist item:** Specify read-only profile inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M06.03-C031-T01 · Scope statement:** Draft the operation boundary for “Read-only profile” within Least-privilege authorization; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M06.03-C031-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Read-only profile”; record each producer, representation and missing-value meaning.
- [ ] **UC-M06.03-C031-T03 · Output inventory:** List the outputs of “Read-only profile” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M06.03-C031-T04 · Field dictionary:** Create a field-and-term dictionary for “Read-only profile”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M06.03-C031-T05 · Prerequisite contract:** Map “Read-only profile” to the source component prerequisites (UC-M06.02); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M06.03-C031-T06 · Authority map:** Identify who may produce, change and consume “Read-only profile”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M06.03-C031-T07 · Invariant clause:** Add a normative clause for “Read-only profile” that preserves “Read access cannot escalate through optional flags or indirect operations”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M06.03-C031-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Read-only profile”; include the source counterexample “A read command's repair option mutates a seal” and the intended safe disposition.
- [ ] **UC-M06.03-C031-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Read-only commands and negative test count” in the “Read-only profile” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M06.03-C031-T10 · Contract review:** Review the “Read-only profile” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M06.03-C032 · Delivery

**Original checklist item:** Implement a read-only operator profile with no mutating side effects.

- [ ] **UC-M06.03-C032-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Read-only profile”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M06.03-C032-T02 · Change plan:** Break the source delivery for “Read-only profile” into concrete edit targets and reviewable outputs; keep the UC-M06.03 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M06.03-C032-T03 · Core artifact:** Implement the smallest selected-profile change for “Read-only profile” that realizes this source instruction: Implement a read-only operator profile with no mutating side effects.
- [ ] **UC-M06.03-C032-T04 · Concrete realization:** Trace “Read-only profile” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M06.03-C032-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Read-only profile” needed to preserve “Read access cannot escalate through optional flags or indirect operations”; record an enforcement gap where only a model exists.
- [ ] **UC-M06.03-C032-T06 · Dependency connection:** Connect the “Read-only profile” implementation to all command/API entry points, resource scopes and privileged broker actions; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M06.03-C032-T07 · Resource behavior:** Account for “Read-only commands and negative test count” in “Read-only profile”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M06.03-C032-T08 · Delivery check:** Run the smallest real “Read-only profile” path and its adverse fixture “A read command's repair option mutates a seal”; retain actual output, state effects and final disposition.
- [ ] **UC-M06.03-C032-T09 · Patch review:** Review the “Read-only profile” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M06.03-C032-T10 · Delivery handoff:** Publish the “Read-only profile” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M06.03-C033 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Read access cannot escalate through optional flags or indirect operations. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M06.03-C033-T01 · Named property:** Create a stable property/check name under this parent for “Read-only profile”; copy its required invariant exactly: “Read access cannot escalate through optional flags or indirect operations”.
- [ ] **UC-M06.03-C033-T02 · Observable terms:** Define each term in the “Read-only profile” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M06.03-C033-T03 · Precondition set:** List the preconditions under which “Read access cannot escalate through optional flags or indirect operations” must hold for “Read-only profile”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M06.03-C033-T04 · Transition coverage:** Map the “Read-only profile” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M06.03-C033-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Read-only profile”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M06.03-C033-T06 · Satisfying fixture:** Create a concrete “Read-only profile” case that satisfies “Read access cannot escalate through optional flags or indirect operations”; record its expected observation before running the assertion or review.
- [ ] **UC-M06.03-C033-T07 · Violating fixture:** Create the source counterexample “A read command's repair option mutates a seal” for “Read-only profile”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M06.03-C033-T08 · Enforcement evidence:** Exercise the “Read-only profile” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M06.03-C033-T09 · Regression linkage:** Link the “Read-only profile” property to changes in all command/API entry points, resource scopes and privileged broker actions; record which dependency or contract changes require rerunning it.
- [ ] **UC-M06.03-C033-T10 · Property disposition:** Compare the satisfying and violating “Read-only profile” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M06.03-C034 · Integration

**Original checklist item:** Integrate read-only profile with all command/API entry points, resource scopes and privileged broker actions; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M06.03-C034-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Read-only profile” across all command/API entry points, resource scopes and privileged broker actions; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M06.03-C034-T02 · Field mapping:** Map every “Read-only profile” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M06.03-C034-T03 · Prerequisite identities:** Record the actual prerequisites for “Read-only profile” (source dependency list: UC-M06.02); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M06.03-C034-T04 · Ownership agreement:** Specify who owns “Read-only profile” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M06.03-C034-T05 · Handoff implementation:** Connect “Read-only profile” through the mapped seam using the real adapter or explicit specification reference; preserve “Read access cannot escalate through optional flags or indirect operations” across the handoff.
- [ ] **UC-M06.03-C034-T06 · Absent-input case:** Omit one required “Read-only profile” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M06.03-C034-T07 · Stale-input case:** Supply an outdated “Read-only profile” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M06.03-C034-T08 · Incompatible-input case:** Supply an incompatible “Read-only profile” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M06.03-C034-T09 · Valid integration trace:** Run a valid “Read-only profile” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M06.03-C034-T10 · Seam review:** Reconcile the “Read-only profile” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M06.03-C035 · Valid-case test

**Original checklist item:** Run a valid-path fixture for read-only profile; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M06.03-C035-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Read-only profile” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M06.03-C035-T02 · Expected-result oracle:** Specify the “Read-only profile” expected result independently of the implementation output; include the property “Read access cannot escalate through optional flags or indirect operations” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M06.03-C035-T03 · Fixture material:** Create the concrete “Read-only profile” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M06.03-C035-T04 · Target preparation:** Prepare the “Read-only profile” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M06.03-C035-T05 · Initial-state record:** Record the initial “Read-only profile” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M06.03-C035-T06 · Valid-path execution:** Execute the “Read-only profile” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M06.03-C035-T07 · Outcome comparison:** Compare every declared “Read-only profile” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M06.03-C035-T08 · State and bounds check:** Inspect the “Read-only profile” ownership/state effects and actual use of “Read-only commands and negative test count”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M06.03-C035-T09 · Repeatability check:** Repeat the same “Read-only profile” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M06.03-C035-T10 · Positive evidence:** Attach the “Read-only profile” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M06.03-C036 · Negative test

**Original checklist item:** Negative case: A read command's repair option mutates a seal. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M06.03-C036-T01 · Adverse-case definition:** Create a test record for the exact “Read-only profile” source counterexample: “A read command's repair option mutates a seal”; state which precondition or invariant it challenges.
- [ ] **UC-M06.03-C036-T02 · Safe fixture boundary:** Define the contained test boundary for “Read-only profile”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M06.03-C036-T03 · Valid control:** Construct a valid “Read-only profile” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M06.03-C036-T04 · Minimal adverse input:** Derive the “Read-only profile” adverse fixture from the control with the smallest documented change needed to reproduce “A read command's repair option mutates a seal”; retain that change as reproducible data.
- [ ] **UC-M06.03-C036-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Read-only profile”; require “Read access cannot escalate through optional flags or indirect operations” and forbid a false-success verdict.
- [ ] **UC-M06.03-C036-T06 · Adverse execution:** Exercise the “Read-only profile” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M06.03-C036-T07 · Effect inspection:** Inspect “Read-only profile” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M06.03-C036-T08 · Refusal versus failure:** Confirm the “Read-only profile” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M06.03-C036-T09 · Reset and retention:** Restore only the disposable “Read-only profile” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M06.03-C036-T10 · Negative regression:** Register the “Read-only profile” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M06.03-C037 · Change / failure test

**Original checklist item:** Exercise read-only profile when an indirect option or newly added command attempts an action denied by the normal path; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M06.03-C037-T01 · Scenario record:** Write the “Read-only profile” change/failure scenario exactly as supplied: an indirect option or newly added command attempts an action denied by the normal path; identify the property that must remain true: “Read access cannot escalate through optional flags or indirect operations”.
- [ ] **UC-M06.03-C037-T02 · Baseline capture:** Create a known-valid “Read-only profile” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M06.03-C037-T03 · Injection map:** Locate the “Read-only profile” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M06.03-C037-T04 · Disposition oracle:** Define the legal intermediate and final “Read-only profile” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M06.03-C037-T05 · Controlled trigger:** Introduce the controlled “Read-only profile” scenario in the disposable fixture: an indirect option or newly added command attempts an action denied by the normal path; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M06.03-C037-T06 · Intermediate inspection:** Inspect the “Read-only profile” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M06.03-C037-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Read-only profile”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M06.03-C037-T08 · Stale-evidence cleanup:** Invalidate superseded “Read-only profile” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M06.03-C037-T09 · Repeat and compare:** Repeat the selected “Read-only profile” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M06.03-C037-T10 · Failure evidence:** Publish the “Read-only profile” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M06.03-C038 · Bounds

**Original checklist item:** Choose, document and test limits for read-only commands and negative test count; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M06.03-C038-T01 · Quantity inventory:** Create a measurement inventory for “Read-only profile”: “Read-only commands and negative test count”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M06.03-C038-T02 · Measurement method:** Choose how to observe each “Read-only profile” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M06.03-C038-T03 · Budget decision:** Select justified resource and input limits for “Read-only profile”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M06.03-C038-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Read-only profile” cases for “Read-only commands and negative test count”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M06.03-C038-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Read-only profile” limit; preserve “Read access cannot escalate through optional flags or indirect operations”.
- [ ] **UC-M06.03-C038-T06 · Normal measurement:** Run or review the normal “Read-only profile” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M06.03-C038-T07 · At-limit measurement:** Exercise the “Read-only profile” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M06.03-C038-T08 · Over-limit measurement:** Exercise the “Read-only profile” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M06.03-C038-T09 · Uncovered-scope report:** List the “Read-only profile” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M06.03-C038-T10 · Limit evidence:** Publish the selected “Read-only profile” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M06.03-C039 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for read-only profile with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M06.03-C039-T01 · Event inventory:** List the “Read-only profile” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M06.03-C039-T02 · Diagnostic schema:** Define nonsecret fields for “Read-only profile” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M06.03-C039-T03 · Failure mapping:** Map each documented “Read-only profile” refusal or error to a diagnostic outcome; include “A read command's repair option mutates a seal” and prohibit conversion into a success message.
- [ ] **UC-M06.03-C039-T04 · Emission path:** Add the “Read-only profile” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M06.03-C039-T05 · Redaction check:** Test “Read-only profile” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M06.03-C039-T06 · Output budget:** Set and exercise bounded “Read-only profile” message size, rate and retention compatible with “Read-only commands and negative test count”; define truncation behavior that preserves the final reason.
- [ ] **UC-M06.03-C039-T07 · Success/refusal fixtures:** Capture “Read-only profile” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M06.03-C039-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Read-only profile” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M06.03-C039-T09 · Operator review:** Read the “Read-only profile” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M06.03-C039-T10 · Diagnostic evidence:** Publish redacted “Read-only profile” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M06.03-C040 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for read-only profile; label unexecuted checks as untested.

- [ ] **UC-M06.03-C040-T01 · Evidence inventory:** List the “Read-only profile” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M06.03-C040-T02 · Artifact references:** Record the exact “Read-only profile” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M06.03-C040-T03 · Fixture references:** Attach the “Read-only profile” fixture IDs, input identities and oracle definition; preserve the source counterexample “A read command's repair option mutates a seal” as a distinct evidence case.
- [ ] **UC-M06.03-C040-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Read-only profile”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M06.03-C040-T05 · Environment record:** Record the actual “Read-only profile” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M06.03-C040-T06 · Expected versus observed:** Pair every “Read-only profile” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M06.03-C040-T07 · Failure and limit records:** Attach “Read-only profile” change/failure and bounds evidence where required; include uncovered “Read-only commands and negative test count” and unresolved violations of “Read access cannot escalate through optional flags or indirect operations”.
- [ ] **UC-M06.03-C040-T08 · Evidence hygiene:** Check the “Read-only profile” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M06.03-C040-T09 · Reproduction review:** Have the “Read-only profile” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M06.03-C040-T10 · Acceptance linkage:** Link the “Read-only profile” evidence to its parent and UC-M06.03 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 05. Build versus execution separation

**Source delivery:** Keep permission to compile separate from permission to execute produced artifacts.

**Source invariant:** Build authority alone does not authorize guest launch.

**Source negative case:** A build completion callback launches a guest automatically.

**Source bounded quantities:** Build hooks and executable handoff points.

### UC-M06.03-C041 · Contract

**Original checklist item:** Specify build versus execution separation inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M06.03-C041-T01 · Scope statement:** Draft the operation boundary for “Build versus execution separation” within Least-privilege authorization; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M06.03-C041-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Build versus execution separation”; record each producer, representation and missing-value meaning.
- [ ] **UC-M06.03-C041-T03 · Output inventory:** List the outputs of “Build versus execution separation” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M06.03-C041-T04 · Field dictionary:** Create a field-and-term dictionary for “Build versus execution separation”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M06.03-C041-T05 · Prerequisite contract:** Map “Build versus execution separation” to the source component prerequisites (UC-M06.02); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M06.03-C041-T06 · Authority map:** Identify who may produce, change and consume “Build versus execution separation”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M06.03-C041-T07 · Invariant clause:** Add a normative clause for “Build versus execution separation” that preserves “Build authority alone does not authorize guest launch”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M06.03-C041-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Build versus execution separation”; include the source counterexample “A build completion callback launches a guest automatically” and the intended safe disposition.
- [ ] **UC-M06.03-C041-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Build hooks and executable handoff points” in the “Build versus execution separation” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M06.03-C041-T10 · Contract review:** Review the “Build versus execution separation” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M06.03-C042 · Delivery

**Original checklist item:** Keep permission to compile separate from permission to execute produced artifacts.

- [ ] **UC-M06.03-C042-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Build versus execution separation”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M06.03-C042-T02 · Change plan:** Break the source delivery for “Build versus execution separation” into concrete edit targets and reviewable outputs; keep the UC-M06.03 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M06.03-C042-T03 · Core artifact:** Implement the smallest selected-profile change for “Build versus execution separation” that realizes this source instruction: Keep permission to compile separate from permission to execute produced artifacts.
- [ ] **UC-M06.03-C042-T04 · Concrete realization:** Trace “Build versus execution separation” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M06.03-C042-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Build versus execution separation” needed to preserve “Build authority alone does not authorize guest launch”; record an enforcement gap where only a model exists.
- [ ] **UC-M06.03-C042-T06 · Dependency connection:** Connect the “Build versus execution separation” implementation to all command/API entry points, resource scopes and privileged broker actions; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M06.03-C042-T07 · Resource behavior:** Account for “Build hooks and executable handoff points” in “Build versus execution separation”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M06.03-C042-T08 · Delivery check:** Run the smallest real “Build versus execution separation” path and its adverse fixture “A build completion callback launches a guest automatically”; retain actual output, state effects and final disposition.
- [ ] **UC-M06.03-C042-T09 · Patch review:** Review the “Build versus execution separation” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M06.03-C042-T10 · Delivery handoff:** Publish the “Build versus execution separation” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M06.03-C043 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Build authority alone does not authorize guest launch. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M06.03-C043-T01 · Named property:** Create a stable property/check name under this parent for “Build versus execution separation”; copy its required invariant exactly: “Build authority alone does not authorize guest launch”.
- [ ] **UC-M06.03-C043-T02 · Observable terms:** Define each term in the “Build versus execution separation” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M06.03-C043-T03 · Precondition set:** List the preconditions under which “Build authority alone does not authorize guest launch” must hold for “Build versus execution separation”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M06.03-C043-T04 · Transition coverage:** Map the “Build versus execution separation” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M06.03-C043-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Build versus execution separation”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M06.03-C043-T06 · Satisfying fixture:** Create a concrete “Build versus execution separation” case that satisfies “Build authority alone does not authorize guest launch”; record its expected observation before running the assertion or review.
- [ ] **UC-M06.03-C043-T07 · Violating fixture:** Create the source counterexample “A build completion callback launches a guest automatically” for “Build versus execution separation”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M06.03-C043-T08 · Enforcement evidence:** Exercise the “Build versus execution separation” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M06.03-C043-T09 · Regression linkage:** Link the “Build versus execution separation” property to changes in all command/API entry points, resource scopes and privileged broker actions; record which dependency or contract changes require rerunning it.
- [ ] **UC-M06.03-C043-T10 · Property disposition:** Compare the satisfying and violating “Build versus execution separation” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M06.03-C044 · Integration

**Original checklist item:** Integrate build versus execution separation with all command/API entry points, resource scopes and privileged broker actions; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M06.03-C044-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Build versus execution separation” across all command/API entry points, resource scopes and privileged broker actions; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M06.03-C044-T02 · Field mapping:** Map every “Build versus execution separation” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M06.03-C044-T03 · Prerequisite identities:** Record the actual prerequisites for “Build versus execution separation” (source dependency list: UC-M06.02); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M06.03-C044-T04 · Ownership agreement:** Specify who owns “Build versus execution separation” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M06.03-C044-T05 · Handoff implementation:** Connect “Build versus execution separation” through the mapped seam using the real adapter or explicit specification reference; preserve “Build authority alone does not authorize guest launch” across the handoff.
- [ ] **UC-M06.03-C044-T06 · Absent-input case:** Omit one required “Build versus execution separation” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M06.03-C044-T07 · Stale-input case:** Supply an outdated “Build versus execution separation” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M06.03-C044-T08 · Incompatible-input case:** Supply an incompatible “Build versus execution separation” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M06.03-C044-T09 · Valid integration trace:** Run a valid “Build versus execution separation” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M06.03-C044-T10 · Seam review:** Reconcile the “Build versus execution separation” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M06.03-C045 · Valid-case test

**Original checklist item:** Run a valid-path fixture for build versus execution separation; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M06.03-C045-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Build versus execution separation” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M06.03-C045-T02 · Expected-result oracle:** Specify the “Build versus execution separation” expected result independently of the implementation output; include the property “Build authority alone does not authorize guest launch” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M06.03-C045-T03 · Fixture material:** Create the concrete “Build versus execution separation” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M06.03-C045-T04 · Target preparation:** Prepare the “Build versus execution separation” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M06.03-C045-T05 · Initial-state record:** Record the initial “Build versus execution separation” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M06.03-C045-T06 · Valid-path execution:** Execute the “Build versus execution separation” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M06.03-C045-T07 · Outcome comparison:** Compare every declared “Build versus execution separation” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M06.03-C045-T08 · State and bounds check:** Inspect the “Build versus execution separation” ownership/state effects and actual use of “Build hooks and executable handoff points”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M06.03-C045-T09 · Repeatability check:** Repeat the same “Build versus execution separation” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M06.03-C045-T10 · Positive evidence:** Attach the “Build versus execution separation” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M06.03-C046 · Negative test

**Original checklist item:** Negative case: A build completion callback launches a guest automatically. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M06.03-C046-T01 · Adverse-case definition:** Create a test record for the exact “Build versus execution separation” source counterexample: “A build completion callback launches a guest automatically”; state which precondition or invariant it challenges.
- [ ] **UC-M06.03-C046-T02 · Safe fixture boundary:** Define the contained test boundary for “Build versus execution separation”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M06.03-C046-T03 · Valid control:** Construct a valid “Build versus execution separation” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M06.03-C046-T04 · Minimal adverse input:** Derive the “Build versus execution separation” adverse fixture from the control with the smallest documented change needed to reproduce “A build completion callback launches a guest automatically”; retain that change as reproducible data.
- [ ] **UC-M06.03-C046-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Build versus execution separation”; require “Build authority alone does not authorize guest launch” and forbid a false-success verdict.
- [ ] **UC-M06.03-C046-T06 · Adverse execution:** Exercise the “Build versus execution separation” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M06.03-C046-T07 · Effect inspection:** Inspect “Build versus execution separation” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M06.03-C046-T08 · Refusal versus failure:** Confirm the “Build versus execution separation” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M06.03-C046-T09 · Reset and retention:** Restore only the disposable “Build versus execution separation” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M06.03-C046-T10 · Negative regression:** Register the “Build versus execution separation” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M06.03-C047 · Change / failure test

**Original checklist item:** Exercise build versus execution separation when an indirect option or newly added command attempts an action denied by the normal path; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M06.03-C047-T01 · Scenario record:** Write the “Build versus execution separation” change/failure scenario exactly as supplied: an indirect option or newly added command attempts an action denied by the normal path; identify the property that must remain true: “Build authority alone does not authorize guest launch”.
- [ ] **UC-M06.03-C047-T02 · Baseline capture:** Create a known-valid “Build versus execution separation” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M06.03-C047-T03 · Injection map:** Locate the “Build versus execution separation” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M06.03-C047-T04 · Disposition oracle:** Define the legal intermediate and final “Build versus execution separation” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M06.03-C047-T05 · Controlled trigger:** Introduce the controlled “Build versus execution separation” scenario in the disposable fixture: an indirect option or newly added command attempts an action denied by the normal path; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M06.03-C047-T06 · Intermediate inspection:** Inspect the “Build versus execution separation” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M06.03-C047-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Build versus execution separation”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M06.03-C047-T08 · Stale-evidence cleanup:** Invalidate superseded “Build versus execution separation” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M06.03-C047-T09 · Repeat and compare:** Repeat the selected “Build versus execution separation” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M06.03-C047-T10 · Failure evidence:** Publish the “Build versus execution separation” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M06.03-C048 · Bounds

**Original checklist item:** Choose, document and test limits for build hooks and executable handoff points; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M06.03-C048-T01 · Quantity inventory:** Create a measurement inventory for “Build versus execution separation”: “Build hooks and executable handoff points”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M06.03-C048-T02 · Measurement method:** Choose how to observe each “Build versus execution separation” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M06.03-C048-T03 · Budget decision:** Select justified resource and input limits for “Build versus execution separation”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M06.03-C048-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Build versus execution separation” cases for “Build hooks and executable handoff points”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M06.03-C048-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Build versus execution separation” limit; preserve “Build authority alone does not authorize guest launch”.
- [ ] **UC-M06.03-C048-T06 · Normal measurement:** Run or review the normal “Build versus execution separation” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M06.03-C048-T07 · At-limit measurement:** Exercise the “Build versus execution separation” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M06.03-C048-T08 · Over-limit measurement:** Exercise the “Build versus execution separation” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M06.03-C048-T09 · Uncovered-scope report:** List the “Build versus execution separation” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M06.03-C048-T10 · Limit evidence:** Publish the selected “Build versus execution separation” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M06.03-C049 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for build versus execution separation with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M06.03-C049-T01 · Event inventory:** List the “Build versus execution separation” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M06.03-C049-T02 · Diagnostic schema:** Define nonsecret fields for “Build versus execution separation” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M06.03-C049-T03 · Failure mapping:** Map each documented “Build versus execution separation” refusal or error to a diagnostic outcome; include “A build completion callback launches a guest automatically” and prohibit conversion into a success message.
- [ ] **UC-M06.03-C049-T04 · Emission path:** Add the “Build versus execution separation” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M06.03-C049-T05 · Redaction check:** Test “Build versus execution separation” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M06.03-C049-T06 · Output budget:** Set and exercise bounded “Build versus execution separation” message size, rate and retention compatible with “Build hooks and executable handoff points”; define truncation behavior that preserves the final reason.
- [ ] **UC-M06.03-C049-T07 · Success/refusal fixtures:** Capture “Build versus execution separation” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M06.03-C049-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Build versus execution separation” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M06.03-C049-T09 · Operator review:** Read the “Build versus execution separation” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M06.03-C049-T10 · Diagnostic evidence:** Publish redacted “Build versus execution separation” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M06.03-C050 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for build versus execution separation; label unexecuted checks as untested.

- [ ] **UC-M06.03-C050-T01 · Evidence inventory:** List the “Build versus execution separation” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M06.03-C050-T02 · Artifact references:** Record the exact “Build versus execution separation” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M06.03-C050-T03 · Fixture references:** Attach the “Build versus execution separation” fixture IDs, input identities and oracle definition; preserve the source counterexample “A build completion callback launches a guest automatically” as a distinct evidence case.
- [ ] **UC-M06.03-C050-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Build versus execution separation”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M06.03-C050-T05 · Environment record:** Record the actual “Build versus execution separation” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M06.03-C050-T06 · Expected versus observed:** Pair every “Build versus execution separation” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M06.03-C050-T07 · Failure and limit records:** Attach “Build versus execution separation” change/failure and bounds evidence where required; include uncovered “Build hooks and executable handoff points” and unresolved violations of “Build authority alone does not authorize guest launch”.
- [ ] **UC-M06.03-C050-T08 · Evidence hygiene:** Check the “Build versus execution separation” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M06.03-C050-T09 · Reproduction review:** Have the “Build versus execution separation” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M06.03-C050-T10 · Acceptance linkage:** Link the “Build versus execution separation” evidence to its parent and UC-M06.03 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 06. Seal versus signing authority

**Source delivery:** Separate local byte sealing from authority to sign or approve a release.

**Source invariant:** A local seal cannot substitute for signing authorization.

**Source negative case:** A user with seal permission enrolls a release key.

**Source bounded quantities:** Authority roles and signing request count.

### UC-M06.03-C051 · Contract

**Original checklist item:** Specify seal versus signing authority inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M06.03-C051-T01 · Scope statement:** Draft the operation boundary for “Seal versus signing authority” within Least-privilege authorization; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M06.03-C051-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Seal versus signing authority”; record each producer, representation and missing-value meaning.
- [ ] **UC-M06.03-C051-T03 · Output inventory:** List the outputs of “Seal versus signing authority” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M06.03-C051-T04 · Field dictionary:** Create a field-and-term dictionary for “Seal versus signing authority”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M06.03-C051-T05 · Prerequisite contract:** Map “Seal versus signing authority” to the source component prerequisites (UC-M06.02); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M06.03-C051-T06 · Authority map:** Identify who may produce, change and consume “Seal versus signing authority”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M06.03-C051-T07 · Invariant clause:** Add a normative clause for “Seal versus signing authority” that preserves “A local seal cannot substitute for signing authorization”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M06.03-C051-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Seal versus signing authority”; include the source counterexample “A user with seal permission enrolls a release key” and the intended safe disposition.
- [ ] **UC-M06.03-C051-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Authority roles and signing request count” in the “Seal versus signing authority” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M06.03-C051-T10 · Contract review:** Review the “Seal versus signing authority” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M06.03-C052 · Delivery

**Original checklist item:** Separate local byte sealing from authority to sign or approve a release.

- [ ] **UC-M06.03-C052-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Seal versus signing authority”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M06.03-C052-T02 · Change plan:** Break the source delivery for “Seal versus signing authority” into concrete edit targets and reviewable outputs; keep the UC-M06.03 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M06.03-C052-T03 · Core artifact:** Implement the smallest selected-profile change for “Seal versus signing authority” that realizes this source instruction: Separate local byte sealing from authority to sign or approve a release.
- [ ] **UC-M06.03-C052-T04 · Concrete realization:** Trace “Seal versus signing authority” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M06.03-C052-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Seal versus signing authority” needed to preserve “A local seal cannot substitute for signing authorization”; record an enforcement gap where only a model exists.
- [ ] **UC-M06.03-C052-T06 · Dependency connection:** Connect the “Seal versus signing authority” implementation to all command/API entry points, resource scopes and privileged broker actions; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M06.03-C052-T07 · Resource behavior:** Account for “Authority roles and signing request count” in “Seal versus signing authority”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M06.03-C052-T08 · Delivery check:** Run the smallest real “Seal versus signing authority” path and its adverse fixture “A user with seal permission enrolls a release key”; retain actual output, state effects and final disposition.
- [ ] **UC-M06.03-C052-T09 · Patch review:** Review the “Seal versus signing authority” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M06.03-C052-T10 · Delivery handoff:** Publish the “Seal versus signing authority” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M06.03-C053 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: A local seal cannot substitute for signing authorization. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M06.03-C053-T01 · Named property:** Create a stable property/check name under this parent for “Seal versus signing authority”; copy its required invariant exactly: “A local seal cannot substitute for signing authorization”.
- [ ] **UC-M06.03-C053-T02 · Observable terms:** Define each term in the “Seal versus signing authority” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M06.03-C053-T03 · Precondition set:** List the preconditions under which “A local seal cannot substitute for signing authorization” must hold for “Seal versus signing authority”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M06.03-C053-T04 · Transition coverage:** Map the “Seal versus signing authority” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M06.03-C053-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Seal versus signing authority”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M06.03-C053-T06 · Satisfying fixture:** Create a concrete “Seal versus signing authority” case that satisfies “A local seal cannot substitute for signing authorization”; record its expected observation before running the assertion or review.
- [ ] **UC-M06.03-C053-T07 · Violating fixture:** Create the source counterexample “A user with seal permission enrolls a release key” for “Seal versus signing authority”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M06.03-C053-T08 · Enforcement evidence:** Exercise the “Seal versus signing authority” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M06.03-C053-T09 · Regression linkage:** Link the “Seal versus signing authority” property to changes in all command/API entry points, resource scopes and privileged broker actions; record which dependency or contract changes require rerunning it.
- [ ] **UC-M06.03-C053-T10 · Property disposition:** Compare the satisfying and violating “Seal versus signing authority” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M06.03-C054 · Integration

**Original checklist item:** Integrate seal versus signing authority with all command/API entry points, resource scopes and privileged broker actions; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M06.03-C054-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Seal versus signing authority” across all command/API entry points, resource scopes and privileged broker actions; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M06.03-C054-T02 · Field mapping:** Map every “Seal versus signing authority” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M06.03-C054-T03 · Prerequisite identities:** Record the actual prerequisites for “Seal versus signing authority” (source dependency list: UC-M06.02); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M06.03-C054-T04 · Ownership agreement:** Specify who owns “Seal versus signing authority” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M06.03-C054-T05 · Handoff implementation:** Connect “Seal versus signing authority” through the mapped seam using the real adapter or explicit specification reference; preserve “A local seal cannot substitute for signing authorization” across the handoff.
- [ ] **UC-M06.03-C054-T06 · Absent-input case:** Omit one required “Seal versus signing authority” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M06.03-C054-T07 · Stale-input case:** Supply an outdated “Seal versus signing authority” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M06.03-C054-T08 · Incompatible-input case:** Supply an incompatible “Seal versus signing authority” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M06.03-C054-T09 · Valid integration trace:** Run a valid “Seal versus signing authority” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M06.03-C054-T10 · Seam review:** Reconcile the “Seal versus signing authority” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M06.03-C055 · Valid-case test

**Original checklist item:** Run a valid-path fixture for seal versus signing authority; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M06.03-C055-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Seal versus signing authority” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M06.03-C055-T02 · Expected-result oracle:** Specify the “Seal versus signing authority” expected result independently of the implementation output; include the property “A local seal cannot substitute for signing authorization” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M06.03-C055-T03 · Fixture material:** Create the concrete “Seal versus signing authority” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M06.03-C055-T04 · Target preparation:** Prepare the “Seal versus signing authority” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M06.03-C055-T05 · Initial-state record:** Record the initial “Seal versus signing authority” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M06.03-C055-T06 · Valid-path execution:** Execute the “Seal versus signing authority” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M06.03-C055-T07 · Outcome comparison:** Compare every declared “Seal versus signing authority” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M06.03-C055-T08 · State and bounds check:** Inspect the “Seal versus signing authority” ownership/state effects and actual use of “Authority roles and signing request count”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M06.03-C055-T09 · Repeatability check:** Repeat the same “Seal versus signing authority” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M06.03-C055-T10 · Positive evidence:** Attach the “Seal versus signing authority” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M06.03-C056 · Negative test

**Original checklist item:** Negative case: A user with seal permission enrolls a release key. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M06.03-C056-T01 · Adverse-case definition:** Create a test record for the exact “Seal versus signing authority” source counterexample: “A user with seal permission enrolls a release key”; state which precondition or invariant it challenges.
- [ ] **UC-M06.03-C056-T02 · Safe fixture boundary:** Define the contained test boundary for “Seal versus signing authority”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M06.03-C056-T03 · Valid control:** Construct a valid “Seal versus signing authority” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M06.03-C056-T04 · Minimal adverse input:** Derive the “Seal versus signing authority” adverse fixture from the control with the smallest documented change needed to reproduce “A user with seal permission enrolls a release key”; retain that change as reproducible data.
- [ ] **UC-M06.03-C056-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Seal versus signing authority”; require “A local seal cannot substitute for signing authorization” and forbid a false-success verdict.
- [ ] **UC-M06.03-C056-T06 · Adverse execution:** Exercise the “Seal versus signing authority” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M06.03-C056-T07 · Effect inspection:** Inspect “Seal versus signing authority” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M06.03-C056-T08 · Refusal versus failure:** Confirm the “Seal versus signing authority” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M06.03-C056-T09 · Reset and retention:** Restore only the disposable “Seal versus signing authority” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M06.03-C056-T10 · Negative regression:** Register the “Seal versus signing authority” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M06.03-C057 · Change / failure test

**Original checklist item:** Exercise seal versus signing authority when an indirect option or newly added command attempts an action denied by the normal path; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M06.03-C057-T01 · Scenario record:** Write the “Seal versus signing authority” change/failure scenario exactly as supplied: an indirect option or newly added command attempts an action denied by the normal path; identify the property that must remain true: “A local seal cannot substitute for signing authorization”.
- [ ] **UC-M06.03-C057-T02 · Baseline capture:** Create a known-valid “Seal versus signing authority” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M06.03-C057-T03 · Injection map:** Locate the “Seal versus signing authority” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M06.03-C057-T04 · Disposition oracle:** Define the legal intermediate and final “Seal versus signing authority” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M06.03-C057-T05 · Controlled trigger:** Introduce the controlled “Seal versus signing authority” scenario in the disposable fixture: an indirect option or newly added command attempts an action denied by the normal path; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M06.03-C057-T06 · Intermediate inspection:** Inspect the “Seal versus signing authority” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M06.03-C057-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Seal versus signing authority”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M06.03-C057-T08 · Stale-evidence cleanup:** Invalidate superseded “Seal versus signing authority” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M06.03-C057-T09 · Repeat and compare:** Repeat the selected “Seal versus signing authority” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M06.03-C057-T10 · Failure evidence:** Publish the “Seal versus signing authority” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M06.03-C058 · Bounds

**Original checklist item:** Choose, document and test limits for authority roles and signing request count; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M06.03-C058-T01 · Quantity inventory:** Create a measurement inventory for “Seal versus signing authority”: “Authority roles and signing request count”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M06.03-C058-T02 · Measurement method:** Choose how to observe each “Seal versus signing authority” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M06.03-C058-T03 · Budget decision:** Select justified resource and input limits for “Seal versus signing authority”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M06.03-C058-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Seal versus signing authority” cases for “Authority roles and signing request count”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M06.03-C058-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Seal versus signing authority” limit; preserve “A local seal cannot substitute for signing authorization”.
- [ ] **UC-M06.03-C058-T06 · Normal measurement:** Run or review the normal “Seal versus signing authority” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M06.03-C058-T07 · At-limit measurement:** Exercise the “Seal versus signing authority” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M06.03-C058-T08 · Over-limit measurement:** Exercise the “Seal versus signing authority” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M06.03-C058-T09 · Uncovered-scope report:** List the “Seal versus signing authority” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M06.03-C058-T10 · Limit evidence:** Publish the selected “Seal versus signing authority” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M06.03-C059 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for seal versus signing authority with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M06.03-C059-T01 · Event inventory:** List the “Seal versus signing authority” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M06.03-C059-T02 · Diagnostic schema:** Define nonsecret fields for “Seal versus signing authority” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M06.03-C059-T03 · Failure mapping:** Map each documented “Seal versus signing authority” refusal or error to a diagnostic outcome; include “A user with seal permission enrolls a release key” and prohibit conversion into a success message.
- [ ] **UC-M06.03-C059-T04 · Emission path:** Add the “Seal versus signing authority” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M06.03-C059-T05 · Redaction check:** Test “Seal versus signing authority” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M06.03-C059-T06 · Output budget:** Set and exercise bounded “Seal versus signing authority” message size, rate and retention compatible with “Authority roles and signing request count”; define truncation behavior that preserves the final reason.
- [ ] **UC-M06.03-C059-T07 · Success/refusal fixtures:** Capture “Seal versus signing authority” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M06.03-C059-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Seal versus signing authority” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M06.03-C059-T09 · Operator review:** Read the “Seal versus signing authority” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M06.03-C059-T10 · Diagnostic evidence:** Publish redacted “Seal versus signing authority” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M06.03-C060 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for seal versus signing authority; label unexecuted checks as untested.

- [ ] **UC-M06.03-C060-T01 · Evidence inventory:** List the “Seal versus signing authority” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M06.03-C060-T02 · Artifact references:** Record the exact “Seal versus signing authority” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M06.03-C060-T03 · Fixture references:** Attach the “Seal versus signing authority” fixture IDs, input identities and oracle definition; preserve the source counterexample “A user with seal permission enrolls a release key” as a distinct evidence case.
- [ ] **UC-M06.03-C060-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Seal versus signing authority”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M06.03-C060-T05 · Environment record:** Record the actual “Seal versus signing authority” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M06.03-C060-T06 · Expected versus observed:** Pair every “Seal versus signing authority” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M06.03-C060-T07 · Failure and limit records:** Attach “Seal versus signing authority” change/failure and bounds evidence where required; include uncovered “Authority roles and signing request count” and unresolved violations of “A local seal cannot substitute for signing authorization”.
- [ ] **UC-M06.03-C060-T08 · Evidence hygiene:** Check the “Seal versus signing authority” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M06.03-C060-T09 · Reproduction review:** Have the “Seal versus signing authority” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M06.03-C060-T10 · Acceptance linkage:** Link the “Seal versus signing authority” evidence to its parent and UC-M06.03 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 07. Trust enrollment controls

**Source delivery:** Require explicit scoped permission for adding or changing trust anchors.

**Source invariant:** Execution permission cannot redefine admission trust.

**Source negative case:** A workload run option adds its embedded key as trusted.

**Source bounded quantities:** Enrollment actions and trust-root changes.

### UC-M06.03-C061 · Contract

**Original checklist item:** Specify trust enrollment controls inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M06.03-C061-T01 · Scope statement:** Draft the operation boundary for “Trust enrollment controls” within Least-privilege authorization; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M06.03-C061-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Trust enrollment controls”; record each producer, representation and missing-value meaning.
- [ ] **UC-M06.03-C061-T03 · Output inventory:** List the outputs of “Trust enrollment controls” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M06.03-C061-T04 · Field dictionary:** Create a field-and-term dictionary for “Trust enrollment controls”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M06.03-C061-T05 · Prerequisite contract:** Map “Trust enrollment controls” to the source component prerequisites (UC-M06.02); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M06.03-C061-T06 · Authority map:** Identify who may produce, change and consume “Trust enrollment controls”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M06.03-C061-T07 · Invariant clause:** Add a normative clause for “Trust enrollment controls” that preserves “Execution permission cannot redefine admission trust”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M06.03-C061-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Trust enrollment controls”; include the source counterexample “A workload run option adds its embedded key as trusted” and the intended safe disposition.
- [ ] **UC-M06.03-C061-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Enrollment actions and trust-root changes” in the “Trust enrollment controls” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M06.03-C061-T10 · Contract review:** Review the “Trust enrollment controls” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M06.03-C062 · Delivery

**Original checklist item:** Require explicit scoped permission for adding or changing trust anchors.

- [ ] **UC-M06.03-C062-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Trust enrollment controls”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M06.03-C062-T02 · Change plan:** Break the source delivery for “Trust enrollment controls” into concrete edit targets and reviewable outputs; keep the UC-M06.03 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M06.03-C062-T03 · Core artifact:** Implement the smallest selected-profile change for “Trust enrollment controls” that realizes this source instruction: Require explicit scoped permission for adding or changing trust anchors.
- [ ] **UC-M06.03-C062-T04 · Concrete realization:** Trace “Trust enrollment controls” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M06.03-C062-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Trust enrollment controls” needed to preserve “Execution permission cannot redefine admission trust”; record an enforcement gap where only a model exists.
- [ ] **UC-M06.03-C062-T06 · Dependency connection:** Connect the “Trust enrollment controls” implementation to all command/API entry points, resource scopes and privileged broker actions; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M06.03-C062-T07 · Resource behavior:** Account for “Enrollment actions and trust-root changes” in “Trust enrollment controls”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M06.03-C062-T08 · Delivery check:** Run the smallest real “Trust enrollment controls” path and its adverse fixture “A workload run option adds its embedded key as trusted”; retain actual output, state effects and final disposition.
- [ ] **UC-M06.03-C062-T09 · Patch review:** Review the “Trust enrollment controls” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M06.03-C062-T10 · Delivery handoff:** Publish the “Trust enrollment controls” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M06.03-C063 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Execution permission cannot redefine admission trust. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M06.03-C063-T01 · Named property:** Create a stable property/check name under this parent for “Trust enrollment controls”; copy its required invariant exactly: “Execution permission cannot redefine admission trust”.
- [ ] **UC-M06.03-C063-T02 · Observable terms:** Define each term in the “Trust enrollment controls” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M06.03-C063-T03 · Precondition set:** List the preconditions under which “Execution permission cannot redefine admission trust” must hold for “Trust enrollment controls”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M06.03-C063-T04 · Transition coverage:** Map the “Trust enrollment controls” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M06.03-C063-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Trust enrollment controls”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M06.03-C063-T06 · Satisfying fixture:** Create a concrete “Trust enrollment controls” case that satisfies “Execution permission cannot redefine admission trust”; record its expected observation before running the assertion or review.
- [ ] **UC-M06.03-C063-T07 · Violating fixture:** Create the source counterexample “A workload run option adds its embedded key as trusted” for “Trust enrollment controls”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M06.03-C063-T08 · Enforcement evidence:** Exercise the “Trust enrollment controls” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M06.03-C063-T09 · Regression linkage:** Link the “Trust enrollment controls” property to changes in all command/API entry points, resource scopes and privileged broker actions; record which dependency or contract changes require rerunning it.
- [ ] **UC-M06.03-C063-T10 · Property disposition:** Compare the satisfying and violating “Trust enrollment controls” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M06.03-C064 · Integration

**Original checklist item:** Integrate trust enrollment controls with all command/API entry points, resource scopes and privileged broker actions; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M06.03-C064-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Trust enrollment controls” across all command/API entry points, resource scopes and privileged broker actions; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M06.03-C064-T02 · Field mapping:** Map every “Trust enrollment controls” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M06.03-C064-T03 · Prerequisite identities:** Record the actual prerequisites for “Trust enrollment controls” (source dependency list: UC-M06.02); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M06.03-C064-T04 · Ownership agreement:** Specify who owns “Trust enrollment controls” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M06.03-C064-T05 · Handoff implementation:** Connect “Trust enrollment controls” through the mapped seam using the real adapter or explicit specification reference; preserve “Execution permission cannot redefine admission trust” across the handoff.
- [ ] **UC-M06.03-C064-T06 · Absent-input case:** Omit one required “Trust enrollment controls” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M06.03-C064-T07 · Stale-input case:** Supply an outdated “Trust enrollment controls” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M06.03-C064-T08 · Incompatible-input case:** Supply an incompatible “Trust enrollment controls” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M06.03-C064-T09 · Valid integration trace:** Run a valid “Trust enrollment controls” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M06.03-C064-T10 · Seam review:** Reconcile the “Trust enrollment controls” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M06.03-C065 · Valid-case test

**Original checklist item:** Run a valid-path fixture for trust enrollment controls; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M06.03-C065-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Trust enrollment controls” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M06.03-C065-T02 · Expected-result oracle:** Specify the “Trust enrollment controls” expected result independently of the implementation output; include the property “Execution permission cannot redefine admission trust” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M06.03-C065-T03 · Fixture material:** Create the concrete “Trust enrollment controls” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M06.03-C065-T04 · Target preparation:** Prepare the “Trust enrollment controls” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M06.03-C065-T05 · Initial-state record:** Record the initial “Trust enrollment controls” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M06.03-C065-T06 · Valid-path execution:** Execute the “Trust enrollment controls” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M06.03-C065-T07 · Outcome comparison:** Compare every declared “Trust enrollment controls” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M06.03-C065-T08 · State and bounds check:** Inspect the “Trust enrollment controls” ownership/state effects and actual use of “Enrollment actions and trust-root changes”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M06.03-C065-T09 · Repeatability check:** Repeat the same “Trust enrollment controls” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M06.03-C065-T10 · Positive evidence:** Attach the “Trust enrollment controls” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M06.03-C066 · Negative test

**Original checklist item:** Negative case: A workload run option adds its embedded key as trusted. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M06.03-C066-T01 · Adverse-case definition:** Create a test record for the exact “Trust enrollment controls” source counterexample: “A workload run option adds its embedded key as trusted”; state which precondition or invariant it challenges.
- [ ] **UC-M06.03-C066-T02 · Safe fixture boundary:** Define the contained test boundary for “Trust enrollment controls”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M06.03-C066-T03 · Valid control:** Construct a valid “Trust enrollment controls” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M06.03-C066-T04 · Minimal adverse input:** Derive the “Trust enrollment controls” adverse fixture from the control with the smallest documented change needed to reproduce “A workload run option adds its embedded key as trusted”; retain that change as reproducible data.
- [ ] **UC-M06.03-C066-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Trust enrollment controls”; require “Execution permission cannot redefine admission trust” and forbid a false-success verdict.
- [ ] **UC-M06.03-C066-T06 · Adverse execution:** Exercise the “Trust enrollment controls” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M06.03-C066-T07 · Effect inspection:** Inspect “Trust enrollment controls” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M06.03-C066-T08 · Refusal versus failure:** Confirm the “Trust enrollment controls” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M06.03-C066-T09 · Reset and retention:** Restore only the disposable “Trust enrollment controls” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M06.03-C066-T10 · Negative regression:** Register the “Trust enrollment controls” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M06.03-C067 · Change / failure test

**Original checklist item:** Exercise trust enrollment controls when an indirect option or newly added command attempts an action denied by the normal path; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M06.03-C067-T01 · Scenario record:** Write the “Trust enrollment controls” change/failure scenario exactly as supplied: an indirect option or newly added command attempts an action denied by the normal path; identify the property that must remain true: “Execution permission cannot redefine admission trust”.
- [ ] **UC-M06.03-C067-T02 · Baseline capture:** Create a known-valid “Trust enrollment controls” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M06.03-C067-T03 · Injection map:** Locate the “Trust enrollment controls” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M06.03-C067-T04 · Disposition oracle:** Define the legal intermediate and final “Trust enrollment controls” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M06.03-C067-T05 · Controlled trigger:** Introduce the controlled “Trust enrollment controls” scenario in the disposable fixture: an indirect option or newly added command attempts an action denied by the normal path; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M06.03-C067-T06 · Intermediate inspection:** Inspect the “Trust enrollment controls” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M06.03-C067-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Trust enrollment controls”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M06.03-C067-T08 · Stale-evidence cleanup:** Invalidate superseded “Trust enrollment controls” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M06.03-C067-T09 · Repeat and compare:** Repeat the selected “Trust enrollment controls” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M06.03-C067-T10 · Failure evidence:** Publish the “Trust enrollment controls” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M06.03-C068 · Bounds

**Original checklist item:** Choose, document and test limits for enrollment actions and trust-root changes; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M06.03-C068-T01 · Quantity inventory:** Create a measurement inventory for “Trust enrollment controls”: “Enrollment actions and trust-root changes”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M06.03-C068-T02 · Measurement method:** Choose how to observe each “Trust enrollment controls” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M06.03-C068-T03 · Budget decision:** Select justified resource and input limits for “Trust enrollment controls”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M06.03-C068-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Trust enrollment controls” cases for “Enrollment actions and trust-root changes”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M06.03-C068-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Trust enrollment controls” limit; preserve “Execution permission cannot redefine admission trust”.
- [ ] **UC-M06.03-C068-T06 · Normal measurement:** Run or review the normal “Trust enrollment controls” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M06.03-C068-T07 · At-limit measurement:** Exercise the “Trust enrollment controls” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M06.03-C068-T08 · Over-limit measurement:** Exercise the “Trust enrollment controls” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M06.03-C068-T09 · Uncovered-scope report:** List the “Trust enrollment controls” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M06.03-C068-T10 · Limit evidence:** Publish the selected “Trust enrollment controls” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M06.03-C069 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for trust enrollment controls with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M06.03-C069-T01 · Event inventory:** List the “Trust enrollment controls” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M06.03-C069-T02 · Diagnostic schema:** Define nonsecret fields for “Trust enrollment controls” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M06.03-C069-T03 · Failure mapping:** Map each documented “Trust enrollment controls” refusal or error to a diagnostic outcome; include “A workload run option adds its embedded key as trusted” and prohibit conversion into a success message.
- [ ] **UC-M06.03-C069-T04 · Emission path:** Add the “Trust enrollment controls” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M06.03-C069-T05 · Redaction check:** Test “Trust enrollment controls” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M06.03-C069-T06 · Output budget:** Set and exercise bounded “Trust enrollment controls” message size, rate and retention compatible with “Enrollment actions and trust-root changes”; define truncation behavior that preserves the final reason.
- [ ] **UC-M06.03-C069-T07 · Success/refusal fixtures:** Capture “Trust enrollment controls” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M06.03-C069-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Trust enrollment controls” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M06.03-C069-T09 · Operator review:** Read the “Trust enrollment controls” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M06.03-C069-T10 · Diagnostic evidence:** Publish redacted “Trust enrollment controls” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M06.03-C070 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for trust enrollment controls; label unexecuted checks as untested.

- [ ] **UC-M06.03-C070-T01 · Evidence inventory:** List the “Trust enrollment controls” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M06.03-C070-T02 · Artifact references:** Record the exact “Trust enrollment controls” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M06.03-C070-T03 · Fixture references:** Attach the “Trust enrollment controls” fixture IDs, input identities and oracle definition; preserve the source counterexample “A workload run option adds its embedded key as trusted” as a distinct evidence case.
- [ ] **UC-M06.03-C070-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Trust enrollment controls”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M06.03-C070-T05 · Environment record:** Record the actual “Trust enrollment controls” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M06.03-C070-T06 · Expected versus observed:** Pair every “Trust enrollment controls” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M06.03-C070-T07 · Failure and limit records:** Attach “Trust enrollment controls” change/failure and bounds evidence where required; include uncovered “Enrollment actions and trust-root changes” and unresolved violations of “Execution permission cannot redefine admission trust”.
- [ ] **UC-M06.03-C070-T08 · Evidence hygiene:** Check the “Trust enrollment controls” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M06.03-C070-T09 · Reproduction review:** Have the “Trust enrollment controls” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M06.03-C070-T10 · Acceptance linkage:** Link the “Trust enrollment controls” evidence to its parent and UC-M06.03 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 08. Destructive action guards

**Source delivery:** Require target identity and appropriate authority for unload, abandon and similar changes.

**Source invariant:** A destructive action is scoped to the authorized current target.

**Source negative case:** A stale display name directs unload at a replacement workload.

**Source bounded quantities:** Destructive operations and confirmation metadata.

### UC-M06.03-C071 · Contract

**Original checklist item:** Specify destructive action guards inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M06.03-C071-T01 · Scope statement:** Draft the operation boundary for “Destructive action guards” within Least-privilege authorization; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M06.03-C071-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Destructive action guards”; record each producer, representation and missing-value meaning.
- [ ] **UC-M06.03-C071-T03 · Output inventory:** List the outputs of “Destructive action guards” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M06.03-C071-T04 · Field dictionary:** Create a field-and-term dictionary for “Destructive action guards”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M06.03-C071-T05 · Prerequisite contract:** Map “Destructive action guards” to the source component prerequisites (UC-M06.02); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M06.03-C071-T06 · Authority map:** Identify who may produce, change and consume “Destructive action guards”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M06.03-C071-T07 · Invariant clause:** Add a normative clause for “Destructive action guards” that preserves “A destructive action is scoped to the authorized current target”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M06.03-C071-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Destructive action guards”; include the source counterexample “A stale display name directs unload at a replacement workload” and the intended safe disposition.
- [ ] **UC-M06.03-C071-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Destructive operations and confirmation metadata” in the “Destructive action guards” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M06.03-C071-T10 · Contract review:** Review the “Destructive action guards” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M06.03-C072 · Delivery

**Original checklist item:** Require target identity and appropriate authority for unload, abandon and similar changes.

- [ ] **UC-M06.03-C072-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Destructive action guards”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M06.03-C072-T02 · Change plan:** Break the source delivery for “Destructive action guards” into concrete edit targets and reviewable outputs; keep the UC-M06.03 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M06.03-C072-T03 · Core artifact:** Implement the smallest selected-profile change for “Destructive action guards” that realizes this source instruction: Require target identity and appropriate authority for unload, abandon and similar changes.
- [ ] **UC-M06.03-C072-T04 · Concrete realization:** Trace “Destructive action guards” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M06.03-C072-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Destructive action guards” needed to preserve “A destructive action is scoped to the authorized current target”; record an enforcement gap where only a model exists.
- [ ] **UC-M06.03-C072-T06 · Dependency connection:** Connect the “Destructive action guards” implementation to all command/API entry points, resource scopes and privileged broker actions; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M06.03-C072-T07 · Resource behavior:** Account for “Destructive operations and confirmation metadata” in “Destructive action guards”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M06.03-C072-T08 · Delivery check:** Run the smallest real “Destructive action guards” path and its adverse fixture “A stale display name directs unload at a replacement workload”; retain actual output, state effects and final disposition.
- [ ] **UC-M06.03-C072-T09 · Patch review:** Review the “Destructive action guards” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M06.03-C072-T10 · Delivery handoff:** Publish the “Destructive action guards” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M06.03-C073 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: A destructive action is scoped to the authorized current target. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M06.03-C073-T01 · Named property:** Create a stable property/check name under this parent for “Destructive action guards”; copy its required invariant exactly: “A destructive action is scoped to the authorized current target”.
- [ ] **UC-M06.03-C073-T02 · Observable terms:** Define each term in the “Destructive action guards” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M06.03-C073-T03 · Precondition set:** List the preconditions under which “A destructive action is scoped to the authorized current target” must hold for “Destructive action guards”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M06.03-C073-T04 · Transition coverage:** Map the “Destructive action guards” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M06.03-C073-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Destructive action guards”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M06.03-C073-T06 · Satisfying fixture:** Create a concrete “Destructive action guards” case that satisfies “A destructive action is scoped to the authorized current target”; record its expected observation before running the assertion or review.
- [ ] **UC-M06.03-C073-T07 · Violating fixture:** Create the source counterexample “A stale display name directs unload at a replacement workload” for “Destructive action guards”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M06.03-C073-T08 · Enforcement evidence:** Exercise the “Destructive action guards” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M06.03-C073-T09 · Regression linkage:** Link the “Destructive action guards” property to changes in all command/API entry points, resource scopes and privileged broker actions; record which dependency or contract changes require rerunning it.
- [ ] **UC-M06.03-C073-T10 · Property disposition:** Compare the satisfying and violating “Destructive action guards” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M06.03-C074 · Integration

**Original checklist item:** Integrate destructive action guards with all command/API entry points, resource scopes and privileged broker actions; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M06.03-C074-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Destructive action guards” across all command/API entry points, resource scopes and privileged broker actions; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M06.03-C074-T02 · Field mapping:** Map every “Destructive action guards” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M06.03-C074-T03 · Prerequisite identities:** Record the actual prerequisites for “Destructive action guards” (source dependency list: UC-M06.02); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M06.03-C074-T04 · Ownership agreement:** Specify who owns “Destructive action guards” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M06.03-C074-T05 · Handoff implementation:** Connect “Destructive action guards” through the mapped seam using the real adapter or explicit specification reference; preserve “A destructive action is scoped to the authorized current target” across the handoff.
- [ ] **UC-M06.03-C074-T06 · Absent-input case:** Omit one required “Destructive action guards” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M06.03-C074-T07 · Stale-input case:** Supply an outdated “Destructive action guards” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M06.03-C074-T08 · Incompatible-input case:** Supply an incompatible “Destructive action guards” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M06.03-C074-T09 · Valid integration trace:** Run a valid “Destructive action guards” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M06.03-C074-T10 · Seam review:** Reconcile the “Destructive action guards” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M06.03-C075 · Valid-case test

**Original checklist item:** Run a valid-path fixture for destructive action guards; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M06.03-C075-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Destructive action guards” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M06.03-C075-T02 · Expected-result oracle:** Specify the “Destructive action guards” expected result independently of the implementation output; include the property “A destructive action is scoped to the authorized current target” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M06.03-C075-T03 · Fixture material:** Create the concrete “Destructive action guards” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M06.03-C075-T04 · Target preparation:** Prepare the “Destructive action guards” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M06.03-C075-T05 · Initial-state record:** Record the initial “Destructive action guards” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M06.03-C075-T06 · Valid-path execution:** Execute the “Destructive action guards” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M06.03-C075-T07 · Outcome comparison:** Compare every declared “Destructive action guards” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M06.03-C075-T08 · State and bounds check:** Inspect the “Destructive action guards” ownership/state effects and actual use of “Destructive operations and confirmation metadata”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M06.03-C075-T09 · Repeatability check:** Repeat the same “Destructive action guards” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M06.03-C075-T10 · Positive evidence:** Attach the “Destructive action guards” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M06.03-C076 · Negative test

**Original checklist item:** Negative case: A stale display name directs unload at a replacement workload. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M06.03-C076-T01 · Adverse-case definition:** Create a test record for the exact “Destructive action guards” source counterexample: “A stale display name directs unload at a replacement workload”; state which precondition or invariant it challenges.
- [ ] **UC-M06.03-C076-T02 · Safe fixture boundary:** Define the contained test boundary for “Destructive action guards”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M06.03-C076-T03 · Valid control:** Construct a valid “Destructive action guards” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M06.03-C076-T04 · Minimal adverse input:** Derive the “Destructive action guards” adverse fixture from the control with the smallest documented change needed to reproduce “A stale display name directs unload at a replacement workload”; retain that change as reproducible data.
- [ ] **UC-M06.03-C076-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Destructive action guards”; require “A destructive action is scoped to the authorized current target” and forbid a false-success verdict.
- [ ] **UC-M06.03-C076-T06 · Adverse execution:** Exercise the “Destructive action guards” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M06.03-C076-T07 · Effect inspection:** Inspect “Destructive action guards” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M06.03-C076-T08 · Refusal versus failure:** Confirm the “Destructive action guards” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M06.03-C076-T09 · Reset and retention:** Restore only the disposable “Destructive action guards” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M06.03-C076-T10 · Negative regression:** Register the “Destructive action guards” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M06.03-C077 · Change / failure test

**Original checklist item:** Exercise destructive action guards when an indirect option or newly added command attempts an action denied by the normal path; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M06.03-C077-T01 · Scenario record:** Write the “Destructive action guards” change/failure scenario exactly as supplied: an indirect option or newly added command attempts an action denied by the normal path; identify the property that must remain true: “A destructive action is scoped to the authorized current target”.
- [ ] **UC-M06.03-C077-T02 · Baseline capture:** Create a known-valid “Destructive action guards” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M06.03-C077-T03 · Injection map:** Locate the “Destructive action guards” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M06.03-C077-T04 · Disposition oracle:** Define the legal intermediate and final “Destructive action guards” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M06.03-C077-T05 · Controlled trigger:** Introduce the controlled “Destructive action guards” scenario in the disposable fixture: an indirect option or newly added command attempts an action denied by the normal path; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M06.03-C077-T06 · Intermediate inspection:** Inspect the “Destructive action guards” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M06.03-C077-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Destructive action guards”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M06.03-C077-T08 · Stale-evidence cleanup:** Invalidate superseded “Destructive action guards” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M06.03-C077-T09 · Repeat and compare:** Repeat the selected “Destructive action guards” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M06.03-C077-T10 · Failure evidence:** Publish the “Destructive action guards” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M06.03-C078 · Bounds

**Original checklist item:** Choose, document and test limits for destructive operations and confirmation metadata; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M06.03-C078-T01 · Quantity inventory:** Create a measurement inventory for “Destructive action guards”: “Destructive operations and confirmation metadata”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M06.03-C078-T02 · Measurement method:** Choose how to observe each “Destructive action guards” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M06.03-C078-T03 · Budget decision:** Select justified resource and input limits for “Destructive action guards”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M06.03-C078-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Destructive action guards” cases for “Destructive operations and confirmation metadata”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M06.03-C078-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Destructive action guards” limit; preserve “A destructive action is scoped to the authorized current target”.
- [ ] **UC-M06.03-C078-T06 · Normal measurement:** Run or review the normal “Destructive action guards” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M06.03-C078-T07 · At-limit measurement:** Exercise the “Destructive action guards” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M06.03-C078-T08 · Over-limit measurement:** Exercise the “Destructive action guards” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M06.03-C078-T09 · Uncovered-scope report:** List the “Destructive action guards” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M06.03-C078-T10 · Limit evidence:** Publish the selected “Destructive action guards” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M06.03-C079 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for destructive action guards with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M06.03-C079-T01 · Event inventory:** List the “Destructive action guards” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M06.03-C079-T02 · Diagnostic schema:** Define nonsecret fields for “Destructive action guards” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M06.03-C079-T03 · Failure mapping:** Map each documented “Destructive action guards” refusal or error to a diagnostic outcome; include “A stale display name directs unload at a replacement workload” and prohibit conversion into a success message.
- [ ] **UC-M06.03-C079-T04 · Emission path:** Add the “Destructive action guards” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M06.03-C079-T05 · Redaction check:** Test “Destructive action guards” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M06.03-C079-T06 · Output budget:** Set and exercise bounded “Destructive action guards” message size, rate and retention compatible with “Destructive operations and confirmation metadata”; define truncation behavior that preserves the final reason.
- [ ] **UC-M06.03-C079-T07 · Success/refusal fixtures:** Capture “Destructive action guards” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M06.03-C079-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Destructive action guards” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M06.03-C079-T09 · Operator review:** Read the “Destructive action guards” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M06.03-C079-T10 · Diagnostic evidence:** Publish redacted “Destructive action guards” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M06.03-C080 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for destructive action guards; label unexecuted checks as untested.

- [ ] **UC-M06.03-C080-T01 · Evidence inventory:** List the “Destructive action guards” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M06.03-C080-T02 · Artifact references:** Record the exact “Destructive action guards” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M06.03-C080-T03 · Fixture references:** Attach the “Destructive action guards” fixture IDs, input identities and oracle definition; preserve the source counterexample “A stale display name directs unload at a replacement workload” as a distinct evidence case.
- [ ] **UC-M06.03-C080-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Destructive action guards”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M06.03-C080-T05 · Environment record:** Record the actual “Destructive action guards” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M06.03-C080-T06 · Expected versus observed:** Pair every “Destructive action guards” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M06.03-C080-T07 · Failure and limit records:** Attach “Destructive action guards” change/failure and bounds evidence where required; include uncovered “Destructive operations and confirmation metadata” and unresolved violations of “A destructive action is scoped to the authorized current target”.
- [ ] **UC-M06.03-C080-T08 · Evidence hygiene:** Check the “Destructive action guards” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M06.03-C080-T09 · Reproduction review:** Have the “Destructive action guards” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M06.03-C080-T10 · Acceptance linkage:** Link the “Destructive action guards” evidence to its parent and UC-M06.03 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 09. Indirect-path coverage

**Source delivery:** Review API aliases, UI actions, recovery tools and broker calls for equivalent checks.

**Source invariant:** Indirect entry points cannot bypass the same permission decision.

**Source negative case:** A recovery command performs an action denied by the normal API.

**Source bounded quantities:** Entry points and authorization coverage.

### UC-M06.03-C081 · Contract

**Original checklist item:** Specify indirect-path coverage inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M06.03-C081-T01 · Scope statement:** Draft the operation boundary for “Indirect-path coverage” within Least-privilege authorization; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M06.03-C081-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Indirect-path coverage”; record each producer, representation and missing-value meaning.
- [ ] **UC-M06.03-C081-T03 · Output inventory:** List the outputs of “Indirect-path coverage” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M06.03-C081-T04 · Field dictionary:** Create a field-and-term dictionary for “Indirect-path coverage”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M06.03-C081-T05 · Prerequisite contract:** Map “Indirect-path coverage” to the source component prerequisites (UC-M06.02); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M06.03-C081-T06 · Authority map:** Identify who may produce, change and consume “Indirect-path coverage”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M06.03-C081-T07 · Invariant clause:** Add a normative clause for “Indirect-path coverage” that preserves “Indirect entry points cannot bypass the same permission decision”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M06.03-C081-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Indirect-path coverage”; include the source counterexample “A recovery command performs an action denied by the normal API” and the intended safe disposition.
- [ ] **UC-M06.03-C081-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Entry points and authorization coverage” in the “Indirect-path coverage” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M06.03-C081-T10 · Contract review:** Review the “Indirect-path coverage” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M06.03-C082 · Delivery

**Original checklist item:** Review API aliases, UI actions, recovery tools and broker calls for equivalent checks.

- [ ] **UC-M06.03-C082-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Indirect-path coverage”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M06.03-C082-T02 · Change plan:** Break the source delivery for “Indirect-path coverage” into concrete edit targets and reviewable outputs; keep the UC-M06.03 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M06.03-C082-T03 · Core artifact:** Implement the smallest selected-profile change for “Indirect-path coverage” that realizes this source instruction: Review API aliases, UI actions, recovery tools and broker calls for equivalent checks.
- [ ] **UC-M06.03-C082-T04 · Concrete realization:** Trace “Indirect-path coverage” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M06.03-C082-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Indirect-path coverage” needed to preserve “Indirect entry points cannot bypass the same permission decision”; record an enforcement gap where only a model exists.
- [ ] **UC-M06.03-C082-T06 · Dependency connection:** Connect the “Indirect-path coverage” implementation to all command/API entry points, resource scopes and privileged broker actions; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M06.03-C082-T07 · Resource behavior:** Account for “Entry points and authorization coverage” in “Indirect-path coverage”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M06.03-C082-T08 · Delivery check:** Run the smallest real “Indirect-path coverage” path and its adverse fixture “A recovery command performs an action denied by the normal API”; retain actual output, state effects and final disposition.
- [ ] **UC-M06.03-C082-T09 · Patch review:** Review the “Indirect-path coverage” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M06.03-C082-T10 · Delivery handoff:** Publish the “Indirect-path coverage” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M06.03-C083 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Indirect entry points cannot bypass the same permission decision. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M06.03-C083-T01 · Named property:** Create a stable property/check name under this parent for “Indirect-path coverage”; copy its required invariant exactly: “Indirect entry points cannot bypass the same permission decision”.
- [ ] **UC-M06.03-C083-T02 · Observable terms:** Define each term in the “Indirect-path coverage” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M06.03-C083-T03 · Precondition set:** List the preconditions under which “Indirect entry points cannot bypass the same permission decision” must hold for “Indirect-path coverage”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M06.03-C083-T04 · Transition coverage:** Map the “Indirect-path coverage” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M06.03-C083-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Indirect-path coverage”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M06.03-C083-T06 · Satisfying fixture:** Create a concrete “Indirect-path coverage” case that satisfies “Indirect entry points cannot bypass the same permission decision”; record its expected observation before running the assertion or review.
- [ ] **UC-M06.03-C083-T07 · Violating fixture:** Create the source counterexample “A recovery command performs an action denied by the normal API” for “Indirect-path coverage”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M06.03-C083-T08 · Enforcement evidence:** Exercise the “Indirect-path coverage” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M06.03-C083-T09 · Regression linkage:** Link the “Indirect-path coverage” property to changes in all command/API entry points, resource scopes and privileged broker actions; record which dependency or contract changes require rerunning it.
- [ ] **UC-M06.03-C083-T10 · Property disposition:** Compare the satisfying and violating “Indirect-path coverage” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M06.03-C084 · Integration

**Original checklist item:** Integrate indirect-path coverage with all command/API entry points, resource scopes and privileged broker actions; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M06.03-C084-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Indirect-path coverage” across all command/API entry points, resource scopes and privileged broker actions; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M06.03-C084-T02 · Field mapping:** Map every “Indirect-path coverage” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M06.03-C084-T03 · Prerequisite identities:** Record the actual prerequisites for “Indirect-path coverage” (source dependency list: UC-M06.02); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M06.03-C084-T04 · Ownership agreement:** Specify who owns “Indirect-path coverage” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M06.03-C084-T05 · Handoff implementation:** Connect “Indirect-path coverage” through the mapped seam using the real adapter or explicit specification reference; preserve “Indirect entry points cannot bypass the same permission decision” across the handoff.
- [ ] **UC-M06.03-C084-T06 · Absent-input case:** Omit one required “Indirect-path coverage” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M06.03-C084-T07 · Stale-input case:** Supply an outdated “Indirect-path coverage” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M06.03-C084-T08 · Incompatible-input case:** Supply an incompatible “Indirect-path coverage” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M06.03-C084-T09 · Valid integration trace:** Run a valid “Indirect-path coverage” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M06.03-C084-T10 · Seam review:** Reconcile the “Indirect-path coverage” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M06.03-C085 · Valid-case test

**Original checklist item:** Run a valid-path fixture for indirect-path coverage; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M06.03-C085-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Indirect-path coverage” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M06.03-C085-T02 · Expected-result oracle:** Specify the “Indirect-path coverage” expected result independently of the implementation output; include the property “Indirect entry points cannot bypass the same permission decision” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M06.03-C085-T03 · Fixture material:** Create the concrete “Indirect-path coverage” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M06.03-C085-T04 · Target preparation:** Prepare the “Indirect-path coverage” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M06.03-C085-T05 · Initial-state record:** Record the initial “Indirect-path coverage” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M06.03-C085-T06 · Valid-path execution:** Execute the “Indirect-path coverage” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M06.03-C085-T07 · Outcome comparison:** Compare every declared “Indirect-path coverage” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M06.03-C085-T08 · State and bounds check:** Inspect the “Indirect-path coverage” ownership/state effects and actual use of “Entry points and authorization coverage”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M06.03-C085-T09 · Repeatability check:** Repeat the same “Indirect-path coverage” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M06.03-C085-T10 · Positive evidence:** Attach the “Indirect-path coverage” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M06.03-C086 · Negative test

**Original checklist item:** Negative case: A recovery command performs an action denied by the normal API. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M06.03-C086-T01 · Adverse-case definition:** Create a test record for the exact “Indirect-path coverage” source counterexample: “A recovery command performs an action denied by the normal API”; state which precondition or invariant it challenges.
- [ ] **UC-M06.03-C086-T02 · Safe fixture boundary:** Define the contained test boundary for “Indirect-path coverage”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M06.03-C086-T03 · Valid control:** Construct a valid “Indirect-path coverage” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M06.03-C086-T04 · Minimal adverse input:** Derive the “Indirect-path coverage” adverse fixture from the control with the smallest documented change needed to reproduce “A recovery command performs an action denied by the normal API”; retain that change as reproducible data.
- [ ] **UC-M06.03-C086-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Indirect-path coverage”; require “Indirect entry points cannot bypass the same permission decision” and forbid a false-success verdict.
- [ ] **UC-M06.03-C086-T06 · Adverse execution:** Exercise the “Indirect-path coverage” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M06.03-C086-T07 · Effect inspection:** Inspect “Indirect-path coverage” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M06.03-C086-T08 · Refusal versus failure:** Confirm the “Indirect-path coverage” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M06.03-C086-T09 · Reset and retention:** Restore only the disposable “Indirect-path coverage” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M06.03-C086-T10 · Negative regression:** Register the “Indirect-path coverage” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M06.03-C087 · Change / failure test

**Original checklist item:** Exercise indirect-path coverage when an indirect option or newly added command attempts an action denied by the normal path; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M06.03-C087-T01 · Scenario record:** Write the “Indirect-path coverage” change/failure scenario exactly as supplied: an indirect option or newly added command attempts an action denied by the normal path; identify the property that must remain true: “Indirect entry points cannot bypass the same permission decision”.
- [ ] **UC-M06.03-C087-T02 · Baseline capture:** Create a known-valid “Indirect-path coverage” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M06.03-C087-T03 · Injection map:** Locate the “Indirect-path coverage” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M06.03-C087-T04 · Disposition oracle:** Define the legal intermediate and final “Indirect-path coverage” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M06.03-C087-T05 · Controlled trigger:** Introduce the controlled “Indirect-path coverage” scenario in the disposable fixture: an indirect option or newly added command attempts an action denied by the normal path; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M06.03-C087-T06 · Intermediate inspection:** Inspect the “Indirect-path coverage” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M06.03-C087-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Indirect-path coverage”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M06.03-C087-T08 · Stale-evidence cleanup:** Invalidate superseded “Indirect-path coverage” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M06.03-C087-T09 · Repeat and compare:** Repeat the selected “Indirect-path coverage” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M06.03-C087-T10 · Failure evidence:** Publish the “Indirect-path coverage” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M06.03-C088 · Bounds

**Original checklist item:** Choose, document and test limits for entry points and authorization coverage; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M06.03-C088-T01 · Quantity inventory:** Create a measurement inventory for “Indirect-path coverage”: “Entry points and authorization coverage”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M06.03-C088-T02 · Measurement method:** Choose how to observe each “Indirect-path coverage” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M06.03-C088-T03 · Budget decision:** Select justified resource and input limits for “Indirect-path coverage”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M06.03-C088-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Indirect-path coverage” cases for “Entry points and authorization coverage”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M06.03-C088-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Indirect-path coverage” limit; preserve “Indirect entry points cannot bypass the same permission decision”.
- [ ] **UC-M06.03-C088-T06 · Normal measurement:** Run or review the normal “Indirect-path coverage” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M06.03-C088-T07 · At-limit measurement:** Exercise the “Indirect-path coverage” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M06.03-C088-T08 · Over-limit measurement:** Exercise the “Indirect-path coverage” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M06.03-C088-T09 · Uncovered-scope report:** List the “Indirect-path coverage” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M06.03-C088-T10 · Limit evidence:** Publish the selected “Indirect-path coverage” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M06.03-C089 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for indirect-path coverage with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M06.03-C089-T01 · Event inventory:** List the “Indirect-path coverage” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M06.03-C089-T02 · Diagnostic schema:** Define nonsecret fields for “Indirect-path coverage” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M06.03-C089-T03 · Failure mapping:** Map each documented “Indirect-path coverage” refusal or error to a diagnostic outcome; include “A recovery command performs an action denied by the normal API” and prohibit conversion into a success message.
- [ ] **UC-M06.03-C089-T04 · Emission path:** Add the “Indirect-path coverage” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M06.03-C089-T05 · Redaction check:** Test “Indirect-path coverage” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M06.03-C089-T06 · Output budget:** Set and exercise bounded “Indirect-path coverage” message size, rate and retention compatible with “Entry points and authorization coverage”; define truncation behavior that preserves the final reason.
- [ ] **UC-M06.03-C089-T07 · Success/refusal fixtures:** Capture “Indirect-path coverage” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M06.03-C089-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Indirect-path coverage” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M06.03-C089-T09 · Operator review:** Read the “Indirect-path coverage” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M06.03-C089-T10 · Diagnostic evidence:** Publish redacted “Indirect-path coverage” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M06.03-C090 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for indirect-path coverage; label unexecuted checks as untested.

- [ ] **UC-M06.03-C090-T01 · Evidence inventory:** List the “Indirect-path coverage” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M06.03-C090-T02 · Artifact references:** Record the exact “Indirect-path coverage” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M06.03-C090-T03 · Fixture references:** Attach the “Indirect-path coverage” fixture IDs, input identities and oracle definition; preserve the source counterexample “A recovery command performs an action denied by the normal API” as a distinct evidence case.
- [ ] **UC-M06.03-C090-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Indirect-path coverage”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M06.03-C090-T05 · Environment record:** Record the actual “Indirect-path coverage” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M06.03-C090-T06 · Expected versus observed:** Pair every “Indirect-path coverage” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M06.03-C090-T07 · Failure and limit records:** Attach “Indirect-path coverage” change/failure and bounds evidence where required; include uncovered “Entry points and authorization coverage” and unresolved violations of “Indirect entry points cannot bypass the same permission decision”.
- [ ] **UC-M06.03-C090-T08 · Evidence hygiene:** Check the “Indirect-path coverage” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M06.03-C090-T09 · Reproduction review:** Have the “Indirect-path coverage” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M06.03-C090-T10 · Acceptance linkage:** Link the “Indirect-path coverage” evidence to its parent and UC-M06.03 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 10. Authorization evidence

**Source delivery:** Record principal, action, scope and decision without exposing secrets.

**Source invariant:** A denied action leaves no unauthorized mutation.

**Source negative case:** An indirect command mutates state before its denial is recorded.

**Source bounded quantities:** Audit bytes and decision rate.

### UC-M06.03-C091 · Contract

**Original checklist item:** Specify authorization evidence inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M06.03-C091-T01 · Scope statement:** Draft the operation boundary for “Authorization evidence” within Least-privilege authorization; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M06.03-C091-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Authorization evidence”; record each producer, representation and missing-value meaning.
- [ ] **UC-M06.03-C091-T03 · Output inventory:** List the outputs of “Authorization evidence” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M06.03-C091-T04 · Field dictionary:** Create a field-and-term dictionary for “Authorization evidence”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M06.03-C091-T05 · Prerequisite contract:** Map “Authorization evidence” to the source component prerequisites (UC-M06.02); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M06.03-C091-T06 · Authority map:** Identify who may produce, change and consume “Authorization evidence”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M06.03-C091-T07 · Invariant clause:** Add a normative clause for “Authorization evidence” that preserves “A denied action leaves no unauthorized mutation”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M06.03-C091-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Authorization evidence”; include the source counterexample “An indirect command mutates state before its denial is recorded” and the intended safe disposition.
- [ ] **UC-M06.03-C091-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Audit bytes and decision rate” in the “Authorization evidence” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M06.03-C091-T10 · Contract review:** Review the “Authorization evidence” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M06.03-C092 · Delivery

**Original checklist item:** Record principal, action, scope and decision without exposing secrets.

- [ ] **UC-M06.03-C092-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Authorization evidence”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M06.03-C092-T02 · Change plan:** Break the source delivery for “Authorization evidence” into concrete edit targets and reviewable outputs; keep the UC-M06.03 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M06.03-C092-T03 · Core artifact:** Create the “Authorization evidence” model, schema or inventory that realizes this source instruction: Record principal, action, scope and decision without exposing secrets.
- [ ] **UC-M06.03-C092-T04 · Concrete realization:** Populate “Authorization evidence” with one concrete worked case; map every required entity or field to its source and flag any unmapped entry.
- [ ] **UC-M06.03-C092-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Authorization evidence” needed to preserve “A denied action leaves no unauthorized mutation”; record an enforcement gap where only a model exists.
- [ ] **UC-M06.03-C092-T06 · Dependency connection:** Connect the “Authorization evidence” implementation to all command/API entry points, resource scopes and privileged broker actions; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M06.03-C092-T07 · Resource behavior:** Account for “Audit bytes and decision rate” in “Authorization evidence”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M06.03-C092-T08 · Delivery check:** Run the smallest real “Authorization evidence” path and its adverse fixture “An indirect command mutates state before its denial is recorded”; retain actual output, state effects and final disposition.
- [ ] **UC-M06.03-C092-T09 · Patch review:** Review the “Authorization evidence” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M06.03-C092-T10 · Delivery handoff:** Publish the “Authorization evidence” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M06.03-C093 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: A denied action leaves no unauthorized mutation. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M06.03-C093-T01 · Named property:** Create a stable property/check name under this parent for “Authorization evidence”; copy its required invariant exactly: “A denied action leaves no unauthorized mutation”.
- [ ] **UC-M06.03-C093-T02 · Observable terms:** Define each term in the “Authorization evidence” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M06.03-C093-T03 · Precondition set:** List the preconditions under which “A denied action leaves no unauthorized mutation” must hold for “Authorization evidence”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M06.03-C093-T04 · Transition coverage:** Map the “Authorization evidence” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M06.03-C093-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Authorization evidence”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M06.03-C093-T06 · Satisfying fixture:** Create a concrete “Authorization evidence” case that satisfies “A denied action leaves no unauthorized mutation”; record its expected observation before running the assertion or review.
- [ ] **UC-M06.03-C093-T07 · Violating fixture:** Create the source counterexample “An indirect command mutates state before its denial is recorded” for “Authorization evidence”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M06.03-C093-T08 · Enforcement evidence:** Exercise the “Authorization evidence” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M06.03-C093-T09 · Regression linkage:** Link the “Authorization evidence” property to changes in all command/API entry points, resource scopes and privileged broker actions; record which dependency or contract changes require rerunning it.
- [ ] **UC-M06.03-C093-T10 · Property disposition:** Compare the satisfying and violating “Authorization evidence” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M06.03-C094 · Integration

**Original checklist item:** Integrate authorization evidence with all command/API entry points, resource scopes and privileged broker actions; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M06.03-C094-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Authorization evidence” across all command/API entry points, resource scopes and privileged broker actions; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M06.03-C094-T02 · Field mapping:** Map every “Authorization evidence” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M06.03-C094-T03 · Prerequisite identities:** Record the actual prerequisites for “Authorization evidence” (source dependency list: UC-M06.02); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M06.03-C094-T04 · Ownership agreement:** Specify who owns “Authorization evidence” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M06.03-C094-T05 · Handoff implementation:** Connect “Authorization evidence” through the mapped seam using the real adapter or explicit specification reference; preserve “A denied action leaves no unauthorized mutation” across the handoff.
- [ ] **UC-M06.03-C094-T06 · Absent-input case:** Omit one required “Authorization evidence” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M06.03-C094-T07 · Stale-input case:** Supply an outdated “Authorization evidence” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M06.03-C094-T08 · Incompatible-input case:** Supply an incompatible “Authorization evidence” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M06.03-C094-T09 · Valid integration trace:** Run a valid “Authorization evidence” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M06.03-C094-T10 · Seam review:** Reconcile the “Authorization evidence” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M06.03-C095 · Valid-case test

**Original checklist item:** Run a valid-path fixture for authorization evidence; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M06.03-C095-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Authorization evidence” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M06.03-C095-T02 · Expected-result oracle:** Specify the “Authorization evidence” expected result independently of the implementation output; include the property “A denied action leaves no unauthorized mutation” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M06.03-C095-T03 · Fixture material:** Create the concrete “Authorization evidence” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M06.03-C095-T04 · Target preparation:** Prepare the “Authorization evidence” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M06.03-C095-T05 · Initial-state record:** Record the initial “Authorization evidence” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M06.03-C095-T06 · Valid-path execution:** Execute the “Authorization evidence” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M06.03-C095-T07 · Outcome comparison:** Compare every declared “Authorization evidence” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M06.03-C095-T08 · State and bounds check:** Inspect the “Authorization evidence” ownership/state effects and actual use of “Audit bytes and decision rate”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M06.03-C095-T09 · Repeatability check:** Repeat the same “Authorization evidence” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M06.03-C095-T10 · Positive evidence:** Attach the “Authorization evidence” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M06.03-C096 · Negative test

**Original checklist item:** Negative case: An indirect command mutates state before its denial is recorded. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M06.03-C096-T01 · Adverse-case definition:** Create a test record for the exact “Authorization evidence” source counterexample: “An indirect command mutates state before its denial is recorded”; state which precondition or invariant it challenges.
- [ ] **UC-M06.03-C096-T02 · Safe fixture boundary:** Define the contained test boundary for “Authorization evidence”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M06.03-C096-T03 · Valid control:** Construct a valid “Authorization evidence” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M06.03-C096-T04 · Minimal adverse input:** Derive the “Authorization evidence” adverse fixture from the control with the smallest documented change needed to reproduce “An indirect command mutates state before its denial is recorded”; retain that change as reproducible data.
- [ ] **UC-M06.03-C096-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Authorization evidence”; require “A denied action leaves no unauthorized mutation” and forbid a false-success verdict.
- [ ] **UC-M06.03-C096-T06 · Adverse execution:** Exercise the “Authorization evidence” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M06.03-C096-T07 · Effect inspection:** Inspect “Authorization evidence” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M06.03-C096-T08 · Refusal versus failure:** Confirm the “Authorization evidence” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M06.03-C096-T09 · Reset and retention:** Restore only the disposable “Authorization evidence” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M06.03-C096-T10 · Negative regression:** Register the “Authorization evidence” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M06.03-C097 · Change / failure test

**Original checklist item:** Exercise authorization evidence when an indirect option or newly added command attempts an action denied by the normal path; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M06.03-C097-T01 · Scenario record:** Write the “Authorization evidence” change/failure scenario exactly as supplied: an indirect option or newly added command attempts an action denied by the normal path; identify the property that must remain true: “A denied action leaves no unauthorized mutation”.
- [ ] **UC-M06.03-C097-T02 · Baseline capture:** Create a known-valid “Authorization evidence” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M06.03-C097-T03 · Injection map:** Locate the “Authorization evidence” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M06.03-C097-T04 · Disposition oracle:** Define the legal intermediate and final “Authorization evidence” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M06.03-C097-T05 · Controlled trigger:** Introduce the controlled “Authorization evidence” scenario in the disposable fixture: an indirect option or newly added command attempts an action denied by the normal path; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M06.03-C097-T06 · Intermediate inspection:** Inspect the “Authorization evidence” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M06.03-C097-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Authorization evidence”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M06.03-C097-T08 · Stale-evidence cleanup:** Invalidate superseded “Authorization evidence” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M06.03-C097-T09 · Repeat and compare:** Repeat the selected “Authorization evidence” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M06.03-C097-T10 · Failure evidence:** Publish the “Authorization evidence” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M06.03-C098 · Bounds

**Original checklist item:** Choose, document and test limits for audit bytes and decision rate; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M06.03-C098-T01 · Quantity inventory:** Create a measurement inventory for “Authorization evidence”: “Audit bytes and decision rate”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M06.03-C098-T02 · Measurement method:** Choose how to observe each “Authorization evidence” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M06.03-C098-T03 · Budget decision:** Select justified resource and input limits for “Authorization evidence”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M06.03-C098-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Authorization evidence” cases for “Audit bytes and decision rate”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M06.03-C098-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Authorization evidence” limit; preserve “A denied action leaves no unauthorized mutation”.
- [ ] **UC-M06.03-C098-T06 · Normal measurement:** Run or review the normal “Authorization evidence” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M06.03-C098-T07 · At-limit measurement:** Exercise the “Authorization evidence” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M06.03-C098-T08 · Over-limit measurement:** Exercise the “Authorization evidence” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M06.03-C098-T09 · Uncovered-scope report:** List the “Authorization evidence” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M06.03-C098-T10 · Limit evidence:** Publish the selected “Authorization evidence” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M06.03-C099 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for authorization evidence with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M06.03-C099-T01 · Event inventory:** List the “Authorization evidence” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M06.03-C099-T02 · Diagnostic schema:** Define nonsecret fields for “Authorization evidence” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M06.03-C099-T03 · Failure mapping:** Map each documented “Authorization evidence” refusal or error to a diagnostic outcome; include “An indirect command mutates state before its denial is recorded” and prohibit conversion into a success message.
- [ ] **UC-M06.03-C099-T04 · Emission path:** Add the “Authorization evidence” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M06.03-C099-T05 · Redaction check:** Test “Authorization evidence” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M06.03-C099-T06 · Output budget:** Set and exercise bounded “Authorization evidence” message size, rate and retention compatible with “Audit bytes and decision rate”; define truncation behavior that preserves the final reason.
- [ ] **UC-M06.03-C099-T07 · Success/refusal fixtures:** Capture “Authorization evidence” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M06.03-C099-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Authorization evidence” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M06.03-C099-T09 · Operator review:** Read the “Authorization evidence” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M06.03-C099-T10 · Diagnostic evidence:** Publish redacted “Authorization evidence” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M06.03-C100 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for authorization evidence; label unexecuted checks as untested.

- [ ] **UC-M06.03-C100-T01 · Evidence inventory:** List the “Authorization evidence” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M06.03-C100-T02 · Artifact references:** Record the exact “Authorization evidence” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M06.03-C100-T03 · Fixture references:** Attach the “Authorization evidence” fixture IDs, input identities and oracle definition; preserve the source counterexample “An indirect command mutates state before its denial is recorded” as a distinct evidence case.
- [ ] **UC-M06.03-C100-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Authorization evidence”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M06.03-C100-T05 · Environment record:** Record the actual “Authorization evidence” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M06.03-C100-T06 · Expected versus observed:** Pair every “Authorization evidence” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M06.03-C100-T07 · Failure and limit records:** Attach “Authorization evidence” change/failure and bounds evidence where required; include uncovered “Audit bytes and decision rate” and unresolved violations of “A denied action leaves no unauthorized mutation”.
- [ ] **UC-M06.03-C100-T08 · Evidence hygiene:** Check the “Authorization evidence” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M06.03-C100-T09 · Reproduction review:** Have the “Authorization evidence” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M06.03-C100-T10 · Acceptance linkage:** Link the “Authorization evidence” evidence to its parent and UC-M06.03 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

