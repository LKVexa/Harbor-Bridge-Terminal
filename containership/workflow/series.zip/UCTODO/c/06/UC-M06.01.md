# UC-M06.01 — Machine-stable management API

**To-Do Pack 2.0.0 · Baseline UC-2.2.0 · 100 parent checks × 10 subtasks = 1,000 to-dos**

[Master index](../../INDEX.md) · [Workstream index](../../w/06.md)

| Field | Preserved source value |
|---|---|
| Workstream | 06. Control plane, identity and policy |
| Milestone | C |
| Priority | P1 |
| Source assessment | PARTIAL |
| Scope | core or selected profile |
| Dependencies | [UC-M01.02](../01/UC-M01.02.md), [UC-M05.04](../05/UC-M05.04.md) |
| Source checklist pack | 1.0.0 |
| Original reference labels | [S4], [S6]. |

## Original requirement

Provide versioned structured operations and errors; keep CLI presentation separate from machine contracts and long-running job IDs.

**Original acceptance criterion:** Contract tests exercise command/API parity and incompatible-version refusal without parsing human log text.

**Source trace:** Original checklist `UC100/c/06/UC-M06.01.md` inside [s/checklists.zip](../../s/checklists.zip); exact parent records in [data/parents.jsonl](../../data/parents.jsonl). Original roadmap lines 524–534 are preserved in [s/roadmap.md](../../s/roadmap.md).

## How to use these lists

Every parent statement below is preserved verbatim. Its ten child tasks are proposed decomposition, not implemented capabilities or executed tests. Child IDs append `-T01` through `-T10` to the original parent ID. All begin unchecked / `TODO`. Design/review evidence does not establish runtime enforcement; observe the actual selected target where the parent requires it.

The source dependency graph and selected release profile determine applicability. The numbered child sequence is a local working order, not an added hard dependency graph. An unselected optional feature needs a recorded not-applicable rationale; missing prerequisites for selected work remain blockers. Numerical budgets, backends and trust mechanisms remain decisions unless fixed by the source. Test hostile cases only with synthetic inputs in authorized disposable environments.

## 01. Operation schema

**Source delivery:** Define structured management requests and results for supported lifecycle operations.

**Source invariant:** Machine behavior does not depend on parsing human log text.

**Source negative case:** A caller must scrape console prose to discover a job ID.

**Source bounded quantities:** Operation count and payload bytes.

### UC-M06.01-C001 · Contract

**Original checklist item:** Specify operation schema inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M06.01-C001-T01 · Scope statement:** Draft the operation boundary for “Operation schema” within Machine-stable management API; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M06.01-C001-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Operation schema”; record each producer, representation and missing-value meaning.
- [ ] **UC-M06.01-C001-T03 · Output inventory:** List the outputs of “Operation schema” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M06.01-C001-T04 · Field dictionary:** Create a field-and-term dictionary for “Operation schema”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M06.01-C001-T05 · Prerequisite contract:** Map “Operation schema” to the source component prerequisites (UC-M01.02, UC-M05.04); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M06.01-C001-T06 · Authority map:** Identify who may produce, change and consume “Operation schema”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M06.01-C001-T07 · Invariant clause:** Add a normative clause for “Operation schema” that preserves “Machine behavior does not depend on parsing human log text”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M06.01-C001-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Operation schema”; include the source counterexample “A caller must scrape console prose to discover a job ID” and the intended safe disposition.
- [ ] **UC-M06.01-C001-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Operation count and payload bytes” in the “Operation schema” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M06.01-C001-T10 · Contract review:** Review the “Operation schema” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M06.01-C002 · Delivery

**Original checklist item:** Define structured management requests and results for supported lifecycle operations.

- [ ] **UC-M06.01-C002-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Operation schema”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M06.01-C002-T02 · Change plan:** Break the source delivery for “Operation schema” into concrete edit targets and reviewable outputs; keep the UC-M06.01 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M06.01-C002-T03 · Core artifact:** Create the “Operation schema” model, schema or inventory that realizes this source instruction: Define structured management requests and results for supported lifecycle operations.
- [ ] **UC-M06.01-C002-T04 · Concrete realization:** Populate “Operation schema” with one concrete worked case; map every required entity or field to its source and flag any unmapped entry.
- [ ] **UC-M06.01-C002-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Operation schema” needed to preserve “Machine behavior does not depend on parsing human log text”; record an enforcement gap where only a model exists.
- [ ] **UC-M06.01-C002-T06 · Dependency connection:** Connect the “Operation schema” implementation to the shared management contract, CLI presentation and durable job registry; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M06.01-C002-T07 · Resource behavior:** Account for “Operation count and payload bytes” in “Operation schema”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M06.01-C002-T08 · Delivery check:** Run the smallest real “Operation schema” path and its adverse fixture “A caller must scrape console prose to discover a job ID”; retain actual output, state effects and final disposition.
- [ ] **UC-M06.01-C002-T09 · Patch review:** Review the “Operation schema” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M06.01-C002-T10 · Delivery handoff:** Publish the “Operation schema” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M06.01-C003 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Machine behavior does not depend on parsing human log text. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M06.01-C003-T01 · Named property:** Create a stable property/check name under this parent for “Operation schema”; copy its required invariant exactly: “Machine behavior does not depend on parsing human log text”.
- [ ] **UC-M06.01-C003-T02 · Observable terms:** Define each term in the “Operation schema” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M06.01-C003-T03 · Precondition set:** List the preconditions under which “Machine behavior does not depend on parsing human log text” must hold for “Operation schema”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M06.01-C003-T04 · Transition coverage:** Map the “Operation schema” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M06.01-C003-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Operation schema”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M06.01-C003-T06 · Satisfying fixture:** Create a concrete “Operation schema” case that satisfies “Machine behavior does not depend on parsing human log text”; record its expected observation before running the assertion or review.
- [ ] **UC-M06.01-C003-T07 · Violating fixture:** Create the source counterexample “A caller must scrape console prose to discover a job ID” for “Operation schema”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M06.01-C003-T08 · Enforcement evidence:** Exercise the “Operation schema” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M06.01-C003-T09 · Regression linkage:** Link the “Operation schema” property to changes in the shared management contract, CLI presentation and durable job registry; record which dependency or contract changes require rerunning it.
- [ ] **UC-M06.01-C003-T10 · Property disposition:** Compare the satisfying and violating “Operation schema” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M06.01-C004 · Integration

**Original checklist item:** Integrate operation schema with the shared management contract, CLI presentation and durable job registry; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M06.01-C004-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Operation schema” across the shared management contract, CLI presentation and durable job registry; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M06.01-C004-T02 · Field mapping:** Map every “Operation schema” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M06.01-C004-T03 · Prerequisite identities:** Record the actual prerequisites for “Operation schema” (source dependency list: UC-M01.02, UC-M05.04); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M06.01-C004-T04 · Ownership agreement:** Specify who owns “Operation schema” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M06.01-C004-T05 · Handoff implementation:** Connect “Operation schema” through the mapped seam using the real adapter or explicit specification reference; preserve “Machine behavior does not depend on parsing human log text” across the handoff.
- [ ] **UC-M06.01-C004-T06 · Absent-input case:** Omit one required “Operation schema” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M06.01-C004-T07 · Stale-input case:** Supply an outdated “Operation schema” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M06.01-C004-T08 · Incompatible-input case:** Supply an incompatible “Operation schema” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M06.01-C004-T09 · Valid integration trace:** Run a valid “Operation schema” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M06.01-C004-T10 · Seam review:** Reconcile the “Operation schema” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M06.01-C005 · Valid-case test

**Original checklist item:** Run a valid-path fixture for operation schema; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M06.01-C005-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Operation schema” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M06.01-C005-T02 · Expected-result oracle:** Specify the “Operation schema” expected result independently of the implementation output; include the property “Machine behavior does not depend on parsing human log text” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M06.01-C005-T03 · Fixture material:** Create the concrete “Operation schema” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M06.01-C005-T04 · Target preparation:** Prepare the “Operation schema” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M06.01-C005-T05 · Initial-state record:** Record the initial “Operation schema” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M06.01-C005-T06 · Valid-path execution:** Execute the “Operation schema” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M06.01-C005-T07 · Outcome comparison:** Compare every declared “Operation schema” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M06.01-C005-T08 · State and bounds check:** Inspect the “Operation schema” ownership/state effects and actual use of “Operation count and payload bytes”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M06.01-C005-T09 · Repeatability check:** Repeat the same “Operation schema” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M06.01-C005-T10 · Positive evidence:** Attach the “Operation schema” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M06.01-C006 · Negative test

**Original checklist item:** Negative case: A caller must scrape console prose to discover a job ID. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M06.01-C006-T01 · Adverse-case definition:** Create a test record for the exact “Operation schema” source counterexample: “A caller must scrape console prose to discover a job ID”; state which precondition or invariant it challenges.
- [ ] **UC-M06.01-C006-T02 · Safe fixture boundary:** Define the contained test boundary for “Operation schema”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M06.01-C006-T03 · Valid control:** Construct a valid “Operation schema” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M06.01-C006-T04 · Minimal adverse input:** Derive the “Operation schema” adverse fixture from the control with the smallest documented change needed to reproduce “A caller must scrape console prose to discover a job ID”; retain that change as reproducible data.
- [ ] **UC-M06.01-C006-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Operation schema”; require “Machine behavior does not depend on parsing human log text” and forbid a false-success verdict.
- [ ] **UC-M06.01-C006-T06 · Adverse execution:** Exercise the “Operation schema” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M06.01-C006-T07 · Effect inspection:** Inspect “Operation schema” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M06.01-C006-T08 · Refusal versus failure:** Confirm the “Operation schema” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M06.01-C006-T09 · Reset and retention:** Restore only the disposable “Operation schema” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M06.01-C006-T10 · Negative regression:** Register the “Operation schema” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M06.01-C007 · Change / failure test

**Original checklist item:** Exercise operation schema when a client retries an operation after an uncertain long-running job response; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M06.01-C007-T01 · Scenario record:** Write the “Operation schema” change/failure scenario exactly as supplied: a client retries an operation after an uncertain long-running job response; identify the property that must remain true: “Machine behavior does not depend on parsing human log text”.
- [ ] **UC-M06.01-C007-T02 · Baseline capture:** Create a known-valid “Operation schema” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M06.01-C007-T03 · Injection map:** Locate the “Operation schema” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M06.01-C007-T04 · Disposition oracle:** Define the legal intermediate and final “Operation schema” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M06.01-C007-T05 · Controlled trigger:** Introduce the controlled “Operation schema” scenario in the disposable fixture: a client retries an operation after an uncertain long-running job response; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M06.01-C007-T06 · Intermediate inspection:** Inspect the “Operation schema” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M06.01-C007-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Operation schema”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M06.01-C007-T08 · Stale-evidence cleanup:** Invalidate superseded “Operation schema” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M06.01-C007-T09 · Repeat and compare:** Repeat the selected “Operation schema” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M06.01-C007-T10 · Failure evidence:** Publish the “Operation schema” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M06.01-C008 · Bounds

**Original checklist item:** Choose, document and test limits for operation count and payload bytes; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M06.01-C008-T01 · Quantity inventory:** Create a measurement inventory for “Operation schema”: “Operation count and payload bytes”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M06.01-C008-T02 · Measurement method:** Choose how to observe each “Operation schema” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M06.01-C008-T03 · Budget decision:** Select justified resource and input limits for “Operation schema”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M06.01-C008-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Operation schema” cases for “Operation count and payload bytes”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M06.01-C008-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Operation schema” limit; preserve “Machine behavior does not depend on parsing human log text”.
- [ ] **UC-M06.01-C008-T06 · Normal measurement:** Run or review the normal “Operation schema” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M06.01-C008-T07 · At-limit measurement:** Exercise the “Operation schema” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M06.01-C008-T08 · Over-limit measurement:** Exercise the “Operation schema” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M06.01-C008-T09 · Uncovered-scope report:** List the “Operation schema” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M06.01-C008-T10 · Limit evidence:** Publish the selected “Operation schema” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M06.01-C009 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for operation schema with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M06.01-C009-T01 · Event inventory:** List the “Operation schema” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M06.01-C009-T02 · Diagnostic schema:** Define nonsecret fields for “Operation schema” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M06.01-C009-T03 · Failure mapping:** Map each documented “Operation schema” refusal or error to a diagnostic outcome; include “A caller must scrape console prose to discover a job ID” and prohibit conversion into a success message.
- [ ] **UC-M06.01-C009-T04 · Emission path:** Add the “Operation schema” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M06.01-C009-T05 · Redaction check:** Test “Operation schema” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M06.01-C009-T06 · Output budget:** Set and exercise bounded “Operation schema” message size, rate and retention compatible with “Operation count and payload bytes”; define truncation behavior that preserves the final reason.
- [ ] **UC-M06.01-C009-T07 · Success/refusal fixtures:** Capture “Operation schema” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M06.01-C009-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Operation schema” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M06.01-C009-T09 · Operator review:** Read the “Operation schema” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M06.01-C009-T10 · Diagnostic evidence:** Publish redacted “Operation schema” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M06.01-C010 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for operation schema; label unexecuted checks as untested.

- [ ] **UC-M06.01-C010-T01 · Evidence inventory:** List the “Operation schema” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M06.01-C010-T02 · Artifact references:** Record the exact “Operation schema” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M06.01-C010-T03 · Fixture references:** Attach the “Operation schema” fixture IDs, input identities and oracle definition; preserve the source counterexample “A caller must scrape console prose to discover a job ID” as a distinct evidence case.
- [ ] **UC-M06.01-C010-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Operation schema”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M06.01-C010-T05 · Environment record:** Record the actual “Operation schema” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M06.01-C010-T06 · Expected versus observed:** Pair every “Operation schema” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M06.01-C010-T07 · Failure and limit records:** Attach “Operation schema” change/failure and bounds evidence where required; include uncovered “Operation count and payload bytes” and unresolved violations of “Machine behavior does not depend on parsing human log text”.
- [ ] **UC-M06.01-C010-T08 · Evidence hygiene:** Check the “Operation schema” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M06.01-C010-T09 · Reproduction review:** Have the “Operation schema” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M06.01-C010-T10 · Acceptance linkage:** Link the “Operation schema” evidence to its parent and UC-M06.01 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 02. Version policy

**Source delivery:** Specify API versions and explicit incompatible-version refusal.

**Source invariant:** Unknown incompatible requests fail before mutation.

**Source negative case:** A future major version is accepted with guessed defaults.

**Source bounded quantities:** Supported versions and negotiation cost.

### UC-M06.01-C011 · Contract

**Original checklist item:** Specify version policy inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M06.01-C011-T01 · Scope statement:** Draft the operation boundary for “Version policy” within Machine-stable management API; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M06.01-C011-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Version policy”; record each producer, representation and missing-value meaning.
- [ ] **UC-M06.01-C011-T03 · Output inventory:** List the outputs of “Version policy” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M06.01-C011-T04 · Field dictionary:** Create a field-and-term dictionary for “Version policy”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M06.01-C011-T05 · Prerequisite contract:** Map “Version policy” to the source component prerequisites (UC-M01.02, UC-M05.04); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M06.01-C011-T06 · Authority map:** Identify who may produce, change and consume “Version policy”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M06.01-C011-T07 · Invariant clause:** Add a normative clause for “Version policy” that preserves “Unknown incompatible requests fail before mutation”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M06.01-C011-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Version policy”; include the source counterexample “A future major version is accepted with guessed defaults” and the intended safe disposition.
- [ ] **UC-M06.01-C011-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Supported versions and negotiation cost” in the “Version policy” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M06.01-C011-T10 · Contract review:** Review the “Version policy” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M06.01-C012 · Delivery

**Original checklist item:** Specify API versions and explicit incompatible-version refusal.

- [ ] **UC-M06.01-C012-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Version policy”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M06.01-C012-T02 · Change plan:** Break the source delivery for “Version policy” into concrete edit targets and reviewable outputs; keep the UC-M06.01 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M06.01-C012-T03 · Core artifact:** Create the “Version policy” model, schema or inventory that realizes this source instruction: Specify API versions and explicit incompatible-version refusal.
- [ ] **UC-M06.01-C012-T04 · Concrete realization:** Populate “Version policy” with one concrete worked case; map every required entity or field to its source and flag any unmapped entry.
- [ ] **UC-M06.01-C012-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Version policy” needed to preserve “Unknown incompatible requests fail before mutation”; record an enforcement gap where only a model exists.
- [ ] **UC-M06.01-C012-T06 · Dependency connection:** Connect the “Version policy” implementation to the shared management contract, CLI presentation and durable job registry; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M06.01-C012-T07 · Resource behavior:** Account for “Supported versions and negotiation cost” in “Version policy”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M06.01-C012-T08 · Delivery check:** Run the smallest real “Version policy” path and its adverse fixture “A future major version is accepted with guessed defaults”; retain actual output, state effects and final disposition.
- [ ] **UC-M06.01-C012-T09 · Patch review:** Review the “Version policy” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M06.01-C012-T10 · Delivery handoff:** Publish the “Version policy” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M06.01-C013 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Unknown incompatible requests fail before mutation. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M06.01-C013-T01 · Named property:** Create a stable property/check name under this parent for “Version policy”; copy its required invariant exactly: “Unknown incompatible requests fail before mutation”.
- [ ] **UC-M06.01-C013-T02 · Observable terms:** Define each term in the “Version policy” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M06.01-C013-T03 · Precondition set:** List the preconditions under which “Unknown incompatible requests fail before mutation” must hold for “Version policy”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M06.01-C013-T04 · Transition coverage:** Map the “Version policy” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M06.01-C013-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Version policy”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M06.01-C013-T06 · Satisfying fixture:** Create a concrete “Version policy” case that satisfies “Unknown incompatible requests fail before mutation”; record its expected observation before running the assertion or review.
- [ ] **UC-M06.01-C013-T07 · Violating fixture:** Create the source counterexample “A future major version is accepted with guessed defaults” for “Version policy”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M06.01-C013-T08 · Enforcement evidence:** Exercise the “Version policy” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M06.01-C013-T09 · Regression linkage:** Link the “Version policy” property to changes in the shared management contract, CLI presentation and durable job registry; record which dependency or contract changes require rerunning it.
- [ ] **UC-M06.01-C013-T10 · Property disposition:** Compare the satisfying and violating “Version policy” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M06.01-C014 · Integration

**Original checklist item:** Integrate version policy with the shared management contract, CLI presentation and durable job registry; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M06.01-C014-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Version policy” across the shared management contract, CLI presentation and durable job registry; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M06.01-C014-T02 · Field mapping:** Map every “Version policy” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M06.01-C014-T03 · Prerequisite identities:** Record the actual prerequisites for “Version policy” (source dependency list: UC-M01.02, UC-M05.04); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M06.01-C014-T04 · Ownership agreement:** Specify who owns “Version policy” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M06.01-C014-T05 · Handoff implementation:** Connect “Version policy” through the mapped seam using the real adapter or explicit specification reference; preserve “Unknown incompatible requests fail before mutation” across the handoff.
- [ ] **UC-M06.01-C014-T06 · Absent-input case:** Omit one required “Version policy” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M06.01-C014-T07 · Stale-input case:** Supply an outdated “Version policy” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M06.01-C014-T08 · Incompatible-input case:** Supply an incompatible “Version policy” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M06.01-C014-T09 · Valid integration trace:** Run a valid “Version policy” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M06.01-C014-T10 · Seam review:** Reconcile the “Version policy” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M06.01-C015 · Valid-case test

**Original checklist item:** Run a valid-path fixture for version policy; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M06.01-C015-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Version policy” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M06.01-C015-T02 · Expected-result oracle:** Specify the “Version policy” expected result independently of the implementation output; include the property “Unknown incompatible requests fail before mutation” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M06.01-C015-T03 · Fixture material:** Create the concrete “Version policy” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M06.01-C015-T04 · Target preparation:** Prepare the “Version policy” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M06.01-C015-T05 · Initial-state record:** Record the initial “Version policy” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M06.01-C015-T06 · Valid-path execution:** Execute the “Version policy” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M06.01-C015-T07 · Outcome comparison:** Compare every declared “Version policy” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M06.01-C015-T08 · State and bounds check:** Inspect the “Version policy” ownership/state effects and actual use of “Supported versions and negotiation cost”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M06.01-C015-T09 · Repeatability check:** Repeat the same “Version policy” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M06.01-C015-T10 · Positive evidence:** Attach the “Version policy” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M06.01-C016 · Negative test

**Original checklist item:** Negative case: A future major version is accepted with guessed defaults. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M06.01-C016-T01 · Adverse-case definition:** Create a test record for the exact “Version policy” source counterexample: “A future major version is accepted with guessed defaults”; state which precondition or invariant it challenges.
- [ ] **UC-M06.01-C016-T02 · Safe fixture boundary:** Define the contained test boundary for “Version policy”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M06.01-C016-T03 · Valid control:** Construct a valid “Version policy” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M06.01-C016-T04 · Minimal adverse input:** Derive the “Version policy” adverse fixture from the control with the smallest documented change needed to reproduce “A future major version is accepted with guessed defaults”; retain that change as reproducible data.
- [ ] **UC-M06.01-C016-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Version policy”; require “Unknown incompatible requests fail before mutation” and forbid a false-success verdict.
- [ ] **UC-M06.01-C016-T06 · Adverse execution:** Exercise the “Version policy” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M06.01-C016-T07 · Effect inspection:** Inspect “Version policy” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M06.01-C016-T08 · Refusal versus failure:** Confirm the “Version policy” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M06.01-C016-T09 · Reset and retention:** Restore only the disposable “Version policy” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M06.01-C016-T10 · Negative regression:** Register the “Version policy” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M06.01-C017 · Change / failure test

**Original checklist item:** Exercise version policy when a client retries an operation after an uncertain long-running job response; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M06.01-C017-T01 · Scenario record:** Write the “Version policy” change/failure scenario exactly as supplied: a client retries an operation after an uncertain long-running job response; identify the property that must remain true: “Unknown incompatible requests fail before mutation”.
- [ ] **UC-M06.01-C017-T02 · Baseline capture:** Create a known-valid “Version policy” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M06.01-C017-T03 · Injection map:** Locate the “Version policy” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M06.01-C017-T04 · Disposition oracle:** Define the legal intermediate and final “Version policy” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M06.01-C017-T05 · Controlled trigger:** Introduce the controlled “Version policy” scenario in the disposable fixture: a client retries an operation after an uncertain long-running job response; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M06.01-C017-T06 · Intermediate inspection:** Inspect the “Version policy” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M06.01-C017-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Version policy”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M06.01-C017-T08 · Stale-evidence cleanup:** Invalidate superseded “Version policy” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M06.01-C017-T09 · Repeat and compare:** Repeat the selected “Version policy” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M06.01-C017-T10 · Failure evidence:** Publish the “Version policy” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M06.01-C018 · Bounds

**Original checklist item:** Choose, document and test limits for supported versions and negotiation cost; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M06.01-C018-T01 · Quantity inventory:** Create a measurement inventory for “Version policy”: “Supported versions and negotiation cost”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M06.01-C018-T02 · Measurement method:** Choose how to observe each “Version policy” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M06.01-C018-T03 · Budget decision:** Select justified resource and input limits for “Version policy”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M06.01-C018-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Version policy” cases for “Supported versions and negotiation cost”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M06.01-C018-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Version policy” limit; preserve “Unknown incompatible requests fail before mutation”.
- [ ] **UC-M06.01-C018-T06 · Normal measurement:** Run or review the normal “Version policy” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M06.01-C018-T07 · At-limit measurement:** Exercise the “Version policy” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M06.01-C018-T08 · Over-limit measurement:** Exercise the “Version policy” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M06.01-C018-T09 · Uncovered-scope report:** List the “Version policy” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M06.01-C018-T10 · Limit evidence:** Publish the selected “Version policy” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M06.01-C019 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for version policy with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M06.01-C019-T01 · Event inventory:** List the “Version policy” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M06.01-C019-T02 · Diagnostic schema:** Define nonsecret fields for “Version policy” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M06.01-C019-T03 · Failure mapping:** Map each documented “Version policy” refusal or error to a diagnostic outcome; include “A future major version is accepted with guessed defaults” and prohibit conversion into a success message.
- [ ] **UC-M06.01-C019-T04 · Emission path:** Add the “Version policy” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M06.01-C019-T05 · Redaction check:** Test “Version policy” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M06.01-C019-T06 · Output budget:** Set and exercise bounded “Version policy” message size, rate and retention compatible with “Supported versions and negotiation cost”; define truncation behavior that preserves the final reason.
- [ ] **UC-M06.01-C019-T07 · Success/refusal fixtures:** Capture “Version policy” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M06.01-C019-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Version policy” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M06.01-C019-T09 · Operator review:** Read the “Version policy” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M06.01-C019-T10 · Diagnostic evidence:** Publish redacted “Version policy” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M06.01-C020 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for version policy; label unexecuted checks as untested.

- [ ] **UC-M06.01-C020-T01 · Evidence inventory:** List the “Version policy” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M06.01-C020-T02 · Artifact references:** Record the exact “Version policy” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M06.01-C020-T03 · Fixture references:** Attach the “Version policy” fixture IDs, input identities and oracle definition; preserve the source counterexample “A future major version is accepted with guessed defaults” as a distinct evidence case.
- [ ] **UC-M06.01-C020-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Version policy”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M06.01-C020-T05 · Environment record:** Record the actual “Version policy” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M06.01-C020-T06 · Expected versus observed:** Pair every “Version policy” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M06.01-C020-T07 · Failure and limit records:** Attach “Version policy” change/failure and bounds evidence where required; include uncovered “Supported versions and negotiation cost” and unresolved violations of “Unknown incompatible requests fail before mutation”.
- [ ] **UC-M06.01-C020-T08 · Evidence hygiene:** Check the “Version policy” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M06.01-C020-T09 · Reproduction review:** Have the “Version policy” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M06.01-C020-T10 · Acceptance linkage:** Link the “Version policy” evidence to its parent and UC-M06.01 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 03. CLI/API parity

**Source delivery:** Map each supported CLI operation to the same underlying machine contract.

**Source invariant:** CLI and API paths enforce equivalent semantics and checks.

**Source negative case:** A CLI flag bypasses an API admission restriction.

**Source bounded quantities:** Command mappings and parity fixtures.

### UC-M06.01-C021 · Contract

**Original checklist item:** Specify CLI/API parity inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M06.01-C021-T01 · Scope statement:** Draft the operation boundary for “CLI/API parity” within Machine-stable management API; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M06.01-C021-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “CLI/API parity”; record each producer, representation and missing-value meaning.
- [ ] **UC-M06.01-C021-T03 · Output inventory:** List the outputs of “CLI/API parity” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M06.01-C021-T04 · Field dictionary:** Create a field-and-term dictionary for “CLI/API parity”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M06.01-C021-T05 · Prerequisite contract:** Map “CLI/API parity” to the source component prerequisites (UC-M01.02, UC-M05.04); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M06.01-C021-T06 · Authority map:** Identify who may produce, change and consume “CLI/API parity”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M06.01-C021-T07 · Invariant clause:** Add a normative clause for “CLI/API parity” that preserves “CLI and API paths enforce equivalent semantics and checks”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M06.01-C021-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “CLI/API parity”; include the source counterexample “A CLI flag bypasses an API admission restriction” and the intended safe disposition.
- [ ] **UC-M06.01-C021-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Command mappings and parity fixtures” in the “CLI/API parity” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M06.01-C021-T10 · Contract review:** Review the “CLI/API parity” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M06.01-C022 · Delivery

**Original checklist item:** Map each supported CLI operation to the same underlying machine contract.

- [ ] **UC-M06.01-C022-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “CLI/API parity”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M06.01-C022-T02 · Change plan:** Break the source delivery for “CLI/API parity” into concrete edit targets and reviewable outputs; keep the UC-M06.01 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M06.01-C022-T03 · Core artifact:** Create the “CLI/API parity” model, schema or inventory that realizes this source instruction: Map each supported CLI operation to the same underlying machine contract.
- [ ] **UC-M06.01-C022-T04 · Concrete realization:** Populate “CLI/API parity” with one concrete worked case; map every required entity or field to its source and flag any unmapped entry.
- [ ] **UC-M06.01-C022-T05 · Invariant protection:** Add the actual guard, check or review criterion for “CLI/API parity” needed to preserve “CLI and API paths enforce equivalent semantics and checks”; record an enforcement gap where only a model exists.
- [ ] **UC-M06.01-C022-T06 · Dependency connection:** Connect the “CLI/API parity” implementation to the shared management contract, CLI presentation and durable job registry; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M06.01-C022-T07 · Resource behavior:** Account for “Command mappings and parity fixtures” in “CLI/API parity”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M06.01-C022-T08 · Delivery check:** Run the smallest real “CLI/API parity” path and its adverse fixture “A CLI flag bypasses an API admission restriction”; retain actual output, state effects and final disposition.
- [ ] **UC-M06.01-C022-T09 · Patch review:** Review the “CLI/API parity” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M06.01-C022-T10 · Delivery handoff:** Publish the “CLI/API parity” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M06.01-C023 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: CLI and API paths enforce equivalent semantics and checks. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M06.01-C023-T01 · Named property:** Create a stable property/check name under this parent for “CLI/API parity”; copy its required invariant exactly: “CLI and API paths enforce equivalent semantics and checks”.
- [ ] **UC-M06.01-C023-T02 · Observable terms:** Define each term in the “CLI/API parity” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M06.01-C023-T03 · Precondition set:** List the preconditions under which “CLI and API paths enforce equivalent semantics and checks” must hold for “CLI/API parity”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M06.01-C023-T04 · Transition coverage:** Map the “CLI/API parity” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M06.01-C023-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “CLI/API parity”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M06.01-C023-T06 · Satisfying fixture:** Create a concrete “CLI/API parity” case that satisfies “CLI and API paths enforce equivalent semantics and checks”; record its expected observation before running the assertion or review.
- [ ] **UC-M06.01-C023-T07 · Violating fixture:** Create the source counterexample “A CLI flag bypasses an API admission restriction” for “CLI/API parity”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M06.01-C023-T08 · Enforcement evidence:** Exercise the “CLI/API parity” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M06.01-C023-T09 · Regression linkage:** Link the “CLI/API parity” property to changes in the shared management contract, CLI presentation and durable job registry; record which dependency or contract changes require rerunning it.
- [ ] **UC-M06.01-C023-T10 · Property disposition:** Compare the satisfying and violating “CLI/API parity” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M06.01-C024 · Integration

**Original checklist item:** Integrate CLI/API parity with the shared management contract, CLI presentation and durable job registry; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M06.01-C024-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “CLI/API parity” across the shared management contract, CLI presentation and durable job registry; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M06.01-C024-T02 · Field mapping:** Map every “CLI/API parity” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M06.01-C024-T03 · Prerequisite identities:** Record the actual prerequisites for “CLI/API parity” (source dependency list: UC-M01.02, UC-M05.04); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M06.01-C024-T04 · Ownership agreement:** Specify who owns “CLI/API parity” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M06.01-C024-T05 · Handoff implementation:** Connect “CLI/API parity” through the mapped seam using the real adapter or explicit specification reference; preserve “CLI and API paths enforce equivalent semantics and checks” across the handoff.
- [ ] **UC-M06.01-C024-T06 · Absent-input case:** Omit one required “CLI/API parity” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M06.01-C024-T07 · Stale-input case:** Supply an outdated “CLI/API parity” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M06.01-C024-T08 · Incompatible-input case:** Supply an incompatible “CLI/API parity” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M06.01-C024-T09 · Valid integration trace:** Run a valid “CLI/API parity” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M06.01-C024-T10 · Seam review:** Reconcile the “CLI/API parity” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M06.01-C025 · Valid-case test

**Original checklist item:** Run a valid-path fixture for CLI/API parity; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M06.01-C025-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “CLI/API parity” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M06.01-C025-T02 · Expected-result oracle:** Specify the “CLI/API parity” expected result independently of the implementation output; include the property “CLI and API paths enforce equivalent semantics and checks” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M06.01-C025-T03 · Fixture material:** Create the concrete “CLI/API parity” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M06.01-C025-T04 · Target preparation:** Prepare the “CLI/API parity” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M06.01-C025-T05 · Initial-state record:** Record the initial “CLI/API parity” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M06.01-C025-T06 · Valid-path execution:** Execute the “CLI/API parity” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M06.01-C025-T07 · Outcome comparison:** Compare every declared “CLI/API parity” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M06.01-C025-T08 · State and bounds check:** Inspect the “CLI/API parity” ownership/state effects and actual use of “Command mappings and parity fixtures”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M06.01-C025-T09 · Repeatability check:** Repeat the same “CLI/API parity” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M06.01-C025-T10 · Positive evidence:** Attach the “CLI/API parity” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M06.01-C026 · Negative test

**Original checklist item:** Negative case: A CLI flag bypasses an API admission restriction. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M06.01-C026-T01 · Adverse-case definition:** Create a test record for the exact “CLI/API parity” source counterexample: “A CLI flag bypasses an API admission restriction”; state which precondition or invariant it challenges.
- [ ] **UC-M06.01-C026-T02 · Safe fixture boundary:** Define the contained test boundary for “CLI/API parity”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M06.01-C026-T03 · Valid control:** Construct a valid “CLI/API parity” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M06.01-C026-T04 · Minimal adverse input:** Derive the “CLI/API parity” adverse fixture from the control with the smallest documented change needed to reproduce “A CLI flag bypasses an API admission restriction”; retain that change as reproducible data.
- [ ] **UC-M06.01-C026-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “CLI/API parity”; require “CLI and API paths enforce equivalent semantics and checks” and forbid a false-success verdict.
- [ ] **UC-M06.01-C026-T06 · Adverse execution:** Exercise the “CLI/API parity” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M06.01-C026-T07 · Effect inspection:** Inspect “CLI/API parity” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M06.01-C026-T08 · Refusal versus failure:** Confirm the “CLI/API parity” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M06.01-C026-T09 · Reset and retention:** Restore only the disposable “CLI/API parity” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M06.01-C026-T10 · Negative regression:** Register the “CLI/API parity” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M06.01-C027 · Change / failure test

**Original checklist item:** Exercise CLI/API parity when a client retries an operation after an uncertain long-running job response; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M06.01-C027-T01 · Scenario record:** Write the “CLI/API parity” change/failure scenario exactly as supplied: a client retries an operation after an uncertain long-running job response; identify the property that must remain true: “CLI and API paths enforce equivalent semantics and checks”.
- [ ] **UC-M06.01-C027-T02 · Baseline capture:** Create a known-valid “CLI/API parity” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M06.01-C027-T03 · Injection map:** Locate the “CLI/API parity” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M06.01-C027-T04 · Disposition oracle:** Define the legal intermediate and final “CLI/API parity” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M06.01-C027-T05 · Controlled trigger:** Introduce the controlled “CLI/API parity” scenario in the disposable fixture: a client retries an operation after an uncertain long-running job response; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M06.01-C027-T06 · Intermediate inspection:** Inspect the “CLI/API parity” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M06.01-C027-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “CLI/API parity”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M06.01-C027-T08 · Stale-evidence cleanup:** Invalidate superseded “CLI/API parity” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M06.01-C027-T09 · Repeat and compare:** Repeat the selected “CLI/API parity” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M06.01-C027-T10 · Failure evidence:** Publish the “CLI/API parity” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M06.01-C028 · Bounds

**Original checklist item:** Choose, document and test limits for command mappings and parity fixtures; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M06.01-C028-T01 · Quantity inventory:** Create a measurement inventory for “CLI/API parity”: “Command mappings and parity fixtures”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M06.01-C028-T02 · Measurement method:** Choose how to observe each “CLI/API parity” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M06.01-C028-T03 · Budget decision:** Select justified resource and input limits for “CLI/API parity”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M06.01-C028-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “CLI/API parity” cases for “Command mappings and parity fixtures”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M06.01-C028-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “CLI/API parity” limit; preserve “CLI and API paths enforce equivalent semantics and checks”.
- [ ] **UC-M06.01-C028-T06 · Normal measurement:** Run or review the normal “CLI/API parity” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M06.01-C028-T07 · At-limit measurement:** Exercise the “CLI/API parity” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M06.01-C028-T08 · Over-limit measurement:** Exercise the “CLI/API parity” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M06.01-C028-T09 · Uncovered-scope report:** List the “CLI/API parity” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M06.01-C028-T10 · Limit evidence:** Publish the selected “CLI/API parity” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M06.01-C029 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for CLI/API parity with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M06.01-C029-T01 · Event inventory:** List the “CLI/API parity” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M06.01-C029-T02 · Diagnostic schema:** Define nonsecret fields for “CLI/API parity” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M06.01-C029-T03 · Failure mapping:** Map each documented “CLI/API parity” refusal or error to a diagnostic outcome; include “A CLI flag bypasses an API admission restriction” and prohibit conversion into a success message.
- [ ] **UC-M06.01-C029-T04 · Emission path:** Add the “CLI/API parity” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M06.01-C029-T05 · Redaction check:** Test “CLI/API parity” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M06.01-C029-T06 · Output budget:** Set and exercise bounded “CLI/API parity” message size, rate and retention compatible with “Command mappings and parity fixtures”; define truncation behavior that preserves the final reason.
- [ ] **UC-M06.01-C029-T07 · Success/refusal fixtures:** Capture “CLI/API parity” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M06.01-C029-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “CLI/API parity” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M06.01-C029-T09 · Operator review:** Read the “CLI/API parity” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M06.01-C029-T10 · Diagnostic evidence:** Publish redacted “CLI/API parity” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M06.01-C030 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for CLI/API parity; label unexecuted checks as untested.

- [ ] **UC-M06.01-C030-T01 · Evidence inventory:** List the “CLI/API parity” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M06.01-C030-T02 · Artifact references:** Record the exact “CLI/API parity” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M06.01-C030-T03 · Fixture references:** Attach the “CLI/API parity” fixture IDs, input identities and oracle definition; preserve the source counterexample “A CLI flag bypasses an API admission restriction” as a distinct evidence case.
- [ ] **UC-M06.01-C030-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “CLI/API parity”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M06.01-C030-T05 · Environment record:** Record the actual “CLI/API parity” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M06.01-C030-T06 · Expected versus observed:** Pair every “CLI/API parity” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M06.01-C030-T07 · Failure and limit records:** Attach “CLI/API parity” change/failure and bounds evidence where required; include uncovered “Command mappings and parity fixtures” and unresolved violations of “CLI and API paths enforce equivalent semantics and checks”.
- [ ] **UC-M06.01-C030-T08 · Evidence hygiene:** Check the “CLI/API parity” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M06.01-C030-T09 · Reproduction review:** Have the “CLI/API parity” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M06.01-C030-T10 · Acceptance linkage:** Link the “CLI/API parity” evidence to its parent and UC-M06.01 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 04. Long-running jobs

**Source delivery:** Return durable job identities for asynchronous operations.

**Source invariant:** Accepted jobs remain distinguishable from completed jobs.

**Source negative case:** The API returns success when a build was merely queued.

**Source bounded quantities:** Active jobs and job record bytes.

### UC-M06.01-C031 · Contract

**Original checklist item:** Specify long-running jobs inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M06.01-C031-T01 · Scope statement:** Draft the operation boundary for “Long-running jobs” within Machine-stable management API; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M06.01-C031-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Long-running jobs”; record each producer, representation and missing-value meaning.
- [ ] **UC-M06.01-C031-T03 · Output inventory:** List the outputs of “Long-running jobs” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M06.01-C031-T04 · Field dictionary:** Create a field-and-term dictionary for “Long-running jobs”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M06.01-C031-T05 · Prerequisite contract:** Map “Long-running jobs” to the source component prerequisites (UC-M01.02, UC-M05.04); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M06.01-C031-T06 · Authority map:** Identify who may produce, change and consume “Long-running jobs”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M06.01-C031-T07 · Invariant clause:** Add a normative clause for “Long-running jobs” that preserves “Accepted jobs remain distinguishable from completed jobs”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M06.01-C031-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Long-running jobs”; include the source counterexample “The API returns success when a build was merely queued” and the intended safe disposition.
- [ ] **UC-M06.01-C031-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Active jobs and job record bytes” in the “Long-running jobs” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M06.01-C031-T10 · Contract review:** Review the “Long-running jobs” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M06.01-C032 · Delivery

**Original checklist item:** Return durable job identities for asynchronous operations.

- [ ] **UC-M06.01-C032-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Long-running jobs”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M06.01-C032-T02 · Change plan:** Break the source delivery for “Long-running jobs” into concrete edit targets and reviewable outputs; keep the UC-M06.01 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M06.01-C032-T03 · Core artifact:** Implement the smallest selected-profile change for “Long-running jobs” that realizes this source instruction: Return durable job identities for asynchronous operations.
- [ ] **UC-M06.01-C032-T04 · Concrete realization:** Trace “Long-running jobs” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M06.01-C032-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Long-running jobs” needed to preserve “Accepted jobs remain distinguishable from completed jobs”; record an enforcement gap where only a model exists.
- [ ] **UC-M06.01-C032-T06 · Dependency connection:** Connect the “Long-running jobs” implementation to the shared management contract, CLI presentation and durable job registry; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M06.01-C032-T07 · Resource behavior:** Account for “Active jobs and job record bytes” in “Long-running jobs”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M06.01-C032-T08 · Delivery check:** Run the smallest real “Long-running jobs” path and its adverse fixture “The API returns success when a build was merely queued”; retain actual output, state effects and final disposition.
- [ ] **UC-M06.01-C032-T09 · Patch review:** Review the “Long-running jobs” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M06.01-C032-T10 · Delivery handoff:** Publish the “Long-running jobs” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M06.01-C033 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Accepted jobs remain distinguishable from completed jobs. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M06.01-C033-T01 · Named property:** Create a stable property/check name under this parent for “Long-running jobs”; copy its required invariant exactly: “Accepted jobs remain distinguishable from completed jobs”.
- [ ] **UC-M06.01-C033-T02 · Observable terms:** Define each term in the “Long-running jobs” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M06.01-C033-T03 · Precondition set:** List the preconditions under which “Accepted jobs remain distinguishable from completed jobs” must hold for “Long-running jobs”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M06.01-C033-T04 · Transition coverage:** Map the “Long-running jobs” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M06.01-C033-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Long-running jobs”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M06.01-C033-T06 · Satisfying fixture:** Create a concrete “Long-running jobs” case that satisfies “Accepted jobs remain distinguishable from completed jobs”; record its expected observation before running the assertion or review.
- [ ] **UC-M06.01-C033-T07 · Violating fixture:** Create the source counterexample “The API returns success when a build was merely queued” for “Long-running jobs”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M06.01-C033-T08 · Enforcement evidence:** Exercise the “Long-running jobs” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M06.01-C033-T09 · Regression linkage:** Link the “Long-running jobs” property to changes in the shared management contract, CLI presentation and durable job registry; record which dependency or contract changes require rerunning it.
- [ ] **UC-M06.01-C033-T10 · Property disposition:** Compare the satisfying and violating “Long-running jobs” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M06.01-C034 · Integration

**Original checklist item:** Integrate long-running jobs with the shared management contract, CLI presentation and durable job registry; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M06.01-C034-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Long-running jobs” across the shared management contract, CLI presentation and durable job registry; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M06.01-C034-T02 · Field mapping:** Map every “Long-running jobs” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M06.01-C034-T03 · Prerequisite identities:** Record the actual prerequisites for “Long-running jobs” (source dependency list: UC-M01.02, UC-M05.04); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M06.01-C034-T04 · Ownership agreement:** Specify who owns “Long-running jobs” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M06.01-C034-T05 · Handoff implementation:** Connect “Long-running jobs” through the mapped seam using the real adapter or explicit specification reference; preserve “Accepted jobs remain distinguishable from completed jobs” across the handoff.
- [ ] **UC-M06.01-C034-T06 · Absent-input case:** Omit one required “Long-running jobs” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M06.01-C034-T07 · Stale-input case:** Supply an outdated “Long-running jobs” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M06.01-C034-T08 · Incompatible-input case:** Supply an incompatible “Long-running jobs” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M06.01-C034-T09 · Valid integration trace:** Run a valid “Long-running jobs” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M06.01-C034-T10 · Seam review:** Reconcile the “Long-running jobs” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M06.01-C035 · Valid-case test

**Original checklist item:** Run a valid-path fixture for long-running jobs; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M06.01-C035-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Long-running jobs” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M06.01-C035-T02 · Expected-result oracle:** Specify the “Long-running jobs” expected result independently of the implementation output; include the property “Accepted jobs remain distinguishable from completed jobs” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M06.01-C035-T03 · Fixture material:** Create the concrete “Long-running jobs” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M06.01-C035-T04 · Target preparation:** Prepare the “Long-running jobs” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M06.01-C035-T05 · Initial-state record:** Record the initial “Long-running jobs” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M06.01-C035-T06 · Valid-path execution:** Execute the “Long-running jobs” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M06.01-C035-T07 · Outcome comparison:** Compare every declared “Long-running jobs” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M06.01-C035-T08 · State and bounds check:** Inspect the “Long-running jobs” ownership/state effects and actual use of “Active jobs and job record bytes”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M06.01-C035-T09 · Repeatability check:** Repeat the same “Long-running jobs” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M06.01-C035-T10 · Positive evidence:** Attach the “Long-running jobs” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M06.01-C036 · Negative test

**Original checklist item:** Negative case: The API returns success when a build was merely queued. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M06.01-C036-T01 · Adverse-case definition:** Create a test record for the exact “Long-running jobs” source counterexample: “The API returns success when a build was merely queued”; state which precondition or invariant it challenges.
- [ ] **UC-M06.01-C036-T02 · Safe fixture boundary:** Define the contained test boundary for “Long-running jobs”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M06.01-C036-T03 · Valid control:** Construct a valid “Long-running jobs” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M06.01-C036-T04 · Minimal adverse input:** Derive the “Long-running jobs” adverse fixture from the control with the smallest documented change needed to reproduce “The API returns success when a build was merely queued”; retain that change as reproducible data.
- [ ] **UC-M06.01-C036-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Long-running jobs”; require “Accepted jobs remain distinguishable from completed jobs” and forbid a false-success verdict.
- [ ] **UC-M06.01-C036-T06 · Adverse execution:** Exercise the “Long-running jobs” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M06.01-C036-T07 · Effect inspection:** Inspect “Long-running jobs” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M06.01-C036-T08 · Refusal versus failure:** Confirm the “Long-running jobs” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M06.01-C036-T09 · Reset and retention:** Restore only the disposable “Long-running jobs” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M06.01-C036-T10 · Negative regression:** Register the “Long-running jobs” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M06.01-C037 · Change / failure test

**Original checklist item:** Exercise long-running jobs when a client retries an operation after an uncertain long-running job response; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M06.01-C037-T01 · Scenario record:** Write the “Long-running jobs” change/failure scenario exactly as supplied: a client retries an operation after an uncertain long-running job response; identify the property that must remain true: “Accepted jobs remain distinguishable from completed jobs”.
- [ ] **UC-M06.01-C037-T02 · Baseline capture:** Create a known-valid “Long-running jobs” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M06.01-C037-T03 · Injection map:** Locate the “Long-running jobs” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M06.01-C037-T04 · Disposition oracle:** Define the legal intermediate and final “Long-running jobs” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M06.01-C037-T05 · Controlled trigger:** Introduce the controlled “Long-running jobs” scenario in the disposable fixture: a client retries an operation after an uncertain long-running job response; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M06.01-C037-T06 · Intermediate inspection:** Inspect the “Long-running jobs” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M06.01-C037-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Long-running jobs”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M06.01-C037-T08 · Stale-evidence cleanup:** Invalidate superseded “Long-running jobs” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M06.01-C037-T09 · Repeat and compare:** Repeat the selected “Long-running jobs” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M06.01-C037-T10 · Failure evidence:** Publish the “Long-running jobs” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M06.01-C038 · Bounds

**Original checklist item:** Choose, document and test limits for active jobs and job record bytes; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M06.01-C038-T01 · Quantity inventory:** Create a measurement inventory for “Long-running jobs”: “Active jobs and job record bytes”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M06.01-C038-T02 · Measurement method:** Choose how to observe each “Long-running jobs” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M06.01-C038-T03 · Budget decision:** Select justified resource and input limits for “Long-running jobs”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M06.01-C038-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Long-running jobs” cases for “Active jobs and job record bytes”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M06.01-C038-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Long-running jobs” limit; preserve “Accepted jobs remain distinguishable from completed jobs”.
- [ ] **UC-M06.01-C038-T06 · Normal measurement:** Run or review the normal “Long-running jobs” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M06.01-C038-T07 · At-limit measurement:** Exercise the “Long-running jobs” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M06.01-C038-T08 · Over-limit measurement:** Exercise the “Long-running jobs” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M06.01-C038-T09 · Uncovered-scope report:** List the “Long-running jobs” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M06.01-C038-T10 · Limit evidence:** Publish the selected “Long-running jobs” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M06.01-C039 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for long-running jobs with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M06.01-C039-T01 · Event inventory:** List the “Long-running jobs” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M06.01-C039-T02 · Diagnostic schema:** Define nonsecret fields for “Long-running jobs” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M06.01-C039-T03 · Failure mapping:** Map each documented “Long-running jobs” refusal or error to a diagnostic outcome; include “The API returns success when a build was merely queued” and prohibit conversion into a success message.
- [ ] **UC-M06.01-C039-T04 · Emission path:** Add the “Long-running jobs” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M06.01-C039-T05 · Redaction check:** Test “Long-running jobs” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M06.01-C039-T06 · Output budget:** Set and exercise bounded “Long-running jobs” message size, rate and retention compatible with “Active jobs and job record bytes”; define truncation behavior that preserves the final reason.
- [ ] **UC-M06.01-C039-T07 · Success/refusal fixtures:** Capture “Long-running jobs” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M06.01-C039-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Long-running jobs” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M06.01-C039-T09 · Operator review:** Read the “Long-running jobs” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M06.01-C039-T10 · Diagnostic evidence:** Publish redacted “Long-running jobs” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M06.01-C040 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for long-running jobs; label unexecuted checks as untested.

- [ ] **UC-M06.01-C040-T01 · Evidence inventory:** List the “Long-running jobs” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M06.01-C040-T02 · Artifact references:** Record the exact “Long-running jobs” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M06.01-C040-T03 · Fixture references:** Attach the “Long-running jobs” fixture IDs, input identities and oracle definition; preserve the source counterexample “The API returns success when a build was merely queued” as a distinct evidence case.
- [ ] **UC-M06.01-C040-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Long-running jobs”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M06.01-C040-T05 · Environment record:** Record the actual “Long-running jobs” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M06.01-C040-T06 · Expected versus observed:** Pair every “Long-running jobs” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M06.01-C040-T07 · Failure and limit records:** Attach “Long-running jobs” change/failure and bounds evidence where required; include uncovered “Active jobs and job record bytes” and unresolved violations of “Accepted jobs remain distinguishable from completed jobs”.
- [ ] **UC-M06.01-C040-T08 · Evidence hygiene:** Check the “Long-running jobs” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M06.01-C040-T09 · Reproduction review:** Have the “Long-running jobs” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M06.01-C040-T10 · Acceptance linkage:** Link the “Long-running jobs” evidence to its parent and UC-M06.01 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 05. Structured errors

**Source delivery:** Return stable error codes, scopes and retry dispositions.

**Source invariant:** Clients can classify failures without interpreting prose.

**Source negative case:** Two different failure classes share an ambiguous success envelope.

**Source bounded quantities:** Error types and cause-chain depth.

### UC-M06.01-C041 · Contract

**Original checklist item:** Specify structured errors inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M06.01-C041-T01 · Scope statement:** Draft the operation boundary for “Structured errors” within Machine-stable management API; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M06.01-C041-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Structured errors”; record each producer, representation and missing-value meaning.
- [ ] **UC-M06.01-C041-T03 · Output inventory:** List the outputs of “Structured errors” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M06.01-C041-T04 · Field dictionary:** Create a field-and-term dictionary for “Structured errors”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M06.01-C041-T05 · Prerequisite contract:** Map “Structured errors” to the source component prerequisites (UC-M01.02, UC-M05.04); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M06.01-C041-T06 · Authority map:** Identify who may produce, change and consume “Structured errors”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M06.01-C041-T07 · Invariant clause:** Add a normative clause for “Structured errors” that preserves “Clients can classify failures without interpreting prose”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M06.01-C041-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Structured errors”; include the source counterexample “Two different failure classes share an ambiguous success envelope” and the intended safe disposition.
- [ ] **UC-M06.01-C041-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Error types and cause-chain depth” in the “Structured errors” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M06.01-C041-T10 · Contract review:** Review the “Structured errors” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M06.01-C042 · Delivery

**Original checklist item:** Return stable error codes, scopes and retry dispositions.

- [ ] **UC-M06.01-C042-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Structured errors”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M06.01-C042-T02 · Change plan:** Break the source delivery for “Structured errors” into concrete edit targets and reviewable outputs; keep the UC-M06.01 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M06.01-C042-T03 · Core artifact:** Implement the smallest selected-profile change for “Structured errors” that realizes this source instruction: Return stable error codes, scopes and retry dispositions.
- [ ] **UC-M06.01-C042-T04 · Concrete realization:** Trace “Structured errors” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M06.01-C042-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Structured errors” needed to preserve “Clients can classify failures without interpreting prose”; record an enforcement gap where only a model exists.
- [ ] **UC-M06.01-C042-T06 · Dependency connection:** Connect the “Structured errors” implementation to the shared management contract, CLI presentation and durable job registry; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M06.01-C042-T07 · Resource behavior:** Account for “Error types and cause-chain depth” in “Structured errors”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M06.01-C042-T08 · Delivery check:** Run the smallest real “Structured errors” path and its adverse fixture “Two different failure classes share an ambiguous success envelope”; retain actual output, state effects and final disposition.
- [ ] **UC-M06.01-C042-T09 · Patch review:** Review the “Structured errors” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M06.01-C042-T10 · Delivery handoff:** Publish the “Structured errors” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M06.01-C043 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Clients can classify failures without interpreting prose. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M06.01-C043-T01 · Named property:** Create a stable property/check name under this parent for “Structured errors”; copy its required invariant exactly: “Clients can classify failures without interpreting prose”.
- [ ] **UC-M06.01-C043-T02 · Observable terms:** Define each term in the “Structured errors” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M06.01-C043-T03 · Precondition set:** List the preconditions under which “Clients can classify failures without interpreting prose” must hold for “Structured errors”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M06.01-C043-T04 · Transition coverage:** Map the “Structured errors” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M06.01-C043-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Structured errors”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M06.01-C043-T06 · Satisfying fixture:** Create a concrete “Structured errors” case that satisfies “Clients can classify failures without interpreting prose”; record its expected observation before running the assertion or review.
- [ ] **UC-M06.01-C043-T07 · Violating fixture:** Create the source counterexample “Two different failure classes share an ambiguous success envelope” for “Structured errors”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M06.01-C043-T08 · Enforcement evidence:** Exercise the “Structured errors” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M06.01-C043-T09 · Regression linkage:** Link the “Structured errors” property to changes in the shared management contract, CLI presentation and durable job registry; record which dependency or contract changes require rerunning it.
- [ ] **UC-M06.01-C043-T10 · Property disposition:** Compare the satisfying and violating “Structured errors” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M06.01-C044 · Integration

**Original checklist item:** Integrate structured errors with the shared management contract, CLI presentation and durable job registry; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M06.01-C044-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Structured errors” across the shared management contract, CLI presentation and durable job registry; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M06.01-C044-T02 · Field mapping:** Map every “Structured errors” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M06.01-C044-T03 · Prerequisite identities:** Record the actual prerequisites for “Structured errors” (source dependency list: UC-M01.02, UC-M05.04); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M06.01-C044-T04 · Ownership agreement:** Specify who owns “Structured errors” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M06.01-C044-T05 · Handoff implementation:** Connect “Structured errors” through the mapped seam using the real adapter or explicit specification reference; preserve “Clients can classify failures without interpreting prose” across the handoff.
- [ ] **UC-M06.01-C044-T06 · Absent-input case:** Omit one required “Structured errors” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M06.01-C044-T07 · Stale-input case:** Supply an outdated “Structured errors” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M06.01-C044-T08 · Incompatible-input case:** Supply an incompatible “Structured errors” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M06.01-C044-T09 · Valid integration trace:** Run a valid “Structured errors” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M06.01-C044-T10 · Seam review:** Reconcile the “Structured errors” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M06.01-C045 · Valid-case test

**Original checklist item:** Run a valid-path fixture for structured errors; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M06.01-C045-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Structured errors” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M06.01-C045-T02 · Expected-result oracle:** Specify the “Structured errors” expected result independently of the implementation output; include the property “Clients can classify failures without interpreting prose” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M06.01-C045-T03 · Fixture material:** Create the concrete “Structured errors” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M06.01-C045-T04 · Target preparation:** Prepare the “Structured errors” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M06.01-C045-T05 · Initial-state record:** Record the initial “Structured errors” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M06.01-C045-T06 · Valid-path execution:** Execute the “Structured errors” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M06.01-C045-T07 · Outcome comparison:** Compare every declared “Structured errors” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M06.01-C045-T08 · State and bounds check:** Inspect the “Structured errors” ownership/state effects and actual use of “Error types and cause-chain depth”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M06.01-C045-T09 · Repeatability check:** Repeat the same “Structured errors” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M06.01-C045-T10 · Positive evidence:** Attach the “Structured errors” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M06.01-C046 · Negative test

**Original checklist item:** Negative case: Two different failure classes share an ambiguous success envelope. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M06.01-C046-T01 · Adverse-case definition:** Create a test record for the exact “Structured errors” source counterexample: “Two different failure classes share an ambiguous success envelope”; state which precondition or invariant it challenges.
- [ ] **UC-M06.01-C046-T02 · Safe fixture boundary:** Define the contained test boundary for “Structured errors”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M06.01-C046-T03 · Valid control:** Construct a valid “Structured errors” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M06.01-C046-T04 · Minimal adverse input:** Derive the “Structured errors” adverse fixture from the control with the smallest documented change needed to reproduce “Two different failure classes share an ambiguous success envelope”; retain that change as reproducible data.
- [ ] **UC-M06.01-C046-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Structured errors”; require “Clients can classify failures without interpreting prose” and forbid a false-success verdict.
- [ ] **UC-M06.01-C046-T06 · Adverse execution:** Exercise the “Structured errors” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M06.01-C046-T07 · Effect inspection:** Inspect “Structured errors” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M06.01-C046-T08 · Refusal versus failure:** Confirm the “Structured errors” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M06.01-C046-T09 · Reset and retention:** Restore only the disposable “Structured errors” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M06.01-C046-T10 · Negative regression:** Register the “Structured errors” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M06.01-C047 · Change / failure test

**Original checklist item:** Exercise structured errors when a client retries an operation after an uncertain long-running job response; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M06.01-C047-T01 · Scenario record:** Write the “Structured errors” change/failure scenario exactly as supplied: a client retries an operation after an uncertain long-running job response; identify the property that must remain true: “Clients can classify failures without interpreting prose”.
- [ ] **UC-M06.01-C047-T02 · Baseline capture:** Create a known-valid “Structured errors” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M06.01-C047-T03 · Injection map:** Locate the “Structured errors” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M06.01-C047-T04 · Disposition oracle:** Define the legal intermediate and final “Structured errors” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M06.01-C047-T05 · Controlled trigger:** Introduce the controlled “Structured errors” scenario in the disposable fixture: a client retries an operation after an uncertain long-running job response; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M06.01-C047-T06 · Intermediate inspection:** Inspect the “Structured errors” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M06.01-C047-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Structured errors”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M06.01-C047-T08 · Stale-evidence cleanup:** Invalidate superseded “Structured errors” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M06.01-C047-T09 · Repeat and compare:** Repeat the selected “Structured errors” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M06.01-C047-T10 · Failure evidence:** Publish the “Structured errors” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M06.01-C048 · Bounds

**Original checklist item:** Choose, document and test limits for error types and cause-chain depth; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M06.01-C048-T01 · Quantity inventory:** Create a measurement inventory for “Structured errors”: “Error types and cause-chain depth”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M06.01-C048-T02 · Measurement method:** Choose how to observe each “Structured errors” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M06.01-C048-T03 · Budget decision:** Select justified resource and input limits for “Structured errors”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M06.01-C048-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Structured errors” cases for “Error types and cause-chain depth”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M06.01-C048-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Structured errors” limit; preserve “Clients can classify failures without interpreting prose”.
- [ ] **UC-M06.01-C048-T06 · Normal measurement:** Run or review the normal “Structured errors” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M06.01-C048-T07 · At-limit measurement:** Exercise the “Structured errors” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M06.01-C048-T08 · Over-limit measurement:** Exercise the “Structured errors” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M06.01-C048-T09 · Uncovered-scope report:** List the “Structured errors” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M06.01-C048-T10 · Limit evidence:** Publish the selected “Structured errors” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M06.01-C049 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for structured errors with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M06.01-C049-T01 · Event inventory:** List the “Structured errors” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M06.01-C049-T02 · Diagnostic schema:** Define nonsecret fields for “Structured errors” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M06.01-C049-T03 · Failure mapping:** Map each documented “Structured errors” refusal or error to a diagnostic outcome; include “Two different failure classes share an ambiguous success envelope” and prohibit conversion into a success message.
- [ ] **UC-M06.01-C049-T04 · Emission path:** Add the “Structured errors” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M06.01-C049-T05 · Redaction check:** Test “Structured errors” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M06.01-C049-T06 · Output budget:** Set and exercise bounded “Structured errors” message size, rate and retention compatible with “Error types and cause-chain depth”; define truncation behavior that preserves the final reason.
- [ ] **UC-M06.01-C049-T07 · Success/refusal fixtures:** Capture “Structured errors” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M06.01-C049-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Structured errors” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M06.01-C049-T09 · Operator review:** Read the “Structured errors” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M06.01-C049-T10 · Diagnostic evidence:** Publish redacted “Structured errors” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M06.01-C050 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for structured errors; label unexecuted checks as untested.

- [ ] **UC-M06.01-C050-T01 · Evidence inventory:** List the “Structured errors” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M06.01-C050-T02 · Artifact references:** Record the exact “Structured errors” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M06.01-C050-T03 · Fixture references:** Attach the “Structured errors” fixture IDs, input identities and oracle definition; preserve the source counterexample “Two different failure classes share an ambiguous success envelope” as a distinct evidence case.
- [ ] **UC-M06.01-C050-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Structured errors”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M06.01-C050-T05 · Environment record:** Record the actual “Structured errors” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M06.01-C050-T06 · Expected versus observed:** Pair every “Structured errors” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M06.01-C050-T07 · Failure and limit records:** Attach “Structured errors” change/failure and bounds evidence where required; include uncovered “Error types and cause-chain depth” and unresolved violations of “Clients can classify failures without interpreting prose”.
- [ ] **UC-M06.01-C050-T08 · Evidence hygiene:** Check the “Structured errors” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M06.01-C050-T09 · Reproduction review:** Have the “Structured errors” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M06.01-C050-T10 · Acceptance linkage:** Link the “Structured errors” evidence to its parent and UC-M06.01 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 06. Inspection responses

**Source delivery:** Expose generation, desired/observed state and evidence references as typed fields.

**Source invariant:** Inspection does not infer state from filenames or animations.

**Source negative case:** A response reports ready solely because a status file exists.

**Source bounded quantities:** Response bytes and observation age.

### UC-M06.01-C051 · Contract

**Original checklist item:** Specify inspection responses inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M06.01-C051-T01 · Scope statement:** Draft the operation boundary for “Inspection responses” within Machine-stable management API; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M06.01-C051-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Inspection responses”; record each producer, representation and missing-value meaning.
- [ ] **UC-M06.01-C051-T03 · Output inventory:** List the outputs of “Inspection responses” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M06.01-C051-T04 · Field dictionary:** Create a field-and-term dictionary for “Inspection responses”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M06.01-C051-T05 · Prerequisite contract:** Map “Inspection responses” to the source component prerequisites (UC-M01.02, UC-M05.04); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M06.01-C051-T06 · Authority map:** Identify who may produce, change and consume “Inspection responses”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M06.01-C051-T07 · Invariant clause:** Add a normative clause for “Inspection responses” that preserves “Inspection does not infer state from filenames or animations”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M06.01-C051-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Inspection responses”; include the source counterexample “A response reports ready solely because a status file exists” and the intended safe disposition.
- [ ] **UC-M06.01-C051-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Response bytes and observation age” in the “Inspection responses” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M06.01-C051-T10 · Contract review:** Review the “Inspection responses” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M06.01-C052 · Delivery

**Original checklist item:** Expose generation, desired/observed state and evidence references as typed fields.

- [ ] **UC-M06.01-C052-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Inspection responses”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M06.01-C052-T02 · Change plan:** Break the source delivery for “Inspection responses” into concrete edit targets and reviewable outputs; keep the UC-M06.01 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M06.01-C052-T03 · Core artifact:** Implement the smallest selected-profile change for “Inspection responses” that realizes this source instruction: Expose generation, desired/observed state and evidence references as typed fields.
- [ ] **UC-M06.01-C052-T04 · Concrete realization:** Trace “Inspection responses” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M06.01-C052-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Inspection responses” needed to preserve “Inspection does not infer state from filenames or animations”; record an enforcement gap where only a model exists.
- [ ] **UC-M06.01-C052-T06 · Dependency connection:** Connect the “Inspection responses” implementation to the shared management contract, CLI presentation and durable job registry; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M06.01-C052-T07 · Resource behavior:** Account for “Response bytes and observation age” in “Inspection responses”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M06.01-C052-T08 · Delivery check:** Run the smallest real “Inspection responses” path and its adverse fixture “A response reports ready solely because a status file exists”; retain actual output, state effects and final disposition.
- [ ] **UC-M06.01-C052-T09 · Patch review:** Review the “Inspection responses” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M06.01-C052-T10 · Delivery handoff:** Publish the “Inspection responses” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M06.01-C053 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Inspection does not infer state from filenames or animations. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M06.01-C053-T01 · Named property:** Create a stable property/check name under this parent for “Inspection responses”; copy its required invariant exactly: “Inspection does not infer state from filenames or animations”.
- [ ] **UC-M06.01-C053-T02 · Observable terms:** Define each term in the “Inspection responses” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M06.01-C053-T03 · Precondition set:** List the preconditions under which “Inspection does not infer state from filenames or animations” must hold for “Inspection responses”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M06.01-C053-T04 · Transition coverage:** Map the “Inspection responses” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M06.01-C053-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Inspection responses”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M06.01-C053-T06 · Satisfying fixture:** Create a concrete “Inspection responses” case that satisfies “Inspection does not infer state from filenames or animations”; record its expected observation before running the assertion or review.
- [ ] **UC-M06.01-C053-T07 · Violating fixture:** Create the source counterexample “A response reports ready solely because a status file exists” for “Inspection responses”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M06.01-C053-T08 · Enforcement evidence:** Exercise the “Inspection responses” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M06.01-C053-T09 · Regression linkage:** Link the “Inspection responses” property to changes in the shared management contract, CLI presentation and durable job registry; record which dependency or contract changes require rerunning it.
- [ ] **UC-M06.01-C053-T10 · Property disposition:** Compare the satisfying and violating “Inspection responses” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M06.01-C054 · Integration

**Original checklist item:** Integrate inspection responses with the shared management contract, CLI presentation and durable job registry; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M06.01-C054-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Inspection responses” across the shared management contract, CLI presentation and durable job registry; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M06.01-C054-T02 · Field mapping:** Map every “Inspection responses” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M06.01-C054-T03 · Prerequisite identities:** Record the actual prerequisites for “Inspection responses” (source dependency list: UC-M01.02, UC-M05.04); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M06.01-C054-T04 · Ownership agreement:** Specify who owns “Inspection responses” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M06.01-C054-T05 · Handoff implementation:** Connect “Inspection responses” through the mapped seam using the real adapter or explicit specification reference; preserve “Inspection does not infer state from filenames or animations” across the handoff.
- [ ] **UC-M06.01-C054-T06 · Absent-input case:** Omit one required “Inspection responses” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M06.01-C054-T07 · Stale-input case:** Supply an outdated “Inspection responses” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M06.01-C054-T08 · Incompatible-input case:** Supply an incompatible “Inspection responses” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M06.01-C054-T09 · Valid integration trace:** Run a valid “Inspection responses” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M06.01-C054-T10 · Seam review:** Reconcile the “Inspection responses” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M06.01-C055 · Valid-case test

**Original checklist item:** Run a valid-path fixture for inspection responses; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M06.01-C055-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Inspection responses” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M06.01-C055-T02 · Expected-result oracle:** Specify the “Inspection responses” expected result independently of the implementation output; include the property “Inspection does not infer state from filenames or animations” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M06.01-C055-T03 · Fixture material:** Create the concrete “Inspection responses” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M06.01-C055-T04 · Target preparation:** Prepare the “Inspection responses” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M06.01-C055-T05 · Initial-state record:** Record the initial “Inspection responses” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M06.01-C055-T06 · Valid-path execution:** Execute the “Inspection responses” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M06.01-C055-T07 · Outcome comparison:** Compare every declared “Inspection responses” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M06.01-C055-T08 · State and bounds check:** Inspect the “Inspection responses” ownership/state effects and actual use of “Response bytes and observation age”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M06.01-C055-T09 · Repeatability check:** Repeat the same “Inspection responses” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M06.01-C055-T10 · Positive evidence:** Attach the “Inspection responses” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M06.01-C056 · Negative test

**Original checklist item:** Negative case: A response reports ready solely because a status file exists. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M06.01-C056-T01 · Adverse-case definition:** Create a test record for the exact “Inspection responses” source counterexample: “A response reports ready solely because a status file exists”; state which precondition or invariant it challenges.
- [ ] **UC-M06.01-C056-T02 · Safe fixture boundary:** Define the contained test boundary for “Inspection responses”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M06.01-C056-T03 · Valid control:** Construct a valid “Inspection responses” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M06.01-C056-T04 · Minimal adverse input:** Derive the “Inspection responses” adverse fixture from the control with the smallest documented change needed to reproduce “A response reports ready solely because a status file exists”; retain that change as reproducible data.
- [ ] **UC-M06.01-C056-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Inspection responses”; require “Inspection does not infer state from filenames or animations” and forbid a false-success verdict.
- [ ] **UC-M06.01-C056-T06 · Adverse execution:** Exercise the “Inspection responses” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M06.01-C056-T07 · Effect inspection:** Inspect “Inspection responses” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M06.01-C056-T08 · Refusal versus failure:** Confirm the “Inspection responses” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M06.01-C056-T09 · Reset and retention:** Restore only the disposable “Inspection responses” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M06.01-C056-T10 · Negative regression:** Register the “Inspection responses” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M06.01-C057 · Change / failure test

**Original checklist item:** Exercise inspection responses when a client retries an operation after an uncertain long-running job response; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M06.01-C057-T01 · Scenario record:** Write the “Inspection responses” change/failure scenario exactly as supplied: a client retries an operation after an uncertain long-running job response; identify the property that must remain true: “Inspection does not infer state from filenames or animations”.
- [ ] **UC-M06.01-C057-T02 · Baseline capture:** Create a known-valid “Inspection responses” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M06.01-C057-T03 · Injection map:** Locate the “Inspection responses” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M06.01-C057-T04 · Disposition oracle:** Define the legal intermediate and final “Inspection responses” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M06.01-C057-T05 · Controlled trigger:** Introduce the controlled “Inspection responses” scenario in the disposable fixture: a client retries an operation after an uncertain long-running job response; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M06.01-C057-T06 · Intermediate inspection:** Inspect the “Inspection responses” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M06.01-C057-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Inspection responses”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M06.01-C057-T08 · Stale-evidence cleanup:** Invalidate superseded “Inspection responses” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M06.01-C057-T09 · Repeat and compare:** Repeat the selected “Inspection responses” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M06.01-C057-T10 · Failure evidence:** Publish the “Inspection responses” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M06.01-C058 · Bounds

**Original checklist item:** Choose, document and test limits for response bytes and observation age; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M06.01-C058-T01 · Quantity inventory:** Create a measurement inventory for “Inspection responses”: “Response bytes and observation age”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M06.01-C058-T02 · Measurement method:** Choose how to observe each “Inspection responses” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M06.01-C058-T03 · Budget decision:** Select justified resource and input limits for “Inspection responses”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M06.01-C058-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Inspection responses” cases for “Response bytes and observation age”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M06.01-C058-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Inspection responses” limit; preserve “Inspection does not infer state from filenames or animations”.
- [ ] **UC-M06.01-C058-T06 · Normal measurement:** Run or review the normal “Inspection responses” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M06.01-C058-T07 · At-limit measurement:** Exercise the “Inspection responses” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M06.01-C058-T08 · Over-limit measurement:** Exercise the “Inspection responses” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M06.01-C058-T09 · Uncovered-scope report:** List the “Inspection responses” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M06.01-C058-T10 · Limit evidence:** Publish the selected “Inspection responses” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M06.01-C059 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for inspection responses with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M06.01-C059-T01 · Event inventory:** List the “Inspection responses” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M06.01-C059-T02 · Diagnostic schema:** Define nonsecret fields for “Inspection responses” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M06.01-C059-T03 · Failure mapping:** Map each documented “Inspection responses” refusal or error to a diagnostic outcome; include “A response reports ready solely because a status file exists” and prohibit conversion into a success message.
- [ ] **UC-M06.01-C059-T04 · Emission path:** Add the “Inspection responses” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M06.01-C059-T05 · Redaction check:** Test “Inspection responses” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M06.01-C059-T06 · Output budget:** Set and exercise bounded “Inspection responses” message size, rate and retention compatible with “Response bytes and observation age”; define truncation behavior that preserves the final reason.
- [ ] **UC-M06.01-C059-T07 · Success/refusal fixtures:** Capture “Inspection responses” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M06.01-C059-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Inspection responses” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M06.01-C059-T09 · Operator review:** Read the “Inspection responses” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M06.01-C059-T10 · Diagnostic evidence:** Publish redacted “Inspection responses” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M06.01-C060 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for inspection responses; label unexecuted checks as untested.

- [ ] **UC-M06.01-C060-T01 · Evidence inventory:** List the “Inspection responses” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M06.01-C060-T02 · Artifact references:** Record the exact “Inspection responses” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M06.01-C060-T03 · Fixture references:** Attach the “Inspection responses” fixture IDs, input identities and oracle definition; preserve the source counterexample “A response reports ready solely because a status file exists” as a distinct evidence case.
- [ ] **UC-M06.01-C060-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Inspection responses”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M06.01-C060-T05 · Environment record:** Record the actual “Inspection responses” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M06.01-C060-T06 · Expected versus observed:** Pair every “Inspection responses” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M06.01-C060-T07 · Failure and limit records:** Attach “Inspection responses” change/failure and bounds evidence where required; include uncovered “Response bytes and observation age” and unresolved violations of “Inspection does not infer state from filenames or animations”.
- [ ] **UC-M06.01-C060-T08 · Evidence hygiene:** Check the “Inspection responses” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M06.01-C060-T09 · Reproduction review:** Have the “Inspection responses” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M06.01-C060-T10 · Acceptance linkage:** Link the “Inspection responses” evidence to its parent and UC-M06.01 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 07. Request idempotency

**Source delivery:** Bind retryable mutation requests to documented idempotency semantics.

**Source invariant:** Network or client retries cannot duplicate committed actions.

**Source negative case:** A retried create request launches a second guest.

**Source bounded quantities:** Deduplication entries and retention duration.

### UC-M06.01-C061 · Contract

**Original checklist item:** Specify request idempotency inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M06.01-C061-T01 · Scope statement:** Draft the operation boundary for “Request idempotency” within Machine-stable management API; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M06.01-C061-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Request idempotency”; record each producer, representation and missing-value meaning.
- [ ] **UC-M06.01-C061-T03 · Output inventory:** List the outputs of “Request idempotency” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M06.01-C061-T04 · Field dictionary:** Create a field-and-term dictionary for “Request idempotency”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M06.01-C061-T05 · Prerequisite contract:** Map “Request idempotency” to the source component prerequisites (UC-M01.02, UC-M05.04); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M06.01-C061-T06 · Authority map:** Identify who may produce, change and consume “Request idempotency”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M06.01-C061-T07 · Invariant clause:** Add a normative clause for “Request idempotency” that preserves “Network or client retries cannot duplicate committed actions”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M06.01-C061-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Request idempotency”; include the source counterexample “A retried create request launches a second guest” and the intended safe disposition.
- [ ] **UC-M06.01-C061-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Deduplication entries and retention duration” in the “Request idempotency” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M06.01-C061-T10 · Contract review:** Review the “Request idempotency” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M06.01-C062 · Delivery

**Original checklist item:** Bind retryable mutation requests to documented idempotency semantics.

- [ ] **UC-M06.01-C062-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Request idempotency”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M06.01-C062-T02 · Change plan:** Break the source delivery for “Request idempotency” into concrete edit targets and reviewable outputs; keep the UC-M06.01 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M06.01-C062-T03 · Core artifact:** Implement the smallest selected-profile change for “Request idempotency” that realizes this source instruction: Bind retryable mutation requests to documented idempotency semantics.
- [ ] **UC-M06.01-C062-T04 · Concrete realization:** Trace “Request idempotency” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M06.01-C062-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Request idempotency” needed to preserve “Network or client retries cannot duplicate committed actions”; record an enforcement gap where only a model exists.
- [ ] **UC-M06.01-C062-T06 · Dependency connection:** Connect the “Request idempotency” implementation to the shared management contract, CLI presentation and durable job registry; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M06.01-C062-T07 · Resource behavior:** Account for “Deduplication entries and retention duration” in “Request idempotency”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M06.01-C062-T08 · Delivery check:** Run the smallest real “Request idempotency” path and its adverse fixture “A retried create request launches a second guest”; retain actual output, state effects and final disposition.
- [ ] **UC-M06.01-C062-T09 · Patch review:** Review the “Request idempotency” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M06.01-C062-T10 · Delivery handoff:** Publish the “Request idempotency” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M06.01-C063 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Network or client retries cannot duplicate committed actions. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M06.01-C063-T01 · Named property:** Create a stable property/check name under this parent for “Request idempotency”; copy its required invariant exactly: “Network or client retries cannot duplicate committed actions”.
- [ ] **UC-M06.01-C063-T02 · Observable terms:** Define each term in the “Request idempotency” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M06.01-C063-T03 · Precondition set:** List the preconditions under which “Network or client retries cannot duplicate committed actions” must hold for “Request idempotency”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M06.01-C063-T04 · Transition coverage:** Map the “Request idempotency” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M06.01-C063-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Request idempotency”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M06.01-C063-T06 · Satisfying fixture:** Create a concrete “Request idempotency” case that satisfies “Network or client retries cannot duplicate committed actions”; record its expected observation before running the assertion or review.
- [ ] **UC-M06.01-C063-T07 · Violating fixture:** Create the source counterexample “A retried create request launches a second guest” for “Request idempotency”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M06.01-C063-T08 · Enforcement evidence:** Exercise the “Request idempotency” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M06.01-C063-T09 · Regression linkage:** Link the “Request idempotency” property to changes in the shared management contract, CLI presentation and durable job registry; record which dependency or contract changes require rerunning it.
- [ ] **UC-M06.01-C063-T10 · Property disposition:** Compare the satisfying and violating “Request idempotency” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M06.01-C064 · Integration

**Original checklist item:** Integrate request idempotency with the shared management contract, CLI presentation and durable job registry; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M06.01-C064-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Request idempotency” across the shared management contract, CLI presentation and durable job registry; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M06.01-C064-T02 · Field mapping:** Map every “Request idempotency” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M06.01-C064-T03 · Prerequisite identities:** Record the actual prerequisites for “Request idempotency” (source dependency list: UC-M01.02, UC-M05.04); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M06.01-C064-T04 · Ownership agreement:** Specify who owns “Request idempotency” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M06.01-C064-T05 · Handoff implementation:** Connect “Request idempotency” through the mapped seam using the real adapter or explicit specification reference; preserve “Network or client retries cannot duplicate committed actions” across the handoff.
- [ ] **UC-M06.01-C064-T06 · Absent-input case:** Omit one required “Request idempotency” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M06.01-C064-T07 · Stale-input case:** Supply an outdated “Request idempotency” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M06.01-C064-T08 · Incompatible-input case:** Supply an incompatible “Request idempotency” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M06.01-C064-T09 · Valid integration trace:** Run a valid “Request idempotency” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M06.01-C064-T10 · Seam review:** Reconcile the “Request idempotency” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M06.01-C065 · Valid-case test

**Original checklist item:** Run a valid-path fixture for request idempotency; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M06.01-C065-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Request idempotency” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M06.01-C065-T02 · Expected-result oracle:** Specify the “Request idempotency” expected result independently of the implementation output; include the property “Network or client retries cannot duplicate committed actions” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M06.01-C065-T03 · Fixture material:** Create the concrete “Request idempotency” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M06.01-C065-T04 · Target preparation:** Prepare the “Request idempotency” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M06.01-C065-T05 · Initial-state record:** Record the initial “Request idempotency” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M06.01-C065-T06 · Valid-path execution:** Execute the “Request idempotency” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M06.01-C065-T07 · Outcome comparison:** Compare every declared “Request idempotency” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M06.01-C065-T08 · State and bounds check:** Inspect the “Request idempotency” ownership/state effects and actual use of “Deduplication entries and retention duration”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M06.01-C065-T09 · Repeatability check:** Repeat the same “Request idempotency” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M06.01-C065-T10 · Positive evidence:** Attach the “Request idempotency” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M06.01-C066 · Negative test

**Original checklist item:** Negative case: A retried create request launches a second guest. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M06.01-C066-T01 · Adverse-case definition:** Create a test record for the exact “Request idempotency” source counterexample: “A retried create request launches a second guest”; state which precondition or invariant it challenges.
- [ ] **UC-M06.01-C066-T02 · Safe fixture boundary:** Define the contained test boundary for “Request idempotency”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M06.01-C066-T03 · Valid control:** Construct a valid “Request idempotency” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M06.01-C066-T04 · Minimal adverse input:** Derive the “Request idempotency” adverse fixture from the control with the smallest documented change needed to reproduce “A retried create request launches a second guest”; retain that change as reproducible data.
- [ ] **UC-M06.01-C066-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Request idempotency”; require “Network or client retries cannot duplicate committed actions” and forbid a false-success verdict.
- [ ] **UC-M06.01-C066-T06 · Adverse execution:** Exercise the “Request idempotency” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M06.01-C066-T07 · Effect inspection:** Inspect “Request idempotency” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M06.01-C066-T08 · Refusal versus failure:** Confirm the “Request idempotency” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M06.01-C066-T09 · Reset and retention:** Restore only the disposable “Request idempotency” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M06.01-C066-T10 · Negative regression:** Register the “Request idempotency” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M06.01-C067 · Change / failure test

**Original checklist item:** Exercise request idempotency when a client retries an operation after an uncertain long-running job response; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M06.01-C067-T01 · Scenario record:** Write the “Request idempotency” change/failure scenario exactly as supplied: a client retries an operation after an uncertain long-running job response; identify the property that must remain true: “Network or client retries cannot duplicate committed actions”.
- [ ] **UC-M06.01-C067-T02 · Baseline capture:** Create a known-valid “Request idempotency” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M06.01-C067-T03 · Injection map:** Locate the “Request idempotency” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M06.01-C067-T04 · Disposition oracle:** Define the legal intermediate and final “Request idempotency” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M06.01-C067-T05 · Controlled trigger:** Introduce the controlled “Request idempotency” scenario in the disposable fixture: a client retries an operation after an uncertain long-running job response; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M06.01-C067-T06 · Intermediate inspection:** Inspect the “Request idempotency” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M06.01-C067-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Request idempotency”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M06.01-C067-T08 · Stale-evidence cleanup:** Invalidate superseded “Request idempotency” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M06.01-C067-T09 · Repeat and compare:** Repeat the selected “Request idempotency” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M06.01-C067-T10 · Failure evidence:** Publish the “Request idempotency” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M06.01-C068 · Bounds

**Original checklist item:** Choose, document and test limits for deduplication entries and retention duration; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M06.01-C068-T01 · Quantity inventory:** Create a measurement inventory for “Request idempotency”: “Deduplication entries and retention duration”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M06.01-C068-T02 · Measurement method:** Choose how to observe each “Request idempotency” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M06.01-C068-T03 · Budget decision:** Select justified resource and input limits for “Request idempotency”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M06.01-C068-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Request idempotency” cases for “Deduplication entries and retention duration”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M06.01-C068-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Request idempotency” limit; preserve “Network or client retries cannot duplicate committed actions”.
- [ ] **UC-M06.01-C068-T06 · Normal measurement:** Run or review the normal “Request idempotency” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M06.01-C068-T07 · At-limit measurement:** Exercise the “Request idempotency” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M06.01-C068-T08 · Over-limit measurement:** Exercise the “Request idempotency” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M06.01-C068-T09 · Uncovered-scope report:** List the “Request idempotency” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M06.01-C068-T10 · Limit evidence:** Publish the selected “Request idempotency” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M06.01-C069 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for request idempotency with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M06.01-C069-T01 · Event inventory:** List the “Request idempotency” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M06.01-C069-T02 · Diagnostic schema:** Define nonsecret fields for “Request idempotency” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M06.01-C069-T03 · Failure mapping:** Map each documented “Request idempotency” refusal or error to a diagnostic outcome; include “A retried create request launches a second guest” and prohibit conversion into a success message.
- [ ] **UC-M06.01-C069-T04 · Emission path:** Add the “Request idempotency” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M06.01-C069-T05 · Redaction check:** Test “Request idempotency” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M06.01-C069-T06 · Output budget:** Set and exercise bounded “Request idempotency” message size, rate and retention compatible with “Deduplication entries and retention duration”; define truncation behavior that preserves the final reason.
- [ ] **UC-M06.01-C069-T07 · Success/refusal fixtures:** Capture “Request idempotency” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M06.01-C069-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Request idempotency” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M06.01-C069-T09 · Operator review:** Read the “Request idempotency” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M06.01-C069-T10 · Diagnostic evidence:** Publish redacted “Request idempotency” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M06.01-C070 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for request idempotency; label unexecuted checks as untested.

- [ ] **UC-M06.01-C070-T01 · Evidence inventory:** List the “Request idempotency” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M06.01-C070-T02 · Artifact references:** Record the exact “Request idempotency” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M06.01-C070-T03 · Fixture references:** Attach the “Request idempotency” fixture IDs, input identities and oracle definition; preserve the source counterexample “A retried create request launches a second guest” as a distinct evidence case.
- [ ] **UC-M06.01-C070-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Request idempotency”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M06.01-C070-T05 · Environment record:** Record the actual “Request idempotency” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M06.01-C070-T06 · Expected versus observed:** Pair every “Request idempotency” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M06.01-C070-T07 · Failure and limit records:** Attach “Request idempotency” change/failure and bounds evidence where required; include uncovered “Deduplication entries and retention duration” and unresolved violations of “Network or client retries cannot duplicate committed actions”.
- [ ] **UC-M06.01-C070-T08 · Evidence hygiene:** Check the “Request idempotency” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M06.01-C070-T09 · Reproduction review:** Have the “Request idempotency” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M06.01-C070-T10 · Acceptance linkage:** Link the “Request idempotency” evidence to its parent and UC-M06.01 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 08. Input validation

**Source delivery:** Validate types, required fields and sensitive unknown options before dispatch.

**Source invariant:** Malformed requests cannot reach backend execution.

**Source negative case:** A nested request supplies an unsupported security option.

**Source bounded quantities:** Request bytes, nesting and field count.

### UC-M06.01-C071 · Contract

**Original checklist item:** Specify input validation inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M06.01-C071-T01 · Scope statement:** Draft the operation boundary for “Input validation” within Machine-stable management API; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M06.01-C071-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Input validation”; record each producer, representation and missing-value meaning.
- [ ] **UC-M06.01-C071-T03 · Output inventory:** List the outputs of “Input validation” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M06.01-C071-T04 · Field dictionary:** Create a field-and-term dictionary for “Input validation”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M06.01-C071-T05 · Prerequisite contract:** Map “Input validation” to the source component prerequisites (UC-M01.02, UC-M05.04); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M06.01-C071-T06 · Authority map:** Identify who may produce, change and consume “Input validation”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M06.01-C071-T07 · Invariant clause:** Add a normative clause for “Input validation” that preserves “Malformed requests cannot reach backend execution”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M06.01-C071-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Input validation”; include the source counterexample “A nested request supplies an unsupported security option” and the intended safe disposition.
- [ ] **UC-M06.01-C071-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Request bytes, nesting and field count” in the “Input validation” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M06.01-C071-T10 · Contract review:** Review the “Input validation” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M06.01-C072 · Delivery

**Original checklist item:** Validate types, required fields and sensitive unknown options before dispatch.

- [ ] **UC-M06.01-C072-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Input validation”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M06.01-C072-T02 · Change plan:** Break the source delivery for “Input validation” into concrete edit targets and reviewable outputs; keep the UC-M06.01 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M06.01-C072-T03 · Core artifact:** Implement the smallest selected-profile change for “Input validation” that realizes this source instruction: Validate types, required fields and sensitive unknown options before dispatch.
- [ ] **UC-M06.01-C072-T04 · Concrete realization:** Trace “Input validation” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M06.01-C072-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Input validation” needed to preserve “Malformed requests cannot reach backend execution”; record an enforcement gap where only a model exists.
- [ ] **UC-M06.01-C072-T06 · Dependency connection:** Connect the “Input validation” implementation to the shared management contract, CLI presentation and durable job registry; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M06.01-C072-T07 · Resource behavior:** Account for “Request bytes, nesting and field count” in “Input validation”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M06.01-C072-T08 · Delivery check:** Run the smallest real “Input validation” path and its adverse fixture “A nested request supplies an unsupported security option”; retain actual output, state effects and final disposition.
- [ ] **UC-M06.01-C072-T09 · Patch review:** Review the “Input validation” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M06.01-C072-T10 · Delivery handoff:** Publish the “Input validation” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M06.01-C073 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Malformed requests cannot reach backend execution. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M06.01-C073-T01 · Named property:** Create a stable property/check name under this parent for “Input validation”; copy its required invariant exactly: “Malformed requests cannot reach backend execution”.
- [ ] **UC-M06.01-C073-T02 · Observable terms:** Define each term in the “Input validation” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M06.01-C073-T03 · Precondition set:** List the preconditions under which “Malformed requests cannot reach backend execution” must hold for “Input validation”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M06.01-C073-T04 · Transition coverage:** Map the “Input validation” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M06.01-C073-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Input validation”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M06.01-C073-T06 · Satisfying fixture:** Create a concrete “Input validation” case that satisfies “Malformed requests cannot reach backend execution”; record its expected observation before running the assertion or review.
- [ ] **UC-M06.01-C073-T07 · Violating fixture:** Create the source counterexample “A nested request supplies an unsupported security option” for “Input validation”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M06.01-C073-T08 · Enforcement evidence:** Exercise the “Input validation” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M06.01-C073-T09 · Regression linkage:** Link the “Input validation” property to changes in the shared management contract, CLI presentation and durable job registry; record which dependency or contract changes require rerunning it.
- [ ] **UC-M06.01-C073-T10 · Property disposition:** Compare the satisfying and violating “Input validation” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M06.01-C074 · Integration

**Original checklist item:** Integrate input validation with the shared management contract, CLI presentation and durable job registry; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M06.01-C074-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Input validation” across the shared management contract, CLI presentation and durable job registry; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M06.01-C074-T02 · Field mapping:** Map every “Input validation” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M06.01-C074-T03 · Prerequisite identities:** Record the actual prerequisites for “Input validation” (source dependency list: UC-M01.02, UC-M05.04); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M06.01-C074-T04 · Ownership agreement:** Specify who owns “Input validation” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M06.01-C074-T05 · Handoff implementation:** Connect “Input validation” through the mapped seam using the real adapter or explicit specification reference; preserve “Malformed requests cannot reach backend execution” across the handoff.
- [ ] **UC-M06.01-C074-T06 · Absent-input case:** Omit one required “Input validation” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M06.01-C074-T07 · Stale-input case:** Supply an outdated “Input validation” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M06.01-C074-T08 · Incompatible-input case:** Supply an incompatible “Input validation” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M06.01-C074-T09 · Valid integration trace:** Run a valid “Input validation” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M06.01-C074-T10 · Seam review:** Reconcile the “Input validation” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M06.01-C075 · Valid-case test

**Original checklist item:** Run a valid-path fixture for input validation; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M06.01-C075-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Input validation” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M06.01-C075-T02 · Expected-result oracle:** Specify the “Input validation” expected result independently of the implementation output; include the property “Malformed requests cannot reach backend execution” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M06.01-C075-T03 · Fixture material:** Create the concrete “Input validation” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M06.01-C075-T04 · Target preparation:** Prepare the “Input validation” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M06.01-C075-T05 · Initial-state record:** Record the initial “Input validation” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M06.01-C075-T06 · Valid-path execution:** Execute the “Input validation” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M06.01-C075-T07 · Outcome comparison:** Compare every declared “Input validation” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M06.01-C075-T08 · State and bounds check:** Inspect the “Input validation” ownership/state effects and actual use of “Request bytes, nesting and field count”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M06.01-C075-T09 · Repeatability check:** Repeat the same “Input validation” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M06.01-C075-T10 · Positive evidence:** Attach the “Input validation” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M06.01-C076 · Negative test

**Original checklist item:** Negative case: A nested request supplies an unsupported security option. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M06.01-C076-T01 · Adverse-case definition:** Create a test record for the exact “Input validation” source counterexample: “A nested request supplies an unsupported security option”; state which precondition or invariant it challenges.
- [ ] **UC-M06.01-C076-T02 · Safe fixture boundary:** Define the contained test boundary for “Input validation”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M06.01-C076-T03 · Valid control:** Construct a valid “Input validation” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M06.01-C076-T04 · Minimal adverse input:** Derive the “Input validation” adverse fixture from the control with the smallest documented change needed to reproduce “A nested request supplies an unsupported security option”; retain that change as reproducible data.
- [ ] **UC-M06.01-C076-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Input validation”; require “Malformed requests cannot reach backend execution” and forbid a false-success verdict.
- [ ] **UC-M06.01-C076-T06 · Adverse execution:** Exercise the “Input validation” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M06.01-C076-T07 · Effect inspection:** Inspect “Input validation” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M06.01-C076-T08 · Refusal versus failure:** Confirm the “Input validation” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M06.01-C076-T09 · Reset and retention:** Restore only the disposable “Input validation” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M06.01-C076-T10 · Negative regression:** Register the “Input validation” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M06.01-C077 · Change / failure test

**Original checklist item:** Exercise input validation when a client retries an operation after an uncertain long-running job response; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M06.01-C077-T01 · Scenario record:** Write the “Input validation” change/failure scenario exactly as supplied: a client retries an operation after an uncertain long-running job response; identify the property that must remain true: “Malformed requests cannot reach backend execution”.
- [ ] **UC-M06.01-C077-T02 · Baseline capture:** Create a known-valid “Input validation” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M06.01-C077-T03 · Injection map:** Locate the “Input validation” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M06.01-C077-T04 · Disposition oracle:** Define the legal intermediate and final “Input validation” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M06.01-C077-T05 · Controlled trigger:** Introduce the controlled “Input validation” scenario in the disposable fixture: a client retries an operation after an uncertain long-running job response; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M06.01-C077-T06 · Intermediate inspection:** Inspect the “Input validation” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M06.01-C077-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Input validation”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M06.01-C077-T08 · Stale-evidence cleanup:** Invalidate superseded “Input validation” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M06.01-C077-T09 · Repeat and compare:** Repeat the selected “Input validation” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M06.01-C077-T10 · Failure evidence:** Publish the “Input validation” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M06.01-C078 · Bounds

**Original checklist item:** Choose, document and test limits for request bytes, nesting and field count; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M06.01-C078-T01 · Quantity inventory:** Create a measurement inventory for “Input validation”: “Request bytes, nesting and field count”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M06.01-C078-T02 · Measurement method:** Choose how to observe each “Input validation” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M06.01-C078-T03 · Budget decision:** Select justified resource and input limits for “Input validation”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M06.01-C078-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Input validation” cases for “Request bytes, nesting and field count”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M06.01-C078-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Input validation” limit; preserve “Malformed requests cannot reach backend execution”.
- [ ] **UC-M06.01-C078-T06 · Normal measurement:** Run or review the normal “Input validation” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M06.01-C078-T07 · At-limit measurement:** Exercise the “Input validation” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M06.01-C078-T08 · Over-limit measurement:** Exercise the “Input validation” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M06.01-C078-T09 · Uncovered-scope report:** List the “Input validation” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M06.01-C078-T10 · Limit evidence:** Publish the selected “Input validation” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M06.01-C079 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for input validation with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M06.01-C079-T01 · Event inventory:** List the “Input validation” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M06.01-C079-T02 · Diagnostic schema:** Define nonsecret fields for “Input validation” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M06.01-C079-T03 · Failure mapping:** Map each documented “Input validation” refusal or error to a diagnostic outcome; include “A nested request supplies an unsupported security option” and prohibit conversion into a success message.
- [ ] **UC-M06.01-C079-T04 · Emission path:** Add the “Input validation” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M06.01-C079-T05 · Redaction check:** Test “Input validation” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M06.01-C079-T06 · Output budget:** Set and exercise bounded “Input validation” message size, rate and retention compatible with “Request bytes, nesting and field count”; define truncation behavior that preserves the final reason.
- [ ] **UC-M06.01-C079-T07 · Success/refusal fixtures:** Capture “Input validation” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M06.01-C079-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Input validation” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M06.01-C079-T09 · Operator review:** Read the “Input validation” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M06.01-C079-T10 · Diagnostic evidence:** Publish redacted “Input validation” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M06.01-C080 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for input validation; label unexecuted checks as untested.

- [ ] **UC-M06.01-C080-T01 · Evidence inventory:** List the “Input validation” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M06.01-C080-T02 · Artifact references:** Record the exact “Input validation” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M06.01-C080-T03 · Fixture references:** Attach the “Input validation” fixture IDs, input identities and oracle definition; preserve the source counterexample “A nested request supplies an unsupported security option” as a distinct evidence case.
- [ ] **UC-M06.01-C080-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Input validation”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M06.01-C080-T05 · Environment record:** Record the actual “Input validation” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M06.01-C080-T06 · Expected versus observed:** Pair every “Input validation” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M06.01-C080-T07 · Failure and limit records:** Attach “Input validation” change/failure and bounds evidence where required; include uncovered “Request bytes, nesting and field count” and unresolved violations of “Malformed requests cannot reach backend execution”.
- [ ] **UC-M06.01-C080-T08 · Evidence hygiene:** Check the “Input validation” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M06.01-C080-T09 · Reproduction review:** Have the “Input validation” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M06.01-C080-T10 · Acceptance linkage:** Link the “Input validation” evidence to its parent and UC-M06.01 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 09. Local and optional remote profiles

**Source delivery:** Specify transport exposure without enabling remote access by default.

**Source invariant:** The offline profile does not gain a remote listener implicitly.

**Source negative case:** Starting the API exposes an unauthenticated network endpoint.

**Source bounded quantities:** Listeners, connections and idle timeout.

### UC-M06.01-C081 · Contract

**Original checklist item:** Specify local and optional remote profiles inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M06.01-C081-T01 · Scope statement:** Draft the operation boundary for “Local and optional remote profiles” within Machine-stable management API; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M06.01-C081-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Local and optional remote profiles”; record each producer, representation and missing-value meaning.
- [ ] **UC-M06.01-C081-T03 · Output inventory:** List the outputs of “Local and optional remote profiles” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M06.01-C081-T04 · Field dictionary:** Create a field-and-term dictionary for “Local and optional remote profiles”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M06.01-C081-T05 · Prerequisite contract:** Map “Local and optional remote profiles” to the source component prerequisites (UC-M01.02, UC-M05.04); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M06.01-C081-T06 · Authority map:** Identify who may produce, change and consume “Local and optional remote profiles”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M06.01-C081-T07 · Invariant clause:** Add a normative clause for “Local and optional remote profiles” that preserves “The offline profile does not gain a remote listener implicitly”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M06.01-C081-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Local and optional remote profiles”; include the source counterexample “Starting the API exposes an unauthenticated network endpoint” and the intended safe disposition.
- [ ] **UC-M06.01-C081-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Listeners, connections and idle timeout” in the “Local and optional remote profiles” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M06.01-C081-T10 · Contract review:** Review the “Local and optional remote profiles” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M06.01-C082 · Delivery

**Original checklist item:** Specify transport exposure without enabling remote access by default.

- [ ] **UC-M06.01-C082-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Local and optional remote profiles”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M06.01-C082-T02 · Change plan:** Break the source delivery for “Local and optional remote profiles” into concrete edit targets and reviewable outputs; keep the UC-M06.01 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M06.01-C082-T03 · Core artifact:** Create the “Local and optional remote profiles” model, schema or inventory that realizes this source instruction: Specify transport exposure without enabling remote access by default.
- [ ] **UC-M06.01-C082-T04 · Concrete realization:** Populate “Local and optional remote profiles” with one concrete worked case; map every required entity or field to its source and flag any unmapped entry.
- [ ] **UC-M06.01-C082-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Local and optional remote profiles” needed to preserve “The offline profile does not gain a remote listener implicitly”; record an enforcement gap where only a model exists.
- [ ] **UC-M06.01-C082-T06 · Dependency connection:** Connect the “Local and optional remote profiles” implementation to the shared management contract, CLI presentation and durable job registry; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M06.01-C082-T07 · Resource behavior:** Account for “Listeners, connections and idle timeout” in “Local and optional remote profiles”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M06.01-C082-T08 · Delivery check:** Run the smallest real “Local and optional remote profiles” path and its adverse fixture “Starting the API exposes an unauthenticated network endpoint”; retain actual output, state effects and final disposition.
- [ ] **UC-M06.01-C082-T09 · Patch review:** Review the “Local and optional remote profiles” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M06.01-C082-T10 · Delivery handoff:** Publish the “Local and optional remote profiles” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M06.01-C083 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: The offline profile does not gain a remote listener implicitly. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M06.01-C083-T01 · Named property:** Create a stable property/check name under this parent for “Local and optional remote profiles”; copy its required invariant exactly: “The offline profile does not gain a remote listener implicitly”.
- [ ] **UC-M06.01-C083-T02 · Observable terms:** Define each term in the “Local and optional remote profiles” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M06.01-C083-T03 · Precondition set:** List the preconditions under which “The offline profile does not gain a remote listener implicitly” must hold for “Local and optional remote profiles”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M06.01-C083-T04 · Transition coverage:** Map the “Local and optional remote profiles” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M06.01-C083-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Local and optional remote profiles”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M06.01-C083-T06 · Satisfying fixture:** Create a concrete “Local and optional remote profiles” case that satisfies “The offline profile does not gain a remote listener implicitly”; record its expected observation before running the assertion or review.
- [ ] **UC-M06.01-C083-T07 · Violating fixture:** Create the source counterexample “Starting the API exposes an unauthenticated network endpoint” for “Local and optional remote profiles”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M06.01-C083-T08 · Enforcement evidence:** Exercise the “Local and optional remote profiles” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M06.01-C083-T09 · Regression linkage:** Link the “Local and optional remote profiles” property to changes in the shared management contract, CLI presentation and durable job registry; record which dependency or contract changes require rerunning it.
- [ ] **UC-M06.01-C083-T10 · Property disposition:** Compare the satisfying and violating “Local and optional remote profiles” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M06.01-C084 · Integration

**Original checklist item:** Integrate local and optional remote profiles with the shared management contract, CLI presentation and durable job registry; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M06.01-C084-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Local and optional remote profiles” across the shared management contract, CLI presentation and durable job registry; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M06.01-C084-T02 · Field mapping:** Map every “Local and optional remote profiles” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M06.01-C084-T03 · Prerequisite identities:** Record the actual prerequisites for “Local and optional remote profiles” (source dependency list: UC-M01.02, UC-M05.04); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M06.01-C084-T04 · Ownership agreement:** Specify who owns “Local and optional remote profiles” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M06.01-C084-T05 · Handoff implementation:** Connect “Local and optional remote profiles” through the mapped seam using the real adapter or explicit specification reference; preserve “The offline profile does not gain a remote listener implicitly” across the handoff.
- [ ] **UC-M06.01-C084-T06 · Absent-input case:** Omit one required “Local and optional remote profiles” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M06.01-C084-T07 · Stale-input case:** Supply an outdated “Local and optional remote profiles” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M06.01-C084-T08 · Incompatible-input case:** Supply an incompatible “Local and optional remote profiles” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M06.01-C084-T09 · Valid integration trace:** Run a valid “Local and optional remote profiles” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M06.01-C084-T10 · Seam review:** Reconcile the “Local and optional remote profiles” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M06.01-C085 · Valid-case test

**Original checklist item:** Run a valid-path fixture for local and optional remote profiles; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M06.01-C085-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Local and optional remote profiles” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M06.01-C085-T02 · Expected-result oracle:** Specify the “Local and optional remote profiles” expected result independently of the implementation output; include the property “The offline profile does not gain a remote listener implicitly” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M06.01-C085-T03 · Fixture material:** Create the concrete “Local and optional remote profiles” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M06.01-C085-T04 · Target preparation:** Prepare the “Local and optional remote profiles” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M06.01-C085-T05 · Initial-state record:** Record the initial “Local and optional remote profiles” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M06.01-C085-T06 · Valid-path execution:** Execute the “Local and optional remote profiles” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M06.01-C085-T07 · Outcome comparison:** Compare every declared “Local and optional remote profiles” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M06.01-C085-T08 · State and bounds check:** Inspect the “Local and optional remote profiles” ownership/state effects and actual use of “Listeners, connections and idle timeout”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M06.01-C085-T09 · Repeatability check:** Repeat the same “Local and optional remote profiles” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M06.01-C085-T10 · Positive evidence:** Attach the “Local and optional remote profiles” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M06.01-C086 · Negative test

**Original checklist item:** Negative case: Starting the API exposes an unauthenticated network endpoint. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M06.01-C086-T01 · Adverse-case definition:** Create a test record for the exact “Local and optional remote profiles” source counterexample: “Starting the API exposes an unauthenticated network endpoint”; state which precondition or invariant it challenges.
- [ ] **UC-M06.01-C086-T02 · Safe fixture boundary:** Define the contained test boundary for “Local and optional remote profiles”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M06.01-C086-T03 · Valid control:** Construct a valid “Local and optional remote profiles” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M06.01-C086-T04 · Minimal adverse input:** Derive the “Local and optional remote profiles” adverse fixture from the control with the smallest documented change needed to reproduce “Starting the API exposes an unauthenticated network endpoint”; retain that change as reproducible data.
- [ ] **UC-M06.01-C086-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Local and optional remote profiles”; require “The offline profile does not gain a remote listener implicitly” and forbid a false-success verdict.
- [ ] **UC-M06.01-C086-T06 · Adverse execution:** Exercise the “Local and optional remote profiles” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M06.01-C086-T07 · Effect inspection:** Inspect “Local and optional remote profiles” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M06.01-C086-T08 · Refusal versus failure:** Confirm the “Local and optional remote profiles” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M06.01-C086-T09 · Reset and retention:** Restore only the disposable “Local and optional remote profiles” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M06.01-C086-T10 · Negative regression:** Register the “Local and optional remote profiles” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M06.01-C087 · Change / failure test

**Original checklist item:** Exercise local and optional remote profiles when a client retries an operation after an uncertain long-running job response; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M06.01-C087-T01 · Scenario record:** Write the “Local and optional remote profiles” change/failure scenario exactly as supplied: a client retries an operation after an uncertain long-running job response; identify the property that must remain true: “The offline profile does not gain a remote listener implicitly”.
- [ ] **UC-M06.01-C087-T02 · Baseline capture:** Create a known-valid “Local and optional remote profiles” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M06.01-C087-T03 · Injection map:** Locate the “Local and optional remote profiles” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M06.01-C087-T04 · Disposition oracle:** Define the legal intermediate and final “Local and optional remote profiles” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M06.01-C087-T05 · Controlled trigger:** Introduce the controlled “Local and optional remote profiles” scenario in the disposable fixture: a client retries an operation after an uncertain long-running job response; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M06.01-C087-T06 · Intermediate inspection:** Inspect the “Local and optional remote profiles” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M06.01-C087-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Local and optional remote profiles”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M06.01-C087-T08 · Stale-evidence cleanup:** Invalidate superseded “Local and optional remote profiles” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M06.01-C087-T09 · Repeat and compare:** Repeat the selected “Local and optional remote profiles” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M06.01-C087-T10 · Failure evidence:** Publish the “Local and optional remote profiles” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M06.01-C088 · Bounds

**Original checklist item:** Choose, document and test limits for listeners, connections and idle timeout; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M06.01-C088-T01 · Quantity inventory:** Create a measurement inventory for “Local and optional remote profiles”: “Listeners, connections and idle timeout”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M06.01-C088-T02 · Measurement method:** Choose how to observe each “Local and optional remote profiles” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M06.01-C088-T03 · Budget decision:** Select justified resource and input limits for “Local and optional remote profiles”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M06.01-C088-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Local and optional remote profiles” cases for “Listeners, connections and idle timeout”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M06.01-C088-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Local and optional remote profiles” limit; preserve “The offline profile does not gain a remote listener implicitly”.
- [ ] **UC-M06.01-C088-T06 · Normal measurement:** Run or review the normal “Local and optional remote profiles” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M06.01-C088-T07 · At-limit measurement:** Exercise the “Local and optional remote profiles” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M06.01-C088-T08 · Over-limit measurement:** Exercise the “Local and optional remote profiles” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M06.01-C088-T09 · Uncovered-scope report:** List the “Local and optional remote profiles” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M06.01-C088-T10 · Limit evidence:** Publish the selected “Local and optional remote profiles” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M06.01-C089 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for local and optional remote profiles with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M06.01-C089-T01 · Event inventory:** List the “Local and optional remote profiles” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M06.01-C089-T02 · Diagnostic schema:** Define nonsecret fields for “Local and optional remote profiles” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M06.01-C089-T03 · Failure mapping:** Map each documented “Local and optional remote profiles” refusal or error to a diagnostic outcome; include “Starting the API exposes an unauthenticated network endpoint” and prohibit conversion into a success message.
- [ ] **UC-M06.01-C089-T04 · Emission path:** Add the “Local and optional remote profiles” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M06.01-C089-T05 · Redaction check:** Test “Local and optional remote profiles” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M06.01-C089-T06 · Output budget:** Set and exercise bounded “Local and optional remote profiles” message size, rate and retention compatible with “Listeners, connections and idle timeout”; define truncation behavior that preserves the final reason.
- [ ] **UC-M06.01-C089-T07 · Success/refusal fixtures:** Capture “Local and optional remote profiles” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M06.01-C089-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Local and optional remote profiles” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M06.01-C089-T09 · Operator review:** Read the “Local and optional remote profiles” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M06.01-C089-T10 · Diagnostic evidence:** Publish redacted “Local and optional remote profiles” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M06.01-C090 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for local and optional remote profiles; label unexecuted checks as untested.

- [ ] **UC-M06.01-C090-T01 · Evidence inventory:** List the “Local and optional remote profiles” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M06.01-C090-T02 · Artifact references:** Record the exact “Local and optional remote profiles” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M06.01-C090-T03 · Fixture references:** Attach the “Local and optional remote profiles” fixture IDs, input identities and oracle definition; preserve the source counterexample “Starting the API exposes an unauthenticated network endpoint” as a distinct evidence case.
- [ ] **UC-M06.01-C090-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Local and optional remote profiles”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M06.01-C090-T05 · Environment record:** Record the actual “Local and optional remote profiles” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M06.01-C090-T06 · Expected versus observed:** Pair every “Local and optional remote profiles” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M06.01-C090-T07 · Failure and limit records:** Attach “Local and optional remote profiles” change/failure and bounds evidence where required; include uncovered “Listeners, connections and idle timeout” and unresolved violations of “The offline profile does not gain a remote listener implicitly”.
- [ ] **UC-M06.01-C090-T08 · Evidence hygiene:** Check the “Local and optional remote profiles” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M06.01-C090-T09 · Reproduction review:** Have the “Local and optional remote profiles” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M06.01-C090-T10 · Acceptance linkage:** Link the “Local and optional remote profiles” evidence to its parent and UC-M06.01 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 10. Contract acceptance suite

**Source delivery:** Test CLI/API parity, jobs, errors and version refusal with executable fixtures.

**Source invariant:** Every claimed operation has observable machine-contract evidence.

**Source negative case:** A new endpoint ships without incompatible-version coverage.

**Source bounded quantities:** Fixture count and supported client versions.

### UC-M06.01-C091 · Contract

**Original checklist item:** Specify contract acceptance suite inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M06.01-C091-T01 · Scope statement:** Draft the operation boundary for “Contract acceptance suite” within Machine-stable management API; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M06.01-C091-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Contract acceptance suite”; record each producer, representation and missing-value meaning.
- [ ] **UC-M06.01-C091-T03 · Output inventory:** List the outputs of “Contract acceptance suite” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M06.01-C091-T04 · Field dictionary:** Create a field-and-term dictionary for “Contract acceptance suite”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M06.01-C091-T05 · Prerequisite contract:** Map “Contract acceptance suite” to the source component prerequisites (UC-M01.02, UC-M05.04); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M06.01-C091-T06 · Authority map:** Identify who may produce, change and consume “Contract acceptance suite”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M06.01-C091-T07 · Invariant clause:** Add a normative clause for “Contract acceptance suite” that preserves “Every claimed operation has observable machine-contract evidence”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M06.01-C091-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Contract acceptance suite”; include the source counterexample “A new endpoint ships without incompatible-version coverage” and the intended safe disposition.
- [ ] **UC-M06.01-C091-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Fixture count and supported client versions” in the “Contract acceptance suite” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M06.01-C091-T10 · Contract review:** Review the “Contract acceptance suite” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M06.01-C092 · Delivery

**Original checklist item:** Test CLI/API parity, jobs, errors and version refusal with executable fixtures.

- [ ] **UC-M06.01-C092-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Contract acceptance suite”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M06.01-C092-T02 · Change plan:** Break the source delivery for “Contract acceptance suite” into concrete edit targets and reviewable outputs; keep the UC-M06.01 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M06.01-C092-T03 · Core artifact:** Create the “Contract acceptance suite” fixture or harness for this source instruction: Test CLI/API parity, jobs, errors and version refusal with executable fixtures.
- [ ] **UC-M06.01-C092-T04 · Concrete realization:** Connect the “Contract acceptance suite” harness to its actual intended target, set the expected oracle before running it, and distinguish a mock/control run from a target run.
- [ ] **UC-M06.01-C092-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Contract acceptance suite” needed to preserve “Every claimed operation has observable machine-contract evidence”; record an enforcement gap where only a model exists.
- [ ] **UC-M06.01-C092-T06 · Dependency connection:** Connect the “Contract acceptance suite” implementation to the shared management contract, CLI presentation and durable job registry; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M06.01-C092-T07 · Resource behavior:** Account for “Fixture count and supported client versions” in “Contract acceptance suite”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M06.01-C092-T08 · Delivery check:** Run the smallest real “Contract acceptance suite” path and its adverse fixture “A new endpoint ships without incompatible-version coverage”; retain actual output, state effects and final disposition.
- [ ] **UC-M06.01-C092-T09 · Patch review:** Review the “Contract acceptance suite” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M06.01-C092-T10 · Delivery handoff:** Publish the “Contract acceptance suite” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M06.01-C093 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Every claimed operation has observable machine-contract evidence. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M06.01-C093-T01 · Named property:** Create a stable property/check name under this parent for “Contract acceptance suite”; copy its required invariant exactly: “Every claimed operation has observable machine-contract evidence”.
- [ ] **UC-M06.01-C093-T02 · Observable terms:** Define each term in the “Contract acceptance suite” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M06.01-C093-T03 · Precondition set:** List the preconditions under which “Every claimed operation has observable machine-contract evidence” must hold for “Contract acceptance suite”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M06.01-C093-T04 · Transition coverage:** Map the “Contract acceptance suite” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M06.01-C093-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Contract acceptance suite”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M06.01-C093-T06 · Satisfying fixture:** Create a concrete “Contract acceptance suite” case that satisfies “Every claimed operation has observable machine-contract evidence”; record its expected observation before running the assertion or review.
- [ ] **UC-M06.01-C093-T07 · Violating fixture:** Create the source counterexample “A new endpoint ships without incompatible-version coverage” for “Contract acceptance suite”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M06.01-C093-T08 · Enforcement evidence:** Exercise the “Contract acceptance suite” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M06.01-C093-T09 · Regression linkage:** Link the “Contract acceptance suite” property to changes in the shared management contract, CLI presentation and durable job registry; record which dependency or contract changes require rerunning it.
- [ ] **UC-M06.01-C093-T10 · Property disposition:** Compare the satisfying and violating “Contract acceptance suite” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M06.01-C094 · Integration

**Original checklist item:** Integrate contract acceptance suite with the shared management contract, CLI presentation and durable job registry; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M06.01-C094-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Contract acceptance suite” across the shared management contract, CLI presentation and durable job registry; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M06.01-C094-T02 · Field mapping:** Map every “Contract acceptance suite” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M06.01-C094-T03 · Prerequisite identities:** Record the actual prerequisites for “Contract acceptance suite” (source dependency list: UC-M01.02, UC-M05.04); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M06.01-C094-T04 · Ownership agreement:** Specify who owns “Contract acceptance suite” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M06.01-C094-T05 · Handoff implementation:** Connect “Contract acceptance suite” through the mapped seam using the real adapter or explicit specification reference; preserve “Every claimed operation has observable machine-contract evidence” across the handoff.
- [ ] **UC-M06.01-C094-T06 · Absent-input case:** Omit one required “Contract acceptance suite” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M06.01-C094-T07 · Stale-input case:** Supply an outdated “Contract acceptance suite” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M06.01-C094-T08 · Incompatible-input case:** Supply an incompatible “Contract acceptance suite” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M06.01-C094-T09 · Valid integration trace:** Run a valid “Contract acceptance suite” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M06.01-C094-T10 · Seam review:** Reconcile the “Contract acceptance suite” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M06.01-C095 · Valid-case test

**Original checklist item:** Run a valid-path fixture for contract acceptance suite; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M06.01-C095-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Contract acceptance suite” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M06.01-C095-T02 · Expected-result oracle:** Specify the “Contract acceptance suite” expected result independently of the implementation output; include the property “Every claimed operation has observable machine-contract evidence” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M06.01-C095-T03 · Fixture material:** Create the concrete “Contract acceptance suite” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M06.01-C095-T04 · Target preparation:** Prepare the “Contract acceptance suite” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M06.01-C095-T05 · Initial-state record:** Record the initial “Contract acceptance suite” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M06.01-C095-T06 · Valid-path execution:** Execute the “Contract acceptance suite” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M06.01-C095-T07 · Outcome comparison:** Compare every declared “Contract acceptance suite” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M06.01-C095-T08 · State and bounds check:** Inspect the “Contract acceptance suite” ownership/state effects and actual use of “Fixture count and supported client versions”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M06.01-C095-T09 · Repeatability check:** Repeat the same “Contract acceptance suite” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M06.01-C095-T10 · Positive evidence:** Attach the “Contract acceptance suite” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M06.01-C096 · Negative test

**Original checklist item:** Negative case: A new endpoint ships without incompatible-version coverage. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M06.01-C096-T01 · Adverse-case definition:** Create a test record for the exact “Contract acceptance suite” source counterexample: “A new endpoint ships without incompatible-version coverage”; state which precondition or invariant it challenges.
- [ ] **UC-M06.01-C096-T02 · Safe fixture boundary:** Define the contained test boundary for “Contract acceptance suite”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M06.01-C096-T03 · Valid control:** Construct a valid “Contract acceptance suite” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M06.01-C096-T04 · Minimal adverse input:** Derive the “Contract acceptance suite” adverse fixture from the control with the smallest documented change needed to reproduce “A new endpoint ships without incompatible-version coverage”; retain that change as reproducible data.
- [ ] **UC-M06.01-C096-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Contract acceptance suite”; require “Every claimed operation has observable machine-contract evidence” and forbid a false-success verdict.
- [ ] **UC-M06.01-C096-T06 · Adverse execution:** Exercise the “Contract acceptance suite” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M06.01-C096-T07 · Effect inspection:** Inspect “Contract acceptance suite” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M06.01-C096-T08 · Refusal versus failure:** Confirm the “Contract acceptance suite” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M06.01-C096-T09 · Reset and retention:** Restore only the disposable “Contract acceptance suite” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M06.01-C096-T10 · Negative regression:** Register the “Contract acceptance suite” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M06.01-C097 · Change / failure test

**Original checklist item:** Exercise contract acceptance suite when a client retries an operation after an uncertain long-running job response; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M06.01-C097-T01 · Scenario record:** Write the “Contract acceptance suite” change/failure scenario exactly as supplied: a client retries an operation after an uncertain long-running job response; identify the property that must remain true: “Every claimed operation has observable machine-contract evidence”.
- [ ] **UC-M06.01-C097-T02 · Baseline capture:** Create a known-valid “Contract acceptance suite” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M06.01-C097-T03 · Injection map:** Locate the “Contract acceptance suite” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M06.01-C097-T04 · Disposition oracle:** Define the legal intermediate and final “Contract acceptance suite” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M06.01-C097-T05 · Controlled trigger:** Introduce the controlled “Contract acceptance suite” scenario in the disposable fixture: a client retries an operation after an uncertain long-running job response; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M06.01-C097-T06 · Intermediate inspection:** Inspect the “Contract acceptance suite” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M06.01-C097-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Contract acceptance suite”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M06.01-C097-T08 · Stale-evidence cleanup:** Invalidate superseded “Contract acceptance suite” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M06.01-C097-T09 · Repeat and compare:** Repeat the selected “Contract acceptance suite” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M06.01-C097-T10 · Failure evidence:** Publish the “Contract acceptance suite” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M06.01-C098 · Bounds

**Original checklist item:** Choose, document and test limits for fixture count and supported client versions; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M06.01-C098-T01 · Quantity inventory:** Create a measurement inventory for “Contract acceptance suite”: “Fixture count and supported client versions”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M06.01-C098-T02 · Measurement method:** Choose how to observe each “Contract acceptance suite” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M06.01-C098-T03 · Budget decision:** Select justified resource and input limits for “Contract acceptance suite”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M06.01-C098-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Contract acceptance suite” cases for “Fixture count and supported client versions”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M06.01-C098-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Contract acceptance suite” limit; preserve “Every claimed operation has observable machine-contract evidence”.
- [ ] **UC-M06.01-C098-T06 · Normal measurement:** Run or review the normal “Contract acceptance suite” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M06.01-C098-T07 · At-limit measurement:** Exercise the “Contract acceptance suite” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M06.01-C098-T08 · Over-limit measurement:** Exercise the “Contract acceptance suite” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M06.01-C098-T09 · Uncovered-scope report:** List the “Contract acceptance suite” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M06.01-C098-T10 · Limit evidence:** Publish the selected “Contract acceptance suite” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M06.01-C099 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for contract acceptance suite with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M06.01-C099-T01 · Event inventory:** List the “Contract acceptance suite” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M06.01-C099-T02 · Diagnostic schema:** Define nonsecret fields for “Contract acceptance suite” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M06.01-C099-T03 · Failure mapping:** Map each documented “Contract acceptance suite” refusal or error to a diagnostic outcome; include “A new endpoint ships without incompatible-version coverage” and prohibit conversion into a success message.
- [ ] **UC-M06.01-C099-T04 · Emission path:** Add the “Contract acceptance suite” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M06.01-C099-T05 · Redaction check:** Test “Contract acceptance suite” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M06.01-C099-T06 · Output budget:** Set and exercise bounded “Contract acceptance suite” message size, rate and retention compatible with “Fixture count and supported client versions”; define truncation behavior that preserves the final reason.
- [ ] **UC-M06.01-C099-T07 · Success/refusal fixtures:** Capture “Contract acceptance suite” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M06.01-C099-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Contract acceptance suite” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M06.01-C099-T09 · Operator review:** Read the “Contract acceptance suite” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M06.01-C099-T10 · Diagnostic evidence:** Publish redacted “Contract acceptance suite” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M06.01-C100 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for contract acceptance suite; label unexecuted checks as untested.

- [ ] **UC-M06.01-C100-T01 · Evidence inventory:** List the “Contract acceptance suite” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M06.01-C100-T02 · Artifact references:** Record the exact “Contract acceptance suite” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M06.01-C100-T03 · Fixture references:** Attach the “Contract acceptance suite” fixture IDs, input identities and oracle definition; preserve the source counterexample “A new endpoint ships without incompatible-version coverage” as a distinct evidence case.
- [ ] **UC-M06.01-C100-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Contract acceptance suite”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M06.01-C100-T05 · Environment record:** Record the actual “Contract acceptance suite” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M06.01-C100-T06 · Expected versus observed:** Pair every “Contract acceptance suite” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M06.01-C100-T07 · Failure and limit records:** Attach “Contract acceptance suite” change/failure and bounds evidence where required; include uncovered “Fixture count and supported client versions” and unresolved violations of “Every claimed operation has observable machine-contract evidence”.
- [ ] **UC-M06.01-C100-T08 · Evidence hygiene:** Check the “Contract acceptance suite” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M06.01-C100-T09 · Reproduction review:** Have the “Contract acceptance suite” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M06.01-C100-T10 · Acceptance linkage:** Link the “Contract acceptance suite” evidence to its parent and UC-M06.01 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

