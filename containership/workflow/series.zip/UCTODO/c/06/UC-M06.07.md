# UC-M06.07 — Secret storage and injection boundary

**To-Do Pack 2.0.0 · Baseline UC-2.2.0 · 100 parent checks × 10 subtasks = 1,000 to-dos**

[Master index](../../INDEX.md) · [Workstream index](../../w/06.md)

| Field | Preserved source value |
|---|---|
| Workstream | 06. Control plane, identity and policy |
| Milestone | C |
| Priority | P0 |
| Source assessment | MISSING |
| Scope | core or selected profile |
| Dependencies | [UC-M03.07](../03/UC-M03.07.md), [UC-M06.04](../06/UC-M06.04.md) |
| Source checklist pack | 1.0.0 |
| Original reference labels | [S4], [S6]. |

## Original requirement

Keep secrets out of cargo, TIFFs, manifests, process arguments and public logs; supply scoped short-lived handles at runtime.

**Original acceptance criterion:** A redaction test finds no test secret in emitted artifacts, logs, snapshots or another tenant's state.

**Source trace:** Original checklist `UC100/c/06/UC-M06.07.md` inside [s/checklists.zip](../../s/checklists.zip); exact parent records in [data/parents.jsonl](../../data/parents.jsonl). Original roadmap lines 590–600 are preserved in [s/roadmap.md](../../s/roadmap.md).

## How to use these lists

Every parent statement below is preserved verbatim. Its ten child tasks are proposed decomposition, not implemented capabilities or executed tests. Child IDs append `-T01` through `-T10` to the original parent ID. All begin unchecked / `TODO`. Design/review evidence does not establish runtime enforcement; observe the actual selected target where the parent requires it.

The source dependency graph and selected release profile determine applicability. The numbered child sequence is a local working order, not an added hard dependency graph. An unselected optional feature needs a recorded not-applicable rationale; missing prerequisites for selected work remain blockers. Numerical budgets, backends and trust mechanisms remain decisions unless fixed by the source. Test hostile cases only with synthetic inputs in authorized disposable environments.

## 01. Secret inventory

**Source delivery:** Identify credentials and sensitive runtime values requiring secret treatment.

**Source invariant:** Secrets are classified before choosing storage or transport.

**Source negative case:** A runtime token is treated as ordinary cargo metadata.

**Source bounded quantities:** Secret types and inventory coverage.

### UC-M06.07-C001 · Contract

**Original checklist item:** Specify secret inventory inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M06.07-C001-T01 · Scope statement:** Draft the operation boundary for “Secret inventory” within Secret storage and injection boundary; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M06.07-C001-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Secret inventory”; record each producer, representation and missing-value meaning.
- [ ] **UC-M06.07-C001-T03 · Output inventory:** List the outputs of “Secret inventory” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M06.07-C001-T04 · Field dictionary:** Create a field-and-term dictionary for “Secret inventory”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M06.07-C001-T05 · Prerequisite contract:** Map “Secret inventory” to the source component prerequisites (UC-M03.07, UC-M06.04); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M06.07-C001-T06 · Authority map:** Identify who may produce, change and consume “Secret inventory”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M06.07-C001-T07 · Invariant clause:** Add a normative clause for “Secret inventory” that preserves “Secrets are classified before choosing storage or transport”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M06.07-C001-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Secret inventory”; include the source counterexample “A runtime token is treated as ordinary cargo metadata” and the intended safe disposition.
- [ ] **UC-M06.07-C001-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Secret types and inventory coverage” in the “Secret inventory” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M06.07-C001-T10 · Contract review:** Review the “Secret inventory” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M06.07-C002 · Delivery

**Original checklist item:** Identify credentials and sensitive runtime values requiring secret treatment.

- [ ] **UC-M06.07-C002-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Secret inventory”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M06.07-C002-T02 · Change plan:** Break the source delivery for “Secret inventory” into concrete edit targets and reviewable outputs; keep the UC-M06.07 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M06.07-C002-T03 · Core artifact:** Create the “Secret inventory” model, schema or inventory that realizes this source instruction: Identify credentials and sensitive runtime values requiring secret treatment.
- [ ] **UC-M06.07-C002-T04 · Concrete realization:** Populate “Secret inventory” with one concrete worked case; map every required entity or field to its source and flag any unmapped entry.
- [ ] **UC-M06.07-C002-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Secret inventory” needed to preserve “Secrets are classified before choosing storage or transport”; record an enforcement gap where only a model exists.
- [ ] **UC-M06.07-C002-T06 · Dependency connection:** Connect the “Secret inventory” implementation to approved secret storage, scoped runtime handles and guest/broker injection; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M06.07-C002-T07 · Resource behavior:** Account for “Secret types and inventory coverage” in “Secret inventory”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M06.07-C002-T08 · Delivery check:** Run the smallest real “Secret inventory” path and its adverse fixture “A runtime token is treated as ordinary cargo metadata”; retain actual output, state effects and final disposition.
- [ ] **UC-M06.07-C002-T09 · Patch review:** Review the “Secret inventory” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M06.07-C002-T10 · Delivery handoff:** Publish the “Secret inventory” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M06.07-C003 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Secrets are classified before choosing storage or transport. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M06.07-C003-T01 · Named property:** Create a stable property/check name under this parent for “Secret inventory”; copy its required invariant exactly: “Secrets are classified before choosing storage or transport”.
- [ ] **UC-M06.07-C003-T02 · Observable terms:** Define each term in the “Secret inventory” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M06.07-C003-T03 · Precondition set:** List the preconditions under which “Secrets are classified before choosing storage or transport” must hold for “Secret inventory”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M06.07-C003-T04 · Transition coverage:** Map the “Secret inventory” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M06.07-C003-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Secret inventory”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M06.07-C003-T06 · Satisfying fixture:** Create a concrete “Secret inventory” case that satisfies “Secrets are classified before choosing storage or transport”; record its expected observation before running the assertion or review.
- [ ] **UC-M06.07-C003-T07 · Violating fixture:** Create the source counterexample “A runtime token is treated as ordinary cargo metadata” for “Secret inventory”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M06.07-C003-T08 · Enforcement evidence:** Exercise the “Secret inventory” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M06.07-C003-T09 · Regression linkage:** Link the “Secret inventory” property to changes in approved secret storage, scoped runtime handles and guest/broker injection; record which dependency or contract changes require rerunning it.
- [ ] **UC-M06.07-C003-T10 · Property disposition:** Compare the satisfying and violating “Secret inventory” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M06.07-C004 · Integration

**Original checklist item:** Integrate secret inventory with approved secret storage, scoped runtime handles and guest/broker injection; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M06.07-C004-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Secret inventory” across approved secret storage, scoped runtime handles and guest/broker injection; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M06.07-C004-T02 · Field mapping:** Map every “Secret inventory” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M06.07-C004-T03 · Prerequisite identities:** Record the actual prerequisites for “Secret inventory” (source dependency list: UC-M03.07, UC-M06.04); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M06.07-C004-T04 · Ownership agreement:** Specify who owns “Secret inventory” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M06.07-C004-T05 · Handoff implementation:** Connect “Secret inventory” through the mapped seam using the real adapter or explicit specification reference; preserve “Secrets are classified before choosing storage or transport” across the handoff.
- [ ] **UC-M06.07-C004-T06 · Absent-input case:** Omit one required “Secret inventory” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M06.07-C004-T07 · Stale-input case:** Supply an outdated “Secret inventory” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M06.07-C004-T08 · Incompatible-input case:** Supply an incompatible “Secret inventory” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M06.07-C004-T09 · Valid integration trace:** Run a valid “Secret inventory” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M06.07-C004-T10 · Seam review:** Reconcile the “Secret inventory” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M06.07-C005 · Valid-case test

**Original checklist item:** Run a valid-path fixture for secret inventory; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M06.07-C005-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Secret inventory” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M06.07-C005-T02 · Expected-result oracle:** Specify the “Secret inventory” expected result independently of the implementation output; include the property “Secrets are classified before choosing storage or transport” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M06.07-C005-T03 · Fixture material:** Create the concrete “Secret inventory” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M06.07-C005-T04 · Target preparation:** Prepare the “Secret inventory” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M06.07-C005-T05 · Initial-state record:** Record the initial “Secret inventory” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M06.07-C005-T06 · Valid-path execution:** Execute the “Secret inventory” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M06.07-C005-T07 · Outcome comparison:** Compare every declared “Secret inventory” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M06.07-C005-T08 · State and bounds check:** Inspect the “Secret inventory” ownership/state effects and actual use of “Secret types and inventory coverage”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M06.07-C005-T09 · Repeatability check:** Repeat the same “Secret inventory” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M06.07-C005-T10 · Positive evidence:** Attach the “Secret inventory” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M06.07-C006 · Negative test

**Original checklist item:** Negative case: A runtime token is treated as ordinary cargo metadata. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M06.07-C006-T01 · Adverse-case definition:** Create a test record for the exact “Secret inventory” source counterexample: “A runtime token is treated as ordinary cargo metadata”; state which precondition or invariant it challenges.
- [ ] **UC-M06.07-C006-T02 · Safe fixture boundary:** Define the contained test boundary for “Secret inventory”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M06.07-C006-T03 · Valid control:** Construct a valid “Secret inventory” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M06.07-C006-T04 · Minimal adverse input:** Derive the “Secret inventory” adverse fixture from the control with the smallest documented change needed to reproduce “A runtime token is treated as ordinary cargo metadata”; retain that change as reproducible data.
- [ ] **UC-M06.07-C006-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Secret inventory”; require “Secrets are classified before choosing storage or transport” and forbid a false-success verdict.
- [ ] **UC-M06.07-C006-T06 · Adverse execution:** Exercise the “Secret inventory” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M06.07-C006-T07 · Effect inspection:** Inspect “Secret inventory” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M06.07-C006-T08 · Refusal versus failure:** Confirm the “Secret inventory” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M06.07-C006-T09 · Reset and retention:** Restore only the disposable “Secret inventory” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M06.07-C006-T10 · Negative regression:** Register the “Secret inventory” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M06.07-C007 · Change / failure test

**Original checklist item:** Exercise secret inventory when a workload stops or is replaced while a secret handle is still cached; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M06.07-C007-T01 · Scenario record:** Write the “Secret inventory” change/failure scenario exactly as supplied: a workload stops or is replaced while a secret handle is still cached; identify the property that must remain true: “Secrets are classified before choosing storage or transport”.
- [ ] **UC-M06.07-C007-T02 · Baseline capture:** Create a known-valid “Secret inventory” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M06.07-C007-T03 · Injection map:** Locate the “Secret inventory” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M06.07-C007-T04 · Disposition oracle:** Define the legal intermediate and final “Secret inventory” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M06.07-C007-T05 · Controlled trigger:** Introduce the controlled “Secret inventory” scenario in the disposable fixture: a workload stops or is replaced while a secret handle is still cached; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M06.07-C007-T06 · Intermediate inspection:** Inspect the “Secret inventory” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M06.07-C007-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Secret inventory”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M06.07-C007-T08 · Stale-evidence cleanup:** Invalidate superseded “Secret inventory” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M06.07-C007-T09 · Repeat and compare:** Repeat the selected “Secret inventory” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M06.07-C007-T10 · Failure evidence:** Publish the “Secret inventory” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M06.07-C008 · Bounds

**Original checklist item:** Choose, document and test limits for secret types and inventory coverage; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M06.07-C008-T01 · Quantity inventory:** Create a measurement inventory for “Secret inventory”: “Secret types and inventory coverage”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M06.07-C008-T02 · Measurement method:** Choose how to observe each “Secret inventory” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M06.07-C008-T03 · Budget decision:** Select justified resource and input limits for “Secret inventory”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M06.07-C008-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Secret inventory” cases for “Secret types and inventory coverage”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M06.07-C008-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Secret inventory” limit; preserve “Secrets are classified before choosing storage or transport”.
- [ ] **UC-M06.07-C008-T06 · Normal measurement:** Run or review the normal “Secret inventory” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M06.07-C008-T07 · At-limit measurement:** Exercise the “Secret inventory” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M06.07-C008-T08 · Over-limit measurement:** Exercise the “Secret inventory” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M06.07-C008-T09 · Uncovered-scope report:** List the “Secret inventory” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M06.07-C008-T10 · Limit evidence:** Publish the selected “Secret inventory” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M06.07-C009 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for secret inventory with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M06.07-C009-T01 · Event inventory:** List the “Secret inventory” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M06.07-C009-T02 · Diagnostic schema:** Define nonsecret fields for “Secret inventory” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M06.07-C009-T03 · Failure mapping:** Map each documented “Secret inventory” refusal or error to a diagnostic outcome; include “A runtime token is treated as ordinary cargo metadata” and prohibit conversion into a success message.
- [ ] **UC-M06.07-C009-T04 · Emission path:** Add the “Secret inventory” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M06.07-C009-T05 · Redaction check:** Test “Secret inventory” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M06.07-C009-T06 · Output budget:** Set and exercise bounded “Secret inventory” message size, rate and retention compatible with “Secret types and inventory coverage”; define truncation behavior that preserves the final reason.
- [ ] **UC-M06.07-C009-T07 · Success/refusal fixtures:** Capture “Secret inventory” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M06.07-C009-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Secret inventory” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M06.07-C009-T09 · Operator review:** Read the “Secret inventory” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M06.07-C009-T10 · Diagnostic evidence:** Publish redacted “Secret inventory” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M06.07-C010 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for secret inventory; label unexecuted checks as untested.

- [ ] **UC-M06.07-C010-T01 · Evidence inventory:** List the “Secret inventory” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M06.07-C010-T02 · Artifact references:** Record the exact “Secret inventory” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M06.07-C010-T03 · Fixture references:** Attach the “Secret inventory” fixture IDs, input identities and oracle definition; preserve the source counterexample “A runtime token is treated as ordinary cargo metadata” as a distinct evidence case.
- [ ] **UC-M06.07-C010-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Secret inventory”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M06.07-C010-T05 · Environment record:** Record the actual “Secret inventory” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M06.07-C010-T06 · Expected versus observed:** Pair every “Secret inventory” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M06.07-C010-T07 · Failure and limit records:** Attach “Secret inventory” change/failure and bounds evidence where required; include uncovered “Secret types and inventory coverage” and unresolved violations of “Secrets are classified before choosing storage or transport”.
- [ ] **UC-M06.07-C010-T08 · Evidence hygiene:** Check the “Secret inventory” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M06.07-C010-T09 · Reproduction review:** Have the “Secret inventory” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M06.07-C010-T10 · Acceptance linkage:** Link the “Secret inventory” evidence to its parent and UC-M06.07 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 02. Storage boundary

**Source delivery:** Keep secret material outside cargo, manifests, TIFF history and public artifacts.

**Source invariant:** Normal artifact storage does not contain secret plaintext.

**Source negative case:** A snapshot contains an injected runtime credential.

**Source bounded quantities:** Secret bytes and approved storage locations.

### UC-M06.07-C011 · Contract

**Original checklist item:** Specify storage boundary inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M06.07-C011-T01 · Scope statement:** Draft the operation boundary for “Storage boundary” within Secret storage and injection boundary; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M06.07-C011-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Storage boundary”; record each producer, representation and missing-value meaning.
- [ ] **UC-M06.07-C011-T03 · Output inventory:** List the outputs of “Storage boundary” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M06.07-C011-T04 · Field dictionary:** Create a field-and-term dictionary for “Storage boundary”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M06.07-C011-T05 · Prerequisite contract:** Map “Storage boundary” to the source component prerequisites (UC-M03.07, UC-M06.04); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M06.07-C011-T06 · Authority map:** Identify who may produce, change and consume “Storage boundary”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M06.07-C011-T07 · Invariant clause:** Add a normative clause for “Storage boundary” that preserves “Normal artifact storage does not contain secret plaintext”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M06.07-C011-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Storage boundary”; include the source counterexample “A snapshot contains an injected runtime credential” and the intended safe disposition.
- [ ] **UC-M06.07-C011-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Secret bytes and approved storage locations” in the “Storage boundary” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M06.07-C011-T10 · Contract review:** Review the “Storage boundary” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M06.07-C012 · Delivery

**Original checklist item:** Keep secret material outside cargo, manifests, TIFF history and public artifacts.

- [ ] **UC-M06.07-C012-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Storage boundary”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M06.07-C012-T02 · Change plan:** Break the source delivery for “Storage boundary” into concrete edit targets and reviewable outputs; keep the UC-M06.07 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M06.07-C012-T03 · Core artifact:** Implement the smallest selected-profile change for “Storage boundary” that realizes this source instruction: Keep secret material outside cargo, manifests, TIFF history and public artifacts.
- [ ] **UC-M06.07-C012-T04 · Concrete realization:** Trace “Storage boundary” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M06.07-C012-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Storage boundary” needed to preserve “Normal artifact storage does not contain secret plaintext”; record an enforcement gap where only a model exists.
- [ ] **UC-M06.07-C012-T06 · Dependency connection:** Connect the “Storage boundary” implementation to approved secret storage, scoped runtime handles and guest/broker injection; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M06.07-C012-T07 · Resource behavior:** Account for “Secret bytes and approved storage locations” in “Storage boundary”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M06.07-C012-T08 · Delivery check:** Run the smallest real “Storage boundary” path and its adverse fixture “A snapshot contains an injected runtime credential”; retain actual output, state effects and final disposition.
- [ ] **UC-M06.07-C012-T09 · Patch review:** Review the “Storage boundary” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M06.07-C012-T10 · Delivery handoff:** Publish the “Storage boundary” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M06.07-C013 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Normal artifact storage does not contain secret plaintext. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M06.07-C013-T01 · Named property:** Create a stable property/check name under this parent for “Storage boundary”; copy its required invariant exactly: “Normal artifact storage does not contain secret plaintext”.
- [ ] **UC-M06.07-C013-T02 · Observable terms:** Define each term in the “Storage boundary” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M06.07-C013-T03 · Precondition set:** List the preconditions under which “Normal artifact storage does not contain secret plaintext” must hold for “Storage boundary”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M06.07-C013-T04 · Transition coverage:** Map the “Storage boundary” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M06.07-C013-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Storage boundary”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M06.07-C013-T06 · Satisfying fixture:** Create a concrete “Storage boundary” case that satisfies “Normal artifact storage does not contain secret plaintext”; record its expected observation before running the assertion or review.
- [ ] **UC-M06.07-C013-T07 · Violating fixture:** Create the source counterexample “A snapshot contains an injected runtime credential” for “Storage boundary”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M06.07-C013-T08 · Enforcement evidence:** Exercise the “Storage boundary” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M06.07-C013-T09 · Regression linkage:** Link the “Storage boundary” property to changes in approved secret storage, scoped runtime handles and guest/broker injection; record which dependency or contract changes require rerunning it.
- [ ] **UC-M06.07-C013-T10 · Property disposition:** Compare the satisfying and violating “Storage boundary” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M06.07-C014 · Integration

**Original checklist item:** Integrate storage boundary with approved secret storage, scoped runtime handles and guest/broker injection; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M06.07-C014-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Storage boundary” across approved secret storage, scoped runtime handles and guest/broker injection; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M06.07-C014-T02 · Field mapping:** Map every “Storage boundary” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M06.07-C014-T03 · Prerequisite identities:** Record the actual prerequisites for “Storage boundary” (source dependency list: UC-M03.07, UC-M06.04); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M06.07-C014-T04 · Ownership agreement:** Specify who owns “Storage boundary” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M06.07-C014-T05 · Handoff implementation:** Connect “Storage boundary” through the mapped seam using the real adapter or explicit specification reference; preserve “Normal artifact storage does not contain secret plaintext” across the handoff.
- [ ] **UC-M06.07-C014-T06 · Absent-input case:** Omit one required “Storage boundary” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M06.07-C014-T07 · Stale-input case:** Supply an outdated “Storage boundary” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M06.07-C014-T08 · Incompatible-input case:** Supply an incompatible “Storage boundary” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M06.07-C014-T09 · Valid integration trace:** Run a valid “Storage boundary” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M06.07-C014-T10 · Seam review:** Reconcile the “Storage boundary” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M06.07-C015 · Valid-case test

**Original checklist item:** Run a valid-path fixture for storage boundary; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M06.07-C015-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Storage boundary” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M06.07-C015-T02 · Expected-result oracle:** Specify the “Storage boundary” expected result independently of the implementation output; include the property “Normal artifact storage does not contain secret plaintext” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M06.07-C015-T03 · Fixture material:** Create the concrete “Storage boundary” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M06.07-C015-T04 · Target preparation:** Prepare the “Storage boundary” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M06.07-C015-T05 · Initial-state record:** Record the initial “Storage boundary” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M06.07-C015-T06 · Valid-path execution:** Execute the “Storage boundary” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M06.07-C015-T07 · Outcome comparison:** Compare every declared “Storage boundary” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M06.07-C015-T08 · State and bounds check:** Inspect the “Storage boundary” ownership/state effects and actual use of “Secret bytes and approved storage locations”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M06.07-C015-T09 · Repeatability check:** Repeat the same “Storage boundary” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M06.07-C015-T10 · Positive evidence:** Attach the “Storage boundary” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M06.07-C016 · Negative test

**Original checklist item:** Negative case: A snapshot contains an injected runtime credential. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M06.07-C016-T01 · Adverse-case definition:** Create a test record for the exact “Storage boundary” source counterexample: “A snapshot contains an injected runtime credential”; state which precondition or invariant it challenges.
- [ ] **UC-M06.07-C016-T02 · Safe fixture boundary:** Define the contained test boundary for “Storage boundary”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M06.07-C016-T03 · Valid control:** Construct a valid “Storage boundary” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M06.07-C016-T04 · Minimal adverse input:** Derive the “Storage boundary” adverse fixture from the control with the smallest documented change needed to reproduce “A snapshot contains an injected runtime credential”; retain that change as reproducible data.
- [ ] **UC-M06.07-C016-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Storage boundary”; require “Normal artifact storage does not contain secret plaintext” and forbid a false-success verdict.
- [ ] **UC-M06.07-C016-T06 · Adverse execution:** Exercise the “Storage boundary” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M06.07-C016-T07 · Effect inspection:** Inspect “Storage boundary” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M06.07-C016-T08 · Refusal versus failure:** Confirm the “Storage boundary” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M06.07-C016-T09 · Reset and retention:** Restore only the disposable “Storage boundary” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M06.07-C016-T10 · Negative regression:** Register the “Storage boundary” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M06.07-C017 · Change / failure test

**Original checklist item:** Exercise storage boundary when a workload stops or is replaced while a secret handle is still cached; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M06.07-C017-T01 · Scenario record:** Write the “Storage boundary” change/failure scenario exactly as supplied: a workload stops or is replaced while a secret handle is still cached; identify the property that must remain true: “Normal artifact storage does not contain secret plaintext”.
- [ ] **UC-M06.07-C017-T02 · Baseline capture:** Create a known-valid “Storage boundary” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M06.07-C017-T03 · Injection map:** Locate the “Storage boundary” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M06.07-C017-T04 · Disposition oracle:** Define the legal intermediate and final “Storage boundary” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M06.07-C017-T05 · Controlled trigger:** Introduce the controlled “Storage boundary” scenario in the disposable fixture: a workload stops or is replaced while a secret handle is still cached; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M06.07-C017-T06 · Intermediate inspection:** Inspect the “Storage boundary” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M06.07-C017-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Storage boundary”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M06.07-C017-T08 · Stale-evidence cleanup:** Invalidate superseded “Storage boundary” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M06.07-C017-T09 · Repeat and compare:** Repeat the selected “Storage boundary” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M06.07-C017-T10 · Failure evidence:** Publish the “Storage boundary” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M06.07-C018 · Bounds

**Original checklist item:** Choose, document and test limits for secret bytes and approved storage locations; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M06.07-C018-T01 · Quantity inventory:** Create a measurement inventory for “Storage boundary”: “Secret bytes and approved storage locations”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M06.07-C018-T02 · Measurement method:** Choose how to observe each “Storage boundary” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M06.07-C018-T03 · Budget decision:** Select justified resource and input limits for “Storage boundary”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M06.07-C018-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Storage boundary” cases for “Secret bytes and approved storage locations”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M06.07-C018-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Storage boundary” limit; preserve “Normal artifact storage does not contain secret plaintext”.
- [ ] **UC-M06.07-C018-T06 · Normal measurement:** Run or review the normal “Storage boundary” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M06.07-C018-T07 · At-limit measurement:** Exercise the “Storage boundary” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M06.07-C018-T08 · Over-limit measurement:** Exercise the “Storage boundary” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M06.07-C018-T09 · Uncovered-scope report:** List the “Storage boundary” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M06.07-C018-T10 · Limit evidence:** Publish the selected “Storage boundary” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M06.07-C019 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for storage boundary with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M06.07-C019-T01 · Event inventory:** List the “Storage boundary” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M06.07-C019-T02 · Diagnostic schema:** Define nonsecret fields for “Storage boundary” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M06.07-C019-T03 · Failure mapping:** Map each documented “Storage boundary” refusal or error to a diagnostic outcome; include “A snapshot contains an injected runtime credential” and prohibit conversion into a success message.
- [ ] **UC-M06.07-C019-T04 · Emission path:** Add the “Storage boundary” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M06.07-C019-T05 · Redaction check:** Test “Storage boundary” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M06.07-C019-T06 · Output budget:** Set and exercise bounded “Storage boundary” message size, rate and retention compatible with “Secret bytes and approved storage locations”; define truncation behavior that preserves the final reason.
- [ ] **UC-M06.07-C019-T07 · Success/refusal fixtures:** Capture “Storage boundary” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M06.07-C019-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Storage boundary” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M06.07-C019-T09 · Operator review:** Read the “Storage boundary” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M06.07-C019-T10 · Diagnostic evidence:** Publish redacted “Storage boundary” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M06.07-C020 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for storage boundary; label unexecuted checks as untested.

- [ ] **UC-M06.07-C020-T01 · Evidence inventory:** List the “Storage boundary” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M06.07-C020-T02 · Artifact references:** Record the exact “Storage boundary” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M06.07-C020-T03 · Fixture references:** Attach the “Storage boundary” fixture IDs, input identities and oracle definition; preserve the source counterexample “A snapshot contains an injected runtime credential” as a distinct evidence case.
- [ ] **UC-M06.07-C020-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Storage boundary”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M06.07-C020-T05 · Environment record:** Record the actual “Storage boundary” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M06.07-C020-T06 · Expected versus observed:** Pair every “Storage boundary” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M06.07-C020-T07 · Failure and limit records:** Attach “Storage boundary” change/failure and bounds evidence where required; include uncovered “Secret bytes and approved storage locations” and unresolved violations of “Normal artifact storage does not contain secret plaintext”.
- [ ] **UC-M06.07-C020-T08 · Evidence hygiene:** Check the “Storage boundary” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M06.07-C020-T09 · Reproduction review:** Have the “Storage boundary” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M06.07-C020-T10 · Acceptance linkage:** Link the “Storage boundary” evidence to its parent and UC-M06.07 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 03. Opaque handle model

**Source delivery:** Represent requested secrets using scoped runtime handles.

**Source invariant:** A handle does not expose or directly encode the secret value.

**Source negative case:** A handle string contains the underlying credential.

**Source bounded quantities:** Handle length and live handle count.

### UC-M06.07-C021 · Contract

**Original checklist item:** Specify opaque handle model inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M06.07-C021-T01 · Scope statement:** Draft the operation boundary for “Opaque handle model” within Secret storage and injection boundary; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M06.07-C021-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Opaque handle model”; record each producer, representation and missing-value meaning.
- [ ] **UC-M06.07-C021-T03 · Output inventory:** List the outputs of “Opaque handle model” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M06.07-C021-T04 · Field dictionary:** Create a field-and-term dictionary for “Opaque handle model”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M06.07-C021-T05 · Prerequisite contract:** Map “Opaque handle model” to the source component prerequisites (UC-M03.07, UC-M06.04); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M06.07-C021-T06 · Authority map:** Identify who may produce, change and consume “Opaque handle model”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M06.07-C021-T07 · Invariant clause:** Add a normative clause for “Opaque handle model” that preserves “A handle does not expose or directly encode the secret value”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M06.07-C021-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Opaque handle model”; include the source counterexample “A handle string contains the underlying credential” and the intended safe disposition.
- [ ] **UC-M06.07-C021-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Handle length and live handle count” in the “Opaque handle model” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M06.07-C021-T10 · Contract review:** Review the “Opaque handle model” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M06.07-C022 · Delivery

**Original checklist item:** Represent requested secrets using scoped runtime handles.

- [ ] **UC-M06.07-C022-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Opaque handle model”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M06.07-C022-T02 · Change plan:** Break the source delivery for “Opaque handle model” into concrete edit targets and reviewable outputs; keep the UC-M06.07 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M06.07-C022-T03 · Core artifact:** Create the “Opaque handle model” model, schema or inventory that realizes this source instruction: Represent requested secrets using scoped runtime handles.
- [ ] **UC-M06.07-C022-T04 · Concrete realization:** Populate “Opaque handle model” with one concrete worked case; map every required entity or field to its source and flag any unmapped entry.
- [ ] **UC-M06.07-C022-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Opaque handle model” needed to preserve “A handle does not expose or directly encode the secret value”; record an enforcement gap where only a model exists.
- [ ] **UC-M06.07-C022-T06 · Dependency connection:** Connect the “Opaque handle model” implementation to approved secret storage, scoped runtime handles and guest/broker injection; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M06.07-C022-T07 · Resource behavior:** Account for “Handle length and live handle count” in “Opaque handle model”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M06.07-C022-T08 · Delivery check:** Run the smallest real “Opaque handle model” path and its adverse fixture “A handle string contains the underlying credential”; retain actual output, state effects and final disposition.
- [ ] **UC-M06.07-C022-T09 · Patch review:** Review the “Opaque handle model” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M06.07-C022-T10 · Delivery handoff:** Publish the “Opaque handle model” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M06.07-C023 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: A handle does not expose or directly encode the secret value. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M06.07-C023-T01 · Named property:** Create a stable property/check name under this parent for “Opaque handle model”; copy its required invariant exactly: “A handle does not expose or directly encode the secret value”.
- [ ] **UC-M06.07-C023-T02 · Observable terms:** Define each term in the “Opaque handle model” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M06.07-C023-T03 · Precondition set:** List the preconditions under which “A handle does not expose or directly encode the secret value” must hold for “Opaque handle model”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M06.07-C023-T04 · Transition coverage:** Map the “Opaque handle model” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M06.07-C023-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Opaque handle model”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M06.07-C023-T06 · Satisfying fixture:** Create a concrete “Opaque handle model” case that satisfies “A handle does not expose or directly encode the secret value”; record its expected observation before running the assertion or review.
- [ ] **UC-M06.07-C023-T07 · Violating fixture:** Create the source counterexample “A handle string contains the underlying credential” for “Opaque handle model”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M06.07-C023-T08 · Enforcement evidence:** Exercise the “Opaque handle model” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M06.07-C023-T09 · Regression linkage:** Link the “Opaque handle model” property to changes in approved secret storage, scoped runtime handles and guest/broker injection; record which dependency or contract changes require rerunning it.
- [ ] **UC-M06.07-C023-T10 · Property disposition:** Compare the satisfying and violating “Opaque handle model” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M06.07-C024 · Integration

**Original checklist item:** Integrate opaque handle model with approved secret storage, scoped runtime handles and guest/broker injection; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M06.07-C024-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Opaque handle model” across approved secret storage, scoped runtime handles and guest/broker injection; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M06.07-C024-T02 · Field mapping:** Map every “Opaque handle model” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M06.07-C024-T03 · Prerequisite identities:** Record the actual prerequisites for “Opaque handle model” (source dependency list: UC-M03.07, UC-M06.04); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M06.07-C024-T04 · Ownership agreement:** Specify who owns “Opaque handle model” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M06.07-C024-T05 · Handoff implementation:** Connect “Opaque handle model” through the mapped seam using the real adapter or explicit specification reference; preserve “A handle does not expose or directly encode the secret value” across the handoff.
- [ ] **UC-M06.07-C024-T06 · Absent-input case:** Omit one required “Opaque handle model” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M06.07-C024-T07 · Stale-input case:** Supply an outdated “Opaque handle model” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M06.07-C024-T08 · Incompatible-input case:** Supply an incompatible “Opaque handle model” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M06.07-C024-T09 · Valid integration trace:** Run a valid “Opaque handle model” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M06.07-C024-T10 · Seam review:** Reconcile the “Opaque handle model” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M06.07-C025 · Valid-case test

**Original checklist item:** Run a valid-path fixture for opaque handle model; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M06.07-C025-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Opaque handle model” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M06.07-C025-T02 · Expected-result oracle:** Specify the “Opaque handle model” expected result independently of the implementation output; include the property “A handle does not expose or directly encode the secret value” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M06.07-C025-T03 · Fixture material:** Create the concrete “Opaque handle model” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M06.07-C025-T04 · Target preparation:** Prepare the “Opaque handle model” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M06.07-C025-T05 · Initial-state record:** Record the initial “Opaque handle model” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M06.07-C025-T06 · Valid-path execution:** Execute the “Opaque handle model” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M06.07-C025-T07 · Outcome comparison:** Compare every declared “Opaque handle model” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M06.07-C025-T08 · State and bounds check:** Inspect the “Opaque handle model” ownership/state effects and actual use of “Handle length and live handle count”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M06.07-C025-T09 · Repeatability check:** Repeat the same “Opaque handle model” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M06.07-C025-T10 · Positive evidence:** Attach the “Opaque handle model” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M06.07-C026 · Negative test

**Original checklist item:** Negative case: A handle string contains the underlying credential. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M06.07-C026-T01 · Adverse-case definition:** Create a test record for the exact “Opaque handle model” source counterexample: “A handle string contains the underlying credential”; state which precondition or invariant it challenges.
- [ ] **UC-M06.07-C026-T02 · Safe fixture boundary:** Define the contained test boundary for “Opaque handle model”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M06.07-C026-T03 · Valid control:** Construct a valid “Opaque handle model” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M06.07-C026-T04 · Minimal adverse input:** Derive the “Opaque handle model” adverse fixture from the control with the smallest documented change needed to reproduce “A handle string contains the underlying credential”; retain that change as reproducible data.
- [ ] **UC-M06.07-C026-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Opaque handle model”; require “A handle does not expose or directly encode the secret value” and forbid a false-success verdict.
- [ ] **UC-M06.07-C026-T06 · Adverse execution:** Exercise the “Opaque handle model” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M06.07-C026-T07 · Effect inspection:** Inspect “Opaque handle model” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M06.07-C026-T08 · Refusal versus failure:** Confirm the “Opaque handle model” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M06.07-C026-T09 · Reset and retention:** Restore only the disposable “Opaque handle model” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M06.07-C026-T10 · Negative regression:** Register the “Opaque handle model” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M06.07-C027 · Change / failure test

**Original checklist item:** Exercise opaque handle model when a workload stops or is replaced while a secret handle is still cached; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M06.07-C027-T01 · Scenario record:** Write the “Opaque handle model” change/failure scenario exactly as supplied: a workload stops or is replaced while a secret handle is still cached; identify the property that must remain true: “A handle does not expose or directly encode the secret value”.
- [ ] **UC-M06.07-C027-T02 · Baseline capture:** Create a known-valid “Opaque handle model” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M06.07-C027-T03 · Injection map:** Locate the “Opaque handle model” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M06.07-C027-T04 · Disposition oracle:** Define the legal intermediate and final “Opaque handle model” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M06.07-C027-T05 · Controlled trigger:** Introduce the controlled “Opaque handle model” scenario in the disposable fixture: a workload stops or is replaced while a secret handle is still cached; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M06.07-C027-T06 · Intermediate inspection:** Inspect the “Opaque handle model” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M06.07-C027-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Opaque handle model”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M06.07-C027-T08 · Stale-evidence cleanup:** Invalidate superseded “Opaque handle model” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M06.07-C027-T09 · Repeat and compare:** Repeat the selected “Opaque handle model” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M06.07-C027-T10 · Failure evidence:** Publish the “Opaque handle model” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M06.07-C028 · Bounds

**Original checklist item:** Choose, document and test limits for handle length and live handle count; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M06.07-C028-T01 · Quantity inventory:** Create a measurement inventory for “Opaque handle model”: “Handle length and live handle count”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M06.07-C028-T02 · Measurement method:** Choose how to observe each “Opaque handle model” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M06.07-C028-T03 · Budget decision:** Select justified resource and input limits for “Opaque handle model”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M06.07-C028-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Opaque handle model” cases for “Handle length and live handle count”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M06.07-C028-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Opaque handle model” limit; preserve “A handle does not expose or directly encode the secret value”.
- [ ] **UC-M06.07-C028-T06 · Normal measurement:** Run or review the normal “Opaque handle model” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M06.07-C028-T07 · At-limit measurement:** Exercise the “Opaque handle model” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M06.07-C028-T08 · Over-limit measurement:** Exercise the “Opaque handle model” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M06.07-C028-T09 · Uncovered-scope report:** List the “Opaque handle model” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M06.07-C028-T10 · Limit evidence:** Publish the selected “Opaque handle model” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M06.07-C029 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for opaque handle model with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M06.07-C029-T01 · Event inventory:** List the “Opaque handle model” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M06.07-C029-T02 · Diagnostic schema:** Define nonsecret fields for “Opaque handle model” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M06.07-C029-T03 · Failure mapping:** Map each documented “Opaque handle model” refusal or error to a diagnostic outcome; include “A handle string contains the underlying credential” and prohibit conversion into a success message.
- [ ] **UC-M06.07-C029-T04 · Emission path:** Add the “Opaque handle model” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M06.07-C029-T05 · Redaction check:** Test “Opaque handle model” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M06.07-C029-T06 · Output budget:** Set and exercise bounded “Opaque handle model” message size, rate and retention compatible with “Handle length and live handle count”; define truncation behavior that preserves the final reason.
- [ ] **UC-M06.07-C029-T07 · Success/refusal fixtures:** Capture “Opaque handle model” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M06.07-C029-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Opaque handle model” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M06.07-C029-T09 · Operator review:** Read the “Opaque handle model” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M06.07-C029-T10 · Diagnostic evidence:** Publish redacted “Opaque handle model” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M06.07-C030 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for opaque handle model; label unexecuted checks as untested.

- [ ] **UC-M06.07-C030-T01 · Evidence inventory:** List the “Opaque handle model” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M06.07-C030-T02 · Artifact references:** Record the exact “Opaque handle model” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M06.07-C030-T03 · Fixture references:** Attach the “Opaque handle model” fixture IDs, input identities and oracle definition; preserve the source counterexample “A handle string contains the underlying credential” as a distinct evidence case.
- [ ] **UC-M06.07-C030-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Opaque handle model”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M06.07-C030-T05 · Environment record:** Record the actual “Opaque handle model” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M06.07-C030-T06 · Expected versus observed:** Pair every “Opaque handle model” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M06.07-C030-T07 · Failure and limit records:** Attach “Opaque handle model” change/failure and bounds evidence where required; include uncovered “Handle length and live handle count” and unresolved violations of “A handle does not expose or directly encode the secret value”.
- [ ] **UC-M06.07-C030-T08 · Evidence hygiene:** Check the “Opaque handle model” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M06.07-C030-T09 · Reproduction review:** Have the “Opaque handle model” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M06.07-C030-T10 · Acceptance linkage:** Link the “Opaque handle model” evidence to its parent and UC-M06.07 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 04. Tenant scoping

**Source delivery:** Bind handles to authenticated tenant, workload and permitted purpose.

**Source invariant:** A secret handle cannot cross tenant boundaries.

**Source negative case:** A guest submits another tenant's valid handle.

**Source bounded quantities:** Scope checks and lookup time.

### UC-M06.07-C031 · Contract

**Original checklist item:** Specify tenant scoping inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M06.07-C031-T01 · Scope statement:** Draft the operation boundary for “Tenant scoping” within Secret storage and injection boundary; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M06.07-C031-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Tenant scoping”; record each producer, representation and missing-value meaning.
- [ ] **UC-M06.07-C031-T03 · Output inventory:** List the outputs of “Tenant scoping” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M06.07-C031-T04 · Field dictionary:** Create a field-and-term dictionary for “Tenant scoping”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M06.07-C031-T05 · Prerequisite contract:** Map “Tenant scoping” to the source component prerequisites (UC-M03.07, UC-M06.04); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M06.07-C031-T06 · Authority map:** Identify who may produce, change and consume “Tenant scoping”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M06.07-C031-T07 · Invariant clause:** Add a normative clause for “Tenant scoping” that preserves “A secret handle cannot cross tenant boundaries”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M06.07-C031-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Tenant scoping”; include the source counterexample “A guest submits another tenant's valid handle” and the intended safe disposition.
- [ ] **UC-M06.07-C031-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Scope checks and lookup time” in the “Tenant scoping” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M06.07-C031-T10 · Contract review:** Review the “Tenant scoping” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M06.07-C032 · Delivery

**Original checklist item:** Bind handles to authenticated tenant, workload and permitted purpose.

- [ ] **UC-M06.07-C032-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Tenant scoping”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M06.07-C032-T02 · Change plan:** Break the source delivery for “Tenant scoping” into concrete edit targets and reviewable outputs; keep the UC-M06.07 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M06.07-C032-T03 · Core artifact:** Implement the smallest selected-profile change for “Tenant scoping” that realizes this source instruction: Bind handles to authenticated tenant, workload and permitted purpose.
- [ ] **UC-M06.07-C032-T04 · Concrete realization:** Trace “Tenant scoping” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M06.07-C032-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Tenant scoping” needed to preserve “A secret handle cannot cross tenant boundaries”; record an enforcement gap where only a model exists.
- [ ] **UC-M06.07-C032-T06 · Dependency connection:** Connect the “Tenant scoping” implementation to approved secret storage, scoped runtime handles and guest/broker injection; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M06.07-C032-T07 · Resource behavior:** Account for “Scope checks and lookup time” in “Tenant scoping”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M06.07-C032-T08 · Delivery check:** Run the smallest real “Tenant scoping” path and its adverse fixture “A guest submits another tenant's valid handle”; retain actual output, state effects and final disposition.
- [ ] **UC-M06.07-C032-T09 · Patch review:** Review the “Tenant scoping” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M06.07-C032-T10 · Delivery handoff:** Publish the “Tenant scoping” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M06.07-C033 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: A secret handle cannot cross tenant boundaries. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M06.07-C033-T01 · Named property:** Create a stable property/check name under this parent for “Tenant scoping”; copy its required invariant exactly: “A secret handle cannot cross tenant boundaries”.
- [ ] **UC-M06.07-C033-T02 · Observable terms:** Define each term in the “Tenant scoping” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M06.07-C033-T03 · Precondition set:** List the preconditions under which “A secret handle cannot cross tenant boundaries” must hold for “Tenant scoping”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M06.07-C033-T04 · Transition coverage:** Map the “Tenant scoping” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M06.07-C033-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Tenant scoping”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M06.07-C033-T06 · Satisfying fixture:** Create a concrete “Tenant scoping” case that satisfies “A secret handle cannot cross tenant boundaries”; record its expected observation before running the assertion or review.
- [ ] **UC-M06.07-C033-T07 · Violating fixture:** Create the source counterexample “A guest submits another tenant's valid handle” for “Tenant scoping”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M06.07-C033-T08 · Enforcement evidence:** Exercise the “Tenant scoping” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M06.07-C033-T09 · Regression linkage:** Link the “Tenant scoping” property to changes in approved secret storage, scoped runtime handles and guest/broker injection; record which dependency or contract changes require rerunning it.
- [ ] **UC-M06.07-C033-T10 · Property disposition:** Compare the satisfying and violating “Tenant scoping” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M06.07-C034 · Integration

**Original checklist item:** Integrate tenant scoping with approved secret storage, scoped runtime handles and guest/broker injection; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M06.07-C034-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Tenant scoping” across approved secret storage, scoped runtime handles and guest/broker injection; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M06.07-C034-T02 · Field mapping:** Map every “Tenant scoping” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M06.07-C034-T03 · Prerequisite identities:** Record the actual prerequisites for “Tenant scoping” (source dependency list: UC-M03.07, UC-M06.04); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M06.07-C034-T04 · Ownership agreement:** Specify who owns “Tenant scoping” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M06.07-C034-T05 · Handoff implementation:** Connect “Tenant scoping” through the mapped seam using the real adapter or explicit specification reference; preserve “A secret handle cannot cross tenant boundaries” across the handoff.
- [ ] **UC-M06.07-C034-T06 · Absent-input case:** Omit one required “Tenant scoping” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M06.07-C034-T07 · Stale-input case:** Supply an outdated “Tenant scoping” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M06.07-C034-T08 · Incompatible-input case:** Supply an incompatible “Tenant scoping” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M06.07-C034-T09 · Valid integration trace:** Run a valid “Tenant scoping” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M06.07-C034-T10 · Seam review:** Reconcile the “Tenant scoping” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M06.07-C035 · Valid-case test

**Original checklist item:** Run a valid-path fixture for tenant scoping; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M06.07-C035-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Tenant scoping” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M06.07-C035-T02 · Expected-result oracle:** Specify the “Tenant scoping” expected result independently of the implementation output; include the property “A secret handle cannot cross tenant boundaries” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M06.07-C035-T03 · Fixture material:** Create the concrete “Tenant scoping” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M06.07-C035-T04 · Target preparation:** Prepare the “Tenant scoping” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M06.07-C035-T05 · Initial-state record:** Record the initial “Tenant scoping” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M06.07-C035-T06 · Valid-path execution:** Execute the “Tenant scoping” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M06.07-C035-T07 · Outcome comparison:** Compare every declared “Tenant scoping” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M06.07-C035-T08 · State and bounds check:** Inspect the “Tenant scoping” ownership/state effects and actual use of “Scope checks and lookup time”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M06.07-C035-T09 · Repeatability check:** Repeat the same “Tenant scoping” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M06.07-C035-T10 · Positive evidence:** Attach the “Tenant scoping” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M06.07-C036 · Negative test

**Original checklist item:** Negative case: A guest submits another tenant's valid handle. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M06.07-C036-T01 · Adverse-case definition:** Create a test record for the exact “Tenant scoping” source counterexample: “A guest submits another tenant's valid handle”; state which precondition or invariant it challenges.
- [ ] **UC-M06.07-C036-T02 · Safe fixture boundary:** Define the contained test boundary for “Tenant scoping”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M06.07-C036-T03 · Valid control:** Construct a valid “Tenant scoping” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M06.07-C036-T04 · Minimal adverse input:** Derive the “Tenant scoping” adverse fixture from the control with the smallest documented change needed to reproduce “A guest submits another tenant's valid handle”; retain that change as reproducible data.
- [ ] **UC-M06.07-C036-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Tenant scoping”; require “A secret handle cannot cross tenant boundaries” and forbid a false-success verdict.
- [ ] **UC-M06.07-C036-T06 · Adverse execution:** Exercise the “Tenant scoping” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M06.07-C036-T07 · Effect inspection:** Inspect “Tenant scoping” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M06.07-C036-T08 · Refusal versus failure:** Confirm the “Tenant scoping” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M06.07-C036-T09 · Reset and retention:** Restore only the disposable “Tenant scoping” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M06.07-C036-T10 · Negative regression:** Register the “Tenant scoping” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M06.07-C037 · Change / failure test

**Original checklist item:** Exercise tenant scoping when a workload stops or is replaced while a secret handle is still cached; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M06.07-C037-T01 · Scenario record:** Write the “Tenant scoping” change/failure scenario exactly as supplied: a workload stops or is replaced while a secret handle is still cached; identify the property that must remain true: “A secret handle cannot cross tenant boundaries”.
- [ ] **UC-M06.07-C037-T02 · Baseline capture:** Create a known-valid “Tenant scoping” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M06.07-C037-T03 · Injection map:** Locate the “Tenant scoping” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M06.07-C037-T04 · Disposition oracle:** Define the legal intermediate and final “Tenant scoping” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M06.07-C037-T05 · Controlled trigger:** Introduce the controlled “Tenant scoping” scenario in the disposable fixture: a workload stops or is replaced while a secret handle is still cached; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M06.07-C037-T06 · Intermediate inspection:** Inspect the “Tenant scoping” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M06.07-C037-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Tenant scoping”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M06.07-C037-T08 · Stale-evidence cleanup:** Invalidate superseded “Tenant scoping” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M06.07-C037-T09 · Repeat and compare:** Repeat the selected “Tenant scoping” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M06.07-C037-T10 · Failure evidence:** Publish the “Tenant scoping” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M06.07-C038 · Bounds

**Original checklist item:** Choose, document and test limits for scope checks and lookup time; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M06.07-C038-T01 · Quantity inventory:** Create a measurement inventory for “Tenant scoping”: “Scope checks and lookup time”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M06.07-C038-T02 · Measurement method:** Choose how to observe each “Tenant scoping” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M06.07-C038-T03 · Budget decision:** Select justified resource and input limits for “Tenant scoping”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M06.07-C038-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Tenant scoping” cases for “Scope checks and lookup time”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M06.07-C038-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Tenant scoping” limit; preserve “A secret handle cannot cross tenant boundaries”.
- [ ] **UC-M06.07-C038-T06 · Normal measurement:** Run or review the normal “Tenant scoping” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M06.07-C038-T07 · At-limit measurement:** Exercise the “Tenant scoping” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M06.07-C038-T08 · Over-limit measurement:** Exercise the “Tenant scoping” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M06.07-C038-T09 · Uncovered-scope report:** List the “Tenant scoping” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M06.07-C038-T10 · Limit evidence:** Publish the selected “Tenant scoping” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M06.07-C039 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for tenant scoping with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M06.07-C039-T01 · Event inventory:** List the “Tenant scoping” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M06.07-C039-T02 · Diagnostic schema:** Define nonsecret fields for “Tenant scoping” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M06.07-C039-T03 · Failure mapping:** Map each documented “Tenant scoping” refusal or error to a diagnostic outcome; include “A guest submits another tenant's valid handle” and prohibit conversion into a success message.
- [ ] **UC-M06.07-C039-T04 · Emission path:** Add the “Tenant scoping” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M06.07-C039-T05 · Redaction check:** Test “Tenant scoping” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M06.07-C039-T06 · Output budget:** Set and exercise bounded “Tenant scoping” message size, rate and retention compatible with “Scope checks and lookup time”; define truncation behavior that preserves the final reason.
- [ ] **UC-M06.07-C039-T07 · Success/refusal fixtures:** Capture “Tenant scoping” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M06.07-C039-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Tenant scoping” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M06.07-C039-T09 · Operator review:** Read the “Tenant scoping” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M06.07-C039-T10 · Diagnostic evidence:** Publish redacted “Tenant scoping” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M06.07-C040 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for tenant scoping; label unexecuted checks as untested.

- [ ] **UC-M06.07-C040-T01 · Evidence inventory:** List the “Tenant scoping” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M06.07-C040-T02 · Artifact references:** Record the exact “Tenant scoping” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M06.07-C040-T03 · Fixture references:** Attach the “Tenant scoping” fixture IDs, input identities and oracle definition; preserve the source counterexample “A guest submits another tenant's valid handle” as a distinct evidence case.
- [ ] **UC-M06.07-C040-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Tenant scoping”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M06.07-C040-T05 · Environment record:** Record the actual “Tenant scoping” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M06.07-C040-T06 · Expected versus observed:** Pair every “Tenant scoping” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M06.07-C040-T07 · Failure and limit records:** Attach “Tenant scoping” change/failure and bounds evidence where required; include uncovered “Scope checks and lookup time” and unresolved violations of “A secret handle cannot cross tenant boundaries”.
- [ ] **UC-M06.07-C040-T08 · Evidence hygiene:** Check the “Tenant scoping” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M06.07-C040-T09 · Reproduction review:** Have the “Tenant scoping” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M06.07-C040-T10 · Acceptance linkage:** Link the “Tenant scoping” evidence to its parent and UC-M06.07 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 05. Short-lived issuance

**Source delivery:** Issue runtime access with an explicit limited lifetime.

**Source invariant:** A stopped or expired workload cannot keep obtaining secrets.

**Source negative case:** A token remains usable after its workload generation is retired.

**Source bounded quantities:** Handle lifetime and renewal frequency.

### UC-M06.07-C041 · Contract

**Original checklist item:** Specify short-lived issuance inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M06.07-C041-T01 · Scope statement:** Draft the operation boundary for “Short-lived issuance” within Secret storage and injection boundary; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M06.07-C041-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Short-lived issuance”; record each producer, representation and missing-value meaning.
- [ ] **UC-M06.07-C041-T03 · Output inventory:** List the outputs of “Short-lived issuance” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M06.07-C041-T04 · Field dictionary:** Create a field-and-term dictionary for “Short-lived issuance”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M06.07-C041-T05 · Prerequisite contract:** Map “Short-lived issuance” to the source component prerequisites (UC-M03.07, UC-M06.04); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M06.07-C041-T06 · Authority map:** Identify who may produce, change and consume “Short-lived issuance”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M06.07-C041-T07 · Invariant clause:** Add a normative clause for “Short-lived issuance” that preserves “A stopped or expired workload cannot keep obtaining secrets”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M06.07-C041-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Short-lived issuance”; include the source counterexample “A token remains usable after its workload generation is retired” and the intended safe disposition.
- [ ] **UC-M06.07-C041-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Handle lifetime and renewal frequency” in the “Short-lived issuance” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M06.07-C041-T10 · Contract review:** Review the “Short-lived issuance” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M06.07-C042 · Delivery

**Original checklist item:** Issue runtime access with an explicit limited lifetime.

- [ ] **UC-M06.07-C042-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Short-lived issuance”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M06.07-C042-T02 · Change plan:** Break the source delivery for “Short-lived issuance” into concrete edit targets and reviewable outputs; keep the UC-M06.07 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M06.07-C042-T03 · Core artifact:** Implement the smallest selected-profile change for “Short-lived issuance” that realizes this source instruction: Issue runtime access with an explicit limited lifetime.
- [ ] **UC-M06.07-C042-T04 · Concrete realization:** Trace “Short-lived issuance” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M06.07-C042-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Short-lived issuance” needed to preserve “A stopped or expired workload cannot keep obtaining secrets”; record an enforcement gap where only a model exists.
- [ ] **UC-M06.07-C042-T06 · Dependency connection:** Connect the “Short-lived issuance” implementation to approved secret storage, scoped runtime handles and guest/broker injection; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M06.07-C042-T07 · Resource behavior:** Account for “Handle lifetime and renewal frequency” in “Short-lived issuance”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M06.07-C042-T08 · Delivery check:** Run the smallest real “Short-lived issuance” path and its adverse fixture “A token remains usable after its workload generation is retired”; retain actual output, state effects and final disposition.
- [ ] **UC-M06.07-C042-T09 · Patch review:** Review the “Short-lived issuance” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M06.07-C042-T10 · Delivery handoff:** Publish the “Short-lived issuance” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M06.07-C043 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: A stopped or expired workload cannot keep obtaining secrets. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M06.07-C043-T01 · Named property:** Create a stable property/check name under this parent for “Short-lived issuance”; copy its required invariant exactly: “A stopped or expired workload cannot keep obtaining secrets”.
- [ ] **UC-M06.07-C043-T02 · Observable terms:** Define each term in the “Short-lived issuance” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M06.07-C043-T03 · Precondition set:** List the preconditions under which “A stopped or expired workload cannot keep obtaining secrets” must hold for “Short-lived issuance”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M06.07-C043-T04 · Transition coverage:** Map the “Short-lived issuance” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M06.07-C043-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Short-lived issuance”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M06.07-C043-T06 · Satisfying fixture:** Create a concrete “Short-lived issuance” case that satisfies “A stopped or expired workload cannot keep obtaining secrets”; record its expected observation before running the assertion or review.
- [ ] **UC-M06.07-C043-T07 · Violating fixture:** Create the source counterexample “A token remains usable after its workload generation is retired” for “Short-lived issuance”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M06.07-C043-T08 · Enforcement evidence:** Exercise the “Short-lived issuance” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M06.07-C043-T09 · Regression linkage:** Link the “Short-lived issuance” property to changes in approved secret storage, scoped runtime handles and guest/broker injection; record which dependency or contract changes require rerunning it.
- [ ] **UC-M06.07-C043-T10 · Property disposition:** Compare the satisfying and violating “Short-lived issuance” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M06.07-C044 · Integration

**Original checklist item:** Integrate short-lived issuance with approved secret storage, scoped runtime handles and guest/broker injection; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M06.07-C044-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Short-lived issuance” across approved secret storage, scoped runtime handles and guest/broker injection; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M06.07-C044-T02 · Field mapping:** Map every “Short-lived issuance” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M06.07-C044-T03 · Prerequisite identities:** Record the actual prerequisites for “Short-lived issuance” (source dependency list: UC-M03.07, UC-M06.04); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M06.07-C044-T04 · Ownership agreement:** Specify who owns “Short-lived issuance” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M06.07-C044-T05 · Handoff implementation:** Connect “Short-lived issuance” through the mapped seam using the real adapter or explicit specification reference; preserve “A stopped or expired workload cannot keep obtaining secrets” across the handoff.
- [ ] **UC-M06.07-C044-T06 · Absent-input case:** Omit one required “Short-lived issuance” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M06.07-C044-T07 · Stale-input case:** Supply an outdated “Short-lived issuance” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M06.07-C044-T08 · Incompatible-input case:** Supply an incompatible “Short-lived issuance” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M06.07-C044-T09 · Valid integration trace:** Run a valid “Short-lived issuance” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M06.07-C044-T10 · Seam review:** Reconcile the “Short-lived issuance” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M06.07-C045 · Valid-case test

**Original checklist item:** Run a valid-path fixture for short-lived issuance; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M06.07-C045-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Short-lived issuance” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M06.07-C045-T02 · Expected-result oracle:** Specify the “Short-lived issuance” expected result independently of the implementation output; include the property “A stopped or expired workload cannot keep obtaining secrets” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M06.07-C045-T03 · Fixture material:** Create the concrete “Short-lived issuance” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M06.07-C045-T04 · Target preparation:** Prepare the “Short-lived issuance” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M06.07-C045-T05 · Initial-state record:** Record the initial “Short-lived issuance” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M06.07-C045-T06 · Valid-path execution:** Execute the “Short-lived issuance” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M06.07-C045-T07 · Outcome comparison:** Compare every declared “Short-lived issuance” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M06.07-C045-T08 · State and bounds check:** Inspect the “Short-lived issuance” ownership/state effects and actual use of “Handle lifetime and renewal frequency”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M06.07-C045-T09 · Repeatability check:** Repeat the same “Short-lived issuance” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M06.07-C045-T10 · Positive evidence:** Attach the “Short-lived issuance” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M06.07-C046 · Negative test

**Original checklist item:** Negative case: A token remains usable after its workload generation is retired. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M06.07-C046-T01 · Adverse-case definition:** Create a test record for the exact “Short-lived issuance” source counterexample: “A token remains usable after its workload generation is retired”; state which precondition or invariant it challenges.
- [ ] **UC-M06.07-C046-T02 · Safe fixture boundary:** Define the contained test boundary for “Short-lived issuance”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M06.07-C046-T03 · Valid control:** Construct a valid “Short-lived issuance” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M06.07-C046-T04 · Minimal adverse input:** Derive the “Short-lived issuance” adverse fixture from the control with the smallest documented change needed to reproduce “A token remains usable after its workload generation is retired”; retain that change as reproducible data.
- [ ] **UC-M06.07-C046-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Short-lived issuance”; require “A stopped or expired workload cannot keep obtaining secrets” and forbid a false-success verdict.
- [ ] **UC-M06.07-C046-T06 · Adverse execution:** Exercise the “Short-lived issuance” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M06.07-C046-T07 · Effect inspection:** Inspect “Short-lived issuance” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M06.07-C046-T08 · Refusal versus failure:** Confirm the “Short-lived issuance” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M06.07-C046-T09 · Reset and retention:** Restore only the disposable “Short-lived issuance” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M06.07-C046-T10 · Negative regression:** Register the “Short-lived issuance” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M06.07-C047 · Change / failure test

**Original checklist item:** Exercise short-lived issuance when a workload stops or is replaced while a secret handle is still cached; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M06.07-C047-T01 · Scenario record:** Write the “Short-lived issuance” change/failure scenario exactly as supplied: a workload stops or is replaced while a secret handle is still cached; identify the property that must remain true: “A stopped or expired workload cannot keep obtaining secrets”.
- [ ] **UC-M06.07-C047-T02 · Baseline capture:** Create a known-valid “Short-lived issuance” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M06.07-C047-T03 · Injection map:** Locate the “Short-lived issuance” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M06.07-C047-T04 · Disposition oracle:** Define the legal intermediate and final “Short-lived issuance” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M06.07-C047-T05 · Controlled trigger:** Introduce the controlled “Short-lived issuance” scenario in the disposable fixture: a workload stops or is replaced while a secret handle is still cached; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M06.07-C047-T06 · Intermediate inspection:** Inspect the “Short-lived issuance” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M06.07-C047-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Short-lived issuance”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M06.07-C047-T08 · Stale-evidence cleanup:** Invalidate superseded “Short-lived issuance” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M06.07-C047-T09 · Repeat and compare:** Repeat the selected “Short-lived issuance” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M06.07-C047-T10 · Failure evidence:** Publish the “Short-lived issuance” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M06.07-C048 · Bounds

**Original checklist item:** Choose, document and test limits for handle lifetime and renewal frequency; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M06.07-C048-T01 · Quantity inventory:** Create a measurement inventory for “Short-lived issuance”: “Handle lifetime and renewal frequency”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M06.07-C048-T02 · Measurement method:** Choose how to observe each “Short-lived issuance” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M06.07-C048-T03 · Budget decision:** Select justified resource and input limits for “Short-lived issuance”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M06.07-C048-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Short-lived issuance” cases for “Handle lifetime and renewal frequency”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M06.07-C048-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Short-lived issuance” limit; preserve “A stopped or expired workload cannot keep obtaining secrets”.
- [ ] **UC-M06.07-C048-T06 · Normal measurement:** Run or review the normal “Short-lived issuance” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M06.07-C048-T07 · At-limit measurement:** Exercise the “Short-lived issuance” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M06.07-C048-T08 · Over-limit measurement:** Exercise the “Short-lived issuance” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M06.07-C048-T09 · Uncovered-scope report:** List the “Short-lived issuance” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M06.07-C048-T10 · Limit evidence:** Publish the selected “Short-lived issuance” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M06.07-C049 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for short-lived issuance with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M06.07-C049-T01 · Event inventory:** List the “Short-lived issuance” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M06.07-C049-T02 · Diagnostic schema:** Define nonsecret fields for “Short-lived issuance” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M06.07-C049-T03 · Failure mapping:** Map each documented “Short-lived issuance” refusal or error to a diagnostic outcome; include “A token remains usable after its workload generation is retired” and prohibit conversion into a success message.
- [ ] **UC-M06.07-C049-T04 · Emission path:** Add the “Short-lived issuance” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M06.07-C049-T05 · Redaction check:** Test “Short-lived issuance” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M06.07-C049-T06 · Output budget:** Set and exercise bounded “Short-lived issuance” message size, rate and retention compatible with “Handle lifetime and renewal frequency”; define truncation behavior that preserves the final reason.
- [ ] **UC-M06.07-C049-T07 · Success/refusal fixtures:** Capture “Short-lived issuance” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M06.07-C049-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Short-lived issuance” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M06.07-C049-T09 · Operator review:** Read the “Short-lived issuance” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M06.07-C049-T10 · Diagnostic evidence:** Publish redacted “Short-lived issuance” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M06.07-C050 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for short-lived issuance; label unexecuted checks as untested.

- [ ] **UC-M06.07-C050-T01 · Evidence inventory:** List the “Short-lived issuance” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M06.07-C050-T02 · Artifact references:** Record the exact “Short-lived issuance” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M06.07-C050-T03 · Fixture references:** Attach the “Short-lived issuance” fixture IDs, input identities and oracle definition; preserve the source counterexample “A token remains usable after its workload generation is retired” as a distinct evidence case.
- [ ] **UC-M06.07-C050-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Short-lived issuance”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M06.07-C050-T05 · Environment record:** Record the actual “Short-lived issuance” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M06.07-C050-T06 · Expected versus observed:** Pair every “Short-lived issuance” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M06.07-C050-T07 · Failure and limit records:** Attach “Short-lived issuance” change/failure and bounds evidence where required; include uncovered “Handle lifetime and renewal frequency” and unresolved violations of “A stopped or expired workload cannot keep obtaining secrets”.
- [ ] **UC-M06.07-C050-T08 · Evidence hygiene:** Check the “Short-lived issuance” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M06.07-C050-T09 · Reproduction review:** Have the “Short-lived issuance” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M06.07-C050-T10 · Acceptance linkage:** Link the “Short-lived issuance” evidence to its parent and UC-M06.07 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 06. Injection transport

**Source delivery:** Choose a runtime injection path that avoids public arguments and logs.

**Source invariant:** Secrets do not appear in process command lines.

**Source negative case:** A launcher passes a credential through a visible command argument.

**Source bounded quantities:** Injected bytes and transfer buffers.

### UC-M06.07-C051 · Contract

**Original checklist item:** Specify injection transport inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M06.07-C051-T01 · Scope statement:** Draft the operation boundary for “Injection transport” within Secret storage and injection boundary; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M06.07-C051-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Injection transport”; record each producer, representation and missing-value meaning.
- [ ] **UC-M06.07-C051-T03 · Output inventory:** List the outputs of “Injection transport” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M06.07-C051-T04 · Field dictionary:** Create a field-and-term dictionary for “Injection transport”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M06.07-C051-T05 · Prerequisite contract:** Map “Injection transport” to the source component prerequisites (UC-M03.07, UC-M06.04); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M06.07-C051-T06 · Authority map:** Identify who may produce, change and consume “Injection transport”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M06.07-C051-T07 · Invariant clause:** Add a normative clause for “Injection transport” that preserves “Secrets do not appear in process command lines”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M06.07-C051-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Injection transport”; include the source counterexample “A launcher passes a credential through a visible command argument” and the intended safe disposition.
- [ ] **UC-M06.07-C051-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Injected bytes and transfer buffers” in the “Injection transport” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M06.07-C051-T10 · Contract review:** Review the “Injection transport” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M06.07-C052 · Delivery

**Original checklist item:** Choose a runtime injection path that avoids public arguments and logs.

- [ ] **UC-M06.07-C052-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Injection transport”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M06.07-C052-T02 · Change plan:** Break the source delivery for “Injection transport” into concrete edit targets and reviewable outputs; keep the UC-M06.07 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M06.07-C052-T03 · Core artifact:** Prepare the “Injection transport” decision record for this source instruction: Choose a runtime injection path that avoids public arguments and logs.
- [ ] **UC-M06.07-C052-T04 · Concrete realization:** Evaluate the “Injection transport” choice against its declared constraints; record the exact selected target/configuration and rejected alternatives, leaving unverified compatibility as a blocker.
- [ ] **UC-M06.07-C052-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Injection transport” needed to preserve “Secrets do not appear in process command lines”; record an enforcement gap where only a model exists.
- [ ] **UC-M06.07-C052-T06 · Dependency connection:** Connect the “Injection transport” implementation to approved secret storage, scoped runtime handles and guest/broker injection; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M06.07-C052-T07 · Resource behavior:** Account for “Injected bytes and transfer buffers” in “Injection transport”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M06.07-C052-T08 · Delivery check:** Run the smallest real “Injection transport” path and its adverse fixture “A launcher passes a credential through a visible command argument”; retain actual output, state effects and final disposition.
- [ ] **UC-M06.07-C052-T09 · Patch review:** Review the “Injection transport” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M06.07-C052-T10 · Delivery handoff:** Publish the “Injection transport” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M06.07-C053 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Secrets do not appear in process command lines. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M06.07-C053-T01 · Named property:** Create a stable property/check name under this parent for “Injection transport”; copy its required invariant exactly: “Secrets do not appear in process command lines”.
- [ ] **UC-M06.07-C053-T02 · Observable terms:** Define each term in the “Injection transport” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M06.07-C053-T03 · Precondition set:** List the preconditions under which “Secrets do not appear in process command lines” must hold for “Injection transport”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M06.07-C053-T04 · Transition coverage:** Map the “Injection transport” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M06.07-C053-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Injection transport”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M06.07-C053-T06 · Satisfying fixture:** Create a concrete “Injection transport” case that satisfies “Secrets do not appear in process command lines”; record its expected observation before running the assertion or review.
- [ ] **UC-M06.07-C053-T07 · Violating fixture:** Create the source counterexample “A launcher passes a credential through a visible command argument” for “Injection transport”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M06.07-C053-T08 · Enforcement evidence:** Exercise the “Injection transport” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M06.07-C053-T09 · Regression linkage:** Link the “Injection transport” property to changes in approved secret storage, scoped runtime handles and guest/broker injection; record which dependency or contract changes require rerunning it.
- [ ] **UC-M06.07-C053-T10 · Property disposition:** Compare the satisfying and violating “Injection transport” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M06.07-C054 · Integration

**Original checklist item:** Integrate injection transport with approved secret storage, scoped runtime handles and guest/broker injection; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M06.07-C054-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Injection transport” across approved secret storage, scoped runtime handles and guest/broker injection; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M06.07-C054-T02 · Field mapping:** Map every “Injection transport” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M06.07-C054-T03 · Prerequisite identities:** Record the actual prerequisites for “Injection transport” (source dependency list: UC-M03.07, UC-M06.04); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M06.07-C054-T04 · Ownership agreement:** Specify who owns “Injection transport” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M06.07-C054-T05 · Handoff implementation:** Connect “Injection transport” through the mapped seam using the real adapter or explicit specification reference; preserve “Secrets do not appear in process command lines” across the handoff.
- [ ] **UC-M06.07-C054-T06 · Absent-input case:** Omit one required “Injection transport” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M06.07-C054-T07 · Stale-input case:** Supply an outdated “Injection transport” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M06.07-C054-T08 · Incompatible-input case:** Supply an incompatible “Injection transport” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M06.07-C054-T09 · Valid integration trace:** Run a valid “Injection transport” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M06.07-C054-T10 · Seam review:** Reconcile the “Injection transport” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M06.07-C055 · Valid-case test

**Original checklist item:** Run a valid-path fixture for injection transport; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M06.07-C055-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Injection transport” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M06.07-C055-T02 · Expected-result oracle:** Specify the “Injection transport” expected result independently of the implementation output; include the property “Secrets do not appear in process command lines” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M06.07-C055-T03 · Fixture material:** Create the concrete “Injection transport” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M06.07-C055-T04 · Target preparation:** Prepare the “Injection transport” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M06.07-C055-T05 · Initial-state record:** Record the initial “Injection transport” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M06.07-C055-T06 · Valid-path execution:** Execute the “Injection transport” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M06.07-C055-T07 · Outcome comparison:** Compare every declared “Injection transport” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M06.07-C055-T08 · State and bounds check:** Inspect the “Injection transport” ownership/state effects and actual use of “Injected bytes and transfer buffers”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M06.07-C055-T09 · Repeatability check:** Repeat the same “Injection transport” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M06.07-C055-T10 · Positive evidence:** Attach the “Injection transport” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M06.07-C056 · Negative test

**Original checklist item:** Negative case: A launcher passes a credential through a visible command argument. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M06.07-C056-T01 · Adverse-case definition:** Create a test record for the exact “Injection transport” source counterexample: “A launcher passes a credential through a visible command argument”; state which precondition or invariant it challenges.
- [ ] **UC-M06.07-C056-T02 · Safe fixture boundary:** Define the contained test boundary for “Injection transport”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M06.07-C056-T03 · Valid control:** Construct a valid “Injection transport” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M06.07-C056-T04 · Minimal adverse input:** Derive the “Injection transport” adverse fixture from the control with the smallest documented change needed to reproduce “A launcher passes a credential through a visible command argument”; retain that change as reproducible data.
- [ ] **UC-M06.07-C056-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Injection transport”; require “Secrets do not appear in process command lines” and forbid a false-success verdict.
- [ ] **UC-M06.07-C056-T06 · Adverse execution:** Exercise the “Injection transport” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M06.07-C056-T07 · Effect inspection:** Inspect “Injection transport” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M06.07-C056-T08 · Refusal versus failure:** Confirm the “Injection transport” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M06.07-C056-T09 · Reset and retention:** Restore only the disposable “Injection transport” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M06.07-C056-T10 · Negative regression:** Register the “Injection transport” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M06.07-C057 · Change / failure test

**Original checklist item:** Exercise injection transport when a workload stops or is replaced while a secret handle is still cached; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M06.07-C057-T01 · Scenario record:** Write the “Injection transport” change/failure scenario exactly as supplied: a workload stops or is replaced while a secret handle is still cached; identify the property that must remain true: “Secrets do not appear in process command lines”.
- [ ] **UC-M06.07-C057-T02 · Baseline capture:** Create a known-valid “Injection transport” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M06.07-C057-T03 · Injection map:** Locate the “Injection transport” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M06.07-C057-T04 · Disposition oracle:** Define the legal intermediate and final “Injection transport” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M06.07-C057-T05 · Controlled trigger:** Introduce the controlled “Injection transport” scenario in the disposable fixture: a workload stops or is replaced while a secret handle is still cached; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M06.07-C057-T06 · Intermediate inspection:** Inspect the “Injection transport” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M06.07-C057-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Injection transport”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M06.07-C057-T08 · Stale-evidence cleanup:** Invalidate superseded “Injection transport” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M06.07-C057-T09 · Repeat and compare:** Repeat the selected “Injection transport” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M06.07-C057-T10 · Failure evidence:** Publish the “Injection transport” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M06.07-C058 · Bounds

**Original checklist item:** Choose, document and test limits for injected bytes and transfer buffers; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M06.07-C058-T01 · Quantity inventory:** Create a measurement inventory for “Injection transport”: “Injected bytes and transfer buffers”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M06.07-C058-T02 · Measurement method:** Choose how to observe each “Injection transport” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M06.07-C058-T03 · Budget decision:** Select justified resource and input limits for “Injection transport”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M06.07-C058-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Injection transport” cases for “Injected bytes and transfer buffers”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M06.07-C058-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Injection transport” limit; preserve “Secrets do not appear in process command lines”.
- [ ] **UC-M06.07-C058-T06 · Normal measurement:** Run or review the normal “Injection transport” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M06.07-C058-T07 · At-limit measurement:** Exercise the “Injection transport” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M06.07-C058-T08 · Over-limit measurement:** Exercise the “Injection transport” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M06.07-C058-T09 · Uncovered-scope report:** List the “Injection transport” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M06.07-C058-T10 · Limit evidence:** Publish the selected “Injection transport” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M06.07-C059 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for injection transport with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M06.07-C059-T01 · Event inventory:** List the “Injection transport” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M06.07-C059-T02 · Diagnostic schema:** Define nonsecret fields for “Injection transport” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M06.07-C059-T03 · Failure mapping:** Map each documented “Injection transport” refusal or error to a diagnostic outcome; include “A launcher passes a credential through a visible command argument” and prohibit conversion into a success message.
- [ ] **UC-M06.07-C059-T04 · Emission path:** Add the “Injection transport” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M06.07-C059-T05 · Redaction check:** Test “Injection transport” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M06.07-C059-T06 · Output budget:** Set and exercise bounded “Injection transport” message size, rate and retention compatible with “Injected bytes and transfer buffers”; define truncation behavior that preserves the final reason.
- [ ] **UC-M06.07-C059-T07 · Success/refusal fixtures:** Capture “Injection transport” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M06.07-C059-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Injection transport” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M06.07-C059-T09 · Operator review:** Read the “Injection transport” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M06.07-C059-T10 · Diagnostic evidence:** Publish redacted “Injection transport” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M06.07-C060 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for injection transport; label unexecuted checks as untested.

- [ ] **UC-M06.07-C060-T01 · Evidence inventory:** List the “Injection transport” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M06.07-C060-T02 · Artifact references:** Record the exact “Injection transport” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M06.07-C060-T03 · Fixture references:** Attach the “Injection transport” fixture IDs, input identities and oracle definition; preserve the source counterexample “A launcher passes a credential through a visible command argument” as a distinct evidence case.
- [ ] **UC-M06.07-C060-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Injection transport”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M06.07-C060-T05 · Environment record:** Record the actual “Injection transport” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M06.07-C060-T06 · Expected versus observed:** Pair every “Injection transport” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M06.07-C060-T07 · Failure and limit records:** Attach “Injection transport” change/failure and bounds evidence where required; include uncovered “Injected bytes and transfer buffers” and unresolved violations of “Secrets do not appear in process command lines”.
- [ ] **UC-M06.07-C060-T08 · Evidence hygiene:** Check the “Injection transport” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M06.07-C060-T09 · Reproduction review:** Have the “Injection transport” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M06.07-C060-T10 · Acceptance linkage:** Link the “Injection transport” evidence to its parent and UC-M06.07 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 07. Broker authorization

**Source delivery:** Require narrowly authorized broker or provider operations for secret access.

**Source invariant:** Access to one secret does not grant arbitrary secret enumeration.

**Source negative case:** A permitted handle is used to request a different secret.

**Source bounded quantities:** Provider requests and authorization latency.

### UC-M06.07-C061 · Contract

**Original checklist item:** Specify broker authorization inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M06.07-C061-T01 · Scope statement:** Draft the operation boundary for “Broker authorization” within Secret storage and injection boundary; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M06.07-C061-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Broker authorization”; record each producer, representation and missing-value meaning.
- [ ] **UC-M06.07-C061-T03 · Output inventory:** List the outputs of “Broker authorization” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M06.07-C061-T04 · Field dictionary:** Create a field-and-term dictionary for “Broker authorization”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M06.07-C061-T05 · Prerequisite contract:** Map “Broker authorization” to the source component prerequisites (UC-M03.07, UC-M06.04); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M06.07-C061-T06 · Authority map:** Identify who may produce, change and consume “Broker authorization”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M06.07-C061-T07 · Invariant clause:** Add a normative clause for “Broker authorization” that preserves “Access to one secret does not grant arbitrary secret enumeration”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M06.07-C061-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Broker authorization”; include the source counterexample “A permitted handle is used to request a different secret” and the intended safe disposition.
- [ ] **UC-M06.07-C061-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Provider requests and authorization latency” in the “Broker authorization” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M06.07-C061-T10 · Contract review:** Review the “Broker authorization” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M06.07-C062 · Delivery

**Original checklist item:** Require narrowly authorized broker or provider operations for secret access.

- [ ] **UC-M06.07-C062-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Broker authorization”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M06.07-C062-T02 · Change plan:** Break the source delivery for “Broker authorization” into concrete edit targets and reviewable outputs; keep the UC-M06.07 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M06.07-C062-T03 · Core artifact:** Implement the smallest selected-profile change for “Broker authorization” that realizes this source instruction: Require narrowly authorized broker or provider operations for secret access.
- [ ] **UC-M06.07-C062-T04 · Concrete realization:** Trace “Broker authorization” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M06.07-C062-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Broker authorization” needed to preserve “Access to one secret does not grant arbitrary secret enumeration”; record an enforcement gap where only a model exists.
- [ ] **UC-M06.07-C062-T06 · Dependency connection:** Connect the “Broker authorization” implementation to approved secret storage, scoped runtime handles and guest/broker injection; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M06.07-C062-T07 · Resource behavior:** Account for “Provider requests and authorization latency” in “Broker authorization”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M06.07-C062-T08 · Delivery check:** Run the smallest real “Broker authorization” path and its adverse fixture “A permitted handle is used to request a different secret”; retain actual output, state effects and final disposition.
- [ ] **UC-M06.07-C062-T09 · Patch review:** Review the “Broker authorization” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M06.07-C062-T10 · Delivery handoff:** Publish the “Broker authorization” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M06.07-C063 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Access to one secret does not grant arbitrary secret enumeration. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M06.07-C063-T01 · Named property:** Create a stable property/check name under this parent for “Broker authorization”; copy its required invariant exactly: “Access to one secret does not grant arbitrary secret enumeration”.
- [ ] **UC-M06.07-C063-T02 · Observable terms:** Define each term in the “Broker authorization” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M06.07-C063-T03 · Precondition set:** List the preconditions under which “Access to one secret does not grant arbitrary secret enumeration” must hold for “Broker authorization”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M06.07-C063-T04 · Transition coverage:** Map the “Broker authorization” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M06.07-C063-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Broker authorization”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M06.07-C063-T06 · Satisfying fixture:** Create a concrete “Broker authorization” case that satisfies “Access to one secret does not grant arbitrary secret enumeration”; record its expected observation before running the assertion or review.
- [ ] **UC-M06.07-C063-T07 · Violating fixture:** Create the source counterexample “A permitted handle is used to request a different secret” for “Broker authorization”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M06.07-C063-T08 · Enforcement evidence:** Exercise the “Broker authorization” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M06.07-C063-T09 · Regression linkage:** Link the “Broker authorization” property to changes in approved secret storage, scoped runtime handles and guest/broker injection; record which dependency or contract changes require rerunning it.
- [ ] **UC-M06.07-C063-T10 · Property disposition:** Compare the satisfying and violating “Broker authorization” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M06.07-C064 · Integration

**Original checklist item:** Integrate broker authorization with approved secret storage, scoped runtime handles and guest/broker injection; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M06.07-C064-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Broker authorization” across approved secret storage, scoped runtime handles and guest/broker injection; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M06.07-C064-T02 · Field mapping:** Map every “Broker authorization” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M06.07-C064-T03 · Prerequisite identities:** Record the actual prerequisites for “Broker authorization” (source dependency list: UC-M03.07, UC-M06.04); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M06.07-C064-T04 · Ownership agreement:** Specify who owns “Broker authorization” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M06.07-C064-T05 · Handoff implementation:** Connect “Broker authorization” through the mapped seam using the real adapter or explicit specification reference; preserve “Access to one secret does not grant arbitrary secret enumeration” across the handoff.
- [ ] **UC-M06.07-C064-T06 · Absent-input case:** Omit one required “Broker authorization” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M06.07-C064-T07 · Stale-input case:** Supply an outdated “Broker authorization” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M06.07-C064-T08 · Incompatible-input case:** Supply an incompatible “Broker authorization” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M06.07-C064-T09 · Valid integration trace:** Run a valid “Broker authorization” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M06.07-C064-T10 · Seam review:** Reconcile the “Broker authorization” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M06.07-C065 · Valid-case test

**Original checklist item:** Run a valid-path fixture for broker authorization; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M06.07-C065-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Broker authorization” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M06.07-C065-T02 · Expected-result oracle:** Specify the “Broker authorization” expected result independently of the implementation output; include the property “Access to one secret does not grant arbitrary secret enumeration” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M06.07-C065-T03 · Fixture material:** Create the concrete “Broker authorization” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M06.07-C065-T04 · Target preparation:** Prepare the “Broker authorization” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M06.07-C065-T05 · Initial-state record:** Record the initial “Broker authorization” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M06.07-C065-T06 · Valid-path execution:** Execute the “Broker authorization” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M06.07-C065-T07 · Outcome comparison:** Compare every declared “Broker authorization” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M06.07-C065-T08 · State and bounds check:** Inspect the “Broker authorization” ownership/state effects and actual use of “Provider requests and authorization latency”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M06.07-C065-T09 · Repeatability check:** Repeat the same “Broker authorization” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M06.07-C065-T10 · Positive evidence:** Attach the “Broker authorization” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M06.07-C066 · Negative test

**Original checklist item:** Negative case: A permitted handle is used to request a different secret. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M06.07-C066-T01 · Adverse-case definition:** Create a test record for the exact “Broker authorization” source counterexample: “A permitted handle is used to request a different secret”; state which precondition or invariant it challenges.
- [ ] **UC-M06.07-C066-T02 · Safe fixture boundary:** Define the contained test boundary for “Broker authorization”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M06.07-C066-T03 · Valid control:** Construct a valid “Broker authorization” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M06.07-C066-T04 · Minimal adverse input:** Derive the “Broker authorization” adverse fixture from the control with the smallest documented change needed to reproduce “A permitted handle is used to request a different secret”; retain that change as reproducible data.
- [ ] **UC-M06.07-C066-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Broker authorization”; require “Access to one secret does not grant arbitrary secret enumeration” and forbid a false-success verdict.
- [ ] **UC-M06.07-C066-T06 · Adverse execution:** Exercise the “Broker authorization” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M06.07-C066-T07 · Effect inspection:** Inspect “Broker authorization” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M06.07-C066-T08 · Refusal versus failure:** Confirm the “Broker authorization” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M06.07-C066-T09 · Reset and retention:** Restore only the disposable “Broker authorization” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M06.07-C066-T10 · Negative regression:** Register the “Broker authorization” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M06.07-C067 · Change / failure test

**Original checklist item:** Exercise broker authorization when a workload stops or is replaced while a secret handle is still cached; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M06.07-C067-T01 · Scenario record:** Write the “Broker authorization” change/failure scenario exactly as supplied: a workload stops or is replaced while a secret handle is still cached; identify the property that must remain true: “Access to one secret does not grant arbitrary secret enumeration”.
- [ ] **UC-M06.07-C067-T02 · Baseline capture:** Create a known-valid “Broker authorization” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M06.07-C067-T03 · Injection map:** Locate the “Broker authorization” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M06.07-C067-T04 · Disposition oracle:** Define the legal intermediate and final “Broker authorization” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M06.07-C067-T05 · Controlled trigger:** Introduce the controlled “Broker authorization” scenario in the disposable fixture: a workload stops or is replaced while a secret handle is still cached; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M06.07-C067-T06 · Intermediate inspection:** Inspect the “Broker authorization” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M06.07-C067-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Broker authorization”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M06.07-C067-T08 · Stale-evidence cleanup:** Invalidate superseded “Broker authorization” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M06.07-C067-T09 · Repeat and compare:** Repeat the selected “Broker authorization” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M06.07-C067-T10 · Failure evidence:** Publish the “Broker authorization” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M06.07-C068 · Bounds

**Original checklist item:** Choose, document and test limits for provider requests and authorization latency; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M06.07-C068-T01 · Quantity inventory:** Create a measurement inventory for “Broker authorization”: “Provider requests and authorization latency”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M06.07-C068-T02 · Measurement method:** Choose how to observe each “Broker authorization” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M06.07-C068-T03 · Budget decision:** Select justified resource and input limits for “Broker authorization”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M06.07-C068-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Broker authorization” cases for “Provider requests and authorization latency”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M06.07-C068-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Broker authorization” limit; preserve “Access to one secret does not grant arbitrary secret enumeration”.
- [ ] **UC-M06.07-C068-T06 · Normal measurement:** Run or review the normal “Broker authorization” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M06.07-C068-T07 · At-limit measurement:** Exercise the “Broker authorization” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M06.07-C068-T08 · Over-limit measurement:** Exercise the “Broker authorization” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M06.07-C068-T09 · Uncovered-scope report:** List the “Broker authorization” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M06.07-C068-T10 · Limit evidence:** Publish the selected “Broker authorization” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M06.07-C069 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for broker authorization with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M06.07-C069-T01 · Event inventory:** List the “Broker authorization” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M06.07-C069-T02 · Diagnostic schema:** Define nonsecret fields for “Broker authorization” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M06.07-C069-T03 · Failure mapping:** Map each documented “Broker authorization” refusal or error to a diagnostic outcome; include “A permitted handle is used to request a different secret” and prohibit conversion into a success message.
- [ ] **UC-M06.07-C069-T04 · Emission path:** Add the “Broker authorization” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M06.07-C069-T05 · Redaction check:** Test “Broker authorization” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M06.07-C069-T06 · Output budget:** Set and exercise bounded “Broker authorization” message size, rate and retention compatible with “Provider requests and authorization latency”; define truncation behavior that preserves the final reason.
- [ ] **UC-M06.07-C069-T07 · Success/refusal fixtures:** Capture “Broker authorization” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M06.07-C069-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Broker authorization” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M06.07-C069-T09 · Operator review:** Read the “Broker authorization” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M06.07-C069-T10 · Diagnostic evidence:** Publish redacted “Broker authorization” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M06.07-C070 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for broker authorization; label unexecuted checks as untested.

- [ ] **UC-M06.07-C070-T01 · Evidence inventory:** List the “Broker authorization” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M06.07-C070-T02 · Artifact references:** Record the exact “Broker authorization” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M06.07-C070-T03 · Fixture references:** Attach the “Broker authorization” fixture IDs, input identities and oracle definition; preserve the source counterexample “A permitted handle is used to request a different secret” as a distinct evidence case.
- [ ] **UC-M06.07-C070-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Broker authorization”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M06.07-C070-T05 · Environment record:** Record the actual “Broker authorization” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M06.07-C070-T06 · Expected versus observed:** Pair every “Broker authorization” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M06.07-C070-T07 · Failure and limit records:** Attach “Broker authorization” change/failure and bounds evidence where required; include uncovered “Provider requests and authorization latency” and unresolved violations of “Access to one secret does not grant arbitrary secret enumeration”.
- [ ] **UC-M06.07-C070-T08 · Evidence hygiene:** Check the “Broker authorization” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M06.07-C070-T09 · Reproduction review:** Have the “Broker authorization” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M06.07-C070-T10 · Acceptance linkage:** Link the “Broker authorization” evidence to its parent and UC-M06.07 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 08. Revocation and cleanup

**Source delivery:** Revoke handles and clean transient exposure at stop, replacement and failure.

**Source invariant:** A stale guest cannot use a retired generation's secret authority.

**Source negative case:** A handle survives a failed replacement cleanup.

**Source bounded quantities:** Revocation delay and transient copies.

### UC-M06.07-C071 · Contract

**Original checklist item:** Specify revocation and cleanup inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M06.07-C071-T01 · Scope statement:** Draft the operation boundary for “Revocation and cleanup” within Secret storage and injection boundary; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M06.07-C071-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Revocation and cleanup”; record each producer, representation and missing-value meaning.
- [ ] **UC-M06.07-C071-T03 · Output inventory:** List the outputs of “Revocation and cleanup” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M06.07-C071-T04 · Field dictionary:** Create a field-and-term dictionary for “Revocation and cleanup”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M06.07-C071-T05 · Prerequisite contract:** Map “Revocation and cleanup” to the source component prerequisites (UC-M03.07, UC-M06.04); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M06.07-C071-T06 · Authority map:** Identify who may produce, change and consume “Revocation and cleanup”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M06.07-C071-T07 · Invariant clause:** Add a normative clause for “Revocation and cleanup” that preserves “A stale guest cannot use a retired generation's secret authority”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M06.07-C071-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Revocation and cleanup”; include the source counterexample “A handle survives a failed replacement cleanup” and the intended safe disposition.
- [ ] **UC-M06.07-C071-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Revocation delay and transient copies” in the “Revocation and cleanup” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M06.07-C071-T10 · Contract review:** Review the “Revocation and cleanup” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M06.07-C072 · Delivery

**Original checklist item:** Revoke handles and clean transient exposure at stop, replacement and failure.

- [ ] **UC-M06.07-C072-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Revocation and cleanup”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M06.07-C072-T02 · Change plan:** Break the source delivery for “Revocation and cleanup” into concrete edit targets and reviewable outputs; keep the UC-M06.07 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M06.07-C072-T03 · Core artifact:** Implement the smallest selected-profile change for “Revocation and cleanup” that realizes this source instruction: Revoke handles and clean transient exposure at stop, replacement and failure.
- [ ] **UC-M06.07-C072-T04 · Concrete realization:** Trace “Revocation and cleanup” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M06.07-C072-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Revocation and cleanup” needed to preserve “A stale guest cannot use a retired generation's secret authority”; record an enforcement gap where only a model exists.
- [ ] **UC-M06.07-C072-T06 · Dependency connection:** Connect the “Revocation and cleanup” implementation to approved secret storage, scoped runtime handles and guest/broker injection; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M06.07-C072-T07 · Resource behavior:** Account for “Revocation delay and transient copies” in “Revocation and cleanup”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M06.07-C072-T08 · Delivery check:** Run the smallest real “Revocation and cleanup” path and its adverse fixture “A handle survives a failed replacement cleanup”; retain actual output, state effects and final disposition.
- [ ] **UC-M06.07-C072-T09 · Patch review:** Review the “Revocation and cleanup” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M06.07-C072-T10 · Delivery handoff:** Publish the “Revocation and cleanup” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M06.07-C073 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: A stale guest cannot use a retired generation's secret authority. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M06.07-C073-T01 · Named property:** Create a stable property/check name under this parent for “Revocation and cleanup”; copy its required invariant exactly: “A stale guest cannot use a retired generation's secret authority”.
- [ ] **UC-M06.07-C073-T02 · Observable terms:** Define each term in the “Revocation and cleanup” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M06.07-C073-T03 · Precondition set:** List the preconditions under which “A stale guest cannot use a retired generation's secret authority” must hold for “Revocation and cleanup”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M06.07-C073-T04 · Transition coverage:** Map the “Revocation and cleanup” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M06.07-C073-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Revocation and cleanup”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M06.07-C073-T06 · Satisfying fixture:** Create a concrete “Revocation and cleanup” case that satisfies “A stale guest cannot use a retired generation's secret authority”; record its expected observation before running the assertion or review.
- [ ] **UC-M06.07-C073-T07 · Violating fixture:** Create the source counterexample “A handle survives a failed replacement cleanup” for “Revocation and cleanup”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M06.07-C073-T08 · Enforcement evidence:** Exercise the “Revocation and cleanup” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M06.07-C073-T09 · Regression linkage:** Link the “Revocation and cleanup” property to changes in approved secret storage, scoped runtime handles and guest/broker injection; record which dependency or contract changes require rerunning it.
- [ ] **UC-M06.07-C073-T10 · Property disposition:** Compare the satisfying and violating “Revocation and cleanup” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M06.07-C074 · Integration

**Original checklist item:** Integrate revocation and cleanup with approved secret storage, scoped runtime handles and guest/broker injection; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M06.07-C074-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Revocation and cleanup” across approved secret storage, scoped runtime handles and guest/broker injection; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M06.07-C074-T02 · Field mapping:** Map every “Revocation and cleanup” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M06.07-C074-T03 · Prerequisite identities:** Record the actual prerequisites for “Revocation and cleanup” (source dependency list: UC-M03.07, UC-M06.04); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M06.07-C074-T04 · Ownership agreement:** Specify who owns “Revocation and cleanup” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M06.07-C074-T05 · Handoff implementation:** Connect “Revocation and cleanup” through the mapped seam using the real adapter or explicit specification reference; preserve “A stale guest cannot use a retired generation's secret authority” across the handoff.
- [ ] **UC-M06.07-C074-T06 · Absent-input case:** Omit one required “Revocation and cleanup” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M06.07-C074-T07 · Stale-input case:** Supply an outdated “Revocation and cleanup” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M06.07-C074-T08 · Incompatible-input case:** Supply an incompatible “Revocation and cleanup” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M06.07-C074-T09 · Valid integration trace:** Run a valid “Revocation and cleanup” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M06.07-C074-T10 · Seam review:** Reconcile the “Revocation and cleanup” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M06.07-C075 · Valid-case test

**Original checklist item:** Run a valid-path fixture for revocation and cleanup; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M06.07-C075-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Revocation and cleanup” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M06.07-C075-T02 · Expected-result oracle:** Specify the “Revocation and cleanup” expected result independently of the implementation output; include the property “A stale guest cannot use a retired generation's secret authority” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M06.07-C075-T03 · Fixture material:** Create the concrete “Revocation and cleanup” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M06.07-C075-T04 · Target preparation:** Prepare the “Revocation and cleanup” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M06.07-C075-T05 · Initial-state record:** Record the initial “Revocation and cleanup” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M06.07-C075-T06 · Valid-path execution:** Execute the “Revocation and cleanup” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M06.07-C075-T07 · Outcome comparison:** Compare every declared “Revocation and cleanup” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M06.07-C075-T08 · State and bounds check:** Inspect the “Revocation and cleanup” ownership/state effects and actual use of “Revocation delay and transient copies”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M06.07-C075-T09 · Repeatability check:** Repeat the same “Revocation and cleanup” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M06.07-C075-T10 · Positive evidence:** Attach the “Revocation and cleanup” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M06.07-C076 · Negative test

**Original checklist item:** Negative case: A handle survives a failed replacement cleanup. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M06.07-C076-T01 · Adverse-case definition:** Create a test record for the exact “Revocation and cleanup” source counterexample: “A handle survives a failed replacement cleanup”; state which precondition or invariant it challenges.
- [ ] **UC-M06.07-C076-T02 · Safe fixture boundary:** Define the contained test boundary for “Revocation and cleanup”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M06.07-C076-T03 · Valid control:** Construct a valid “Revocation and cleanup” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M06.07-C076-T04 · Minimal adverse input:** Derive the “Revocation and cleanup” adverse fixture from the control with the smallest documented change needed to reproduce “A handle survives a failed replacement cleanup”; retain that change as reproducible data.
- [ ] **UC-M06.07-C076-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Revocation and cleanup”; require “A stale guest cannot use a retired generation's secret authority” and forbid a false-success verdict.
- [ ] **UC-M06.07-C076-T06 · Adverse execution:** Exercise the “Revocation and cleanup” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M06.07-C076-T07 · Effect inspection:** Inspect “Revocation and cleanup” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M06.07-C076-T08 · Refusal versus failure:** Confirm the “Revocation and cleanup” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M06.07-C076-T09 · Reset and retention:** Restore only the disposable “Revocation and cleanup” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M06.07-C076-T10 · Negative regression:** Register the “Revocation and cleanup” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M06.07-C077 · Change / failure test

**Original checklist item:** Exercise revocation and cleanup when a workload stops or is replaced while a secret handle is still cached; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M06.07-C077-T01 · Scenario record:** Write the “Revocation and cleanup” change/failure scenario exactly as supplied: a workload stops or is replaced while a secret handle is still cached; identify the property that must remain true: “A stale guest cannot use a retired generation's secret authority”.
- [ ] **UC-M06.07-C077-T02 · Baseline capture:** Create a known-valid “Revocation and cleanup” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M06.07-C077-T03 · Injection map:** Locate the “Revocation and cleanup” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M06.07-C077-T04 · Disposition oracle:** Define the legal intermediate and final “Revocation and cleanup” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M06.07-C077-T05 · Controlled trigger:** Introduce the controlled “Revocation and cleanup” scenario in the disposable fixture: a workload stops or is replaced while a secret handle is still cached; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M06.07-C077-T06 · Intermediate inspection:** Inspect the “Revocation and cleanup” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M06.07-C077-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Revocation and cleanup”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M06.07-C077-T08 · Stale-evidence cleanup:** Invalidate superseded “Revocation and cleanup” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M06.07-C077-T09 · Repeat and compare:** Repeat the selected “Revocation and cleanup” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M06.07-C077-T10 · Failure evidence:** Publish the “Revocation and cleanup” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M06.07-C078 · Bounds

**Original checklist item:** Choose, document and test limits for revocation delay and transient copies; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M06.07-C078-T01 · Quantity inventory:** Create a measurement inventory for “Revocation and cleanup”: “Revocation delay and transient copies”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M06.07-C078-T02 · Measurement method:** Choose how to observe each “Revocation and cleanup” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M06.07-C078-T03 · Budget decision:** Select justified resource and input limits for “Revocation and cleanup”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M06.07-C078-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Revocation and cleanup” cases for “Revocation delay and transient copies”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M06.07-C078-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Revocation and cleanup” limit; preserve “A stale guest cannot use a retired generation's secret authority”.
- [ ] **UC-M06.07-C078-T06 · Normal measurement:** Run or review the normal “Revocation and cleanup” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M06.07-C078-T07 · At-limit measurement:** Exercise the “Revocation and cleanup” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M06.07-C078-T08 · Over-limit measurement:** Exercise the “Revocation and cleanup” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M06.07-C078-T09 · Uncovered-scope report:** List the “Revocation and cleanup” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M06.07-C078-T10 · Limit evidence:** Publish the selected “Revocation and cleanup” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M06.07-C079 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for revocation and cleanup with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M06.07-C079-T01 · Event inventory:** List the “Revocation and cleanup” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M06.07-C079-T02 · Diagnostic schema:** Define nonsecret fields for “Revocation and cleanup” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M06.07-C079-T03 · Failure mapping:** Map each documented “Revocation and cleanup” refusal or error to a diagnostic outcome; include “A handle survives a failed replacement cleanup” and prohibit conversion into a success message.
- [ ] **UC-M06.07-C079-T04 · Emission path:** Add the “Revocation and cleanup” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M06.07-C079-T05 · Redaction check:** Test “Revocation and cleanup” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M06.07-C079-T06 · Output budget:** Set and exercise bounded “Revocation and cleanup” message size, rate and retention compatible with “Revocation delay and transient copies”; define truncation behavior that preserves the final reason.
- [ ] **UC-M06.07-C079-T07 · Success/refusal fixtures:** Capture “Revocation and cleanup” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M06.07-C079-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Revocation and cleanup” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M06.07-C079-T09 · Operator review:** Read the “Revocation and cleanup” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M06.07-C079-T10 · Diagnostic evidence:** Publish redacted “Revocation and cleanup” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M06.07-C080 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for revocation and cleanup; label unexecuted checks as untested.

- [ ] **UC-M06.07-C080-T01 · Evidence inventory:** List the “Revocation and cleanup” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M06.07-C080-T02 · Artifact references:** Record the exact “Revocation and cleanup” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M06.07-C080-T03 · Fixture references:** Attach the “Revocation and cleanup” fixture IDs, input identities and oracle definition; preserve the source counterexample “A handle survives a failed replacement cleanup” as a distinct evidence case.
- [ ] **UC-M06.07-C080-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Revocation and cleanup”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M06.07-C080-T05 · Environment record:** Record the actual “Revocation and cleanup” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M06.07-C080-T06 · Expected versus observed:** Pair every “Revocation and cleanup” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M06.07-C080-T07 · Failure and limit records:** Attach “Revocation and cleanup” change/failure and bounds evidence where required; include uncovered “Revocation delay and transient copies” and unresolved violations of “A stale guest cannot use a retired generation's secret authority”.
- [ ] **UC-M06.07-C080-T08 · Evidence hygiene:** Check the “Revocation and cleanup” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M06.07-C080-T09 · Reproduction review:** Have the “Revocation and cleanup” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M06.07-C080-T10 · Acceptance linkage:** Link the “Revocation and cleanup” evidence to its parent and UC-M06.07 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 09. Redaction fixtures

**Source delivery:** Plant identifiable test secrets and inspect logs, artifacts and snapshots.

**Source invariant:** Test secrets are absent from all nonsecret output surfaces.

**Source negative case:** A panic or support export includes the planted test secret.

**Source bounded quantities:** Scanned bytes and output surface count.

### UC-M06.07-C081 · Contract

**Original checklist item:** Specify redaction fixtures inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M06.07-C081-T01 · Scope statement:** Draft the operation boundary for “Redaction fixtures” within Secret storage and injection boundary; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M06.07-C081-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Redaction fixtures”; record each producer, representation and missing-value meaning.
- [ ] **UC-M06.07-C081-T03 · Output inventory:** List the outputs of “Redaction fixtures” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M06.07-C081-T04 · Field dictionary:** Create a field-and-term dictionary for “Redaction fixtures”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M06.07-C081-T05 · Prerequisite contract:** Map “Redaction fixtures” to the source component prerequisites (UC-M03.07, UC-M06.04); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M06.07-C081-T06 · Authority map:** Identify who may produce, change and consume “Redaction fixtures”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M06.07-C081-T07 · Invariant clause:** Add a normative clause for “Redaction fixtures” that preserves “Test secrets are absent from all nonsecret output surfaces”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M06.07-C081-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Redaction fixtures”; include the source counterexample “A panic or support export includes the planted test secret” and the intended safe disposition.
- [ ] **UC-M06.07-C081-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Scanned bytes and output surface count” in the “Redaction fixtures” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M06.07-C081-T10 · Contract review:** Review the “Redaction fixtures” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M06.07-C082 · Delivery

**Original checklist item:** Plant identifiable test secrets and inspect logs, artifacts and snapshots.

- [ ] **UC-M06.07-C082-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Redaction fixtures”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M06.07-C082-T02 · Change plan:** Break the source delivery for “Redaction fixtures” into concrete edit targets and reviewable outputs; keep the UC-M06.07 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M06.07-C082-T03 · Core artifact:** Implement the smallest selected-profile change for “Redaction fixtures” that realizes this source instruction: Plant identifiable test secrets and inspect logs, artifacts and snapshots.
- [ ] **UC-M06.07-C082-T04 · Concrete realization:** Trace “Redaction fixtures” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M06.07-C082-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Redaction fixtures” needed to preserve “Test secrets are absent from all nonsecret output surfaces”; record an enforcement gap where only a model exists.
- [ ] **UC-M06.07-C082-T06 · Dependency connection:** Connect the “Redaction fixtures” implementation to approved secret storage, scoped runtime handles and guest/broker injection; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M06.07-C082-T07 · Resource behavior:** Account for “Scanned bytes and output surface count” in “Redaction fixtures”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M06.07-C082-T08 · Delivery check:** Run the smallest real “Redaction fixtures” path and its adverse fixture “A panic or support export includes the planted test secret”; retain actual output, state effects and final disposition.
- [ ] **UC-M06.07-C082-T09 · Patch review:** Review the “Redaction fixtures” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M06.07-C082-T10 · Delivery handoff:** Publish the “Redaction fixtures” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M06.07-C083 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Test secrets are absent from all nonsecret output surfaces. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M06.07-C083-T01 · Named property:** Create a stable property/check name under this parent for “Redaction fixtures”; copy its required invariant exactly: “Test secrets are absent from all nonsecret output surfaces”.
- [ ] **UC-M06.07-C083-T02 · Observable terms:** Define each term in the “Redaction fixtures” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M06.07-C083-T03 · Precondition set:** List the preconditions under which “Test secrets are absent from all nonsecret output surfaces” must hold for “Redaction fixtures”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M06.07-C083-T04 · Transition coverage:** Map the “Redaction fixtures” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M06.07-C083-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Redaction fixtures”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M06.07-C083-T06 · Satisfying fixture:** Create a concrete “Redaction fixtures” case that satisfies “Test secrets are absent from all nonsecret output surfaces”; record its expected observation before running the assertion or review.
- [ ] **UC-M06.07-C083-T07 · Violating fixture:** Create the source counterexample “A panic or support export includes the planted test secret” for “Redaction fixtures”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M06.07-C083-T08 · Enforcement evidence:** Exercise the “Redaction fixtures” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M06.07-C083-T09 · Regression linkage:** Link the “Redaction fixtures” property to changes in approved secret storage, scoped runtime handles and guest/broker injection; record which dependency or contract changes require rerunning it.
- [ ] **UC-M06.07-C083-T10 · Property disposition:** Compare the satisfying and violating “Redaction fixtures” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M06.07-C084 · Integration

**Original checklist item:** Integrate redaction fixtures with approved secret storage, scoped runtime handles and guest/broker injection; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M06.07-C084-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Redaction fixtures” across approved secret storage, scoped runtime handles and guest/broker injection; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M06.07-C084-T02 · Field mapping:** Map every “Redaction fixtures” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M06.07-C084-T03 · Prerequisite identities:** Record the actual prerequisites for “Redaction fixtures” (source dependency list: UC-M03.07, UC-M06.04); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M06.07-C084-T04 · Ownership agreement:** Specify who owns “Redaction fixtures” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M06.07-C084-T05 · Handoff implementation:** Connect “Redaction fixtures” through the mapped seam using the real adapter or explicit specification reference; preserve “Test secrets are absent from all nonsecret output surfaces” across the handoff.
- [ ] **UC-M06.07-C084-T06 · Absent-input case:** Omit one required “Redaction fixtures” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M06.07-C084-T07 · Stale-input case:** Supply an outdated “Redaction fixtures” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M06.07-C084-T08 · Incompatible-input case:** Supply an incompatible “Redaction fixtures” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M06.07-C084-T09 · Valid integration trace:** Run a valid “Redaction fixtures” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M06.07-C084-T10 · Seam review:** Reconcile the “Redaction fixtures” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M06.07-C085 · Valid-case test

**Original checklist item:** Run a valid-path fixture for redaction fixtures; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M06.07-C085-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Redaction fixtures” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M06.07-C085-T02 · Expected-result oracle:** Specify the “Redaction fixtures” expected result independently of the implementation output; include the property “Test secrets are absent from all nonsecret output surfaces” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M06.07-C085-T03 · Fixture material:** Create the concrete “Redaction fixtures” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M06.07-C085-T04 · Target preparation:** Prepare the “Redaction fixtures” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M06.07-C085-T05 · Initial-state record:** Record the initial “Redaction fixtures” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M06.07-C085-T06 · Valid-path execution:** Execute the “Redaction fixtures” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M06.07-C085-T07 · Outcome comparison:** Compare every declared “Redaction fixtures” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M06.07-C085-T08 · State and bounds check:** Inspect the “Redaction fixtures” ownership/state effects and actual use of “Scanned bytes and output surface count”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M06.07-C085-T09 · Repeatability check:** Repeat the same “Redaction fixtures” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M06.07-C085-T10 · Positive evidence:** Attach the “Redaction fixtures” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M06.07-C086 · Negative test

**Original checklist item:** Negative case: A panic or support export includes the planted test secret. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M06.07-C086-T01 · Adverse-case definition:** Create a test record for the exact “Redaction fixtures” source counterexample: “A panic or support export includes the planted test secret”; state which precondition or invariant it challenges.
- [ ] **UC-M06.07-C086-T02 · Safe fixture boundary:** Define the contained test boundary for “Redaction fixtures”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M06.07-C086-T03 · Valid control:** Construct a valid “Redaction fixtures” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M06.07-C086-T04 · Minimal adverse input:** Derive the “Redaction fixtures” adverse fixture from the control with the smallest documented change needed to reproduce “A panic or support export includes the planted test secret”; retain that change as reproducible data.
- [ ] **UC-M06.07-C086-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Redaction fixtures”; require “Test secrets are absent from all nonsecret output surfaces” and forbid a false-success verdict.
- [ ] **UC-M06.07-C086-T06 · Adverse execution:** Exercise the “Redaction fixtures” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M06.07-C086-T07 · Effect inspection:** Inspect “Redaction fixtures” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M06.07-C086-T08 · Refusal versus failure:** Confirm the “Redaction fixtures” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M06.07-C086-T09 · Reset and retention:** Restore only the disposable “Redaction fixtures” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M06.07-C086-T10 · Negative regression:** Register the “Redaction fixtures” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M06.07-C087 · Change / failure test

**Original checklist item:** Exercise redaction fixtures when a workload stops or is replaced while a secret handle is still cached; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M06.07-C087-T01 · Scenario record:** Write the “Redaction fixtures” change/failure scenario exactly as supplied: a workload stops or is replaced while a secret handle is still cached; identify the property that must remain true: “Test secrets are absent from all nonsecret output surfaces”.
- [ ] **UC-M06.07-C087-T02 · Baseline capture:** Create a known-valid “Redaction fixtures” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M06.07-C087-T03 · Injection map:** Locate the “Redaction fixtures” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M06.07-C087-T04 · Disposition oracle:** Define the legal intermediate and final “Redaction fixtures” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M06.07-C087-T05 · Controlled trigger:** Introduce the controlled “Redaction fixtures” scenario in the disposable fixture: a workload stops or is replaced while a secret handle is still cached; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M06.07-C087-T06 · Intermediate inspection:** Inspect the “Redaction fixtures” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M06.07-C087-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Redaction fixtures”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M06.07-C087-T08 · Stale-evidence cleanup:** Invalidate superseded “Redaction fixtures” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M06.07-C087-T09 · Repeat and compare:** Repeat the selected “Redaction fixtures” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M06.07-C087-T10 · Failure evidence:** Publish the “Redaction fixtures” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M06.07-C088 · Bounds

**Original checklist item:** Choose, document and test limits for scanned bytes and output surface count; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M06.07-C088-T01 · Quantity inventory:** Create a measurement inventory for “Redaction fixtures”: “Scanned bytes and output surface count”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M06.07-C088-T02 · Measurement method:** Choose how to observe each “Redaction fixtures” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M06.07-C088-T03 · Budget decision:** Select justified resource and input limits for “Redaction fixtures”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M06.07-C088-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Redaction fixtures” cases for “Scanned bytes and output surface count”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M06.07-C088-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Redaction fixtures” limit; preserve “Test secrets are absent from all nonsecret output surfaces”.
- [ ] **UC-M06.07-C088-T06 · Normal measurement:** Run or review the normal “Redaction fixtures” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M06.07-C088-T07 · At-limit measurement:** Exercise the “Redaction fixtures” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M06.07-C088-T08 · Over-limit measurement:** Exercise the “Redaction fixtures” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M06.07-C088-T09 · Uncovered-scope report:** List the “Redaction fixtures” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M06.07-C088-T10 · Limit evidence:** Publish the selected “Redaction fixtures” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M06.07-C089 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for redaction fixtures with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M06.07-C089-T01 · Event inventory:** List the “Redaction fixtures” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M06.07-C089-T02 · Diagnostic schema:** Define nonsecret fields for “Redaction fixtures” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M06.07-C089-T03 · Failure mapping:** Map each documented “Redaction fixtures” refusal or error to a diagnostic outcome; include “A panic or support export includes the planted test secret” and prohibit conversion into a success message.
- [ ] **UC-M06.07-C089-T04 · Emission path:** Add the “Redaction fixtures” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M06.07-C089-T05 · Redaction check:** Test “Redaction fixtures” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M06.07-C089-T06 · Output budget:** Set and exercise bounded “Redaction fixtures” message size, rate and retention compatible with “Scanned bytes and output surface count”; define truncation behavior that preserves the final reason.
- [ ] **UC-M06.07-C089-T07 · Success/refusal fixtures:** Capture “Redaction fixtures” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M06.07-C089-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Redaction fixtures” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M06.07-C089-T09 · Operator review:** Read the “Redaction fixtures” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M06.07-C089-T10 · Diagnostic evidence:** Publish redacted “Redaction fixtures” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M06.07-C090 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for redaction fixtures; label unexecuted checks as untested.

- [ ] **UC-M06.07-C090-T01 · Evidence inventory:** List the “Redaction fixtures” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M06.07-C090-T02 · Artifact references:** Record the exact “Redaction fixtures” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M06.07-C090-T03 · Fixture references:** Attach the “Redaction fixtures” fixture IDs, input identities and oracle definition; preserve the source counterexample “A panic or support export includes the planted test secret” as a distinct evidence case.
- [ ] **UC-M06.07-C090-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Redaction fixtures”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M06.07-C090-T05 · Environment record:** Record the actual “Redaction fixtures” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M06.07-C090-T06 · Expected versus observed:** Pair every “Redaction fixtures” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M06.07-C090-T07 · Failure and limit records:** Attach “Redaction fixtures” change/failure and bounds evidence where required; include uncovered “Scanned bytes and output surface count” and unresolved violations of “Test secrets are absent from all nonsecret output surfaces”.
- [ ] **UC-M06.07-C090-T08 · Evidence hygiene:** Check the “Redaction fixtures” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M06.07-C090-T09 · Reproduction review:** Have the “Redaction fixtures” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M06.07-C090-T10 · Acceptance linkage:** Link the “Redaction fixtures” evidence to its parent and UC-M06.07 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 10. Secret acceptance gate

**Source delivery:** Qualify storage, injection, redaction and cross-tenant refusal together.

**Source invariant:** A working injection demo alone does not qualify the secret boundary.

**Source negative case:** Injection works but the secret is retained in TIFF history.

**Source bounded quantities:** Scenario count and maximum evidence age.

### UC-M06.07-C091 · Contract

**Original checklist item:** Specify secret acceptance gate inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M06.07-C091-T01 · Scope statement:** Draft the operation boundary for “Secret acceptance gate” within Secret storage and injection boundary; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M06.07-C091-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Secret acceptance gate”; record each producer, representation and missing-value meaning.
- [ ] **UC-M06.07-C091-T03 · Output inventory:** List the outputs of “Secret acceptance gate” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M06.07-C091-T04 · Field dictionary:** Create a field-and-term dictionary for “Secret acceptance gate”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M06.07-C091-T05 · Prerequisite contract:** Map “Secret acceptance gate” to the source component prerequisites (UC-M03.07, UC-M06.04); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M06.07-C091-T06 · Authority map:** Identify who may produce, change and consume “Secret acceptance gate”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M06.07-C091-T07 · Invariant clause:** Add a normative clause for “Secret acceptance gate” that preserves “A working injection demo alone does not qualify the secret boundary”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M06.07-C091-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Secret acceptance gate”; include the source counterexample “Injection works but the secret is retained in TIFF history” and the intended safe disposition.
- [ ] **UC-M06.07-C091-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Scenario count and maximum evidence age” in the “Secret acceptance gate” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M06.07-C091-T10 · Contract review:** Review the “Secret acceptance gate” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M06.07-C092 · Delivery

**Original checklist item:** Qualify storage, injection, redaction and cross-tenant refusal together.

- [ ] **UC-M06.07-C092-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Secret acceptance gate”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M06.07-C092-T02 · Change plan:** Break the source delivery for “Secret acceptance gate” into concrete edit targets and reviewable outputs; keep the UC-M06.07 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M06.07-C092-T03 · Core artifact:** Create the “Secret acceptance gate” fixture or harness for this source instruction: Qualify storage, injection, redaction and cross-tenant refusal together.
- [ ] **UC-M06.07-C092-T04 · Concrete realization:** Connect the “Secret acceptance gate” harness to its actual intended target, set the expected oracle before running it, and distinguish a mock/control run from a target run.
- [ ] **UC-M06.07-C092-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Secret acceptance gate” needed to preserve “A working injection demo alone does not qualify the secret boundary”; record an enforcement gap where only a model exists.
- [ ] **UC-M06.07-C092-T06 · Dependency connection:** Connect the “Secret acceptance gate” implementation to approved secret storage, scoped runtime handles and guest/broker injection; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M06.07-C092-T07 · Resource behavior:** Account for “Scenario count and maximum evidence age” in “Secret acceptance gate”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M06.07-C092-T08 · Delivery check:** Run the smallest real “Secret acceptance gate” path and its adverse fixture “Injection works but the secret is retained in TIFF history”; retain actual output, state effects and final disposition.
- [ ] **UC-M06.07-C092-T09 · Patch review:** Review the “Secret acceptance gate” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M06.07-C092-T10 · Delivery handoff:** Publish the “Secret acceptance gate” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M06.07-C093 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: A working injection demo alone does not qualify the secret boundary. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M06.07-C093-T01 · Named property:** Create a stable property/check name under this parent for “Secret acceptance gate”; copy its required invariant exactly: “A working injection demo alone does not qualify the secret boundary”.
- [ ] **UC-M06.07-C093-T02 · Observable terms:** Define each term in the “Secret acceptance gate” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M06.07-C093-T03 · Precondition set:** List the preconditions under which “A working injection demo alone does not qualify the secret boundary” must hold for “Secret acceptance gate”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M06.07-C093-T04 · Transition coverage:** Map the “Secret acceptance gate” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M06.07-C093-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Secret acceptance gate”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M06.07-C093-T06 · Satisfying fixture:** Create a concrete “Secret acceptance gate” case that satisfies “A working injection demo alone does not qualify the secret boundary”; record its expected observation before running the assertion or review.
- [ ] **UC-M06.07-C093-T07 · Violating fixture:** Create the source counterexample “Injection works but the secret is retained in TIFF history” for “Secret acceptance gate”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M06.07-C093-T08 · Enforcement evidence:** Exercise the “Secret acceptance gate” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M06.07-C093-T09 · Regression linkage:** Link the “Secret acceptance gate” property to changes in approved secret storage, scoped runtime handles and guest/broker injection; record which dependency or contract changes require rerunning it.
- [ ] **UC-M06.07-C093-T10 · Property disposition:** Compare the satisfying and violating “Secret acceptance gate” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M06.07-C094 · Integration

**Original checklist item:** Integrate secret acceptance gate with approved secret storage, scoped runtime handles and guest/broker injection; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M06.07-C094-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Secret acceptance gate” across approved secret storage, scoped runtime handles and guest/broker injection; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M06.07-C094-T02 · Field mapping:** Map every “Secret acceptance gate” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M06.07-C094-T03 · Prerequisite identities:** Record the actual prerequisites for “Secret acceptance gate” (source dependency list: UC-M03.07, UC-M06.04); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M06.07-C094-T04 · Ownership agreement:** Specify who owns “Secret acceptance gate” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M06.07-C094-T05 · Handoff implementation:** Connect “Secret acceptance gate” through the mapped seam using the real adapter or explicit specification reference; preserve “A working injection demo alone does not qualify the secret boundary” across the handoff.
- [ ] **UC-M06.07-C094-T06 · Absent-input case:** Omit one required “Secret acceptance gate” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M06.07-C094-T07 · Stale-input case:** Supply an outdated “Secret acceptance gate” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M06.07-C094-T08 · Incompatible-input case:** Supply an incompatible “Secret acceptance gate” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M06.07-C094-T09 · Valid integration trace:** Run a valid “Secret acceptance gate” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M06.07-C094-T10 · Seam review:** Reconcile the “Secret acceptance gate” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M06.07-C095 · Valid-case test

**Original checklist item:** Run a valid-path fixture for secret acceptance gate; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M06.07-C095-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Secret acceptance gate” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M06.07-C095-T02 · Expected-result oracle:** Specify the “Secret acceptance gate” expected result independently of the implementation output; include the property “A working injection demo alone does not qualify the secret boundary” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M06.07-C095-T03 · Fixture material:** Create the concrete “Secret acceptance gate” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M06.07-C095-T04 · Target preparation:** Prepare the “Secret acceptance gate” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M06.07-C095-T05 · Initial-state record:** Record the initial “Secret acceptance gate” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M06.07-C095-T06 · Valid-path execution:** Execute the “Secret acceptance gate” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M06.07-C095-T07 · Outcome comparison:** Compare every declared “Secret acceptance gate” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M06.07-C095-T08 · State and bounds check:** Inspect the “Secret acceptance gate” ownership/state effects and actual use of “Scenario count and maximum evidence age”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M06.07-C095-T09 · Repeatability check:** Repeat the same “Secret acceptance gate” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M06.07-C095-T10 · Positive evidence:** Attach the “Secret acceptance gate” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M06.07-C096 · Negative test

**Original checklist item:** Negative case: Injection works but the secret is retained in TIFF history. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M06.07-C096-T01 · Adverse-case definition:** Create a test record for the exact “Secret acceptance gate” source counterexample: “Injection works but the secret is retained in TIFF history”; state which precondition or invariant it challenges.
- [ ] **UC-M06.07-C096-T02 · Safe fixture boundary:** Define the contained test boundary for “Secret acceptance gate”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M06.07-C096-T03 · Valid control:** Construct a valid “Secret acceptance gate” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M06.07-C096-T04 · Minimal adverse input:** Derive the “Secret acceptance gate” adverse fixture from the control with the smallest documented change needed to reproduce “Injection works but the secret is retained in TIFF history”; retain that change as reproducible data.
- [ ] **UC-M06.07-C096-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Secret acceptance gate”; require “A working injection demo alone does not qualify the secret boundary” and forbid a false-success verdict.
- [ ] **UC-M06.07-C096-T06 · Adverse execution:** Exercise the “Secret acceptance gate” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M06.07-C096-T07 · Effect inspection:** Inspect “Secret acceptance gate” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M06.07-C096-T08 · Refusal versus failure:** Confirm the “Secret acceptance gate” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M06.07-C096-T09 · Reset and retention:** Restore only the disposable “Secret acceptance gate” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M06.07-C096-T10 · Negative regression:** Register the “Secret acceptance gate” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M06.07-C097 · Change / failure test

**Original checklist item:** Exercise secret acceptance gate when a workload stops or is replaced while a secret handle is still cached; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M06.07-C097-T01 · Scenario record:** Write the “Secret acceptance gate” change/failure scenario exactly as supplied: a workload stops or is replaced while a secret handle is still cached; identify the property that must remain true: “A working injection demo alone does not qualify the secret boundary”.
- [ ] **UC-M06.07-C097-T02 · Baseline capture:** Create a known-valid “Secret acceptance gate” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M06.07-C097-T03 · Injection map:** Locate the “Secret acceptance gate” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M06.07-C097-T04 · Disposition oracle:** Define the legal intermediate and final “Secret acceptance gate” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M06.07-C097-T05 · Controlled trigger:** Introduce the controlled “Secret acceptance gate” scenario in the disposable fixture: a workload stops or is replaced while a secret handle is still cached; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M06.07-C097-T06 · Intermediate inspection:** Inspect the “Secret acceptance gate” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M06.07-C097-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Secret acceptance gate”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M06.07-C097-T08 · Stale-evidence cleanup:** Invalidate superseded “Secret acceptance gate” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M06.07-C097-T09 · Repeat and compare:** Repeat the selected “Secret acceptance gate” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M06.07-C097-T10 · Failure evidence:** Publish the “Secret acceptance gate” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M06.07-C098 · Bounds

**Original checklist item:** Choose, document and test limits for scenario count and maximum evidence age; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M06.07-C098-T01 · Quantity inventory:** Create a measurement inventory for “Secret acceptance gate”: “Scenario count and maximum evidence age”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M06.07-C098-T02 · Measurement method:** Choose how to observe each “Secret acceptance gate” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M06.07-C098-T03 · Budget decision:** Select justified resource and input limits for “Secret acceptance gate”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M06.07-C098-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Secret acceptance gate” cases for “Scenario count and maximum evidence age”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M06.07-C098-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Secret acceptance gate” limit; preserve “A working injection demo alone does not qualify the secret boundary”.
- [ ] **UC-M06.07-C098-T06 · Normal measurement:** Run or review the normal “Secret acceptance gate” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M06.07-C098-T07 · At-limit measurement:** Exercise the “Secret acceptance gate” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M06.07-C098-T08 · Over-limit measurement:** Exercise the “Secret acceptance gate” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M06.07-C098-T09 · Uncovered-scope report:** List the “Secret acceptance gate” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M06.07-C098-T10 · Limit evidence:** Publish the selected “Secret acceptance gate” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M06.07-C099 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for secret acceptance gate with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M06.07-C099-T01 · Event inventory:** List the “Secret acceptance gate” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M06.07-C099-T02 · Diagnostic schema:** Define nonsecret fields for “Secret acceptance gate” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M06.07-C099-T03 · Failure mapping:** Map each documented “Secret acceptance gate” refusal or error to a diagnostic outcome; include “Injection works but the secret is retained in TIFF history” and prohibit conversion into a success message.
- [ ] **UC-M06.07-C099-T04 · Emission path:** Add the “Secret acceptance gate” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M06.07-C099-T05 · Redaction check:** Test “Secret acceptance gate” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M06.07-C099-T06 · Output budget:** Set and exercise bounded “Secret acceptance gate” message size, rate and retention compatible with “Scenario count and maximum evidence age”; define truncation behavior that preserves the final reason.
- [ ] **UC-M06.07-C099-T07 · Success/refusal fixtures:** Capture “Secret acceptance gate” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M06.07-C099-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Secret acceptance gate” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M06.07-C099-T09 · Operator review:** Read the “Secret acceptance gate” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M06.07-C099-T10 · Diagnostic evidence:** Publish redacted “Secret acceptance gate” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M06.07-C100 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for secret acceptance gate; label unexecuted checks as untested.

- [ ] **UC-M06.07-C100-T01 · Evidence inventory:** List the “Secret acceptance gate” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M06.07-C100-T02 · Artifact references:** Record the exact “Secret acceptance gate” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M06.07-C100-T03 · Fixture references:** Attach the “Secret acceptance gate” fixture IDs, input identities and oracle definition; preserve the source counterexample “Injection works but the secret is retained in TIFF history” as a distinct evidence case.
- [ ] **UC-M06.07-C100-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Secret acceptance gate”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M06.07-C100-T05 · Environment record:** Record the actual “Secret acceptance gate” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M06.07-C100-T06 · Expected versus observed:** Pair every “Secret acceptance gate” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M06.07-C100-T07 · Failure and limit records:** Attach “Secret acceptance gate” change/failure and bounds evidence where required; include uncovered “Scenario count and maximum evidence age” and unresolved violations of “A working injection demo alone does not qualify the secret boundary”.
- [ ] **UC-M06.07-C100-T08 · Evidence hygiene:** Check the “Secret acceptance gate” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M06.07-C100-T09 · Reproduction review:** Have the “Secret acceptance gate” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M06.07-C100-T10 · Acceptance linkage:** Link the “Secret acceptance gate” evidence to its parent and UC-M06.07 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

