# UC-M02.08 — Guest ABI conformance and panic reporting

**To-Do Pack 2.0.0 · Baseline UC-2.2.0 · 100 parent checks × 10 subtasks = 1,000 to-dos**

[Master index](../../INDEX.md) · [Workstream index](../../w/02.md)

| Field | Preserved source value |
|---|---|
| Workstream | 02. Bootable unikernel guest |
| Milestone | B |
| Priority | P0 |
| Source assessment | MISSING |
| Scope | core or selected profile |
| Dependencies | [UC-M02.03](../02/UC-M02.03.md), [UC-M02.05](../02/UC-M02.05.md), [UC-M02.06](../02/UC-M02.06.md), [UC-M02.07](../02/UC-M02.07.md) |
| Source checklist pack | 1.0.0 |
| Original reference labels | [S1], [S2], [S3]. |

## Original requirement

Build positive/negative ABI probes, panic records and source-mapped traces for the chosen image/runtime combination.

**Original acceptance criterion:** A boot-success artifact includes image digest, ABI version, workload output and intentionally induced panic evidence.

**Source trace:** Original checklist `UC100/c/02/UC-M02.08.md` inside [s/checklists.zip](../../s/checklists.zip); exact parent records in [data/parents.jsonl](../../data/parents.jsonl). Original roadmap lines 221–232 are preserved in [s/roadmap.md](../../s/roadmap.md).

## How to use these lists

Every parent statement below is preserved verbatim. Its ten child tasks are proposed decomposition, not implemented capabilities or executed tests. Child IDs append `-T01` through `-T10` to the original parent ID. All begin unchecked / `TODO`. Design/review evidence does not establish runtime enforcement; observe the actual selected target where the parent requires it.

The source dependency graph and selected release profile determine applicability. The numbered child sequence is a local working order, not an added hard dependency graph. An unselected optional feature needs a recorded not-applicable rationale; missing prerequisites for selected work remain blockers. Numerical budgets, backends and trust mechanisms remain decisions unless fixed by the source. Test hostile cases only with synthetic inputs in authorized disposable environments.

## 01. ABI probe inventory

**Source delivery:** List required guest ABI calls, boot fields and platform behaviors.

**Source invariant:** Every claimed ABI capability has a conformance probe.

**Source negative case:** A capability is advertised without a probe that exercises it.

**Source bounded quantities:** ABI surface size and probe count.

### UC-M02.08-C001 · Contract

**Original checklist item:** Define the qualification objective for ABI probe inventory, including the actual target implementation, prerequisites, observable oracle and explicit exclusions.

- [ ] **UC-M02.08-C001-T01 · Scope statement:** Write the qualification question for “ABI probe inventory”; identify the actual target, claimed capability and observations that can answer that question.
- [ ] **UC-M02.08-C001-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “ABI probe inventory”; record each producer, representation and missing-value meaning.
- [ ] **UC-M02.08-C001-T03 · Output inventory:** List the outputs of “ABI probe inventory” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M02.08-C001-T04 · Field dictionary:** Create a field-and-term dictionary for “ABI probe inventory”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M02.08-C001-T05 · Prerequisite contract:** Map “ABI probe inventory” to the source component prerequisites (UC-M02.03, UC-M02.05, UC-M02.06, UC-M02.07); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M02.08-C001-T06 · Authority map:** Identify who may produce, change and consume “ABI probe inventory”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M02.08-C001-T07 · Invariant clause:** Add a normative clause for “ABI probe inventory” that preserves “Every claimed ABI capability has a conformance probe”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M02.08-C001-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “ABI probe inventory”; include the source counterexample “A capability is advertised without a probe that exercises it” and the intended safe disposition.
- [ ] **UC-M02.08-C001-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “ABI surface size and probe count” in the “ABI probe inventory” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M02.08-C001-T10 · Contract review:** Review the “ABI probe inventory” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M02.08-C002 · Delivery

**Original checklist item:** List required guest ABI calls, boot fields and platform behaviors.

- [ ] **UC-M02.08-C002-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “ABI probe inventory”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M02.08-C002-T02 · Change plan:** Break the source delivery for “ABI probe inventory” into concrete edit targets and reviewable outputs; keep the UC-M02.08 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M02.08-C002-T03 · Core artifact:** Create the “ABI probe inventory” model, schema or inventory that realizes this source instruction: List required guest ABI calls, boot fields and platform behaviors.
- [ ] **UC-M02.08-C002-T04 · Concrete realization:** Populate “ABI probe inventory” with one concrete worked case; map every required entity or field to its source and flag any unmapped entry.
- [ ] **UC-M02.08-C002-T05 · Invariant protection:** Add the actual guard, check or review criterion for “ABI probe inventory” needed to preserve “Every claimed ABI capability has a conformance probe”; record an enforcement gap where only a model exists.
- [ ] **UC-M02.08-C002-T06 · Dependency connection:** Connect the “ABI probe inventory” qualification artifact to the built guest, ABI probe runner and source-mapped panic collector; record the target identity and what the harness actually exercises.
- [ ] **UC-M02.08-C002-T07 · Resource behavior:** Account for “ABI surface size and probe count” in “ABI probe inventory”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M02.08-C002-T08 · Delivery check:** Run a known-valid control and a deliberately failing control for “ABI probe inventory”; confirm the harness distinguishes their observed outcomes.
- [ ] **UC-M02.08-C002-T09 · Patch review:** Review the “ABI probe inventory” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M02.08-C002-T10 · Delivery handoff:** Publish the “ABI probe inventory” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M02.08-C003 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Every claimed ABI capability has a conformance probe. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M02.08-C003-T01 · Named property:** Create a stable property/check name under this parent for “ABI probe inventory”; copy its required invariant exactly: “Every claimed ABI capability has a conformance probe”.
- [ ] **UC-M02.08-C003-T02 · Observable terms:** Define each term in the “ABI probe inventory” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M02.08-C003-T03 · Precondition set:** List the preconditions under which “Every claimed ABI capability has a conformance probe” must hold for “ABI probe inventory”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M02.08-C003-T04 · Transition coverage:** Map the “ABI probe inventory” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M02.08-C003-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “ABI probe inventory”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M02.08-C003-T06 · Satisfying fixture:** Create a concrete “ABI probe inventory” case that satisfies “Every claimed ABI capability has a conformance probe”; record its expected observation before running the assertion or review.
- [ ] **UC-M02.08-C003-T07 · Violating fixture:** Create the source counterexample “A capability is advertised without a probe that exercises it” for “ABI probe inventory”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M02.08-C003-T08 · Enforcement evidence:** Exercise the “ABI probe inventory” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M02.08-C003-T09 · Regression linkage:** Link the “ABI probe inventory” property to changes in the built guest, ABI probe runner and source-mapped panic collector; record which dependency or contract changes require rerunning it.
- [ ] **UC-M02.08-C003-T10 · Property disposition:** Compare the satisfying and violating “ABI probe inventory” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M02.08-C004 · Integration

**Original checklist item:** Integrate ABI probe inventory with the built guest, ABI probe runner and source-mapped panic collector; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M02.08-C004-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “ABI probe inventory” across the built guest, ABI probe runner and source-mapped panic collector; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M02.08-C004-T02 · Field mapping:** Map every “ABI probe inventory” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M02.08-C004-T03 · Prerequisite identities:** Record the actual prerequisites for “ABI probe inventory” (source dependency list: UC-M02.03, UC-M02.05, UC-M02.06, UC-M02.07); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M02.08-C004-T04 · Ownership agreement:** Specify who owns “ABI probe inventory” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M02.08-C004-T05 · Handoff implementation:** Connect “ABI probe inventory” through the mapped seam using the real adapter or explicit specification reference; preserve “Every claimed ABI capability has a conformance probe” across the handoff.
- [ ] **UC-M02.08-C004-T06 · Absent-input case:** Omit one required “ABI probe inventory” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M02.08-C004-T07 · Stale-input case:** Supply an outdated “ABI probe inventory” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M02.08-C004-T08 · Incompatible-input case:** Supply an incompatible “ABI probe inventory” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M02.08-C004-T09 · Valid integration trace:** Run a valid “ABI probe inventory” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M02.08-C004-T10 · Seam review:** Reconcile the “ABI probe inventory” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M02.08-C005 · Valid-case test

**Original checklist item:** Run a known-valid control for ABI probe inventory; verify that the harness reaches its intended target and compare observed measurements or verdicts with predeclared expectations.

- [ ] **UC-M02.08-C005-T01 · Valid fixture choice:** Choose a known-valid control for “ABI probe inventory”; document why it should pass and how it proves the harness reaches the intended target.
- [ ] **UC-M02.08-C005-T02 · Expected-result oracle:** Specify the “ABI probe inventory” expected result independently of the implementation output; include the property “Every claimed ABI capability has a conformance probe” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M02.08-C005-T03 · Fixture material:** Create the concrete “ABI probe inventory” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M02.08-C005-T04 · Target preparation:** Prepare the “ABI probe inventory” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M02.08-C005-T05 · Initial-state record:** Record the initial “ABI probe inventory” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M02.08-C005-T06 · Valid-path execution:** Run the “ABI probe inventory” known-valid control on the identified target; retain enough observations to prove the correct target was exercised.
- [ ] **UC-M02.08-C005-T07 · Outcome comparison:** Compare every declared “ABI probe inventory” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M02.08-C005-T08 · State and bounds check:** Inspect the “ABI probe inventory” ownership/state effects and actual use of “ABI surface size and probe count”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M02.08-C005-T09 · Repeatability check:** Repeat the same “ABI probe inventory” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M02.08-C005-T10 · Positive evidence:** Attach the “ABI probe inventory” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M02.08-C006 · Negative test

**Original checklist item:** Negative case: A capability is advertised without a probe that exercises it. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M02.08-C006-T01 · Adverse-case definition:** Create a test record for the exact “ABI probe inventory” source counterexample: “A capability is advertised without a probe that exercises it”; state which precondition or invariant it challenges.
- [ ] **UC-M02.08-C006-T02 · Safe fixture boundary:** Define the contained test boundary for “ABI probe inventory”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M02.08-C006-T03 · Valid control:** Construct a valid “ABI probe inventory” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M02.08-C006-T04 · Minimal adverse input:** Derive the “ABI probe inventory” adverse fixture from the control with the smallest documented change needed to reproduce “A capability is advertised without a probe that exercises it”; retain that change as reproducible data.
- [ ] **UC-M02.08-C006-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “ABI probe inventory”; require “Every claimed ABI capability has a conformance probe” and forbid a false-success verdict.
- [ ] **UC-M02.08-C006-T06 · Adverse execution:** Exercise the “ABI probe inventory” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M02.08-C006-T07 · Effect inspection:** Inspect “ABI probe inventory” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M02.08-C006-T08 · Refusal versus failure:** Confirm the “ABI probe inventory” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M02.08-C006-T09 · Reset and retention:** Restore only the disposable “ABI probe inventory” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M02.08-C006-T10 · Negative regression:** Register the “ABI probe inventory” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M02.08-C007 · Change / failure test

**Original checklist item:** Exercise ABI probe inventory when the image is rebuilt and previously collected ABI and panic evidence becomes stale; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M02.08-C007-T01 · Scenario record:** Write the “ABI probe inventory” change/failure scenario exactly as supplied: the image is rebuilt and previously collected ABI and panic evidence becomes stale; identify the property that must remain true: “Every claimed ABI capability has a conformance probe”.
- [ ] **UC-M02.08-C007-T02 · Baseline capture:** Create a known-valid “ABI probe inventory” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M02.08-C007-T03 · Injection map:** Locate the “ABI probe inventory” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M02.08-C007-T04 · Disposition oracle:** Define the legal intermediate and final “ABI probe inventory” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M02.08-C007-T05 · Controlled trigger:** Introduce the controlled “ABI probe inventory” scenario in the disposable fixture: the image is rebuilt and previously collected ABI and panic evidence becomes stale; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M02.08-C007-T06 · Intermediate inspection:** Inspect the “ABI probe inventory” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M02.08-C007-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “ABI probe inventory”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M02.08-C007-T08 · Stale-evidence cleanup:** Invalidate superseded “ABI probe inventory” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M02.08-C007-T09 · Repeat and compare:** Repeat the selected “ABI probe inventory” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M02.08-C007-T10 · Failure evidence:** Publish the “ABI probe inventory” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M02.08-C008 · Bounds

**Original checklist item:** Set a documented campaign budget for ABI surface size and probe count; record actual consumption, incomplete coverage and the disposition when the budget is exhausted.

- [ ] **UC-M02.08-C008-T01 · Quantity inventory:** Create a measurement inventory for “ABI probe inventory”: “ABI surface size and probe count”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M02.08-C008-T02 · Measurement method:** Choose how to observe each “ABI probe inventory” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M02.08-C008-T03 · Budget decision:** Select justified campaign and target-resource budgets for “ABI probe inventory”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M02.08-C008-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “ABI probe inventory” cases for “ABI surface size and probe count”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M02.08-C008-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “ABI probe inventory” limit; preserve “Every claimed ABI capability has a conformance probe”.
- [ ] **UC-M02.08-C008-T06 · Normal measurement:** Run or review the normal “ABI probe inventory” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M02.08-C008-T07 · At-limit measurement:** Exercise the “ABI probe inventory” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M02.08-C008-T08 · Over-limit measurement:** Exercise the “ABI probe inventory” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M02.08-C008-T09 · Uncovered-scope report:** List the “ABI probe inventory” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M02.08-C008-T10 · Limit evidence:** Publish the selected “ABI probe inventory” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M02.08-C009 · Diagnostics / review

**Original checklist item:** Report ABI probe inventory results with executed, failed, skipped and unavailable cases separated; preserve the underlying observations and do not manufacture missing measurements.

- [ ] **UC-M02.08-C009-T01 · Result inventory:** Enumerate the required “ABI probe inventory” qualification cases and intended targets before aggregating results; keep the planned denominator visible.
- [ ] **UC-M02.08-C009-T02 · Verdict schema:** Define separate executed-pass, executed-fail, skipped, unavailable and untested outcomes for “ABI probe inventory”; document how incomplete cases block relevant claims.
- [ ] **UC-M02.08-C009-T03 · Identity fields:** Attach the actual target, fixture, configuration and revision identifiers to each “ABI probe inventory” result; do not attribute host-only evidence to a guest or another OS.
- [ ] **UC-M02.08-C009-T04 · Observation capture:** Capture bounded raw “ABI probe inventory” observations and harness errors; retain enough information to verify the reported oracle comparison.
- [ ] **UC-M02.08-C009-T05 · Aggregation rules:** Implement the “ABI probe inventory” count/reduction rule so failures and missing measurements cannot disappear; preserve “Every claimed ABI capability has a conformance probe”.
- [ ] **UC-M02.08-C009-T06 · Failure visibility:** Feed a failing “ABI probe inventory” control through the report path; assert the exact failed case and underlying observation remain visible.
- [ ] **UC-M02.08-C009-T07 · Missing-result visibility:** Withhold a required “ABI probe inventory” measurement or target; verify the report uses unavailable/untested rather than a fabricated zero or passing value.
- [ ] **UC-M02.08-C009-T08 · Bounds and redaction:** Check “ABI probe inventory” report size and retention against “ABI surface size and probe count”; remove secrets while retaining fixture and subject references.
- [ ] **UC-M02.08-C009-T09 · Report reconciliation:** Reconcile the “ABI probe inventory” summary with every underlying case record; account for the full planned denominator and all omitted scope.
- [ ] **UC-M02.08-C009-T10 · Qualification handoff:** Publish the “ABI probe inventory” report with measured observations, coverage limits and blockers; state which actual targets remain unqualified.

### UC-M02.08-C010 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for ABI probe inventory; label unexecuted checks as untested.

- [ ] **UC-M02.08-C010-T01 · Evidence inventory:** List the “ABI probe inventory” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M02.08-C010-T02 · Artifact references:** Record the exact “ABI probe inventory” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M02.08-C010-T03 · Fixture references:** Attach the “ABI probe inventory” fixture IDs, input identities and oracle definition; preserve the source counterexample “A capability is advertised without a probe that exercises it” as a distinct evidence case.
- [ ] **UC-M02.08-C010-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “ABI probe inventory”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M02.08-C010-T05 · Environment record:** Record the actual “ABI probe inventory” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M02.08-C010-T06 · Expected versus observed:** Pair every “ABI probe inventory” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M02.08-C010-T07 · Failure and limit records:** Attach “ABI probe inventory” change/failure and bounds evidence where required; include uncovered “ABI surface size and probe count” and unresolved violations of “Every claimed ABI capability has a conformance probe”.
- [ ] **UC-M02.08-C010-T08 · Evidence hygiene:** Check the “ABI probe inventory” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M02.08-C010-T09 · Reproduction review:** Have the “ABI probe inventory” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M02.08-C010-T10 · Acceptance linkage:** Link the “ABI probe inventory” evidence to its parent and UC-M02.08 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 02. Positive ABI probes

**Source delivery:** Implement valid guest-originated calls that produce checkable results.

**Source invariant:** A positive probe demonstrates guest-to-platform behavior rather than a mock response.

**Source negative case:** A host test harness supplies the expected output without guest execution.

**Source bounded quantities:** Probe output bytes and execution deadline.

### UC-M02.08-C011 · Contract

**Original checklist item:** Define the qualification objective for positive ABI probes, including the actual target implementation, prerequisites, observable oracle and explicit exclusions.

- [ ] **UC-M02.08-C011-T01 · Scope statement:** Write the qualification question for “Positive ABI probes”; identify the actual target, claimed capability and observations that can answer that question.
- [ ] **UC-M02.08-C011-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Positive ABI probes”; record each producer, representation and missing-value meaning.
- [ ] **UC-M02.08-C011-T03 · Output inventory:** List the outputs of “Positive ABI probes” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M02.08-C011-T04 · Field dictionary:** Create a field-and-term dictionary for “Positive ABI probes”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M02.08-C011-T05 · Prerequisite contract:** Map “Positive ABI probes” to the source component prerequisites (UC-M02.03, UC-M02.05, UC-M02.06, UC-M02.07); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M02.08-C011-T06 · Authority map:** Identify who may produce, change and consume “Positive ABI probes”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M02.08-C011-T07 · Invariant clause:** Add a normative clause for “Positive ABI probes” that preserves “A positive probe demonstrates guest-to-platform behavior rather than a mock response”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M02.08-C011-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Positive ABI probes”; include the source counterexample “A host test harness supplies the expected output without guest execution” and the intended safe disposition.
- [ ] **UC-M02.08-C011-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Probe output bytes and execution deadline” in the “Positive ABI probes” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M02.08-C011-T10 · Contract review:** Review the “Positive ABI probes” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M02.08-C012 · Delivery

**Original checklist item:** Implement valid guest-originated calls that produce checkable results.

- [ ] **UC-M02.08-C012-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Positive ABI probes”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M02.08-C012-T02 · Change plan:** Break the source delivery for “Positive ABI probes” into concrete edit targets and reviewable outputs; keep the UC-M02.08 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M02.08-C012-T03 · Core artifact:** Implement the smallest selected-profile change for “Positive ABI probes” that realizes this source instruction: Implement valid guest-originated calls that produce checkable results.
- [ ] **UC-M02.08-C012-T04 · Concrete realization:** Trace “Positive ABI probes” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M02.08-C012-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Positive ABI probes” needed to preserve “A positive probe demonstrates guest-to-platform behavior rather than a mock response”; record an enforcement gap where only a model exists.
- [ ] **UC-M02.08-C012-T06 · Dependency connection:** Connect the “Positive ABI probes” qualification artifact to the built guest, ABI probe runner and source-mapped panic collector; record the target identity and what the harness actually exercises.
- [ ] **UC-M02.08-C012-T07 · Resource behavior:** Account for “Probe output bytes and execution deadline” in “Positive ABI probes”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M02.08-C012-T08 · Delivery check:** Run a known-valid control and a deliberately failing control for “Positive ABI probes”; confirm the harness distinguishes their observed outcomes.
- [ ] **UC-M02.08-C012-T09 · Patch review:** Review the “Positive ABI probes” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M02.08-C012-T10 · Delivery handoff:** Publish the “Positive ABI probes” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M02.08-C013 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: A positive probe demonstrates guest-to-platform behavior rather than a mock response. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M02.08-C013-T01 · Named property:** Create a stable property/check name under this parent for “Positive ABI probes”; copy its required invariant exactly: “A positive probe demonstrates guest-to-platform behavior rather than a mock response”.
- [ ] **UC-M02.08-C013-T02 · Observable terms:** Define each term in the “Positive ABI probes” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M02.08-C013-T03 · Precondition set:** List the preconditions under which “A positive probe demonstrates guest-to-platform behavior rather than a mock response” must hold for “Positive ABI probes”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M02.08-C013-T04 · Transition coverage:** Map the “Positive ABI probes” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M02.08-C013-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Positive ABI probes”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M02.08-C013-T06 · Satisfying fixture:** Create a concrete “Positive ABI probes” case that satisfies “A positive probe demonstrates guest-to-platform behavior rather than a mock response”; record its expected observation before running the assertion or review.
- [ ] **UC-M02.08-C013-T07 · Violating fixture:** Create the source counterexample “A host test harness supplies the expected output without guest execution” for “Positive ABI probes”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M02.08-C013-T08 · Enforcement evidence:** Exercise the “Positive ABI probes” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M02.08-C013-T09 · Regression linkage:** Link the “Positive ABI probes” property to changes in the built guest, ABI probe runner and source-mapped panic collector; record which dependency or contract changes require rerunning it.
- [ ] **UC-M02.08-C013-T10 · Property disposition:** Compare the satisfying and violating “Positive ABI probes” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M02.08-C014 · Integration

**Original checklist item:** Integrate positive ABI probes with the built guest, ABI probe runner and source-mapped panic collector; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M02.08-C014-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Positive ABI probes” across the built guest, ABI probe runner and source-mapped panic collector; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M02.08-C014-T02 · Field mapping:** Map every “Positive ABI probes” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M02.08-C014-T03 · Prerequisite identities:** Record the actual prerequisites for “Positive ABI probes” (source dependency list: UC-M02.03, UC-M02.05, UC-M02.06, UC-M02.07); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M02.08-C014-T04 · Ownership agreement:** Specify who owns “Positive ABI probes” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M02.08-C014-T05 · Handoff implementation:** Connect “Positive ABI probes” through the mapped seam using the real adapter or explicit specification reference; preserve “A positive probe demonstrates guest-to-platform behavior rather than a mock response” across the handoff.
- [ ] **UC-M02.08-C014-T06 · Absent-input case:** Omit one required “Positive ABI probes” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M02.08-C014-T07 · Stale-input case:** Supply an outdated “Positive ABI probes” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M02.08-C014-T08 · Incompatible-input case:** Supply an incompatible “Positive ABI probes” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M02.08-C014-T09 · Valid integration trace:** Run a valid “Positive ABI probes” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M02.08-C014-T10 · Seam review:** Reconcile the “Positive ABI probes” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M02.08-C015 · Valid-case test

**Original checklist item:** Run a known-valid control for positive ABI probes; verify that the harness reaches its intended target and compare observed measurements or verdicts with predeclared expectations.

- [ ] **UC-M02.08-C015-T01 · Valid fixture choice:** Choose a known-valid control for “Positive ABI probes”; document why it should pass and how it proves the harness reaches the intended target.
- [ ] **UC-M02.08-C015-T02 · Expected-result oracle:** Specify the “Positive ABI probes” expected result independently of the implementation output; include the property “A positive probe demonstrates guest-to-platform behavior rather than a mock response” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M02.08-C015-T03 · Fixture material:** Create the concrete “Positive ABI probes” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M02.08-C015-T04 · Target preparation:** Prepare the “Positive ABI probes” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M02.08-C015-T05 · Initial-state record:** Record the initial “Positive ABI probes” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M02.08-C015-T06 · Valid-path execution:** Run the “Positive ABI probes” known-valid control on the identified target; retain enough observations to prove the correct target was exercised.
- [ ] **UC-M02.08-C015-T07 · Outcome comparison:** Compare every declared “Positive ABI probes” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M02.08-C015-T08 · State and bounds check:** Inspect the “Positive ABI probes” ownership/state effects and actual use of “Probe output bytes and execution deadline”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M02.08-C015-T09 · Repeatability check:** Repeat the same “Positive ABI probes” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M02.08-C015-T10 · Positive evidence:** Attach the “Positive ABI probes” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M02.08-C016 · Negative test

**Original checklist item:** Negative case: A host test harness supplies the expected output without guest execution. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M02.08-C016-T01 · Adverse-case definition:** Create a test record for the exact “Positive ABI probes” source counterexample: “A host test harness supplies the expected output without guest execution”; state which precondition or invariant it challenges.
- [ ] **UC-M02.08-C016-T02 · Safe fixture boundary:** Define the contained test boundary for “Positive ABI probes”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M02.08-C016-T03 · Valid control:** Construct a valid “Positive ABI probes” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M02.08-C016-T04 · Minimal adverse input:** Derive the “Positive ABI probes” adverse fixture from the control with the smallest documented change needed to reproduce “A host test harness supplies the expected output without guest execution”; retain that change as reproducible data.
- [ ] **UC-M02.08-C016-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Positive ABI probes”; require “A positive probe demonstrates guest-to-platform behavior rather than a mock response” and forbid a false-success verdict.
- [ ] **UC-M02.08-C016-T06 · Adverse execution:** Exercise the “Positive ABI probes” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M02.08-C016-T07 · Effect inspection:** Inspect “Positive ABI probes” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M02.08-C016-T08 · Refusal versus failure:** Confirm the “Positive ABI probes” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M02.08-C016-T09 · Reset and retention:** Restore only the disposable “Positive ABI probes” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M02.08-C016-T10 · Negative regression:** Register the “Positive ABI probes” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M02.08-C017 · Change / failure test

**Original checklist item:** Exercise positive ABI probes when the image is rebuilt and previously collected ABI and panic evidence becomes stale; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M02.08-C017-T01 · Scenario record:** Write the “Positive ABI probes” change/failure scenario exactly as supplied: the image is rebuilt and previously collected ABI and panic evidence becomes stale; identify the property that must remain true: “A positive probe demonstrates guest-to-platform behavior rather than a mock response”.
- [ ] **UC-M02.08-C017-T02 · Baseline capture:** Create a known-valid “Positive ABI probes” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M02.08-C017-T03 · Injection map:** Locate the “Positive ABI probes” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M02.08-C017-T04 · Disposition oracle:** Define the legal intermediate and final “Positive ABI probes” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M02.08-C017-T05 · Controlled trigger:** Introduce the controlled “Positive ABI probes” scenario in the disposable fixture: the image is rebuilt and previously collected ABI and panic evidence becomes stale; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M02.08-C017-T06 · Intermediate inspection:** Inspect the “Positive ABI probes” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M02.08-C017-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Positive ABI probes”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M02.08-C017-T08 · Stale-evidence cleanup:** Invalidate superseded “Positive ABI probes” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M02.08-C017-T09 · Repeat and compare:** Repeat the selected “Positive ABI probes” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M02.08-C017-T10 · Failure evidence:** Publish the “Positive ABI probes” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M02.08-C018 · Bounds

**Original checklist item:** Set a documented campaign budget for probe output bytes and execution deadline; record actual consumption, incomplete coverage and the disposition when the budget is exhausted.

- [ ] **UC-M02.08-C018-T01 · Quantity inventory:** Create a measurement inventory for “Positive ABI probes”: “Probe output bytes and execution deadline”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M02.08-C018-T02 · Measurement method:** Choose how to observe each “Positive ABI probes” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M02.08-C018-T03 · Budget decision:** Select justified campaign and target-resource budgets for “Positive ABI probes”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M02.08-C018-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Positive ABI probes” cases for “Probe output bytes and execution deadline”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M02.08-C018-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Positive ABI probes” limit; preserve “A positive probe demonstrates guest-to-platform behavior rather than a mock response”.
- [ ] **UC-M02.08-C018-T06 · Normal measurement:** Run or review the normal “Positive ABI probes” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M02.08-C018-T07 · At-limit measurement:** Exercise the “Positive ABI probes” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M02.08-C018-T08 · Over-limit measurement:** Exercise the “Positive ABI probes” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M02.08-C018-T09 · Uncovered-scope report:** List the “Positive ABI probes” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M02.08-C018-T10 · Limit evidence:** Publish the selected “Positive ABI probes” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M02.08-C019 · Diagnostics / review

**Original checklist item:** Report positive ABI probes results with executed, failed, skipped and unavailable cases separated; preserve the underlying observations and do not manufacture missing measurements.

- [ ] **UC-M02.08-C019-T01 · Result inventory:** Enumerate the required “Positive ABI probes” qualification cases and intended targets before aggregating results; keep the planned denominator visible.
- [ ] **UC-M02.08-C019-T02 · Verdict schema:** Define separate executed-pass, executed-fail, skipped, unavailable and untested outcomes for “Positive ABI probes”; document how incomplete cases block relevant claims.
- [ ] **UC-M02.08-C019-T03 · Identity fields:** Attach the actual target, fixture, configuration and revision identifiers to each “Positive ABI probes” result; do not attribute host-only evidence to a guest or another OS.
- [ ] **UC-M02.08-C019-T04 · Observation capture:** Capture bounded raw “Positive ABI probes” observations and harness errors; retain enough information to verify the reported oracle comparison.
- [ ] **UC-M02.08-C019-T05 · Aggregation rules:** Implement the “Positive ABI probes” count/reduction rule so failures and missing measurements cannot disappear; preserve “A positive probe demonstrates guest-to-platform behavior rather than a mock response”.
- [ ] **UC-M02.08-C019-T06 · Failure visibility:** Feed a failing “Positive ABI probes” control through the report path; assert the exact failed case and underlying observation remain visible.
- [ ] **UC-M02.08-C019-T07 · Missing-result visibility:** Withhold a required “Positive ABI probes” measurement or target; verify the report uses unavailable/untested rather than a fabricated zero or passing value.
- [ ] **UC-M02.08-C019-T08 · Bounds and redaction:** Check “Positive ABI probes” report size and retention against “Probe output bytes and execution deadline”; remove secrets while retaining fixture and subject references.
- [ ] **UC-M02.08-C019-T09 · Report reconciliation:** Reconcile the “Positive ABI probes” summary with every underlying case record; account for the full planned denominator and all omitted scope.
- [ ] **UC-M02.08-C019-T10 · Qualification handoff:** Publish the “Positive ABI probes” report with measured observations, coverage limits and blockers; state which actual targets remain unqualified.

### UC-M02.08-C020 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for positive ABI probes; label unexecuted checks as untested.

- [ ] **UC-M02.08-C020-T01 · Evidence inventory:** List the “Positive ABI probes” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M02.08-C020-T02 · Artifact references:** Record the exact “Positive ABI probes” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M02.08-C020-T03 · Fixture references:** Attach the “Positive ABI probes” fixture IDs, input identities and oracle definition; preserve the source counterexample “A host test harness supplies the expected output without guest execution” as a distinct evidence case.
- [ ] **UC-M02.08-C020-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Positive ABI probes”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M02.08-C020-T05 · Environment record:** Record the actual “Positive ABI probes” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M02.08-C020-T06 · Expected versus observed:** Pair every “Positive ABI probes” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M02.08-C020-T07 · Failure and limit records:** Attach “Positive ABI probes” change/failure and bounds evidence where required; include uncovered “Probe output bytes and execution deadline” and unresolved violations of “A positive probe demonstrates guest-to-platform behavior rather than a mock response”.
- [ ] **UC-M02.08-C020-T08 · Evidence hygiene:** Check the “Positive ABI probes” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M02.08-C020-T09 · Reproduction review:** Have the “Positive ABI probes” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M02.08-C020-T10 · Acceptance linkage:** Link the “Positive ABI probes” evidence to its parent and UC-M02.08 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 03. Negative ABI probes

**Source delivery:** Implement malformed arguments and unsupported-operation probes.

**Source invariant:** Rejected ABI calls preserve the declared boundary and guest disposition.

**Source negative case:** An invalid buffer is accepted by an ABI call.

**Source bounded quantities:** Negative corpus size and per-probe resource limit.

### UC-M02.08-C021 · Contract

**Original checklist item:** Define the qualification objective for negative ABI probes, including the actual target implementation, prerequisites, observable oracle and explicit exclusions.

- [ ] **UC-M02.08-C021-T01 · Scope statement:** Write the qualification question for “Negative ABI probes”; identify the actual target, claimed capability and observations that can answer that question.
- [ ] **UC-M02.08-C021-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Negative ABI probes”; record each producer, representation and missing-value meaning.
- [ ] **UC-M02.08-C021-T03 · Output inventory:** List the outputs of “Negative ABI probes” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M02.08-C021-T04 · Field dictionary:** Create a field-and-term dictionary for “Negative ABI probes”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M02.08-C021-T05 · Prerequisite contract:** Map “Negative ABI probes” to the source component prerequisites (UC-M02.03, UC-M02.05, UC-M02.06, UC-M02.07); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M02.08-C021-T06 · Authority map:** Identify who may produce, change and consume “Negative ABI probes”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M02.08-C021-T07 · Invariant clause:** Add a normative clause for “Negative ABI probes” that preserves “Rejected ABI calls preserve the declared boundary and guest disposition”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M02.08-C021-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Negative ABI probes”; include the source counterexample “An invalid buffer is accepted by an ABI call” and the intended safe disposition.
- [ ] **UC-M02.08-C021-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Negative corpus size and per-probe resource limit” in the “Negative ABI probes” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M02.08-C021-T10 · Contract review:** Review the “Negative ABI probes” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M02.08-C022 · Delivery

**Original checklist item:** Implement malformed arguments and unsupported-operation probes.

- [ ] **UC-M02.08-C022-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Negative ABI probes”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M02.08-C022-T02 · Change plan:** Break the source delivery for “Negative ABI probes” into concrete edit targets and reviewable outputs; keep the UC-M02.08 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M02.08-C022-T03 · Core artifact:** Implement the smallest selected-profile change for “Negative ABI probes” that realizes this source instruction: Implement malformed arguments and unsupported-operation probes.
- [ ] **UC-M02.08-C022-T04 · Concrete realization:** Trace “Negative ABI probes” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M02.08-C022-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Negative ABI probes” needed to preserve “Rejected ABI calls preserve the declared boundary and guest disposition”; record an enforcement gap where only a model exists.
- [ ] **UC-M02.08-C022-T06 · Dependency connection:** Connect the “Negative ABI probes” qualification artifact to the built guest, ABI probe runner and source-mapped panic collector; record the target identity and what the harness actually exercises.
- [ ] **UC-M02.08-C022-T07 · Resource behavior:** Account for “Negative corpus size and per-probe resource limit” in “Negative ABI probes”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M02.08-C022-T08 · Delivery check:** Run a known-valid control and a deliberately failing control for “Negative ABI probes”; confirm the harness distinguishes their observed outcomes.
- [ ] **UC-M02.08-C022-T09 · Patch review:** Review the “Negative ABI probes” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M02.08-C022-T10 · Delivery handoff:** Publish the “Negative ABI probes” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M02.08-C023 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Rejected ABI calls preserve the declared boundary and guest disposition. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M02.08-C023-T01 · Named property:** Create a stable property/check name under this parent for “Negative ABI probes”; copy its required invariant exactly: “Rejected ABI calls preserve the declared boundary and guest disposition”.
- [ ] **UC-M02.08-C023-T02 · Observable terms:** Define each term in the “Negative ABI probes” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M02.08-C023-T03 · Precondition set:** List the preconditions under which “Rejected ABI calls preserve the declared boundary and guest disposition” must hold for “Negative ABI probes”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M02.08-C023-T04 · Transition coverage:** Map the “Negative ABI probes” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M02.08-C023-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Negative ABI probes”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M02.08-C023-T06 · Satisfying fixture:** Create a concrete “Negative ABI probes” case that satisfies “Rejected ABI calls preserve the declared boundary and guest disposition”; record its expected observation before running the assertion or review.
- [ ] **UC-M02.08-C023-T07 · Violating fixture:** Create the source counterexample “An invalid buffer is accepted by an ABI call” for “Negative ABI probes”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M02.08-C023-T08 · Enforcement evidence:** Exercise the “Negative ABI probes” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M02.08-C023-T09 · Regression linkage:** Link the “Negative ABI probes” property to changes in the built guest, ABI probe runner and source-mapped panic collector; record which dependency or contract changes require rerunning it.
- [ ] **UC-M02.08-C023-T10 · Property disposition:** Compare the satisfying and violating “Negative ABI probes” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M02.08-C024 · Integration

**Original checklist item:** Integrate negative ABI probes with the built guest, ABI probe runner and source-mapped panic collector; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M02.08-C024-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Negative ABI probes” across the built guest, ABI probe runner and source-mapped panic collector; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M02.08-C024-T02 · Field mapping:** Map every “Negative ABI probes” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M02.08-C024-T03 · Prerequisite identities:** Record the actual prerequisites for “Negative ABI probes” (source dependency list: UC-M02.03, UC-M02.05, UC-M02.06, UC-M02.07); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M02.08-C024-T04 · Ownership agreement:** Specify who owns “Negative ABI probes” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M02.08-C024-T05 · Handoff implementation:** Connect “Negative ABI probes” through the mapped seam using the real adapter or explicit specification reference; preserve “Rejected ABI calls preserve the declared boundary and guest disposition” across the handoff.
- [ ] **UC-M02.08-C024-T06 · Absent-input case:** Omit one required “Negative ABI probes” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M02.08-C024-T07 · Stale-input case:** Supply an outdated “Negative ABI probes” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M02.08-C024-T08 · Incompatible-input case:** Supply an incompatible “Negative ABI probes” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M02.08-C024-T09 · Valid integration trace:** Run a valid “Negative ABI probes” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M02.08-C024-T10 · Seam review:** Reconcile the “Negative ABI probes” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M02.08-C025 · Valid-case test

**Original checklist item:** Run a known-valid control for negative ABI probes; verify that the harness reaches its intended target and compare observed measurements or verdicts with predeclared expectations.

- [ ] **UC-M02.08-C025-T01 · Valid fixture choice:** Choose a known-valid control for “Negative ABI probes”; document why it should pass and how it proves the harness reaches the intended target.
- [ ] **UC-M02.08-C025-T02 · Expected-result oracle:** Specify the “Negative ABI probes” expected result independently of the implementation output; include the property “Rejected ABI calls preserve the declared boundary and guest disposition” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M02.08-C025-T03 · Fixture material:** Create the concrete “Negative ABI probes” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M02.08-C025-T04 · Target preparation:** Prepare the “Negative ABI probes” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M02.08-C025-T05 · Initial-state record:** Record the initial “Negative ABI probes” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M02.08-C025-T06 · Valid-path execution:** Run the “Negative ABI probes” known-valid control on the identified target; retain enough observations to prove the correct target was exercised.
- [ ] **UC-M02.08-C025-T07 · Outcome comparison:** Compare every declared “Negative ABI probes” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M02.08-C025-T08 · State and bounds check:** Inspect the “Negative ABI probes” ownership/state effects and actual use of “Negative corpus size and per-probe resource limit”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M02.08-C025-T09 · Repeatability check:** Repeat the same “Negative ABI probes” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M02.08-C025-T10 · Positive evidence:** Attach the “Negative ABI probes” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M02.08-C026 · Negative test

**Original checklist item:** Negative case: An invalid buffer is accepted by an ABI call. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M02.08-C026-T01 · Adverse-case definition:** Create a test record for the exact “Negative ABI probes” source counterexample: “An invalid buffer is accepted by an ABI call”; state which precondition or invariant it challenges.
- [ ] **UC-M02.08-C026-T02 · Safe fixture boundary:** Define the contained test boundary for “Negative ABI probes”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M02.08-C026-T03 · Valid control:** Construct a valid “Negative ABI probes” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M02.08-C026-T04 · Minimal adverse input:** Derive the “Negative ABI probes” adverse fixture from the control with the smallest documented change needed to reproduce “An invalid buffer is accepted by an ABI call”; retain that change as reproducible data.
- [ ] **UC-M02.08-C026-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Negative ABI probes”; require “Rejected ABI calls preserve the declared boundary and guest disposition” and forbid a false-success verdict.
- [ ] **UC-M02.08-C026-T06 · Adverse execution:** Exercise the “Negative ABI probes” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M02.08-C026-T07 · Effect inspection:** Inspect “Negative ABI probes” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M02.08-C026-T08 · Refusal versus failure:** Confirm the “Negative ABI probes” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M02.08-C026-T09 · Reset and retention:** Restore only the disposable “Negative ABI probes” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M02.08-C026-T10 · Negative regression:** Register the “Negative ABI probes” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M02.08-C027 · Change / failure test

**Original checklist item:** Exercise negative ABI probes when the image is rebuilt and previously collected ABI and panic evidence becomes stale; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M02.08-C027-T01 · Scenario record:** Write the “Negative ABI probes” change/failure scenario exactly as supplied: the image is rebuilt and previously collected ABI and panic evidence becomes stale; identify the property that must remain true: “Rejected ABI calls preserve the declared boundary and guest disposition”.
- [ ] **UC-M02.08-C027-T02 · Baseline capture:** Create a known-valid “Negative ABI probes” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M02.08-C027-T03 · Injection map:** Locate the “Negative ABI probes” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M02.08-C027-T04 · Disposition oracle:** Define the legal intermediate and final “Negative ABI probes” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M02.08-C027-T05 · Controlled trigger:** Introduce the controlled “Negative ABI probes” scenario in the disposable fixture: the image is rebuilt and previously collected ABI and panic evidence becomes stale; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M02.08-C027-T06 · Intermediate inspection:** Inspect the “Negative ABI probes” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M02.08-C027-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Negative ABI probes”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M02.08-C027-T08 · Stale-evidence cleanup:** Invalidate superseded “Negative ABI probes” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M02.08-C027-T09 · Repeat and compare:** Repeat the selected “Negative ABI probes” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M02.08-C027-T10 · Failure evidence:** Publish the “Negative ABI probes” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M02.08-C028 · Bounds

**Original checklist item:** Set a documented campaign budget for negative corpus size and per-probe resource limit; record actual consumption, incomplete coverage and the disposition when the budget is exhausted.

- [ ] **UC-M02.08-C028-T01 · Quantity inventory:** Create a measurement inventory for “Negative ABI probes”: “Negative corpus size and per-probe resource limit”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M02.08-C028-T02 · Measurement method:** Choose how to observe each “Negative ABI probes” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M02.08-C028-T03 · Budget decision:** Select justified campaign and target-resource budgets for “Negative ABI probes”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M02.08-C028-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Negative ABI probes” cases for “Negative corpus size and per-probe resource limit”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M02.08-C028-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Negative ABI probes” limit; preserve “Rejected ABI calls preserve the declared boundary and guest disposition”.
- [ ] **UC-M02.08-C028-T06 · Normal measurement:** Run or review the normal “Negative ABI probes” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M02.08-C028-T07 · At-limit measurement:** Exercise the “Negative ABI probes” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M02.08-C028-T08 · Over-limit measurement:** Exercise the “Negative ABI probes” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M02.08-C028-T09 · Uncovered-scope report:** List the “Negative ABI probes” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M02.08-C028-T10 · Limit evidence:** Publish the selected “Negative ABI probes” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M02.08-C029 · Diagnostics / review

**Original checklist item:** Report negative ABI probes results with executed, failed, skipped and unavailable cases separated; preserve the underlying observations and do not manufacture missing measurements.

- [ ] **UC-M02.08-C029-T01 · Result inventory:** Enumerate the required “Negative ABI probes” qualification cases and intended targets before aggregating results; keep the planned denominator visible.
- [ ] **UC-M02.08-C029-T02 · Verdict schema:** Define separate executed-pass, executed-fail, skipped, unavailable and untested outcomes for “Negative ABI probes”; document how incomplete cases block relevant claims.
- [ ] **UC-M02.08-C029-T03 · Identity fields:** Attach the actual target, fixture, configuration and revision identifiers to each “Negative ABI probes” result; do not attribute host-only evidence to a guest or another OS.
- [ ] **UC-M02.08-C029-T04 · Observation capture:** Capture bounded raw “Negative ABI probes” observations and harness errors; retain enough information to verify the reported oracle comparison.
- [ ] **UC-M02.08-C029-T05 · Aggregation rules:** Implement the “Negative ABI probes” count/reduction rule so failures and missing measurements cannot disappear; preserve “Rejected ABI calls preserve the declared boundary and guest disposition”.
- [ ] **UC-M02.08-C029-T06 · Failure visibility:** Feed a failing “Negative ABI probes” control through the report path; assert the exact failed case and underlying observation remain visible.
- [ ] **UC-M02.08-C029-T07 · Missing-result visibility:** Withhold a required “Negative ABI probes” measurement or target; verify the report uses unavailable/untested rather than a fabricated zero or passing value.
- [ ] **UC-M02.08-C029-T08 · Bounds and redaction:** Check “Negative ABI probes” report size and retention against “Negative corpus size and per-probe resource limit”; remove secrets while retaining fixture and subject references.
- [ ] **UC-M02.08-C029-T09 · Report reconciliation:** Reconcile the “Negative ABI probes” summary with every underlying case record; account for the full planned denominator and all omitted scope.
- [ ] **UC-M02.08-C029-T10 · Qualification handoff:** Publish the “Negative ABI probes” report with measured observations, coverage limits and blockers; state which actual targets remain unqualified.

### UC-M02.08-C030 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for negative ABI probes; label unexecuted checks as untested.

- [ ] **UC-M02.08-C030-T01 · Evidence inventory:** List the “Negative ABI probes” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M02.08-C030-T02 · Artifact references:** Record the exact “Negative ABI probes” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M02.08-C030-T03 · Fixture references:** Attach the “Negative ABI probes” fixture IDs, input identities and oracle definition; preserve the source counterexample “An invalid buffer is accepted by an ABI call” as a distinct evidence case.
- [ ] **UC-M02.08-C030-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Negative ABI probes”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M02.08-C030-T05 · Environment record:** Record the actual “Negative ABI probes” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M02.08-C030-T06 · Expected versus observed:** Pair every “Negative ABI probes” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M02.08-C030-T07 · Failure and limit records:** Attach “Negative ABI probes” change/failure and bounds evidence where required; include uncovered “Negative corpus size and per-probe resource limit” and unresolved violations of “Rejected ABI calls preserve the declared boundary and guest disposition”.
- [ ] **UC-M02.08-C030-T08 · Evidence hygiene:** Check the “Negative ABI probes” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M02.08-C030-T09 · Reproduction review:** Have the “Negative ABI probes” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M02.08-C030-T10 · Acceptance linkage:** Link the “Negative ABI probes” evidence to its parent and UC-M02.08 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 04. Boot-success evidence

**Source delivery:** Record image digest, ABI version and guest-ready observation.

**Source invariant:** Boot evidence cannot be reassigned to a different image or ABI.

**Source negative case:** A changed image reuses an earlier boot-success report.

**Source bounded quantities:** Evidence bytes and retention count.

### UC-M02.08-C031 · Contract

**Original checklist item:** Define the qualification objective for boot-success evidence, including the actual target implementation, prerequisites, observable oracle and explicit exclusions.

- [ ] **UC-M02.08-C031-T01 · Scope statement:** Write the qualification question for “Boot-success evidence”; identify the actual target, claimed capability and observations that can answer that question.
- [ ] **UC-M02.08-C031-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Boot-success evidence”; record each producer, representation and missing-value meaning.
- [ ] **UC-M02.08-C031-T03 · Output inventory:** List the outputs of “Boot-success evidence” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M02.08-C031-T04 · Field dictionary:** Create a field-and-term dictionary for “Boot-success evidence”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M02.08-C031-T05 · Prerequisite contract:** Map “Boot-success evidence” to the source component prerequisites (UC-M02.03, UC-M02.05, UC-M02.06, UC-M02.07); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M02.08-C031-T06 · Authority map:** Identify who may produce, change and consume “Boot-success evidence”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M02.08-C031-T07 · Invariant clause:** Add a normative clause for “Boot-success evidence” that preserves “Boot evidence cannot be reassigned to a different image or ABI”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M02.08-C031-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Boot-success evidence”; include the source counterexample “A changed image reuses an earlier boot-success report” and the intended safe disposition.
- [ ] **UC-M02.08-C031-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Evidence bytes and retention count” in the “Boot-success evidence” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M02.08-C031-T10 · Contract review:** Review the “Boot-success evidence” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M02.08-C032 · Delivery

**Original checklist item:** Record image digest, ABI version and guest-ready observation.

- [ ] **UC-M02.08-C032-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Boot-success evidence”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M02.08-C032-T02 · Change plan:** Break the source delivery for “Boot-success evidence” into concrete edit targets and reviewable outputs; keep the UC-M02.08 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M02.08-C032-T03 · Core artifact:** Create the “Boot-success evidence” model, schema or inventory that realizes this source instruction: Record image digest, ABI version and guest-ready observation.
- [ ] **UC-M02.08-C032-T04 · Concrete realization:** Populate “Boot-success evidence” with one concrete worked case; map every required entity or field to its source and flag any unmapped entry.
- [ ] **UC-M02.08-C032-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Boot-success evidence” needed to preserve “Boot evidence cannot be reassigned to a different image or ABI”; record an enforcement gap where only a model exists.
- [ ] **UC-M02.08-C032-T06 · Dependency connection:** Connect the “Boot-success evidence” qualification artifact to the built guest, ABI probe runner and source-mapped panic collector; record the target identity and what the harness actually exercises.
- [ ] **UC-M02.08-C032-T07 · Resource behavior:** Account for “Evidence bytes and retention count” in “Boot-success evidence”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M02.08-C032-T08 · Delivery check:** Run a known-valid control and a deliberately failing control for “Boot-success evidence”; confirm the harness distinguishes their observed outcomes.
- [ ] **UC-M02.08-C032-T09 · Patch review:** Review the “Boot-success evidence” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M02.08-C032-T10 · Delivery handoff:** Publish the “Boot-success evidence” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M02.08-C033 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Boot evidence cannot be reassigned to a different image or ABI. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M02.08-C033-T01 · Named property:** Create a stable property/check name under this parent for “Boot-success evidence”; copy its required invariant exactly: “Boot evidence cannot be reassigned to a different image or ABI”.
- [ ] **UC-M02.08-C033-T02 · Observable terms:** Define each term in the “Boot-success evidence” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M02.08-C033-T03 · Precondition set:** List the preconditions under which “Boot evidence cannot be reassigned to a different image or ABI” must hold for “Boot-success evidence”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M02.08-C033-T04 · Transition coverage:** Map the “Boot-success evidence” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M02.08-C033-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Boot-success evidence”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M02.08-C033-T06 · Satisfying fixture:** Create a concrete “Boot-success evidence” case that satisfies “Boot evidence cannot be reassigned to a different image or ABI”; record its expected observation before running the assertion or review.
- [ ] **UC-M02.08-C033-T07 · Violating fixture:** Create the source counterexample “A changed image reuses an earlier boot-success report” for “Boot-success evidence”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M02.08-C033-T08 · Enforcement evidence:** Exercise the “Boot-success evidence” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M02.08-C033-T09 · Regression linkage:** Link the “Boot-success evidence” property to changes in the built guest, ABI probe runner and source-mapped panic collector; record which dependency or contract changes require rerunning it.
- [ ] **UC-M02.08-C033-T10 · Property disposition:** Compare the satisfying and violating “Boot-success evidence” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M02.08-C034 · Integration

**Original checklist item:** Integrate boot-success evidence with the built guest, ABI probe runner and source-mapped panic collector; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M02.08-C034-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Boot-success evidence” across the built guest, ABI probe runner and source-mapped panic collector; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M02.08-C034-T02 · Field mapping:** Map every “Boot-success evidence” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M02.08-C034-T03 · Prerequisite identities:** Record the actual prerequisites for “Boot-success evidence” (source dependency list: UC-M02.03, UC-M02.05, UC-M02.06, UC-M02.07); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M02.08-C034-T04 · Ownership agreement:** Specify who owns “Boot-success evidence” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M02.08-C034-T05 · Handoff implementation:** Connect “Boot-success evidence” through the mapped seam using the real adapter or explicit specification reference; preserve “Boot evidence cannot be reassigned to a different image or ABI” across the handoff.
- [ ] **UC-M02.08-C034-T06 · Absent-input case:** Omit one required “Boot-success evidence” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M02.08-C034-T07 · Stale-input case:** Supply an outdated “Boot-success evidence” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M02.08-C034-T08 · Incompatible-input case:** Supply an incompatible “Boot-success evidence” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M02.08-C034-T09 · Valid integration trace:** Run a valid “Boot-success evidence” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M02.08-C034-T10 · Seam review:** Reconcile the “Boot-success evidence” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M02.08-C035 · Valid-case test

**Original checklist item:** Run a known-valid control for boot-success evidence; verify that the harness reaches its intended target and compare observed measurements or verdicts with predeclared expectations.

- [ ] **UC-M02.08-C035-T01 · Valid fixture choice:** Choose a known-valid control for “Boot-success evidence”; document why it should pass and how it proves the harness reaches the intended target.
- [ ] **UC-M02.08-C035-T02 · Expected-result oracle:** Specify the “Boot-success evidence” expected result independently of the implementation output; include the property “Boot evidence cannot be reassigned to a different image or ABI” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M02.08-C035-T03 · Fixture material:** Create the concrete “Boot-success evidence” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M02.08-C035-T04 · Target preparation:** Prepare the “Boot-success evidence” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M02.08-C035-T05 · Initial-state record:** Record the initial “Boot-success evidence” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M02.08-C035-T06 · Valid-path execution:** Run the “Boot-success evidence” known-valid control on the identified target; retain enough observations to prove the correct target was exercised.
- [ ] **UC-M02.08-C035-T07 · Outcome comparison:** Compare every declared “Boot-success evidence” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M02.08-C035-T08 · State and bounds check:** Inspect the “Boot-success evidence” ownership/state effects and actual use of “Evidence bytes and retention count”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M02.08-C035-T09 · Repeatability check:** Repeat the same “Boot-success evidence” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M02.08-C035-T10 · Positive evidence:** Attach the “Boot-success evidence” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M02.08-C036 · Negative test

**Original checklist item:** Negative case: A changed image reuses an earlier boot-success report. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M02.08-C036-T01 · Adverse-case definition:** Create a test record for the exact “Boot-success evidence” source counterexample: “A changed image reuses an earlier boot-success report”; state which precondition or invariant it challenges.
- [ ] **UC-M02.08-C036-T02 · Safe fixture boundary:** Define the contained test boundary for “Boot-success evidence”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M02.08-C036-T03 · Valid control:** Construct a valid “Boot-success evidence” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M02.08-C036-T04 · Minimal adverse input:** Derive the “Boot-success evidence” adverse fixture from the control with the smallest documented change needed to reproduce “A changed image reuses an earlier boot-success report”; retain that change as reproducible data.
- [ ] **UC-M02.08-C036-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Boot-success evidence”; require “Boot evidence cannot be reassigned to a different image or ABI” and forbid a false-success verdict.
- [ ] **UC-M02.08-C036-T06 · Adverse execution:** Exercise the “Boot-success evidence” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M02.08-C036-T07 · Effect inspection:** Inspect “Boot-success evidence” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M02.08-C036-T08 · Refusal versus failure:** Confirm the “Boot-success evidence” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M02.08-C036-T09 · Reset and retention:** Restore only the disposable “Boot-success evidence” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M02.08-C036-T10 · Negative regression:** Register the “Boot-success evidence” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M02.08-C037 · Change / failure test

**Original checklist item:** Exercise boot-success evidence when the image is rebuilt and previously collected ABI and panic evidence becomes stale; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M02.08-C037-T01 · Scenario record:** Write the “Boot-success evidence” change/failure scenario exactly as supplied: the image is rebuilt and previously collected ABI and panic evidence becomes stale; identify the property that must remain true: “Boot evidence cannot be reassigned to a different image or ABI”.
- [ ] **UC-M02.08-C037-T02 · Baseline capture:** Create a known-valid “Boot-success evidence” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M02.08-C037-T03 · Injection map:** Locate the “Boot-success evidence” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M02.08-C037-T04 · Disposition oracle:** Define the legal intermediate and final “Boot-success evidence” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M02.08-C037-T05 · Controlled trigger:** Introduce the controlled “Boot-success evidence” scenario in the disposable fixture: the image is rebuilt and previously collected ABI and panic evidence becomes stale; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M02.08-C037-T06 · Intermediate inspection:** Inspect the “Boot-success evidence” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M02.08-C037-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Boot-success evidence”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M02.08-C037-T08 · Stale-evidence cleanup:** Invalidate superseded “Boot-success evidence” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M02.08-C037-T09 · Repeat and compare:** Repeat the selected “Boot-success evidence” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M02.08-C037-T10 · Failure evidence:** Publish the “Boot-success evidence” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M02.08-C038 · Bounds

**Original checklist item:** Set a documented campaign budget for evidence bytes and retention count; record actual consumption, incomplete coverage and the disposition when the budget is exhausted.

- [ ] **UC-M02.08-C038-T01 · Quantity inventory:** Create a measurement inventory for “Boot-success evidence”: “Evidence bytes and retention count”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M02.08-C038-T02 · Measurement method:** Choose how to observe each “Boot-success evidence” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M02.08-C038-T03 · Budget decision:** Select justified campaign and target-resource budgets for “Boot-success evidence”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M02.08-C038-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Boot-success evidence” cases for “Evidence bytes and retention count”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M02.08-C038-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Boot-success evidence” limit; preserve “Boot evidence cannot be reassigned to a different image or ABI”.
- [ ] **UC-M02.08-C038-T06 · Normal measurement:** Run or review the normal “Boot-success evidence” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M02.08-C038-T07 · At-limit measurement:** Exercise the “Boot-success evidence” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M02.08-C038-T08 · Over-limit measurement:** Exercise the “Boot-success evidence” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M02.08-C038-T09 · Uncovered-scope report:** List the “Boot-success evidence” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M02.08-C038-T10 · Limit evidence:** Publish the selected “Boot-success evidence” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M02.08-C039 · Diagnostics / review

**Original checklist item:** Report boot-success evidence results with executed, failed, skipped and unavailable cases separated; preserve the underlying observations and do not manufacture missing measurements.

- [ ] **UC-M02.08-C039-T01 · Result inventory:** Enumerate the required “Boot-success evidence” qualification cases and intended targets before aggregating results; keep the planned denominator visible.
- [ ] **UC-M02.08-C039-T02 · Verdict schema:** Define separate executed-pass, executed-fail, skipped, unavailable and untested outcomes for “Boot-success evidence”; document how incomplete cases block relevant claims.
- [ ] **UC-M02.08-C039-T03 · Identity fields:** Attach the actual target, fixture, configuration and revision identifiers to each “Boot-success evidence” result; do not attribute host-only evidence to a guest or another OS.
- [ ] **UC-M02.08-C039-T04 · Observation capture:** Capture bounded raw “Boot-success evidence” observations and harness errors; retain enough information to verify the reported oracle comparison.
- [ ] **UC-M02.08-C039-T05 · Aggregation rules:** Implement the “Boot-success evidence” count/reduction rule so failures and missing measurements cannot disappear; preserve “Boot evidence cannot be reassigned to a different image or ABI”.
- [ ] **UC-M02.08-C039-T06 · Failure visibility:** Feed a failing “Boot-success evidence” control through the report path; assert the exact failed case and underlying observation remain visible.
- [ ] **UC-M02.08-C039-T07 · Missing-result visibility:** Withhold a required “Boot-success evidence” measurement or target; verify the report uses unavailable/untested rather than a fabricated zero or passing value.
- [ ] **UC-M02.08-C039-T08 · Bounds and redaction:** Check “Boot-success evidence” report size and retention against “Evidence bytes and retention count”; remove secrets while retaining fixture and subject references.
- [ ] **UC-M02.08-C039-T09 · Report reconciliation:** Reconcile the “Boot-success evidence” summary with every underlying case record; account for the full planned denominator and all omitted scope.
- [ ] **UC-M02.08-C039-T10 · Qualification handoff:** Publish the “Boot-success evidence” report with measured observations, coverage limits and blockers; state which actual targets remain unqualified.

### UC-M02.08-C040 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for boot-success evidence; label unexecuted checks as untested.

- [ ] **UC-M02.08-C040-T01 · Evidence inventory:** List the “Boot-success evidence” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M02.08-C040-T02 · Artifact references:** Record the exact “Boot-success evidence” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M02.08-C040-T03 · Fixture references:** Attach the “Boot-success evidence” fixture IDs, input identities and oracle definition; preserve the source counterexample “A changed image reuses an earlier boot-success report” as a distinct evidence case.
- [ ] **UC-M02.08-C040-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Boot-success evidence”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M02.08-C040-T05 · Environment record:** Record the actual “Boot-success evidence” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M02.08-C040-T06 · Expected versus observed:** Pair every “Boot-success evidence” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M02.08-C040-T07 · Failure and limit records:** Attach “Boot-success evidence” change/failure and bounds evidence where required; include uncovered “Evidence bytes and retention count” and unresolved violations of “Boot evidence cannot be reassigned to a different image or ABI”.
- [ ] **UC-M02.08-C040-T08 · Evidence hygiene:** Check the “Boot-success evidence” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M02.08-C040-T09 · Reproduction review:** Have the “Boot-success evidence” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M02.08-C040-T10 · Acceptance linkage:** Link the “Boot-success evidence” evidence to its parent and UC-M02.08 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 05. Application output evidence

**Source delivery:** Capture the selected workload's actual output alongside ABI observations.

**Source invariant:** ABI success is separate from application correctness.

**Source negative case:** A guest passes boot probes but produces the wrong workload output.

**Source bounded quantities:** Output bytes and oracle comparison time.

### UC-M02.08-C041 · Contract

**Original checklist item:** Define the qualification objective for application output evidence, including the actual target implementation, prerequisites, observable oracle and explicit exclusions.

- [ ] **UC-M02.08-C041-T01 · Scope statement:** Write the qualification question for “Application output evidence”; identify the actual target, claimed capability and observations that can answer that question.
- [ ] **UC-M02.08-C041-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Application output evidence”; record each producer, representation and missing-value meaning.
- [ ] **UC-M02.08-C041-T03 · Output inventory:** List the outputs of “Application output evidence” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M02.08-C041-T04 · Field dictionary:** Create a field-and-term dictionary for “Application output evidence”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M02.08-C041-T05 · Prerequisite contract:** Map “Application output evidence” to the source component prerequisites (UC-M02.03, UC-M02.05, UC-M02.06, UC-M02.07); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M02.08-C041-T06 · Authority map:** Identify who may produce, change and consume “Application output evidence”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M02.08-C041-T07 · Invariant clause:** Add a normative clause for “Application output evidence” that preserves “ABI success is separate from application correctness”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M02.08-C041-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Application output evidence”; include the source counterexample “A guest passes boot probes but produces the wrong workload output” and the intended safe disposition.
- [ ] **UC-M02.08-C041-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Output bytes and oracle comparison time” in the “Application output evidence” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M02.08-C041-T10 · Contract review:** Review the “Application output evidence” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M02.08-C042 · Delivery

**Original checklist item:** Capture the selected workload's actual output alongside ABI observations.

- [ ] **UC-M02.08-C042-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Application output evidence”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M02.08-C042-T02 · Change plan:** Break the source delivery for “Application output evidence” into concrete edit targets and reviewable outputs; keep the UC-M02.08 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M02.08-C042-T03 · Core artifact:** Create the “Application output evidence” output artifact for this source instruction: Capture the selected workload's actual output alongside ABI observations.
- [ ] **UC-M02.08-C042-T04 · Concrete realization:** Populate the “Application output evidence” artifact from identified observations; keep unknown, failed and unexecuted results distinct and exclude unapproved sensitive material.
- [ ] **UC-M02.08-C042-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Application output evidence” needed to preserve “ABI success is separate from application correctness”; record an enforcement gap where only a model exists.
- [ ] **UC-M02.08-C042-T06 · Dependency connection:** Connect the “Application output evidence” qualification artifact to the built guest, ABI probe runner and source-mapped panic collector; record the target identity and what the harness actually exercises.
- [ ] **UC-M02.08-C042-T07 · Resource behavior:** Account for “Output bytes and oracle comparison time” in “Application output evidence”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M02.08-C042-T08 · Delivery check:** Run a known-valid control and a deliberately failing control for “Application output evidence”; confirm the harness distinguishes their observed outcomes.
- [ ] **UC-M02.08-C042-T09 · Patch review:** Review the “Application output evidence” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M02.08-C042-T10 · Delivery handoff:** Publish the “Application output evidence” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M02.08-C043 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: ABI success is separate from application correctness. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M02.08-C043-T01 · Named property:** Create a stable property/check name under this parent for “Application output evidence”; copy its required invariant exactly: “ABI success is separate from application correctness”.
- [ ] **UC-M02.08-C043-T02 · Observable terms:** Define each term in the “Application output evidence” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M02.08-C043-T03 · Precondition set:** List the preconditions under which “ABI success is separate from application correctness” must hold for “Application output evidence”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M02.08-C043-T04 · Transition coverage:** Map the “Application output evidence” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M02.08-C043-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Application output evidence”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M02.08-C043-T06 · Satisfying fixture:** Create a concrete “Application output evidence” case that satisfies “ABI success is separate from application correctness”; record its expected observation before running the assertion or review.
- [ ] **UC-M02.08-C043-T07 · Violating fixture:** Create the source counterexample “A guest passes boot probes but produces the wrong workload output” for “Application output evidence”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M02.08-C043-T08 · Enforcement evidence:** Exercise the “Application output evidence” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M02.08-C043-T09 · Regression linkage:** Link the “Application output evidence” property to changes in the built guest, ABI probe runner and source-mapped panic collector; record which dependency or contract changes require rerunning it.
- [ ] **UC-M02.08-C043-T10 · Property disposition:** Compare the satisfying and violating “Application output evidence” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M02.08-C044 · Integration

**Original checklist item:** Integrate application output evidence with the built guest, ABI probe runner and source-mapped panic collector; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M02.08-C044-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Application output evidence” across the built guest, ABI probe runner and source-mapped panic collector; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M02.08-C044-T02 · Field mapping:** Map every “Application output evidence” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M02.08-C044-T03 · Prerequisite identities:** Record the actual prerequisites for “Application output evidence” (source dependency list: UC-M02.03, UC-M02.05, UC-M02.06, UC-M02.07); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M02.08-C044-T04 · Ownership agreement:** Specify who owns “Application output evidence” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M02.08-C044-T05 · Handoff implementation:** Connect “Application output evidence” through the mapped seam using the real adapter or explicit specification reference; preserve “ABI success is separate from application correctness” across the handoff.
- [ ] **UC-M02.08-C044-T06 · Absent-input case:** Omit one required “Application output evidence” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M02.08-C044-T07 · Stale-input case:** Supply an outdated “Application output evidence” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M02.08-C044-T08 · Incompatible-input case:** Supply an incompatible “Application output evidence” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M02.08-C044-T09 · Valid integration trace:** Run a valid “Application output evidence” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M02.08-C044-T10 · Seam review:** Reconcile the “Application output evidence” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M02.08-C045 · Valid-case test

**Original checklist item:** Run a known-valid control for application output evidence; verify that the harness reaches its intended target and compare observed measurements or verdicts with predeclared expectations.

- [ ] **UC-M02.08-C045-T01 · Valid fixture choice:** Choose a known-valid control for “Application output evidence”; document why it should pass and how it proves the harness reaches the intended target.
- [ ] **UC-M02.08-C045-T02 · Expected-result oracle:** Specify the “Application output evidence” expected result independently of the implementation output; include the property “ABI success is separate from application correctness” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M02.08-C045-T03 · Fixture material:** Create the concrete “Application output evidence” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M02.08-C045-T04 · Target preparation:** Prepare the “Application output evidence” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M02.08-C045-T05 · Initial-state record:** Record the initial “Application output evidence” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M02.08-C045-T06 · Valid-path execution:** Run the “Application output evidence” known-valid control on the identified target; retain enough observations to prove the correct target was exercised.
- [ ] **UC-M02.08-C045-T07 · Outcome comparison:** Compare every declared “Application output evidence” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M02.08-C045-T08 · State and bounds check:** Inspect the “Application output evidence” ownership/state effects and actual use of “Output bytes and oracle comparison time”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M02.08-C045-T09 · Repeatability check:** Repeat the same “Application output evidence” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M02.08-C045-T10 · Positive evidence:** Attach the “Application output evidence” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M02.08-C046 · Negative test

**Original checklist item:** Negative case: A guest passes boot probes but produces the wrong workload output. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M02.08-C046-T01 · Adverse-case definition:** Create a test record for the exact “Application output evidence” source counterexample: “A guest passes boot probes but produces the wrong workload output”; state which precondition or invariant it challenges.
- [ ] **UC-M02.08-C046-T02 · Safe fixture boundary:** Define the contained test boundary for “Application output evidence”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M02.08-C046-T03 · Valid control:** Construct a valid “Application output evidence” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M02.08-C046-T04 · Minimal adverse input:** Derive the “Application output evidence” adverse fixture from the control with the smallest documented change needed to reproduce “A guest passes boot probes but produces the wrong workload output”; retain that change as reproducible data.
- [ ] **UC-M02.08-C046-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Application output evidence”; require “ABI success is separate from application correctness” and forbid a false-success verdict.
- [ ] **UC-M02.08-C046-T06 · Adverse execution:** Exercise the “Application output evidence” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M02.08-C046-T07 · Effect inspection:** Inspect “Application output evidence” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M02.08-C046-T08 · Refusal versus failure:** Confirm the “Application output evidence” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M02.08-C046-T09 · Reset and retention:** Restore only the disposable “Application output evidence” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M02.08-C046-T10 · Negative regression:** Register the “Application output evidence” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M02.08-C047 · Change / failure test

**Original checklist item:** Exercise application output evidence when the image is rebuilt and previously collected ABI and panic evidence becomes stale; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M02.08-C047-T01 · Scenario record:** Write the “Application output evidence” change/failure scenario exactly as supplied: the image is rebuilt and previously collected ABI and panic evidence becomes stale; identify the property that must remain true: “ABI success is separate from application correctness”.
- [ ] **UC-M02.08-C047-T02 · Baseline capture:** Create a known-valid “Application output evidence” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M02.08-C047-T03 · Injection map:** Locate the “Application output evidence” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M02.08-C047-T04 · Disposition oracle:** Define the legal intermediate and final “Application output evidence” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M02.08-C047-T05 · Controlled trigger:** Introduce the controlled “Application output evidence” scenario in the disposable fixture: the image is rebuilt and previously collected ABI and panic evidence becomes stale; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M02.08-C047-T06 · Intermediate inspection:** Inspect the “Application output evidence” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M02.08-C047-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Application output evidence”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M02.08-C047-T08 · Stale-evidence cleanup:** Invalidate superseded “Application output evidence” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M02.08-C047-T09 · Repeat and compare:** Repeat the selected “Application output evidence” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M02.08-C047-T10 · Failure evidence:** Publish the “Application output evidence” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M02.08-C048 · Bounds

**Original checklist item:** Set a documented campaign budget for output bytes and oracle comparison time; record actual consumption, incomplete coverage and the disposition when the budget is exhausted.

- [ ] **UC-M02.08-C048-T01 · Quantity inventory:** Create a measurement inventory for “Application output evidence”: “Output bytes and oracle comparison time”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M02.08-C048-T02 · Measurement method:** Choose how to observe each “Application output evidence” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M02.08-C048-T03 · Budget decision:** Select justified campaign and target-resource budgets for “Application output evidence”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M02.08-C048-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Application output evidence” cases for “Output bytes and oracle comparison time”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M02.08-C048-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Application output evidence” limit; preserve “ABI success is separate from application correctness”.
- [ ] **UC-M02.08-C048-T06 · Normal measurement:** Run or review the normal “Application output evidence” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M02.08-C048-T07 · At-limit measurement:** Exercise the “Application output evidence” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M02.08-C048-T08 · Over-limit measurement:** Exercise the “Application output evidence” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M02.08-C048-T09 · Uncovered-scope report:** List the “Application output evidence” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M02.08-C048-T10 · Limit evidence:** Publish the selected “Application output evidence” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M02.08-C049 · Diagnostics / review

**Original checklist item:** Report application output evidence results with executed, failed, skipped and unavailable cases separated; preserve the underlying observations and do not manufacture missing measurements.

- [ ] **UC-M02.08-C049-T01 · Result inventory:** Enumerate the required “Application output evidence” qualification cases and intended targets before aggregating results; keep the planned denominator visible.
- [ ] **UC-M02.08-C049-T02 · Verdict schema:** Define separate executed-pass, executed-fail, skipped, unavailable and untested outcomes for “Application output evidence”; document how incomplete cases block relevant claims.
- [ ] **UC-M02.08-C049-T03 · Identity fields:** Attach the actual target, fixture, configuration and revision identifiers to each “Application output evidence” result; do not attribute host-only evidence to a guest or another OS.
- [ ] **UC-M02.08-C049-T04 · Observation capture:** Capture bounded raw “Application output evidence” observations and harness errors; retain enough information to verify the reported oracle comparison.
- [ ] **UC-M02.08-C049-T05 · Aggregation rules:** Implement the “Application output evidence” count/reduction rule so failures and missing measurements cannot disappear; preserve “ABI success is separate from application correctness”.
- [ ] **UC-M02.08-C049-T06 · Failure visibility:** Feed a failing “Application output evidence” control through the report path; assert the exact failed case and underlying observation remain visible.
- [ ] **UC-M02.08-C049-T07 · Missing-result visibility:** Withhold a required “Application output evidence” measurement or target; verify the report uses unavailable/untested rather than a fabricated zero or passing value.
- [ ] **UC-M02.08-C049-T08 · Bounds and redaction:** Check “Application output evidence” report size and retention against “Output bytes and oracle comparison time”; remove secrets while retaining fixture and subject references.
- [ ] **UC-M02.08-C049-T09 · Report reconciliation:** Reconcile the “Application output evidence” summary with every underlying case record; account for the full planned denominator and all omitted scope.
- [ ] **UC-M02.08-C049-T10 · Qualification handoff:** Publish the “Application output evidence” report with measured observations, coverage limits and blockers; state which actual targets remain unqualified.

### UC-M02.08-C050 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for application output evidence; label unexecuted checks as untested.

- [ ] **UC-M02.08-C050-T01 · Evidence inventory:** List the “Application output evidence” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M02.08-C050-T02 · Artifact references:** Record the exact “Application output evidence” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M02.08-C050-T03 · Fixture references:** Attach the “Application output evidence” fixture IDs, input identities and oracle definition; preserve the source counterexample “A guest passes boot probes but produces the wrong workload output” as a distinct evidence case.
- [ ] **UC-M02.08-C050-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Application output evidence”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M02.08-C050-T05 · Environment record:** Record the actual “Application output evidence” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M02.08-C050-T06 · Expected versus observed:** Pair every “Application output evidence” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M02.08-C050-T07 · Failure and limit records:** Attach “Application output evidence” change/failure and bounds evidence where required; include uncovered “Output bytes and oracle comparison time” and unresolved violations of “ABI success is separate from application correctness”.
- [ ] **UC-M02.08-C050-T08 · Evidence hygiene:** Check the “Application output evidence” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M02.08-C050-T09 · Reproduction review:** Have the “Application output evidence” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M02.08-C050-T10 · Acceptance linkage:** Link the “Application output evidence” evidence to its parent and UC-M02.08 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 06. Panic record schema

**Source delivery:** Define bounded panic records with stage, reason and guest identity.

**Source invariant:** Panic reporting does not require trusting unlimited guest data.

**Source negative case:** A panic contains an oversized or malformed message.

**Source bounded quantities:** Panic bytes and nested diagnostic depth.

### UC-M02.08-C051 · Contract

**Original checklist item:** Define the qualification objective for panic record schema, including the actual target implementation, prerequisites, observable oracle and explicit exclusions.

- [ ] **UC-M02.08-C051-T01 · Scope statement:** Write the qualification question for “Panic record schema”; identify the actual target, claimed capability and observations that can answer that question.
- [ ] **UC-M02.08-C051-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Panic record schema”; record each producer, representation and missing-value meaning.
- [ ] **UC-M02.08-C051-T03 · Output inventory:** List the outputs of “Panic record schema” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M02.08-C051-T04 · Field dictionary:** Create a field-and-term dictionary for “Panic record schema”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M02.08-C051-T05 · Prerequisite contract:** Map “Panic record schema” to the source component prerequisites (UC-M02.03, UC-M02.05, UC-M02.06, UC-M02.07); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M02.08-C051-T06 · Authority map:** Identify who may produce, change and consume “Panic record schema”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M02.08-C051-T07 · Invariant clause:** Add a normative clause for “Panic record schema” that preserves “Panic reporting does not require trusting unlimited guest data”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M02.08-C051-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Panic record schema”; include the source counterexample “A panic contains an oversized or malformed message” and the intended safe disposition.
- [ ] **UC-M02.08-C051-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Panic bytes and nested diagnostic depth” in the “Panic record schema” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M02.08-C051-T10 · Contract review:** Review the “Panic record schema” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M02.08-C052 · Delivery

**Original checklist item:** Define bounded panic records with stage, reason and guest identity.

- [ ] **UC-M02.08-C052-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Panic record schema”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M02.08-C052-T02 · Change plan:** Break the source delivery for “Panic record schema” into concrete edit targets and reviewable outputs; keep the UC-M02.08 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M02.08-C052-T03 · Core artifact:** Create the “Panic record schema” model, schema or inventory that realizes this source instruction: Define bounded panic records with stage, reason and guest identity.
- [ ] **UC-M02.08-C052-T04 · Concrete realization:** Populate “Panic record schema” with one concrete worked case; map every required entity or field to its source and flag any unmapped entry.
- [ ] **UC-M02.08-C052-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Panic record schema” needed to preserve “Panic reporting does not require trusting unlimited guest data”; record an enforcement gap where only a model exists.
- [ ] **UC-M02.08-C052-T06 · Dependency connection:** Connect the “Panic record schema” qualification artifact to the built guest, ABI probe runner and source-mapped panic collector; record the target identity and what the harness actually exercises.
- [ ] **UC-M02.08-C052-T07 · Resource behavior:** Account for “Panic bytes and nested diagnostic depth” in “Panic record schema”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M02.08-C052-T08 · Delivery check:** Run a known-valid control and a deliberately failing control for “Panic record schema”; confirm the harness distinguishes their observed outcomes.
- [ ] **UC-M02.08-C052-T09 · Patch review:** Review the “Panic record schema” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M02.08-C052-T10 · Delivery handoff:** Publish the “Panic record schema” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M02.08-C053 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Panic reporting does not require trusting unlimited guest data. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M02.08-C053-T01 · Named property:** Create a stable property/check name under this parent for “Panic record schema”; copy its required invariant exactly: “Panic reporting does not require trusting unlimited guest data”.
- [ ] **UC-M02.08-C053-T02 · Observable terms:** Define each term in the “Panic record schema” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M02.08-C053-T03 · Precondition set:** List the preconditions under which “Panic reporting does not require trusting unlimited guest data” must hold for “Panic record schema”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M02.08-C053-T04 · Transition coverage:** Map the “Panic record schema” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M02.08-C053-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Panic record schema”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M02.08-C053-T06 · Satisfying fixture:** Create a concrete “Panic record schema” case that satisfies “Panic reporting does not require trusting unlimited guest data”; record its expected observation before running the assertion or review.
- [ ] **UC-M02.08-C053-T07 · Violating fixture:** Create the source counterexample “A panic contains an oversized or malformed message” for “Panic record schema”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M02.08-C053-T08 · Enforcement evidence:** Exercise the “Panic record schema” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M02.08-C053-T09 · Regression linkage:** Link the “Panic record schema” property to changes in the built guest, ABI probe runner and source-mapped panic collector; record which dependency or contract changes require rerunning it.
- [ ] **UC-M02.08-C053-T10 · Property disposition:** Compare the satisfying and violating “Panic record schema” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M02.08-C054 · Integration

**Original checklist item:** Integrate panic record schema with the built guest, ABI probe runner and source-mapped panic collector; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M02.08-C054-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Panic record schema” across the built guest, ABI probe runner and source-mapped panic collector; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M02.08-C054-T02 · Field mapping:** Map every “Panic record schema” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M02.08-C054-T03 · Prerequisite identities:** Record the actual prerequisites for “Panic record schema” (source dependency list: UC-M02.03, UC-M02.05, UC-M02.06, UC-M02.07); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M02.08-C054-T04 · Ownership agreement:** Specify who owns “Panic record schema” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M02.08-C054-T05 · Handoff implementation:** Connect “Panic record schema” through the mapped seam using the real adapter or explicit specification reference; preserve “Panic reporting does not require trusting unlimited guest data” across the handoff.
- [ ] **UC-M02.08-C054-T06 · Absent-input case:** Omit one required “Panic record schema” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M02.08-C054-T07 · Stale-input case:** Supply an outdated “Panic record schema” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M02.08-C054-T08 · Incompatible-input case:** Supply an incompatible “Panic record schema” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M02.08-C054-T09 · Valid integration trace:** Run a valid “Panic record schema” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M02.08-C054-T10 · Seam review:** Reconcile the “Panic record schema” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M02.08-C055 · Valid-case test

**Original checklist item:** Run a known-valid control for panic record schema; verify that the harness reaches its intended target and compare observed measurements or verdicts with predeclared expectations.

- [ ] **UC-M02.08-C055-T01 · Valid fixture choice:** Choose a known-valid control for “Panic record schema”; document why it should pass and how it proves the harness reaches the intended target.
- [ ] **UC-M02.08-C055-T02 · Expected-result oracle:** Specify the “Panic record schema” expected result independently of the implementation output; include the property “Panic reporting does not require trusting unlimited guest data” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M02.08-C055-T03 · Fixture material:** Create the concrete “Panic record schema” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M02.08-C055-T04 · Target preparation:** Prepare the “Panic record schema” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M02.08-C055-T05 · Initial-state record:** Record the initial “Panic record schema” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M02.08-C055-T06 · Valid-path execution:** Run the “Panic record schema” known-valid control on the identified target; retain enough observations to prove the correct target was exercised.
- [ ] **UC-M02.08-C055-T07 · Outcome comparison:** Compare every declared “Panic record schema” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M02.08-C055-T08 · State and bounds check:** Inspect the “Panic record schema” ownership/state effects and actual use of “Panic bytes and nested diagnostic depth”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M02.08-C055-T09 · Repeatability check:** Repeat the same “Panic record schema” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M02.08-C055-T10 · Positive evidence:** Attach the “Panic record schema” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M02.08-C056 · Negative test

**Original checklist item:** Negative case: A panic contains an oversized or malformed message. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M02.08-C056-T01 · Adverse-case definition:** Create a test record for the exact “Panic record schema” source counterexample: “A panic contains an oversized or malformed message”; state which precondition or invariant it challenges.
- [ ] **UC-M02.08-C056-T02 · Safe fixture boundary:** Define the contained test boundary for “Panic record schema”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M02.08-C056-T03 · Valid control:** Construct a valid “Panic record schema” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M02.08-C056-T04 · Minimal adverse input:** Derive the “Panic record schema” adverse fixture from the control with the smallest documented change needed to reproduce “A panic contains an oversized or malformed message”; retain that change as reproducible data.
- [ ] **UC-M02.08-C056-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Panic record schema”; require “Panic reporting does not require trusting unlimited guest data” and forbid a false-success verdict.
- [ ] **UC-M02.08-C056-T06 · Adverse execution:** Exercise the “Panic record schema” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M02.08-C056-T07 · Effect inspection:** Inspect “Panic record schema” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M02.08-C056-T08 · Refusal versus failure:** Confirm the “Panic record schema” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M02.08-C056-T09 · Reset and retention:** Restore only the disposable “Panic record schema” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M02.08-C056-T10 · Negative regression:** Register the “Panic record schema” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M02.08-C057 · Change / failure test

**Original checklist item:** Exercise panic record schema when the image is rebuilt and previously collected ABI and panic evidence becomes stale; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M02.08-C057-T01 · Scenario record:** Write the “Panic record schema” change/failure scenario exactly as supplied: the image is rebuilt and previously collected ABI and panic evidence becomes stale; identify the property that must remain true: “Panic reporting does not require trusting unlimited guest data”.
- [ ] **UC-M02.08-C057-T02 · Baseline capture:** Create a known-valid “Panic record schema” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M02.08-C057-T03 · Injection map:** Locate the “Panic record schema” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M02.08-C057-T04 · Disposition oracle:** Define the legal intermediate and final “Panic record schema” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M02.08-C057-T05 · Controlled trigger:** Introduce the controlled “Panic record schema” scenario in the disposable fixture: the image is rebuilt and previously collected ABI and panic evidence becomes stale; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M02.08-C057-T06 · Intermediate inspection:** Inspect the “Panic record schema” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M02.08-C057-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Panic record schema”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M02.08-C057-T08 · Stale-evidence cleanup:** Invalidate superseded “Panic record schema” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M02.08-C057-T09 · Repeat and compare:** Repeat the selected “Panic record schema” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M02.08-C057-T10 · Failure evidence:** Publish the “Panic record schema” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M02.08-C058 · Bounds

**Original checklist item:** Set a documented campaign budget for panic bytes and nested diagnostic depth; record actual consumption, incomplete coverage and the disposition when the budget is exhausted.

- [ ] **UC-M02.08-C058-T01 · Quantity inventory:** Create a measurement inventory for “Panic record schema”: “Panic bytes and nested diagnostic depth”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M02.08-C058-T02 · Measurement method:** Choose how to observe each “Panic record schema” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M02.08-C058-T03 · Budget decision:** Select justified campaign and target-resource budgets for “Panic record schema”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M02.08-C058-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Panic record schema” cases for “Panic bytes and nested diagnostic depth”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M02.08-C058-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Panic record schema” limit; preserve “Panic reporting does not require trusting unlimited guest data”.
- [ ] **UC-M02.08-C058-T06 · Normal measurement:** Run or review the normal “Panic record schema” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M02.08-C058-T07 · At-limit measurement:** Exercise the “Panic record schema” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M02.08-C058-T08 · Over-limit measurement:** Exercise the “Panic record schema” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M02.08-C058-T09 · Uncovered-scope report:** List the “Panic record schema” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M02.08-C058-T10 · Limit evidence:** Publish the selected “Panic record schema” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M02.08-C059 · Diagnostics / review

**Original checklist item:** Report panic record schema results with executed, failed, skipped and unavailable cases separated; preserve the underlying observations and do not manufacture missing measurements.

- [ ] **UC-M02.08-C059-T01 · Result inventory:** Enumerate the required “Panic record schema” qualification cases and intended targets before aggregating results; keep the planned denominator visible.
- [ ] **UC-M02.08-C059-T02 · Verdict schema:** Define separate executed-pass, executed-fail, skipped, unavailable and untested outcomes for “Panic record schema”; document how incomplete cases block relevant claims.
- [ ] **UC-M02.08-C059-T03 · Identity fields:** Attach the actual target, fixture, configuration and revision identifiers to each “Panic record schema” result; do not attribute host-only evidence to a guest or another OS.
- [ ] **UC-M02.08-C059-T04 · Observation capture:** Capture bounded raw “Panic record schema” observations and harness errors; retain enough information to verify the reported oracle comparison.
- [ ] **UC-M02.08-C059-T05 · Aggregation rules:** Implement the “Panic record schema” count/reduction rule so failures and missing measurements cannot disappear; preserve “Panic reporting does not require trusting unlimited guest data”.
- [ ] **UC-M02.08-C059-T06 · Failure visibility:** Feed a failing “Panic record schema” control through the report path; assert the exact failed case and underlying observation remain visible.
- [ ] **UC-M02.08-C059-T07 · Missing-result visibility:** Withhold a required “Panic record schema” measurement or target; verify the report uses unavailable/untested rather than a fabricated zero or passing value.
- [ ] **UC-M02.08-C059-T08 · Bounds and redaction:** Check “Panic record schema” report size and retention against “Panic bytes and nested diagnostic depth”; remove secrets while retaining fixture and subject references.
- [ ] **UC-M02.08-C059-T09 · Report reconciliation:** Reconcile the “Panic record schema” summary with every underlying case record; account for the full planned denominator and all omitted scope.
- [ ] **UC-M02.08-C059-T10 · Qualification handoff:** Publish the “Panic record schema” report with measured observations, coverage limits and blockers; state which actual targets remain unqualified.

### UC-M02.08-C060 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for panic record schema; label unexecuted checks as untested.

- [ ] **UC-M02.08-C060-T01 · Evidence inventory:** List the “Panic record schema” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M02.08-C060-T02 · Artifact references:** Record the exact “Panic record schema” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M02.08-C060-T03 · Fixture references:** Attach the “Panic record schema” fixture IDs, input identities and oracle definition; preserve the source counterexample “A panic contains an oversized or malformed message” as a distinct evidence case.
- [ ] **UC-M02.08-C060-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Panic record schema”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M02.08-C060-T05 · Environment record:** Record the actual “Panic record schema” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M02.08-C060-T06 · Expected versus observed:** Pair every “Panic record schema” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M02.08-C060-T07 · Failure and limit records:** Attach “Panic record schema” change/failure and bounds evidence where required; include uncovered “Panic bytes and nested diagnostic depth” and unresolved violations of “Panic reporting does not require trusting unlimited guest data”.
- [ ] **UC-M02.08-C060-T08 · Evidence hygiene:** Check the “Panic record schema” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M02.08-C060-T09 · Reproduction review:** Have the “Panic record schema” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M02.08-C060-T10 · Acceptance linkage:** Link the “Panic record schema” evidence to its parent and UC-M02.08 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 07. Intentional panic trigger

**Source delivery:** Provide a controlled test that induces a guest panic in the selected image.

**Source invariant:** Panic qualification uses a real observed panic.

**Source negative case:** A test marks panic handling passed without triggering one.

**Source bounded quantities:** Trigger count and panic completion deadline.

### UC-M02.08-C061 · Contract

**Original checklist item:** Define the qualification objective for intentional panic trigger, including the actual target implementation, prerequisites, observable oracle and explicit exclusions.

- [ ] **UC-M02.08-C061-T01 · Scope statement:** Write the qualification question for “Intentional panic trigger”; identify the actual target, claimed capability and observations that can answer that question.
- [ ] **UC-M02.08-C061-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Intentional panic trigger”; record each producer, representation and missing-value meaning.
- [ ] **UC-M02.08-C061-T03 · Output inventory:** List the outputs of “Intentional panic trigger” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M02.08-C061-T04 · Field dictionary:** Create a field-and-term dictionary for “Intentional panic trigger”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M02.08-C061-T05 · Prerequisite contract:** Map “Intentional panic trigger” to the source component prerequisites (UC-M02.03, UC-M02.05, UC-M02.06, UC-M02.07); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M02.08-C061-T06 · Authority map:** Identify who may produce, change and consume “Intentional panic trigger”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M02.08-C061-T07 · Invariant clause:** Add a normative clause for “Intentional panic trigger” that preserves “Panic qualification uses a real observed panic”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M02.08-C061-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Intentional panic trigger”; include the source counterexample “A test marks panic handling passed without triggering one” and the intended safe disposition.
- [ ] **UC-M02.08-C061-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Trigger count and panic completion deadline” in the “Intentional panic trigger” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M02.08-C061-T10 · Contract review:** Review the “Intentional panic trigger” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M02.08-C062 · Delivery

**Original checklist item:** Provide a controlled test that induces a guest panic in the selected image.

- [ ] **UC-M02.08-C062-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Intentional panic trigger”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M02.08-C062-T02 · Change plan:** Break the source delivery for “Intentional panic trigger” into concrete edit targets and reviewable outputs; keep the UC-M02.08 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M02.08-C062-T03 · Core artifact:** Implement the smallest selected-profile change for “Intentional panic trigger” that realizes this source instruction: Provide a controlled test that induces a guest panic in the selected image.
- [ ] **UC-M02.08-C062-T04 · Concrete realization:** Trace “Intentional panic trigger” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M02.08-C062-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Intentional panic trigger” needed to preserve “Panic qualification uses a real observed panic”; record an enforcement gap where only a model exists.
- [ ] **UC-M02.08-C062-T06 · Dependency connection:** Connect the “Intentional panic trigger” qualification artifact to the built guest, ABI probe runner and source-mapped panic collector; record the target identity and what the harness actually exercises.
- [ ] **UC-M02.08-C062-T07 · Resource behavior:** Account for “Trigger count and panic completion deadline” in “Intentional panic trigger”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M02.08-C062-T08 · Delivery check:** Run a known-valid control and a deliberately failing control for “Intentional panic trigger”; confirm the harness distinguishes their observed outcomes.
- [ ] **UC-M02.08-C062-T09 · Patch review:** Review the “Intentional panic trigger” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M02.08-C062-T10 · Delivery handoff:** Publish the “Intentional panic trigger” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M02.08-C063 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Panic qualification uses a real observed panic. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M02.08-C063-T01 · Named property:** Create a stable property/check name under this parent for “Intentional panic trigger”; copy its required invariant exactly: “Panic qualification uses a real observed panic”.
- [ ] **UC-M02.08-C063-T02 · Observable terms:** Define each term in the “Intentional panic trigger” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M02.08-C063-T03 · Precondition set:** List the preconditions under which “Panic qualification uses a real observed panic” must hold for “Intentional panic trigger”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M02.08-C063-T04 · Transition coverage:** Map the “Intentional panic trigger” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M02.08-C063-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Intentional panic trigger”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M02.08-C063-T06 · Satisfying fixture:** Create a concrete “Intentional panic trigger” case that satisfies “Panic qualification uses a real observed panic”; record its expected observation before running the assertion or review.
- [ ] **UC-M02.08-C063-T07 · Violating fixture:** Create the source counterexample “A test marks panic handling passed without triggering one” for “Intentional panic trigger”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M02.08-C063-T08 · Enforcement evidence:** Exercise the “Intentional panic trigger” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M02.08-C063-T09 · Regression linkage:** Link the “Intentional panic trigger” property to changes in the built guest, ABI probe runner and source-mapped panic collector; record which dependency or contract changes require rerunning it.
- [ ] **UC-M02.08-C063-T10 · Property disposition:** Compare the satisfying and violating “Intentional panic trigger” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M02.08-C064 · Integration

**Original checklist item:** Integrate intentional panic trigger with the built guest, ABI probe runner and source-mapped panic collector; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M02.08-C064-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Intentional panic trigger” across the built guest, ABI probe runner and source-mapped panic collector; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M02.08-C064-T02 · Field mapping:** Map every “Intentional panic trigger” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M02.08-C064-T03 · Prerequisite identities:** Record the actual prerequisites for “Intentional panic trigger” (source dependency list: UC-M02.03, UC-M02.05, UC-M02.06, UC-M02.07); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M02.08-C064-T04 · Ownership agreement:** Specify who owns “Intentional panic trigger” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M02.08-C064-T05 · Handoff implementation:** Connect “Intentional panic trigger” through the mapped seam using the real adapter or explicit specification reference; preserve “Panic qualification uses a real observed panic” across the handoff.
- [ ] **UC-M02.08-C064-T06 · Absent-input case:** Omit one required “Intentional panic trigger” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M02.08-C064-T07 · Stale-input case:** Supply an outdated “Intentional panic trigger” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M02.08-C064-T08 · Incompatible-input case:** Supply an incompatible “Intentional panic trigger” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M02.08-C064-T09 · Valid integration trace:** Run a valid “Intentional panic trigger” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M02.08-C064-T10 · Seam review:** Reconcile the “Intentional panic trigger” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M02.08-C065 · Valid-case test

**Original checklist item:** Run a known-valid control for intentional panic trigger; verify that the harness reaches its intended target and compare observed measurements or verdicts with predeclared expectations.

- [ ] **UC-M02.08-C065-T01 · Valid fixture choice:** Choose a known-valid control for “Intentional panic trigger”; document why it should pass and how it proves the harness reaches the intended target.
- [ ] **UC-M02.08-C065-T02 · Expected-result oracle:** Specify the “Intentional panic trigger” expected result independently of the implementation output; include the property “Panic qualification uses a real observed panic” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M02.08-C065-T03 · Fixture material:** Create the concrete “Intentional panic trigger” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M02.08-C065-T04 · Target preparation:** Prepare the “Intentional panic trigger” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M02.08-C065-T05 · Initial-state record:** Record the initial “Intentional panic trigger” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M02.08-C065-T06 · Valid-path execution:** Run the “Intentional panic trigger” known-valid control on the identified target; retain enough observations to prove the correct target was exercised.
- [ ] **UC-M02.08-C065-T07 · Outcome comparison:** Compare every declared “Intentional panic trigger” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M02.08-C065-T08 · State and bounds check:** Inspect the “Intentional panic trigger” ownership/state effects and actual use of “Trigger count and panic completion deadline”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M02.08-C065-T09 · Repeatability check:** Repeat the same “Intentional panic trigger” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M02.08-C065-T10 · Positive evidence:** Attach the “Intentional panic trigger” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M02.08-C066 · Negative test

**Original checklist item:** Negative case: A test marks panic handling passed without triggering one. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M02.08-C066-T01 · Adverse-case definition:** Create a test record for the exact “Intentional panic trigger” source counterexample: “A test marks panic handling passed without triggering one”; state which precondition or invariant it challenges.
- [ ] **UC-M02.08-C066-T02 · Safe fixture boundary:** Define the contained test boundary for “Intentional panic trigger”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M02.08-C066-T03 · Valid control:** Construct a valid “Intentional panic trigger” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M02.08-C066-T04 · Minimal adverse input:** Derive the “Intentional panic trigger” adverse fixture from the control with the smallest documented change needed to reproduce “A test marks panic handling passed without triggering one”; retain that change as reproducible data.
- [ ] **UC-M02.08-C066-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Intentional panic trigger”; require “Panic qualification uses a real observed panic” and forbid a false-success verdict.
- [ ] **UC-M02.08-C066-T06 · Adverse execution:** Exercise the “Intentional panic trigger” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M02.08-C066-T07 · Effect inspection:** Inspect “Intentional panic trigger” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M02.08-C066-T08 · Refusal versus failure:** Confirm the “Intentional panic trigger” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M02.08-C066-T09 · Reset and retention:** Restore only the disposable “Intentional panic trigger” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M02.08-C066-T10 · Negative regression:** Register the “Intentional panic trigger” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M02.08-C067 · Change / failure test

**Original checklist item:** Exercise intentional panic trigger when the image is rebuilt and previously collected ABI and panic evidence becomes stale; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M02.08-C067-T01 · Scenario record:** Write the “Intentional panic trigger” change/failure scenario exactly as supplied: the image is rebuilt and previously collected ABI and panic evidence becomes stale; identify the property that must remain true: “Panic qualification uses a real observed panic”.
- [ ] **UC-M02.08-C067-T02 · Baseline capture:** Create a known-valid “Intentional panic trigger” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M02.08-C067-T03 · Injection map:** Locate the “Intentional panic trigger” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M02.08-C067-T04 · Disposition oracle:** Define the legal intermediate and final “Intentional panic trigger” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M02.08-C067-T05 · Controlled trigger:** Introduce the controlled “Intentional panic trigger” scenario in the disposable fixture: the image is rebuilt and previously collected ABI and panic evidence becomes stale; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M02.08-C067-T06 · Intermediate inspection:** Inspect the “Intentional panic trigger” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M02.08-C067-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Intentional panic trigger”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M02.08-C067-T08 · Stale-evidence cleanup:** Invalidate superseded “Intentional panic trigger” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M02.08-C067-T09 · Repeat and compare:** Repeat the selected “Intentional panic trigger” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M02.08-C067-T10 · Failure evidence:** Publish the “Intentional panic trigger” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M02.08-C068 · Bounds

**Original checklist item:** Set a documented campaign budget for trigger count and panic completion deadline; record actual consumption, incomplete coverage and the disposition when the budget is exhausted.

- [ ] **UC-M02.08-C068-T01 · Quantity inventory:** Create a measurement inventory for “Intentional panic trigger”: “Trigger count and panic completion deadline”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M02.08-C068-T02 · Measurement method:** Choose how to observe each “Intentional panic trigger” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M02.08-C068-T03 · Budget decision:** Select justified campaign and target-resource budgets for “Intentional panic trigger”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M02.08-C068-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Intentional panic trigger” cases for “Trigger count and panic completion deadline”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M02.08-C068-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Intentional panic trigger” limit; preserve “Panic qualification uses a real observed panic”.
- [ ] **UC-M02.08-C068-T06 · Normal measurement:** Run or review the normal “Intentional panic trigger” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M02.08-C068-T07 · At-limit measurement:** Exercise the “Intentional panic trigger” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M02.08-C068-T08 · Over-limit measurement:** Exercise the “Intentional panic trigger” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M02.08-C068-T09 · Uncovered-scope report:** List the “Intentional panic trigger” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M02.08-C068-T10 · Limit evidence:** Publish the selected “Intentional panic trigger” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M02.08-C069 · Diagnostics / review

**Original checklist item:** Report intentional panic trigger results with executed, failed, skipped and unavailable cases separated; preserve the underlying observations and do not manufacture missing measurements.

- [ ] **UC-M02.08-C069-T01 · Result inventory:** Enumerate the required “Intentional panic trigger” qualification cases and intended targets before aggregating results; keep the planned denominator visible.
- [ ] **UC-M02.08-C069-T02 · Verdict schema:** Define separate executed-pass, executed-fail, skipped, unavailable and untested outcomes for “Intentional panic trigger”; document how incomplete cases block relevant claims.
- [ ] **UC-M02.08-C069-T03 · Identity fields:** Attach the actual target, fixture, configuration and revision identifiers to each “Intentional panic trigger” result; do not attribute host-only evidence to a guest or another OS.
- [ ] **UC-M02.08-C069-T04 · Observation capture:** Capture bounded raw “Intentional panic trigger” observations and harness errors; retain enough information to verify the reported oracle comparison.
- [ ] **UC-M02.08-C069-T05 · Aggregation rules:** Implement the “Intentional panic trigger” count/reduction rule so failures and missing measurements cannot disappear; preserve “Panic qualification uses a real observed panic”.
- [ ] **UC-M02.08-C069-T06 · Failure visibility:** Feed a failing “Intentional panic trigger” control through the report path; assert the exact failed case and underlying observation remain visible.
- [ ] **UC-M02.08-C069-T07 · Missing-result visibility:** Withhold a required “Intentional panic trigger” measurement or target; verify the report uses unavailable/untested rather than a fabricated zero or passing value.
- [ ] **UC-M02.08-C069-T08 · Bounds and redaction:** Check “Intentional panic trigger” report size and retention against “Trigger count and panic completion deadline”; remove secrets while retaining fixture and subject references.
- [ ] **UC-M02.08-C069-T09 · Report reconciliation:** Reconcile the “Intentional panic trigger” summary with every underlying case record; account for the full planned denominator and all omitted scope.
- [ ] **UC-M02.08-C069-T10 · Qualification handoff:** Publish the “Intentional panic trigger” report with measured observations, coverage limits and blockers; state which actual targets remain unqualified.

### UC-M02.08-C070 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for intentional panic trigger; label unexecuted checks as untested.

- [ ] **UC-M02.08-C070-T01 · Evidence inventory:** List the “Intentional panic trigger” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M02.08-C070-T02 · Artifact references:** Record the exact “Intentional panic trigger” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M02.08-C070-T03 · Fixture references:** Attach the “Intentional panic trigger” fixture IDs, input identities and oracle definition; preserve the source counterexample “A test marks panic handling passed without triggering one” as a distinct evidence case.
- [ ] **UC-M02.08-C070-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Intentional panic trigger”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M02.08-C070-T05 · Environment record:** Record the actual “Intentional panic trigger” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M02.08-C070-T06 · Expected versus observed:** Pair every “Intentional panic trigger” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M02.08-C070-T07 · Failure and limit records:** Attach “Intentional panic trigger” change/failure and bounds evidence where required; include uncovered “Trigger count and panic completion deadline” and unresolved violations of “Panic qualification uses a real observed panic”.
- [ ] **UC-M02.08-C070-T08 · Evidence hygiene:** Check the “Intentional panic trigger” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M02.08-C070-T09 · Reproduction review:** Have the “Intentional panic trigger” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M02.08-C070-T10 · Acceptance linkage:** Link the “Intentional panic trigger” evidence to its parent and UC-M02.08 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 08. Source mapping

**Source delivery:** Bind guest trace locations to exact source and build identities.

**Source invariant:** A trace is not decoded against unrelated source maps.

**Source negative case:** A symbol map from another build produces a misleading trace.

**Source bounded quantities:** Symbol map bytes and lookup time.

### UC-M02.08-C071 · Contract

**Original checklist item:** Define the qualification objective for source mapping, including the actual target implementation, prerequisites, observable oracle and explicit exclusions.

- [ ] **UC-M02.08-C071-T01 · Scope statement:** Write the qualification question for “Source mapping”; identify the actual target, claimed capability and observations that can answer that question.
- [ ] **UC-M02.08-C071-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Source mapping”; record each producer, representation and missing-value meaning.
- [ ] **UC-M02.08-C071-T03 · Output inventory:** List the outputs of “Source mapping” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M02.08-C071-T04 · Field dictionary:** Create a field-and-term dictionary for “Source mapping”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M02.08-C071-T05 · Prerequisite contract:** Map “Source mapping” to the source component prerequisites (UC-M02.03, UC-M02.05, UC-M02.06, UC-M02.07); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M02.08-C071-T06 · Authority map:** Identify who may produce, change and consume “Source mapping”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M02.08-C071-T07 · Invariant clause:** Add a normative clause for “Source mapping” that preserves “A trace is not decoded against unrelated source maps”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M02.08-C071-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Source mapping”; include the source counterexample “A symbol map from another build produces a misleading trace” and the intended safe disposition.
- [ ] **UC-M02.08-C071-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Symbol map bytes and lookup time” in the “Source mapping” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M02.08-C071-T10 · Contract review:** Review the “Source mapping” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M02.08-C072 · Delivery

**Original checklist item:** Bind guest trace locations to exact source and build identities.

- [ ] **UC-M02.08-C072-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Source mapping”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M02.08-C072-T02 · Change plan:** Break the source delivery for “Source mapping” into concrete edit targets and reviewable outputs; keep the UC-M02.08 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M02.08-C072-T03 · Core artifact:** Implement the smallest selected-profile change for “Source mapping” that realizes this source instruction: Bind guest trace locations to exact source and build identities.
- [ ] **UC-M02.08-C072-T04 · Concrete realization:** Trace “Source mapping” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M02.08-C072-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Source mapping” needed to preserve “A trace is not decoded against unrelated source maps”; record an enforcement gap where only a model exists.
- [ ] **UC-M02.08-C072-T06 · Dependency connection:** Connect the “Source mapping” qualification artifact to the built guest, ABI probe runner and source-mapped panic collector; record the target identity and what the harness actually exercises.
- [ ] **UC-M02.08-C072-T07 · Resource behavior:** Account for “Symbol map bytes and lookup time” in “Source mapping”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M02.08-C072-T08 · Delivery check:** Run a known-valid control and a deliberately failing control for “Source mapping”; confirm the harness distinguishes their observed outcomes.
- [ ] **UC-M02.08-C072-T09 · Patch review:** Review the “Source mapping” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M02.08-C072-T10 · Delivery handoff:** Publish the “Source mapping” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M02.08-C073 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: A trace is not decoded against unrelated source maps. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M02.08-C073-T01 · Named property:** Create a stable property/check name under this parent for “Source mapping”; copy its required invariant exactly: “A trace is not decoded against unrelated source maps”.
- [ ] **UC-M02.08-C073-T02 · Observable terms:** Define each term in the “Source mapping” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M02.08-C073-T03 · Precondition set:** List the preconditions under which “A trace is not decoded against unrelated source maps” must hold for “Source mapping”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M02.08-C073-T04 · Transition coverage:** Map the “Source mapping” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M02.08-C073-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Source mapping”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M02.08-C073-T06 · Satisfying fixture:** Create a concrete “Source mapping” case that satisfies “A trace is not decoded against unrelated source maps”; record its expected observation before running the assertion or review.
- [ ] **UC-M02.08-C073-T07 · Violating fixture:** Create the source counterexample “A symbol map from another build produces a misleading trace” for “Source mapping”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M02.08-C073-T08 · Enforcement evidence:** Exercise the “Source mapping” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M02.08-C073-T09 · Regression linkage:** Link the “Source mapping” property to changes in the built guest, ABI probe runner and source-mapped panic collector; record which dependency or contract changes require rerunning it.
- [ ] **UC-M02.08-C073-T10 · Property disposition:** Compare the satisfying and violating “Source mapping” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M02.08-C074 · Integration

**Original checklist item:** Integrate source mapping with the built guest, ABI probe runner and source-mapped panic collector; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M02.08-C074-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Source mapping” across the built guest, ABI probe runner and source-mapped panic collector; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M02.08-C074-T02 · Field mapping:** Map every “Source mapping” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M02.08-C074-T03 · Prerequisite identities:** Record the actual prerequisites for “Source mapping” (source dependency list: UC-M02.03, UC-M02.05, UC-M02.06, UC-M02.07); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M02.08-C074-T04 · Ownership agreement:** Specify who owns “Source mapping” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M02.08-C074-T05 · Handoff implementation:** Connect “Source mapping” through the mapped seam using the real adapter or explicit specification reference; preserve “A trace is not decoded against unrelated source maps” across the handoff.
- [ ] **UC-M02.08-C074-T06 · Absent-input case:** Omit one required “Source mapping” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M02.08-C074-T07 · Stale-input case:** Supply an outdated “Source mapping” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M02.08-C074-T08 · Incompatible-input case:** Supply an incompatible “Source mapping” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M02.08-C074-T09 · Valid integration trace:** Run a valid “Source mapping” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M02.08-C074-T10 · Seam review:** Reconcile the “Source mapping” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M02.08-C075 · Valid-case test

**Original checklist item:** Run a known-valid control for source mapping; verify that the harness reaches its intended target and compare observed measurements or verdicts with predeclared expectations.

- [ ] **UC-M02.08-C075-T01 · Valid fixture choice:** Choose a known-valid control for “Source mapping”; document why it should pass and how it proves the harness reaches the intended target.
- [ ] **UC-M02.08-C075-T02 · Expected-result oracle:** Specify the “Source mapping” expected result independently of the implementation output; include the property “A trace is not decoded against unrelated source maps” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M02.08-C075-T03 · Fixture material:** Create the concrete “Source mapping” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M02.08-C075-T04 · Target preparation:** Prepare the “Source mapping” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M02.08-C075-T05 · Initial-state record:** Record the initial “Source mapping” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M02.08-C075-T06 · Valid-path execution:** Run the “Source mapping” known-valid control on the identified target; retain enough observations to prove the correct target was exercised.
- [ ] **UC-M02.08-C075-T07 · Outcome comparison:** Compare every declared “Source mapping” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M02.08-C075-T08 · State and bounds check:** Inspect the “Source mapping” ownership/state effects and actual use of “Symbol map bytes and lookup time”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M02.08-C075-T09 · Repeatability check:** Repeat the same “Source mapping” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M02.08-C075-T10 · Positive evidence:** Attach the “Source mapping” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M02.08-C076 · Negative test

**Original checklist item:** Negative case: A symbol map from another build produces a misleading trace. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M02.08-C076-T01 · Adverse-case definition:** Create a test record for the exact “Source mapping” source counterexample: “A symbol map from another build produces a misleading trace”; state which precondition or invariant it challenges.
- [ ] **UC-M02.08-C076-T02 · Safe fixture boundary:** Define the contained test boundary for “Source mapping”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M02.08-C076-T03 · Valid control:** Construct a valid “Source mapping” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M02.08-C076-T04 · Minimal adverse input:** Derive the “Source mapping” adverse fixture from the control with the smallest documented change needed to reproduce “A symbol map from another build produces a misleading trace”; retain that change as reproducible data.
- [ ] **UC-M02.08-C076-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Source mapping”; require “A trace is not decoded against unrelated source maps” and forbid a false-success verdict.
- [ ] **UC-M02.08-C076-T06 · Adverse execution:** Exercise the “Source mapping” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M02.08-C076-T07 · Effect inspection:** Inspect “Source mapping” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M02.08-C076-T08 · Refusal versus failure:** Confirm the “Source mapping” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M02.08-C076-T09 · Reset and retention:** Restore only the disposable “Source mapping” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M02.08-C076-T10 · Negative regression:** Register the “Source mapping” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M02.08-C077 · Change / failure test

**Original checklist item:** Exercise source mapping when the image is rebuilt and previously collected ABI and panic evidence becomes stale; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M02.08-C077-T01 · Scenario record:** Write the “Source mapping” change/failure scenario exactly as supplied: the image is rebuilt and previously collected ABI and panic evidence becomes stale; identify the property that must remain true: “A trace is not decoded against unrelated source maps”.
- [ ] **UC-M02.08-C077-T02 · Baseline capture:** Create a known-valid “Source mapping” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M02.08-C077-T03 · Injection map:** Locate the “Source mapping” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M02.08-C077-T04 · Disposition oracle:** Define the legal intermediate and final “Source mapping” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M02.08-C077-T05 · Controlled trigger:** Introduce the controlled “Source mapping” scenario in the disposable fixture: the image is rebuilt and previously collected ABI and panic evidence becomes stale; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M02.08-C077-T06 · Intermediate inspection:** Inspect the “Source mapping” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M02.08-C077-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Source mapping”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M02.08-C077-T08 · Stale-evidence cleanup:** Invalidate superseded “Source mapping” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M02.08-C077-T09 · Repeat and compare:** Repeat the selected “Source mapping” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M02.08-C077-T10 · Failure evidence:** Publish the “Source mapping” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M02.08-C078 · Bounds

**Original checklist item:** Set a documented campaign budget for symbol map bytes and lookup time; record actual consumption, incomplete coverage and the disposition when the budget is exhausted.

- [ ] **UC-M02.08-C078-T01 · Quantity inventory:** Create a measurement inventory for “Source mapping”: “Symbol map bytes and lookup time”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M02.08-C078-T02 · Measurement method:** Choose how to observe each “Source mapping” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M02.08-C078-T03 · Budget decision:** Select justified campaign and target-resource budgets for “Source mapping”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M02.08-C078-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Source mapping” cases for “Symbol map bytes and lookup time”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M02.08-C078-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Source mapping” limit; preserve “A trace is not decoded against unrelated source maps”.
- [ ] **UC-M02.08-C078-T06 · Normal measurement:** Run or review the normal “Source mapping” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M02.08-C078-T07 · At-limit measurement:** Exercise the “Source mapping” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M02.08-C078-T08 · Over-limit measurement:** Exercise the “Source mapping” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M02.08-C078-T09 · Uncovered-scope report:** List the “Source mapping” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M02.08-C078-T10 · Limit evidence:** Publish the selected “Source mapping” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M02.08-C079 · Diagnostics / review

**Original checklist item:** Report source mapping results with executed, failed, skipped and unavailable cases separated; preserve the underlying observations and do not manufacture missing measurements.

- [ ] **UC-M02.08-C079-T01 · Result inventory:** Enumerate the required “Source mapping” qualification cases and intended targets before aggregating results; keep the planned denominator visible.
- [ ] **UC-M02.08-C079-T02 · Verdict schema:** Define separate executed-pass, executed-fail, skipped, unavailable and untested outcomes for “Source mapping”; document how incomplete cases block relevant claims.
- [ ] **UC-M02.08-C079-T03 · Identity fields:** Attach the actual target, fixture, configuration and revision identifiers to each “Source mapping” result; do not attribute host-only evidence to a guest or another OS.
- [ ] **UC-M02.08-C079-T04 · Observation capture:** Capture bounded raw “Source mapping” observations and harness errors; retain enough information to verify the reported oracle comparison.
- [ ] **UC-M02.08-C079-T05 · Aggregation rules:** Implement the “Source mapping” count/reduction rule so failures and missing measurements cannot disappear; preserve “A trace is not decoded against unrelated source maps”.
- [ ] **UC-M02.08-C079-T06 · Failure visibility:** Feed a failing “Source mapping” control through the report path; assert the exact failed case and underlying observation remain visible.
- [ ] **UC-M02.08-C079-T07 · Missing-result visibility:** Withhold a required “Source mapping” measurement or target; verify the report uses unavailable/untested rather than a fabricated zero or passing value.
- [ ] **UC-M02.08-C079-T08 · Bounds and redaction:** Check “Source mapping” report size and retention against “Symbol map bytes and lookup time”; remove secrets while retaining fixture and subject references.
- [ ] **UC-M02.08-C079-T09 · Report reconciliation:** Reconcile the “Source mapping” summary with every underlying case record; account for the full planned denominator and all omitted scope.
- [ ] **UC-M02.08-C079-T10 · Qualification handoff:** Publish the “Source mapping” report with measured observations, coverage limits and blockers; state which actual targets remain unqualified.

### UC-M02.08-C080 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for source mapping; label unexecuted checks as untested.

- [ ] **UC-M02.08-C080-T01 · Evidence inventory:** List the “Source mapping” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M02.08-C080-T02 · Artifact references:** Record the exact “Source mapping” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M02.08-C080-T03 · Fixture references:** Attach the “Source mapping” fixture IDs, input identities and oracle definition; preserve the source counterexample “A symbol map from another build produces a misleading trace” as a distinct evidence case.
- [ ] **UC-M02.08-C080-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Source mapping”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M02.08-C080-T05 · Environment record:** Record the actual “Source mapping” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M02.08-C080-T06 · Expected versus observed:** Pair every “Source mapping” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M02.08-C080-T07 · Failure and limit records:** Attach “Source mapping” change/failure and bounds evidence where required; include uncovered “Symbol map bytes and lookup time” and unresolved violations of “A trace is not decoded against unrelated source maps”.
- [ ] **UC-M02.08-C080-T08 · Evidence hygiene:** Check the “Source mapping” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M02.08-C080-T09 · Reproduction review:** Have the “Source mapping” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M02.08-C080-T10 · Acceptance linkage:** Link the “Source mapping” evidence to its parent and UC-M02.08 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 09. Trace redaction and bounds

**Source delivery:** Limit panic traces and remove sensitive input material from exported records.

**Source invariant:** A diagnostic failure cannot leak secrets or exhaust the host.

**Source negative case:** A panic dumps a buffer containing injected secret material.

**Source bounded quantities:** Trace bytes and retained panic count.

### UC-M02.08-C081 · Contract

**Original checklist item:** Define the qualification objective for trace redaction and bounds, including the actual target implementation, prerequisites, observable oracle and explicit exclusions.

- [ ] **UC-M02.08-C081-T01 · Scope statement:** Write the qualification question for “Trace redaction and bounds”; identify the actual target, claimed capability and observations that can answer that question.
- [ ] **UC-M02.08-C081-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Trace redaction and bounds”; record each producer, representation and missing-value meaning.
- [ ] **UC-M02.08-C081-T03 · Output inventory:** List the outputs of “Trace redaction and bounds” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M02.08-C081-T04 · Field dictionary:** Create a field-and-term dictionary for “Trace redaction and bounds”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M02.08-C081-T05 · Prerequisite contract:** Map “Trace redaction and bounds” to the source component prerequisites (UC-M02.03, UC-M02.05, UC-M02.06, UC-M02.07); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M02.08-C081-T06 · Authority map:** Identify who may produce, change and consume “Trace redaction and bounds”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M02.08-C081-T07 · Invariant clause:** Add a normative clause for “Trace redaction and bounds” that preserves “A diagnostic failure cannot leak secrets or exhaust the host”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M02.08-C081-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Trace redaction and bounds”; include the source counterexample “A panic dumps a buffer containing injected secret material” and the intended safe disposition.
- [ ] **UC-M02.08-C081-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Trace bytes and retained panic count” in the “Trace redaction and bounds” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M02.08-C081-T10 · Contract review:** Review the “Trace redaction and bounds” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M02.08-C082 · Delivery

**Original checklist item:** Limit panic traces and remove sensitive input material from exported records.

- [ ] **UC-M02.08-C082-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Trace redaction and bounds”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M02.08-C082-T02 · Change plan:** Break the source delivery for “Trace redaction and bounds” into concrete edit targets and reviewable outputs; keep the UC-M02.08 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M02.08-C082-T03 · Core artifact:** Implement the smallest selected-profile change for “Trace redaction and bounds” that realizes this source instruction: Limit panic traces and remove sensitive input material from exported records.
- [ ] **UC-M02.08-C082-T04 · Concrete realization:** Trace “Trace redaction and bounds” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M02.08-C082-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Trace redaction and bounds” needed to preserve “A diagnostic failure cannot leak secrets or exhaust the host”; record an enforcement gap where only a model exists.
- [ ] **UC-M02.08-C082-T06 · Dependency connection:** Connect the “Trace redaction and bounds” qualification artifact to the built guest, ABI probe runner and source-mapped panic collector; record the target identity and what the harness actually exercises.
- [ ] **UC-M02.08-C082-T07 · Resource behavior:** Account for “Trace bytes and retained panic count” in “Trace redaction and bounds”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M02.08-C082-T08 · Delivery check:** Run a known-valid control and a deliberately failing control for “Trace redaction and bounds”; confirm the harness distinguishes their observed outcomes.
- [ ] **UC-M02.08-C082-T09 · Patch review:** Review the “Trace redaction and bounds” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M02.08-C082-T10 · Delivery handoff:** Publish the “Trace redaction and bounds” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M02.08-C083 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: A diagnostic failure cannot leak secrets or exhaust the host. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M02.08-C083-T01 · Named property:** Create a stable property/check name under this parent for “Trace redaction and bounds”; copy its required invariant exactly: “A diagnostic failure cannot leak secrets or exhaust the host”.
- [ ] **UC-M02.08-C083-T02 · Observable terms:** Define each term in the “Trace redaction and bounds” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M02.08-C083-T03 · Precondition set:** List the preconditions under which “A diagnostic failure cannot leak secrets or exhaust the host” must hold for “Trace redaction and bounds”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M02.08-C083-T04 · Transition coverage:** Map the “Trace redaction and bounds” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M02.08-C083-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Trace redaction and bounds”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M02.08-C083-T06 · Satisfying fixture:** Create a concrete “Trace redaction and bounds” case that satisfies “A diagnostic failure cannot leak secrets or exhaust the host”; record its expected observation before running the assertion or review.
- [ ] **UC-M02.08-C083-T07 · Violating fixture:** Create the source counterexample “A panic dumps a buffer containing injected secret material” for “Trace redaction and bounds”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M02.08-C083-T08 · Enforcement evidence:** Exercise the “Trace redaction and bounds” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M02.08-C083-T09 · Regression linkage:** Link the “Trace redaction and bounds” property to changes in the built guest, ABI probe runner and source-mapped panic collector; record which dependency or contract changes require rerunning it.
- [ ] **UC-M02.08-C083-T10 · Property disposition:** Compare the satisfying and violating “Trace redaction and bounds” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M02.08-C084 · Integration

**Original checklist item:** Integrate trace redaction and bounds with the built guest, ABI probe runner and source-mapped panic collector; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M02.08-C084-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Trace redaction and bounds” across the built guest, ABI probe runner and source-mapped panic collector; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M02.08-C084-T02 · Field mapping:** Map every “Trace redaction and bounds” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M02.08-C084-T03 · Prerequisite identities:** Record the actual prerequisites for “Trace redaction and bounds” (source dependency list: UC-M02.03, UC-M02.05, UC-M02.06, UC-M02.07); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M02.08-C084-T04 · Ownership agreement:** Specify who owns “Trace redaction and bounds” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M02.08-C084-T05 · Handoff implementation:** Connect “Trace redaction and bounds” through the mapped seam using the real adapter or explicit specification reference; preserve “A diagnostic failure cannot leak secrets or exhaust the host” across the handoff.
- [ ] **UC-M02.08-C084-T06 · Absent-input case:** Omit one required “Trace redaction and bounds” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M02.08-C084-T07 · Stale-input case:** Supply an outdated “Trace redaction and bounds” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M02.08-C084-T08 · Incompatible-input case:** Supply an incompatible “Trace redaction and bounds” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M02.08-C084-T09 · Valid integration trace:** Run a valid “Trace redaction and bounds” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M02.08-C084-T10 · Seam review:** Reconcile the “Trace redaction and bounds” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M02.08-C085 · Valid-case test

**Original checklist item:** Run a known-valid control for trace redaction and bounds; verify that the harness reaches its intended target and compare observed measurements or verdicts with predeclared expectations.

- [ ] **UC-M02.08-C085-T01 · Valid fixture choice:** Choose a known-valid control for “Trace redaction and bounds”; document why it should pass and how it proves the harness reaches the intended target.
- [ ] **UC-M02.08-C085-T02 · Expected-result oracle:** Specify the “Trace redaction and bounds” expected result independently of the implementation output; include the property “A diagnostic failure cannot leak secrets or exhaust the host” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M02.08-C085-T03 · Fixture material:** Create the concrete “Trace redaction and bounds” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M02.08-C085-T04 · Target preparation:** Prepare the “Trace redaction and bounds” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M02.08-C085-T05 · Initial-state record:** Record the initial “Trace redaction and bounds” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M02.08-C085-T06 · Valid-path execution:** Run the “Trace redaction and bounds” known-valid control on the identified target; retain enough observations to prove the correct target was exercised.
- [ ] **UC-M02.08-C085-T07 · Outcome comparison:** Compare every declared “Trace redaction and bounds” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M02.08-C085-T08 · State and bounds check:** Inspect the “Trace redaction and bounds” ownership/state effects and actual use of “Trace bytes and retained panic count”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M02.08-C085-T09 · Repeatability check:** Repeat the same “Trace redaction and bounds” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M02.08-C085-T10 · Positive evidence:** Attach the “Trace redaction and bounds” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M02.08-C086 · Negative test

**Original checklist item:** Negative case: A panic dumps a buffer containing injected secret material. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M02.08-C086-T01 · Adverse-case definition:** Create a test record for the exact “Trace redaction and bounds” source counterexample: “A panic dumps a buffer containing injected secret material”; state which precondition or invariant it challenges.
- [ ] **UC-M02.08-C086-T02 · Safe fixture boundary:** Define the contained test boundary for “Trace redaction and bounds”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M02.08-C086-T03 · Valid control:** Construct a valid “Trace redaction and bounds” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M02.08-C086-T04 · Minimal adverse input:** Derive the “Trace redaction and bounds” adverse fixture from the control with the smallest documented change needed to reproduce “A panic dumps a buffer containing injected secret material”; retain that change as reproducible data.
- [ ] **UC-M02.08-C086-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Trace redaction and bounds”; require “A diagnostic failure cannot leak secrets or exhaust the host” and forbid a false-success verdict.
- [ ] **UC-M02.08-C086-T06 · Adverse execution:** Exercise the “Trace redaction and bounds” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M02.08-C086-T07 · Effect inspection:** Inspect “Trace redaction and bounds” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M02.08-C086-T08 · Refusal versus failure:** Confirm the “Trace redaction and bounds” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M02.08-C086-T09 · Reset and retention:** Restore only the disposable “Trace redaction and bounds” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M02.08-C086-T10 · Negative regression:** Register the “Trace redaction and bounds” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M02.08-C087 · Change / failure test

**Original checklist item:** Exercise trace redaction and bounds when the image is rebuilt and previously collected ABI and panic evidence becomes stale; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M02.08-C087-T01 · Scenario record:** Write the “Trace redaction and bounds” change/failure scenario exactly as supplied: the image is rebuilt and previously collected ABI and panic evidence becomes stale; identify the property that must remain true: “A diagnostic failure cannot leak secrets or exhaust the host”.
- [ ] **UC-M02.08-C087-T02 · Baseline capture:** Create a known-valid “Trace redaction and bounds” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M02.08-C087-T03 · Injection map:** Locate the “Trace redaction and bounds” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M02.08-C087-T04 · Disposition oracle:** Define the legal intermediate and final “Trace redaction and bounds” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M02.08-C087-T05 · Controlled trigger:** Introduce the controlled “Trace redaction and bounds” scenario in the disposable fixture: the image is rebuilt and previously collected ABI and panic evidence becomes stale; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M02.08-C087-T06 · Intermediate inspection:** Inspect the “Trace redaction and bounds” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M02.08-C087-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Trace redaction and bounds”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M02.08-C087-T08 · Stale-evidence cleanup:** Invalidate superseded “Trace redaction and bounds” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M02.08-C087-T09 · Repeat and compare:** Repeat the selected “Trace redaction and bounds” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M02.08-C087-T10 · Failure evidence:** Publish the “Trace redaction and bounds” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M02.08-C088 · Bounds

**Original checklist item:** Set a documented campaign budget for trace bytes and retained panic count; record actual consumption, incomplete coverage and the disposition when the budget is exhausted.

- [ ] **UC-M02.08-C088-T01 · Quantity inventory:** Create a measurement inventory for “Trace redaction and bounds”: “Trace bytes and retained panic count”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M02.08-C088-T02 · Measurement method:** Choose how to observe each “Trace redaction and bounds” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M02.08-C088-T03 · Budget decision:** Select justified campaign and target-resource budgets for “Trace redaction and bounds”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M02.08-C088-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Trace redaction and bounds” cases for “Trace bytes and retained panic count”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M02.08-C088-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Trace redaction and bounds” limit; preserve “A diagnostic failure cannot leak secrets or exhaust the host”.
- [ ] **UC-M02.08-C088-T06 · Normal measurement:** Run or review the normal “Trace redaction and bounds” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M02.08-C088-T07 · At-limit measurement:** Exercise the “Trace redaction and bounds” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M02.08-C088-T08 · Over-limit measurement:** Exercise the “Trace redaction and bounds” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M02.08-C088-T09 · Uncovered-scope report:** List the “Trace redaction and bounds” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M02.08-C088-T10 · Limit evidence:** Publish the selected “Trace redaction and bounds” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M02.08-C089 · Diagnostics / review

**Original checklist item:** Report trace redaction and bounds results with executed, failed, skipped and unavailable cases separated; preserve the underlying observations and do not manufacture missing measurements.

- [ ] **UC-M02.08-C089-T01 · Result inventory:** Enumerate the required “Trace redaction and bounds” qualification cases and intended targets before aggregating results; keep the planned denominator visible.
- [ ] **UC-M02.08-C089-T02 · Verdict schema:** Define separate executed-pass, executed-fail, skipped, unavailable and untested outcomes for “Trace redaction and bounds”; document how incomplete cases block relevant claims.
- [ ] **UC-M02.08-C089-T03 · Identity fields:** Attach the actual target, fixture, configuration and revision identifiers to each “Trace redaction and bounds” result; do not attribute host-only evidence to a guest or another OS.
- [ ] **UC-M02.08-C089-T04 · Observation capture:** Capture bounded raw “Trace redaction and bounds” observations and harness errors; retain enough information to verify the reported oracle comparison.
- [ ] **UC-M02.08-C089-T05 · Aggregation rules:** Implement the “Trace redaction and bounds” count/reduction rule so failures and missing measurements cannot disappear; preserve “A diagnostic failure cannot leak secrets or exhaust the host”.
- [ ] **UC-M02.08-C089-T06 · Failure visibility:** Feed a failing “Trace redaction and bounds” control through the report path; assert the exact failed case and underlying observation remain visible.
- [ ] **UC-M02.08-C089-T07 · Missing-result visibility:** Withhold a required “Trace redaction and bounds” measurement or target; verify the report uses unavailable/untested rather than a fabricated zero or passing value.
- [ ] **UC-M02.08-C089-T08 · Bounds and redaction:** Check “Trace redaction and bounds” report size and retention against “Trace bytes and retained panic count”; remove secrets while retaining fixture and subject references.
- [ ] **UC-M02.08-C089-T09 · Report reconciliation:** Reconcile the “Trace redaction and bounds” summary with every underlying case record; account for the full planned denominator and all omitted scope.
- [ ] **UC-M02.08-C089-T10 · Qualification handoff:** Publish the “Trace redaction and bounds” report with measured observations, coverage limits and blockers; state which actual targets remain unqualified.

### UC-M02.08-C090 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for trace redaction and bounds; label unexecuted checks as untested.

- [ ] **UC-M02.08-C090-T01 · Evidence inventory:** List the “Trace redaction and bounds” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M02.08-C090-T02 · Artifact references:** Record the exact “Trace redaction and bounds” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M02.08-C090-T03 · Fixture references:** Attach the “Trace redaction and bounds” fixture IDs, input identities and oracle definition; preserve the source counterexample “A panic dumps a buffer containing injected secret material” as a distinct evidence case.
- [ ] **UC-M02.08-C090-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Trace redaction and bounds”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M02.08-C090-T05 · Environment record:** Record the actual “Trace redaction and bounds” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M02.08-C090-T06 · Expected versus observed:** Pair every “Trace redaction and bounds” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M02.08-C090-T07 · Failure and limit records:** Attach “Trace redaction and bounds” change/failure and bounds evidence where required; include uncovered “Trace bytes and retained panic count” and unresolved violations of “A diagnostic failure cannot leak secrets or exhaust the host”.
- [ ] **UC-M02.08-C090-T08 · Evidence hygiene:** Check the “Trace redaction and bounds” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M02.08-C090-T09 · Reproduction review:** Have the “Trace redaction and bounds” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M02.08-C090-T10 · Acceptance linkage:** Link the “Trace redaction and bounds” evidence to its parent and UC-M02.08 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 10. Conformance promotion gate

**Source delivery:** Combine required ABI probes, workload output and induced-panic evidence.

**Source invariant:** A boot-only pass cannot qualify full guest ABI and panic support.

**Source negative case:** One required negative probe is skipped in an otherwise passing run.

**Source bounded quantities:** Required gate count and maximum evidence age.

### UC-M02.08-C091 · Contract

**Original checklist item:** Define the qualification objective for conformance promotion gate, including the actual target implementation, prerequisites, observable oracle and explicit exclusions.

- [ ] **UC-M02.08-C091-T01 · Scope statement:** Write the qualification question for “Conformance promotion gate”; identify the actual target, claimed capability and observations that can answer that question.
- [ ] **UC-M02.08-C091-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Conformance promotion gate”; record each producer, representation and missing-value meaning.
- [ ] **UC-M02.08-C091-T03 · Output inventory:** List the outputs of “Conformance promotion gate” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M02.08-C091-T04 · Field dictionary:** Create a field-and-term dictionary for “Conformance promotion gate”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M02.08-C091-T05 · Prerequisite contract:** Map “Conformance promotion gate” to the source component prerequisites (UC-M02.03, UC-M02.05, UC-M02.06, UC-M02.07); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M02.08-C091-T06 · Authority map:** Identify who may produce, change and consume “Conformance promotion gate”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M02.08-C091-T07 · Invariant clause:** Add a normative clause for “Conformance promotion gate” that preserves “A boot-only pass cannot qualify full guest ABI and panic support”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M02.08-C091-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Conformance promotion gate”; include the source counterexample “One required negative probe is skipped in an otherwise passing run” and the intended safe disposition.
- [ ] **UC-M02.08-C091-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Required gate count and maximum evidence age” in the “Conformance promotion gate” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M02.08-C091-T10 · Contract review:** Review the “Conformance promotion gate” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M02.08-C092 · Delivery

**Original checklist item:** Combine required ABI probes, workload output and induced-panic evidence.

- [ ] **UC-M02.08-C092-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Conformance promotion gate”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M02.08-C092-T02 · Change plan:** Break the source delivery for “Conformance promotion gate” into concrete edit targets and reviewable outputs; keep the UC-M02.08 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M02.08-C092-T03 · Core artifact:** Implement the smallest selected-profile change for “Conformance promotion gate” that realizes this source instruction: Combine required ABI probes, workload output and induced-panic evidence.
- [ ] **UC-M02.08-C092-T04 · Concrete realization:** Trace “Conformance promotion gate” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M02.08-C092-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Conformance promotion gate” needed to preserve “A boot-only pass cannot qualify full guest ABI and panic support”; record an enforcement gap where only a model exists.
- [ ] **UC-M02.08-C092-T06 · Dependency connection:** Connect the “Conformance promotion gate” qualification artifact to the built guest, ABI probe runner and source-mapped panic collector; record the target identity and what the harness actually exercises.
- [ ] **UC-M02.08-C092-T07 · Resource behavior:** Account for “Required gate count and maximum evidence age” in “Conformance promotion gate”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M02.08-C092-T08 · Delivery check:** Run a known-valid control and a deliberately failing control for “Conformance promotion gate”; confirm the harness distinguishes their observed outcomes.
- [ ] **UC-M02.08-C092-T09 · Patch review:** Review the “Conformance promotion gate” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M02.08-C092-T10 · Delivery handoff:** Publish the “Conformance promotion gate” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M02.08-C093 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: A boot-only pass cannot qualify full guest ABI and panic support. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M02.08-C093-T01 · Named property:** Create a stable property/check name under this parent for “Conformance promotion gate”; copy its required invariant exactly: “A boot-only pass cannot qualify full guest ABI and panic support”.
- [ ] **UC-M02.08-C093-T02 · Observable terms:** Define each term in the “Conformance promotion gate” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M02.08-C093-T03 · Precondition set:** List the preconditions under which “A boot-only pass cannot qualify full guest ABI and panic support” must hold for “Conformance promotion gate”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M02.08-C093-T04 · Transition coverage:** Map the “Conformance promotion gate” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M02.08-C093-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Conformance promotion gate”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M02.08-C093-T06 · Satisfying fixture:** Create a concrete “Conformance promotion gate” case that satisfies “A boot-only pass cannot qualify full guest ABI and panic support”; record its expected observation before running the assertion or review.
- [ ] **UC-M02.08-C093-T07 · Violating fixture:** Create the source counterexample “One required negative probe is skipped in an otherwise passing run” for “Conformance promotion gate”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M02.08-C093-T08 · Enforcement evidence:** Exercise the “Conformance promotion gate” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M02.08-C093-T09 · Regression linkage:** Link the “Conformance promotion gate” property to changes in the built guest, ABI probe runner and source-mapped panic collector; record which dependency or contract changes require rerunning it.
- [ ] **UC-M02.08-C093-T10 · Property disposition:** Compare the satisfying and violating “Conformance promotion gate” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M02.08-C094 · Integration

**Original checklist item:** Integrate conformance promotion gate with the built guest, ABI probe runner and source-mapped panic collector; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M02.08-C094-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Conformance promotion gate” across the built guest, ABI probe runner and source-mapped panic collector; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M02.08-C094-T02 · Field mapping:** Map every “Conformance promotion gate” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M02.08-C094-T03 · Prerequisite identities:** Record the actual prerequisites for “Conformance promotion gate” (source dependency list: UC-M02.03, UC-M02.05, UC-M02.06, UC-M02.07); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M02.08-C094-T04 · Ownership agreement:** Specify who owns “Conformance promotion gate” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M02.08-C094-T05 · Handoff implementation:** Connect “Conformance promotion gate” through the mapped seam using the real adapter or explicit specification reference; preserve “A boot-only pass cannot qualify full guest ABI and panic support” across the handoff.
- [ ] **UC-M02.08-C094-T06 · Absent-input case:** Omit one required “Conformance promotion gate” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M02.08-C094-T07 · Stale-input case:** Supply an outdated “Conformance promotion gate” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M02.08-C094-T08 · Incompatible-input case:** Supply an incompatible “Conformance promotion gate” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M02.08-C094-T09 · Valid integration trace:** Run a valid “Conformance promotion gate” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M02.08-C094-T10 · Seam review:** Reconcile the “Conformance promotion gate” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M02.08-C095 · Valid-case test

**Original checklist item:** Run a known-valid control for conformance promotion gate; verify that the harness reaches its intended target and compare observed measurements or verdicts with predeclared expectations.

- [ ] **UC-M02.08-C095-T01 · Valid fixture choice:** Choose a known-valid control for “Conformance promotion gate”; document why it should pass and how it proves the harness reaches the intended target.
- [ ] **UC-M02.08-C095-T02 · Expected-result oracle:** Specify the “Conformance promotion gate” expected result independently of the implementation output; include the property “A boot-only pass cannot qualify full guest ABI and panic support” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M02.08-C095-T03 · Fixture material:** Create the concrete “Conformance promotion gate” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M02.08-C095-T04 · Target preparation:** Prepare the “Conformance promotion gate” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M02.08-C095-T05 · Initial-state record:** Record the initial “Conformance promotion gate” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M02.08-C095-T06 · Valid-path execution:** Run the “Conformance promotion gate” known-valid control on the identified target; retain enough observations to prove the correct target was exercised.
- [ ] **UC-M02.08-C095-T07 · Outcome comparison:** Compare every declared “Conformance promotion gate” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M02.08-C095-T08 · State and bounds check:** Inspect the “Conformance promotion gate” ownership/state effects and actual use of “Required gate count and maximum evidence age”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M02.08-C095-T09 · Repeatability check:** Repeat the same “Conformance promotion gate” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M02.08-C095-T10 · Positive evidence:** Attach the “Conformance promotion gate” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M02.08-C096 · Negative test

**Original checklist item:** Negative case: One required negative probe is skipped in an otherwise passing run. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M02.08-C096-T01 · Adverse-case definition:** Create a test record for the exact “Conformance promotion gate” source counterexample: “One required negative probe is skipped in an otherwise passing run”; state which precondition or invariant it challenges.
- [ ] **UC-M02.08-C096-T02 · Safe fixture boundary:** Define the contained test boundary for “Conformance promotion gate”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M02.08-C096-T03 · Valid control:** Construct a valid “Conformance promotion gate” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M02.08-C096-T04 · Minimal adverse input:** Derive the “Conformance promotion gate” adverse fixture from the control with the smallest documented change needed to reproduce “One required negative probe is skipped in an otherwise passing run”; retain that change as reproducible data.
- [ ] **UC-M02.08-C096-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Conformance promotion gate”; require “A boot-only pass cannot qualify full guest ABI and panic support” and forbid a false-success verdict.
- [ ] **UC-M02.08-C096-T06 · Adverse execution:** Exercise the “Conformance promotion gate” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M02.08-C096-T07 · Effect inspection:** Inspect “Conformance promotion gate” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M02.08-C096-T08 · Refusal versus failure:** Confirm the “Conformance promotion gate” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M02.08-C096-T09 · Reset and retention:** Restore only the disposable “Conformance promotion gate” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M02.08-C096-T10 · Negative regression:** Register the “Conformance promotion gate” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M02.08-C097 · Change / failure test

**Original checklist item:** Exercise conformance promotion gate when the image is rebuilt and previously collected ABI and panic evidence becomes stale; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M02.08-C097-T01 · Scenario record:** Write the “Conformance promotion gate” change/failure scenario exactly as supplied: the image is rebuilt and previously collected ABI and panic evidence becomes stale; identify the property that must remain true: “A boot-only pass cannot qualify full guest ABI and panic support”.
- [ ] **UC-M02.08-C097-T02 · Baseline capture:** Create a known-valid “Conformance promotion gate” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M02.08-C097-T03 · Injection map:** Locate the “Conformance promotion gate” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M02.08-C097-T04 · Disposition oracle:** Define the legal intermediate and final “Conformance promotion gate” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M02.08-C097-T05 · Controlled trigger:** Introduce the controlled “Conformance promotion gate” scenario in the disposable fixture: the image is rebuilt and previously collected ABI and panic evidence becomes stale; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M02.08-C097-T06 · Intermediate inspection:** Inspect the “Conformance promotion gate” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M02.08-C097-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Conformance promotion gate”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M02.08-C097-T08 · Stale-evidence cleanup:** Invalidate superseded “Conformance promotion gate” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M02.08-C097-T09 · Repeat and compare:** Repeat the selected “Conformance promotion gate” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M02.08-C097-T10 · Failure evidence:** Publish the “Conformance promotion gate” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M02.08-C098 · Bounds

**Original checklist item:** Set a documented campaign budget for required gate count and maximum evidence age; record actual consumption, incomplete coverage and the disposition when the budget is exhausted.

- [ ] **UC-M02.08-C098-T01 · Quantity inventory:** Create a measurement inventory for “Conformance promotion gate”: “Required gate count and maximum evidence age”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M02.08-C098-T02 · Measurement method:** Choose how to observe each “Conformance promotion gate” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M02.08-C098-T03 · Budget decision:** Select justified campaign and target-resource budgets for “Conformance promotion gate”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M02.08-C098-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Conformance promotion gate” cases for “Required gate count and maximum evidence age”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M02.08-C098-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Conformance promotion gate” limit; preserve “A boot-only pass cannot qualify full guest ABI and panic support”.
- [ ] **UC-M02.08-C098-T06 · Normal measurement:** Run or review the normal “Conformance promotion gate” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M02.08-C098-T07 · At-limit measurement:** Exercise the “Conformance promotion gate” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M02.08-C098-T08 · Over-limit measurement:** Exercise the “Conformance promotion gate” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M02.08-C098-T09 · Uncovered-scope report:** List the “Conformance promotion gate” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M02.08-C098-T10 · Limit evidence:** Publish the selected “Conformance promotion gate” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M02.08-C099 · Diagnostics / review

**Original checklist item:** Report conformance promotion gate results with executed, failed, skipped and unavailable cases separated; preserve the underlying observations and do not manufacture missing measurements.

- [ ] **UC-M02.08-C099-T01 · Result inventory:** Enumerate the required “Conformance promotion gate” qualification cases and intended targets before aggregating results; keep the planned denominator visible.
- [ ] **UC-M02.08-C099-T02 · Verdict schema:** Define separate executed-pass, executed-fail, skipped, unavailable and untested outcomes for “Conformance promotion gate”; document how incomplete cases block relevant claims.
- [ ] **UC-M02.08-C099-T03 · Identity fields:** Attach the actual target, fixture, configuration and revision identifiers to each “Conformance promotion gate” result; do not attribute host-only evidence to a guest or another OS.
- [ ] **UC-M02.08-C099-T04 · Observation capture:** Capture bounded raw “Conformance promotion gate” observations and harness errors; retain enough information to verify the reported oracle comparison.
- [ ] **UC-M02.08-C099-T05 · Aggregation rules:** Implement the “Conformance promotion gate” count/reduction rule so failures and missing measurements cannot disappear; preserve “A boot-only pass cannot qualify full guest ABI and panic support”.
- [ ] **UC-M02.08-C099-T06 · Failure visibility:** Feed a failing “Conformance promotion gate” control through the report path; assert the exact failed case and underlying observation remain visible.
- [ ] **UC-M02.08-C099-T07 · Missing-result visibility:** Withhold a required “Conformance promotion gate” measurement or target; verify the report uses unavailable/untested rather than a fabricated zero or passing value.
- [ ] **UC-M02.08-C099-T08 · Bounds and redaction:** Check “Conformance promotion gate” report size and retention against “Required gate count and maximum evidence age”; remove secrets while retaining fixture and subject references.
- [ ] **UC-M02.08-C099-T09 · Report reconciliation:** Reconcile the “Conformance promotion gate” summary with every underlying case record; account for the full planned denominator and all omitted scope.
- [ ] **UC-M02.08-C099-T10 · Qualification handoff:** Publish the “Conformance promotion gate” report with measured observations, coverage limits and blockers; state which actual targets remain unqualified.

### UC-M02.08-C100 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for conformance promotion gate; label unexecuted checks as untested.

- [ ] **UC-M02.08-C100-T01 · Evidence inventory:** List the “Conformance promotion gate” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M02.08-C100-T02 · Artifact references:** Record the exact “Conformance promotion gate” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M02.08-C100-T03 · Fixture references:** Attach the “Conformance promotion gate” fixture IDs, input identities and oracle definition; preserve the source counterexample “One required negative probe is skipped in an otherwise passing run” as a distinct evidence case.
- [ ] **UC-M02.08-C100-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Conformance promotion gate”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M02.08-C100-T05 · Environment record:** Record the actual “Conformance promotion gate” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M02.08-C100-T06 · Expected versus observed:** Pair every “Conformance promotion gate” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M02.08-C100-T07 · Failure and limit records:** Attach “Conformance promotion gate” change/failure and bounds evidence where required; include uncovered “Required gate count and maximum evidence age” and unresolved violations of “A boot-only pass cannot qualify full guest ABI and panic support”.
- [ ] **UC-M02.08-C100-T08 · Evidence hygiene:** Check the “Conformance promotion gate” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M02.08-C100-T09 · Reproduction review:** Have the “Conformance promotion gate” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M02.08-C100-T10 · Acceptance linkage:** Link the “Conformance promotion gate” evidence to its parent and UC-M02.08 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

