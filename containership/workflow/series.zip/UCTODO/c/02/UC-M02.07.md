# UC-M02.07 — Minimal console, block and transport drivers

**To-Do Pack 2.0.0 · Baseline UC-2.2.0 · 100 parent checks × 10 subtasks = 1,000 to-dos**

[Master index](../../INDEX.md) · [Workstream index](../../w/02.md)

| Field | Preserved source value |
|---|---|
| Workstream | 02. Bootable unikernel guest |
| Milestone | B |
| Priority | P0 |
| Source assessment | MISSING |
| Scope | core or selected profile |
| Dependencies | [UC-M02.02](../02/UC-M02.02.md), [UC-M02.04](../02/UC-M02.04.md) |
| Source checklist pack | 1.0.0 |
| Original reference labels | [S1], [S2], [S3]. |

## Original requirement

Implement only devices needed by the first workload: bounded console, selected block device and optional transport with validated descriptors.

**Original acceptance criterion:** Malformed descriptors and unavailable devices fail safely; no unused device is exposed by default.

**Source trace:** Original checklist `UC100/c/02/UC-M02.07.md` inside [s/checklists.zip](../../s/checklists.zip); exact parent records in [data/parents.jsonl](../../data/parents.jsonl). Original roadmap lines 210–220 are preserved in [s/roadmap.md](../../s/roadmap.md).

## How to use these lists

Every parent statement below is preserved verbatim. Its ten child tasks are proposed decomposition, not implemented capabilities or executed tests. Child IDs append `-T01` through `-T10` to the original parent ID. All begin unchecked / `TODO`. Design/review evidence does not establish runtime enforcement; observe the actual selected target where the parent requires it.

The source dependency graph and selected release profile determine applicability. The numbered child sequence is a local working order, not an added hard dependency graph. An unselected optional feature needs a recorded not-applicable rationale; missing prerequisites for selected work remain blockers. Numerical budgets, backends and trust mechanisms remain decisions unless fixed by the source. Test hostile cases only with synthetic inputs in authorized disposable environments.

## 01. Required-device inventory

**Source delivery:** List only console, block and transport devices required by the first workload.

**Source invariant:** An unused device is absent from the default guest profile.

**Source negative case:** The offline workload receives an unnecessary virtual network device.

**Source bounded quantities:** Device count and exposed interface surface.

### UC-M02.07-C001 · Contract

**Original checklist item:** Specify required-device inventory inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M02.07-C001-T01 · Scope statement:** Draft the operation boundary for “Required-device inventory” within Minimal console, block and transport drivers; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M02.07-C001-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Required-device inventory”; record each producer, representation and missing-value meaning.
- [ ] **UC-M02.07-C001-T03 · Output inventory:** List the outputs of “Required-device inventory” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M02.07-C001-T04 · Field dictionary:** Create a field-and-term dictionary for “Required-device inventory”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M02.07-C001-T05 · Prerequisite contract:** Map “Required-device inventory” to the source component prerequisites (UC-M02.02, UC-M02.04); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M02.07-C001-T06 · Authority map:** Identify who may produce, change and consume “Required-device inventory”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M02.07-C001-T07 · Invariant clause:** Add a normative clause for “Required-device inventory” that preserves “An unused device is absent from the default guest profile”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M02.07-C001-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Required-device inventory”; include the source counterexample “The offline workload receives an unnecessary virtual network device” and the intended safe disposition.
- [ ] **UC-M02.07-C001-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Device count and exposed interface surface” in the “Required-device inventory” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M02.07-C001-T10 · Contract review:** Review the “Required-device inventory” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M02.07-C002 · Delivery

**Original checklist item:** List only console, block and transport devices required by the first workload.

- [ ] **UC-M02.07-C002-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Required-device inventory”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M02.07-C002-T02 · Change plan:** Break the source delivery for “Required-device inventory” into concrete edit targets and reviewable outputs; keep the UC-M02.07 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M02.07-C002-T03 · Core artifact:** Create the “Required-device inventory” model, schema or inventory that realizes this source instruction: List only console, block and transport devices required by the first workload.
- [ ] **UC-M02.07-C002-T04 · Concrete realization:** Populate “Required-device inventory” with one concrete worked case; map every required entity or field to its source and flag any unmapped entry.
- [ ] **UC-M02.07-C002-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Required-device inventory” needed to preserve “An unused device is absent from the default guest profile”; record an enforcement gap where only a model exists.
- [ ] **UC-M02.07-C002-T06 · Dependency connection:** Connect the “Required-device inventory” implementation to selected guest devices, validated descriptors and host resource ownership; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M02.07-C002-T07 · Resource behavior:** Account for “Device count and exposed interface surface” in “Required-device inventory”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M02.07-C002-T08 · Delivery check:** Run the smallest real “Required-device inventory” path and its adverse fixture “The offline workload receives an unnecessary virtual network device”; retain actual output, state effects and final disposition.
- [ ] **UC-M02.07-C002-T09 · Patch review:** Review the “Required-device inventory” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M02.07-C002-T10 · Delivery handoff:** Publish the “Required-device inventory” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M02.07-C003 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: An unused device is absent from the default guest profile. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M02.07-C003-T01 · Named property:** Create a stable property/check name under this parent for “Required-device inventory”; copy its required invariant exactly: “An unused device is absent from the default guest profile”.
- [ ] **UC-M02.07-C003-T02 · Observable terms:** Define each term in the “Required-device inventory” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M02.07-C003-T03 · Precondition set:** List the preconditions under which “An unused device is absent from the default guest profile” must hold for “Required-device inventory”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M02.07-C003-T04 · Transition coverage:** Map the “Required-device inventory” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M02.07-C003-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Required-device inventory”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M02.07-C003-T06 · Satisfying fixture:** Create a concrete “Required-device inventory” case that satisfies “An unused device is absent from the default guest profile”; record its expected observation before running the assertion or review.
- [ ] **UC-M02.07-C003-T07 · Violating fixture:** Create the source counterexample “The offline workload receives an unnecessary virtual network device” for “Required-device inventory”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M02.07-C003-T08 · Enforcement evidence:** Exercise the “Required-device inventory” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M02.07-C003-T09 · Regression linkage:** Link the “Required-device inventory” property to changes in selected guest devices, validated descriptors and host resource ownership; record which dependency or contract changes require rerunning it.
- [ ] **UC-M02.07-C003-T10 · Property disposition:** Compare the satisfying and violating “Required-device inventory” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M02.07-C004 · Integration

**Original checklist item:** Integrate required-device inventory with selected guest devices, validated descriptors and host resource ownership; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M02.07-C004-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Required-device inventory” across selected guest devices, validated descriptors and host resource ownership; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M02.07-C004-T02 · Field mapping:** Map every “Required-device inventory” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M02.07-C004-T03 · Prerequisite identities:** Record the actual prerequisites for “Required-device inventory” (source dependency list: UC-M02.02, UC-M02.04); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M02.07-C004-T04 · Ownership agreement:** Specify who owns “Required-device inventory” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M02.07-C004-T05 · Handoff implementation:** Connect “Required-device inventory” through the mapped seam using the real adapter or explicit specification reference; preserve “An unused device is absent from the default guest profile” across the handoff.
- [ ] **UC-M02.07-C004-T06 · Absent-input case:** Omit one required “Required-device inventory” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M02.07-C004-T07 · Stale-input case:** Supply an outdated “Required-device inventory” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M02.07-C004-T08 · Incompatible-input case:** Supply an incompatible “Required-device inventory” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M02.07-C004-T09 · Valid integration trace:** Run a valid “Required-device inventory” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M02.07-C004-T10 · Seam review:** Reconcile the “Required-device inventory” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M02.07-C005 · Valid-case test

**Original checklist item:** Run a valid-path fixture for required-device inventory; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M02.07-C005-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Required-device inventory” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M02.07-C005-T02 · Expected-result oracle:** Specify the “Required-device inventory” expected result independently of the implementation output; include the property “An unused device is absent from the default guest profile” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M02.07-C005-T03 · Fixture material:** Create the concrete “Required-device inventory” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M02.07-C005-T04 · Target preparation:** Prepare the “Required-device inventory” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M02.07-C005-T05 · Initial-state record:** Record the initial “Required-device inventory” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M02.07-C005-T06 · Valid-path execution:** Execute the “Required-device inventory” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M02.07-C005-T07 · Outcome comparison:** Compare every declared “Required-device inventory” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M02.07-C005-T08 · State and bounds check:** Inspect the “Required-device inventory” ownership/state effects and actual use of “Device count and exposed interface surface”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M02.07-C005-T09 · Repeatability check:** Repeat the same “Required-device inventory” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M02.07-C005-T10 · Positive evidence:** Attach the “Required-device inventory” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M02.07-C006 · Negative test

**Original checklist item:** Negative case: The offline workload receives an unnecessary virtual network device. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M02.07-C006-T01 · Adverse-case definition:** Create a test record for the exact “Required-device inventory” source counterexample: “The offline workload receives an unnecessary virtual network device”; state which precondition or invariant it challenges.
- [ ] **UC-M02.07-C006-T02 · Safe fixture boundary:** Define the contained test boundary for “Required-device inventory”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M02.07-C006-T03 · Valid control:** Construct a valid “Required-device inventory” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M02.07-C006-T04 · Minimal adverse input:** Derive the “Required-device inventory” adverse fixture from the control with the smallest documented change needed to reproduce “The offline workload receives an unnecessary virtual network device”; retain that change as reproducible data.
- [ ] **UC-M02.07-C006-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Required-device inventory”; require “An unused device is absent from the default guest profile” and forbid a false-success verdict.
- [ ] **UC-M02.07-C006-T06 · Adverse execution:** Exercise the “Required-device inventory” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M02.07-C006-T07 · Effect inspection:** Inspect “Required-device inventory” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M02.07-C006-T08 · Refusal versus failure:** Confirm the “Required-device inventory” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M02.07-C006-T09 · Reset and retention:** Restore only the disposable “Required-device inventory” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M02.07-C006-T10 · Negative regression:** Register the “Required-device inventory” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M02.07-C007 · Change / failure test

**Original checklist item:** Exercise required-device inventory when a required device disappears with requests still outstanding; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M02.07-C007-T01 · Scenario record:** Write the “Required-device inventory” change/failure scenario exactly as supplied: a required device disappears with requests still outstanding; identify the property that must remain true: “An unused device is absent from the default guest profile”.
- [ ] **UC-M02.07-C007-T02 · Baseline capture:** Create a known-valid “Required-device inventory” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M02.07-C007-T03 · Injection map:** Locate the “Required-device inventory” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M02.07-C007-T04 · Disposition oracle:** Define the legal intermediate and final “Required-device inventory” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M02.07-C007-T05 · Controlled trigger:** Introduce the controlled “Required-device inventory” scenario in the disposable fixture: a required device disappears with requests still outstanding; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M02.07-C007-T06 · Intermediate inspection:** Inspect the “Required-device inventory” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M02.07-C007-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Required-device inventory”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M02.07-C007-T08 · Stale-evidence cleanup:** Invalidate superseded “Required-device inventory” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M02.07-C007-T09 · Repeat and compare:** Repeat the selected “Required-device inventory” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M02.07-C007-T10 · Failure evidence:** Publish the “Required-device inventory” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M02.07-C008 · Bounds

**Original checklist item:** Choose, document and test limits for device count and exposed interface surface; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M02.07-C008-T01 · Quantity inventory:** Create a measurement inventory for “Required-device inventory”: “Device count and exposed interface surface”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M02.07-C008-T02 · Measurement method:** Choose how to observe each “Required-device inventory” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M02.07-C008-T03 · Budget decision:** Select justified resource and input limits for “Required-device inventory”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M02.07-C008-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Required-device inventory” cases for “Device count and exposed interface surface”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M02.07-C008-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Required-device inventory” limit; preserve “An unused device is absent from the default guest profile”.
- [ ] **UC-M02.07-C008-T06 · Normal measurement:** Run or review the normal “Required-device inventory” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M02.07-C008-T07 · At-limit measurement:** Exercise the “Required-device inventory” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M02.07-C008-T08 · Over-limit measurement:** Exercise the “Required-device inventory” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M02.07-C008-T09 · Uncovered-scope report:** List the “Required-device inventory” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M02.07-C008-T10 · Limit evidence:** Publish the selected “Required-device inventory” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M02.07-C009 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for required-device inventory with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M02.07-C009-T01 · Event inventory:** List the “Required-device inventory” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M02.07-C009-T02 · Diagnostic schema:** Define nonsecret fields for “Required-device inventory” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M02.07-C009-T03 · Failure mapping:** Map each documented “Required-device inventory” refusal or error to a diagnostic outcome; include “The offline workload receives an unnecessary virtual network device” and prohibit conversion into a success message.
- [ ] **UC-M02.07-C009-T04 · Emission path:** Add the “Required-device inventory” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M02.07-C009-T05 · Redaction check:** Test “Required-device inventory” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M02.07-C009-T06 · Output budget:** Set and exercise bounded “Required-device inventory” message size, rate and retention compatible with “Device count and exposed interface surface”; define truncation behavior that preserves the final reason.
- [ ] **UC-M02.07-C009-T07 · Success/refusal fixtures:** Capture “Required-device inventory” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M02.07-C009-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Required-device inventory” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M02.07-C009-T09 · Operator review:** Read the “Required-device inventory” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M02.07-C009-T10 · Diagnostic evidence:** Publish redacted “Required-device inventory” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M02.07-C010 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for required-device inventory; label unexecuted checks as untested.

- [ ] **UC-M02.07-C010-T01 · Evidence inventory:** List the “Required-device inventory” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M02.07-C010-T02 · Artifact references:** Record the exact “Required-device inventory” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M02.07-C010-T03 · Fixture references:** Attach the “Required-device inventory” fixture IDs, input identities and oracle definition; preserve the source counterexample “The offline workload receives an unnecessary virtual network device” as a distinct evidence case.
- [ ] **UC-M02.07-C010-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Required-device inventory”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M02.07-C010-T05 · Environment record:** Record the actual “Required-device inventory” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M02.07-C010-T06 · Expected versus observed:** Pair every “Required-device inventory” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M02.07-C010-T07 · Failure and limit records:** Attach “Required-device inventory” change/failure and bounds evidence where required; include uncovered “Device count and exposed interface surface” and unresolved violations of “An unused device is absent from the default guest profile”.
- [ ] **UC-M02.07-C010-T08 · Evidence hygiene:** Check the “Required-device inventory” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M02.07-C010-T09 · Reproduction review:** Have the “Required-device inventory” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M02.07-C010-T10 · Acceptance linkage:** Link the “Required-device inventory” evidence to its parent and UC-M02.07 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 02. Console output boundary

**Source delivery:** Implement bounded guest console writes and declared encoding behavior.

**Source invariant:** Console output cannot exhaust host memory or disk.

**Source negative case:** A guest emits console data without termination.

**Source bounded quantities:** Console bytes per interval and retained log size.

### UC-M02.07-C011 · Contract

**Original checklist item:** Specify console output boundary inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M02.07-C011-T01 · Scope statement:** Draft the operation boundary for “Console output boundary” within Minimal console, block and transport drivers; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M02.07-C011-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Console output boundary”; record each producer, representation and missing-value meaning.
- [ ] **UC-M02.07-C011-T03 · Output inventory:** List the outputs of “Console output boundary” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M02.07-C011-T04 · Field dictionary:** Create a field-and-term dictionary for “Console output boundary”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M02.07-C011-T05 · Prerequisite contract:** Map “Console output boundary” to the source component prerequisites (UC-M02.02, UC-M02.04); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M02.07-C011-T06 · Authority map:** Identify who may produce, change and consume “Console output boundary”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M02.07-C011-T07 · Invariant clause:** Add a normative clause for “Console output boundary” that preserves “Console output cannot exhaust host memory or disk”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M02.07-C011-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Console output boundary”; include the source counterexample “A guest emits console data without termination” and the intended safe disposition.
- [ ] **UC-M02.07-C011-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Console bytes per interval and retained log size” in the “Console output boundary” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M02.07-C011-T10 · Contract review:** Review the “Console output boundary” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M02.07-C012 · Delivery

**Original checklist item:** Implement bounded guest console writes and declared encoding behavior.

- [ ] **UC-M02.07-C012-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Console output boundary”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M02.07-C012-T02 · Change plan:** Break the source delivery for “Console output boundary” into concrete edit targets and reviewable outputs; keep the UC-M02.07 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M02.07-C012-T03 · Core artifact:** Implement the smallest selected-profile change for “Console output boundary” that realizes this source instruction: Implement bounded guest console writes and declared encoding behavior.
- [ ] **UC-M02.07-C012-T04 · Concrete realization:** Trace “Console output boundary” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M02.07-C012-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Console output boundary” needed to preserve “Console output cannot exhaust host memory or disk”; record an enforcement gap where only a model exists.
- [ ] **UC-M02.07-C012-T06 · Dependency connection:** Connect the “Console output boundary” implementation to selected guest devices, validated descriptors and host resource ownership; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M02.07-C012-T07 · Resource behavior:** Account for “Console bytes per interval and retained log size” in “Console output boundary”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M02.07-C012-T08 · Delivery check:** Run the smallest real “Console output boundary” path and its adverse fixture “A guest emits console data without termination”; retain actual output, state effects and final disposition.
- [ ] **UC-M02.07-C012-T09 · Patch review:** Review the “Console output boundary” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M02.07-C012-T10 · Delivery handoff:** Publish the “Console output boundary” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M02.07-C013 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Console output cannot exhaust host memory or disk. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M02.07-C013-T01 · Named property:** Create a stable property/check name under this parent for “Console output boundary”; copy its required invariant exactly: “Console output cannot exhaust host memory or disk”.
- [ ] **UC-M02.07-C013-T02 · Observable terms:** Define each term in the “Console output boundary” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M02.07-C013-T03 · Precondition set:** List the preconditions under which “Console output cannot exhaust host memory or disk” must hold for “Console output boundary”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M02.07-C013-T04 · Transition coverage:** Map the “Console output boundary” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M02.07-C013-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Console output boundary”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M02.07-C013-T06 · Satisfying fixture:** Create a concrete “Console output boundary” case that satisfies “Console output cannot exhaust host memory or disk”; record its expected observation before running the assertion or review.
- [ ] **UC-M02.07-C013-T07 · Violating fixture:** Create the source counterexample “A guest emits console data without termination” for “Console output boundary”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M02.07-C013-T08 · Enforcement evidence:** Exercise the “Console output boundary” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M02.07-C013-T09 · Regression linkage:** Link the “Console output boundary” property to changes in selected guest devices, validated descriptors and host resource ownership; record which dependency or contract changes require rerunning it.
- [ ] **UC-M02.07-C013-T10 · Property disposition:** Compare the satisfying and violating “Console output boundary” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M02.07-C014 · Integration

**Original checklist item:** Integrate console output boundary with selected guest devices, validated descriptors and host resource ownership; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M02.07-C014-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Console output boundary” across selected guest devices, validated descriptors and host resource ownership; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M02.07-C014-T02 · Field mapping:** Map every “Console output boundary” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M02.07-C014-T03 · Prerequisite identities:** Record the actual prerequisites for “Console output boundary” (source dependency list: UC-M02.02, UC-M02.04); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M02.07-C014-T04 · Ownership agreement:** Specify who owns “Console output boundary” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M02.07-C014-T05 · Handoff implementation:** Connect “Console output boundary” through the mapped seam using the real adapter or explicit specification reference; preserve “Console output cannot exhaust host memory or disk” across the handoff.
- [ ] **UC-M02.07-C014-T06 · Absent-input case:** Omit one required “Console output boundary” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M02.07-C014-T07 · Stale-input case:** Supply an outdated “Console output boundary” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M02.07-C014-T08 · Incompatible-input case:** Supply an incompatible “Console output boundary” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M02.07-C014-T09 · Valid integration trace:** Run a valid “Console output boundary” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M02.07-C014-T10 · Seam review:** Reconcile the “Console output boundary” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M02.07-C015 · Valid-case test

**Original checklist item:** Run a valid-path fixture for console output boundary; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M02.07-C015-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Console output boundary” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M02.07-C015-T02 · Expected-result oracle:** Specify the “Console output boundary” expected result independently of the implementation output; include the property “Console output cannot exhaust host memory or disk” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M02.07-C015-T03 · Fixture material:** Create the concrete “Console output boundary” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M02.07-C015-T04 · Target preparation:** Prepare the “Console output boundary” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M02.07-C015-T05 · Initial-state record:** Record the initial “Console output boundary” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M02.07-C015-T06 · Valid-path execution:** Execute the “Console output boundary” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M02.07-C015-T07 · Outcome comparison:** Compare every declared “Console output boundary” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M02.07-C015-T08 · State and bounds check:** Inspect the “Console output boundary” ownership/state effects and actual use of “Console bytes per interval and retained log size”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M02.07-C015-T09 · Repeatability check:** Repeat the same “Console output boundary” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M02.07-C015-T10 · Positive evidence:** Attach the “Console output boundary” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M02.07-C016 · Negative test

**Original checklist item:** Negative case: A guest emits console data without termination. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M02.07-C016-T01 · Adverse-case definition:** Create a test record for the exact “Console output boundary” source counterexample: “A guest emits console data without termination”; state which precondition or invariant it challenges.
- [ ] **UC-M02.07-C016-T02 · Safe fixture boundary:** Define the contained test boundary for “Console output boundary”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M02.07-C016-T03 · Valid control:** Construct a valid “Console output boundary” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M02.07-C016-T04 · Minimal adverse input:** Derive the “Console output boundary” adverse fixture from the control with the smallest documented change needed to reproduce “A guest emits console data without termination”; retain that change as reproducible data.
- [ ] **UC-M02.07-C016-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Console output boundary”; require “Console output cannot exhaust host memory or disk” and forbid a false-success verdict.
- [ ] **UC-M02.07-C016-T06 · Adverse execution:** Exercise the “Console output boundary” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M02.07-C016-T07 · Effect inspection:** Inspect “Console output boundary” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M02.07-C016-T08 · Refusal versus failure:** Confirm the “Console output boundary” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M02.07-C016-T09 · Reset and retention:** Restore only the disposable “Console output boundary” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M02.07-C016-T10 · Negative regression:** Register the “Console output boundary” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M02.07-C017 · Change / failure test

**Original checklist item:** Exercise console output boundary when a required device disappears with requests still outstanding; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M02.07-C017-T01 · Scenario record:** Write the “Console output boundary” change/failure scenario exactly as supplied: a required device disappears with requests still outstanding; identify the property that must remain true: “Console output cannot exhaust host memory or disk”.
- [ ] **UC-M02.07-C017-T02 · Baseline capture:** Create a known-valid “Console output boundary” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M02.07-C017-T03 · Injection map:** Locate the “Console output boundary” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M02.07-C017-T04 · Disposition oracle:** Define the legal intermediate and final “Console output boundary” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M02.07-C017-T05 · Controlled trigger:** Introduce the controlled “Console output boundary” scenario in the disposable fixture: a required device disappears with requests still outstanding; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M02.07-C017-T06 · Intermediate inspection:** Inspect the “Console output boundary” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M02.07-C017-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Console output boundary”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M02.07-C017-T08 · Stale-evidence cleanup:** Invalidate superseded “Console output boundary” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M02.07-C017-T09 · Repeat and compare:** Repeat the selected “Console output boundary” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M02.07-C017-T10 · Failure evidence:** Publish the “Console output boundary” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M02.07-C018 · Bounds

**Original checklist item:** Choose, document and test limits for console bytes per interval and retained log size; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M02.07-C018-T01 · Quantity inventory:** Create a measurement inventory for “Console output boundary”: “Console bytes per interval and retained log size”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M02.07-C018-T02 · Measurement method:** Choose how to observe each “Console output boundary” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M02.07-C018-T03 · Budget decision:** Select justified resource and input limits for “Console output boundary”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M02.07-C018-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Console output boundary” cases for “Console bytes per interval and retained log size”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M02.07-C018-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Console output boundary” limit; preserve “Console output cannot exhaust host memory or disk”.
- [ ] **UC-M02.07-C018-T06 · Normal measurement:** Run or review the normal “Console output boundary” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M02.07-C018-T07 · At-limit measurement:** Exercise the “Console output boundary” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M02.07-C018-T08 · Over-limit measurement:** Exercise the “Console output boundary” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M02.07-C018-T09 · Uncovered-scope report:** List the “Console output boundary” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M02.07-C018-T10 · Limit evidence:** Publish the selected “Console output boundary” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M02.07-C019 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for console output boundary with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M02.07-C019-T01 · Event inventory:** List the “Console output boundary” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M02.07-C019-T02 · Diagnostic schema:** Define nonsecret fields for “Console output boundary” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M02.07-C019-T03 · Failure mapping:** Map each documented “Console output boundary” refusal or error to a diagnostic outcome; include “A guest emits console data without termination” and prohibit conversion into a success message.
- [ ] **UC-M02.07-C019-T04 · Emission path:** Add the “Console output boundary” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M02.07-C019-T05 · Redaction check:** Test “Console output boundary” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M02.07-C019-T06 · Output budget:** Set and exercise bounded “Console output boundary” message size, rate and retention compatible with “Console bytes per interval and retained log size”; define truncation behavior that preserves the final reason.
- [ ] **UC-M02.07-C019-T07 · Success/refusal fixtures:** Capture “Console output boundary” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M02.07-C019-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Console output boundary” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M02.07-C019-T09 · Operator review:** Read the “Console output boundary” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M02.07-C019-T10 · Diagnostic evidence:** Publish redacted “Console output boundary” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M02.07-C020 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for console output boundary; label unexecuted checks as untested.

- [ ] **UC-M02.07-C020-T01 · Evidence inventory:** List the “Console output boundary” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M02.07-C020-T02 · Artifact references:** Record the exact “Console output boundary” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M02.07-C020-T03 · Fixture references:** Attach the “Console output boundary” fixture IDs, input identities and oracle definition; preserve the source counterexample “A guest emits console data without termination” as a distinct evidence case.
- [ ] **UC-M02.07-C020-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Console output boundary”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M02.07-C020-T05 · Environment record:** Record the actual “Console output boundary” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M02.07-C020-T06 · Expected versus observed:** Pair every “Console output boundary” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M02.07-C020-T07 · Failure and limit records:** Attach “Console output boundary” change/failure and bounds evidence where required; include uncovered “Console bytes per interval and retained log size” and unresolved violations of “Console output cannot exhaust host memory or disk”.
- [ ] **UC-M02.07-C020-T08 · Evidence hygiene:** Check the “Console output boundary” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M02.07-C020-T09 · Reproduction review:** Have the “Console output boundary” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M02.07-C020-T10 · Acceptance linkage:** Link the “Console output boundary” evidence to its parent and UC-M02.07 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 03. Console input policy

**Source delivery:** Specify whether guest console input exists and who may supply it.

**Source invariant:** Console input cannot bypass the workload's command or identity contract.

**Source negative case:** An unauthenticated console message invokes a management action.

**Source bounded quantities:** Input bytes and pending console messages.

### UC-M02.07-C021 · Contract

**Original checklist item:** Specify console input policy inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M02.07-C021-T01 · Scope statement:** Draft the operation boundary for “Console input policy” within Minimal console, block and transport drivers; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M02.07-C021-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Console input policy”; record each producer, representation and missing-value meaning.
- [ ] **UC-M02.07-C021-T03 · Output inventory:** List the outputs of “Console input policy” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M02.07-C021-T04 · Field dictionary:** Create a field-and-term dictionary for “Console input policy”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M02.07-C021-T05 · Prerequisite contract:** Map “Console input policy” to the source component prerequisites (UC-M02.02, UC-M02.04); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M02.07-C021-T06 · Authority map:** Identify who may produce, change and consume “Console input policy”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M02.07-C021-T07 · Invariant clause:** Add a normative clause for “Console input policy” that preserves “Console input cannot bypass the workload's command or identity contract”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M02.07-C021-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Console input policy”; include the source counterexample “An unauthenticated console message invokes a management action” and the intended safe disposition.
- [ ] **UC-M02.07-C021-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Input bytes and pending console messages” in the “Console input policy” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M02.07-C021-T10 · Contract review:** Review the “Console input policy” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M02.07-C022 · Delivery

**Original checklist item:** Specify whether guest console input exists and who may supply it.

- [ ] **UC-M02.07-C022-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Console input policy”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M02.07-C022-T02 · Change plan:** Break the source delivery for “Console input policy” into concrete edit targets and reviewable outputs; keep the UC-M02.07 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M02.07-C022-T03 · Core artifact:** Create the “Console input policy” model, schema or inventory that realizes this source instruction: Specify whether guest console input exists and who may supply it.
- [ ] **UC-M02.07-C022-T04 · Concrete realization:** Populate “Console input policy” with one concrete worked case; map every required entity or field to its source and flag any unmapped entry.
- [ ] **UC-M02.07-C022-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Console input policy” needed to preserve “Console input cannot bypass the workload's command or identity contract”; record an enforcement gap where only a model exists.
- [ ] **UC-M02.07-C022-T06 · Dependency connection:** Connect the “Console input policy” implementation to selected guest devices, validated descriptors and host resource ownership; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M02.07-C022-T07 · Resource behavior:** Account for “Input bytes and pending console messages” in “Console input policy”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M02.07-C022-T08 · Delivery check:** Run the smallest real “Console input policy” path and its adverse fixture “An unauthenticated console message invokes a management action”; retain actual output, state effects and final disposition.
- [ ] **UC-M02.07-C022-T09 · Patch review:** Review the “Console input policy” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M02.07-C022-T10 · Delivery handoff:** Publish the “Console input policy” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M02.07-C023 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Console input cannot bypass the workload's command or identity contract. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M02.07-C023-T01 · Named property:** Create a stable property/check name under this parent for “Console input policy”; copy its required invariant exactly: “Console input cannot bypass the workload's command or identity contract”.
- [ ] **UC-M02.07-C023-T02 · Observable terms:** Define each term in the “Console input policy” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M02.07-C023-T03 · Precondition set:** List the preconditions under which “Console input cannot bypass the workload's command or identity contract” must hold for “Console input policy”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M02.07-C023-T04 · Transition coverage:** Map the “Console input policy” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M02.07-C023-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Console input policy”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M02.07-C023-T06 · Satisfying fixture:** Create a concrete “Console input policy” case that satisfies “Console input cannot bypass the workload's command or identity contract”; record its expected observation before running the assertion or review.
- [ ] **UC-M02.07-C023-T07 · Violating fixture:** Create the source counterexample “An unauthenticated console message invokes a management action” for “Console input policy”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M02.07-C023-T08 · Enforcement evidence:** Exercise the “Console input policy” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M02.07-C023-T09 · Regression linkage:** Link the “Console input policy” property to changes in selected guest devices, validated descriptors and host resource ownership; record which dependency or contract changes require rerunning it.
- [ ] **UC-M02.07-C023-T10 · Property disposition:** Compare the satisfying and violating “Console input policy” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M02.07-C024 · Integration

**Original checklist item:** Integrate console input policy with selected guest devices, validated descriptors and host resource ownership; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M02.07-C024-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Console input policy” across selected guest devices, validated descriptors and host resource ownership; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M02.07-C024-T02 · Field mapping:** Map every “Console input policy” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M02.07-C024-T03 · Prerequisite identities:** Record the actual prerequisites for “Console input policy” (source dependency list: UC-M02.02, UC-M02.04); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M02.07-C024-T04 · Ownership agreement:** Specify who owns “Console input policy” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M02.07-C024-T05 · Handoff implementation:** Connect “Console input policy” through the mapped seam using the real adapter or explicit specification reference; preserve “Console input cannot bypass the workload's command or identity contract” across the handoff.
- [ ] **UC-M02.07-C024-T06 · Absent-input case:** Omit one required “Console input policy” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M02.07-C024-T07 · Stale-input case:** Supply an outdated “Console input policy” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M02.07-C024-T08 · Incompatible-input case:** Supply an incompatible “Console input policy” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M02.07-C024-T09 · Valid integration trace:** Run a valid “Console input policy” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M02.07-C024-T10 · Seam review:** Reconcile the “Console input policy” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M02.07-C025 · Valid-case test

**Original checklist item:** Run a valid-path fixture for console input policy; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M02.07-C025-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Console input policy” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M02.07-C025-T02 · Expected-result oracle:** Specify the “Console input policy” expected result independently of the implementation output; include the property “Console input cannot bypass the workload's command or identity contract” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M02.07-C025-T03 · Fixture material:** Create the concrete “Console input policy” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M02.07-C025-T04 · Target preparation:** Prepare the “Console input policy” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M02.07-C025-T05 · Initial-state record:** Record the initial “Console input policy” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M02.07-C025-T06 · Valid-path execution:** Execute the “Console input policy” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M02.07-C025-T07 · Outcome comparison:** Compare every declared “Console input policy” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M02.07-C025-T08 · State and bounds check:** Inspect the “Console input policy” ownership/state effects and actual use of “Input bytes and pending console messages”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M02.07-C025-T09 · Repeatability check:** Repeat the same “Console input policy” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M02.07-C025-T10 · Positive evidence:** Attach the “Console input policy” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M02.07-C026 · Negative test

**Original checklist item:** Negative case: An unauthenticated console message invokes a management action. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M02.07-C026-T01 · Adverse-case definition:** Create a test record for the exact “Console input policy” source counterexample: “An unauthenticated console message invokes a management action”; state which precondition or invariant it challenges.
- [ ] **UC-M02.07-C026-T02 · Safe fixture boundary:** Define the contained test boundary for “Console input policy”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M02.07-C026-T03 · Valid control:** Construct a valid “Console input policy” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M02.07-C026-T04 · Minimal adverse input:** Derive the “Console input policy” adverse fixture from the control with the smallest documented change needed to reproduce “An unauthenticated console message invokes a management action”; retain that change as reproducible data.
- [ ] **UC-M02.07-C026-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Console input policy”; require “Console input cannot bypass the workload's command or identity contract” and forbid a false-success verdict.
- [ ] **UC-M02.07-C026-T06 · Adverse execution:** Exercise the “Console input policy” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M02.07-C026-T07 · Effect inspection:** Inspect “Console input policy” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M02.07-C026-T08 · Refusal versus failure:** Confirm the “Console input policy” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M02.07-C026-T09 · Reset and retention:** Restore only the disposable “Console input policy” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M02.07-C026-T10 · Negative regression:** Register the “Console input policy” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M02.07-C027 · Change / failure test

**Original checklist item:** Exercise console input policy when a required device disappears with requests still outstanding; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M02.07-C027-T01 · Scenario record:** Write the “Console input policy” change/failure scenario exactly as supplied: a required device disappears with requests still outstanding; identify the property that must remain true: “Console input cannot bypass the workload's command or identity contract”.
- [ ] **UC-M02.07-C027-T02 · Baseline capture:** Create a known-valid “Console input policy” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M02.07-C027-T03 · Injection map:** Locate the “Console input policy” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M02.07-C027-T04 · Disposition oracle:** Define the legal intermediate and final “Console input policy” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M02.07-C027-T05 · Controlled trigger:** Introduce the controlled “Console input policy” scenario in the disposable fixture: a required device disappears with requests still outstanding; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M02.07-C027-T06 · Intermediate inspection:** Inspect the “Console input policy” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M02.07-C027-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Console input policy”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M02.07-C027-T08 · Stale-evidence cleanup:** Invalidate superseded “Console input policy” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M02.07-C027-T09 · Repeat and compare:** Repeat the selected “Console input policy” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M02.07-C027-T10 · Failure evidence:** Publish the “Console input policy” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M02.07-C028 · Bounds

**Original checklist item:** Choose, document and test limits for input bytes and pending console messages; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M02.07-C028-T01 · Quantity inventory:** Create a measurement inventory for “Console input policy”: “Input bytes and pending console messages”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M02.07-C028-T02 · Measurement method:** Choose how to observe each “Console input policy” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M02.07-C028-T03 · Budget decision:** Select justified resource and input limits for “Console input policy”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M02.07-C028-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Console input policy” cases for “Input bytes and pending console messages”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M02.07-C028-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Console input policy” limit; preserve “Console input cannot bypass the workload's command or identity contract”.
- [ ] **UC-M02.07-C028-T06 · Normal measurement:** Run or review the normal “Console input policy” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M02.07-C028-T07 · At-limit measurement:** Exercise the “Console input policy” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M02.07-C028-T08 · Over-limit measurement:** Exercise the “Console input policy” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M02.07-C028-T09 · Uncovered-scope report:** List the “Console input policy” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M02.07-C028-T10 · Limit evidence:** Publish the selected “Console input policy” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M02.07-C029 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for console input policy with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M02.07-C029-T01 · Event inventory:** List the “Console input policy” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M02.07-C029-T02 · Diagnostic schema:** Define nonsecret fields for “Console input policy” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M02.07-C029-T03 · Failure mapping:** Map each documented “Console input policy” refusal or error to a diagnostic outcome; include “An unauthenticated console message invokes a management action” and prohibit conversion into a success message.
- [ ] **UC-M02.07-C029-T04 · Emission path:** Add the “Console input policy” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M02.07-C029-T05 · Redaction check:** Test “Console input policy” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M02.07-C029-T06 · Output budget:** Set and exercise bounded “Console input policy” message size, rate and retention compatible with “Input bytes and pending console messages”; define truncation behavior that preserves the final reason.
- [ ] **UC-M02.07-C029-T07 · Success/refusal fixtures:** Capture “Console input policy” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M02.07-C029-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Console input policy” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M02.07-C029-T09 · Operator review:** Read the “Console input policy” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M02.07-C029-T10 · Diagnostic evidence:** Publish redacted “Console input policy” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M02.07-C030 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for console input policy; label unexecuted checks as untested.

- [ ] **UC-M02.07-C030-T01 · Evidence inventory:** List the “Console input policy” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M02.07-C030-T02 · Artifact references:** Record the exact “Console input policy” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M02.07-C030-T03 · Fixture references:** Attach the “Console input policy” fixture IDs, input identities and oracle definition; preserve the source counterexample “An unauthenticated console message invokes a management action” as a distinct evidence case.
- [ ] **UC-M02.07-C030-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Console input policy”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M02.07-C030-T05 · Environment record:** Record the actual “Console input policy” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M02.07-C030-T06 · Expected versus observed:** Pair every “Console input policy” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M02.07-C030-T07 · Failure and limit records:** Attach “Console input policy” change/failure and bounds evidence where required; include uncovered “Input bytes and pending console messages” and unresolved violations of “Console input cannot bypass the workload's command or identity contract”.
- [ ] **UC-M02.07-C030-T08 · Evidence hygiene:** Check the “Console input policy” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M02.07-C030-T09 · Reproduction review:** Have the “Console input policy” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M02.07-C030-T10 · Acceptance linkage:** Link the “Console input policy” evidence to its parent and UC-M02.07 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 04. Block geometry validation

**Source delivery:** Validate selected block device capacity, alignment and transfer sizes.

**Source invariant:** A block request stays within the granted device region.

**Source negative case:** A transfer crosses the last permitted block.

**Source bounded quantities:** Device bytes, request size and alignment.

### UC-M02.07-C031 · Contract

**Original checklist item:** Specify block geometry validation inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M02.07-C031-T01 · Scope statement:** Draft the operation boundary for “Block geometry validation” within Minimal console, block and transport drivers; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M02.07-C031-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Block geometry validation”; record each producer, representation and missing-value meaning.
- [ ] **UC-M02.07-C031-T03 · Output inventory:** List the outputs of “Block geometry validation” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M02.07-C031-T04 · Field dictionary:** Create a field-and-term dictionary for “Block geometry validation”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M02.07-C031-T05 · Prerequisite contract:** Map “Block geometry validation” to the source component prerequisites (UC-M02.02, UC-M02.04); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M02.07-C031-T06 · Authority map:** Identify who may produce, change and consume “Block geometry validation”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M02.07-C031-T07 · Invariant clause:** Add a normative clause for “Block geometry validation” that preserves “A block request stays within the granted device region”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M02.07-C031-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Block geometry validation”; include the source counterexample “A transfer crosses the last permitted block” and the intended safe disposition.
- [ ] **UC-M02.07-C031-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Device bytes, request size and alignment” in the “Block geometry validation” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M02.07-C031-T10 · Contract review:** Review the “Block geometry validation” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M02.07-C032 · Delivery

**Original checklist item:** Validate selected block device capacity, alignment and transfer sizes.

- [ ] **UC-M02.07-C032-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Block geometry validation”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M02.07-C032-T02 · Change plan:** Break the source delivery for “Block geometry validation” into concrete edit targets and reviewable outputs; keep the UC-M02.07 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M02.07-C032-T03 · Core artifact:** Implement the smallest selected-profile change for “Block geometry validation” that realizes this source instruction: Validate selected block device capacity, alignment and transfer sizes.
- [ ] **UC-M02.07-C032-T04 · Concrete realization:** Trace “Block geometry validation” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M02.07-C032-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Block geometry validation” needed to preserve “A block request stays within the granted device region”; record an enforcement gap where only a model exists.
- [ ] **UC-M02.07-C032-T06 · Dependency connection:** Connect the “Block geometry validation” implementation to selected guest devices, validated descriptors and host resource ownership; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M02.07-C032-T07 · Resource behavior:** Account for “Device bytes, request size and alignment” in “Block geometry validation”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M02.07-C032-T08 · Delivery check:** Run the smallest real “Block geometry validation” path and its adverse fixture “A transfer crosses the last permitted block”; retain actual output, state effects and final disposition.
- [ ] **UC-M02.07-C032-T09 · Patch review:** Review the “Block geometry validation” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M02.07-C032-T10 · Delivery handoff:** Publish the “Block geometry validation” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M02.07-C033 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: A block request stays within the granted device region. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M02.07-C033-T01 · Named property:** Create a stable property/check name under this parent for “Block geometry validation”; copy its required invariant exactly: “A block request stays within the granted device region”.
- [ ] **UC-M02.07-C033-T02 · Observable terms:** Define each term in the “Block geometry validation” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M02.07-C033-T03 · Precondition set:** List the preconditions under which “A block request stays within the granted device region” must hold for “Block geometry validation”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M02.07-C033-T04 · Transition coverage:** Map the “Block geometry validation” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M02.07-C033-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Block geometry validation”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M02.07-C033-T06 · Satisfying fixture:** Create a concrete “Block geometry validation” case that satisfies “A block request stays within the granted device region”; record its expected observation before running the assertion or review.
- [ ] **UC-M02.07-C033-T07 · Violating fixture:** Create the source counterexample “A transfer crosses the last permitted block” for “Block geometry validation”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M02.07-C033-T08 · Enforcement evidence:** Exercise the “Block geometry validation” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M02.07-C033-T09 · Regression linkage:** Link the “Block geometry validation” property to changes in selected guest devices, validated descriptors and host resource ownership; record which dependency or contract changes require rerunning it.
- [ ] **UC-M02.07-C033-T10 · Property disposition:** Compare the satisfying and violating “Block geometry validation” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M02.07-C034 · Integration

**Original checklist item:** Integrate block geometry validation with selected guest devices, validated descriptors and host resource ownership; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M02.07-C034-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Block geometry validation” across selected guest devices, validated descriptors and host resource ownership; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M02.07-C034-T02 · Field mapping:** Map every “Block geometry validation” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M02.07-C034-T03 · Prerequisite identities:** Record the actual prerequisites for “Block geometry validation” (source dependency list: UC-M02.02, UC-M02.04); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M02.07-C034-T04 · Ownership agreement:** Specify who owns “Block geometry validation” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M02.07-C034-T05 · Handoff implementation:** Connect “Block geometry validation” through the mapped seam using the real adapter or explicit specification reference; preserve “A block request stays within the granted device region” across the handoff.
- [ ] **UC-M02.07-C034-T06 · Absent-input case:** Omit one required “Block geometry validation” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M02.07-C034-T07 · Stale-input case:** Supply an outdated “Block geometry validation” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M02.07-C034-T08 · Incompatible-input case:** Supply an incompatible “Block geometry validation” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M02.07-C034-T09 · Valid integration trace:** Run a valid “Block geometry validation” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M02.07-C034-T10 · Seam review:** Reconcile the “Block geometry validation” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M02.07-C035 · Valid-case test

**Original checklist item:** Run a valid-path fixture for block geometry validation; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M02.07-C035-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Block geometry validation” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M02.07-C035-T02 · Expected-result oracle:** Specify the “Block geometry validation” expected result independently of the implementation output; include the property “A block request stays within the granted device region” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M02.07-C035-T03 · Fixture material:** Create the concrete “Block geometry validation” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M02.07-C035-T04 · Target preparation:** Prepare the “Block geometry validation” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M02.07-C035-T05 · Initial-state record:** Record the initial “Block geometry validation” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M02.07-C035-T06 · Valid-path execution:** Execute the “Block geometry validation” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M02.07-C035-T07 · Outcome comparison:** Compare every declared “Block geometry validation” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M02.07-C035-T08 · State and bounds check:** Inspect the “Block geometry validation” ownership/state effects and actual use of “Device bytes, request size and alignment”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M02.07-C035-T09 · Repeatability check:** Repeat the same “Block geometry validation” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M02.07-C035-T10 · Positive evidence:** Attach the “Block geometry validation” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M02.07-C036 · Negative test

**Original checklist item:** Negative case: A transfer crosses the last permitted block. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M02.07-C036-T01 · Adverse-case definition:** Create a test record for the exact “Block geometry validation” source counterexample: “A transfer crosses the last permitted block”; state which precondition or invariant it challenges.
- [ ] **UC-M02.07-C036-T02 · Safe fixture boundary:** Define the contained test boundary for “Block geometry validation”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M02.07-C036-T03 · Valid control:** Construct a valid “Block geometry validation” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M02.07-C036-T04 · Minimal adverse input:** Derive the “Block geometry validation” adverse fixture from the control with the smallest documented change needed to reproduce “A transfer crosses the last permitted block”; retain that change as reproducible data.
- [ ] **UC-M02.07-C036-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Block geometry validation”; require “A block request stays within the granted device region” and forbid a false-success verdict.
- [ ] **UC-M02.07-C036-T06 · Adverse execution:** Exercise the “Block geometry validation” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M02.07-C036-T07 · Effect inspection:** Inspect “Block geometry validation” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M02.07-C036-T08 · Refusal versus failure:** Confirm the “Block geometry validation” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M02.07-C036-T09 · Reset and retention:** Restore only the disposable “Block geometry validation” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M02.07-C036-T10 · Negative regression:** Register the “Block geometry validation” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M02.07-C037 · Change / failure test

**Original checklist item:** Exercise block geometry validation when a required device disappears with requests still outstanding; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M02.07-C037-T01 · Scenario record:** Write the “Block geometry validation” change/failure scenario exactly as supplied: a required device disappears with requests still outstanding; identify the property that must remain true: “A block request stays within the granted device region”.
- [ ] **UC-M02.07-C037-T02 · Baseline capture:** Create a known-valid “Block geometry validation” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M02.07-C037-T03 · Injection map:** Locate the “Block geometry validation” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M02.07-C037-T04 · Disposition oracle:** Define the legal intermediate and final “Block geometry validation” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M02.07-C037-T05 · Controlled trigger:** Introduce the controlled “Block geometry validation” scenario in the disposable fixture: a required device disappears with requests still outstanding; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M02.07-C037-T06 · Intermediate inspection:** Inspect the “Block geometry validation” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M02.07-C037-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Block geometry validation”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M02.07-C037-T08 · Stale-evidence cleanup:** Invalidate superseded “Block geometry validation” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M02.07-C037-T09 · Repeat and compare:** Repeat the selected “Block geometry validation” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M02.07-C037-T10 · Failure evidence:** Publish the “Block geometry validation” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M02.07-C038 · Bounds

**Original checklist item:** Choose, document and test limits for device bytes, request size and alignment; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M02.07-C038-T01 · Quantity inventory:** Create a measurement inventory for “Block geometry validation”: “Device bytes, request size and alignment”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M02.07-C038-T02 · Measurement method:** Choose how to observe each “Block geometry validation” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M02.07-C038-T03 · Budget decision:** Select justified resource and input limits for “Block geometry validation”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M02.07-C038-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Block geometry validation” cases for “Device bytes, request size and alignment”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M02.07-C038-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Block geometry validation” limit; preserve “A block request stays within the granted device region”.
- [ ] **UC-M02.07-C038-T06 · Normal measurement:** Run or review the normal “Block geometry validation” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M02.07-C038-T07 · At-limit measurement:** Exercise the “Block geometry validation” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M02.07-C038-T08 · Over-limit measurement:** Exercise the “Block geometry validation” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M02.07-C038-T09 · Uncovered-scope report:** List the “Block geometry validation” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M02.07-C038-T10 · Limit evidence:** Publish the selected “Block geometry validation” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M02.07-C039 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for block geometry validation with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M02.07-C039-T01 · Event inventory:** List the “Block geometry validation” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M02.07-C039-T02 · Diagnostic schema:** Define nonsecret fields for “Block geometry validation” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M02.07-C039-T03 · Failure mapping:** Map each documented “Block geometry validation” refusal or error to a diagnostic outcome; include “A transfer crosses the last permitted block” and prohibit conversion into a success message.
- [ ] **UC-M02.07-C039-T04 · Emission path:** Add the “Block geometry validation” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M02.07-C039-T05 · Redaction check:** Test “Block geometry validation” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M02.07-C039-T06 · Output budget:** Set and exercise bounded “Block geometry validation” message size, rate and retention compatible with “Device bytes, request size and alignment”; define truncation behavior that preserves the final reason.
- [ ] **UC-M02.07-C039-T07 · Success/refusal fixtures:** Capture “Block geometry validation” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M02.07-C039-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Block geometry validation” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M02.07-C039-T09 · Operator review:** Read the “Block geometry validation” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M02.07-C039-T10 · Diagnostic evidence:** Publish redacted “Block geometry validation” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M02.07-C040 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for block geometry validation; label unexecuted checks as untested.

- [ ] **UC-M02.07-C040-T01 · Evidence inventory:** List the “Block geometry validation” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M02.07-C040-T02 · Artifact references:** Record the exact “Block geometry validation” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M02.07-C040-T03 · Fixture references:** Attach the “Block geometry validation” fixture IDs, input identities and oracle definition; preserve the source counterexample “A transfer crosses the last permitted block” as a distinct evidence case.
- [ ] **UC-M02.07-C040-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Block geometry validation”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M02.07-C040-T05 · Environment record:** Record the actual “Block geometry validation” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M02.07-C040-T06 · Expected versus observed:** Pair every “Block geometry validation” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M02.07-C040-T07 · Failure and limit records:** Attach “Block geometry validation” change/failure and bounds evidence where required; include uncovered “Device bytes, request size and alignment” and unresolved violations of “A block request stays within the granted device region”.
- [ ] **UC-M02.07-C040-T08 · Evidence hygiene:** Check the “Block geometry validation” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M02.07-C040-T09 · Reproduction review:** Have the “Block geometry validation” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M02.07-C040-T10 · Acceptance linkage:** Link the “Block geometry validation” evidence to its parent and UC-M02.07 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 05. Block request lifecycle

**Source delivery:** Track accepted, completed, canceled and failed block requests.

**Source invariant:** One request cannot complete twice or outlive its valid guest generation.

**Source negative case:** A delayed completion arrives after guest stop.

**Source bounded quantities:** Outstanding requests and completion deadlines.

### UC-M02.07-C041 · Contract

**Original checklist item:** Specify block request lifecycle inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M02.07-C041-T01 · Scope statement:** Draft the operation boundary for “Block request lifecycle” within Minimal console, block and transport drivers; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M02.07-C041-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Block request lifecycle”; record each producer, representation and missing-value meaning.
- [ ] **UC-M02.07-C041-T03 · Output inventory:** List the outputs of “Block request lifecycle” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M02.07-C041-T04 · Field dictionary:** Create a field-and-term dictionary for “Block request lifecycle”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M02.07-C041-T05 · Prerequisite contract:** Map “Block request lifecycle” to the source component prerequisites (UC-M02.02, UC-M02.04); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M02.07-C041-T06 · Authority map:** Identify who may produce, change and consume “Block request lifecycle”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M02.07-C041-T07 · Invariant clause:** Add a normative clause for “Block request lifecycle” that preserves “One request cannot complete twice or outlive its valid guest generation”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M02.07-C041-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Block request lifecycle”; include the source counterexample “A delayed completion arrives after guest stop” and the intended safe disposition.
- [ ] **UC-M02.07-C041-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Outstanding requests and completion deadlines” in the “Block request lifecycle” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M02.07-C041-T10 · Contract review:** Review the “Block request lifecycle” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M02.07-C042 · Delivery

**Original checklist item:** Track accepted, completed, canceled and failed block requests.

- [ ] **UC-M02.07-C042-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Block request lifecycle”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M02.07-C042-T02 · Change plan:** Break the source delivery for “Block request lifecycle” into concrete edit targets and reviewable outputs; keep the UC-M02.07 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M02.07-C042-T03 · Core artifact:** Implement the smallest selected-profile change for “Block request lifecycle” that realizes this source instruction: Track accepted, completed, canceled and failed block requests.
- [ ] **UC-M02.07-C042-T04 · Concrete realization:** Trace “Block request lifecycle” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M02.07-C042-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Block request lifecycle” needed to preserve “One request cannot complete twice or outlive its valid guest generation”; record an enforcement gap where only a model exists.
- [ ] **UC-M02.07-C042-T06 · Dependency connection:** Connect the “Block request lifecycle” implementation to selected guest devices, validated descriptors and host resource ownership; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M02.07-C042-T07 · Resource behavior:** Account for “Outstanding requests and completion deadlines” in “Block request lifecycle”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M02.07-C042-T08 · Delivery check:** Run the smallest real “Block request lifecycle” path and its adverse fixture “A delayed completion arrives after guest stop”; retain actual output, state effects and final disposition.
- [ ] **UC-M02.07-C042-T09 · Patch review:** Review the “Block request lifecycle” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M02.07-C042-T10 · Delivery handoff:** Publish the “Block request lifecycle” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M02.07-C043 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: One request cannot complete twice or outlive its valid guest generation. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M02.07-C043-T01 · Named property:** Create a stable property/check name under this parent for “Block request lifecycle”; copy its required invariant exactly: “One request cannot complete twice or outlive its valid guest generation”.
- [ ] **UC-M02.07-C043-T02 · Observable terms:** Define each term in the “Block request lifecycle” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M02.07-C043-T03 · Precondition set:** List the preconditions under which “One request cannot complete twice or outlive its valid guest generation” must hold for “Block request lifecycle”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M02.07-C043-T04 · Transition coverage:** Map the “Block request lifecycle” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M02.07-C043-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Block request lifecycle”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M02.07-C043-T06 · Satisfying fixture:** Create a concrete “Block request lifecycle” case that satisfies “One request cannot complete twice or outlive its valid guest generation”; record its expected observation before running the assertion or review.
- [ ] **UC-M02.07-C043-T07 · Violating fixture:** Create the source counterexample “A delayed completion arrives after guest stop” for “Block request lifecycle”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M02.07-C043-T08 · Enforcement evidence:** Exercise the “Block request lifecycle” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M02.07-C043-T09 · Regression linkage:** Link the “Block request lifecycle” property to changes in selected guest devices, validated descriptors and host resource ownership; record which dependency or contract changes require rerunning it.
- [ ] **UC-M02.07-C043-T10 · Property disposition:** Compare the satisfying and violating “Block request lifecycle” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M02.07-C044 · Integration

**Original checklist item:** Integrate block request lifecycle with selected guest devices, validated descriptors and host resource ownership; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M02.07-C044-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Block request lifecycle” across selected guest devices, validated descriptors and host resource ownership; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M02.07-C044-T02 · Field mapping:** Map every “Block request lifecycle” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M02.07-C044-T03 · Prerequisite identities:** Record the actual prerequisites for “Block request lifecycle” (source dependency list: UC-M02.02, UC-M02.04); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M02.07-C044-T04 · Ownership agreement:** Specify who owns “Block request lifecycle” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M02.07-C044-T05 · Handoff implementation:** Connect “Block request lifecycle” through the mapped seam using the real adapter or explicit specification reference; preserve “One request cannot complete twice or outlive its valid guest generation” across the handoff.
- [ ] **UC-M02.07-C044-T06 · Absent-input case:** Omit one required “Block request lifecycle” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M02.07-C044-T07 · Stale-input case:** Supply an outdated “Block request lifecycle” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M02.07-C044-T08 · Incompatible-input case:** Supply an incompatible “Block request lifecycle” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M02.07-C044-T09 · Valid integration trace:** Run a valid “Block request lifecycle” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M02.07-C044-T10 · Seam review:** Reconcile the “Block request lifecycle” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M02.07-C045 · Valid-case test

**Original checklist item:** Run a valid-path fixture for block request lifecycle; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M02.07-C045-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Block request lifecycle” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M02.07-C045-T02 · Expected-result oracle:** Specify the “Block request lifecycle” expected result independently of the implementation output; include the property “One request cannot complete twice or outlive its valid guest generation” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M02.07-C045-T03 · Fixture material:** Create the concrete “Block request lifecycle” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M02.07-C045-T04 · Target preparation:** Prepare the “Block request lifecycle” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M02.07-C045-T05 · Initial-state record:** Record the initial “Block request lifecycle” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M02.07-C045-T06 · Valid-path execution:** Execute the “Block request lifecycle” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M02.07-C045-T07 · Outcome comparison:** Compare every declared “Block request lifecycle” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M02.07-C045-T08 · State and bounds check:** Inspect the “Block request lifecycle” ownership/state effects and actual use of “Outstanding requests and completion deadlines”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M02.07-C045-T09 · Repeatability check:** Repeat the same “Block request lifecycle” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M02.07-C045-T10 · Positive evidence:** Attach the “Block request lifecycle” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M02.07-C046 · Negative test

**Original checklist item:** Negative case: A delayed completion arrives after guest stop. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M02.07-C046-T01 · Adverse-case definition:** Create a test record for the exact “Block request lifecycle” source counterexample: “A delayed completion arrives after guest stop”; state which precondition or invariant it challenges.
- [ ] **UC-M02.07-C046-T02 · Safe fixture boundary:** Define the contained test boundary for “Block request lifecycle”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M02.07-C046-T03 · Valid control:** Construct a valid “Block request lifecycle” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M02.07-C046-T04 · Minimal adverse input:** Derive the “Block request lifecycle” adverse fixture from the control with the smallest documented change needed to reproduce “A delayed completion arrives after guest stop”; retain that change as reproducible data.
- [ ] **UC-M02.07-C046-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Block request lifecycle”; require “One request cannot complete twice or outlive its valid guest generation” and forbid a false-success verdict.
- [ ] **UC-M02.07-C046-T06 · Adverse execution:** Exercise the “Block request lifecycle” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M02.07-C046-T07 · Effect inspection:** Inspect “Block request lifecycle” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M02.07-C046-T08 · Refusal versus failure:** Confirm the “Block request lifecycle” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M02.07-C046-T09 · Reset and retention:** Restore only the disposable “Block request lifecycle” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M02.07-C046-T10 · Negative regression:** Register the “Block request lifecycle” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M02.07-C047 · Change / failure test

**Original checklist item:** Exercise block request lifecycle when a required device disappears with requests still outstanding; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M02.07-C047-T01 · Scenario record:** Write the “Block request lifecycle” change/failure scenario exactly as supplied: a required device disappears with requests still outstanding; identify the property that must remain true: “One request cannot complete twice or outlive its valid guest generation”.
- [ ] **UC-M02.07-C047-T02 · Baseline capture:** Create a known-valid “Block request lifecycle” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M02.07-C047-T03 · Injection map:** Locate the “Block request lifecycle” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M02.07-C047-T04 · Disposition oracle:** Define the legal intermediate and final “Block request lifecycle” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M02.07-C047-T05 · Controlled trigger:** Introduce the controlled “Block request lifecycle” scenario in the disposable fixture: a required device disappears with requests still outstanding; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M02.07-C047-T06 · Intermediate inspection:** Inspect the “Block request lifecycle” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M02.07-C047-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Block request lifecycle”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M02.07-C047-T08 · Stale-evidence cleanup:** Invalidate superseded “Block request lifecycle” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M02.07-C047-T09 · Repeat and compare:** Repeat the selected “Block request lifecycle” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M02.07-C047-T10 · Failure evidence:** Publish the “Block request lifecycle” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M02.07-C048 · Bounds

**Original checklist item:** Choose, document and test limits for outstanding requests and completion deadlines; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M02.07-C048-T01 · Quantity inventory:** Create a measurement inventory for “Block request lifecycle”: “Outstanding requests and completion deadlines”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M02.07-C048-T02 · Measurement method:** Choose how to observe each “Block request lifecycle” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M02.07-C048-T03 · Budget decision:** Select justified resource and input limits for “Block request lifecycle”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M02.07-C048-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Block request lifecycle” cases for “Outstanding requests and completion deadlines”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M02.07-C048-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Block request lifecycle” limit; preserve “One request cannot complete twice or outlive its valid guest generation”.
- [ ] **UC-M02.07-C048-T06 · Normal measurement:** Run or review the normal “Block request lifecycle” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M02.07-C048-T07 · At-limit measurement:** Exercise the “Block request lifecycle” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M02.07-C048-T08 · Over-limit measurement:** Exercise the “Block request lifecycle” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M02.07-C048-T09 · Uncovered-scope report:** List the “Block request lifecycle” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M02.07-C048-T10 · Limit evidence:** Publish the selected “Block request lifecycle” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M02.07-C049 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for block request lifecycle with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M02.07-C049-T01 · Event inventory:** List the “Block request lifecycle” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M02.07-C049-T02 · Diagnostic schema:** Define nonsecret fields for “Block request lifecycle” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M02.07-C049-T03 · Failure mapping:** Map each documented “Block request lifecycle” refusal or error to a diagnostic outcome; include “A delayed completion arrives after guest stop” and prohibit conversion into a success message.
- [ ] **UC-M02.07-C049-T04 · Emission path:** Add the “Block request lifecycle” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M02.07-C049-T05 · Redaction check:** Test “Block request lifecycle” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M02.07-C049-T06 · Output budget:** Set and exercise bounded “Block request lifecycle” message size, rate and retention compatible with “Outstanding requests and completion deadlines”; define truncation behavior that preserves the final reason.
- [ ] **UC-M02.07-C049-T07 · Success/refusal fixtures:** Capture “Block request lifecycle” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M02.07-C049-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Block request lifecycle” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M02.07-C049-T09 · Operator review:** Read the “Block request lifecycle” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M02.07-C049-T10 · Diagnostic evidence:** Publish redacted “Block request lifecycle” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M02.07-C050 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for block request lifecycle; label unexecuted checks as untested.

- [ ] **UC-M02.07-C050-T01 · Evidence inventory:** List the “Block request lifecycle” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M02.07-C050-T02 · Artifact references:** Record the exact “Block request lifecycle” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M02.07-C050-T03 · Fixture references:** Attach the “Block request lifecycle” fixture IDs, input identities and oracle definition; preserve the source counterexample “A delayed completion arrives after guest stop” as a distinct evidence case.
- [ ] **UC-M02.07-C050-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Block request lifecycle”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M02.07-C050-T05 · Environment record:** Record the actual “Block request lifecycle” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M02.07-C050-T06 · Expected versus observed:** Pair every “Block request lifecycle” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M02.07-C050-T07 · Failure and limit records:** Attach “Block request lifecycle” change/failure and bounds evidence where required; include uncovered “Outstanding requests and completion deadlines” and unresolved violations of “One request cannot complete twice or outlive its valid guest generation”.
- [ ] **UC-M02.07-C050-T08 · Evidence hygiene:** Check the “Block request lifecycle” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M02.07-C050-T09 · Reproduction review:** Have the “Block request lifecycle” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M02.07-C050-T10 · Acceptance linkage:** Link the “Block request lifecycle” evidence to its parent and UC-M02.07 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 06. Descriptor parsing

**Source delivery:** Validate descriptor lengths, indices, chains and ownership before use.

**Source invariant:** Malformed descriptors cannot address arbitrary host or guest memory.

**Source negative case:** A descriptor chain loops or references an invalid entry.

**Source bounded quantities:** Descriptor count and chain length.

### UC-M02.07-C051 · Contract

**Original checklist item:** Specify descriptor parsing inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M02.07-C051-T01 · Scope statement:** Draft the operation boundary for “Descriptor parsing” within Minimal console, block and transport drivers; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M02.07-C051-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Descriptor parsing”; record each producer, representation and missing-value meaning.
- [ ] **UC-M02.07-C051-T03 · Output inventory:** List the outputs of “Descriptor parsing” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M02.07-C051-T04 · Field dictionary:** Create a field-and-term dictionary for “Descriptor parsing”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M02.07-C051-T05 · Prerequisite contract:** Map “Descriptor parsing” to the source component prerequisites (UC-M02.02, UC-M02.04); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M02.07-C051-T06 · Authority map:** Identify who may produce, change and consume “Descriptor parsing”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M02.07-C051-T07 · Invariant clause:** Add a normative clause for “Descriptor parsing” that preserves “Malformed descriptors cannot address arbitrary host or guest memory”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M02.07-C051-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Descriptor parsing”; include the source counterexample “A descriptor chain loops or references an invalid entry” and the intended safe disposition.
- [ ] **UC-M02.07-C051-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Descriptor count and chain length” in the “Descriptor parsing” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M02.07-C051-T10 · Contract review:** Review the “Descriptor parsing” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M02.07-C052 · Delivery

**Original checklist item:** Validate descriptor lengths, indices, chains and ownership before use.

- [ ] **UC-M02.07-C052-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Descriptor parsing”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M02.07-C052-T02 · Change plan:** Break the source delivery for “Descriptor parsing” into concrete edit targets and reviewable outputs; keep the UC-M02.07 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M02.07-C052-T03 · Core artifact:** Implement the smallest selected-profile change for “Descriptor parsing” that realizes this source instruction: Validate descriptor lengths, indices, chains and ownership before use.
- [ ] **UC-M02.07-C052-T04 · Concrete realization:** Trace “Descriptor parsing” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M02.07-C052-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Descriptor parsing” needed to preserve “Malformed descriptors cannot address arbitrary host or guest memory”; record an enforcement gap where only a model exists.
- [ ] **UC-M02.07-C052-T06 · Dependency connection:** Connect the “Descriptor parsing” implementation to selected guest devices, validated descriptors and host resource ownership; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M02.07-C052-T07 · Resource behavior:** Account for “Descriptor count and chain length” in “Descriptor parsing”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M02.07-C052-T08 · Delivery check:** Run the smallest real “Descriptor parsing” path and its adverse fixture “A descriptor chain loops or references an invalid entry”; retain actual output, state effects and final disposition.
- [ ] **UC-M02.07-C052-T09 · Patch review:** Review the “Descriptor parsing” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M02.07-C052-T10 · Delivery handoff:** Publish the “Descriptor parsing” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M02.07-C053 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Malformed descriptors cannot address arbitrary host or guest memory. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M02.07-C053-T01 · Named property:** Create a stable property/check name under this parent for “Descriptor parsing”; copy its required invariant exactly: “Malformed descriptors cannot address arbitrary host or guest memory”.
- [ ] **UC-M02.07-C053-T02 · Observable terms:** Define each term in the “Descriptor parsing” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M02.07-C053-T03 · Precondition set:** List the preconditions under which “Malformed descriptors cannot address arbitrary host or guest memory” must hold for “Descriptor parsing”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M02.07-C053-T04 · Transition coverage:** Map the “Descriptor parsing” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M02.07-C053-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Descriptor parsing”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M02.07-C053-T06 · Satisfying fixture:** Create a concrete “Descriptor parsing” case that satisfies “Malformed descriptors cannot address arbitrary host or guest memory”; record its expected observation before running the assertion or review.
- [ ] **UC-M02.07-C053-T07 · Violating fixture:** Create the source counterexample “A descriptor chain loops or references an invalid entry” for “Descriptor parsing”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M02.07-C053-T08 · Enforcement evidence:** Exercise the “Descriptor parsing” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M02.07-C053-T09 · Regression linkage:** Link the “Descriptor parsing” property to changes in selected guest devices, validated descriptors and host resource ownership; record which dependency or contract changes require rerunning it.
- [ ] **UC-M02.07-C053-T10 · Property disposition:** Compare the satisfying and violating “Descriptor parsing” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M02.07-C054 · Integration

**Original checklist item:** Integrate descriptor parsing with selected guest devices, validated descriptors and host resource ownership; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M02.07-C054-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Descriptor parsing” across selected guest devices, validated descriptors and host resource ownership; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M02.07-C054-T02 · Field mapping:** Map every “Descriptor parsing” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M02.07-C054-T03 · Prerequisite identities:** Record the actual prerequisites for “Descriptor parsing” (source dependency list: UC-M02.02, UC-M02.04); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M02.07-C054-T04 · Ownership agreement:** Specify who owns “Descriptor parsing” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M02.07-C054-T05 · Handoff implementation:** Connect “Descriptor parsing” through the mapped seam using the real adapter or explicit specification reference; preserve “Malformed descriptors cannot address arbitrary host or guest memory” across the handoff.
- [ ] **UC-M02.07-C054-T06 · Absent-input case:** Omit one required “Descriptor parsing” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M02.07-C054-T07 · Stale-input case:** Supply an outdated “Descriptor parsing” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M02.07-C054-T08 · Incompatible-input case:** Supply an incompatible “Descriptor parsing” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M02.07-C054-T09 · Valid integration trace:** Run a valid “Descriptor parsing” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M02.07-C054-T10 · Seam review:** Reconcile the “Descriptor parsing” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M02.07-C055 · Valid-case test

**Original checklist item:** Run a valid-path fixture for descriptor parsing; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M02.07-C055-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Descriptor parsing” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M02.07-C055-T02 · Expected-result oracle:** Specify the “Descriptor parsing” expected result independently of the implementation output; include the property “Malformed descriptors cannot address arbitrary host or guest memory” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M02.07-C055-T03 · Fixture material:** Create the concrete “Descriptor parsing” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M02.07-C055-T04 · Target preparation:** Prepare the “Descriptor parsing” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M02.07-C055-T05 · Initial-state record:** Record the initial “Descriptor parsing” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M02.07-C055-T06 · Valid-path execution:** Execute the “Descriptor parsing” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M02.07-C055-T07 · Outcome comparison:** Compare every declared “Descriptor parsing” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M02.07-C055-T08 · State and bounds check:** Inspect the “Descriptor parsing” ownership/state effects and actual use of “Descriptor count and chain length”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M02.07-C055-T09 · Repeatability check:** Repeat the same “Descriptor parsing” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M02.07-C055-T10 · Positive evidence:** Attach the “Descriptor parsing” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M02.07-C056 · Negative test

**Original checklist item:** Negative case: A descriptor chain loops or references an invalid entry. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M02.07-C056-T01 · Adverse-case definition:** Create a test record for the exact “Descriptor parsing” source counterexample: “A descriptor chain loops or references an invalid entry”; state which precondition or invariant it challenges.
- [ ] **UC-M02.07-C056-T02 · Safe fixture boundary:** Define the contained test boundary for “Descriptor parsing”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M02.07-C056-T03 · Valid control:** Construct a valid “Descriptor parsing” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M02.07-C056-T04 · Minimal adverse input:** Derive the “Descriptor parsing” adverse fixture from the control with the smallest documented change needed to reproduce “A descriptor chain loops or references an invalid entry”; retain that change as reproducible data.
- [ ] **UC-M02.07-C056-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Descriptor parsing”; require “Malformed descriptors cannot address arbitrary host or guest memory” and forbid a false-success verdict.
- [ ] **UC-M02.07-C056-T06 · Adverse execution:** Exercise the “Descriptor parsing” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M02.07-C056-T07 · Effect inspection:** Inspect “Descriptor parsing” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M02.07-C056-T08 · Refusal versus failure:** Confirm the “Descriptor parsing” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M02.07-C056-T09 · Reset and retention:** Restore only the disposable “Descriptor parsing” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M02.07-C056-T10 · Negative regression:** Register the “Descriptor parsing” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M02.07-C057 · Change / failure test

**Original checklist item:** Exercise descriptor parsing when a required device disappears with requests still outstanding; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M02.07-C057-T01 · Scenario record:** Write the “Descriptor parsing” change/failure scenario exactly as supplied: a required device disappears with requests still outstanding; identify the property that must remain true: “Malformed descriptors cannot address arbitrary host or guest memory”.
- [ ] **UC-M02.07-C057-T02 · Baseline capture:** Create a known-valid “Descriptor parsing” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M02.07-C057-T03 · Injection map:** Locate the “Descriptor parsing” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M02.07-C057-T04 · Disposition oracle:** Define the legal intermediate and final “Descriptor parsing” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M02.07-C057-T05 · Controlled trigger:** Introduce the controlled “Descriptor parsing” scenario in the disposable fixture: a required device disappears with requests still outstanding; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M02.07-C057-T06 · Intermediate inspection:** Inspect the “Descriptor parsing” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M02.07-C057-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Descriptor parsing”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M02.07-C057-T08 · Stale-evidence cleanup:** Invalidate superseded “Descriptor parsing” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M02.07-C057-T09 · Repeat and compare:** Repeat the selected “Descriptor parsing” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M02.07-C057-T10 · Failure evidence:** Publish the “Descriptor parsing” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M02.07-C058 · Bounds

**Original checklist item:** Choose, document and test limits for descriptor count and chain length; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M02.07-C058-T01 · Quantity inventory:** Create a measurement inventory for “Descriptor parsing”: “Descriptor count and chain length”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M02.07-C058-T02 · Measurement method:** Choose how to observe each “Descriptor parsing” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M02.07-C058-T03 · Budget decision:** Select justified resource and input limits for “Descriptor parsing”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M02.07-C058-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Descriptor parsing” cases for “Descriptor count and chain length”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M02.07-C058-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Descriptor parsing” limit; preserve “Malformed descriptors cannot address arbitrary host or guest memory”.
- [ ] **UC-M02.07-C058-T06 · Normal measurement:** Run or review the normal “Descriptor parsing” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M02.07-C058-T07 · At-limit measurement:** Exercise the “Descriptor parsing” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M02.07-C058-T08 · Over-limit measurement:** Exercise the “Descriptor parsing” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M02.07-C058-T09 · Uncovered-scope report:** List the “Descriptor parsing” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M02.07-C058-T10 · Limit evidence:** Publish the selected “Descriptor parsing” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M02.07-C059 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for descriptor parsing with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M02.07-C059-T01 · Event inventory:** List the “Descriptor parsing” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M02.07-C059-T02 · Diagnostic schema:** Define nonsecret fields for “Descriptor parsing” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M02.07-C059-T03 · Failure mapping:** Map each documented “Descriptor parsing” refusal or error to a diagnostic outcome; include “A descriptor chain loops or references an invalid entry” and prohibit conversion into a success message.
- [ ] **UC-M02.07-C059-T04 · Emission path:** Add the “Descriptor parsing” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M02.07-C059-T05 · Redaction check:** Test “Descriptor parsing” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M02.07-C059-T06 · Output budget:** Set and exercise bounded “Descriptor parsing” message size, rate and retention compatible with “Descriptor count and chain length”; define truncation behavior that preserves the final reason.
- [ ] **UC-M02.07-C059-T07 · Success/refusal fixtures:** Capture “Descriptor parsing” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M02.07-C059-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Descriptor parsing” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M02.07-C059-T09 · Operator review:** Read the “Descriptor parsing” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M02.07-C059-T10 · Diagnostic evidence:** Publish redacted “Descriptor parsing” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M02.07-C060 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for descriptor parsing; label unexecuted checks as untested.

- [ ] **UC-M02.07-C060-T01 · Evidence inventory:** List the “Descriptor parsing” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M02.07-C060-T02 · Artifact references:** Record the exact “Descriptor parsing” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M02.07-C060-T03 · Fixture references:** Attach the “Descriptor parsing” fixture IDs, input identities and oracle definition; preserve the source counterexample “A descriptor chain loops or references an invalid entry” as a distinct evidence case.
- [ ] **UC-M02.07-C060-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Descriptor parsing”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M02.07-C060-T05 · Environment record:** Record the actual “Descriptor parsing” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M02.07-C060-T06 · Expected versus observed:** Pair every “Descriptor parsing” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M02.07-C060-T07 · Failure and limit records:** Attach “Descriptor parsing” change/failure and bounds evidence where required; include uncovered “Descriptor count and chain length” and unresolved violations of “Malformed descriptors cannot address arbitrary host or guest memory”.
- [ ] **UC-M02.07-C060-T08 · Evidence hygiene:** Check the “Descriptor parsing” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M02.07-C060-T09 · Reproduction review:** Have the “Descriptor parsing” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M02.07-C060-T10 · Acceptance linkage:** Link the “Descriptor parsing” evidence to its parent and UC-M02.07 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 07. Optional transport adapter

**Source delivery:** Implement transport only when the selected workload profile requires it.

**Source invariant:** Absent transport support is an explicit capability limitation.

**Source negative case:** A workload assumes an unconfigured transport exists.

**Source bounded quantities:** Transport queues and message byte budget.

### UC-M02.07-C061 · Contract

**Original checklist item:** Specify optional transport adapter inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M02.07-C061-T01 · Scope statement:** Draft the operation boundary for “Optional transport adapter” within Minimal console, block and transport drivers; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M02.07-C061-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Optional transport adapter”; record each producer, representation and missing-value meaning.
- [ ] **UC-M02.07-C061-T03 · Output inventory:** List the outputs of “Optional transport adapter” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M02.07-C061-T04 · Field dictionary:** Create a field-and-term dictionary for “Optional transport adapter”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M02.07-C061-T05 · Prerequisite contract:** Map “Optional transport adapter” to the source component prerequisites (UC-M02.02, UC-M02.04); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M02.07-C061-T06 · Authority map:** Identify who may produce, change and consume “Optional transport adapter”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M02.07-C061-T07 · Invariant clause:** Add a normative clause for “Optional transport adapter” that preserves “Absent transport support is an explicit capability limitation”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M02.07-C061-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Optional transport adapter”; include the source counterexample “A workload assumes an unconfigured transport exists” and the intended safe disposition.
- [ ] **UC-M02.07-C061-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Transport queues and message byte budget” in the “Optional transport adapter” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M02.07-C061-T10 · Contract review:** Review the “Optional transport adapter” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M02.07-C062 · Delivery

**Original checklist item:** Implement transport only when the selected workload profile requires it.

- [ ] **UC-M02.07-C062-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Optional transport adapter”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M02.07-C062-T02 · Change plan:** Break the source delivery for “Optional transport adapter” into concrete edit targets and reviewable outputs; keep the UC-M02.07 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M02.07-C062-T03 · Core artifact:** Implement the smallest selected-profile change for “Optional transport adapter” that realizes this source instruction: Implement transport only when the selected workload profile requires it.
- [ ] **UC-M02.07-C062-T04 · Concrete realization:** Trace “Optional transport adapter” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M02.07-C062-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Optional transport adapter” needed to preserve “Absent transport support is an explicit capability limitation”; record an enforcement gap where only a model exists.
- [ ] **UC-M02.07-C062-T06 · Dependency connection:** Connect the “Optional transport adapter” implementation to selected guest devices, validated descriptors and host resource ownership; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M02.07-C062-T07 · Resource behavior:** Account for “Transport queues and message byte budget” in “Optional transport adapter”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M02.07-C062-T08 · Delivery check:** Run the smallest real “Optional transport adapter” path and its adverse fixture “A workload assumes an unconfigured transport exists”; retain actual output, state effects and final disposition.
- [ ] **UC-M02.07-C062-T09 · Patch review:** Review the “Optional transport adapter” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M02.07-C062-T10 · Delivery handoff:** Publish the “Optional transport adapter” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M02.07-C063 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Absent transport support is an explicit capability limitation. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M02.07-C063-T01 · Named property:** Create a stable property/check name under this parent for “Optional transport adapter”; copy its required invariant exactly: “Absent transport support is an explicit capability limitation”.
- [ ] **UC-M02.07-C063-T02 · Observable terms:** Define each term in the “Optional transport adapter” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M02.07-C063-T03 · Precondition set:** List the preconditions under which “Absent transport support is an explicit capability limitation” must hold for “Optional transport adapter”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M02.07-C063-T04 · Transition coverage:** Map the “Optional transport adapter” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M02.07-C063-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Optional transport adapter”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M02.07-C063-T06 · Satisfying fixture:** Create a concrete “Optional transport adapter” case that satisfies “Absent transport support is an explicit capability limitation”; record its expected observation before running the assertion or review.
- [ ] **UC-M02.07-C063-T07 · Violating fixture:** Create the source counterexample “A workload assumes an unconfigured transport exists” for “Optional transport adapter”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M02.07-C063-T08 · Enforcement evidence:** Exercise the “Optional transport adapter” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M02.07-C063-T09 · Regression linkage:** Link the “Optional transport adapter” property to changes in selected guest devices, validated descriptors and host resource ownership; record which dependency or contract changes require rerunning it.
- [ ] **UC-M02.07-C063-T10 · Property disposition:** Compare the satisfying and violating “Optional transport adapter” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M02.07-C064 · Integration

**Original checklist item:** Integrate optional transport adapter with selected guest devices, validated descriptors and host resource ownership; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M02.07-C064-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Optional transport adapter” across selected guest devices, validated descriptors and host resource ownership; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M02.07-C064-T02 · Field mapping:** Map every “Optional transport adapter” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M02.07-C064-T03 · Prerequisite identities:** Record the actual prerequisites for “Optional transport adapter” (source dependency list: UC-M02.02, UC-M02.04); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M02.07-C064-T04 · Ownership agreement:** Specify who owns “Optional transport adapter” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M02.07-C064-T05 · Handoff implementation:** Connect “Optional transport adapter” through the mapped seam using the real adapter or explicit specification reference; preserve “Absent transport support is an explicit capability limitation” across the handoff.
- [ ] **UC-M02.07-C064-T06 · Absent-input case:** Omit one required “Optional transport adapter” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M02.07-C064-T07 · Stale-input case:** Supply an outdated “Optional transport adapter” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M02.07-C064-T08 · Incompatible-input case:** Supply an incompatible “Optional transport adapter” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M02.07-C064-T09 · Valid integration trace:** Run a valid “Optional transport adapter” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M02.07-C064-T10 · Seam review:** Reconcile the “Optional transport adapter” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M02.07-C065 · Valid-case test

**Original checklist item:** Run a valid-path fixture for optional transport adapter; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M02.07-C065-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Optional transport adapter” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M02.07-C065-T02 · Expected-result oracle:** Specify the “Optional transport adapter” expected result independently of the implementation output; include the property “Absent transport support is an explicit capability limitation” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M02.07-C065-T03 · Fixture material:** Create the concrete “Optional transport adapter” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M02.07-C065-T04 · Target preparation:** Prepare the “Optional transport adapter” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M02.07-C065-T05 · Initial-state record:** Record the initial “Optional transport adapter” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M02.07-C065-T06 · Valid-path execution:** Execute the “Optional transport adapter” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M02.07-C065-T07 · Outcome comparison:** Compare every declared “Optional transport adapter” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M02.07-C065-T08 · State and bounds check:** Inspect the “Optional transport adapter” ownership/state effects and actual use of “Transport queues and message byte budget”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M02.07-C065-T09 · Repeatability check:** Repeat the same “Optional transport adapter” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M02.07-C065-T10 · Positive evidence:** Attach the “Optional transport adapter” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M02.07-C066 · Negative test

**Original checklist item:** Negative case: A workload assumes an unconfigured transport exists. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M02.07-C066-T01 · Adverse-case definition:** Create a test record for the exact “Optional transport adapter” source counterexample: “A workload assumes an unconfigured transport exists”; state which precondition or invariant it challenges.
- [ ] **UC-M02.07-C066-T02 · Safe fixture boundary:** Define the contained test boundary for “Optional transport adapter”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M02.07-C066-T03 · Valid control:** Construct a valid “Optional transport adapter” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M02.07-C066-T04 · Minimal adverse input:** Derive the “Optional transport adapter” adverse fixture from the control with the smallest documented change needed to reproduce “A workload assumes an unconfigured transport exists”; retain that change as reproducible data.
- [ ] **UC-M02.07-C066-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Optional transport adapter”; require “Absent transport support is an explicit capability limitation” and forbid a false-success verdict.
- [ ] **UC-M02.07-C066-T06 · Adverse execution:** Exercise the “Optional transport adapter” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M02.07-C066-T07 · Effect inspection:** Inspect “Optional transport adapter” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M02.07-C066-T08 · Refusal versus failure:** Confirm the “Optional transport adapter” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M02.07-C066-T09 · Reset and retention:** Restore only the disposable “Optional transport adapter” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M02.07-C066-T10 · Negative regression:** Register the “Optional transport adapter” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M02.07-C067 · Change / failure test

**Original checklist item:** Exercise optional transport adapter when a required device disappears with requests still outstanding; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M02.07-C067-T01 · Scenario record:** Write the “Optional transport adapter” change/failure scenario exactly as supplied: a required device disappears with requests still outstanding; identify the property that must remain true: “Absent transport support is an explicit capability limitation”.
- [ ] **UC-M02.07-C067-T02 · Baseline capture:** Create a known-valid “Optional transport adapter” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M02.07-C067-T03 · Injection map:** Locate the “Optional transport adapter” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M02.07-C067-T04 · Disposition oracle:** Define the legal intermediate and final “Optional transport adapter” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M02.07-C067-T05 · Controlled trigger:** Introduce the controlled “Optional transport adapter” scenario in the disposable fixture: a required device disappears with requests still outstanding; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M02.07-C067-T06 · Intermediate inspection:** Inspect the “Optional transport adapter” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M02.07-C067-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Optional transport adapter”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M02.07-C067-T08 · Stale-evidence cleanup:** Invalidate superseded “Optional transport adapter” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M02.07-C067-T09 · Repeat and compare:** Repeat the selected “Optional transport adapter” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M02.07-C067-T10 · Failure evidence:** Publish the “Optional transport adapter” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M02.07-C068 · Bounds

**Original checklist item:** Choose, document and test limits for transport queues and message byte budget; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M02.07-C068-T01 · Quantity inventory:** Create a measurement inventory for “Optional transport adapter”: “Transport queues and message byte budget”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M02.07-C068-T02 · Measurement method:** Choose how to observe each “Optional transport adapter” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M02.07-C068-T03 · Budget decision:** Select justified resource and input limits for “Optional transport adapter”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M02.07-C068-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Optional transport adapter” cases for “Transport queues and message byte budget”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M02.07-C068-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Optional transport adapter” limit; preserve “Absent transport support is an explicit capability limitation”.
- [ ] **UC-M02.07-C068-T06 · Normal measurement:** Run or review the normal “Optional transport adapter” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M02.07-C068-T07 · At-limit measurement:** Exercise the “Optional transport adapter” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M02.07-C068-T08 · Over-limit measurement:** Exercise the “Optional transport adapter” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M02.07-C068-T09 · Uncovered-scope report:** List the “Optional transport adapter” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M02.07-C068-T10 · Limit evidence:** Publish the selected “Optional transport adapter” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M02.07-C069 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for optional transport adapter with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M02.07-C069-T01 · Event inventory:** List the “Optional transport adapter” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M02.07-C069-T02 · Diagnostic schema:** Define nonsecret fields for “Optional transport adapter” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M02.07-C069-T03 · Failure mapping:** Map each documented “Optional transport adapter” refusal or error to a diagnostic outcome; include “A workload assumes an unconfigured transport exists” and prohibit conversion into a success message.
- [ ] **UC-M02.07-C069-T04 · Emission path:** Add the “Optional transport adapter” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M02.07-C069-T05 · Redaction check:** Test “Optional transport adapter” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M02.07-C069-T06 · Output budget:** Set and exercise bounded “Optional transport adapter” message size, rate and retention compatible with “Transport queues and message byte budget”; define truncation behavior that preserves the final reason.
- [ ] **UC-M02.07-C069-T07 · Success/refusal fixtures:** Capture “Optional transport adapter” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M02.07-C069-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Optional transport adapter” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M02.07-C069-T09 · Operator review:** Read the “Optional transport adapter” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M02.07-C069-T10 · Diagnostic evidence:** Publish redacted “Optional transport adapter” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M02.07-C070 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for optional transport adapter; label unexecuted checks as untested.

- [ ] **UC-M02.07-C070-T01 · Evidence inventory:** List the “Optional transport adapter” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M02.07-C070-T02 · Artifact references:** Record the exact “Optional transport adapter” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M02.07-C070-T03 · Fixture references:** Attach the “Optional transport adapter” fixture IDs, input identities and oracle definition; preserve the source counterexample “A workload assumes an unconfigured transport exists” as a distinct evidence case.
- [ ] **UC-M02.07-C070-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Optional transport adapter”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M02.07-C070-T05 · Environment record:** Record the actual “Optional transport adapter” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M02.07-C070-T06 · Expected versus observed:** Pair every “Optional transport adapter” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M02.07-C070-T07 · Failure and limit records:** Attach “Optional transport adapter” change/failure and bounds evidence where required; include uncovered “Transport queues and message byte budget” and unresolved violations of “Absent transport support is an explicit capability limitation”.
- [ ] **UC-M02.07-C070-T08 · Evidence hygiene:** Check the “Optional transport adapter” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M02.07-C070-T09 · Reproduction review:** Have the “Optional transport adapter” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M02.07-C070-T10 · Acceptance linkage:** Link the “Optional transport adapter” evidence to its parent and UC-M02.07 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 08. Unavailable-device behavior

**Source delivery:** Return explicit safe failure when a required device is absent or lost.

**Source invariant:** Device absence never becomes a fabricated successful I/O result.

**Source negative case:** A block device disappears during an invocation.

**Source bounded quantities:** Failure propagation time and retry count.

### UC-M02.07-C071 · Contract

**Original checklist item:** Specify unavailable-device behavior inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M02.07-C071-T01 · Scope statement:** Draft the operation boundary for “Unavailable-device behavior” within Minimal console, block and transport drivers; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M02.07-C071-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Unavailable-device behavior”; record each producer, representation and missing-value meaning.
- [ ] **UC-M02.07-C071-T03 · Output inventory:** List the outputs of “Unavailable-device behavior” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M02.07-C071-T04 · Field dictionary:** Create a field-and-term dictionary for “Unavailable-device behavior”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M02.07-C071-T05 · Prerequisite contract:** Map “Unavailable-device behavior” to the source component prerequisites (UC-M02.02, UC-M02.04); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M02.07-C071-T06 · Authority map:** Identify who may produce, change and consume “Unavailable-device behavior”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M02.07-C071-T07 · Invariant clause:** Add a normative clause for “Unavailable-device behavior” that preserves “Device absence never becomes a fabricated successful I/O result”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M02.07-C071-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Unavailable-device behavior”; include the source counterexample “A block device disappears during an invocation” and the intended safe disposition.
- [ ] **UC-M02.07-C071-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Failure propagation time and retry count” in the “Unavailable-device behavior” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M02.07-C071-T10 · Contract review:** Review the “Unavailable-device behavior” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M02.07-C072 · Delivery

**Original checklist item:** Return explicit safe failure when a required device is absent or lost.

- [ ] **UC-M02.07-C072-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Unavailable-device behavior”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M02.07-C072-T02 · Change plan:** Break the source delivery for “Unavailable-device behavior” into concrete edit targets and reviewable outputs; keep the UC-M02.07 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M02.07-C072-T03 · Core artifact:** Implement the smallest selected-profile change for “Unavailable-device behavior” that realizes this source instruction: Return explicit safe failure when a required device is absent or lost.
- [ ] **UC-M02.07-C072-T04 · Concrete realization:** Trace “Unavailable-device behavior” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M02.07-C072-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Unavailable-device behavior” needed to preserve “Device absence never becomes a fabricated successful I/O result”; record an enforcement gap where only a model exists.
- [ ] **UC-M02.07-C072-T06 · Dependency connection:** Connect the “Unavailable-device behavior” implementation to selected guest devices, validated descriptors and host resource ownership; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M02.07-C072-T07 · Resource behavior:** Account for “Failure propagation time and retry count” in “Unavailable-device behavior”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M02.07-C072-T08 · Delivery check:** Run the smallest real “Unavailable-device behavior” path and its adverse fixture “A block device disappears during an invocation”; retain actual output, state effects and final disposition.
- [ ] **UC-M02.07-C072-T09 · Patch review:** Review the “Unavailable-device behavior” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M02.07-C072-T10 · Delivery handoff:** Publish the “Unavailable-device behavior” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M02.07-C073 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Device absence never becomes a fabricated successful I/O result. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M02.07-C073-T01 · Named property:** Create a stable property/check name under this parent for “Unavailable-device behavior”; copy its required invariant exactly: “Device absence never becomes a fabricated successful I/O result”.
- [ ] **UC-M02.07-C073-T02 · Observable terms:** Define each term in the “Unavailable-device behavior” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M02.07-C073-T03 · Precondition set:** List the preconditions under which “Device absence never becomes a fabricated successful I/O result” must hold for “Unavailable-device behavior”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M02.07-C073-T04 · Transition coverage:** Map the “Unavailable-device behavior” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M02.07-C073-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Unavailable-device behavior”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M02.07-C073-T06 · Satisfying fixture:** Create a concrete “Unavailable-device behavior” case that satisfies “Device absence never becomes a fabricated successful I/O result”; record its expected observation before running the assertion or review.
- [ ] **UC-M02.07-C073-T07 · Violating fixture:** Create the source counterexample “A block device disappears during an invocation” for “Unavailable-device behavior”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M02.07-C073-T08 · Enforcement evidence:** Exercise the “Unavailable-device behavior” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M02.07-C073-T09 · Regression linkage:** Link the “Unavailable-device behavior” property to changes in selected guest devices, validated descriptors and host resource ownership; record which dependency or contract changes require rerunning it.
- [ ] **UC-M02.07-C073-T10 · Property disposition:** Compare the satisfying and violating “Unavailable-device behavior” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M02.07-C074 · Integration

**Original checklist item:** Integrate unavailable-device behavior with selected guest devices, validated descriptors and host resource ownership; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M02.07-C074-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Unavailable-device behavior” across selected guest devices, validated descriptors and host resource ownership; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M02.07-C074-T02 · Field mapping:** Map every “Unavailable-device behavior” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M02.07-C074-T03 · Prerequisite identities:** Record the actual prerequisites for “Unavailable-device behavior” (source dependency list: UC-M02.02, UC-M02.04); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M02.07-C074-T04 · Ownership agreement:** Specify who owns “Unavailable-device behavior” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M02.07-C074-T05 · Handoff implementation:** Connect “Unavailable-device behavior” through the mapped seam using the real adapter or explicit specification reference; preserve “Device absence never becomes a fabricated successful I/O result” across the handoff.
- [ ] **UC-M02.07-C074-T06 · Absent-input case:** Omit one required “Unavailable-device behavior” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M02.07-C074-T07 · Stale-input case:** Supply an outdated “Unavailable-device behavior” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M02.07-C074-T08 · Incompatible-input case:** Supply an incompatible “Unavailable-device behavior” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M02.07-C074-T09 · Valid integration trace:** Run a valid “Unavailable-device behavior” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M02.07-C074-T10 · Seam review:** Reconcile the “Unavailable-device behavior” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M02.07-C075 · Valid-case test

**Original checklist item:** Run a valid-path fixture for unavailable-device behavior; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M02.07-C075-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Unavailable-device behavior” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M02.07-C075-T02 · Expected-result oracle:** Specify the “Unavailable-device behavior” expected result independently of the implementation output; include the property “Device absence never becomes a fabricated successful I/O result” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M02.07-C075-T03 · Fixture material:** Create the concrete “Unavailable-device behavior” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M02.07-C075-T04 · Target preparation:** Prepare the “Unavailable-device behavior” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M02.07-C075-T05 · Initial-state record:** Record the initial “Unavailable-device behavior” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M02.07-C075-T06 · Valid-path execution:** Execute the “Unavailable-device behavior” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M02.07-C075-T07 · Outcome comparison:** Compare every declared “Unavailable-device behavior” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M02.07-C075-T08 · State and bounds check:** Inspect the “Unavailable-device behavior” ownership/state effects and actual use of “Failure propagation time and retry count”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M02.07-C075-T09 · Repeatability check:** Repeat the same “Unavailable-device behavior” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M02.07-C075-T10 · Positive evidence:** Attach the “Unavailable-device behavior” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M02.07-C076 · Negative test

**Original checklist item:** Negative case: A block device disappears during an invocation. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M02.07-C076-T01 · Adverse-case definition:** Create a test record for the exact “Unavailable-device behavior” source counterexample: “A block device disappears during an invocation”; state which precondition or invariant it challenges.
- [ ] **UC-M02.07-C076-T02 · Safe fixture boundary:** Define the contained test boundary for “Unavailable-device behavior”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M02.07-C076-T03 · Valid control:** Construct a valid “Unavailable-device behavior” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M02.07-C076-T04 · Minimal adverse input:** Derive the “Unavailable-device behavior” adverse fixture from the control with the smallest documented change needed to reproduce “A block device disappears during an invocation”; retain that change as reproducible data.
- [ ] **UC-M02.07-C076-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Unavailable-device behavior”; require “Device absence never becomes a fabricated successful I/O result” and forbid a false-success verdict.
- [ ] **UC-M02.07-C076-T06 · Adverse execution:** Exercise the “Unavailable-device behavior” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M02.07-C076-T07 · Effect inspection:** Inspect “Unavailable-device behavior” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M02.07-C076-T08 · Refusal versus failure:** Confirm the “Unavailable-device behavior” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M02.07-C076-T09 · Reset and retention:** Restore only the disposable “Unavailable-device behavior” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M02.07-C076-T10 · Negative regression:** Register the “Unavailable-device behavior” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M02.07-C077 · Change / failure test

**Original checklist item:** Exercise unavailable-device behavior when a required device disappears with requests still outstanding; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M02.07-C077-T01 · Scenario record:** Write the “Unavailable-device behavior” change/failure scenario exactly as supplied: a required device disappears with requests still outstanding; identify the property that must remain true: “Device absence never becomes a fabricated successful I/O result”.
- [ ] **UC-M02.07-C077-T02 · Baseline capture:** Create a known-valid “Unavailable-device behavior” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M02.07-C077-T03 · Injection map:** Locate the “Unavailable-device behavior” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M02.07-C077-T04 · Disposition oracle:** Define the legal intermediate and final “Unavailable-device behavior” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M02.07-C077-T05 · Controlled trigger:** Introduce the controlled “Unavailable-device behavior” scenario in the disposable fixture: a required device disappears with requests still outstanding; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M02.07-C077-T06 · Intermediate inspection:** Inspect the “Unavailable-device behavior” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M02.07-C077-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Unavailable-device behavior”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M02.07-C077-T08 · Stale-evidence cleanup:** Invalidate superseded “Unavailable-device behavior” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M02.07-C077-T09 · Repeat and compare:** Repeat the selected “Unavailable-device behavior” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M02.07-C077-T10 · Failure evidence:** Publish the “Unavailable-device behavior” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M02.07-C078 · Bounds

**Original checklist item:** Choose, document and test limits for failure propagation time and retry count; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M02.07-C078-T01 · Quantity inventory:** Create a measurement inventory for “Unavailable-device behavior”: “Failure propagation time and retry count”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M02.07-C078-T02 · Measurement method:** Choose how to observe each “Unavailable-device behavior” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M02.07-C078-T03 · Budget decision:** Select justified resource and input limits for “Unavailable-device behavior”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M02.07-C078-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Unavailable-device behavior” cases for “Failure propagation time and retry count”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M02.07-C078-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Unavailable-device behavior” limit; preserve “Device absence never becomes a fabricated successful I/O result”.
- [ ] **UC-M02.07-C078-T06 · Normal measurement:** Run or review the normal “Unavailable-device behavior” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M02.07-C078-T07 · At-limit measurement:** Exercise the “Unavailable-device behavior” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M02.07-C078-T08 · Over-limit measurement:** Exercise the “Unavailable-device behavior” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M02.07-C078-T09 · Uncovered-scope report:** List the “Unavailable-device behavior” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M02.07-C078-T10 · Limit evidence:** Publish the selected “Unavailable-device behavior” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M02.07-C079 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for unavailable-device behavior with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M02.07-C079-T01 · Event inventory:** List the “Unavailable-device behavior” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M02.07-C079-T02 · Diagnostic schema:** Define nonsecret fields for “Unavailable-device behavior” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M02.07-C079-T03 · Failure mapping:** Map each documented “Unavailable-device behavior” refusal or error to a diagnostic outcome; include “A block device disappears during an invocation” and prohibit conversion into a success message.
- [ ] **UC-M02.07-C079-T04 · Emission path:** Add the “Unavailable-device behavior” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M02.07-C079-T05 · Redaction check:** Test “Unavailable-device behavior” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M02.07-C079-T06 · Output budget:** Set and exercise bounded “Unavailable-device behavior” message size, rate and retention compatible with “Failure propagation time and retry count”; define truncation behavior that preserves the final reason.
- [ ] **UC-M02.07-C079-T07 · Success/refusal fixtures:** Capture “Unavailable-device behavior” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M02.07-C079-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Unavailable-device behavior” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M02.07-C079-T09 · Operator review:** Read the “Unavailable-device behavior” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M02.07-C079-T10 · Diagnostic evidence:** Publish redacted “Unavailable-device behavior” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M02.07-C080 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for unavailable-device behavior; label unexecuted checks as untested.

- [ ] **UC-M02.07-C080-T01 · Evidence inventory:** List the “Unavailable-device behavior” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M02.07-C080-T02 · Artifact references:** Record the exact “Unavailable-device behavior” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M02.07-C080-T03 · Fixture references:** Attach the “Unavailable-device behavior” fixture IDs, input identities and oracle definition; preserve the source counterexample “A block device disappears during an invocation” as a distinct evidence case.
- [ ] **UC-M02.07-C080-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Unavailable-device behavior”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M02.07-C080-T05 · Environment record:** Record the actual “Unavailable-device behavior” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M02.07-C080-T06 · Expected versus observed:** Pair every “Unavailable-device behavior” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M02.07-C080-T07 · Failure and limit records:** Attach “Unavailable-device behavior” change/failure and bounds evidence where required; include uncovered “Failure propagation time and retry count” and unresolved violations of “Device absence never becomes a fabricated successful I/O result”.
- [ ] **UC-M02.07-C080-T08 · Evidence hygiene:** Check the “Unavailable-device behavior” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M02.07-C080-T09 · Reproduction review:** Have the “Unavailable-device behavior” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M02.07-C080-T10 · Acceptance linkage:** Link the “Unavailable-device behavior” evidence to its parent and UC-M02.07 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 09. Device shutdown

**Source delivery:** Drain or cancel pending device work before revoking its resources.

**Source invariant:** A stopped guest cannot continue using stale device descriptors.

**Source negative case:** A guest reuses descriptors after the device is revoked.

**Source bounded quantities:** Drain deadline and remaining requests.

### UC-M02.07-C081 · Contract

**Original checklist item:** Specify device shutdown inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M02.07-C081-T01 · Scope statement:** Draft the operation boundary for “Device shutdown” within Minimal console, block and transport drivers; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M02.07-C081-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Device shutdown”; record each producer, representation and missing-value meaning.
- [ ] **UC-M02.07-C081-T03 · Output inventory:** List the outputs of “Device shutdown” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M02.07-C081-T04 · Field dictionary:** Create a field-and-term dictionary for “Device shutdown”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M02.07-C081-T05 · Prerequisite contract:** Map “Device shutdown” to the source component prerequisites (UC-M02.02, UC-M02.04); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M02.07-C081-T06 · Authority map:** Identify who may produce, change and consume “Device shutdown”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M02.07-C081-T07 · Invariant clause:** Add a normative clause for “Device shutdown” that preserves “A stopped guest cannot continue using stale device descriptors”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M02.07-C081-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Device shutdown”; include the source counterexample “A guest reuses descriptors after the device is revoked” and the intended safe disposition.
- [ ] **UC-M02.07-C081-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Drain deadline and remaining requests” in the “Device shutdown” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M02.07-C081-T10 · Contract review:** Review the “Device shutdown” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M02.07-C082 · Delivery

**Original checklist item:** Drain or cancel pending device work before revoking its resources.

- [ ] **UC-M02.07-C082-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Device shutdown”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M02.07-C082-T02 · Change plan:** Break the source delivery for “Device shutdown” into concrete edit targets and reviewable outputs; keep the UC-M02.07 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M02.07-C082-T03 · Core artifact:** Implement the smallest selected-profile change for “Device shutdown” that realizes this source instruction: Drain or cancel pending device work before revoking its resources.
- [ ] **UC-M02.07-C082-T04 · Concrete realization:** Trace “Device shutdown” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M02.07-C082-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Device shutdown” needed to preserve “A stopped guest cannot continue using stale device descriptors”; record an enforcement gap where only a model exists.
- [ ] **UC-M02.07-C082-T06 · Dependency connection:** Connect the “Device shutdown” implementation to selected guest devices, validated descriptors and host resource ownership; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M02.07-C082-T07 · Resource behavior:** Account for “Drain deadline and remaining requests” in “Device shutdown”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M02.07-C082-T08 · Delivery check:** Run the smallest real “Device shutdown” path and its adverse fixture “A guest reuses descriptors after the device is revoked”; retain actual output, state effects and final disposition.
- [ ] **UC-M02.07-C082-T09 · Patch review:** Review the “Device shutdown” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M02.07-C082-T10 · Delivery handoff:** Publish the “Device shutdown” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M02.07-C083 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: A stopped guest cannot continue using stale device descriptors. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M02.07-C083-T01 · Named property:** Create a stable property/check name under this parent for “Device shutdown”; copy its required invariant exactly: “A stopped guest cannot continue using stale device descriptors”.
- [ ] **UC-M02.07-C083-T02 · Observable terms:** Define each term in the “Device shutdown” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M02.07-C083-T03 · Precondition set:** List the preconditions under which “A stopped guest cannot continue using stale device descriptors” must hold for “Device shutdown”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M02.07-C083-T04 · Transition coverage:** Map the “Device shutdown” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M02.07-C083-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Device shutdown”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M02.07-C083-T06 · Satisfying fixture:** Create a concrete “Device shutdown” case that satisfies “A stopped guest cannot continue using stale device descriptors”; record its expected observation before running the assertion or review.
- [ ] **UC-M02.07-C083-T07 · Violating fixture:** Create the source counterexample “A guest reuses descriptors after the device is revoked” for “Device shutdown”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M02.07-C083-T08 · Enforcement evidence:** Exercise the “Device shutdown” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M02.07-C083-T09 · Regression linkage:** Link the “Device shutdown” property to changes in selected guest devices, validated descriptors and host resource ownership; record which dependency or contract changes require rerunning it.
- [ ] **UC-M02.07-C083-T10 · Property disposition:** Compare the satisfying and violating “Device shutdown” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M02.07-C084 · Integration

**Original checklist item:** Integrate device shutdown with selected guest devices, validated descriptors and host resource ownership; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M02.07-C084-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Device shutdown” across selected guest devices, validated descriptors and host resource ownership; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M02.07-C084-T02 · Field mapping:** Map every “Device shutdown” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M02.07-C084-T03 · Prerequisite identities:** Record the actual prerequisites for “Device shutdown” (source dependency list: UC-M02.02, UC-M02.04); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M02.07-C084-T04 · Ownership agreement:** Specify who owns “Device shutdown” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M02.07-C084-T05 · Handoff implementation:** Connect “Device shutdown” through the mapped seam using the real adapter or explicit specification reference; preserve “A stopped guest cannot continue using stale device descriptors” across the handoff.
- [ ] **UC-M02.07-C084-T06 · Absent-input case:** Omit one required “Device shutdown” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M02.07-C084-T07 · Stale-input case:** Supply an outdated “Device shutdown” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M02.07-C084-T08 · Incompatible-input case:** Supply an incompatible “Device shutdown” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M02.07-C084-T09 · Valid integration trace:** Run a valid “Device shutdown” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M02.07-C084-T10 · Seam review:** Reconcile the “Device shutdown” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M02.07-C085 · Valid-case test

**Original checklist item:** Run a valid-path fixture for device shutdown; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M02.07-C085-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Device shutdown” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M02.07-C085-T02 · Expected-result oracle:** Specify the “Device shutdown” expected result independently of the implementation output; include the property “A stopped guest cannot continue using stale device descriptors” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M02.07-C085-T03 · Fixture material:** Create the concrete “Device shutdown” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M02.07-C085-T04 · Target preparation:** Prepare the “Device shutdown” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M02.07-C085-T05 · Initial-state record:** Record the initial “Device shutdown” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M02.07-C085-T06 · Valid-path execution:** Execute the “Device shutdown” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M02.07-C085-T07 · Outcome comparison:** Compare every declared “Device shutdown” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M02.07-C085-T08 · State and bounds check:** Inspect the “Device shutdown” ownership/state effects and actual use of “Drain deadline and remaining requests”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M02.07-C085-T09 · Repeatability check:** Repeat the same “Device shutdown” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M02.07-C085-T10 · Positive evidence:** Attach the “Device shutdown” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M02.07-C086 · Negative test

**Original checklist item:** Negative case: A guest reuses descriptors after the device is revoked. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M02.07-C086-T01 · Adverse-case definition:** Create a test record for the exact “Device shutdown” source counterexample: “A guest reuses descriptors after the device is revoked”; state which precondition or invariant it challenges.
- [ ] **UC-M02.07-C086-T02 · Safe fixture boundary:** Define the contained test boundary for “Device shutdown”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M02.07-C086-T03 · Valid control:** Construct a valid “Device shutdown” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M02.07-C086-T04 · Minimal adverse input:** Derive the “Device shutdown” adverse fixture from the control with the smallest documented change needed to reproduce “A guest reuses descriptors after the device is revoked”; retain that change as reproducible data.
- [ ] **UC-M02.07-C086-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Device shutdown”; require “A stopped guest cannot continue using stale device descriptors” and forbid a false-success verdict.
- [ ] **UC-M02.07-C086-T06 · Adverse execution:** Exercise the “Device shutdown” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M02.07-C086-T07 · Effect inspection:** Inspect “Device shutdown” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M02.07-C086-T08 · Refusal versus failure:** Confirm the “Device shutdown” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M02.07-C086-T09 · Reset and retention:** Restore only the disposable “Device shutdown” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M02.07-C086-T10 · Negative regression:** Register the “Device shutdown” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M02.07-C087 · Change / failure test

**Original checklist item:** Exercise device shutdown when a required device disappears with requests still outstanding; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M02.07-C087-T01 · Scenario record:** Write the “Device shutdown” change/failure scenario exactly as supplied: a required device disappears with requests still outstanding; identify the property that must remain true: “A stopped guest cannot continue using stale device descriptors”.
- [ ] **UC-M02.07-C087-T02 · Baseline capture:** Create a known-valid “Device shutdown” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M02.07-C087-T03 · Injection map:** Locate the “Device shutdown” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M02.07-C087-T04 · Disposition oracle:** Define the legal intermediate and final “Device shutdown” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M02.07-C087-T05 · Controlled trigger:** Introduce the controlled “Device shutdown” scenario in the disposable fixture: a required device disappears with requests still outstanding; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M02.07-C087-T06 · Intermediate inspection:** Inspect the “Device shutdown” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M02.07-C087-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Device shutdown”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M02.07-C087-T08 · Stale-evidence cleanup:** Invalidate superseded “Device shutdown” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M02.07-C087-T09 · Repeat and compare:** Repeat the selected “Device shutdown” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M02.07-C087-T10 · Failure evidence:** Publish the “Device shutdown” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M02.07-C088 · Bounds

**Original checklist item:** Choose, document and test limits for drain deadline and remaining requests; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M02.07-C088-T01 · Quantity inventory:** Create a measurement inventory for “Device shutdown”: “Drain deadline and remaining requests”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M02.07-C088-T02 · Measurement method:** Choose how to observe each “Device shutdown” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M02.07-C088-T03 · Budget decision:** Select justified resource and input limits for “Device shutdown”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M02.07-C088-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Device shutdown” cases for “Drain deadline and remaining requests”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M02.07-C088-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Device shutdown” limit; preserve “A stopped guest cannot continue using stale device descriptors”.
- [ ] **UC-M02.07-C088-T06 · Normal measurement:** Run or review the normal “Device shutdown” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M02.07-C088-T07 · At-limit measurement:** Exercise the “Device shutdown” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M02.07-C088-T08 · Over-limit measurement:** Exercise the “Device shutdown” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M02.07-C088-T09 · Uncovered-scope report:** List the “Device shutdown” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M02.07-C088-T10 · Limit evidence:** Publish the selected “Device shutdown” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M02.07-C089 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for device shutdown with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M02.07-C089-T01 · Event inventory:** List the “Device shutdown” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M02.07-C089-T02 · Diagnostic schema:** Define nonsecret fields for “Device shutdown” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M02.07-C089-T03 · Failure mapping:** Map each documented “Device shutdown” refusal or error to a diagnostic outcome; include “A guest reuses descriptors after the device is revoked” and prohibit conversion into a success message.
- [ ] **UC-M02.07-C089-T04 · Emission path:** Add the “Device shutdown” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M02.07-C089-T05 · Redaction check:** Test “Device shutdown” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M02.07-C089-T06 · Output budget:** Set and exercise bounded “Device shutdown” message size, rate and retention compatible with “Drain deadline and remaining requests”; define truncation behavior that preserves the final reason.
- [ ] **UC-M02.07-C089-T07 · Success/refusal fixtures:** Capture “Device shutdown” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M02.07-C089-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Device shutdown” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M02.07-C089-T09 · Operator review:** Read the “Device shutdown” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M02.07-C089-T10 · Diagnostic evidence:** Publish redacted “Device shutdown” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M02.07-C090 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for device shutdown; label unexecuted checks as untested.

- [ ] **UC-M02.07-C090-T01 · Evidence inventory:** List the “Device shutdown” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M02.07-C090-T02 · Artifact references:** Record the exact “Device shutdown” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M02.07-C090-T03 · Fixture references:** Attach the “Device shutdown” fixture IDs, input identities and oracle definition; preserve the source counterexample “A guest reuses descriptors after the device is revoked” as a distinct evidence case.
- [ ] **UC-M02.07-C090-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Device shutdown”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M02.07-C090-T05 · Environment record:** Record the actual “Device shutdown” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M02.07-C090-T06 · Expected versus observed:** Pair every “Device shutdown” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M02.07-C090-T07 · Failure and limit records:** Attach “Device shutdown” change/failure and bounds evidence where required; include uncovered “Drain deadline and remaining requests” and unresolved violations of “A stopped guest cannot continue using stale device descriptors”.
- [ ] **UC-M02.07-C090-T08 · Evidence hygiene:** Check the “Device shutdown” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M02.07-C090-T09 · Reproduction review:** Have the “Device shutdown” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M02.07-C090-T10 · Acceptance linkage:** Link the “Device shutdown” evidence to its parent and UC-M02.07 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 10. Driver conformance suite

**Source delivery:** Test valid I/O, malformed descriptors and device loss for the selected profile.

**Source invariant:** Driver evidence matches exactly the devices exposed by that profile.

**Source negative case:** Tests qualify a device configuration different from the released image.

**Source bounded quantities:** Device matrix, corpus size and test time.

### UC-M02.07-C091 · Contract

**Original checklist item:** Specify driver conformance suite inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M02.07-C091-T01 · Scope statement:** Draft the operation boundary for “Driver conformance suite” within Minimal console, block and transport drivers; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M02.07-C091-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Driver conformance suite”; record each producer, representation and missing-value meaning.
- [ ] **UC-M02.07-C091-T03 · Output inventory:** List the outputs of “Driver conformance suite” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M02.07-C091-T04 · Field dictionary:** Create a field-and-term dictionary for “Driver conformance suite”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M02.07-C091-T05 · Prerequisite contract:** Map “Driver conformance suite” to the source component prerequisites (UC-M02.02, UC-M02.04); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M02.07-C091-T06 · Authority map:** Identify who may produce, change and consume “Driver conformance suite”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M02.07-C091-T07 · Invariant clause:** Add a normative clause for “Driver conformance suite” that preserves “Driver evidence matches exactly the devices exposed by that profile”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M02.07-C091-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Driver conformance suite”; include the source counterexample “Tests qualify a device configuration different from the released image” and the intended safe disposition.
- [ ] **UC-M02.07-C091-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Device matrix, corpus size and test time” in the “Driver conformance suite” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M02.07-C091-T10 · Contract review:** Review the “Driver conformance suite” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M02.07-C092 · Delivery

**Original checklist item:** Test valid I/O, malformed descriptors and device loss for the selected profile.

- [ ] **UC-M02.07-C092-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Driver conformance suite”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M02.07-C092-T02 · Change plan:** Break the source delivery for “Driver conformance suite” into concrete edit targets and reviewable outputs; keep the UC-M02.07 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M02.07-C092-T03 · Core artifact:** Create the “Driver conformance suite” fixture or harness for this source instruction: Test valid I/O, malformed descriptors and device loss for the selected profile.
- [ ] **UC-M02.07-C092-T04 · Concrete realization:** Connect the “Driver conformance suite” harness to its actual intended target, set the expected oracle before running it, and distinguish a mock/control run from a target run.
- [ ] **UC-M02.07-C092-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Driver conformance suite” needed to preserve “Driver evidence matches exactly the devices exposed by that profile”; record an enforcement gap where only a model exists.
- [ ] **UC-M02.07-C092-T06 · Dependency connection:** Connect the “Driver conformance suite” implementation to selected guest devices, validated descriptors and host resource ownership; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M02.07-C092-T07 · Resource behavior:** Account for “Device matrix, corpus size and test time” in “Driver conformance suite”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M02.07-C092-T08 · Delivery check:** Run the smallest real “Driver conformance suite” path and its adverse fixture “Tests qualify a device configuration different from the released image”; retain actual output, state effects and final disposition.
- [ ] **UC-M02.07-C092-T09 · Patch review:** Review the “Driver conformance suite” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M02.07-C092-T10 · Delivery handoff:** Publish the “Driver conformance suite” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M02.07-C093 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Driver evidence matches exactly the devices exposed by that profile. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M02.07-C093-T01 · Named property:** Create a stable property/check name under this parent for “Driver conformance suite”; copy its required invariant exactly: “Driver evidence matches exactly the devices exposed by that profile”.
- [ ] **UC-M02.07-C093-T02 · Observable terms:** Define each term in the “Driver conformance suite” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M02.07-C093-T03 · Precondition set:** List the preconditions under which “Driver evidence matches exactly the devices exposed by that profile” must hold for “Driver conformance suite”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M02.07-C093-T04 · Transition coverage:** Map the “Driver conformance suite” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M02.07-C093-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Driver conformance suite”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M02.07-C093-T06 · Satisfying fixture:** Create a concrete “Driver conformance suite” case that satisfies “Driver evidence matches exactly the devices exposed by that profile”; record its expected observation before running the assertion or review.
- [ ] **UC-M02.07-C093-T07 · Violating fixture:** Create the source counterexample “Tests qualify a device configuration different from the released image” for “Driver conformance suite”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M02.07-C093-T08 · Enforcement evidence:** Exercise the “Driver conformance suite” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M02.07-C093-T09 · Regression linkage:** Link the “Driver conformance suite” property to changes in selected guest devices, validated descriptors and host resource ownership; record which dependency or contract changes require rerunning it.
- [ ] **UC-M02.07-C093-T10 · Property disposition:** Compare the satisfying and violating “Driver conformance suite” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M02.07-C094 · Integration

**Original checklist item:** Integrate driver conformance suite with selected guest devices, validated descriptors and host resource ownership; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M02.07-C094-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Driver conformance suite” across selected guest devices, validated descriptors and host resource ownership; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M02.07-C094-T02 · Field mapping:** Map every “Driver conformance suite” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M02.07-C094-T03 · Prerequisite identities:** Record the actual prerequisites for “Driver conformance suite” (source dependency list: UC-M02.02, UC-M02.04); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M02.07-C094-T04 · Ownership agreement:** Specify who owns “Driver conformance suite” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M02.07-C094-T05 · Handoff implementation:** Connect “Driver conformance suite” through the mapped seam using the real adapter or explicit specification reference; preserve “Driver evidence matches exactly the devices exposed by that profile” across the handoff.
- [ ] **UC-M02.07-C094-T06 · Absent-input case:** Omit one required “Driver conformance suite” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M02.07-C094-T07 · Stale-input case:** Supply an outdated “Driver conformance suite” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M02.07-C094-T08 · Incompatible-input case:** Supply an incompatible “Driver conformance suite” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M02.07-C094-T09 · Valid integration trace:** Run a valid “Driver conformance suite” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M02.07-C094-T10 · Seam review:** Reconcile the “Driver conformance suite” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M02.07-C095 · Valid-case test

**Original checklist item:** Run a valid-path fixture for driver conformance suite; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M02.07-C095-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Driver conformance suite” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M02.07-C095-T02 · Expected-result oracle:** Specify the “Driver conformance suite” expected result independently of the implementation output; include the property “Driver evidence matches exactly the devices exposed by that profile” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M02.07-C095-T03 · Fixture material:** Create the concrete “Driver conformance suite” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M02.07-C095-T04 · Target preparation:** Prepare the “Driver conformance suite” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M02.07-C095-T05 · Initial-state record:** Record the initial “Driver conformance suite” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M02.07-C095-T06 · Valid-path execution:** Execute the “Driver conformance suite” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M02.07-C095-T07 · Outcome comparison:** Compare every declared “Driver conformance suite” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M02.07-C095-T08 · State and bounds check:** Inspect the “Driver conformance suite” ownership/state effects and actual use of “Device matrix, corpus size and test time”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M02.07-C095-T09 · Repeatability check:** Repeat the same “Driver conformance suite” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M02.07-C095-T10 · Positive evidence:** Attach the “Driver conformance suite” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M02.07-C096 · Negative test

**Original checklist item:** Negative case: Tests qualify a device configuration different from the released image. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M02.07-C096-T01 · Adverse-case definition:** Create a test record for the exact “Driver conformance suite” source counterexample: “Tests qualify a device configuration different from the released image”; state which precondition or invariant it challenges.
- [ ] **UC-M02.07-C096-T02 · Safe fixture boundary:** Define the contained test boundary for “Driver conformance suite”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M02.07-C096-T03 · Valid control:** Construct a valid “Driver conformance suite” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M02.07-C096-T04 · Minimal adverse input:** Derive the “Driver conformance suite” adverse fixture from the control with the smallest documented change needed to reproduce “Tests qualify a device configuration different from the released image”; retain that change as reproducible data.
- [ ] **UC-M02.07-C096-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Driver conformance suite”; require “Driver evidence matches exactly the devices exposed by that profile” and forbid a false-success verdict.
- [ ] **UC-M02.07-C096-T06 · Adverse execution:** Exercise the “Driver conformance suite” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M02.07-C096-T07 · Effect inspection:** Inspect “Driver conformance suite” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M02.07-C096-T08 · Refusal versus failure:** Confirm the “Driver conformance suite” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M02.07-C096-T09 · Reset and retention:** Restore only the disposable “Driver conformance suite” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M02.07-C096-T10 · Negative regression:** Register the “Driver conformance suite” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M02.07-C097 · Change / failure test

**Original checklist item:** Exercise driver conformance suite when a required device disappears with requests still outstanding; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M02.07-C097-T01 · Scenario record:** Write the “Driver conformance suite” change/failure scenario exactly as supplied: a required device disappears with requests still outstanding; identify the property that must remain true: “Driver evidence matches exactly the devices exposed by that profile”.
- [ ] **UC-M02.07-C097-T02 · Baseline capture:** Create a known-valid “Driver conformance suite” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M02.07-C097-T03 · Injection map:** Locate the “Driver conformance suite” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M02.07-C097-T04 · Disposition oracle:** Define the legal intermediate and final “Driver conformance suite” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M02.07-C097-T05 · Controlled trigger:** Introduce the controlled “Driver conformance suite” scenario in the disposable fixture: a required device disappears with requests still outstanding; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M02.07-C097-T06 · Intermediate inspection:** Inspect the “Driver conformance suite” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M02.07-C097-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Driver conformance suite”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M02.07-C097-T08 · Stale-evidence cleanup:** Invalidate superseded “Driver conformance suite” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M02.07-C097-T09 · Repeat and compare:** Repeat the selected “Driver conformance suite” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M02.07-C097-T10 · Failure evidence:** Publish the “Driver conformance suite” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M02.07-C098 · Bounds

**Original checklist item:** Choose, document and test limits for device matrix, corpus size and test time; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M02.07-C098-T01 · Quantity inventory:** Create a measurement inventory for “Driver conformance suite”: “Device matrix, corpus size and test time”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M02.07-C098-T02 · Measurement method:** Choose how to observe each “Driver conformance suite” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M02.07-C098-T03 · Budget decision:** Select justified resource and input limits for “Driver conformance suite”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M02.07-C098-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Driver conformance suite” cases for “Device matrix, corpus size and test time”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M02.07-C098-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Driver conformance suite” limit; preserve “Driver evidence matches exactly the devices exposed by that profile”.
- [ ] **UC-M02.07-C098-T06 · Normal measurement:** Run or review the normal “Driver conformance suite” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M02.07-C098-T07 · At-limit measurement:** Exercise the “Driver conformance suite” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M02.07-C098-T08 · Over-limit measurement:** Exercise the “Driver conformance suite” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M02.07-C098-T09 · Uncovered-scope report:** List the “Driver conformance suite” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M02.07-C098-T10 · Limit evidence:** Publish the selected “Driver conformance suite” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M02.07-C099 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for driver conformance suite with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M02.07-C099-T01 · Event inventory:** List the “Driver conformance suite” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M02.07-C099-T02 · Diagnostic schema:** Define nonsecret fields for “Driver conformance suite” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M02.07-C099-T03 · Failure mapping:** Map each documented “Driver conformance suite” refusal or error to a diagnostic outcome; include “Tests qualify a device configuration different from the released image” and prohibit conversion into a success message.
- [ ] **UC-M02.07-C099-T04 · Emission path:** Add the “Driver conformance suite” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M02.07-C099-T05 · Redaction check:** Test “Driver conformance suite” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M02.07-C099-T06 · Output budget:** Set and exercise bounded “Driver conformance suite” message size, rate and retention compatible with “Device matrix, corpus size and test time”; define truncation behavior that preserves the final reason.
- [ ] **UC-M02.07-C099-T07 · Success/refusal fixtures:** Capture “Driver conformance suite” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M02.07-C099-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Driver conformance suite” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M02.07-C099-T09 · Operator review:** Read the “Driver conformance suite” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M02.07-C099-T10 · Diagnostic evidence:** Publish redacted “Driver conformance suite” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M02.07-C100 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for driver conformance suite; label unexecuted checks as untested.

- [ ] **UC-M02.07-C100-T01 · Evidence inventory:** List the “Driver conformance suite” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M02.07-C100-T02 · Artifact references:** Record the exact “Driver conformance suite” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M02.07-C100-T03 · Fixture references:** Attach the “Driver conformance suite” fixture IDs, input identities and oracle definition; preserve the source counterexample “Tests qualify a device configuration different from the released image” as a distinct evidence case.
- [ ] **UC-M02.07-C100-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Driver conformance suite”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M02.07-C100-T05 · Environment record:** Record the actual “Driver conformance suite” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M02.07-C100-T06 · Expected versus observed:** Pair every “Driver conformance suite” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M02.07-C100-T07 · Failure and limit records:** Attach “Driver conformance suite” change/failure and bounds evidence where required; include uncovered “Device matrix, corpus size and test time” and unresolved violations of “Driver evidence matches exactly the devices exposed by that profile”.
- [ ] **UC-M02.07-C100-T08 · Evidence hygiene:** Check the “Driver conformance suite” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M02.07-C100-T09 · Reproduction review:** Have the “Driver conformance suite” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M02.07-C100-T10 · Acceptance linkage:** Link the “Driver conformance suite” evidence to its parent and UC-M02.07 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

