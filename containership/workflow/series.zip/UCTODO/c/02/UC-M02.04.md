# UC-M02.04 — Guest allocator and memory lifecycle

**To-Do Pack 2.0.0 · Baseline UC-2.2.0 · 100 parent checks × 10 subtasks = 1,000 to-dos**

[Master index](../../INDEX.md) · [Workstream index](../../w/02.md)

| Field | Preserved source value |
|---|---|
| Workstream | 02. Bootable unikernel guest |
| Milestone | B |
| Priority | P0 |
| Source assessment | MISSING |
| Scope | core or selected profile |
| Dependencies | [UC-M02.03](../02/UC-M02.03.md) |
| Source checklist pack | 1.0.0 |
| Original reference labels | [S1], [S2], [S3]. |

## Original requirement

Provide bounded allocation, failure behavior, stack budgets and memory ownership appropriate to the linked runtime.

**Original acceptance criterion:** Memory exhaustion yields a documented failure without host escape or cross-guest corruption.

**Source trace:** Original checklist `UC100/c/02/UC-M02.04.md` inside [s/checklists.zip](../../s/checklists.zip); exact parent records in [data/parents.jsonl](../../data/parents.jsonl). Original roadmap lines 177–187 are preserved in [s/roadmap.md](../../s/roadmap.md).

## How to use these lists

Every parent statement below is preserved verbatim. Its ten child tasks are proposed decomposition, not implemented capabilities or executed tests. Child IDs append `-T01` through `-T10` to the original parent ID. All begin unchecked / `TODO`. Design/review evidence does not establish runtime enforcement; observe the actual selected target where the parent requires it.

The source dependency graph and selected release profile determine applicability. The numbered child sequence is a local working order, not an added hard dependency graph. An unselected optional feature needs a recorded not-applicable rationale; missing prerequisites for selected work remain blockers. Numerical budgets, backends and trust mechanisms remain decisions unless fixed by the source. Test hostile cases only with synthetic inputs in authorized disposable environments.

## 01. Allocation interface

**Source delivery:** Define allocation, reallocation and release semantics for the linked runtime.

**Source invariant:** Callers can distinguish allocation failure from valid memory.

**Source negative case:** An allocation failure is returned as an apparently valid address.

**Source bounded quantities:** Allocation request size and call rate.

### UC-M02.04-C001 · Contract

**Original checklist item:** Specify allocation interface inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M02.04-C001-T01 · Scope statement:** Draft the operation boundary for “Allocation interface” within Guest allocator and memory lifecycle; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M02.04-C001-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Allocation interface”; record each producer, representation and missing-value meaning.
- [ ] **UC-M02.04-C001-T03 · Output inventory:** List the outputs of “Allocation interface” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M02.04-C001-T04 · Field dictionary:** Create a field-and-term dictionary for “Allocation interface”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M02.04-C001-T05 · Prerequisite contract:** Map “Allocation interface” to the source component prerequisites (UC-M02.03); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M02.04-C001-T06 · Authority map:** Identify who may produce, change and consume “Allocation interface”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M02.04-C001-T07 · Invariant clause:** Add a normative clause for “Allocation interface” that preserves “Callers can distinguish allocation failure from valid memory”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M02.04-C001-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Allocation interface”; include the source counterexample “An allocation failure is returned as an apparently valid address” and the intended safe disposition.
- [ ] **UC-M02.04-C001-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Allocation request size and call rate” in the “Allocation interface” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M02.04-C001-T10 · Contract review:** Review the “Allocation interface” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M02.04-C002 · Delivery

**Original checklist item:** Define allocation, reallocation and release semantics for the linked runtime.

- [ ] **UC-M02.04-C002-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Allocation interface”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M02.04-C002-T02 · Change plan:** Break the source delivery for “Allocation interface” into concrete edit targets and reviewable outputs; keep the UC-M02.04 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M02.04-C002-T03 · Core artifact:** Create the “Allocation interface” model, schema or inventory that realizes this source instruction: Define allocation, reallocation and release semantics for the linked runtime.
- [ ] **UC-M02.04-C002-T04 · Concrete realization:** Populate “Allocation interface” with one concrete worked case; map every required entity or field to its source and flag any unmapped entry.
- [ ] **UC-M02.04-C002-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Allocation interface” needed to preserve “Callers can distinguish allocation failure from valid memory”; record an enforcement gap where only a model exists.
- [ ] **UC-M02.04-C002-T06 · Dependency connection:** Connect the “Allocation interface” implementation to guest runtime allocations, stack setup and host-assigned memory regions; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M02.04-C002-T07 · Resource behavior:** Account for “Allocation request size and call rate” in “Allocation interface”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M02.04-C002-T08 · Delivery check:** Run the smallest real “Allocation interface” path and its adverse fixture “An allocation failure is returned as an apparently valid address”; retain actual output, state effects and final disposition.
- [ ] **UC-M02.04-C002-T09 · Patch review:** Review the “Allocation interface” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M02.04-C002-T10 · Delivery handoff:** Publish the “Allocation interface” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M02.04-C003 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Callers can distinguish allocation failure from valid memory. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M02.04-C003-T01 · Named property:** Create a stable property/check name under this parent for “Allocation interface”; copy its required invariant exactly: “Callers can distinguish allocation failure from valid memory”.
- [ ] **UC-M02.04-C003-T02 · Observable terms:** Define each term in the “Allocation interface” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M02.04-C003-T03 · Precondition set:** List the preconditions under which “Callers can distinguish allocation failure from valid memory” must hold for “Allocation interface”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M02.04-C003-T04 · Transition coverage:** Map the “Allocation interface” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M02.04-C003-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Allocation interface”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M02.04-C003-T06 · Satisfying fixture:** Create a concrete “Allocation interface” case that satisfies “Callers can distinguish allocation failure from valid memory”; record its expected observation before running the assertion or review.
- [ ] **UC-M02.04-C003-T07 · Violating fixture:** Create the source counterexample “An allocation failure is returned as an apparently valid address” for “Allocation interface”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M02.04-C003-T08 · Enforcement evidence:** Exercise the “Allocation interface” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M02.04-C003-T09 · Regression linkage:** Link the “Allocation interface” property to changes in guest runtime allocations, stack setup and host-assigned memory regions; record which dependency or contract changes require rerunning it.
- [ ] **UC-M02.04-C003-T10 · Property disposition:** Compare the satisfying and violating “Allocation interface” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M02.04-C004 · Integration

**Original checklist item:** Integrate allocation interface with guest runtime allocations, stack setup and host-assigned memory regions; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M02.04-C004-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Allocation interface” across guest runtime allocations, stack setup and host-assigned memory regions; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M02.04-C004-T02 · Field mapping:** Map every “Allocation interface” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M02.04-C004-T03 · Prerequisite identities:** Record the actual prerequisites for “Allocation interface” (source dependency list: UC-M02.03); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M02.04-C004-T04 · Ownership agreement:** Specify who owns “Allocation interface” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M02.04-C004-T05 · Handoff implementation:** Connect “Allocation interface” through the mapped seam using the real adapter or explicit specification reference; preserve “Callers can distinguish allocation failure from valid memory” across the handoff.
- [ ] **UC-M02.04-C004-T06 · Absent-input case:** Omit one required “Allocation interface” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M02.04-C004-T07 · Stale-input case:** Supply an outdated “Allocation interface” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M02.04-C004-T08 · Incompatible-input case:** Supply an incompatible “Allocation interface” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M02.04-C004-T09 · Valid integration trace:** Run a valid “Allocation interface” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M02.04-C004-T10 · Seam review:** Reconcile the “Allocation interface” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M02.04-C005 · Valid-case test

**Original checklist item:** Run a valid-path fixture for allocation interface; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M02.04-C005-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Allocation interface” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M02.04-C005-T02 · Expected-result oracle:** Specify the “Allocation interface” expected result independently of the implementation output; include the property “Callers can distinguish allocation failure from valid memory” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M02.04-C005-T03 · Fixture material:** Create the concrete “Allocation interface” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M02.04-C005-T04 · Target preparation:** Prepare the “Allocation interface” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M02.04-C005-T05 · Initial-state record:** Record the initial “Allocation interface” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M02.04-C005-T06 · Valid-path execution:** Execute the “Allocation interface” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M02.04-C005-T07 · Outcome comparison:** Compare every declared “Allocation interface” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M02.04-C005-T08 · State and bounds check:** Inspect the “Allocation interface” ownership/state effects and actual use of “Allocation request size and call rate”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M02.04-C005-T09 · Repeatability check:** Repeat the same “Allocation interface” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M02.04-C005-T10 · Positive evidence:** Attach the “Allocation interface” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M02.04-C006 · Negative test

**Original checklist item:** Negative case: An allocation failure is returned as an apparently valid address. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M02.04-C006-T01 · Adverse-case definition:** Create a test record for the exact “Allocation interface” source counterexample: “An allocation failure is returned as an apparently valid address”; state which precondition or invariant it challenges.
- [ ] **UC-M02.04-C006-T02 · Safe fixture boundary:** Define the contained test boundary for “Allocation interface”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M02.04-C006-T03 · Valid control:** Construct a valid “Allocation interface” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M02.04-C006-T04 · Minimal adverse input:** Derive the “Allocation interface” adverse fixture from the control with the smallest documented change needed to reproduce “An allocation failure is returned as an apparently valid address”; retain that change as reproducible data.
- [ ] **UC-M02.04-C006-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Allocation interface”; require “Callers can distinguish allocation failure from valid memory” and forbid a false-success verdict.
- [ ] **UC-M02.04-C006-T06 · Adverse execution:** Exercise the “Allocation interface” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M02.04-C006-T07 · Effect inspection:** Inspect “Allocation interface” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M02.04-C006-T08 · Refusal versus failure:** Confirm the “Allocation interface” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M02.04-C006-T09 · Reset and retention:** Restore only the disposable “Allocation interface” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M02.04-C006-T10 · Negative regression:** Register the “Allocation interface” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M02.04-C007 · Change / failure test

**Original checklist item:** Exercise allocation interface when an invocation fails during allocation and a subsequent invocation starts; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M02.04-C007-T01 · Scenario record:** Write the “Allocation interface” change/failure scenario exactly as supplied: an invocation fails during allocation and a subsequent invocation starts; identify the property that must remain true: “Callers can distinguish allocation failure from valid memory”.
- [ ] **UC-M02.04-C007-T02 · Baseline capture:** Create a known-valid “Allocation interface” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M02.04-C007-T03 · Injection map:** Locate the “Allocation interface” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M02.04-C007-T04 · Disposition oracle:** Define the legal intermediate and final “Allocation interface” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M02.04-C007-T05 · Controlled trigger:** Introduce the controlled “Allocation interface” scenario in the disposable fixture: an invocation fails during allocation and a subsequent invocation starts; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M02.04-C007-T06 · Intermediate inspection:** Inspect the “Allocation interface” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M02.04-C007-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Allocation interface”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M02.04-C007-T08 · Stale-evidence cleanup:** Invalidate superseded “Allocation interface” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M02.04-C007-T09 · Repeat and compare:** Repeat the selected “Allocation interface” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M02.04-C007-T10 · Failure evidence:** Publish the “Allocation interface” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M02.04-C008 · Bounds

**Original checklist item:** Choose, document and test limits for allocation request size and call rate; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M02.04-C008-T01 · Quantity inventory:** Create a measurement inventory for “Allocation interface”: “Allocation request size and call rate”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M02.04-C008-T02 · Measurement method:** Choose how to observe each “Allocation interface” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M02.04-C008-T03 · Budget decision:** Select justified resource and input limits for “Allocation interface”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M02.04-C008-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Allocation interface” cases for “Allocation request size and call rate”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M02.04-C008-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Allocation interface” limit; preserve “Callers can distinguish allocation failure from valid memory”.
- [ ] **UC-M02.04-C008-T06 · Normal measurement:** Run or review the normal “Allocation interface” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M02.04-C008-T07 · At-limit measurement:** Exercise the “Allocation interface” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M02.04-C008-T08 · Over-limit measurement:** Exercise the “Allocation interface” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M02.04-C008-T09 · Uncovered-scope report:** List the “Allocation interface” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M02.04-C008-T10 · Limit evidence:** Publish the selected “Allocation interface” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M02.04-C009 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for allocation interface with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M02.04-C009-T01 · Event inventory:** List the “Allocation interface” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M02.04-C009-T02 · Diagnostic schema:** Define nonsecret fields for “Allocation interface” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M02.04-C009-T03 · Failure mapping:** Map each documented “Allocation interface” refusal or error to a diagnostic outcome; include “An allocation failure is returned as an apparently valid address” and prohibit conversion into a success message.
- [ ] **UC-M02.04-C009-T04 · Emission path:** Add the “Allocation interface” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M02.04-C009-T05 · Redaction check:** Test “Allocation interface” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M02.04-C009-T06 · Output budget:** Set and exercise bounded “Allocation interface” message size, rate and retention compatible with “Allocation request size and call rate”; define truncation behavior that preserves the final reason.
- [ ] **UC-M02.04-C009-T07 · Success/refusal fixtures:** Capture “Allocation interface” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M02.04-C009-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Allocation interface” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M02.04-C009-T09 · Operator review:** Read the “Allocation interface” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M02.04-C009-T10 · Diagnostic evidence:** Publish redacted “Allocation interface” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M02.04-C010 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for allocation interface; label unexecuted checks as untested.

- [ ] **UC-M02.04-C010-T01 · Evidence inventory:** List the “Allocation interface” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M02.04-C010-T02 · Artifact references:** Record the exact “Allocation interface” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M02.04-C010-T03 · Fixture references:** Attach the “Allocation interface” fixture IDs, input identities and oracle definition; preserve the source counterexample “An allocation failure is returned as an apparently valid address” as a distinct evidence case.
- [ ] **UC-M02.04-C010-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Allocation interface”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M02.04-C010-T05 · Environment record:** Record the actual “Allocation interface” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M02.04-C010-T06 · Expected versus observed:** Pair every “Allocation interface” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M02.04-C010-T07 · Failure and limit records:** Attach “Allocation interface” change/failure and bounds evidence where required; include uncovered “Allocation request size and call rate” and unresolved violations of “Callers can distinguish allocation failure from valid memory”.
- [ ] **UC-M02.04-C010-T08 · Evidence hygiene:** Check the “Allocation interface” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M02.04-C010-T09 · Reproduction review:** Have the “Allocation interface” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M02.04-C010-T10 · Acceptance linkage:** Link the “Allocation interface” evidence to its parent and UC-M02.04 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 02. Guest heap budget

**Source delivery:** Set an explicit heap budget derived from the selected guest memory allocation.

**Source invariant:** Guest allocation cannot exceed its assigned heap region.

**Source negative case:** A workload repeatedly allocates beyond the configured heap budget.

**Source bounded quantities:** Heap bytes and per-allocation maximum.

### UC-M02.04-C011 · Contract

**Original checklist item:** Specify guest heap budget inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M02.04-C011-T01 · Scope statement:** Draft the operation boundary for “Guest heap budget” within Guest allocator and memory lifecycle; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M02.04-C011-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Guest heap budget”; record each producer, representation and missing-value meaning.
- [ ] **UC-M02.04-C011-T03 · Output inventory:** List the outputs of “Guest heap budget” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M02.04-C011-T04 · Field dictionary:** Create a field-and-term dictionary for “Guest heap budget”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M02.04-C011-T05 · Prerequisite contract:** Map “Guest heap budget” to the source component prerequisites (UC-M02.03); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M02.04-C011-T06 · Authority map:** Identify who may produce, change and consume “Guest heap budget”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M02.04-C011-T07 · Invariant clause:** Add a normative clause for “Guest heap budget” that preserves “Guest allocation cannot exceed its assigned heap region”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M02.04-C011-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Guest heap budget”; include the source counterexample “A workload repeatedly allocates beyond the configured heap budget” and the intended safe disposition.
- [ ] **UC-M02.04-C011-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Heap bytes and per-allocation maximum” in the “Guest heap budget” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M02.04-C011-T10 · Contract review:** Review the “Guest heap budget” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M02.04-C012 · Delivery

**Original checklist item:** Set an explicit heap budget derived from the selected guest memory allocation.

- [ ] **UC-M02.04-C012-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Guest heap budget”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M02.04-C012-T02 · Change plan:** Break the source delivery for “Guest heap budget” into concrete edit targets and reviewable outputs; keep the UC-M02.04 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M02.04-C012-T03 · Core artifact:** Implement the smallest selected-profile change for “Guest heap budget” that realizes this source instruction: Set an explicit heap budget derived from the selected guest memory allocation.
- [ ] **UC-M02.04-C012-T04 · Concrete realization:** Trace “Guest heap budget” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M02.04-C012-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Guest heap budget” needed to preserve “Guest allocation cannot exceed its assigned heap region”; record an enforcement gap where only a model exists.
- [ ] **UC-M02.04-C012-T06 · Dependency connection:** Connect the “Guest heap budget” implementation to guest runtime allocations, stack setup and host-assigned memory regions; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M02.04-C012-T07 · Resource behavior:** Account for “Heap bytes and per-allocation maximum” in “Guest heap budget”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M02.04-C012-T08 · Delivery check:** Run the smallest real “Guest heap budget” path and its adverse fixture “A workload repeatedly allocates beyond the configured heap budget”; retain actual output, state effects and final disposition.
- [ ] **UC-M02.04-C012-T09 · Patch review:** Review the “Guest heap budget” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M02.04-C012-T10 · Delivery handoff:** Publish the “Guest heap budget” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M02.04-C013 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Guest allocation cannot exceed its assigned heap region. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M02.04-C013-T01 · Named property:** Create a stable property/check name under this parent for “Guest heap budget”; copy its required invariant exactly: “Guest allocation cannot exceed its assigned heap region”.
- [ ] **UC-M02.04-C013-T02 · Observable terms:** Define each term in the “Guest heap budget” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M02.04-C013-T03 · Precondition set:** List the preconditions under which “Guest allocation cannot exceed its assigned heap region” must hold for “Guest heap budget”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M02.04-C013-T04 · Transition coverage:** Map the “Guest heap budget” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M02.04-C013-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Guest heap budget”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M02.04-C013-T06 · Satisfying fixture:** Create a concrete “Guest heap budget” case that satisfies “Guest allocation cannot exceed its assigned heap region”; record its expected observation before running the assertion or review.
- [ ] **UC-M02.04-C013-T07 · Violating fixture:** Create the source counterexample “A workload repeatedly allocates beyond the configured heap budget” for “Guest heap budget”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M02.04-C013-T08 · Enforcement evidence:** Exercise the “Guest heap budget” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M02.04-C013-T09 · Regression linkage:** Link the “Guest heap budget” property to changes in guest runtime allocations, stack setup and host-assigned memory regions; record which dependency or contract changes require rerunning it.
- [ ] **UC-M02.04-C013-T10 · Property disposition:** Compare the satisfying and violating “Guest heap budget” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M02.04-C014 · Integration

**Original checklist item:** Integrate guest heap budget with guest runtime allocations, stack setup and host-assigned memory regions; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M02.04-C014-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Guest heap budget” across guest runtime allocations, stack setup and host-assigned memory regions; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M02.04-C014-T02 · Field mapping:** Map every “Guest heap budget” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M02.04-C014-T03 · Prerequisite identities:** Record the actual prerequisites for “Guest heap budget” (source dependency list: UC-M02.03); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M02.04-C014-T04 · Ownership agreement:** Specify who owns “Guest heap budget” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M02.04-C014-T05 · Handoff implementation:** Connect “Guest heap budget” through the mapped seam using the real adapter or explicit specification reference; preserve “Guest allocation cannot exceed its assigned heap region” across the handoff.
- [ ] **UC-M02.04-C014-T06 · Absent-input case:** Omit one required “Guest heap budget” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M02.04-C014-T07 · Stale-input case:** Supply an outdated “Guest heap budget” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M02.04-C014-T08 · Incompatible-input case:** Supply an incompatible “Guest heap budget” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M02.04-C014-T09 · Valid integration trace:** Run a valid “Guest heap budget” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M02.04-C014-T10 · Seam review:** Reconcile the “Guest heap budget” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M02.04-C015 · Valid-case test

**Original checklist item:** Run a valid-path fixture for guest heap budget; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M02.04-C015-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Guest heap budget” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M02.04-C015-T02 · Expected-result oracle:** Specify the “Guest heap budget” expected result independently of the implementation output; include the property “Guest allocation cannot exceed its assigned heap region” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M02.04-C015-T03 · Fixture material:** Create the concrete “Guest heap budget” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M02.04-C015-T04 · Target preparation:** Prepare the “Guest heap budget” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M02.04-C015-T05 · Initial-state record:** Record the initial “Guest heap budget” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M02.04-C015-T06 · Valid-path execution:** Execute the “Guest heap budget” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M02.04-C015-T07 · Outcome comparison:** Compare every declared “Guest heap budget” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M02.04-C015-T08 · State and bounds check:** Inspect the “Guest heap budget” ownership/state effects and actual use of “Heap bytes and per-allocation maximum”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M02.04-C015-T09 · Repeatability check:** Repeat the same “Guest heap budget” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M02.04-C015-T10 · Positive evidence:** Attach the “Guest heap budget” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M02.04-C016 · Negative test

**Original checklist item:** Negative case: A workload repeatedly allocates beyond the configured heap budget. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M02.04-C016-T01 · Adverse-case definition:** Create a test record for the exact “Guest heap budget” source counterexample: “A workload repeatedly allocates beyond the configured heap budget”; state which precondition or invariant it challenges.
- [ ] **UC-M02.04-C016-T02 · Safe fixture boundary:** Define the contained test boundary for “Guest heap budget”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M02.04-C016-T03 · Valid control:** Construct a valid “Guest heap budget” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M02.04-C016-T04 · Minimal adverse input:** Derive the “Guest heap budget” adverse fixture from the control with the smallest documented change needed to reproduce “A workload repeatedly allocates beyond the configured heap budget”; retain that change as reproducible data.
- [ ] **UC-M02.04-C016-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Guest heap budget”; require “Guest allocation cannot exceed its assigned heap region” and forbid a false-success verdict.
- [ ] **UC-M02.04-C016-T06 · Adverse execution:** Exercise the “Guest heap budget” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M02.04-C016-T07 · Effect inspection:** Inspect “Guest heap budget” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M02.04-C016-T08 · Refusal versus failure:** Confirm the “Guest heap budget” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M02.04-C016-T09 · Reset and retention:** Restore only the disposable “Guest heap budget” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M02.04-C016-T10 · Negative regression:** Register the “Guest heap budget” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M02.04-C017 · Change / failure test

**Original checklist item:** Exercise guest heap budget when an invocation fails during allocation and a subsequent invocation starts; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M02.04-C017-T01 · Scenario record:** Write the “Guest heap budget” change/failure scenario exactly as supplied: an invocation fails during allocation and a subsequent invocation starts; identify the property that must remain true: “Guest allocation cannot exceed its assigned heap region”.
- [ ] **UC-M02.04-C017-T02 · Baseline capture:** Create a known-valid “Guest heap budget” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M02.04-C017-T03 · Injection map:** Locate the “Guest heap budget” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M02.04-C017-T04 · Disposition oracle:** Define the legal intermediate and final “Guest heap budget” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M02.04-C017-T05 · Controlled trigger:** Introduce the controlled “Guest heap budget” scenario in the disposable fixture: an invocation fails during allocation and a subsequent invocation starts; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M02.04-C017-T06 · Intermediate inspection:** Inspect the “Guest heap budget” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M02.04-C017-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Guest heap budget”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M02.04-C017-T08 · Stale-evidence cleanup:** Invalidate superseded “Guest heap budget” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M02.04-C017-T09 · Repeat and compare:** Repeat the selected “Guest heap budget” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M02.04-C017-T10 · Failure evidence:** Publish the “Guest heap budget” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M02.04-C018 · Bounds

**Original checklist item:** Choose, document and test limits for heap bytes and per-allocation maximum; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M02.04-C018-T01 · Quantity inventory:** Create a measurement inventory for “Guest heap budget”: “Heap bytes and per-allocation maximum”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M02.04-C018-T02 · Measurement method:** Choose how to observe each “Guest heap budget” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M02.04-C018-T03 · Budget decision:** Select justified resource and input limits for “Guest heap budget”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M02.04-C018-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Guest heap budget” cases for “Heap bytes and per-allocation maximum”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M02.04-C018-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Guest heap budget” limit; preserve “Guest allocation cannot exceed its assigned heap region”.
- [ ] **UC-M02.04-C018-T06 · Normal measurement:** Run or review the normal “Guest heap budget” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M02.04-C018-T07 · At-limit measurement:** Exercise the “Guest heap budget” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M02.04-C018-T08 · Over-limit measurement:** Exercise the “Guest heap budget” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M02.04-C018-T09 · Uncovered-scope report:** List the “Guest heap budget” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M02.04-C018-T10 · Limit evidence:** Publish the selected “Guest heap budget” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M02.04-C019 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for guest heap budget with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M02.04-C019-T01 · Event inventory:** List the “Guest heap budget” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M02.04-C019-T02 · Diagnostic schema:** Define nonsecret fields for “Guest heap budget” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M02.04-C019-T03 · Failure mapping:** Map each documented “Guest heap budget” refusal or error to a diagnostic outcome; include “A workload repeatedly allocates beyond the configured heap budget” and prohibit conversion into a success message.
- [ ] **UC-M02.04-C019-T04 · Emission path:** Add the “Guest heap budget” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M02.04-C019-T05 · Redaction check:** Test “Guest heap budget” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M02.04-C019-T06 · Output budget:** Set and exercise bounded “Guest heap budget” message size, rate and retention compatible with “Heap bytes and per-allocation maximum”; define truncation behavior that preserves the final reason.
- [ ] **UC-M02.04-C019-T07 · Success/refusal fixtures:** Capture “Guest heap budget” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M02.04-C019-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Guest heap budget” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M02.04-C019-T09 · Operator review:** Read the “Guest heap budget” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M02.04-C019-T10 · Diagnostic evidence:** Publish redacted “Guest heap budget” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M02.04-C020 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for guest heap budget; label unexecuted checks as untested.

- [ ] **UC-M02.04-C020-T01 · Evidence inventory:** List the “Guest heap budget” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M02.04-C020-T02 · Artifact references:** Record the exact “Guest heap budget” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M02.04-C020-T03 · Fixture references:** Attach the “Guest heap budget” fixture IDs, input identities and oracle definition; preserve the source counterexample “A workload repeatedly allocates beyond the configured heap budget” as a distinct evidence case.
- [ ] **UC-M02.04-C020-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Guest heap budget”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M02.04-C020-T05 · Environment record:** Record the actual “Guest heap budget” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M02.04-C020-T06 · Expected versus observed:** Pair every “Guest heap budget” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M02.04-C020-T07 · Failure and limit records:** Attach “Guest heap budget” change/failure and bounds evidence where required; include uncovered “Heap bytes and per-allocation maximum” and unresolved violations of “Guest allocation cannot exceed its assigned heap region”.
- [ ] **UC-M02.04-C020-T08 · Evidence hygiene:** Check the “Guest heap budget” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M02.04-C020-T09 · Reproduction review:** Have the “Guest heap budget” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M02.04-C020-T10 · Acceptance linkage:** Link the “Guest heap budget” evidence to its parent and UC-M02.04 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 03. Ownership model

**Source delivery:** Specify which runtime subsystem owns each allocated buffer and when it may release it.

**Source invariant:** A buffer has a documented owner throughout its lifetime.

**Source negative case:** Two subsystems both release the same shared buffer.

**Source bounded quantities:** Concurrent allocations and ownership metadata bytes.

### UC-M02.04-C021 · Contract

**Original checklist item:** Specify ownership model inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M02.04-C021-T01 · Scope statement:** Draft the operation boundary for “Ownership model” within Guest allocator and memory lifecycle; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M02.04-C021-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Ownership model”; record each producer, representation and missing-value meaning.
- [ ] **UC-M02.04-C021-T03 · Output inventory:** List the outputs of “Ownership model” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M02.04-C021-T04 · Field dictionary:** Create a field-and-term dictionary for “Ownership model”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M02.04-C021-T05 · Prerequisite contract:** Map “Ownership model” to the source component prerequisites (UC-M02.03); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M02.04-C021-T06 · Authority map:** Identify who may produce, change and consume “Ownership model”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M02.04-C021-T07 · Invariant clause:** Add a normative clause for “Ownership model” that preserves “A buffer has a documented owner throughout its lifetime”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M02.04-C021-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Ownership model”; include the source counterexample “Two subsystems both release the same shared buffer” and the intended safe disposition.
- [ ] **UC-M02.04-C021-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Concurrent allocations and ownership metadata bytes” in the “Ownership model” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M02.04-C021-T10 · Contract review:** Review the “Ownership model” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M02.04-C022 · Delivery

**Original checklist item:** Specify which runtime subsystem owns each allocated buffer and when it may release it.

- [ ] **UC-M02.04-C022-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Ownership model”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M02.04-C022-T02 · Change plan:** Break the source delivery for “Ownership model” into concrete edit targets and reviewable outputs; keep the UC-M02.04 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M02.04-C022-T03 · Core artifact:** Create the “Ownership model” model, schema or inventory that realizes this source instruction: Specify which runtime subsystem owns each allocated buffer and when it may release it.
- [ ] **UC-M02.04-C022-T04 · Concrete realization:** Populate “Ownership model” with one concrete worked case; map every required entity or field to its source and flag any unmapped entry.
- [ ] **UC-M02.04-C022-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Ownership model” needed to preserve “A buffer has a documented owner throughout its lifetime”; record an enforcement gap where only a model exists.
- [ ] **UC-M02.04-C022-T06 · Dependency connection:** Connect the “Ownership model” implementation to guest runtime allocations, stack setup and host-assigned memory regions; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M02.04-C022-T07 · Resource behavior:** Account for “Concurrent allocations and ownership metadata bytes” in “Ownership model”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M02.04-C022-T08 · Delivery check:** Run the smallest real “Ownership model” path and its adverse fixture “Two subsystems both release the same shared buffer”; retain actual output, state effects and final disposition.
- [ ] **UC-M02.04-C022-T09 · Patch review:** Review the “Ownership model” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M02.04-C022-T10 · Delivery handoff:** Publish the “Ownership model” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M02.04-C023 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: A buffer has a documented owner throughout its lifetime. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M02.04-C023-T01 · Named property:** Create a stable property/check name under this parent for “Ownership model”; copy its required invariant exactly: “A buffer has a documented owner throughout its lifetime”.
- [ ] **UC-M02.04-C023-T02 · Observable terms:** Define each term in the “Ownership model” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M02.04-C023-T03 · Precondition set:** List the preconditions under which “A buffer has a documented owner throughout its lifetime” must hold for “Ownership model”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M02.04-C023-T04 · Transition coverage:** Map the “Ownership model” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M02.04-C023-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Ownership model”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M02.04-C023-T06 · Satisfying fixture:** Create a concrete “Ownership model” case that satisfies “A buffer has a documented owner throughout its lifetime”; record its expected observation before running the assertion or review.
- [ ] **UC-M02.04-C023-T07 · Violating fixture:** Create the source counterexample “Two subsystems both release the same shared buffer” for “Ownership model”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M02.04-C023-T08 · Enforcement evidence:** Exercise the “Ownership model” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M02.04-C023-T09 · Regression linkage:** Link the “Ownership model” property to changes in guest runtime allocations, stack setup and host-assigned memory regions; record which dependency or contract changes require rerunning it.
- [ ] **UC-M02.04-C023-T10 · Property disposition:** Compare the satisfying and violating “Ownership model” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M02.04-C024 · Integration

**Original checklist item:** Integrate ownership model with guest runtime allocations, stack setup and host-assigned memory regions; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M02.04-C024-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Ownership model” across guest runtime allocations, stack setup and host-assigned memory regions; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M02.04-C024-T02 · Field mapping:** Map every “Ownership model” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M02.04-C024-T03 · Prerequisite identities:** Record the actual prerequisites for “Ownership model” (source dependency list: UC-M02.03); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M02.04-C024-T04 · Ownership agreement:** Specify who owns “Ownership model” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M02.04-C024-T05 · Handoff implementation:** Connect “Ownership model” through the mapped seam using the real adapter or explicit specification reference; preserve “A buffer has a documented owner throughout its lifetime” across the handoff.
- [ ] **UC-M02.04-C024-T06 · Absent-input case:** Omit one required “Ownership model” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M02.04-C024-T07 · Stale-input case:** Supply an outdated “Ownership model” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M02.04-C024-T08 · Incompatible-input case:** Supply an incompatible “Ownership model” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M02.04-C024-T09 · Valid integration trace:** Run a valid “Ownership model” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M02.04-C024-T10 · Seam review:** Reconcile the “Ownership model” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M02.04-C025 · Valid-case test

**Original checklist item:** Run a valid-path fixture for ownership model; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M02.04-C025-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Ownership model” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M02.04-C025-T02 · Expected-result oracle:** Specify the “Ownership model” expected result independently of the implementation output; include the property “A buffer has a documented owner throughout its lifetime” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M02.04-C025-T03 · Fixture material:** Create the concrete “Ownership model” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M02.04-C025-T04 · Target preparation:** Prepare the “Ownership model” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M02.04-C025-T05 · Initial-state record:** Record the initial “Ownership model” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M02.04-C025-T06 · Valid-path execution:** Execute the “Ownership model” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M02.04-C025-T07 · Outcome comparison:** Compare every declared “Ownership model” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M02.04-C025-T08 · State and bounds check:** Inspect the “Ownership model” ownership/state effects and actual use of “Concurrent allocations and ownership metadata bytes”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M02.04-C025-T09 · Repeatability check:** Repeat the same “Ownership model” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M02.04-C025-T10 · Positive evidence:** Attach the “Ownership model” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M02.04-C026 · Negative test

**Original checklist item:** Negative case: Two subsystems both release the same shared buffer. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M02.04-C026-T01 · Adverse-case definition:** Create a test record for the exact “Ownership model” source counterexample: “Two subsystems both release the same shared buffer”; state which precondition or invariant it challenges.
- [ ] **UC-M02.04-C026-T02 · Safe fixture boundary:** Define the contained test boundary for “Ownership model”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M02.04-C026-T03 · Valid control:** Construct a valid “Ownership model” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M02.04-C026-T04 · Minimal adverse input:** Derive the “Ownership model” adverse fixture from the control with the smallest documented change needed to reproduce “Two subsystems both release the same shared buffer”; retain that change as reproducible data.
- [ ] **UC-M02.04-C026-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Ownership model”; require “A buffer has a documented owner throughout its lifetime” and forbid a false-success verdict.
- [ ] **UC-M02.04-C026-T06 · Adverse execution:** Exercise the “Ownership model” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M02.04-C026-T07 · Effect inspection:** Inspect “Ownership model” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M02.04-C026-T08 · Refusal versus failure:** Confirm the “Ownership model” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M02.04-C026-T09 · Reset and retention:** Restore only the disposable “Ownership model” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M02.04-C026-T10 · Negative regression:** Register the “Ownership model” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M02.04-C027 · Change / failure test

**Original checklist item:** Exercise ownership model when an invocation fails during allocation and a subsequent invocation starts; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M02.04-C027-T01 · Scenario record:** Write the “Ownership model” change/failure scenario exactly as supplied: an invocation fails during allocation and a subsequent invocation starts; identify the property that must remain true: “A buffer has a documented owner throughout its lifetime”.
- [ ] **UC-M02.04-C027-T02 · Baseline capture:** Create a known-valid “Ownership model” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M02.04-C027-T03 · Injection map:** Locate the “Ownership model” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M02.04-C027-T04 · Disposition oracle:** Define the legal intermediate and final “Ownership model” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M02.04-C027-T05 · Controlled trigger:** Introduce the controlled “Ownership model” scenario in the disposable fixture: an invocation fails during allocation and a subsequent invocation starts; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M02.04-C027-T06 · Intermediate inspection:** Inspect the “Ownership model” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M02.04-C027-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Ownership model”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M02.04-C027-T08 · Stale-evidence cleanup:** Invalidate superseded “Ownership model” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M02.04-C027-T09 · Repeat and compare:** Repeat the selected “Ownership model” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M02.04-C027-T10 · Failure evidence:** Publish the “Ownership model” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M02.04-C028 · Bounds

**Original checklist item:** Choose, document and test limits for concurrent allocations and ownership metadata bytes; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M02.04-C028-T01 · Quantity inventory:** Create a measurement inventory for “Ownership model”: “Concurrent allocations and ownership metadata bytes”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M02.04-C028-T02 · Measurement method:** Choose how to observe each “Ownership model” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M02.04-C028-T03 · Budget decision:** Select justified resource and input limits for “Ownership model”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M02.04-C028-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Ownership model” cases for “Concurrent allocations and ownership metadata bytes”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M02.04-C028-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Ownership model” limit; preserve “A buffer has a documented owner throughout its lifetime”.
- [ ] **UC-M02.04-C028-T06 · Normal measurement:** Run or review the normal “Ownership model” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M02.04-C028-T07 · At-limit measurement:** Exercise the “Ownership model” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M02.04-C028-T08 · Over-limit measurement:** Exercise the “Ownership model” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M02.04-C028-T09 · Uncovered-scope report:** List the “Ownership model” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M02.04-C028-T10 · Limit evidence:** Publish the selected “Ownership model” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M02.04-C029 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for ownership model with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M02.04-C029-T01 · Event inventory:** List the “Ownership model” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M02.04-C029-T02 · Diagnostic schema:** Define nonsecret fields for “Ownership model” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M02.04-C029-T03 · Failure mapping:** Map each documented “Ownership model” refusal or error to a diagnostic outcome; include “Two subsystems both release the same shared buffer” and prohibit conversion into a success message.
- [ ] **UC-M02.04-C029-T04 · Emission path:** Add the “Ownership model” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M02.04-C029-T05 · Redaction check:** Test “Ownership model” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M02.04-C029-T06 · Output budget:** Set and exercise bounded “Ownership model” message size, rate and retention compatible with “Concurrent allocations and ownership metadata bytes”; define truncation behavior that preserves the final reason.
- [ ] **UC-M02.04-C029-T07 · Success/refusal fixtures:** Capture “Ownership model” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M02.04-C029-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Ownership model” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M02.04-C029-T09 · Operator review:** Read the “Ownership model” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M02.04-C029-T10 · Diagnostic evidence:** Publish redacted “Ownership model” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M02.04-C030 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for ownership model; label unexecuted checks as untested.

- [ ] **UC-M02.04-C030-T01 · Evidence inventory:** List the “Ownership model” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M02.04-C030-T02 · Artifact references:** Record the exact “Ownership model” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M02.04-C030-T03 · Fixture references:** Attach the “Ownership model” fixture IDs, input identities and oracle definition; preserve the source counterexample “Two subsystems both release the same shared buffer” as a distinct evidence case.
- [ ] **UC-M02.04-C030-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Ownership model”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M02.04-C030-T05 · Environment record:** Record the actual “Ownership model” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M02.04-C030-T06 · Expected versus observed:** Pair every “Ownership model” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M02.04-C030-T07 · Failure and limit records:** Attach “Ownership model” change/failure and bounds evidence where required; include uncovered “Concurrent allocations and ownership metadata bytes” and unresolved violations of “A buffer has a documented owner throughout its lifetime”.
- [ ] **UC-M02.04-C030-T08 · Evidence hygiene:** Check the “Ownership model” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M02.04-C030-T09 · Reproduction review:** Have the “Ownership model” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M02.04-C030-T10 · Acceptance linkage:** Link the “Ownership model” evidence to its parent and UC-M02.04 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 04. Allocator metadata bounds

**Source delivery:** Protect allocator bookkeeping from malformed sizes and arithmetic overflow.

**Source invariant:** A requested size cannot corrupt allocation metadata.

**Source negative case:** A near-maximum request wraps an allocation-size calculation.

**Source bounded quantities:** Metadata bytes and supported allocation size range.

### UC-M02.04-C031 · Contract

**Original checklist item:** Specify allocator metadata bounds inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M02.04-C031-T01 · Scope statement:** Draft the operation boundary for “Allocator metadata bounds” within Guest allocator and memory lifecycle; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M02.04-C031-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Allocator metadata bounds”; record each producer, representation and missing-value meaning.
- [ ] **UC-M02.04-C031-T03 · Output inventory:** List the outputs of “Allocator metadata bounds” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M02.04-C031-T04 · Field dictionary:** Create a field-and-term dictionary for “Allocator metadata bounds”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M02.04-C031-T05 · Prerequisite contract:** Map “Allocator metadata bounds” to the source component prerequisites (UC-M02.03); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M02.04-C031-T06 · Authority map:** Identify who may produce, change and consume “Allocator metadata bounds”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M02.04-C031-T07 · Invariant clause:** Add a normative clause for “Allocator metadata bounds” that preserves “A requested size cannot corrupt allocation metadata”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M02.04-C031-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Allocator metadata bounds”; include the source counterexample “A near-maximum request wraps an allocation-size calculation” and the intended safe disposition.
- [ ] **UC-M02.04-C031-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Metadata bytes and supported allocation size range” in the “Allocator metadata bounds” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M02.04-C031-T10 · Contract review:** Review the “Allocator metadata bounds” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M02.04-C032 · Delivery

**Original checklist item:** Protect allocator bookkeeping from malformed sizes and arithmetic overflow.

- [ ] **UC-M02.04-C032-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Allocator metadata bounds”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M02.04-C032-T02 · Change plan:** Break the source delivery for “Allocator metadata bounds” into concrete edit targets and reviewable outputs; keep the UC-M02.04 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M02.04-C032-T03 · Core artifact:** Implement the smallest selected-profile change for “Allocator metadata bounds” that realizes this source instruction: Protect allocator bookkeeping from malformed sizes and arithmetic overflow.
- [ ] **UC-M02.04-C032-T04 · Concrete realization:** Trace “Allocator metadata bounds” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M02.04-C032-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Allocator metadata bounds” needed to preserve “A requested size cannot corrupt allocation metadata”; record an enforcement gap where only a model exists.
- [ ] **UC-M02.04-C032-T06 · Dependency connection:** Connect the “Allocator metadata bounds” implementation to guest runtime allocations, stack setup and host-assigned memory regions; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M02.04-C032-T07 · Resource behavior:** Account for “Metadata bytes and supported allocation size range” in “Allocator metadata bounds”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M02.04-C032-T08 · Delivery check:** Run the smallest real “Allocator metadata bounds” path and its adverse fixture “A near-maximum request wraps an allocation-size calculation”; retain actual output, state effects and final disposition.
- [ ] **UC-M02.04-C032-T09 · Patch review:** Review the “Allocator metadata bounds” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M02.04-C032-T10 · Delivery handoff:** Publish the “Allocator metadata bounds” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M02.04-C033 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: A requested size cannot corrupt allocation metadata. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M02.04-C033-T01 · Named property:** Create a stable property/check name under this parent for “Allocator metadata bounds”; copy its required invariant exactly: “A requested size cannot corrupt allocation metadata”.
- [ ] **UC-M02.04-C033-T02 · Observable terms:** Define each term in the “Allocator metadata bounds” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M02.04-C033-T03 · Precondition set:** List the preconditions under which “A requested size cannot corrupt allocation metadata” must hold for “Allocator metadata bounds”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M02.04-C033-T04 · Transition coverage:** Map the “Allocator metadata bounds” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M02.04-C033-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Allocator metadata bounds”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M02.04-C033-T06 · Satisfying fixture:** Create a concrete “Allocator metadata bounds” case that satisfies “A requested size cannot corrupt allocation metadata”; record its expected observation before running the assertion or review.
- [ ] **UC-M02.04-C033-T07 · Violating fixture:** Create the source counterexample “A near-maximum request wraps an allocation-size calculation” for “Allocator metadata bounds”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M02.04-C033-T08 · Enforcement evidence:** Exercise the “Allocator metadata bounds” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M02.04-C033-T09 · Regression linkage:** Link the “Allocator metadata bounds” property to changes in guest runtime allocations, stack setup and host-assigned memory regions; record which dependency or contract changes require rerunning it.
- [ ] **UC-M02.04-C033-T10 · Property disposition:** Compare the satisfying and violating “Allocator metadata bounds” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M02.04-C034 · Integration

**Original checklist item:** Integrate allocator metadata bounds with guest runtime allocations, stack setup and host-assigned memory regions; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M02.04-C034-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Allocator metadata bounds” across guest runtime allocations, stack setup and host-assigned memory regions; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M02.04-C034-T02 · Field mapping:** Map every “Allocator metadata bounds” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M02.04-C034-T03 · Prerequisite identities:** Record the actual prerequisites for “Allocator metadata bounds” (source dependency list: UC-M02.03); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M02.04-C034-T04 · Ownership agreement:** Specify who owns “Allocator metadata bounds” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M02.04-C034-T05 · Handoff implementation:** Connect “Allocator metadata bounds” through the mapped seam using the real adapter or explicit specification reference; preserve “A requested size cannot corrupt allocation metadata” across the handoff.
- [ ] **UC-M02.04-C034-T06 · Absent-input case:** Omit one required “Allocator metadata bounds” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M02.04-C034-T07 · Stale-input case:** Supply an outdated “Allocator metadata bounds” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M02.04-C034-T08 · Incompatible-input case:** Supply an incompatible “Allocator metadata bounds” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M02.04-C034-T09 · Valid integration trace:** Run a valid “Allocator metadata bounds” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M02.04-C034-T10 · Seam review:** Reconcile the “Allocator metadata bounds” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M02.04-C035 · Valid-case test

**Original checklist item:** Run a valid-path fixture for allocator metadata bounds; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M02.04-C035-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Allocator metadata bounds” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M02.04-C035-T02 · Expected-result oracle:** Specify the “Allocator metadata bounds” expected result independently of the implementation output; include the property “A requested size cannot corrupt allocation metadata” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M02.04-C035-T03 · Fixture material:** Create the concrete “Allocator metadata bounds” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M02.04-C035-T04 · Target preparation:** Prepare the “Allocator metadata bounds” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M02.04-C035-T05 · Initial-state record:** Record the initial “Allocator metadata bounds” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M02.04-C035-T06 · Valid-path execution:** Execute the “Allocator metadata bounds” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M02.04-C035-T07 · Outcome comparison:** Compare every declared “Allocator metadata bounds” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M02.04-C035-T08 · State and bounds check:** Inspect the “Allocator metadata bounds” ownership/state effects and actual use of “Metadata bytes and supported allocation size range”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M02.04-C035-T09 · Repeatability check:** Repeat the same “Allocator metadata bounds” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M02.04-C035-T10 · Positive evidence:** Attach the “Allocator metadata bounds” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M02.04-C036 · Negative test

**Original checklist item:** Negative case: A near-maximum request wraps an allocation-size calculation. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M02.04-C036-T01 · Adverse-case definition:** Create a test record for the exact “Allocator metadata bounds” source counterexample: “A near-maximum request wraps an allocation-size calculation”; state which precondition or invariant it challenges.
- [ ] **UC-M02.04-C036-T02 · Safe fixture boundary:** Define the contained test boundary for “Allocator metadata bounds”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M02.04-C036-T03 · Valid control:** Construct a valid “Allocator metadata bounds” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M02.04-C036-T04 · Minimal adverse input:** Derive the “Allocator metadata bounds” adverse fixture from the control with the smallest documented change needed to reproduce “A near-maximum request wraps an allocation-size calculation”; retain that change as reproducible data.
- [ ] **UC-M02.04-C036-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Allocator metadata bounds”; require “A requested size cannot corrupt allocation metadata” and forbid a false-success verdict.
- [ ] **UC-M02.04-C036-T06 · Adverse execution:** Exercise the “Allocator metadata bounds” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M02.04-C036-T07 · Effect inspection:** Inspect “Allocator metadata bounds” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M02.04-C036-T08 · Refusal versus failure:** Confirm the “Allocator metadata bounds” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M02.04-C036-T09 · Reset and retention:** Restore only the disposable “Allocator metadata bounds” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M02.04-C036-T10 · Negative regression:** Register the “Allocator metadata bounds” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M02.04-C037 · Change / failure test

**Original checklist item:** Exercise allocator metadata bounds when an invocation fails during allocation and a subsequent invocation starts; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M02.04-C037-T01 · Scenario record:** Write the “Allocator metadata bounds” change/failure scenario exactly as supplied: an invocation fails during allocation and a subsequent invocation starts; identify the property that must remain true: “A requested size cannot corrupt allocation metadata”.
- [ ] **UC-M02.04-C037-T02 · Baseline capture:** Create a known-valid “Allocator metadata bounds” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M02.04-C037-T03 · Injection map:** Locate the “Allocator metadata bounds” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M02.04-C037-T04 · Disposition oracle:** Define the legal intermediate and final “Allocator metadata bounds” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M02.04-C037-T05 · Controlled trigger:** Introduce the controlled “Allocator metadata bounds” scenario in the disposable fixture: an invocation fails during allocation and a subsequent invocation starts; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M02.04-C037-T06 · Intermediate inspection:** Inspect the “Allocator metadata bounds” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M02.04-C037-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Allocator metadata bounds”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M02.04-C037-T08 · Stale-evidence cleanup:** Invalidate superseded “Allocator metadata bounds” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M02.04-C037-T09 · Repeat and compare:** Repeat the selected “Allocator metadata bounds” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M02.04-C037-T10 · Failure evidence:** Publish the “Allocator metadata bounds” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M02.04-C038 · Bounds

**Original checklist item:** Choose, document and test limits for metadata bytes and supported allocation size range; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M02.04-C038-T01 · Quantity inventory:** Create a measurement inventory for “Allocator metadata bounds”: “Metadata bytes and supported allocation size range”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M02.04-C038-T02 · Measurement method:** Choose how to observe each “Allocator metadata bounds” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M02.04-C038-T03 · Budget decision:** Select justified resource and input limits for “Allocator metadata bounds”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M02.04-C038-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Allocator metadata bounds” cases for “Metadata bytes and supported allocation size range”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M02.04-C038-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Allocator metadata bounds” limit; preserve “A requested size cannot corrupt allocation metadata”.
- [ ] **UC-M02.04-C038-T06 · Normal measurement:** Run or review the normal “Allocator metadata bounds” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M02.04-C038-T07 · At-limit measurement:** Exercise the “Allocator metadata bounds” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M02.04-C038-T08 · Over-limit measurement:** Exercise the “Allocator metadata bounds” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M02.04-C038-T09 · Uncovered-scope report:** List the “Allocator metadata bounds” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M02.04-C038-T10 · Limit evidence:** Publish the selected “Allocator metadata bounds” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M02.04-C039 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for allocator metadata bounds with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M02.04-C039-T01 · Event inventory:** List the “Allocator metadata bounds” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M02.04-C039-T02 · Diagnostic schema:** Define nonsecret fields for “Allocator metadata bounds” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M02.04-C039-T03 · Failure mapping:** Map each documented “Allocator metadata bounds” refusal or error to a diagnostic outcome; include “A near-maximum request wraps an allocation-size calculation” and prohibit conversion into a success message.
- [ ] **UC-M02.04-C039-T04 · Emission path:** Add the “Allocator metadata bounds” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M02.04-C039-T05 · Redaction check:** Test “Allocator metadata bounds” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M02.04-C039-T06 · Output budget:** Set and exercise bounded “Allocator metadata bounds” message size, rate and retention compatible with “Metadata bytes and supported allocation size range”; define truncation behavior that preserves the final reason.
- [ ] **UC-M02.04-C039-T07 · Success/refusal fixtures:** Capture “Allocator metadata bounds” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M02.04-C039-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Allocator metadata bounds” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M02.04-C039-T09 · Operator review:** Read the “Allocator metadata bounds” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M02.04-C039-T10 · Diagnostic evidence:** Publish redacted “Allocator metadata bounds” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M02.04-C040 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for allocator metadata bounds; label unexecuted checks as untested.

- [ ] **UC-M02.04-C040-T01 · Evidence inventory:** List the “Allocator metadata bounds” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M02.04-C040-T02 · Artifact references:** Record the exact “Allocator metadata bounds” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M02.04-C040-T03 · Fixture references:** Attach the “Allocator metadata bounds” fixture IDs, input identities and oracle definition; preserve the source counterexample “A near-maximum request wraps an allocation-size calculation” as a distinct evidence case.
- [ ] **UC-M02.04-C040-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Allocator metadata bounds”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M02.04-C040-T05 · Environment record:** Record the actual “Allocator metadata bounds” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M02.04-C040-T06 · Expected versus observed:** Pair every “Allocator metadata bounds” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M02.04-C040-T07 · Failure and limit records:** Attach “Allocator metadata bounds” change/failure and bounds evidence where required; include uncovered “Metadata bytes and supported allocation size range” and unresolved violations of “A requested size cannot corrupt allocation metadata”.
- [ ] **UC-M02.04-C040-T08 · Evidence hygiene:** Check the “Allocator metadata bounds” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M02.04-C040-T09 · Reproduction review:** Have the “Allocator metadata bounds” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M02.04-C040-T10 · Acceptance linkage:** Link the “Allocator metadata bounds” evidence to its parent and UC-M02.04 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 05. Alignment guarantees

**Source delivery:** Provide the alignment guarantees required by the selected engine and ABI.

**Source invariant:** Returned memory meets the declared alignment contract.

**Source negative case:** A guest requests alignment unsupported by the allocator.

**Source bounded quantities:** Maximum alignment and padding overhead.

### UC-M02.04-C041 · Contract

**Original checklist item:** Specify alignment guarantees inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M02.04-C041-T01 · Scope statement:** Draft the operation boundary for “Alignment guarantees” within Guest allocator and memory lifecycle; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M02.04-C041-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Alignment guarantees”; record each producer, representation and missing-value meaning.
- [ ] **UC-M02.04-C041-T03 · Output inventory:** List the outputs of “Alignment guarantees” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M02.04-C041-T04 · Field dictionary:** Create a field-and-term dictionary for “Alignment guarantees”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M02.04-C041-T05 · Prerequisite contract:** Map “Alignment guarantees” to the source component prerequisites (UC-M02.03); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M02.04-C041-T06 · Authority map:** Identify who may produce, change and consume “Alignment guarantees”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M02.04-C041-T07 · Invariant clause:** Add a normative clause for “Alignment guarantees” that preserves “Returned memory meets the declared alignment contract”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M02.04-C041-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Alignment guarantees”; include the source counterexample “A guest requests alignment unsupported by the allocator” and the intended safe disposition.
- [ ] **UC-M02.04-C041-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Maximum alignment and padding overhead” in the “Alignment guarantees” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M02.04-C041-T10 · Contract review:** Review the “Alignment guarantees” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M02.04-C042 · Delivery

**Original checklist item:** Provide the alignment guarantees required by the selected engine and ABI.

- [ ] **UC-M02.04-C042-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Alignment guarantees”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M02.04-C042-T02 · Change plan:** Break the source delivery for “Alignment guarantees” into concrete edit targets and reviewable outputs; keep the UC-M02.04 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M02.04-C042-T03 · Core artifact:** Implement the smallest selected-profile change for “Alignment guarantees” that realizes this source instruction: Provide the alignment guarantees required by the selected engine and ABI.
- [ ] **UC-M02.04-C042-T04 · Concrete realization:** Trace “Alignment guarantees” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M02.04-C042-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Alignment guarantees” needed to preserve “Returned memory meets the declared alignment contract”; record an enforcement gap where only a model exists.
- [ ] **UC-M02.04-C042-T06 · Dependency connection:** Connect the “Alignment guarantees” implementation to guest runtime allocations, stack setup and host-assigned memory regions; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M02.04-C042-T07 · Resource behavior:** Account for “Maximum alignment and padding overhead” in “Alignment guarantees”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M02.04-C042-T08 · Delivery check:** Run the smallest real “Alignment guarantees” path and its adverse fixture “A guest requests alignment unsupported by the allocator”; retain actual output, state effects and final disposition.
- [ ] **UC-M02.04-C042-T09 · Patch review:** Review the “Alignment guarantees” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M02.04-C042-T10 · Delivery handoff:** Publish the “Alignment guarantees” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M02.04-C043 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Returned memory meets the declared alignment contract. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M02.04-C043-T01 · Named property:** Create a stable property/check name under this parent for “Alignment guarantees”; copy its required invariant exactly: “Returned memory meets the declared alignment contract”.
- [ ] **UC-M02.04-C043-T02 · Observable terms:** Define each term in the “Alignment guarantees” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M02.04-C043-T03 · Precondition set:** List the preconditions under which “Returned memory meets the declared alignment contract” must hold for “Alignment guarantees”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M02.04-C043-T04 · Transition coverage:** Map the “Alignment guarantees” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M02.04-C043-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Alignment guarantees”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M02.04-C043-T06 · Satisfying fixture:** Create a concrete “Alignment guarantees” case that satisfies “Returned memory meets the declared alignment contract”; record its expected observation before running the assertion or review.
- [ ] **UC-M02.04-C043-T07 · Violating fixture:** Create the source counterexample “A guest requests alignment unsupported by the allocator” for “Alignment guarantees”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M02.04-C043-T08 · Enforcement evidence:** Exercise the “Alignment guarantees” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M02.04-C043-T09 · Regression linkage:** Link the “Alignment guarantees” property to changes in guest runtime allocations, stack setup and host-assigned memory regions; record which dependency or contract changes require rerunning it.
- [ ] **UC-M02.04-C043-T10 · Property disposition:** Compare the satisfying and violating “Alignment guarantees” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M02.04-C044 · Integration

**Original checklist item:** Integrate alignment guarantees with guest runtime allocations, stack setup and host-assigned memory regions; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M02.04-C044-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Alignment guarantees” across guest runtime allocations, stack setup and host-assigned memory regions; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M02.04-C044-T02 · Field mapping:** Map every “Alignment guarantees” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M02.04-C044-T03 · Prerequisite identities:** Record the actual prerequisites for “Alignment guarantees” (source dependency list: UC-M02.03); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M02.04-C044-T04 · Ownership agreement:** Specify who owns “Alignment guarantees” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M02.04-C044-T05 · Handoff implementation:** Connect “Alignment guarantees” through the mapped seam using the real adapter or explicit specification reference; preserve “Returned memory meets the declared alignment contract” across the handoff.
- [ ] **UC-M02.04-C044-T06 · Absent-input case:** Omit one required “Alignment guarantees” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M02.04-C044-T07 · Stale-input case:** Supply an outdated “Alignment guarantees” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M02.04-C044-T08 · Incompatible-input case:** Supply an incompatible “Alignment guarantees” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M02.04-C044-T09 · Valid integration trace:** Run a valid “Alignment guarantees” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M02.04-C044-T10 · Seam review:** Reconcile the “Alignment guarantees” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M02.04-C045 · Valid-case test

**Original checklist item:** Run a valid-path fixture for alignment guarantees; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M02.04-C045-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Alignment guarantees” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M02.04-C045-T02 · Expected-result oracle:** Specify the “Alignment guarantees” expected result independently of the implementation output; include the property “Returned memory meets the declared alignment contract” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M02.04-C045-T03 · Fixture material:** Create the concrete “Alignment guarantees” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M02.04-C045-T04 · Target preparation:** Prepare the “Alignment guarantees” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M02.04-C045-T05 · Initial-state record:** Record the initial “Alignment guarantees” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M02.04-C045-T06 · Valid-path execution:** Execute the “Alignment guarantees” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M02.04-C045-T07 · Outcome comparison:** Compare every declared “Alignment guarantees” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M02.04-C045-T08 · State and bounds check:** Inspect the “Alignment guarantees” ownership/state effects and actual use of “Maximum alignment and padding overhead”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M02.04-C045-T09 · Repeatability check:** Repeat the same “Alignment guarantees” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M02.04-C045-T10 · Positive evidence:** Attach the “Alignment guarantees” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M02.04-C046 · Negative test

**Original checklist item:** Negative case: A guest requests alignment unsupported by the allocator. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M02.04-C046-T01 · Adverse-case definition:** Create a test record for the exact “Alignment guarantees” source counterexample: “A guest requests alignment unsupported by the allocator”; state which precondition or invariant it challenges.
- [ ] **UC-M02.04-C046-T02 · Safe fixture boundary:** Define the contained test boundary for “Alignment guarantees”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M02.04-C046-T03 · Valid control:** Construct a valid “Alignment guarantees” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M02.04-C046-T04 · Minimal adverse input:** Derive the “Alignment guarantees” adverse fixture from the control with the smallest documented change needed to reproduce “A guest requests alignment unsupported by the allocator”; retain that change as reproducible data.
- [ ] **UC-M02.04-C046-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Alignment guarantees”; require “Returned memory meets the declared alignment contract” and forbid a false-success verdict.
- [ ] **UC-M02.04-C046-T06 · Adverse execution:** Exercise the “Alignment guarantees” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M02.04-C046-T07 · Effect inspection:** Inspect “Alignment guarantees” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M02.04-C046-T08 · Refusal versus failure:** Confirm the “Alignment guarantees” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M02.04-C046-T09 · Reset and retention:** Restore only the disposable “Alignment guarantees” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M02.04-C046-T10 · Negative regression:** Register the “Alignment guarantees” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M02.04-C047 · Change / failure test

**Original checklist item:** Exercise alignment guarantees when an invocation fails during allocation and a subsequent invocation starts; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M02.04-C047-T01 · Scenario record:** Write the “Alignment guarantees” change/failure scenario exactly as supplied: an invocation fails during allocation and a subsequent invocation starts; identify the property that must remain true: “Returned memory meets the declared alignment contract”.
- [ ] **UC-M02.04-C047-T02 · Baseline capture:** Create a known-valid “Alignment guarantees” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M02.04-C047-T03 · Injection map:** Locate the “Alignment guarantees” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M02.04-C047-T04 · Disposition oracle:** Define the legal intermediate and final “Alignment guarantees” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M02.04-C047-T05 · Controlled trigger:** Introduce the controlled “Alignment guarantees” scenario in the disposable fixture: an invocation fails during allocation and a subsequent invocation starts; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M02.04-C047-T06 · Intermediate inspection:** Inspect the “Alignment guarantees” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M02.04-C047-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Alignment guarantees”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M02.04-C047-T08 · Stale-evidence cleanup:** Invalidate superseded “Alignment guarantees” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M02.04-C047-T09 · Repeat and compare:** Repeat the selected “Alignment guarantees” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M02.04-C047-T10 · Failure evidence:** Publish the “Alignment guarantees” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M02.04-C048 · Bounds

**Original checklist item:** Choose, document and test limits for maximum alignment and padding overhead; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M02.04-C048-T01 · Quantity inventory:** Create a measurement inventory for “Alignment guarantees”: “Maximum alignment and padding overhead”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M02.04-C048-T02 · Measurement method:** Choose how to observe each “Alignment guarantees” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M02.04-C048-T03 · Budget decision:** Select justified resource and input limits for “Alignment guarantees”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M02.04-C048-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Alignment guarantees” cases for “Maximum alignment and padding overhead”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M02.04-C048-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Alignment guarantees” limit; preserve “Returned memory meets the declared alignment contract”.
- [ ] **UC-M02.04-C048-T06 · Normal measurement:** Run or review the normal “Alignment guarantees” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M02.04-C048-T07 · At-limit measurement:** Exercise the “Alignment guarantees” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M02.04-C048-T08 · Over-limit measurement:** Exercise the “Alignment guarantees” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M02.04-C048-T09 · Uncovered-scope report:** List the “Alignment guarantees” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M02.04-C048-T10 · Limit evidence:** Publish the selected “Alignment guarantees” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M02.04-C049 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for alignment guarantees with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M02.04-C049-T01 · Event inventory:** List the “Alignment guarantees” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M02.04-C049-T02 · Diagnostic schema:** Define nonsecret fields for “Alignment guarantees” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M02.04-C049-T03 · Failure mapping:** Map each documented “Alignment guarantees” refusal or error to a diagnostic outcome; include “A guest requests alignment unsupported by the allocator” and prohibit conversion into a success message.
- [ ] **UC-M02.04-C049-T04 · Emission path:** Add the “Alignment guarantees” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M02.04-C049-T05 · Redaction check:** Test “Alignment guarantees” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M02.04-C049-T06 · Output budget:** Set and exercise bounded “Alignment guarantees” message size, rate and retention compatible with “Maximum alignment and padding overhead”; define truncation behavior that preserves the final reason.
- [ ] **UC-M02.04-C049-T07 · Success/refusal fixtures:** Capture “Alignment guarantees” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M02.04-C049-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Alignment guarantees” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M02.04-C049-T09 · Operator review:** Read the “Alignment guarantees” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M02.04-C049-T10 · Diagnostic evidence:** Publish redacted “Alignment guarantees” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M02.04-C050 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for alignment guarantees; label unexecuted checks as untested.

- [ ] **UC-M02.04-C050-T01 · Evidence inventory:** List the “Alignment guarantees” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M02.04-C050-T02 · Artifact references:** Record the exact “Alignment guarantees” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M02.04-C050-T03 · Fixture references:** Attach the “Alignment guarantees” fixture IDs, input identities and oracle definition; preserve the source counterexample “A guest requests alignment unsupported by the allocator” as a distinct evidence case.
- [ ] **UC-M02.04-C050-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Alignment guarantees”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M02.04-C050-T05 · Environment record:** Record the actual “Alignment guarantees” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M02.04-C050-T06 · Expected versus observed:** Pair every “Alignment guarantees” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M02.04-C050-T07 · Failure and limit records:** Attach “Alignment guarantees” change/failure and bounds evidence where required; include uncovered “Maximum alignment and padding overhead” and unresolved violations of “Returned memory meets the declared alignment contract”.
- [ ] **UC-M02.04-C050-T08 · Evidence hygiene:** Check the “Alignment guarantees” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M02.04-C050-T09 · Reproduction review:** Have the “Alignment guarantees” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M02.04-C050-T10 · Acceptance linkage:** Link the “Alignment guarantees” evidence to its parent and UC-M02.04 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 06. Stack budgets

**Source delivery:** Assign and validate stack budgets for startup and workload execution.

**Source invariant:** Stack growth does not silently overwrite heap or image data.

**Source negative case:** A deep call chain exceeds its configured stack budget.

**Source bounded quantities:** Stack bytes and supported call depth.

### UC-M02.04-C051 · Contract

**Original checklist item:** Specify stack budgets inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M02.04-C051-T01 · Scope statement:** Draft the operation boundary for “Stack budgets” within Guest allocator and memory lifecycle; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M02.04-C051-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Stack budgets”; record each producer, representation and missing-value meaning.
- [ ] **UC-M02.04-C051-T03 · Output inventory:** List the outputs of “Stack budgets” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M02.04-C051-T04 · Field dictionary:** Create a field-and-term dictionary for “Stack budgets”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M02.04-C051-T05 · Prerequisite contract:** Map “Stack budgets” to the source component prerequisites (UC-M02.03); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M02.04-C051-T06 · Authority map:** Identify who may produce, change and consume “Stack budgets”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M02.04-C051-T07 · Invariant clause:** Add a normative clause for “Stack budgets” that preserves “Stack growth does not silently overwrite heap or image data”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M02.04-C051-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Stack budgets”; include the source counterexample “A deep call chain exceeds its configured stack budget” and the intended safe disposition.
- [ ] **UC-M02.04-C051-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Stack bytes and supported call depth” in the “Stack budgets” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M02.04-C051-T10 · Contract review:** Review the “Stack budgets” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M02.04-C052 · Delivery

**Original checklist item:** Assign and validate stack budgets for startup and workload execution.

- [ ] **UC-M02.04-C052-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Stack budgets”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M02.04-C052-T02 · Change plan:** Break the source delivery for “Stack budgets” into concrete edit targets and reviewable outputs; keep the UC-M02.04 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M02.04-C052-T03 · Core artifact:** Implement the smallest selected-profile change for “Stack budgets” that realizes this source instruction: Assign and validate stack budgets for startup and workload execution.
- [ ] **UC-M02.04-C052-T04 · Concrete realization:** Trace “Stack budgets” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M02.04-C052-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Stack budgets” needed to preserve “Stack growth does not silently overwrite heap or image data”; record an enforcement gap where only a model exists.
- [ ] **UC-M02.04-C052-T06 · Dependency connection:** Connect the “Stack budgets” implementation to guest runtime allocations, stack setup and host-assigned memory regions; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M02.04-C052-T07 · Resource behavior:** Account for “Stack bytes and supported call depth” in “Stack budgets”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M02.04-C052-T08 · Delivery check:** Run the smallest real “Stack budgets” path and its adverse fixture “A deep call chain exceeds its configured stack budget”; retain actual output, state effects and final disposition.
- [ ] **UC-M02.04-C052-T09 · Patch review:** Review the “Stack budgets” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M02.04-C052-T10 · Delivery handoff:** Publish the “Stack budgets” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M02.04-C053 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Stack growth does not silently overwrite heap or image data. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M02.04-C053-T01 · Named property:** Create a stable property/check name under this parent for “Stack budgets”; copy its required invariant exactly: “Stack growth does not silently overwrite heap or image data”.
- [ ] **UC-M02.04-C053-T02 · Observable terms:** Define each term in the “Stack budgets” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M02.04-C053-T03 · Precondition set:** List the preconditions under which “Stack growth does not silently overwrite heap or image data” must hold for “Stack budgets”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M02.04-C053-T04 · Transition coverage:** Map the “Stack budgets” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M02.04-C053-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Stack budgets”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M02.04-C053-T06 · Satisfying fixture:** Create a concrete “Stack budgets” case that satisfies “Stack growth does not silently overwrite heap or image data”; record its expected observation before running the assertion or review.
- [ ] **UC-M02.04-C053-T07 · Violating fixture:** Create the source counterexample “A deep call chain exceeds its configured stack budget” for “Stack budgets”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M02.04-C053-T08 · Enforcement evidence:** Exercise the “Stack budgets” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M02.04-C053-T09 · Regression linkage:** Link the “Stack budgets” property to changes in guest runtime allocations, stack setup and host-assigned memory regions; record which dependency or contract changes require rerunning it.
- [ ] **UC-M02.04-C053-T10 · Property disposition:** Compare the satisfying and violating “Stack budgets” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M02.04-C054 · Integration

**Original checklist item:** Integrate stack budgets with guest runtime allocations, stack setup and host-assigned memory regions; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M02.04-C054-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Stack budgets” across guest runtime allocations, stack setup and host-assigned memory regions; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M02.04-C054-T02 · Field mapping:** Map every “Stack budgets” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M02.04-C054-T03 · Prerequisite identities:** Record the actual prerequisites for “Stack budgets” (source dependency list: UC-M02.03); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M02.04-C054-T04 · Ownership agreement:** Specify who owns “Stack budgets” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M02.04-C054-T05 · Handoff implementation:** Connect “Stack budgets” through the mapped seam using the real adapter or explicit specification reference; preserve “Stack growth does not silently overwrite heap or image data” across the handoff.
- [ ] **UC-M02.04-C054-T06 · Absent-input case:** Omit one required “Stack budgets” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M02.04-C054-T07 · Stale-input case:** Supply an outdated “Stack budgets” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M02.04-C054-T08 · Incompatible-input case:** Supply an incompatible “Stack budgets” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M02.04-C054-T09 · Valid integration trace:** Run a valid “Stack budgets” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M02.04-C054-T10 · Seam review:** Reconcile the “Stack budgets” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M02.04-C055 · Valid-case test

**Original checklist item:** Run a valid-path fixture for stack budgets; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M02.04-C055-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Stack budgets” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M02.04-C055-T02 · Expected-result oracle:** Specify the “Stack budgets” expected result independently of the implementation output; include the property “Stack growth does not silently overwrite heap or image data” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M02.04-C055-T03 · Fixture material:** Create the concrete “Stack budgets” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M02.04-C055-T04 · Target preparation:** Prepare the “Stack budgets” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M02.04-C055-T05 · Initial-state record:** Record the initial “Stack budgets” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M02.04-C055-T06 · Valid-path execution:** Execute the “Stack budgets” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M02.04-C055-T07 · Outcome comparison:** Compare every declared “Stack budgets” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M02.04-C055-T08 · State and bounds check:** Inspect the “Stack budgets” ownership/state effects and actual use of “Stack bytes and supported call depth”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M02.04-C055-T09 · Repeatability check:** Repeat the same “Stack budgets” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M02.04-C055-T10 · Positive evidence:** Attach the “Stack budgets” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M02.04-C056 · Negative test

**Original checklist item:** Negative case: A deep call chain exceeds its configured stack budget. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M02.04-C056-T01 · Adverse-case definition:** Create a test record for the exact “Stack budgets” source counterexample: “A deep call chain exceeds its configured stack budget”; state which precondition or invariant it challenges.
- [ ] **UC-M02.04-C056-T02 · Safe fixture boundary:** Define the contained test boundary for “Stack budgets”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M02.04-C056-T03 · Valid control:** Construct a valid “Stack budgets” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M02.04-C056-T04 · Minimal adverse input:** Derive the “Stack budgets” adverse fixture from the control with the smallest documented change needed to reproduce “A deep call chain exceeds its configured stack budget”; retain that change as reproducible data.
- [ ] **UC-M02.04-C056-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Stack budgets”; require “Stack growth does not silently overwrite heap or image data” and forbid a false-success verdict.
- [ ] **UC-M02.04-C056-T06 · Adverse execution:** Exercise the “Stack budgets” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M02.04-C056-T07 · Effect inspection:** Inspect “Stack budgets” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M02.04-C056-T08 · Refusal versus failure:** Confirm the “Stack budgets” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M02.04-C056-T09 · Reset and retention:** Restore only the disposable “Stack budgets” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M02.04-C056-T10 · Negative regression:** Register the “Stack budgets” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M02.04-C057 · Change / failure test

**Original checklist item:** Exercise stack budgets when an invocation fails during allocation and a subsequent invocation starts; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M02.04-C057-T01 · Scenario record:** Write the “Stack budgets” change/failure scenario exactly as supplied: an invocation fails during allocation and a subsequent invocation starts; identify the property that must remain true: “Stack growth does not silently overwrite heap or image data”.
- [ ] **UC-M02.04-C057-T02 · Baseline capture:** Create a known-valid “Stack budgets” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M02.04-C057-T03 · Injection map:** Locate the “Stack budgets” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M02.04-C057-T04 · Disposition oracle:** Define the legal intermediate and final “Stack budgets” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M02.04-C057-T05 · Controlled trigger:** Introduce the controlled “Stack budgets” scenario in the disposable fixture: an invocation fails during allocation and a subsequent invocation starts; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M02.04-C057-T06 · Intermediate inspection:** Inspect the “Stack budgets” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M02.04-C057-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Stack budgets”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M02.04-C057-T08 · Stale-evidence cleanup:** Invalidate superseded “Stack budgets” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M02.04-C057-T09 · Repeat and compare:** Repeat the selected “Stack budgets” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M02.04-C057-T10 · Failure evidence:** Publish the “Stack budgets” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M02.04-C058 · Bounds

**Original checklist item:** Choose, document and test limits for stack bytes and supported call depth; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M02.04-C058-T01 · Quantity inventory:** Create a measurement inventory for “Stack budgets”: “Stack bytes and supported call depth”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M02.04-C058-T02 · Measurement method:** Choose how to observe each “Stack budgets” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M02.04-C058-T03 · Budget decision:** Select justified resource and input limits for “Stack budgets”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M02.04-C058-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Stack budgets” cases for “Stack bytes and supported call depth”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M02.04-C058-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Stack budgets” limit; preserve “Stack growth does not silently overwrite heap or image data”.
- [ ] **UC-M02.04-C058-T06 · Normal measurement:** Run or review the normal “Stack budgets” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M02.04-C058-T07 · At-limit measurement:** Exercise the “Stack budgets” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M02.04-C058-T08 · Over-limit measurement:** Exercise the “Stack budgets” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M02.04-C058-T09 · Uncovered-scope report:** List the “Stack budgets” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M02.04-C058-T10 · Limit evidence:** Publish the selected “Stack budgets” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M02.04-C059 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for stack budgets with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M02.04-C059-T01 · Event inventory:** List the “Stack budgets” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M02.04-C059-T02 · Diagnostic schema:** Define nonsecret fields for “Stack budgets” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M02.04-C059-T03 · Failure mapping:** Map each documented “Stack budgets” refusal or error to a diagnostic outcome; include “A deep call chain exceeds its configured stack budget” and prohibit conversion into a success message.
- [ ] **UC-M02.04-C059-T04 · Emission path:** Add the “Stack budgets” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M02.04-C059-T05 · Redaction check:** Test “Stack budgets” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M02.04-C059-T06 · Output budget:** Set and exercise bounded “Stack budgets” message size, rate and retention compatible with “Stack bytes and supported call depth”; define truncation behavior that preserves the final reason.
- [ ] **UC-M02.04-C059-T07 · Success/refusal fixtures:** Capture “Stack budgets” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M02.04-C059-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Stack budgets” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M02.04-C059-T09 · Operator review:** Read the “Stack budgets” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M02.04-C059-T10 · Diagnostic evidence:** Publish redacted “Stack budgets” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M02.04-C060 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for stack budgets; label unexecuted checks as untested.

- [ ] **UC-M02.04-C060-T01 · Evidence inventory:** List the “Stack budgets” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M02.04-C060-T02 · Artifact references:** Record the exact “Stack budgets” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M02.04-C060-T03 · Fixture references:** Attach the “Stack budgets” fixture IDs, input identities and oracle definition; preserve the source counterexample “A deep call chain exceeds its configured stack budget” as a distinct evidence case.
- [ ] **UC-M02.04-C060-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Stack budgets”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M02.04-C060-T05 · Environment record:** Record the actual “Stack budgets” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M02.04-C060-T06 · Expected versus observed:** Pair every “Stack budgets” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M02.04-C060-T07 · Failure and limit records:** Attach “Stack budgets” change/failure and bounds evidence where required; include uncovered “Stack bytes and supported call depth” and unresolved violations of “Stack growth does not silently overwrite heap or image data”.
- [ ] **UC-M02.04-C060-T08 · Evidence hygiene:** Check the “Stack budgets” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M02.04-C060-T09 · Reproduction review:** Have the “Stack budgets” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M02.04-C060-T10 · Acceptance linkage:** Link the “Stack budgets” evidence to its parent and UC-M02.04 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 07. Exhaustion behavior

**Source delivery:** Define observable behavior when heap or stack resources are exhausted.

**Source invariant:** Exhaustion produces a documented guest failure without cross-guest corruption.

**Source negative case:** The heap is exhausted during an in-flight invocation.

**Source bounded quantities:** Failure-log bytes and exhaustion handling time.

### UC-M02.04-C061 · Contract

**Original checklist item:** Specify exhaustion behavior inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M02.04-C061-T01 · Scope statement:** Draft the operation boundary for “Exhaustion behavior” within Guest allocator and memory lifecycle; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M02.04-C061-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Exhaustion behavior”; record each producer, representation and missing-value meaning.
- [ ] **UC-M02.04-C061-T03 · Output inventory:** List the outputs of “Exhaustion behavior” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M02.04-C061-T04 · Field dictionary:** Create a field-and-term dictionary for “Exhaustion behavior”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M02.04-C061-T05 · Prerequisite contract:** Map “Exhaustion behavior” to the source component prerequisites (UC-M02.03); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M02.04-C061-T06 · Authority map:** Identify who may produce, change and consume “Exhaustion behavior”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M02.04-C061-T07 · Invariant clause:** Add a normative clause for “Exhaustion behavior” that preserves “Exhaustion produces a documented guest failure without cross-guest corruption”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M02.04-C061-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Exhaustion behavior”; include the source counterexample “The heap is exhausted during an in-flight invocation” and the intended safe disposition.
- [ ] **UC-M02.04-C061-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Failure-log bytes and exhaustion handling time” in the “Exhaustion behavior” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M02.04-C061-T10 · Contract review:** Review the “Exhaustion behavior” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M02.04-C062 · Delivery

**Original checklist item:** Define observable behavior when heap or stack resources are exhausted.

- [ ] **UC-M02.04-C062-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Exhaustion behavior”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M02.04-C062-T02 · Change plan:** Break the source delivery for “Exhaustion behavior” into concrete edit targets and reviewable outputs; keep the UC-M02.04 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M02.04-C062-T03 · Core artifact:** Create the “Exhaustion behavior” model, schema or inventory that realizes this source instruction: Define observable behavior when heap or stack resources are exhausted.
- [ ] **UC-M02.04-C062-T04 · Concrete realization:** Populate “Exhaustion behavior” with one concrete worked case; map every required entity or field to its source and flag any unmapped entry.
- [ ] **UC-M02.04-C062-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Exhaustion behavior” needed to preserve “Exhaustion produces a documented guest failure without cross-guest corruption”; record an enforcement gap where only a model exists.
- [ ] **UC-M02.04-C062-T06 · Dependency connection:** Connect the “Exhaustion behavior” implementation to guest runtime allocations, stack setup and host-assigned memory regions; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M02.04-C062-T07 · Resource behavior:** Account for “Failure-log bytes and exhaustion handling time” in “Exhaustion behavior”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M02.04-C062-T08 · Delivery check:** Run the smallest real “Exhaustion behavior” path and its adverse fixture “The heap is exhausted during an in-flight invocation”; retain actual output, state effects and final disposition.
- [ ] **UC-M02.04-C062-T09 · Patch review:** Review the “Exhaustion behavior” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M02.04-C062-T10 · Delivery handoff:** Publish the “Exhaustion behavior” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M02.04-C063 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Exhaustion produces a documented guest failure without cross-guest corruption. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M02.04-C063-T01 · Named property:** Create a stable property/check name under this parent for “Exhaustion behavior”; copy its required invariant exactly: “Exhaustion produces a documented guest failure without cross-guest corruption”.
- [ ] **UC-M02.04-C063-T02 · Observable terms:** Define each term in the “Exhaustion behavior” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M02.04-C063-T03 · Precondition set:** List the preconditions under which “Exhaustion produces a documented guest failure without cross-guest corruption” must hold for “Exhaustion behavior”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M02.04-C063-T04 · Transition coverage:** Map the “Exhaustion behavior” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M02.04-C063-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Exhaustion behavior”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M02.04-C063-T06 · Satisfying fixture:** Create a concrete “Exhaustion behavior” case that satisfies “Exhaustion produces a documented guest failure without cross-guest corruption”; record its expected observation before running the assertion or review.
- [ ] **UC-M02.04-C063-T07 · Violating fixture:** Create the source counterexample “The heap is exhausted during an in-flight invocation” for “Exhaustion behavior”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M02.04-C063-T08 · Enforcement evidence:** Exercise the “Exhaustion behavior” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M02.04-C063-T09 · Regression linkage:** Link the “Exhaustion behavior” property to changes in guest runtime allocations, stack setup and host-assigned memory regions; record which dependency or contract changes require rerunning it.
- [ ] **UC-M02.04-C063-T10 · Property disposition:** Compare the satisfying and violating “Exhaustion behavior” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M02.04-C064 · Integration

**Original checklist item:** Integrate exhaustion behavior with guest runtime allocations, stack setup and host-assigned memory regions; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M02.04-C064-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Exhaustion behavior” across guest runtime allocations, stack setup and host-assigned memory regions; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M02.04-C064-T02 · Field mapping:** Map every “Exhaustion behavior” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M02.04-C064-T03 · Prerequisite identities:** Record the actual prerequisites for “Exhaustion behavior” (source dependency list: UC-M02.03); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M02.04-C064-T04 · Ownership agreement:** Specify who owns “Exhaustion behavior” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M02.04-C064-T05 · Handoff implementation:** Connect “Exhaustion behavior” through the mapped seam using the real adapter or explicit specification reference; preserve “Exhaustion produces a documented guest failure without cross-guest corruption” across the handoff.
- [ ] **UC-M02.04-C064-T06 · Absent-input case:** Omit one required “Exhaustion behavior” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M02.04-C064-T07 · Stale-input case:** Supply an outdated “Exhaustion behavior” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M02.04-C064-T08 · Incompatible-input case:** Supply an incompatible “Exhaustion behavior” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M02.04-C064-T09 · Valid integration trace:** Run a valid “Exhaustion behavior” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M02.04-C064-T10 · Seam review:** Reconcile the “Exhaustion behavior” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M02.04-C065 · Valid-case test

**Original checklist item:** Run a valid-path fixture for exhaustion behavior; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M02.04-C065-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Exhaustion behavior” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M02.04-C065-T02 · Expected-result oracle:** Specify the “Exhaustion behavior” expected result independently of the implementation output; include the property “Exhaustion produces a documented guest failure without cross-guest corruption” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M02.04-C065-T03 · Fixture material:** Create the concrete “Exhaustion behavior” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M02.04-C065-T04 · Target preparation:** Prepare the “Exhaustion behavior” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M02.04-C065-T05 · Initial-state record:** Record the initial “Exhaustion behavior” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M02.04-C065-T06 · Valid-path execution:** Execute the “Exhaustion behavior” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M02.04-C065-T07 · Outcome comparison:** Compare every declared “Exhaustion behavior” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M02.04-C065-T08 · State and bounds check:** Inspect the “Exhaustion behavior” ownership/state effects and actual use of “Failure-log bytes and exhaustion handling time”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M02.04-C065-T09 · Repeatability check:** Repeat the same “Exhaustion behavior” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M02.04-C065-T10 · Positive evidence:** Attach the “Exhaustion behavior” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M02.04-C066 · Negative test

**Original checklist item:** Negative case: The heap is exhausted during an in-flight invocation. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M02.04-C066-T01 · Adverse-case definition:** Create a test record for the exact “Exhaustion behavior” source counterexample: “The heap is exhausted during an in-flight invocation”; state which precondition or invariant it challenges.
- [ ] **UC-M02.04-C066-T02 · Safe fixture boundary:** Define the contained test boundary for “Exhaustion behavior”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M02.04-C066-T03 · Valid control:** Construct a valid “Exhaustion behavior” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M02.04-C066-T04 · Minimal adverse input:** Derive the “Exhaustion behavior” adverse fixture from the control with the smallest documented change needed to reproduce “The heap is exhausted during an in-flight invocation”; retain that change as reproducible data.
- [ ] **UC-M02.04-C066-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Exhaustion behavior”; require “Exhaustion produces a documented guest failure without cross-guest corruption” and forbid a false-success verdict.
- [ ] **UC-M02.04-C066-T06 · Adverse execution:** Exercise the “Exhaustion behavior” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M02.04-C066-T07 · Effect inspection:** Inspect “Exhaustion behavior” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M02.04-C066-T08 · Refusal versus failure:** Confirm the “Exhaustion behavior” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M02.04-C066-T09 · Reset and retention:** Restore only the disposable “Exhaustion behavior” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M02.04-C066-T10 · Negative regression:** Register the “Exhaustion behavior” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M02.04-C067 · Change / failure test

**Original checklist item:** Exercise exhaustion behavior when an invocation fails during allocation and a subsequent invocation starts; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M02.04-C067-T01 · Scenario record:** Write the “Exhaustion behavior” change/failure scenario exactly as supplied: an invocation fails during allocation and a subsequent invocation starts; identify the property that must remain true: “Exhaustion produces a documented guest failure without cross-guest corruption”.
- [ ] **UC-M02.04-C067-T02 · Baseline capture:** Create a known-valid “Exhaustion behavior” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M02.04-C067-T03 · Injection map:** Locate the “Exhaustion behavior” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M02.04-C067-T04 · Disposition oracle:** Define the legal intermediate and final “Exhaustion behavior” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M02.04-C067-T05 · Controlled trigger:** Introduce the controlled “Exhaustion behavior” scenario in the disposable fixture: an invocation fails during allocation and a subsequent invocation starts; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M02.04-C067-T06 · Intermediate inspection:** Inspect the “Exhaustion behavior” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M02.04-C067-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Exhaustion behavior”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M02.04-C067-T08 · Stale-evidence cleanup:** Invalidate superseded “Exhaustion behavior” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M02.04-C067-T09 · Repeat and compare:** Repeat the selected “Exhaustion behavior” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M02.04-C067-T10 · Failure evidence:** Publish the “Exhaustion behavior” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M02.04-C068 · Bounds

**Original checklist item:** Choose, document and test limits for failure-log bytes and exhaustion handling time; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M02.04-C068-T01 · Quantity inventory:** Create a measurement inventory for “Exhaustion behavior”: “Failure-log bytes and exhaustion handling time”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M02.04-C068-T02 · Measurement method:** Choose how to observe each “Exhaustion behavior” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M02.04-C068-T03 · Budget decision:** Select justified resource and input limits for “Exhaustion behavior”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M02.04-C068-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Exhaustion behavior” cases for “Failure-log bytes and exhaustion handling time”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M02.04-C068-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Exhaustion behavior” limit; preserve “Exhaustion produces a documented guest failure without cross-guest corruption”.
- [ ] **UC-M02.04-C068-T06 · Normal measurement:** Run or review the normal “Exhaustion behavior” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M02.04-C068-T07 · At-limit measurement:** Exercise the “Exhaustion behavior” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M02.04-C068-T08 · Over-limit measurement:** Exercise the “Exhaustion behavior” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M02.04-C068-T09 · Uncovered-scope report:** List the “Exhaustion behavior” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M02.04-C068-T10 · Limit evidence:** Publish the selected “Exhaustion behavior” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M02.04-C069 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for exhaustion behavior with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M02.04-C069-T01 · Event inventory:** List the “Exhaustion behavior” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M02.04-C069-T02 · Diagnostic schema:** Define nonsecret fields for “Exhaustion behavior” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M02.04-C069-T03 · Failure mapping:** Map each documented “Exhaustion behavior” refusal or error to a diagnostic outcome; include “The heap is exhausted during an in-flight invocation” and prohibit conversion into a success message.
- [ ] **UC-M02.04-C069-T04 · Emission path:** Add the “Exhaustion behavior” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M02.04-C069-T05 · Redaction check:** Test “Exhaustion behavior” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M02.04-C069-T06 · Output budget:** Set and exercise bounded “Exhaustion behavior” message size, rate and retention compatible with “Failure-log bytes and exhaustion handling time”; define truncation behavior that preserves the final reason.
- [ ] **UC-M02.04-C069-T07 · Success/refusal fixtures:** Capture “Exhaustion behavior” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M02.04-C069-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Exhaustion behavior” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M02.04-C069-T09 · Operator review:** Read the “Exhaustion behavior” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M02.04-C069-T10 · Diagnostic evidence:** Publish redacted “Exhaustion behavior” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M02.04-C070 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for exhaustion behavior; label unexecuted checks as untested.

- [ ] **UC-M02.04-C070-T01 · Evidence inventory:** List the “Exhaustion behavior” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M02.04-C070-T02 · Artifact references:** Record the exact “Exhaustion behavior” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M02.04-C070-T03 · Fixture references:** Attach the “Exhaustion behavior” fixture IDs, input identities and oracle definition; preserve the source counterexample “The heap is exhausted during an in-flight invocation” as a distinct evidence case.
- [ ] **UC-M02.04-C070-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Exhaustion behavior”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M02.04-C070-T05 · Environment record:** Record the actual “Exhaustion behavior” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M02.04-C070-T06 · Expected versus observed:** Pair every “Exhaustion behavior” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M02.04-C070-T07 · Failure and limit records:** Attach “Exhaustion behavior” change/failure and bounds evidence where required; include uncovered “Failure-log bytes and exhaustion handling time” and unresolved violations of “Exhaustion produces a documented guest failure without cross-guest corruption”.
- [ ] **UC-M02.04-C070-T08 · Evidence hygiene:** Check the “Exhaustion behavior” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M02.04-C070-T09 · Reproduction review:** Have the “Exhaustion behavior” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M02.04-C070-T10 · Acceptance linkage:** Link the “Exhaustion behavior” evidence to its parent and UC-M02.04 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 08. Reclamation lifecycle

**Source delivery:** Release or reset guest-owned memory at the declared invocation and shutdown boundaries.

**Source invariant:** Finished invocations do not retain unintended allocations.

**Source negative case:** Repeated invocations leak memory until later workloads fail.

**Source bounded quantities:** Residual allocations and repetition count.

### UC-M02.04-C071 · Contract

**Original checklist item:** Specify reclamation lifecycle inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M02.04-C071-T01 · Scope statement:** Draft the operation boundary for “Reclamation lifecycle” within Guest allocator and memory lifecycle; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M02.04-C071-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Reclamation lifecycle”; record each producer, representation and missing-value meaning.
- [ ] **UC-M02.04-C071-T03 · Output inventory:** List the outputs of “Reclamation lifecycle” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M02.04-C071-T04 · Field dictionary:** Create a field-and-term dictionary for “Reclamation lifecycle”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M02.04-C071-T05 · Prerequisite contract:** Map “Reclamation lifecycle” to the source component prerequisites (UC-M02.03); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M02.04-C071-T06 · Authority map:** Identify who may produce, change and consume “Reclamation lifecycle”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M02.04-C071-T07 · Invariant clause:** Add a normative clause for “Reclamation lifecycle” that preserves “Finished invocations do not retain unintended allocations”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M02.04-C071-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Reclamation lifecycle”; include the source counterexample “Repeated invocations leak memory until later workloads fail” and the intended safe disposition.
- [ ] **UC-M02.04-C071-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Residual allocations and repetition count” in the “Reclamation lifecycle” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M02.04-C071-T10 · Contract review:** Review the “Reclamation lifecycle” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M02.04-C072 · Delivery

**Original checklist item:** Release or reset guest-owned memory at the declared invocation and shutdown boundaries.

- [ ] **UC-M02.04-C072-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Reclamation lifecycle”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M02.04-C072-T02 · Change plan:** Break the source delivery for “Reclamation lifecycle” into concrete edit targets and reviewable outputs; keep the UC-M02.04 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M02.04-C072-T03 · Core artifact:** Implement the smallest selected-profile change for “Reclamation lifecycle” that realizes this source instruction: Release or reset guest-owned memory at the declared invocation and shutdown boundaries.
- [ ] **UC-M02.04-C072-T04 · Concrete realization:** Trace “Reclamation lifecycle” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M02.04-C072-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Reclamation lifecycle” needed to preserve “Finished invocations do not retain unintended allocations”; record an enforcement gap where only a model exists.
- [ ] **UC-M02.04-C072-T06 · Dependency connection:** Connect the “Reclamation lifecycle” implementation to guest runtime allocations, stack setup and host-assigned memory regions; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M02.04-C072-T07 · Resource behavior:** Account for “Residual allocations and repetition count” in “Reclamation lifecycle”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M02.04-C072-T08 · Delivery check:** Run the smallest real “Reclamation lifecycle” path and its adverse fixture “Repeated invocations leak memory until later workloads fail”; retain actual output, state effects and final disposition.
- [ ] **UC-M02.04-C072-T09 · Patch review:** Review the “Reclamation lifecycle” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M02.04-C072-T10 · Delivery handoff:** Publish the “Reclamation lifecycle” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M02.04-C073 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Finished invocations do not retain unintended allocations. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M02.04-C073-T01 · Named property:** Create a stable property/check name under this parent for “Reclamation lifecycle”; copy its required invariant exactly: “Finished invocations do not retain unintended allocations”.
- [ ] **UC-M02.04-C073-T02 · Observable terms:** Define each term in the “Reclamation lifecycle” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M02.04-C073-T03 · Precondition set:** List the preconditions under which “Finished invocations do not retain unintended allocations” must hold for “Reclamation lifecycle”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M02.04-C073-T04 · Transition coverage:** Map the “Reclamation lifecycle” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M02.04-C073-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Reclamation lifecycle”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M02.04-C073-T06 · Satisfying fixture:** Create a concrete “Reclamation lifecycle” case that satisfies “Finished invocations do not retain unintended allocations”; record its expected observation before running the assertion or review.
- [ ] **UC-M02.04-C073-T07 · Violating fixture:** Create the source counterexample “Repeated invocations leak memory until later workloads fail” for “Reclamation lifecycle”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M02.04-C073-T08 · Enforcement evidence:** Exercise the “Reclamation lifecycle” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M02.04-C073-T09 · Regression linkage:** Link the “Reclamation lifecycle” property to changes in guest runtime allocations, stack setup and host-assigned memory regions; record which dependency or contract changes require rerunning it.
- [ ] **UC-M02.04-C073-T10 · Property disposition:** Compare the satisfying and violating “Reclamation lifecycle” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M02.04-C074 · Integration

**Original checklist item:** Integrate reclamation lifecycle with guest runtime allocations, stack setup and host-assigned memory regions; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M02.04-C074-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Reclamation lifecycle” across guest runtime allocations, stack setup and host-assigned memory regions; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M02.04-C074-T02 · Field mapping:** Map every “Reclamation lifecycle” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M02.04-C074-T03 · Prerequisite identities:** Record the actual prerequisites for “Reclamation lifecycle” (source dependency list: UC-M02.03); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M02.04-C074-T04 · Ownership agreement:** Specify who owns “Reclamation lifecycle” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M02.04-C074-T05 · Handoff implementation:** Connect “Reclamation lifecycle” through the mapped seam using the real adapter or explicit specification reference; preserve “Finished invocations do not retain unintended allocations” across the handoff.
- [ ] **UC-M02.04-C074-T06 · Absent-input case:** Omit one required “Reclamation lifecycle” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M02.04-C074-T07 · Stale-input case:** Supply an outdated “Reclamation lifecycle” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M02.04-C074-T08 · Incompatible-input case:** Supply an incompatible “Reclamation lifecycle” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M02.04-C074-T09 · Valid integration trace:** Run a valid “Reclamation lifecycle” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M02.04-C074-T10 · Seam review:** Reconcile the “Reclamation lifecycle” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M02.04-C075 · Valid-case test

**Original checklist item:** Run a valid-path fixture for reclamation lifecycle; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M02.04-C075-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Reclamation lifecycle” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M02.04-C075-T02 · Expected-result oracle:** Specify the “Reclamation lifecycle” expected result independently of the implementation output; include the property “Finished invocations do not retain unintended allocations” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M02.04-C075-T03 · Fixture material:** Create the concrete “Reclamation lifecycle” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M02.04-C075-T04 · Target preparation:** Prepare the “Reclamation lifecycle” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M02.04-C075-T05 · Initial-state record:** Record the initial “Reclamation lifecycle” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M02.04-C075-T06 · Valid-path execution:** Execute the “Reclamation lifecycle” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M02.04-C075-T07 · Outcome comparison:** Compare every declared “Reclamation lifecycle” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M02.04-C075-T08 · State and bounds check:** Inspect the “Reclamation lifecycle” ownership/state effects and actual use of “Residual allocations and repetition count”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M02.04-C075-T09 · Repeatability check:** Repeat the same “Reclamation lifecycle” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M02.04-C075-T10 · Positive evidence:** Attach the “Reclamation lifecycle” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M02.04-C076 · Negative test

**Original checklist item:** Negative case: Repeated invocations leak memory until later workloads fail. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M02.04-C076-T01 · Adverse-case definition:** Create a test record for the exact “Reclamation lifecycle” source counterexample: “Repeated invocations leak memory until later workloads fail”; state which precondition or invariant it challenges.
- [ ] **UC-M02.04-C076-T02 · Safe fixture boundary:** Define the contained test boundary for “Reclamation lifecycle”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M02.04-C076-T03 · Valid control:** Construct a valid “Reclamation lifecycle” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M02.04-C076-T04 · Minimal adverse input:** Derive the “Reclamation lifecycle” adverse fixture from the control with the smallest documented change needed to reproduce “Repeated invocations leak memory until later workloads fail”; retain that change as reproducible data.
- [ ] **UC-M02.04-C076-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Reclamation lifecycle”; require “Finished invocations do not retain unintended allocations” and forbid a false-success verdict.
- [ ] **UC-M02.04-C076-T06 · Adverse execution:** Exercise the “Reclamation lifecycle” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M02.04-C076-T07 · Effect inspection:** Inspect “Reclamation lifecycle” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M02.04-C076-T08 · Refusal versus failure:** Confirm the “Reclamation lifecycle” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M02.04-C076-T09 · Reset and retention:** Restore only the disposable “Reclamation lifecycle” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M02.04-C076-T10 · Negative regression:** Register the “Reclamation lifecycle” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M02.04-C077 · Change / failure test

**Original checklist item:** Exercise reclamation lifecycle when an invocation fails during allocation and a subsequent invocation starts; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M02.04-C077-T01 · Scenario record:** Write the “Reclamation lifecycle” change/failure scenario exactly as supplied: an invocation fails during allocation and a subsequent invocation starts; identify the property that must remain true: “Finished invocations do not retain unintended allocations”.
- [ ] **UC-M02.04-C077-T02 · Baseline capture:** Create a known-valid “Reclamation lifecycle” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M02.04-C077-T03 · Injection map:** Locate the “Reclamation lifecycle” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M02.04-C077-T04 · Disposition oracle:** Define the legal intermediate and final “Reclamation lifecycle” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M02.04-C077-T05 · Controlled trigger:** Introduce the controlled “Reclamation lifecycle” scenario in the disposable fixture: an invocation fails during allocation and a subsequent invocation starts; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M02.04-C077-T06 · Intermediate inspection:** Inspect the “Reclamation lifecycle” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M02.04-C077-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Reclamation lifecycle”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M02.04-C077-T08 · Stale-evidence cleanup:** Invalidate superseded “Reclamation lifecycle” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M02.04-C077-T09 · Repeat and compare:** Repeat the selected “Reclamation lifecycle” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M02.04-C077-T10 · Failure evidence:** Publish the “Reclamation lifecycle” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M02.04-C078 · Bounds

**Original checklist item:** Choose, document and test limits for residual allocations and repetition count; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M02.04-C078-T01 · Quantity inventory:** Create a measurement inventory for “Reclamation lifecycle”: “Residual allocations and repetition count”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M02.04-C078-T02 · Measurement method:** Choose how to observe each “Reclamation lifecycle” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M02.04-C078-T03 · Budget decision:** Select justified resource and input limits for “Reclamation lifecycle”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M02.04-C078-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Reclamation lifecycle” cases for “Residual allocations and repetition count”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M02.04-C078-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Reclamation lifecycle” limit; preserve “Finished invocations do not retain unintended allocations”.
- [ ] **UC-M02.04-C078-T06 · Normal measurement:** Run or review the normal “Reclamation lifecycle” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M02.04-C078-T07 · At-limit measurement:** Exercise the “Reclamation lifecycle” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M02.04-C078-T08 · Over-limit measurement:** Exercise the “Reclamation lifecycle” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M02.04-C078-T09 · Uncovered-scope report:** List the “Reclamation lifecycle” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M02.04-C078-T10 · Limit evidence:** Publish the selected “Reclamation lifecycle” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M02.04-C079 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for reclamation lifecycle with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M02.04-C079-T01 · Event inventory:** List the “Reclamation lifecycle” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M02.04-C079-T02 · Diagnostic schema:** Define nonsecret fields for “Reclamation lifecycle” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M02.04-C079-T03 · Failure mapping:** Map each documented “Reclamation lifecycle” refusal or error to a diagnostic outcome; include “Repeated invocations leak memory until later workloads fail” and prohibit conversion into a success message.
- [ ] **UC-M02.04-C079-T04 · Emission path:** Add the “Reclamation lifecycle” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M02.04-C079-T05 · Redaction check:** Test “Reclamation lifecycle” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M02.04-C079-T06 · Output budget:** Set and exercise bounded “Reclamation lifecycle” message size, rate and retention compatible with “Residual allocations and repetition count”; define truncation behavior that preserves the final reason.
- [ ] **UC-M02.04-C079-T07 · Success/refusal fixtures:** Capture “Reclamation lifecycle” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M02.04-C079-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Reclamation lifecycle” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M02.04-C079-T09 · Operator review:** Read the “Reclamation lifecycle” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M02.04-C079-T10 · Diagnostic evidence:** Publish redacted “Reclamation lifecycle” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M02.04-C080 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for reclamation lifecycle; label unexecuted checks as untested.

- [ ] **UC-M02.04-C080-T01 · Evidence inventory:** List the “Reclamation lifecycle” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M02.04-C080-T02 · Artifact references:** Record the exact “Reclamation lifecycle” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M02.04-C080-T03 · Fixture references:** Attach the “Reclamation lifecycle” fixture IDs, input identities and oracle definition; preserve the source counterexample “Repeated invocations leak memory until later workloads fail” as a distinct evidence case.
- [ ] **UC-M02.04-C080-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Reclamation lifecycle”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M02.04-C080-T05 · Environment record:** Record the actual “Reclamation lifecycle” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M02.04-C080-T06 · Expected versus observed:** Pair every “Reclamation lifecycle” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M02.04-C080-T07 · Failure and limit records:** Attach “Reclamation lifecycle” change/failure and bounds evidence where required; include uncovered “Residual allocations and repetition count” and unresolved violations of “Finished invocations do not retain unintended allocations”.
- [ ] **UC-M02.04-C080-T08 · Evidence hygiene:** Check the “Reclamation lifecycle” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M02.04-C080-T09 · Reproduction review:** Have the “Reclamation lifecycle” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M02.04-C080-T10 · Acceptance linkage:** Link the “Reclamation lifecycle” evidence to its parent and UC-M02.04 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 09. Allocator stress tests

**Source delivery:** Exercise mixed sizes, allocation failures and repeated release patterns.

**Source invariant:** Allocator accounting matches owned live allocations.

**Source negative case:** Fragmentation prevents a required allocation despite misleading free totals.

**Source bounded quantities:** Stress duration, allocation population and fragmentation metrics.

### UC-M02.04-C081 · Contract

**Original checklist item:** Specify allocator stress tests inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M02.04-C081-T01 · Scope statement:** Draft the operation boundary for “Allocator stress tests” within Guest allocator and memory lifecycle; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M02.04-C081-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Allocator stress tests”; record each producer, representation and missing-value meaning.
- [ ] **UC-M02.04-C081-T03 · Output inventory:** List the outputs of “Allocator stress tests” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M02.04-C081-T04 · Field dictionary:** Create a field-and-term dictionary for “Allocator stress tests”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M02.04-C081-T05 · Prerequisite contract:** Map “Allocator stress tests” to the source component prerequisites (UC-M02.03); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M02.04-C081-T06 · Authority map:** Identify who may produce, change and consume “Allocator stress tests”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M02.04-C081-T07 · Invariant clause:** Add a normative clause for “Allocator stress tests” that preserves “Allocator accounting matches owned live allocations”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M02.04-C081-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Allocator stress tests”; include the source counterexample “Fragmentation prevents a required allocation despite misleading free totals” and the intended safe disposition.
- [ ] **UC-M02.04-C081-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Stress duration, allocation population and fragmentation metrics” in the “Allocator stress tests” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M02.04-C081-T10 · Contract review:** Review the “Allocator stress tests” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M02.04-C082 · Delivery

**Original checklist item:** Exercise mixed sizes, allocation failures and repeated release patterns.

- [ ] **UC-M02.04-C082-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Allocator stress tests”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M02.04-C082-T02 · Change plan:** Break the source delivery for “Allocator stress tests” into concrete edit targets and reviewable outputs; keep the UC-M02.04 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M02.04-C082-T03 · Core artifact:** Create the “Allocator stress tests” fixture or harness for this source instruction: Exercise mixed sizes, allocation failures and repeated release patterns.
- [ ] **UC-M02.04-C082-T04 · Concrete realization:** Connect the “Allocator stress tests” harness to its actual intended target, set the expected oracle before running it, and distinguish a mock/control run from a target run.
- [ ] **UC-M02.04-C082-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Allocator stress tests” needed to preserve “Allocator accounting matches owned live allocations”; record an enforcement gap where only a model exists.
- [ ] **UC-M02.04-C082-T06 · Dependency connection:** Connect the “Allocator stress tests” implementation to guest runtime allocations, stack setup and host-assigned memory regions; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M02.04-C082-T07 · Resource behavior:** Account for “Stress duration, allocation population and fragmentation metrics” in “Allocator stress tests”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M02.04-C082-T08 · Delivery check:** Run the smallest real “Allocator stress tests” path and its adverse fixture “Fragmentation prevents a required allocation despite misleading free totals”; retain actual output, state effects and final disposition.
- [ ] **UC-M02.04-C082-T09 · Patch review:** Review the “Allocator stress tests” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M02.04-C082-T10 · Delivery handoff:** Publish the “Allocator stress tests” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M02.04-C083 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Allocator accounting matches owned live allocations. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M02.04-C083-T01 · Named property:** Create a stable property/check name under this parent for “Allocator stress tests”; copy its required invariant exactly: “Allocator accounting matches owned live allocations”.
- [ ] **UC-M02.04-C083-T02 · Observable terms:** Define each term in the “Allocator stress tests” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M02.04-C083-T03 · Precondition set:** List the preconditions under which “Allocator accounting matches owned live allocations” must hold for “Allocator stress tests”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M02.04-C083-T04 · Transition coverage:** Map the “Allocator stress tests” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M02.04-C083-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Allocator stress tests”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M02.04-C083-T06 · Satisfying fixture:** Create a concrete “Allocator stress tests” case that satisfies “Allocator accounting matches owned live allocations”; record its expected observation before running the assertion or review.
- [ ] **UC-M02.04-C083-T07 · Violating fixture:** Create the source counterexample “Fragmentation prevents a required allocation despite misleading free totals” for “Allocator stress tests”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M02.04-C083-T08 · Enforcement evidence:** Exercise the “Allocator stress tests” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M02.04-C083-T09 · Regression linkage:** Link the “Allocator stress tests” property to changes in guest runtime allocations, stack setup and host-assigned memory regions; record which dependency or contract changes require rerunning it.
- [ ] **UC-M02.04-C083-T10 · Property disposition:** Compare the satisfying and violating “Allocator stress tests” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M02.04-C084 · Integration

**Original checklist item:** Integrate allocator stress tests with guest runtime allocations, stack setup and host-assigned memory regions; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M02.04-C084-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Allocator stress tests” across guest runtime allocations, stack setup and host-assigned memory regions; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M02.04-C084-T02 · Field mapping:** Map every “Allocator stress tests” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M02.04-C084-T03 · Prerequisite identities:** Record the actual prerequisites for “Allocator stress tests” (source dependency list: UC-M02.03); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M02.04-C084-T04 · Ownership agreement:** Specify who owns “Allocator stress tests” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M02.04-C084-T05 · Handoff implementation:** Connect “Allocator stress tests” through the mapped seam using the real adapter or explicit specification reference; preserve “Allocator accounting matches owned live allocations” across the handoff.
- [ ] **UC-M02.04-C084-T06 · Absent-input case:** Omit one required “Allocator stress tests” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M02.04-C084-T07 · Stale-input case:** Supply an outdated “Allocator stress tests” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M02.04-C084-T08 · Incompatible-input case:** Supply an incompatible “Allocator stress tests” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M02.04-C084-T09 · Valid integration trace:** Run a valid “Allocator stress tests” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M02.04-C084-T10 · Seam review:** Reconcile the “Allocator stress tests” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M02.04-C085 · Valid-case test

**Original checklist item:** Run a valid-path fixture for allocator stress tests; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M02.04-C085-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Allocator stress tests” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M02.04-C085-T02 · Expected-result oracle:** Specify the “Allocator stress tests” expected result independently of the implementation output; include the property “Allocator accounting matches owned live allocations” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M02.04-C085-T03 · Fixture material:** Create the concrete “Allocator stress tests” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M02.04-C085-T04 · Target preparation:** Prepare the “Allocator stress tests” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M02.04-C085-T05 · Initial-state record:** Record the initial “Allocator stress tests” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M02.04-C085-T06 · Valid-path execution:** Execute the “Allocator stress tests” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M02.04-C085-T07 · Outcome comparison:** Compare every declared “Allocator stress tests” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M02.04-C085-T08 · State and bounds check:** Inspect the “Allocator stress tests” ownership/state effects and actual use of “Stress duration, allocation population and fragmentation metrics”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M02.04-C085-T09 · Repeatability check:** Repeat the same “Allocator stress tests” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M02.04-C085-T10 · Positive evidence:** Attach the “Allocator stress tests” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M02.04-C086 · Negative test

**Original checklist item:** Negative case: Fragmentation prevents a required allocation despite misleading free totals. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M02.04-C086-T01 · Adverse-case definition:** Create a test record for the exact “Allocator stress tests” source counterexample: “Fragmentation prevents a required allocation despite misleading free totals”; state which precondition or invariant it challenges.
- [ ] **UC-M02.04-C086-T02 · Safe fixture boundary:** Define the contained test boundary for “Allocator stress tests”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M02.04-C086-T03 · Valid control:** Construct a valid “Allocator stress tests” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M02.04-C086-T04 · Minimal adverse input:** Derive the “Allocator stress tests” adverse fixture from the control with the smallest documented change needed to reproduce “Fragmentation prevents a required allocation despite misleading free totals”; retain that change as reproducible data.
- [ ] **UC-M02.04-C086-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Allocator stress tests”; require “Allocator accounting matches owned live allocations” and forbid a false-success verdict.
- [ ] **UC-M02.04-C086-T06 · Adverse execution:** Exercise the “Allocator stress tests” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M02.04-C086-T07 · Effect inspection:** Inspect “Allocator stress tests” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M02.04-C086-T08 · Refusal versus failure:** Confirm the “Allocator stress tests” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M02.04-C086-T09 · Reset and retention:** Restore only the disposable “Allocator stress tests” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M02.04-C086-T10 · Negative regression:** Register the “Allocator stress tests” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M02.04-C087 · Change / failure test

**Original checklist item:** Exercise allocator stress tests when an invocation fails during allocation and a subsequent invocation starts; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M02.04-C087-T01 · Scenario record:** Write the “Allocator stress tests” change/failure scenario exactly as supplied: an invocation fails during allocation and a subsequent invocation starts; identify the property that must remain true: “Allocator accounting matches owned live allocations”.
- [ ] **UC-M02.04-C087-T02 · Baseline capture:** Create a known-valid “Allocator stress tests” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M02.04-C087-T03 · Injection map:** Locate the “Allocator stress tests” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M02.04-C087-T04 · Disposition oracle:** Define the legal intermediate and final “Allocator stress tests” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M02.04-C087-T05 · Controlled trigger:** Introduce the controlled “Allocator stress tests” scenario in the disposable fixture: an invocation fails during allocation and a subsequent invocation starts; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M02.04-C087-T06 · Intermediate inspection:** Inspect the “Allocator stress tests” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M02.04-C087-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Allocator stress tests”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M02.04-C087-T08 · Stale-evidence cleanup:** Invalidate superseded “Allocator stress tests” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M02.04-C087-T09 · Repeat and compare:** Repeat the selected “Allocator stress tests” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M02.04-C087-T10 · Failure evidence:** Publish the “Allocator stress tests” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M02.04-C088 · Bounds

**Original checklist item:** Choose, document and test limits for stress duration, allocation population and fragmentation metrics; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M02.04-C088-T01 · Quantity inventory:** Create a measurement inventory for “Allocator stress tests”: “Stress duration, allocation population and fragmentation metrics”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M02.04-C088-T02 · Measurement method:** Choose how to observe each “Allocator stress tests” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M02.04-C088-T03 · Budget decision:** Select justified resource and input limits for “Allocator stress tests”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M02.04-C088-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Allocator stress tests” cases for “Stress duration, allocation population and fragmentation metrics”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M02.04-C088-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Allocator stress tests” limit; preserve “Allocator accounting matches owned live allocations”.
- [ ] **UC-M02.04-C088-T06 · Normal measurement:** Run or review the normal “Allocator stress tests” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M02.04-C088-T07 · At-limit measurement:** Exercise the “Allocator stress tests” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M02.04-C088-T08 · Over-limit measurement:** Exercise the “Allocator stress tests” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M02.04-C088-T09 · Uncovered-scope report:** List the “Allocator stress tests” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M02.04-C088-T10 · Limit evidence:** Publish the selected “Allocator stress tests” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M02.04-C089 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for allocator stress tests with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M02.04-C089-T01 · Event inventory:** List the “Allocator stress tests” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M02.04-C089-T02 · Diagnostic schema:** Define nonsecret fields for “Allocator stress tests” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M02.04-C089-T03 · Failure mapping:** Map each documented “Allocator stress tests” refusal or error to a diagnostic outcome; include “Fragmentation prevents a required allocation despite misleading free totals” and prohibit conversion into a success message.
- [ ] **UC-M02.04-C089-T04 · Emission path:** Add the “Allocator stress tests” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M02.04-C089-T05 · Redaction check:** Test “Allocator stress tests” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M02.04-C089-T06 · Output budget:** Set and exercise bounded “Allocator stress tests” message size, rate and retention compatible with “Stress duration, allocation population and fragmentation metrics”; define truncation behavior that preserves the final reason.
- [ ] **UC-M02.04-C089-T07 · Success/refusal fixtures:** Capture “Allocator stress tests” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M02.04-C089-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Allocator stress tests” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M02.04-C089-T09 · Operator review:** Read the “Allocator stress tests” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M02.04-C089-T10 · Diagnostic evidence:** Publish redacted “Allocator stress tests” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M02.04-C090 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for allocator stress tests; label unexecuted checks as untested.

- [ ] **UC-M02.04-C090-T01 · Evidence inventory:** List the “Allocator stress tests” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M02.04-C090-T02 · Artifact references:** Record the exact “Allocator stress tests” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M02.04-C090-T03 · Fixture references:** Attach the “Allocator stress tests” fixture IDs, input identities and oracle definition; preserve the source counterexample “Fragmentation prevents a required allocation despite misleading free totals” as a distinct evidence case.
- [ ] **UC-M02.04-C090-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Allocator stress tests”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M02.04-C090-T05 · Environment record:** Record the actual “Allocator stress tests” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M02.04-C090-T06 · Expected versus observed:** Pair every “Allocator stress tests” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M02.04-C090-T07 · Failure and limit records:** Attach “Allocator stress tests” change/failure and bounds evidence where required; include uncovered “Stress duration, allocation population and fragmentation metrics” and unresolved violations of “Allocator accounting matches owned live allocations”.
- [ ] **UC-M02.04-C090-T08 · Evidence hygiene:** Check the “Allocator stress tests” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M02.04-C090-T09 · Reproduction review:** Have the “Allocator stress tests” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M02.04-C090-T10 · Acceptance linkage:** Link the “Allocator stress tests” evidence to its parent and UC-M02.04 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 10. Memory isolation acceptance

**Source delivery:** Run exhaustion and invalid-ownership fixtures alongside another guest.

**Source invariant:** A memory failure in one guest does not corrupt another guest's state.

**Source negative case:** One guest exhausts memory while a second verifies its own state.

**Source bounded quantities:** Parallel guests and host observation budget.

### UC-M02.04-C091 · Contract

**Original checklist item:** Specify memory isolation acceptance inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M02.04-C091-T01 · Scope statement:** Draft the operation boundary for “Memory isolation acceptance” within Guest allocator and memory lifecycle; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M02.04-C091-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Memory isolation acceptance”; record each producer, representation and missing-value meaning.
- [ ] **UC-M02.04-C091-T03 · Output inventory:** List the outputs of “Memory isolation acceptance” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M02.04-C091-T04 · Field dictionary:** Create a field-and-term dictionary for “Memory isolation acceptance”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M02.04-C091-T05 · Prerequisite contract:** Map “Memory isolation acceptance” to the source component prerequisites (UC-M02.03); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M02.04-C091-T06 · Authority map:** Identify who may produce, change and consume “Memory isolation acceptance”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M02.04-C091-T07 · Invariant clause:** Add a normative clause for “Memory isolation acceptance” that preserves “A memory failure in one guest does not corrupt another guest's state”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M02.04-C091-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Memory isolation acceptance”; include the source counterexample “One guest exhausts memory while a second verifies its own state” and the intended safe disposition.
- [ ] **UC-M02.04-C091-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Parallel guests and host observation budget” in the “Memory isolation acceptance” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M02.04-C091-T10 · Contract review:** Review the “Memory isolation acceptance” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M02.04-C092 · Delivery

**Original checklist item:** Run exhaustion and invalid-ownership fixtures alongside another guest.

- [ ] **UC-M02.04-C092-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Memory isolation acceptance”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M02.04-C092-T02 · Change plan:** Break the source delivery for “Memory isolation acceptance” into concrete edit targets and reviewable outputs; keep the UC-M02.04 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M02.04-C092-T03 · Core artifact:** Create the “Memory isolation acceptance” fixture or harness for this source instruction: Run exhaustion and invalid-ownership fixtures alongside another guest.
- [ ] **UC-M02.04-C092-T04 · Concrete realization:** Connect the “Memory isolation acceptance” harness to its actual intended target, set the expected oracle before running it, and distinguish a mock/control run from a target run.
- [ ] **UC-M02.04-C092-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Memory isolation acceptance” needed to preserve “A memory failure in one guest does not corrupt another guest's state”; record an enforcement gap where only a model exists.
- [ ] **UC-M02.04-C092-T06 · Dependency connection:** Connect the “Memory isolation acceptance” implementation to guest runtime allocations, stack setup and host-assigned memory regions; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M02.04-C092-T07 · Resource behavior:** Account for “Parallel guests and host observation budget” in “Memory isolation acceptance”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M02.04-C092-T08 · Delivery check:** Run the smallest real “Memory isolation acceptance” path and its adverse fixture “One guest exhausts memory while a second verifies its own state”; retain actual output, state effects and final disposition.
- [ ] **UC-M02.04-C092-T09 · Patch review:** Review the “Memory isolation acceptance” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M02.04-C092-T10 · Delivery handoff:** Publish the “Memory isolation acceptance” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M02.04-C093 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: A memory failure in one guest does not corrupt another guest's state. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M02.04-C093-T01 · Named property:** Create a stable property/check name under this parent for “Memory isolation acceptance”; copy its required invariant exactly: “A memory failure in one guest does not corrupt another guest's state”.
- [ ] **UC-M02.04-C093-T02 · Observable terms:** Define each term in the “Memory isolation acceptance” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M02.04-C093-T03 · Precondition set:** List the preconditions under which “A memory failure in one guest does not corrupt another guest's state” must hold for “Memory isolation acceptance”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M02.04-C093-T04 · Transition coverage:** Map the “Memory isolation acceptance” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M02.04-C093-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Memory isolation acceptance”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M02.04-C093-T06 · Satisfying fixture:** Create a concrete “Memory isolation acceptance” case that satisfies “A memory failure in one guest does not corrupt another guest's state”; record its expected observation before running the assertion or review.
- [ ] **UC-M02.04-C093-T07 · Violating fixture:** Create the source counterexample “One guest exhausts memory while a second verifies its own state” for “Memory isolation acceptance”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M02.04-C093-T08 · Enforcement evidence:** Exercise the “Memory isolation acceptance” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M02.04-C093-T09 · Regression linkage:** Link the “Memory isolation acceptance” property to changes in guest runtime allocations, stack setup and host-assigned memory regions; record which dependency or contract changes require rerunning it.
- [ ] **UC-M02.04-C093-T10 · Property disposition:** Compare the satisfying and violating “Memory isolation acceptance” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M02.04-C094 · Integration

**Original checklist item:** Integrate memory isolation acceptance with guest runtime allocations, stack setup and host-assigned memory regions; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M02.04-C094-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Memory isolation acceptance” across guest runtime allocations, stack setup and host-assigned memory regions; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M02.04-C094-T02 · Field mapping:** Map every “Memory isolation acceptance” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M02.04-C094-T03 · Prerequisite identities:** Record the actual prerequisites for “Memory isolation acceptance” (source dependency list: UC-M02.03); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M02.04-C094-T04 · Ownership agreement:** Specify who owns “Memory isolation acceptance” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M02.04-C094-T05 · Handoff implementation:** Connect “Memory isolation acceptance” through the mapped seam using the real adapter or explicit specification reference; preserve “A memory failure in one guest does not corrupt another guest's state” across the handoff.
- [ ] **UC-M02.04-C094-T06 · Absent-input case:** Omit one required “Memory isolation acceptance” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M02.04-C094-T07 · Stale-input case:** Supply an outdated “Memory isolation acceptance” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M02.04-C094-T08 · Incompatible-input case:** Supply an incompatible “Memory isolation acceptance” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M02.04-C094-T09 · Valid integration trace:** Run a valid “Memory isolation acceptance” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M02.04-C094-T10 · Seam review:** Reconcile the “Memory isolation acceptance” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M02.04-C095 · Valid-case test

**Original checklist item:** Run a valid-path fixture for memory isolation acceptance; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M02.04-C095-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Memory isolation acceptance” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M02.04-C095-T02 · Expected-result oracle:** Specify the “Memory isolation acceptance” expected result independently of the implementation output; include the property “A memory failure in one guest does not corrupt another guest's state” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M02.04-C095-T03 · Fixture material:** Create the concrete “Memory isolation acceptance” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M02.04-C095-T04 · Target preparation:** Prepare the “Memory isolation acceptance” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M02.04-C095-T05 · Initial-state record:** Record the initial “Memory isolation acceptance” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M02.04-C095-T06 · Valid-path execution:** Execute the “Memory isolation acceptance” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M02.04-C095-T07 · Outcome comparison:** Compare every declared “Memory isolation acceptance” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M02.04-C095-T08 · State and bounds check:** Inspect the “Memory isolation acceptance” ownership/state effects and actual use of “Parallel guests and host observation budget”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M02.04-C095-T09 · Repeatability check:** Repeat the same “Memory isolation acceptance” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M02.04-C095-T10 · Positive evidence:** Attach the “Memory isolation acceptance” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M02.04-C096 · Negative test

**Original checklist item:** Negative case: One guest exhausts memory while a second verifies its own state. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M02.04-C096-T01 · Adverse-case definition:** Create a test record for the exact “Memory isolation acceptance” source counterexample: “One guest exhausts memory while a second verifies its own state”; state which precondition or invariant it challenges.
- [ ] **UC-M02.04-C096-T02 · Safe fixture boundary:** Define the contained test boundary for “Memory isolation acceptance”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M02.04-C096-T03 · Valid control:** Construct a valid “Memory isolation acceptance” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M02.04-C096-T04 · Minimal adverse input:** Derive the “Memory isolation acceptance” adverse fixture from the control with the smallest documented change needed to reproduce “One guest exhausts memory while a second verifies its own state”; retain that change as reproducible data.
- [ ] **UC-M02.04-C096-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Memory isolation acceptance”; require “A memory failure in one guest does not corrupt another guest's state” and forbid a false-success verdict.
- [ ] **UC-M02.04-C096-T06 · Adverse execution:** Exercise the “Memory isolation acceptance” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M02.04-C096-T07 · Effect inspection:** Inspect “Memory isolation acceptance” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M02.04-C096-T08 · Refusal versus failure:** Confirm the “Memory isolation acceptance” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M02.04-C096-T09 · Reset and retention:** Restore only the disposable “Memory isolation acceptance” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M02.04-C096-T10 · Negative regression:** Register the “Memory isolation acceptance” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M02.04-C097 · Change / failure test

**Original checklist item:** Exercise memory isolation acceptance when an invocation fails during allocation and a subsequent invocation starts; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M02.04-C097-T01 · Scenario record:** Write the “Memory isolation acceptance” change/failure scenario exactly as supplied: an invocation fails during allocation and a subsequent invocation starts; identify the property that must remain true: “A memory failure in one guest does not corrupt another guest's state”.
- [ ] **UC-M02.04-C097-T02 · Baseline capture:** Create a known-valid “Memory isolation acceptance” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M02.04-C097-T03 · Injection map:** Locate the “Memory isolation acceptance” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M02.04-C097-T04 · Disposition oracle:** Define the legal intermediate and final “Memory isolation acceptance” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M02.04-C097-T05 · Controlled trigger:** Introduce the controlled “Memory isolation acceptance” scenario in the disposable fixture: an invocation fails during allocation and a subsequent invocation starts; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M02.04-C097-T06 · Intermediate inspection:** Inspect the “Memory isolation acceptance” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M02.04-C097-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Memory isolation acceptance”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M02.04-C097-T08 · Stale-evidence cleanup:** Invalidate superseded “Memory isolation acceptance” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M02.04-C097-T09 · Repeat and compare:** Repeat the selected “Memory isolation acceptance” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M02.04-C097-T10 · Failure evidence:** Publish the “Memory isolation acceptance” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M02.04-C098 · Bounds

**Original checklist item:** Choose, document and test limits for parallel guests and host observation budget; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M02.04-C098-T01 · Quantity inventory:** Create a measurement inventory for “Memory isolation acceptance”: “Parallel guests and host observation budget”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M02.04-C098-T02 · Measurement method:** Choose how to observe each “Memory isolation acceptance” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M02.04-C098-T03 · Budget decision:** Select justified resource and input limits for “Memory isolation acceptance”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M02.04-C098-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Memory isolation acceptance” cases for “Parallel guests and host observation budget”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M02.04-C098-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Memory isolation acceptance” limit; preserve “A memory failure in one guest does not corrupt another guest's state”.
- [ ] **UC-M02.04-C098-T06 · Normal measurement:** Run or review the normal “Memory isolation acceptance” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M02.04-C098-T07 · At-limit measurement:** Exercise the “Memory isolation acceptance” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M02.04-C098-T08 · Over-limit measurement:** Exercise the “Memory isolation acceptance” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M02.04-C098-T09 · Uncovered-scope report:** List the “Memory isolation acceptance” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M02.04-C098-T10 · Limit evidence:** Publish the selected “Memory isolation acceptance” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M02.04-C099 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for memory isolation acceptance with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M02.04-C099-T01 · Event inventory:** List the “Memory isolation acceptance” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M02.04-C099-T02 · Diagnostic schema:** Define nonsecret fields for “Memory isolation acceptance” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M02.04-C099-T03 · Failure mapping:** Map each documented “Memory isolation acceptance” refusal or error to a diagnostic outcome; include “One guest exhausts memory while a second verifies its own state” and prohibit conversion into a success message.
- [ ] **UC-M02.04-C099-T04 · Emission path:** Add the “Memory isolation acceptance” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M02.04-C099-T05 · Redaction check:** Test “Memory isolation acceptance” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M02.04-C099-T06 · Output budget:** Set and exercise bounded “Memory isolation acceptance” message size, rate and retention compatible with “Parallel guests and host observation budget”; define truncation behavior that preserves the final reason.
- [ ] **UC-M02.04-C099-T07 · Success/refusal fixtures:** Capture “Memory isolation acceptance” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M02.04-C099-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Memory isolation acceptance” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M02.04-C099-T09 · Operator review:** Read the “Memory isolation acceptance” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M02.04-C099-T10 · Diagnostic evidence:** Publish redacted “Memory isolation acceptance” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M02.04-C100 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for memory isolation acceptance; label unexecuted checks as untested.

- [ ] **UC-M02.04-C100-T01 · Evidence inventory:** List the “Memory isolation acceptance” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M02.04-C100-T02 · Artifact references:** Record the exact “Memory isolation acceptance” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M02.04-C100-T03 · Fixture references:** Attach the “Memory isolation acceptance” fixture IDs, input identities and oracle definition; preserve the source counterexample “One guest exhausts memory while a second verifies its own state” as a distinct evidence case.
- [ ] **UC-M02.04-C100-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Memory isolation acceptance”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M02.04-C100-T05 · Environment record:** Record the actual “Memory isolation acceptance” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M02.04-C100-T06 · Expected versus observed:** Pair every “Memory isolation acceptance” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M02.04-C100-T07 · Failure and limit records:** Attach “Memory isolation acceptance” change/failure and bounds evidence where required; include uncovered “Parallel guests and host observation budget” and unresolved violations of “A memory failure in one guest does not corrupt another guest's state”.
- [ ] **UC-M02.04-C100-T08 · Evidence hygiene:** Check the “Memory isolation acceptance” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M02.04-C100-T09 · Reproduction review:** Have the “Memory isolation acceptance” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M02.04-C100-T10 · Acceptance linkage:** Link the “Memory isolation acceptance” evidence to its parent and UC-M02.04 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

