# UC-M02.05 — Guest execution loop and scheduling

**To-Do Pack 2.0.0 · Baseline UC-2.2.0 · 100 parent checks × 10 subtasks = 1,000 to-dos**

[Master index](../../INDEX.md) · [Workstream index](../../w/02.md)

| Field | Preserved source value |
|---|---|
| Workstream | 02. Bootable unikernel guest |
| Milestone | B |
| Priority | P0 |
| Source assessment | MISSING |
| Scope | core or selected profile |
| Dependencies | [UC-M02.02](../02/UC-M02.02.md), [UC-M02.04](../02/UC-M02.04.md) |
| Source checklist pack | 1.0.0 |
| Original reference labels | [S1], [S2], [S3]. |

## Original requirement

Select cooperative, preemptive or run-to-completion semantics; implement required timers, interrupt handling and cancellation points.

**Original acceptance criterion:** A deliberately non-terminating workload can be stopped at the host boundary and cannot starve other guests.

**Source trace:** Original checklist `UC100/c/02/UC-M02.05.md` inside [s/checklists.zip](../../s/checklists.zip); exact parent records in [data/parents.jsonl](../../data/parents.jsonl). Original roadmap lines 188–198 are preserved in [s/roadmap.md](../../s/roadmap.md).

## How to use these lists

Every parent statement below is preserved verbatim. Its ten child tasks are proposed decomposition, not implemented capabilities or executed tests. Child IDs append `-T01` through `-T10` to the original parent ID. All begin unchecked / `TODO`. Design/review evidence does not establish runtime enforcement; observe the actual selected target where the parent requires it.

The source dependency graph and selected release profile determine applicability. The numbered child sequence is a local working order, not an added hard dependency graph. An unselected optional feature needs a recorded not-applicable rationale; missing prerequisites for selected work remain blockers. Numerical budgets, backends and trust mechanisms remain decisions unless fixed by the source. Test hostile cases only with synthetic inputs in authorized disposable environments.

## 01. Scheduling model selection

**Source delivery:** Choose cooperative, preemptive or run-to-completion execution for the first guest.

**Source invariant:** Scheduling claims correspond to the implemented execution model.

**Source negative case:** A run-to-completion engine is advertised as preemptively cancellable.

**Source bounded quantities:** Supported scheduling modes and runnable work count.

### UC-M02.05-C001 · Contract

**Original checklist item:** Specify scheduling model selection inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M02.05-C001-T01 · Scope statement:** Draft the operation boundary for “Scheduling model selection” within Guest execution loop and scheduling; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M02.05-C001-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Scheduling model selection”; record each producer, representation and missing-value meaning.
- [ ] **UC-M02.05-C001-T03 · Output inventory:** List the outputs of “Scheduling model selection” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M02.05-C001-T04 · Field dictionary:** Create a field-and-term dictionary for “Scheduling model selection”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M02.05-C001-T05 · Prerequisite contract:** Map “Scheduling model selection” to the source component prerequisites (UC-M02.02, UC-M02.04); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M02.05-C001-T06 · Authority map:** Identify who may produce, change and consume “Scheduling model selection”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M02.05-C001-T07 · Invariant clause:** Add a normative clause for “Scheduling model selection” that preserves “Scheduling claims correspond to the implemented execution model”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M02.05-C001-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Scheduling model selection”; include the source counterexample “A run-to-completion engine is advertised as preemptively cancellable” and the intended safe disposition.
- [ ] **UC-M02.05-C001-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Supported scheduling modes and runnable work count” in the “Scheduling model selection” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M02.05-C001-T10 · Contract review:** Review the “Scheduling model selection” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M02.05-C002 · Delivery

**Original checklist item:** Choose cooperative, preemptive or run-to-completion execution for the first guest.

- [ ] **UC-M02.05-C002-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Scheduling model selection”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M02.05-C002-T02 · Change plan:** Break the source delivery for “Scheduling model selection” into concrete edit targets and reviewable outputs; keep the UC-M02.05 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M02.05-C002-T03 · Core artifact:** Prepare the “Scheduling model selection” decision record for this source instruction: Choose cooperative, preemptive or run-to-completion execution for the first guest.
- [ ] **UC-M02.05-C002-T04 · Concrete realization:** Evaluate the “Scheduling model selection” choice against its declared constraints; record the exact selected target/configuration and rejected alternatives, leaving unverified compatibility as a blocker.
- [ ] **UC-M02.05-C002-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Scheduling model selection” needed to preserve “Scheduling claims correspond to the implemented execution model”; record an enforcement gap where only a model exists.
- [ ] **UC-M02.05-C002-T06 · Dependency connection:** Connect the “Scheduling model selection” implementation to guest work dispatch, timers and the independent host stop path; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M02.05-C002-T07 · Resource behavior:** Account for “Supported scheduling modes and runnable work count” in “Scheduling model selection”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M02.05-C002-T08 · Delivery check:** Run the smallest real “Scheduling model selection” path and its adverse fixture “A run-to-completion engine is advertised as preemptively cancellable”; retain actual output, state effects and final disposition.
- [ ] **UC-M02.05-C002-T09 · Patch review:** Review the “Scheduling model selection” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M02.05-C002-T10 · Delivery handoff:** Publish the “Scheduling model selection” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M02.05-C003 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Scheduling claims correspond to the implemented execution model. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M02.05-C003-T01 · Named property:** Create a stable property/check name under this parent for “Scheduling model selection”; copy its required invariant exactly: “Scheduling claims correspond to the implemented execution model”.
- [ ] **UC-M02.05-C003-T02 · Observable terms:** Define each term in the “Scheduling model selection” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M02.05-C003-T03 · Precondition set:** List the preconditions under which “Scheduling claims correspond to the implemented execution model” must hold for “Scheduling model selection”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M02.05-C003-T04 · Transition coverage:** Map the “Scheduling model selection” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M02.05-C003-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Scheduling model selection”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M02.05-C003-T06 · Satisfying fixture:** Create a concrete “Scheduling model selection” case that satisfies “Scheduling claims correspond to the implemented execution model”; record its expected observation before running the assertion or review.
- [ ] **UC-M02.05-C003-T07 · Violating fixture:** Create the source counterexample “A run-to-completion engine is advertised as preemptively cancellable” for “Scheduling model selection”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M02.05-C003-T08 · Enforcement evidence:** Exercise the “Scheduling model selection” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M02.05-C003-T09 · Regression linkage:** Link the “Scheduling model selection” property to changes in guest work dispatch, timers and the independent host stop path; record which dependency or contract changes require rerunning it.
- [ ] **UC-M02.05-C003-T10 · Property disposition:** Compare the satisfying and violating “Scheduling model selection” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M02.05-C004 · Integration

**Original checklist item:** Integrate scheduling model selection with guest work dispatch, timers and the independent host stop path; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M02.05-C004-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Scheduling model selection” across guest work dispatch, timers and the independent host stop path; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M02.05-C004-T02 · Field mapping:** Map every “Scheduling model selection” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M02.05-C004-T03 · Prerequisite identities:** Record the actual prerequisites for “Scheduling model selection” (source dependency list: UC-M02.02, UC-M02.04); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M02.05-C004-T04 · Ownership agreement:** Specify who owns “Scheduling model selection” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M02.05-C004-T05 · Handoff implementation:** Connect “Scheduling model selection” through the mapped seam using the real adapter or explicit specification reference; preserve “Scheduling claims correspond to the implemented execution model” across the handoff.
- [ ] **UC-M02.05-C004-T06 · Absent-input case:** Omit one required “Scheduling model selection” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M02.05-C004-T07 · Stale-input case:** Supply an outdated “Scheduling model selection” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M02.05-C004-T08 · Incompatible-input case:** Supply an incompatible “Scheduling model selection” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M02.05-C004-T09 · Valid integration trace:** Run a valid “Scheduling model selection” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M02.05-C004-T10 · Seam review:** Reconcile the “Scheduling model selection” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M02.05-C005 · Valid-case test

**Original checklist item:** Run a valid-path fixture for scheduling model selection; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M02.05-C005-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Scheduling model selection” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M02.05-C005-T02 · Expected-result oracle:** Specify the “Scheduling model selection” expected result independently of the implementation output; include the property “Scheduling claims correspond to the implemented execution model” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M02.05-C005-T03 · Fixture material:** Create the concrete “Scheduling model selection” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M02.05-C005-T04 · Target preparation:** Prepare the “Scheduling model selection” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M02.05-C005-T05 · Initial-state record:** Record the initial “Scheduling model selection” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M02.05-C005-T06 · Valid-path execution:** Execute the “Scheduling model selection” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M02.05-C005-T07 · Outcome comparison:** Compare every declared “Scheduling model selection” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M02.05-C005-T08 · State and bounds check:** Inspect the “Scheduling model selection” ownership/state effects and actual use of “Supported scheduling modes and runnable work count”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M02.05-C005-T09 · Repeatability check:** Repeat the same “Scheduling model selection” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M02.05-C005-T10 · Positive evidence:** Attach the “Scheduling model selection” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M02.05-C006 · Negative test

**Original checklist item:** Negative case: A run-to-completion engine is advertised as preemptively cancellable. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M02.05-C006-T01 · Adverse-case definition:** Create a test record for the exact “Scheduling model selection” source counterexample: “A run-to-completion engine is advertised as preemptively cancellable”; state which precondition or invariant it challenges.
- [ ] **UC-M02.05-C006-T02 · Safe fixture boundary:** Define the contained test boundary for “Scheduling model selection”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M02.05-C006-T03 · Valid control:** Construct a valid “Scheduling model selection” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M02.05-C006-T04 · Minimal adverse input:** Derive the “Scheduling model selection” adverse fixture from the control with the smallest documented change needed to reproduce “A run-to-completion engine is advertised as preemptively cancellable”; retain that change as reproducible data.
- [ ] **UC-M02.05-C006-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Scheduling model selection”; require “Scheduling claims correspond to the implemented execution model” and forbid a false-success verdict.
- [ ] **UC-M02.05-C006-T06 · Adverse execution:** Exercise the “Scheduling model selection” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M02.05-C006-T07 · Effect inspection:** Inspect “Scheduling model selection” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M02.05-C006-T08 · Refusal versus failure:** Confirm the “Scheduling model selection” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M02.05-C006-T09 · Reset and retention:** Restore only the disposable “Scheduling model selection” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M02.05-C006-T10 · Negative regression:** Register the “Scheduling model selection” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M02.05-C007 · Change / failure test

**Original checklist item:** Exercise scheduling model selection when an uncooperative guest ignores cancellation while another guest must keep progressing; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M02.05-C007-T01 · Scenario record:** Write the “Scheduling model selection” change/failure scenario exactly as supplied: an uncooperative guest ignores cancellation while another guest must keep progressing; identify the property that must remain true: “Scheduling claims correspond to the implemented execution model”.
- [ ] **UC-M02.05-C007-T02 · Baseline capture:** Create a known-valid “Scheduling model selection” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M02.05-C007-T03 · Injection map:** Locate the “Scheduling model selection” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M02.05-C007-T04 · Disposition oracle:** Define the legal intermediate and final “Scheduling model selection” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M02.05-C007-T05 · Controlled trigger:** Introduce the controlled “Scheduling model selection” scenario in the disposable fixture: an uncooperative guest ignores cancellation while another guest must keep progressing; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M02.05-C007-T06 · Intermediate inspection:** Inspect the “Scheduling model selection” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M02.05-C007-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Scheduling model selection”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M02.05-C007-T08 · Stale-evidence cleanup:** Invalidate superseded “Scheduling model selection” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M02.05-C007-T09 · Repeat and compare:** Repeat the selected “Scheduling model selection” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M02.05-C007-T10 · Failure evidence:** Publish the “Scheduling model selection” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M02.05-C008 · Bounds

**Original checklist item:** Choose, document and test limits for supported scheduling modes and runnable work count; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M02.05-C008-T01 · Quantity inventory:** Create a measurement inventory for “Scheduling model selection”: “Supported scheduling modes and runnable work count”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M02.05-C008-T02 · Measurement method:** Choose how to observe each “Scheduling model selection” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M02.05-C008-T03 · Budget decision:** Select justified resource and input limits for “Scheduling model selection”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M02.05-C008-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Scheduling model selection” cases for “Supported scheduling modes and runnable work count”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M02.05-C008-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Scheduling model selection” limit; preserve “Scheduling claims correspond to the implemented execution model”.
- [ ] **UC-M02.05-C008-T06 · Normal measurement:** Run or review the normal “Scheduling model selection” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M02.05-C008-T07 · At-limit measurement:** Exercise the “Scheduling model selection” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M02.05-C008-T08 · Over-limit measurement:** Exercise the “Scheduling model selection” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M02.05-C008-T09 · Uncovered-scope report:** List the “Scheduling model selection” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M02.05-C008-T10 · Limit evidence:** Publish the selected “Scheduling model selection” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M02.05-C009 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for scheduling model selection with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M02.05-C009-T01 · Event inventory:** List the “Scheduling model selection” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M02.05-C009-T02 · Diagnostic schema:** Define nonsecret fields for “Scheduling model selection” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M02.05-C009-T03 · Failure mapping:** Map each documented “Scheduling model selection” refusal or error to a diagnostic outcome; include “A run-to-completion engine is advertised as preemptively cancellable” and prohibit conversion into a success message.
- [ ] **UC-M02.05-C009-T04 · Emission path:** Add the “Scheduling model selection” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M02.05-C009-T05 · Redaction check:** Test “Scheduling model selection” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M02.05-C009-T06 · Output budget:** Set and exercise bounded “Scheduling model selection” message size, rate and retention compatible with “Supported scheduling modes and runnable work count”; define truncation behavior that preserves the final reason.
- [ ] **UC-M02.05-C009-T07 · Success/refusal fixtures:** Capture “Scheduling model selection” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M02.05-C009-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Scheduling model selection” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M02.05-C009-T09 · Operator review:** Read the “Scheduling model selection” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M02.05-C009-T10 · Diagnostic evidence:** Publish redacted “Scheduling model selection” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M02.05-C010 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for scheduling model selection; label unexecuted checks as untested.

- [ ] **UC-M02.05-C010-T01 · Evidence inventory:** List the “Scheduling model selection” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M02.05-C010-T02 · Artifact references:** Record the exact “Scheduling model selection” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M02.05-C010-T03 · Fixture references:** Attach the “Scheduling model selection” fixture IDs, input identities and oracle definition; preserve the source counterexample “A run-to-completion engine is advertised as preemptively cancellable” as a distinct evidence case.
- [ ] **UC-M02.05-C010-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Scheduling model selection”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M02.05-C010-T05 · Environment record:** Record the actual “Scheduling model selection” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M02.05-C010-T06 · Expected versus observed:** Pair every “Scheduling model selection” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M02.05-C010-T07 · Failure and limit records:** Attach “Scheduling model selection” change/failure and bounds evidence where required; include uncovered “Supported scheduling modes and runnable work count” and unresolved violations of “Scheduling claims correspond to the implemented execution model”.
- [ ] **UC-M02.05-C010-T08 · Evidence hygiene:** Check the “Scheduling model selection” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M02.05-C010-T09 · Reproduction review:** Have the “Scheduling model selection” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M02.05-C010-T10 · Acceptance linkage:** Link the “Scheduling model selection” evidence to its parent and UC-M02.05 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 02. Execution-loop ownership

**Source delivery:** Define the loop that receives work, executes it and publishes completion.

**Source invariant:** Only the designated owner advances an invocation's execution state.

**Source negative case:** Two loop paths concurrently publish completion for one invocation.

**Source bounded quantities:** In-flight invocations and loop iteration work.

### UC-M02.05-C011 · Contract

**Original checklist item:** Specify execution-loop ownership inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M02.05-C011-T01 · Scope statement:** Draft the operation boundary for “Execution-loop ownership” within Guest execution loop and scheduling; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M02.05-C011-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Execution-loop ownership”; record each producer, representation and missing-value meaning.
- [ ] **UC-M02.05-C011-T03 · Output inventory:** List the outputs of “Execution-loop ownership” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M02.05-C011-T04 · Field dictionary:** Create a field-and-term dictionary for “Execution-loop ownership”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M02.05-C011-T05 · Prerequisite contract:** Map “Execution-loop ownership” to the source component prerequisites (UC-M02.02, UC-M02.04); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M02.05-C011-T06 · Authority map:** Identify who may produce, change and consume “Execution-loop ownership”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M02.05-C011-T07 · Invariant clause:** Add a normative clause for “Execution-loop ownership” that preserves “Only the designated owner advances an invocation's execution state”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M02.05-C011-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Execution-loop ownership”; include the source counterexample “Two loop paths concurrently publish completion for one invocation” and the intended safe disposition.
- [ ] **UC-M02.05-C011-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “In-flight invocations and loop iteration work” in the “Execution-loop ownership” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M02.05-C011-T10 · Contract review:** Review the “Execution-loop ownership” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M02.05-C012 · Delivery

**Original checklist item:** Define the loop that receives work, executes it and publishes completion.

- [ ] **UC-M02.05-C012-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Execution-loop ownership”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M02.05-C012-T02 · Change plan:** Break the source delivery for “Execution-loop ownership” into concrete edit targets and reviewable outputs; keep the UC-M02.05 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M02.05-C012-T03 · Core artifact:** Create the “Execution-loop ownership” model, schema or inventory that realizes this source instruction: Define the loop that receives work, executes it and publishes completion.
- [ ] **UC-M02.05-C012-T04 · Concrete realization:** Populate “Execution-loop ownership” with one concrete worked case; map every required entity or field to its source and flag any unmapped entry.
- [ ] **UC-M02.05-C012-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Execution-loop ownership” needed to preserve “Only the designated owner advances an invocation's execution state”; record an enforcement gap where only a model exists.
- [ ] **UC-M02.05-C012-T06 · Dependency connection:** Connect the “Execution-loop ownership” implementation to guest work dispatch, timers and the independent host stop path; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M02.05-C012-T07 · Resource behavior:** Account for “In-flight invocations and loop iteration work” in “Execution-loop ownership”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M02.05-C012-T08 · Delivery check:** Run the smallest real “Execution-loop ownership” path and its adverse fixture “Two loop paths concurrently publish completion for one invocation”; retain actual output, state effects and final disposition.
- [ ] **UC-M02.05-C012-T09 · Patch review:** Review the “Execution-loop ownership” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M02.05-C012-T10 · Delivery handoff:** Publish the “Execution-loop ownership” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M02.05-C013 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Only the designated owner advances an invocation's execution state. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M02.05-C013-T01 · Named property:** Create a stable property/check name under this parent for “Execution-loop ownership”; copy its required invariant exactly: “Only the designated owner advances an invocation's execution state”.
- [ ] **UC-M02.05-C013-T02 · Observable terms:** Define each term in the “Execution-loop ownership” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M02.05-C013-T03 · Precondition set:** List the preconditions under which “Only the designated owner advances an invocation's execution state” must hold for “Execution-loop ownership”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M02.05-C013-T04 · Transition coverage:** Map the “Execution-loop ownership” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M02.05-C013-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Execution-loop ownership”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M02.05-C013-T06 · Satisfying fixture:** Create a concrete “Execution-loop ownership” case that satisfies “Only the designated owner advances an invocation's execution state”; record its expected observation before running the assertion or review.
- [ ] **UC-M02.05-C013-T07 · Violating fixture:** Create the source counterexample “Two loop paths concurrently publish completion for one invocation” for “Execution-loop ownership”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M02.05-C013-T08 · Enforcement evidence:** Exercise the “Execution-loop ownership” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M02.05-C013-T09 · Regression linkage:** Link the “Execution-loop ownership” property to changes in guest work dispatch, timers and the independent host stop path; record which dependency or contract changes require rerunning it.
- [ ] **UC-M02.05-C013-T10 · Property disposition:** Compare the satisfying and violating “Execution-loop ownership” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M02.05-C014 · Integration

**Original checklist item:** Integrate execution-loop ownership with guest work dispatch, timers and the independent host stop path; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M02.05-C014-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Execution-loop ownership” across guest work dispatch, timers and the independent host stop path; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M02.05-C014-T02 · Field mapping:** Map every “Execution-loop ownership” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M02.05-C014-T03 · Prerequisite identities:** Record the actual prerequisites for “Execution-loop ownership” (source dependency list: UC-M02.02, UC-M02.04); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M02.05-C014-T04 · Ownership agreement:** Specify who owns “Execution-loop ownership” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M02.05-C014-T05 · Handoff implementation:** Connect “Execution-loop ownership” through the mapped seam using the real adapter or explicit specification reference; preserve “Only the designated owner advances an invocation's execution state” across the handoff.
- [ ] **UC-M02.05-C014-T06 · Absent-input case:** Omit one required “Execution-loop ownership” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M02.05-C014-T07 · Stale-input case:** Supply an outdated “Execution-loop ownership” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M02.05-C014-T08 · Incompatible-input case:** Supply an incompatible “Execution-loop ownership” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M02.05-C014-T09 · Valid integration trace:** Run a valid “Execution-loop ownership” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M02.05-C014-T10 · Seam review:** Reconcile the “Execution-loop ownership” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M02.05-C015 · Valid-case test

**Original checklist item:** Run a valid-path fixture for execution-loop ownership; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M02.05-C015-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Execution-loop ownership” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M02.05-C015-T02 · Expected-result oracle:** Specify the “Execution-loop ownership” expected result independently of the implementation output; include the property “Only the designated owner advances an invocation's execution state” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M02.05-C015-T03 · Fixture material:** Create the concrete “Execution-loop ownership” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M02.05-C015-T04 · Target preparation:** Prepare the “Execution-loop ownership” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M02.05-C015-T05 · Initial-state record:** Record the initial “Execution-loop ownership” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M02.05-C015-T06 · Valid-path execution:** Execute the “Execution-loop ownership” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M02.05-C015-T07 · Outcome comparison:** Compare every declared “Execution-loop ownership” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M02.05-C015-T08 · State and bounds check:** Inspect the “Execution-loop ownership” ownership/state effects and actual use of “In-flight invocations and loop iteration work”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M02.05-C015-T09 · Repeatability check:** Repeat the same “Execution-loop ownership” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M02.05-C015-T10 · Positive evidence:** Attach the “Execution-loop ownership” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M02.05-C016 · Negative test

**Original checklist item:** Negative case: Two loop paths concurrently publish completion for one invocation. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M02.05-C016-T01 · Adverse-case definition:** Create a test record for the exact “Execution-loop ownership” source counterexample: “Two loop paths concurrently publish completion for one invocation”; state which precondition or invariant it challenges.
- [ ] **UC-M02.05-C016-T02 · Safe fixture boundary:** Define the contained test boundary for “Execution-loop ownership”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M02.05-C016-T03 · Valid control:** Construct a valid “Execution-loop ownership” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M02.05-C016-T04 · Minimal adverse input:** Derive the “Execution-loop ownership” adverse fixture from the control with the smallest documented change needed to reproduce “Two loop paths concurrently publish completion for one invocation”; retain that change as reproducible data.
- [ ] **UC-M02.05-C016-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Execution-loop ownership”; require “Only the designated owner advances an invocation's execution state” and forbid a false-success verdict.
- [ ] **UC-M02.05-C016-T06 · Adverse execution:** Exercise the “Execution-loop ownership” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M02.05-C016-T07 · Effect inspection:** Inspect “Execution-loop ownership” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M02.05-C016-T08 · Refusal versus failure:** Confirm the “Execution-loop ownership” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M02.05-C016-T09 · Reset and retention:** Restore only the disposable “Execution-loop ownership” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M02.05-C016-T10 · Negative regression:** Register the “Execution-loop ownership” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M02.05-C017 · Change / failure test

**Original checklist item:** Exercise execution-loop ownership when an uncooperative guest ignores cancellation while another guest must keep progressing; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M02.05-C017-T01 · Scenario record:** Write the “Execution-loop ownership” change/failure scenario exactly as supplied: an uncooperative guest ignores cancellation while another guest must keep progressing; identify the property that must remain true: “Only the designated owner advances an invocation's execution state”.
- [ ] **UC-M02.05-C017-T02 · Baseline capture:** Create a known-valid “Execution-loop ownership” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M02.05-C017-T03 · Injection map:** Locate the “Execution-loop ownership” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M02.05-C017-T04 · Disposition oracle:** Define the legal intermediate and final “Execution-loop ownership” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M02.05-C017-T05 · Controlled trigger:** Introduce the controlled “Execution-loop ownership” scenario in the disposable fixture: an uncooperative guest ignores cancellation while another guest must keep progressing; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M02.05-C017-T06 · Intermediate inspection:** Inspect the “Execution-loop ownership” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M02.05-C017-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Execution-loop ownership”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M02.05-C017-T08 · Stale-evidence cleanup:** Invalidate superseded “Execution-loop ownership” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M02.05-C017-T09 · Repeat and compare:** Repeat the selected “Execution-loop ownership” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M02.05-C017-T10 · Failure evidence:** Publish the “Execution-loop ownership” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M02.05-C018 · Bounds

**Original checklist item:** Choose, document and test limits for in-flight invocations and loop iteration work; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M02.05-C018-T01 · Quantity inventory:** Create a measurement inventory for “Execution-loop ownership”: “In-flight invocations and loop iteration work”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M02.05-C018-T02 · Measurement method:** Choose how to observe each “Execution-loop ownership” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M02.05-C018-T03 · Budget decision:** Select justified resource and input limits for “Execution-loop ownership”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M02.05-C018-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Execution-loop ownership” cases for “In-flight invocations and loop iteration work”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M02.05-C018-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Execution-loop ownership” limit; preserve “Only the designated owner advances an invocation's execution state”.
- [ ] **UC-M02.05-C018-T06 · Normal measurement:** Run or review the normal “Execution-loop ownership” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M02.05-C018-T07 · At-limit measurement:** Exercise the “Execution-loop ownership” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M02.05-C018-T08 · Over-limit measurement:** Exercise the “Execution-loop ownership” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M02.05-C018-T09 · Uncovered-scope report:** List the “Execution-loop ownership” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M02.05-C018-T10 · Limit evidence:** Publish the selected “Execution-loop ownership” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M02.05-C019 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for execution-loop ownership with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M02.05-C019-T01 · Event inventory:** List the “Execution-loop ownership” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M02.05-C019-T02 · Diagnostic schema:** Define nonsecret fields for “Execution-loop ownership” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M02.05-C019-T03 · Failure mapping:** Map each documented “Execution-loop ownership” refusal or error to a diagnostic outcome; include “Two loop paths concurrently publish completion for one invocation” and prohibit conversion into a success message.
- [ ] **UC-M02.05-C019-T04 · Emission path:** Add the “Execution-loop ownership” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M02.05-C019-T05 · Redaction check:** Test “Execution-loop ownership” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M02.05-C019-T06 · Output budget:** Set and exercise bounded “Execution-loop ownership” message size, rate and retention compatible with “In-flight invocations and loop iteration work”; define truncation behavior that preserves the final reason.
- [ ] **UC-M02.05-C019-T07 · Success/refusal fixtures:** Capture “Execution-loop ownership” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M02.05-C019-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Execution-loop ownership” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M02.05-C019-T09 · Operator review:** Read the “Execution-loop ownership” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M02.05-C019-T10 · Diagnostic evidence:** Publish redacted “Execution-loop ownership” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M02.05-C020 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for execution-loop ownership; label unexecuted checks as untested.

- [ ] **UC-M02.05-C020-T01 · Evidence inventory:** List the “Execution-loop ownership” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M02.05-C020-T02 · Artifact references:** Record the exact “Execution-loop ownership” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M02.05-C020-T03 · Fixture references:** Attach the “Execution-loop ownership” fixture IDs, input identities and oracle definition; preserve the source counterexample “Two loop paths concurrently publish completion for one invocation” as a distinct evidence case.
- [ ] **UC-M02.05-C020-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Execution-loop ownership”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M02.05-C020-T05 · Environment record:** Record the actual “Execution-loop ownership” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M02.05-C020-T06 · Expected versus observed:** Pair every “Execution-loop ownership” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M02.05-C020-T07 · Failure and limit records:** Attach “Execution-loop ownership” change/failure and bounds evidence where required; include uncovered “In-flight invocations and loop iteration work” and unresolved violations of “Only the designated owner advances an invocation's execution state”.
- [ ] **UC-M02.05-C020-T08 · Evidence hygiene:** Check the “Execution-loop ownership” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M02.05-C020-T09 · Reproduction review:** Have the “Execution-loop ownership” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M02.05-C020-T10 · Acceptance linkage:** Link the “Execution-loop ownership” evidence to its parent and UC-M02.05 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 03. Runnable work representation

**Source delivery:** Represent pending and active guest work with explicit state and identity.

**Source invariant:** A canceled work item cannot be resumed as a new active invocation.

**Source negative case:** A stale queue entry survives replacement of its invocation.

**Source bounded quantities:** Queue entries and work descriptor bytes.

### UC-M02.05-C021 · Contract

**Original checklist item:** Specify runnable work representation inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M02.05-C021-T01 · Scope statement:** Draft the operation boundary for “Runnable work representation” within Guest execution loop and scheduling; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M02.05-C021-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Runnable work representation”; record each producer, representation and missing-value meaning.
- [ ] **UC-M02.05-C021-T03 · Output inventory:** List the outputs of “Runnable work representation” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M02.05-C021-T04 · Field dictionary:** Create a field-and-term dictionary for “Runnable work representation”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M02.05-C021-T05 · Prerequisite contract:** Map “Runnable work representation” to the source component prerequisites (UC-M02.02, UC-M02.04); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M02.05-C021-T06 · Authority map:** Identify who may produce, change and consume “Runnable work representation”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M02.05-C021-T07 · Invariant clause:** Add a normative clause for “Runnable work representation” that preserves “A canceled work item cannot be resumed as a new active invocation”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M02.05-C021-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Runnable work representation”; include the source counterexample “A stale queue entry survives replacement of its invocation” and the intended safe disposition.
- [ ] **UC-M02.05-C021-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Queue entries and work descriptor bytes” in the “Runnable work representation” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M02.05-C021-T10 · Contract review:** Review the “Runnable work representation” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M02.05-C022 · Delivery

**Original checklist item:** Represent pending and active guest work with explicit state and identity.

- [ ] **UC-M02.05-C022-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Runnable work representation”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M02.05-C022-T02 · Change plan:** Break the source delivery for “Runnable work representation” into concrete edit targets and reviewable outputs; keep the UC-M02.05 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M02.05-C022-T03 · Core artifact:** Create the “Runnable work representation” model, schema or inventory that realizes this source instruction: Represent pending and active guest work with explicit state and identity.
- [ ] **UC-M02.05-C022-T04 · Concrete realization:** Populate “Runnable work representation” with one concrete worked case; map every required entity or field to its source and flag any unmapped entry.
- [ ] **UC-M02.05-C022-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Runnable work representation” needed to preserve “A canceled work item cannot be resumed as a new active invocation”; record an enforcement gap where only a model exists.
- [ ] **UC-M02.05-C022-T06 · Dependency connection:** Connect the “Runnable work representation” implementation to guest work dispatch, timers and the independent host stop path; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M02.05-C022-T07 · Resource behavior:** Account for “Queue entries and work descriptor bytes” in “Runnable work representation”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M02.05-C022-T08 · Delivery check:** Run the smallest real “Runnable work representation” path and its adverse fixture “A stale queue entry survives replacement of its invocation”; retain actual output, state effects and final disposition.
- [ ] **UC-M02.05-C022-T09 · Patch review:** Review the “Runnable work representation” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M02.05-C022-T10 · Delivery handoff:** Publish the “Runnable work representation” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M02.05-C023 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: A canceled work item cannot be resumed as a new active invocation. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M02.05-C023-T01 · Named property:** Create a stable property/check name under this parent for “Runnable work representation”; copy its required invariant exactly: “A canceled work item cannot be resumed as a new active invocation”.
- [ ] **UC-M02.05-C023-T02 · Observable terms:** Define each term in the “Runnable work representation” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M02.05-C023-T03 · Precondition set:** List the preconditions under which “A canceled work item cannot be resumed as a new active invocation” must hold for “Runnable work representation”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M02.05-C023-T04 · Transition coverage:** Map the “Runnable work representation” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M02.05-C023-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Runnable work representation”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M02.05-C023-T06 · Satisfying fixture:** Create a concrete “Runnable work representation” case that satisfies “A canceled work item cannot be resumed as a new active invocation”; record its expected observation before running the assertion or review.
- [ ] **UC-M02.05-C023-T07 · Violating fixture:** Create the source counterexample “A stale queue entry survives replacement of its invocation” for “Runnable work representation”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M02.05-C023-T08 · Enforcement evidence:** Exercise the “Runnable work representation” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M02.05-C023-T09 · Regression linkage:** Link the “Runnable work representation” property to changes in guest work dispatch, timers and the independent host stop path; record which dependency or contract changes require rerunning it.
- [ ] **UC-M02.05-C023-T10 · Property disposition:** Compare the satisfying and violating “Runnable work representation” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M02.05-C024 · Integration

**Original checklist item:** Integrate runnable work representation with guest work dispatch, timers and the independent host stop path; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M02.05-C024-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Runnable work representation” across guest work dispatch, timers and the independent host stop path; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M02.05-C024-T02 · Field mapping:** Map every “Runnable work representation” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M02.05-C024-T03 · Prerequisite identities:** Record the actual prerequisites for “Runnable work representation” (source dependency list: UC-M02.02, UC-M02.04); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M02.05-C024-T04 · Ownership agreement:** Specify who owns “Runnable work representation” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M02.05-C024-T05 · Handoff implementation:** Connect “Runnable work representation” through the mapped seam using the real adapter or explicit specification reference; preserve “A canceled work item cannot be resumed as a new active invocation” across the handoff.
- [ ] **UC-M02.05-C024-T06 · Absent-input case:** Omit one required “Runnable work representation” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M02.05-C024-T07 · Stale-input case:** Supply an outdated “Runnable work representation” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M02.05-C024-T08 · Incompatible-input case:** Supply an incompatible “Runnable work representation” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M02.05-C024-T09 · Valid integration trace:** Run a valid “Runnable work representation” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M02.05-C024-T10 · Seam review:** Reconcile the “Runnable work representation” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M02.05-C025 · Valid-case test

**Original checklist item:** Run a valid-path fixture for runnable work representation; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M02.05-C025-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Runnable work representation” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M02.05-C025-T02 · Expected-result oracle:** Specify the “Runnable work representation” expected result independently of the implementation output; include the property “A canceled work item cannot be resumed as a new active invocation” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M02.05-C025-T03 · Fixture material:** Create the concrete “Runnable work representation” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M02.05-C025-T04 · Target preparation:** Prepare the “Runnable work representation” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M02.05-C025-T05 · Initial-state record:** Record the initial “Runnable work representation” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M02.05-C025-T06 · Valid-path execution:** Execute the “Runnable work representation” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M02.05-C025-T07 · Outcome comparison:** Compare every declared “Runnable work representation” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M02.05-C025-T08 · State and bounds check:** Inspect the “Runnable work representation” ownership/state effects and actual use of “Queue entries and work descriptor bytes”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M02.05-C025-T09 · Repeatability check:** Repeat the same “Runnable work representation” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M02.05-C025-T10 · Positive evidence:** Attach the “Runnable work representation” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M02.05-C026 · Negative test

**Original checklist item:** Negative case: A stale queue entry survives replacement of its invocation. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M02.05-C026-T01 · Adverse-case definition:** Create a test record for the exact “Runnable work representation” source counterexample: “A stale queue entry survives replacement of its invocation”; state which precondition or invariant it challenges.
- [ ] **UC-M02.05-C026-T02 · Safe fixture boundary:** Define the contained test boundary for “Runnable work representation”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M02.05-C026-T03 · Valid control:** Construct a valid “Runnable work representation” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M02.05-C026-T04 · Minimal adverse input:** Derive the “Runnable work representation” adverse fixture from the control with the smallest documented change needed to reproduce “A stale queue entry survives replacement of its invocation”; retain that change as reproducible data.
- [ ] **UC-M02.05-C026-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Runnable work representation”; require “A canceled work item cannot be resumed as a new active invocation” and forbid a false-success verdict.
- [ ] **UC-M02.05-C026-T06 · Adverse execution:** Exercise the “Runnable work representation” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M02.05-C026-T07 · Effect inspection:** Inspect “Runnable work representation” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M02.05-C026-T08 · Refusal versus failure:** Confirm the “Runnable work representation” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M02.05-C026-T09 · Reset and retention:** Restore only the disposable “Runnable work representation” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M02.05-C026-T10 · Negative regression:** Register the “Runnable work representation” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M02.05-C027 · Change / failure test

**Original checklist item:** Exercise runnable work representation when an uncooperative guest ignores cancellation while another guest must keep progressing; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M02.05-C027-T01 · Scenario record:** Write the “Runnable work representation” change/failure scenario exactly as supplied: an uncooperative guest ignores cancellation while another guest must keep progressing; identify the property that must remain true: “A canceled work item cannot be resumed as a new active invocation”.
- [ ] **UC-M02.05-C027-T02 · Baseline capture:** Create a known-valid “Runnable work representation” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M02.05-C027-T03 · Injection map:** Locate the “Runnable work representation” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M02.05-C027-T04 · Disposition oracle:** Define the legal intermediate and final “Runnable work representation” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M02.05-C027-T05 · Controlled trigger:** Introduce the controlled “Runnable work representation” scenario in the disposable fixture: an uncooperative guest ignores cancellation while another guest must keep progressing; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M02.05-C027-T06 · Intermediate inspection:** Inspect the “Runnable work representation” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M02.05-C027-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Runnable work representation”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M02.05-C027-T08 · Stale-evidence cleanup:** Invalidate superseded “Runnable work representation” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M02.05-C027-T09 · Repeat and compare:** Repeat the selected “Runnable work representation” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M02.05-C027-T10 · Failure evidence:** Publish the “Runnable work representation” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M02.05-C028 · Bounds

**Original checklist item:** Choose, document and test limits for queue entries and work descriptor bytes; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M02.05-C028-T01 · Quantity inventory:** Create a measurement inventory for “Runnable work representation”: “Queue entries and work descriptor bytes”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M02.05-C028-T02 · Measurement method:** Choose how to observe each “Runnable work representation” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M02.05-C028-T03 · Budget decision:** Select justified resource and input limits for “Runnable work representation”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M02.05-C028-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Runnable work representation” cases for “Queue entries and work descriptor bytes”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M02.05-C028-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Runnable work representation” limit; preserve “A canceled work item cannot be resumed as a new active invocation”.
- [ ] **UC-M02.05-C028-T06 · Normal measurement:** Run or review the normal “Runnable work representation” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M02.05-C028-T07 · At-limit measurement:** Exercise the “Runnable work representation” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M02.05-C028-T08 · Over-limit measurement:** Exercise the “Runnable work representation” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M02.05-C028-T09 · Uncovered-scope report:** List the “Runnable work representation” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M02.05-C028-T10 · Limit evidence:** Publish the selected “Runnable work representation” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M02.05-C029 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for runnable work representation with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M02.05-C029-T01 · Event inventory:** List the “Runnable work representation” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M02.05-C029-T02 · Diagnostic schema:** Define nonsecret fields for “Runnable work representation” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M02.05-C029-T03 · Failure mapping:** Map each documented “Runnable work representation” refusal or error to a diagnostic outcome; include “A stale queue entry survives replacement of its invocation” and prohibit conversion into a success message.
- [ ] **UC-M02.05-C029-T04 · Emission path:** Add the “Runnable work representation” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M02.05-C029-T05 · Redaction check:** Test “Runnable work representation” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M02.05-C029-T06 · Output budget:** Set and exercise bounded “Runnable work representation” message size, rate and retention compatible with “Queue entries and work descriptor bytes”; define truncation behavior that preserves the final reason.
- [ ] **UC-M02.05-C029-T07 · Success/refusal fixtures:** Capture “Runnable work representation” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M02.05-C029-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Runnable work representation” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M02.05-C029-T09 · Operator review:** Read the “Runnable work representation” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M02.05-C029-T10 · Diagnostic evidence:** Publish redacted “Runnable work representation” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M02.05-C030 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for runnable work representation; label unexecuted checks as untested.

- [ ] **UC-M02.05-C030-T01 · Evidence inventory:** List the “Runnable work representation” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M02.05-C030-T02 · Artifact references:** Record the exact “Runnable work representation” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M02.05-C030-T03 · Fixture references:** Attach the “Runnable work representation” fixture IDs, input identities and oracle definition; preserve the source counterexample “A stale queue entry survives replacement of its invocation” as a distinct evidence case.
- [ ] **UC-M02.05-C030-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Runnable work representation”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M02.05-C030-T05 · Environment record:** Record the actual “Runnable work representation” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M02.05-C030-T06 · Expected versus observed:** Pair every “Runnable work representation” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M02.05-C030-T07 · Failure and limit records:** Attach “Runnable work representation” change/failure and bounds evidence where required; include uncovered “Queue entries and work descriptor bytes” and unresolved violations of “A canceled work item cannot be resumed as a new active invocation”.
- [ ] **UC-M02.05-C030-T08 · Evidence hygiene:** Check the “Runnable work representation” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M02.05-C030-T09 · Reproduction review:** Have the “Runnable work representation” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M02.05-C030-T10 · Acceptance linkage:** Link the “Runnable work representation” evidence to its parent and UC-M02.05 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 04. Timer integration

**Source delivery:** Integrate only timers required by the selected scheduling semantics.

**Source invariant:** Timer callbacks operate on valid current guest state.

**Source negative case:** A timer fires after its invocation has been retired.

**Source bounded quantities:** Timer count and callback execution budget.

### UC-M02.05-C031 · Contract

**Original checklist item:** Specify timer integration inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M02.05-C031-T01 · Scope statement:** Draft the operation boundary for “Timer integration” within Guest execution loop and scheduling; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M02.05-C031-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Timer integration”; record each producer, representation and missing-value meaning.
- [ ] **UC-M02.05-C031-T03 · Output inventory:** List the outputs of “Timer integration” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M02.05-C031-T04 · Field dictionary:** Create a field-and-term dictionary for “Timer integration”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M02.05-C031-T05 · Prerequisite contract:** Map “Timer integration” to the source component prerequisites (UC-M02.02, UC-M02.04); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M02.05-C031-T06 · Authority map:** Identify who may produce, change and consume “Timer integration”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M02.05-C031-T07 · Invariant clause:** Add a normative clause for “Timer integration” that preserves “Timer callbacks operate on valid current guest state”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M02.05-C031-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Timer integration”; include the source counterexample “A timer fires after its invocation has been retired” and the intended safe disposition.
- [ ] **UC-M02.05-C031-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Timer count and callback execution budget” in the “Timer integration” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M02.05-C031-T10 · Contract review:** Review the “Timer integration” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M02.05-C032 · Delivery

**Original checklist item:** Integrate only timers required by the selected scheduling semantics.

- [ ] **UC-M02.05-C032-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Timer integration”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M02.05-C032-T02 · Change plan:** Break the source delivery for “Timer integration” into concrete edit targets and reviewable outputs; keep the UC-M02.05 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M02.05-C032-T03 · Core artifact:** Implement the smallest selected-profile change for “Timer integration” that realizes this source instruction: Integrate only timers required by the selected scheduling semantics.
- [ ] **UC-M02.05-C032-T04 · Concrete realization:** Trace “Timer integration” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M02.05-C032-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Timer integration” needed to preserve “Timer callbacks operate on valid current guest state”; record an enforcement gap where only a model exists.
- [ ] **UC-M02.05-C032-T06 · Dependency connection:** Connect the “Timer integration” implementation to guest work dispatch, timers and the independent host stop path; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M02.05-C032-T07 · Resource behavior:** Account for “Timer count and callback execution budget” in “Timer integration”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M02.05-C032-T08 · Delivery check:** Run the smallest real “Timer integration” path and its adverse fixture “A timer fires after its invocation has been retired”; retain actual output, state effects and final disposition.
- [ ] **UC-M02.05-C032-T09 · Patch review:** Review the “Timer integration” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M02.05-C032-T10 · Delivery handoff:** Publish the “Timer integration” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M02.05-C033 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Timer callbacks operate on valid current guest state. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M02.05-C033-T01 · Named property:** Create a stable property/check name under this parent for “Timer integration”; copy its required invariant exactly: “Timer callbacks operate on valid current guest state”.
- [ ] **UC-M02.05-C033-T02 · Observable terms:** Define each term in the “Timer integration” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M02.05-C033-T03 · Precondition set:** List the preconditions under which “Timer callbacks operate on valid current guest state” must hold for “Timer integration”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M02.05-C033-T04 · Transition coverage:** Map the “Timer integration” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M02.05-C033-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Timer integration”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M02.05-C033-T06 · Satisfying fixture:** Create a concrete “Timer integration” case that satisfies “Timer callbacks operate on valid current guest state”; record its expected observation before running the assertion or review.
- [ ] **UC-M02.05-C033-T07 · Violating fixture:** Create the source counterexample “A timer fires after its invocation has been retired” for “Timer integration”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M02.05-C033-T08 · Enforcement evidence:** Exercise the “Timer integration” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M02.05-C033-T09 · Regression linkage:** Link the “Timer integration” property to changes in guest work dispatch, timers and the independent host stop path; record which dependency or contract changes require rerunning it.
- [ ] **UC-M02.05-C033-T10 · Property disposition:** Compare the satisfying and violating “Timer integration” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M02.05-C034 · Integration

**Original checklist item:** Integrate timer integration with guest work dispatch, timers and the independent host stop path; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M02.05-C034-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Timer integration” across guest work dispatch, timers and the independent host stop path; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M02.05-C034-T02 · Field mapping:** Map every “Timer integration” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M02.05-C034-T03 · Prerequisite identities:** Record the actual prerequisites for “Timer integration” (source dependency list: UC-M02.02, UC-M02.04); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M02.05-C034-T04 · Ownership agreement:** Specify who owns “Timer integration” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M02.05-C034-T05 · Handoff implementation:** Connect “Timer integration” through the mapped seam using the real adapter or explicit specification reference; preserve “Timer callbacks operate on valid current guest state” across the handoff.
- [ ] **UC-M02.05-C034-T06 · Absent-input case:** Omit one required “Timer integration” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M02.05-C034-T07 · Stale-input case:** Supply an outdated “Timer integration” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M02.05-C034-T08 · Incompatible-input case:** Supply an incompatible “Timer integration” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M02.05-C034-T09 · Valid integration trace:** Run a valid “Timer integration” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M02.05-C034-T10 · Seam review:** Reconcile the “Timer integration” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M02.05-C035 · Valid-case test

**Original checklist item:** Run a valid-path fixture for timer integration; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M02.05-C035-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Timer integration” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M02.05-C035-T02 · Expected-result oracle:** Specify the “Timer integration” expected result independently of the implementation output; include the property “Timer callbacks operate on valid current guest state” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M02.05-C035-T03 · Fixture material:** Create the concrete “Timer integration” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M02.05-C035-T04 · Target preparation:** Prepare the “Timer integration” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M02.05-C035-T05 · Initial-state record:** Record the initial “Timer integration” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M02.05-C035-T06 · Valid-path execution:** Execute the “Timer integration” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M02.05-C035-T07 · Outcome comparison:** Compare every declared “Timer integration” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M02.05-C035-T08 · State and bounds check:** Inspect the “Timer integration” ownership/state effects and actual use of “Timer count and callback execution budget”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M02.05-C035-T09 · Repeatability check:** Repeat the same “Timer integration” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M02.05-C035-T10 · Positive evidence:** Attach the “Timer integration” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M02.05-C036 · Negative test

**Original checklist item:** Negative case: A timer fires after its invocation has been retired. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M02.05-C036-T01 · Adverse-case definition:** Create a test record for the exact “Timer integration” source counterexample: “A timer fires after its invocation has been retired”; state which precondition or invariant it challenges.
- [ ] **UC-M02.05-C036-T02 · Safe fixture boundary:** Define the contained test boundary for “Timer integration”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M02.05-C036-T03 · Valid control:** Construct a valid “Timer integration” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M02.05-C036-T04 · Minimal adverse input:** Derive the “Timer integration” adverse fixture from the control with the smallest documented change needed to reproduce “A timer fires after its invocation has been retired”; retain that change as reproducible data.
- [ ] **UC-M02.05-C036-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Timer integration”; require “Timer callbacks operate on valid current guest state” and forbid a false-success verdict.
- [ ] **UC-M02.05-C036-T06 · Adverse execution:** Exercise the “Timer integration” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M02.05-C036-T07 · Effect inspection:** Inspect “Timer integration” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M02.05-C036-T08 · Refusal versus failure:** Confirm the “Timer integration” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M02.05-C036-T09 · Reset and retention:** Restore only the disposable “Timer integration” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M02.05-C036-T10 · Negative regression:** Register the “Timer integration” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M02.05-C037 · Change / failure test

**Original checklist item:** Exercise timer integration when an uncooperative guest ignores cancellation while another guest must keep progressing; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M02.05-C037-T01 · Scenario record:** Write the “Timer integration” change/failure scenario exactly as supplied: an uncooperative guest ignores cancellation while another guest must keep progressing; identify the property that must remain true: “Timer callbacks operate on valid current guest state”.
- [ ] **UC-M02.05-C037-T02 · Baseline capture:** Create a known-valid “Timer integration” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M02.05-C037-T03 · Injection map:** Locate the “Timer integration” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M02.05-C037-T04 · Disposition oracle:** Define the legal intermediate and final “Timer integration” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M02.05-C037-T05 · Controlled trigger:** Introduce the controlled “Timer integration” scenario in the disposable fixture: an uncooperative guest ignores cancellation while another guest must keep progressing; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M02.05-C037-T06 · Intermediate inspection:** Inspect the “Timer integration” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M02.05-C037-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Timer integration”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M02.05-C037-T08 · Stale-evidence cleanup:** Invalidate superseded “Timer integration” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M02.05-C037-T09 · Repeat and compare:** Repeat the selected “Timer integration” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M02.05-C037-T10 · Failure evidence:** Publish the “Timer integration” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M02.05-C038 · Bounds

**Original checklist item:** Choose, document and test limits for timer count and callback execution budget; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M02.05-C038-T01 · Quantity inventory:** Create a measurement inventory for “Timer integration”: “Timer count and callback execution budget”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M02.05-C038-T02 · Measurement method:** Choose how to observe each “Timer integration” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M02.05-C038-T03 · Budget decision:** Select justified resource and input limits for “Timer integration”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M02.05-C038-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Timer integration” cases for “Timer count and callback execution budget”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M02.05-C038-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Timer integration” limit; preserve “Timer callbacks operate on valid current guest state”.
- [ ] **UC-M02.05-C038-T06 · Normal measurement:** Run or review the normal “Timer integration” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M02.05-C038-T07 · At-limit measurement:** Exercise the “Timer integration” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M02.05-C038-T08 · Over-limit measurement:** Exercise the “Timer integration” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M02.05-C038-T09 · Uncovered-scope report:** List the “Timer integration” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M02.05-C038-T10 · Limit evidence:** Publish the selected “Timer integration” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M02.05-C039 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for timer integration with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M02.05-C039-T01 · Event inventory:** List the “Timer integration” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M02.05-C039-T02 · Diagnostic schema:** Define nonsecret fields for “Timer integration” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M02.05-C039-T03 · Failure mapping:** Map each documented “Timer integration” refusal or error to a diagnostic outcome; include “A timer fires after its invocation has been retired” and prohibit conversion into a success message.
- [ ] **UC-M02.05-C039-T04 · Emission path:** Add the “Timer integration” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M02.05-C039-T05 · Redaction check:** Test “Timer integration” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M02.05-C039-T06 · Output budget:** Set and exercise bounded “Timer integration” message size, rate and retention compatible with “Timer count and callback execution budget”; define truncation behavior that preserves the final reason.
- [ ] **UC-M02.05-C039-T07 · Success/refusal fixtures:** Capture “Timer integration” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M02.05-C039-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Timer integration” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M02.05-C039-T09 · Operator review:** Read the “Timer integration” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M02.05-C039-T10 · Diagnostic evidence:** Publish redacted “Timer integration” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M02.05-C040 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for timer integration; label unexecuted checks as untested.

- [ ] **UC-M02.05-C040-T01 · Evidence inventory:** List the “Timer integration” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M02.05-C040-T02 · Artifact references:** Record the exact “Timer integration” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M02.05-C040-T03 · Fixture references:** Attach the “Timer integration” fixture IDs, input identities and oracle definition; preserve the source counterexample “A timer fires after its invocation has been retired” as a distinct evidence case.
- [ ] **UC-M02.05-C040-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Timer integration”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M02.05-C040-T05 · Environment record:** Record the actual “Timer integration” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M02.05-C040-T06 · Expected versus observed:** Pair every “Timer integration” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M02.05-C040-T07 · Failure and limit records:** Attach “Timer integration” change/failure and bounds evidence where required; include uncovered “Timer count and callback execution budget” and unresolved violations of “Timer callbacks operate on valid current guest state”.
- [ ] **UC-M02.05-C040-T08 · Evidence hygiene:** Check the “Timer integration” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M02.05-C040-T09 · Reproduction review:** Have the “Timer integration” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M02.05-C040-T10 · Acceptance linkage:** Link the “Timer integration” evidence to its parent and UC-M02.05 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 05. Interrupt handling

**Source delivery:** Define interrupt masking, dispatch and acknowledgment where the platform requires them.

**Source invariant:** Interrupt handlers respect the guest's memory and execution invariants.

**Source negative case:** An interrupt arrives during partially initialized guest state.

**Source bounded quantities:** Interrupt rate and handler duration.

### UC-M02.05-C041 · Contract

**Original checklist item:** Specify interrupt handling inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M02.05-C041-T01 · Scope statement:** Draft the operation boundary for “Interrupt handling” within Guest execution loop and scheduling; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M02.05-C041-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Interrupt handling”; record each producer, representation and missing-value meaning.
- [ ] **UC-M02.05-C041-T03 · Output inventory:** List the outputs of “Interrupt handling” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M02.05-C041-T04 · Field dictionary:** Create a field-and-term dictionary for “Interrupt handling”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M02.05-C041-T05 · Prerequisite contract:** Map “Interrupt handling” to the source component prerequisites (UC-M02.02, UC-M02.04); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M02.05-C041-T06 · Authority map:** Identify who may produce, change and consume “Interrupt handling”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M02.05-C041-T07 · Invariant clause:** Add a normative clause for “Interrupt handling” that preserves “Interrupt handlers respect the guest's memory and execution invariants”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M02.05-C041-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Interrupt handling”; include the source counterexample “An interrupt arrives during partially initialized guest state” and the intended safe disposition.
- [ ] **UC-M02.05-C041-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Interrupt rate and handler duration” in the “Interrupt handling” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M02.05-C041-T10 · Contract review:** Review the “Interrupt handling” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M02.05-C042 · Delivery

**Original checklist item:** Define interrupt masking, dispatch and acknowledgment where the platform requires them.

- [ ] **UC-M02.05-C042-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Interrupt handling”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M02.05-C042-T02 · Change plan:** Break the source delivery for “Interrupt handling” into concrete edit targets and reviewable outputs; keep the UC-M02.05 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M02.05-C042-T03 · Core artifact:** Create the “Interrupt handling” model, schema or inventory that realizes this source instruction: Define interrupt masking, dispatch and acknowledgment where the platform requires them.
- [ ] **UC-M02.05-C042-T04 · Concrete realization:** Populate “Interrupt handling” with one concrete worked case; map every required entity or field to its source and flag any unmapped entry.
- [ ] **UC-M02.05-C042-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Interrupt handling” needed to preserve “Interrupt handlers respect the guest's memory and execution invariants”; record an enforcement gap where only a model exists.
- [ ] **UC-M02.05-C042-T06 · Dependency connection:** Connect the “Interrupt handling” implementation to guest work dispatch, timers and the independent host stop path; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M02.05-C042-T07 · Resource behavior:** Account for “Interrupt rate and handler duration” in “Interrupt handling”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M02.05-C042-T08 · Delivery check:** Run the smallest real “Interrupt handling” path and its adverse fixture “An interrupt arrives during partially initialized guest state”; retain actual output, state effects and final disposition.
- [ ] **UC-M02.05-C042-T09 · Patch review:** Review the “Interrupt handling” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M02.05-C042-T10 · Delivery handoff:** Publish the “Interrupt handling” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M02.05-C043 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Interrupt handlers respect the guest's memory and execution invariants. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M02.05-C043-T01 · Named property:** Create a stable property/check name under this parent for “Interrupt handling”; copy its required invariant exactly: “Interrupt handlers respect the guest's memory and execution invariants”.
- [ ] **UC-M02.05-C043-T02 · Observable terms:** Define each term in the “Interrupt handling” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M02.05-C043-T03 · Precondition set:** List the preconditions under which “Interrupt handlers respect the guest's memory and execution invariants” must hold for “Interrupt handling”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M02.05-C043-T04 · Transition coverage:** Map the “Interrupt handling” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M02.05-C043-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Interrupt handling”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M02.05-C043-T06 · Satisfying fixture:** Create a concrete “Interrupt handling” case that satisfies “Interrupt handlers respect the guest's memory and execution invariants”; record its expected observation before running the assertion or review.
- [ ] **UC-M02.05-C043-T07 · Violating fixture:** Create the source counterexample “An interrupt arrives during partially initialized guest state” for “Interrupt handling”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M02.05-C043-T08 · Enforcement evidence:** Exercise the “Interrupt handling” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M02.05-C043-T09 · Regression linkage:** Link the “Interrupt handling” property to changes in guest work dispatch, timers and the independent host stop path; record which dependency or contract changes require rerunning it.
- [ ] **UC-M02.05-C043-T10 · Property disposition:** Compare the satisfying and violating “Interrupt handling” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M02.05-C044 · Integration

**Original checklist item:** Integrate interrupt handling with guest work dispatch, timers and the independent host stop path; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M02.05-C044-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Interrupt handling” across guest work dispatch, timers and the independent host stop path; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M02.05-C044-T02 · Field mapping:** Map every “Interrupt handling” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M02.05-C044-T03 · Prerequisite identities:** Record the actual prerequisites for “Interrupt handling” (source dependency list: UC-M02.02, UC-M02.04); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M02.05-C044-T04 · Ownership agreement:** Specify who owns “Interrupt handling” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M02.05-C044-T05 · Handoff implementation:** Connect “Interrupt handling” through the mapped seam using the real adapter or explicit specification reference; preserve “Interrupt handlers respect the guest's memory and execution invariants” across the handoff.
- [ ] **UC-M02.05-C044-T06 · Absent-input case:** Omit one required “Interrupt handling” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M02.05-C044-T07 · Stale-input case:** Supply an outdated “Interrupt handling” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M02.05-C044-T08 · Incompatible-input case:** Supply an incompatible “Interrupt handling” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M02.05-C044-T09 · Valid integration trace:** Run a valid “Interrupt handling” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M02.05-C044-T10 · Seam review:** Reconcile the “Interrupt handling” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M02.05-C045 · Valid-case test

**Original checklist item:** Run a valid-path fixture for interrupt handling; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M02.05-C045-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Interrupt handling” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M02.05-C045-T02 · Expected-result oracle:** Specify the “Interrupt handling” expected result independently of the implementation output; include the property “Interrupt handlers respect the guest's memory and execution invariants” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M02.05-C045-T03 · Fixture material:** Create the concrete “Interrupt handling” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M02.05-C045-T04 · Target preparation:** Prepare the “Interrupt handling” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M02.05-C045-T05 · Initial-state record:** Record the initial “Interrupt handling” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M02.05-C045-T06 · Valid-path execution:** Execute the “Interrupt handling” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M02.05-C045-T07 · Outcome comparison:** Compare every declared “Interrupt handling” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M02.05-C045-T08 · State and bounds check:** Inspect the “Interrupt handling” ownership/state effects and actual use of “Interrupt rate and handler duration”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M02.05-C045-T09 · Repeatability check:** Repeat the same “Interrupt handling” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M02.05-C045-T10 · Positive evidence:** Attach the “Interrupt handling” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M02.05-C046 · Negative test

**Original checklist item:** Negative case: An interrupt arrives during partially initialized guest state. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M02.05-C046-T01 · Adverse-case definition:** Create a test record for the exact “Interrupt handling” source counterexample: “An interrupt arrives during partially initialized guest state”; state which precondition or invariant it challenges.
- [ ] **UC-M02.05-C046-T02 · Safe fixture boundary:** Define the contained test boundary for “Interrupt handling”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M02.05-C046-T03 · Valid control:** Construct a valid “Interrupt handling” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M02.05-C046-T04 · Minimal adverse input:** Derive the “Interrupt handling” adverse fixture from the control with the smallest documented change needed to reproduce “An interrupt arrives during partially initialized guest state”; retain that change as reproducible data.
- [ ] **UC-M02.05-C046-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Interrupt handling”; require “Interrupt handlers respect the guest's memory and execution invariants” and forbid a false-success verdict.
- [ ] **UC-M02.05-C046-T06 · Adverse execution:** Exercise the “Interrupt handling” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M02.05-C046-T07 · Effect inspection:** Inspect “Interrupt handling” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M02.05-C046-T08 · Refusal versus failure:** Confirm the “Interrupt handling” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M02.05-C046-T09 · Reset and retention:** Restore only the disposable “Interrupt handling” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M02.05-C046-T10 · Negative regression:** Register the “Interrupt handling” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M02.05-C047 · Change / failure test

**Original checklist item:** Exercise interrupt handling when an uncooperative guest ignores cancellation while another guest must keep progressing; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M02.05-C047-T01 · Scenario record:** Write the “Interrupt handling” change/failure scenario exactly as supplied: an uncooperative guest ignores cancellation while another guest must keep progressing; identify the property that must remain true: “Interrupt handlers respect the guest's memory and execution invariants”.
- [ ] **UC-M02.05-C047-T02 · Baseline capture:** Create a known-valid “Interrupt handling” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M02.05-C047-T03 · Injection map:** Locate the “Interrupt handling” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M02.05-C047-T04 · Disposition oracle:** Define the legal intermediate and final “Interrupt handling” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M02.05-C047-T05 · Controlled trigger:** Introduce the controlled “Interrupt handling” scenario in the disposable fixture: an uncooperative guest ignores cancellation while another guest must keep progressing; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M02.05-C047-T06 · Intermediate inspection:** Inspect the “Interrupt handling” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M02.05-C047-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Interrupt handling”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M02.05-C047-T08 · Stale-evidence cleanup:** Invalidate superseded “Interrupt handling” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M02.05-C047-T09 · Repeat and compare:** Repeat the selected “Interrupt handling” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M02.05-C047-T10 · Failure evidence:** Publish the “Interrupt handling” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M02.05-C048 · Bounds

**Original checklist item:** Choose, document and test limits for interrupt rate and handler duration; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M02.05-C048-T01 · Quantity inventory:** Create a measurement inventory for “Interrupt handling”: “Interrupt rate and handler duration”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M02.05-C048-T02 · Measurement method:** Choose how to observe each “Interrupt handling” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M02.05-C048-T03 · Budget decision:** Select justified resource and input limits for “Interrupt handling”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M02.05-C048-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Interrupt handling” cases for “Interrupt rate and handler duration”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M02.05-C048-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Interrupt handling” limit; preserve “Interrupt handlers respect the guest's memory and execution invariants”.
- [ ] **UC-M02.05-C048-T06 · Normal measurement:** Run or review the normal “Interrupt handling” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M02.05-C048-T07 · At-limit measurement:** Exercise the “Interrupt handling” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M02.05-C048-T08 · Over-limit measurement:** Exercise the “Interrupt handling” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M02.05-C048-T09 · Uncovered-scope report:** List the “Interrupt handling” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M02.05-C048-T10 · Limit evidence:** Publish the selected “Interrupt handling” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M02.05-C049 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for interrupt handling with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M02.05-C049-T01 · Event inventory:** List the “Interrupt handling” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M02.05-C049-T02 · Diagnostic schema:** Define nonsecret fields for “Interrupt handling” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M02.05-C049-T03 · Failure mapping:** Map each documented “Interrupt handling” refusal or error to a diagnostic outcome; include “An interrupt arrives during partially initialized guest state” and prohibit conversion into a success message.
- [ ] **UC-M02.05-C049-T04 · Emission path:** Add the “Interrupt handling” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M02.05-C049-T05 · Redaction check:** Test “Interrupt handling” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M02.05-C049-T06 · Output budget:** Set and exercise bounded “Interrupt handling” message size, rate and retention compatible with “Interrupt rate and handler duration”; define truncation behavior that preserves the final reason.
- [ ] **UC-M02.05-C049-T07 · Success/refusal fixtures:** Capture “Interrupt handling” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M02.05-C049-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Interrupt handling” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M02.05-C049-T09 · Operator review:** Read the “Interrupt handling” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M02.05-C049-T10 · Diagnostic evidence:** Publish redacted “Interrupt handling” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M02.05-C050 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for interrupt handling; label unexecuted checks as untested.

- [ ] **UC-M02.05-C050-T01 · Evidence inventory:** List the “Interrupt handling” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M02.05-C050-T02 · Artifact references:** Record the exact “Interrupt handling” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M02.05-C050-T03 · Fixture references:** Attach the “Interrupt handling” fixture IDs, input identities and oracle definition; preserve the source counterexample “An interrupt arrives during partially initialized guest state” as a distinct evidence case.
- [ ] **UC-M02.05-C050-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Interrupt handling”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M02.05-C050-T05 · Environment record:** Record the actual “Interrupt handling” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M02.05-C050-T06 · Expected versus observed:** Pair every “Interrupt handling” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M02.05-C050-T07 · Failure and limit records:** Attach “Interrupt handling” change/failure and bounds evidence where required; include uncovered “Interrupt rate and handler duration” and unresolved violations of “Interrupt handlers respect the guest's memory and execution invariants”.
- [ ] **UC-M02.05-C050-T08 · Evidence hygiene:** Check the “Interrupt handling” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M02.05-C050-T09 · Reproduction review:** Have the “Interrupt handling” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M02.05-C050-T10 · Acceptance linkage:** Link the “Interrupt handling” evidence to its parent and UC-M02.05 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 06. Cancellation points

**Source delivery:** Implement and document guest cancellation points appropriate to the execution model.

**Source invariant:** Cancellation behavior does not promise responsiveness the model lacks.

**Source negative case:** A workload never reaches a cooperative cancellation point.

**Source bounded quantities:** Cancellation checks and response-time bound.

### UC-M02.05-C051 · Contract

**Original checklist item:** Specify cancellation points inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M02.05-C051-T01 · Scope statement:** Draft the operation boundary for “Cancellation points” within Guest execution loop and scheduling; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M02.05-C051-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Cancellation points”; record each producer, representation and missing-value meaning.
- [ ] **UC-M02.05-C051-T03 · Output inventory:** List the outputs of “Cancellation points” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M02.05-C051-T04 · Field dictionary:** Create a field-and-term dictionary for “Cancellation points”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M02.05-C051-T05 · Prerequisite contract:** Map “Cancellation points” to the source component prerequisites (UC-M02.02, UC-M02.04); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M02.05-C051-T06 · Authority map:** Identify who may produce, change and consume “Cancellation points”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M02.05-C051-T07 · Invariant clause:** Add a normative clause for “Cancellation points” that preserves “Cancellation behavior does not promise responsiveness the model lacks”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M02.05-C051-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Cancellation points”; include the source counterexample “A workload never reaches a cooperative cancellation point” and the intended safe disposition.
- [ ] **UC-M02.05-C051-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Cancellation checks and response-time bound” in the “Cancellation points” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M02.05-C051-T10 · Contract review:** Review the “Cancellation points” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M02.05-C052 · Delivery

**Original checklist item:** Implement and document guest cancellation points appropriate to the execution model.

- [ ] **UC-M02.05-C052-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Cancellation points”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M02.05-C052-T02 · Change plan:** Break the source delivery for “Cancellation points” into concrete edit targets and reviewable outputs; keep the UC-M02.05 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M02.05-C052-T03 · Core artifact:** Implement the smallest selected-profile change for “Cancellation points” that realizes this source instruction: Implement and document guest cancellation points appropriate to the execution model.
- [ ] **UC-M02.05-C052-T04 · Concrete realization:** Trace “Cancellation points” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M02.05-C052-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Cancellation points” needed to preserve “Cancellation behavior does not promise responsiveness the model lacks”; record an enforcement gap where only a model exists.
- [ ] **UC-M02.05-C052-T06 · Dependency connection:** Connect the “Cancellation points” implementation to guest work dispatch, timers and the independent host stop path; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M02.05-C052-T07 · Resource behavior:** Account for “Cancellation checks and response-time bound” in “Cancellation points”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M02.05-C052-T08 · Delivery check:** Run the smallest real “Cancellation points” path and its adverse fixture “A workload never reaches a cooperative cancellation point”; retain actual output, state effects and final disposition.
- [ ] **UC-M02.05-C052-T09 · Patch review:** Review the “Cancellation points” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M02.05-C052-T10 · Delivery handoff:** Publish the “Cancellation points” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M02.05-C053 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Cancellation behavior does not promise responsiveness the model lacks. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M02.05-C053-T01 · Named property:** Create a stable property/check name under this parent for “Cancellation points”; copy its required invariant exactly: “Cancellation behavior does not promise responsiveness the model lacks”.
- [ ] **UC-M02.05-C053-T02 · Observable terms:** Define each term in the “Cancellation points” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M02.05-C053-T03 · Precondition set:** List the preconditions under which “Cancellation behavior does not promise responsiveness the model lacks” must hold for “Cancellation points”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M02.05-C053-T04 · Transition coverage:** Map the “Cancellation points” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M02.05-C053-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Cancellation points”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M02.05-C053-T06 · Satisfying fixture:** Create a concrete “Cancellation points” case that satisfies “Cancellation behavior does not promise responsiveness the model lacks”; record its expected observation before running the assertion or review.
- [ ] **UC-M02.05-C053-T07 · Violating fixture:** Create the source counterexample “A workload never reaches a cooperative cancellation point” for “Cancellation points”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M02.05-C053-T08 · Enforcement evidence:** Exercise the “Cancellation points” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M02.05-C053-T09 · Regression linkage:** Link the “Cancellation points” property to changes in guest work dispatch, timers and the independent host stop path; record which dependency or contract changes require rerunning it.
- [ ] **UC-M02.05-C053-T10 · Property disposition:** Compare the satisfying and violating “Cancellation points” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M02.05-C054 · Integration

**Original checklist item:** Integrate cancellation points with guest work dispatch, timers and the independent host stop path; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M02.05-C054-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Cancellation points” across guest work dispatch, timers and the independent host stop path; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M02.05-C054-T02 · Field mapping:** Map every “Cancellation points” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M02.05-C054-T03 · Prerequisite identities:** Record the actual prerequisites for “Cancellation points” (source dependency list: UC-M02.02, UC-M02.04); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M02.05-C054-T04 · Ownership agreement:** Specify who owns “Cancellation points” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M02.05-C054-T05 · Handoff implementation:** Connect “Cancellation points” through the mapped seam using the real adapter or explicit specification reference; preserve “Cancellation behavior does not promise responsiveness the model lacks” across the handoff.
- [ ] **UC-M02.05-C054-T06 · Absent-input case:** Omit one required “Cancellation points” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M02.05-C054-T07 · Stale-input case:** Supply an outdated “Cancellation points” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M02.05-C054-T08 · Incompatible-input case:** Supply an incompatible “Cancellation points” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M02.05-C054-T09 · Valid integration trace:** Run a valid “Cancellation points” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M02.05-C054-T10 · Seam review:** Reconcile the “Cancellation points” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M02.05-C055 · Valid-case test

**Original checklist item:** Run a valid-path fixture for cancellation points; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M02.05-C055-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Cancellation points” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M02.05-C055-T02 · Expected-result oracle:** Specify the “Cancellation points” expected result independently of the implementation output; include the property “Cancellation behavior does not promise responsiveness the model lacks” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M02.05-C055-T03 · Fixture material:** Create the concrete “Cancellation points” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M02.05-C055-T04 · Target preparation:** Prepare the “Cancellation points” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M02.05-C055-T05 · Initial-state record:** Record the initial “Cancellation points” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M02.05-C055-T06 · Valid-path execution:** Execute the “Cancellation points” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M02.05-C055-T07 · Outcome comparison:** Compare every declared “Cancellation points” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M02.05-C055-T08 · State and bounds check:** Inspect the “Cancellation points” ownership/state effects and actual use of “Cancellation checks and response-time bound”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M02.05-C055-T09 · Repeatability check:** Repeat the same “Cancellation points” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M02.05-C055-T10 · Positive evidence:** Attach the “Cancellation points” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M02.05-C056 · Negative test

**Original checklist item:** Negative case: A workload never reaches a cooperative cancellation point. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M02.05-C056-T01 · Adverse-case definition:** Create a test record for the exact “Cancellation points” source counterexample: “A workload never reaches a cooperative cancellation point”; state which precondition or invariant it challenges.
- [ ] **UC-M02.05-C056-T02 · Safe fixture boundary:** Define the contained test boundary for “Cancellation points”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M02.05-C056-T03 · Valid control:** Construct a valid “Cancellation points” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M02.05-C056-T04 · Minimal adverse input:** Derive the “Cancellation points” adverse fixture from the control with the smallest documented change needed to reproduce “A workload never reaches a cooperative cancellation point”; retain that change as reproducible data.
- [ ] **UC-M02.05-C056-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Cancellation points”; require “Cancellation behavior does not promise responsiveness the model lacks” and forbid a false-success verdict.
- [ ] **UC-M02.05-C056-T06 · Adverse execution:** Exercise the “Cancellation points” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M02.05-C056-T07 · Effect inspection:** Inspect “Cancellation points” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M02.05-C056-T08 · Refusal versus failure:** Confirm the “Cancellation points” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M02.05-C056-T09 · Reset and retention:** Restore only the disposable “Cancellation points” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M02.05-C056-T10 · Negative regression:** Register the “Cancellation points” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M02.05-C057 · Change / failure test

**Original checklist item:** Exercise cancellation points when an uncooperative guest ignores cancellation while another guest must keep progressing; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M02.05-C057-T01 · Scenario record:** Write the “Cancellation points” change/failure scenario exactly as supplied: an uncooperative guest ignores cancellation while another guest must keep progressing; identify the property that must remain true: “Cancellation behavior does not promise responsiveness the model lacks”.
- [ ] **UC-M02.05-C057-T02 · Baseline capture:** Create a known-valid “Cancellation points” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M02.05-C057-T03 · Injection map:** Locate the “Cancellation points” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M02.05-C057-T04 · Disposition oracle:** Define the legal intermediate and final “Cancellation points” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M02.05-C057-T05 · Controlled trigger:** Introduce the controlled “Cancellation points” scenario in the disposable fixture: an uncooperative guest ignores cancellation while another guest must keep progressing; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M02.05-C057-T06 · Intermediate inspection:** Inspect the “Cancellation points” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M02.05-C057-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Cancellation points”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M02.05-C057-T08 · Stale-evidence cleanup:** Invalidate superseded “Cancellation points” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M02.05-C057-T09 · Repeat and compare:** Repeat the selected “Cancellation points” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M02.05-C057-T10 · Failure evidence:** Publish the “Cancellation points” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M02.05-C058 · Bounds

**Original checklist item:** Choose, document and test limits for cancellation checks and response-time bound; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M02.05-C058-T01 · Quantity inventory:** Create a measurement inventory for “Cancellation points”: “Cancellation checks and response-time bound”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M02.05-C058-T02 · Measurement method:** Choose how to observe each “Cancellation points” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M02.05-C058-T03 · Budget decision:** Select justified resource and input limits for “Cancellation points”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M02.05-C058-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Cancellation points” cases for “Cancellation checks and response-time bound”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M02.05-C058-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Cancellation points” limit; preserve “Cancellation behavior does not promise responsiveness the model lacks”.
- [ ] **UC-M02.05-C058-T06 · Normal measurement:** Run or review the normal “Cancellation points” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M02.05-C058-T07 · At-limit measurement:** Exercise the “Cancellation points” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M02.05-C058-T08 · Over-limit measurement:** Exercise the “Cancellation points” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M02.05-C058-T09 · Uncovered-scope report:** List the “Cancellation points” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M02.05-C058-T10 · Limit evidence:** Publish the selected “Cancellation points” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M02.05-C059 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for cancellation points with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M02.05-C059-T01 · Event inventory:** List the “Cancellation points” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M02.05-C059-T02 · Diagnostic schema:** Define nonsecret fields for “Cancellation points” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M02.05-C059-T03 · Failure mapping:** Map each documented “Cancellation points” refusal or error to a diagnostic outcome; include “A workload never reaches a cooperative cancellation point” and prohibit conversion into a success message.
- [ ] **UC-M02.05-C059-T04 · Emission path:** Add the “Cancellation points” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M02.05-C059-T05 · Redaction check:** Test “Cancellation points” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M02.05-C059-T06 · Output budget:** Set and exercise bounded “Cancellation points” message size, rate and retention compatible with “Cancellation checks and response-time bound”; define truncation behavior that preserves the final reason.
- [ ] **UC-M02.05-C059-T07 · Success/refusal fixtures:** Capture “Cancellation points” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M02.05-C059-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Cancellation points” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M02.05-C059-T09 · Operator review:** Read the “Cancellation points” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M02.05-C059-T10 · Diagnostic evidence:** Publish redacted “Cancellation points” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M02.05-C060 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for cancellation points; label unexecuted checks as untested.

- [ ] **UC-M02.05-C060-T01 · Evidence inventory:** List the “Cancellation points” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M02.05-C060-T02 · Artifact references:** Record the exact “Cancellation points” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M02.05-C060-T03 · Fixture references:** Attach the “Cancellation points” fixture IDs, input identities and oracle definition; preserve the source counterexample “A workload never reaches a cooperative cancellation point” as a distinct evidence case.
- [ ] **UC-M02.05-C060-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Cancellation points”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M02.05-C060-T05 · Environment record:** Record the actual “Cancellation points” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M02.05-C060-T06 · Expected versus observed:** Pair every “Cancellation points” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M02.05-C060-T07 · Failure and limit records:** Attach “Cancellation points” change/failure and bounds evidence where required; include uncovered “Cancellation checks and response-time bound” and unresolved violations of “Cancellation behavior does not promise responsiveness the model lacks”.
- [ ] **UC-M02.05-C060-T08 · Evidence hygiene:** Check the “Cancellation points” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M02.05-C060-T09 · Reproduction review:** Have the “Cancellation points” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M02.05-C060-T10 · Acceptance linkage:** Link the “Cancellation points” evidence to its parent and UC-M02.05 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 07. Host stop boundary

**Source delivery:** Ensure the host can terminate a non-terminating guest independently of its loop.

**Source invariant:** An uncooperative guest cannot prevent host-enforced stop.

**Source negative case:** An infinite guest loop ignores all cooperative stop requests.

**Source bounded quantities:** Host stop deadline and forced-termination attempts.

### UC-M02.05-C061 · Contract

**Original checklist item:** Specify host stop boundary inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M02.05-C061-T01 · Scope statement:** Draft the operation boundary for “Host stop boundary” within Guest execution loop and scheduling; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M02.05-C061-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Host stop boundary”; record each producer, representation and missing-value meaning.
- [ ] **UC-M02.05-C061-T03 · Output inventory:** List the outputs of “Host stop boundary” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M02.05-C061-T04 · Field dictionary:** Create a field-and-term dictionary for “Host stop boundary”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M02.05-C061-T05 · Prerequisite contract:** Map “Host stop boundary” to the source component prerequisites (UC-M02.02, UC-M02.04); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M02.05-C061-T06 · Authority map:** Identify who may produce, change and consume “Host stop boundary”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M02.05-C061-T07 · Invariant clause:** Add a normative clause for “Host stop boundary” that preserves “An uncooperative guest cannot prevent host-enforced stop”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M02.05-C061-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Host stop boundary”; include the source counterexample “An infinite guest loop ignores all cooperative stop requests” and the intended safe disposition.
- [ ] **UC-M02.05-C061-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Host stop deadline and forced-termination attempts” in the “Host stop boundary” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M02.05-C061-T10 · Contract review:** Review the “Host stop boundary” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M02.05-C062 · Delivery

**Original checklist item:** Ensure the host can terminate a non-terminating guest independently of its loop.

- [ ] **UC-M02.05-C062-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Host stop boundary”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M02.05-C062-T02 · Change plan:** Break the source delivery for “Host stop boundary” into concrete edit targets and reviewable outputs; keep the UC-M02.05 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M02.05-C062-T03 · Core artifact:** Implement the smallest selected-profile change for “Host stop boundary” that realizes this source instruction: Ensure the host can terminate a non-terminating guest independently of its loop.
- [ ] **UC-M02.05-C062-T04 · Concrete realization:** Trace “Host stop boundary” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M02.05-C062-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Host stop boundary” needed to preserve “An uncooperative guest cannot prevent host-enforced stop”; record an enforcement gap where only a model exists.
- [ ] **UC-M02.05-C062-T06 · Dependency connection:** Connect the “Host stop boundary” implementation to guest work dispatch, timers and the independent host stop path; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M02.05-C062-T07 · Resource behavior:** Account for “Host stop deadline and forced-termination attempts” in “Host stop boundary”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M02.05-C062-T08 · Delivery check:** Run the smallest real “Host stop boundary” path and its adverse fixture “An infinite guest loop ignores all cooperative stop requests”; retain actual output, state effects and final disposition.
- [ ] **UC-M02.05-C062-T09 · Patch review:** Review the “Host stop boundary” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M02.05-C062-T10 · Delivery handoff:** Publish the “Host stop boundary” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M02.05-C063 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: An uncooperative guest cannot prevent host-enforced stop. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M02.05-C063-T01 · Named property:** Create a stable property/check name under this parent for “Host stop boundary”; copy its required invariant exactly: “An uncooperative guest cannot prevent host-enforced stop”.
- [ ] **UC-M02.05-C063-T02 · Observable terms:** Define each term in the “Host stop boundary” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M02.05-C063-T03 · Precondition set:** List the preconditions under which “An uncooperative guest cannot prevent host-enforced stop” must hold for “Host stop boundary”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M02.05-C063-T04 · Transition coverage:** Map the “Host stop boundary” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M02.05-C063-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Host stop boundary”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M02.05-C063-T06 · Satisfying fixture:** Create a concrete “Host stop boundary” case that satisfies “An uncooperative guest cannot prevent host-enforced stop”; record its expected observation before running the assertion or review.
- [ ] **UC-M02.05-C063-T07 · Violating fixture:** Create the source counterexample “An infinite guest loop ignores all cooperative stop requests” for “Host stop boundary”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M02.05-C063-T08 · Enforcement evidence:** Exercise the “Host stop boundary” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M02.05-C063-T09 · Regression linkage:** Link the “Host stop boundary” property to changes in guest work dispatch, timers and the independent host stop path; record which dependency or contract changes require rerunning it.
- [ ] **UC-M02.05-C063-T10 · Property disposition:** Compare the satisfying and violating “Host stop boundary” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M02.05-C064 · Integration

**Original checklist item:** Integrate host stop boundary with guest work dispatch, timers and the independent host stop path; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M02.05-C064-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Host stop boundary” across guest work dispatch, timers and the independent host stop path; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M02.05-C064-T02 · Field mapping:** Map every “Host stop boundary” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M02.05-C064-T03 · Prerequisite identities:** Record the actual prerequisites for “Host stop boundary” (source dependency list: UC-M02.02, UC-M02.04); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M02.05-C064-T04 · Ownership agreement:** Specify who owns “Host stop boundary” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M02.05-C064-T05 · Handoff implementation:** Connect “Host stop boundary” through the mapped seam using the real adapter or explicit specification reference; preserve “An uncooperative guest cannot prevent host-enforced stop” across the handoff.
- [ ] **UC-M02.05-C064-T06 · Absent-input case:** Omit one required “Host stop boundary” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M02.05-C064-T07 · Stale-input case:** Supply an outdated “Host stop boundary” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M02.05-C064-T08 · Incompatible-input case:** Supply an incompatible “Host stop boundary” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M02.05-C064-T09 · Valid integration trace:** Run a valid “Host stop boundary” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M02.05-C064-T10 · Seam review:** Reconcile the “Host stop boundary” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M02.05-C065 · Valid-case test

**Original checklist item:** Run a valid-path fixture for host stop boundary; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M02.05-C065-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Host stop boundary” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M02.05-C065-T02 · Expected-result oracle:** Specify the “Host stop boundary” expected result independently of the implementation output; include the property “An uncooperative guest cannot prevent host-enforced stop” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M02.05-C065-T03 · Fixture material:** Create the concrete “Host stop boundary” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M02.05-C065-T04 · Target preparation:** Prepare the “Host stop boundary” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M02.05-C065-T05 · Initial-state record:** Record the initial “Host stop boundary” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M02.05-C065-T06 · Valid-path execution:** Execute the “Host stop boundary” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M02.05-C065-T07 · Outcome comparison:** Compare every declared “Host stop boundary” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M02.05-C065-T08 · State and bounds check:** Inspect the “Host stop boundary” ownership/state effects and actual use of “Host stop deadline and forced-termination attempts”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M02.05-C065-T09 · Repeatability check:** Repeat the same “Host stop boundary” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M02.05-C065-T10 · Positive evidence:** Attach the “Host stop boundary” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M02.05-C066 · Negative test

**Original checklist item:** Negative case: An infinite guest loop ignores all cooperative stop requests. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M02.05-C066-T01 · Adverse-case definition:** Create a test record for the exact “Host stop boundary” source counterexample: “An infinite guest loop ignores all cooperative stop requests”; state which precondition or invariant it challenges.
- [ ] **UC-M02.05-C066-T02 · Safe fixture boundary:** Define the contained test boundary for “Host stop boundary”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M02.05-C066-T03 · Valid control:** Construct a valid “Host stop boundary” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M02.05-C066-T04 · Minimal adverse input:** Derive the “Host stop boundary” adverse fixture from the control with the smallest documented change needed to reproduce “An infinite guest loop ignores all cooperative stop requests”; retain that change as reproducible data.
- [ ] **UC-M02.05-C066-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Host stop boundary”; require “An uncooperative guest cannot prevent host-enforced stop” and forbid a false-success verdict.
- [ ] **UC-M02.05-C066-T06 · Adverse execution:** Exercise the “Host stop boundary” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M02.05-C066-T07 · Effect inspection:** Inspect “Host stop boundary” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M02.05-C066-T08 · Refusal versus failure:** Confirm the “Host stop boundary” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M02.05-C066-T09 · Reset and retention:** Restore only the disposable “Host stop boundary” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M02.05-C066-T10 · Negative regression:** Register the “Host stop boundary” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M02.05-C067 · Change / failure test

**Original checklist item:** Exercise host stop boundary when an uncooperative guest ignores cancellation while another guest must keep progressing; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M02.05-C067-T01 · Scenario record:** Write the “Host stop boundary” change/failure scenario exactly as supplied: an uncooperative guest ignores cancellation while another guest must keep progressing; identify the property that must remain true: “An uncooperative guest cannot prevent host-enforced stop”.
- [ ] **UC-M02.05-C067-T02 · Baseline capture:** Create a known-valid “Host stop boundary” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M02.05-C067-T03 · Injection map:** Locate the “Host stop boundary” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M02.05-C067-T04 · Disposition oracle:** Define the legal intermediate and final “Host stop boundary” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M02.05-C067-T05 · Controlled trigger:** Introduce the controlled “Host stop boundary” scenario in the disposable fixture: an uncooperative guest ignores cancellation while another guest must keep progressing; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M02.05-C067-T06 · Intermediate inspection:** Inspect the “Host stop boundary” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M02.05-C067-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Host stop boundary”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M02.05-C067-T08 · Stale-evidence cleanup:** Invalidate superseded “Host stop boundary” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M02.05-C067-T09 · Repeat and compare:** Repeat the selected “Host stop boundary” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M02.05-C067-T10 · Failure evidence:** Publish the “Host stop boundary” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M02.05-C068 · Bounds

**Original checklist item:** Choose, document and test limits for host stop deadline and forced-termination attempts; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M02.05-C068-T01 · Quantity inventory:** Create a measurement inventory for “Host stop boundary”: “Host stop deadline and forced-termination attempts”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M02.05-C068-T02 · Measurement method:** Choose how to observe each “Host stop boundary” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M02.05-C068-T03 · Budget decision:** Select justified resource and input limits for “Host stop boundary”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M02.05-C068-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Host stop boundary” cases for “Host stop deadline and forced-termination attempts”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M02.05-C068-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Host stop boundary” limit; preserve “An uncooperative guest cannot prevent host-enforced stop”.
- [ ] **UC-M02.05-C068-T06 · Normal measurement:** Run or review the normal “Host stop boundary” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M02.05-C068-T07 · At-limit measurement:** Exercise the “Host stop boundary” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M02.05-C068-T08 · Over-limit measurement:** Exercise the “Host stop boundary” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M02.05-C068-T09 · Uncovered-scope report:** List the “Host stop boundary” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M02.05-C068-T10 · Limit evidence:** Publish the selected “Host stop boundary” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M02.05-C069 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for host stop boundary with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M02.05-C069-T01 · Event inventory:** List the “Host stop boundary” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M02.05-C069-T02 · Diagnostic schema:** Define nonsecret fields for “Host stop boundary” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M02.05-C069-T03 · Failure mapping:** Map each documented “Host stop boundary” refusal or error to a diagnostic outcome; include “An infinite guest loop ignores all cooperative stop requests” and prohibit conversion into a success message.
- [ ] **UC-M02.05-C069-T04 · Emission path:** Add the “Host stop boundary” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M02.05-C069-T05 · Redaction check:** Test “Host stop boundary” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M02.05-C069-T06 · Output budget:** Set and exercise bounded “Host stop boundary” message size, rate and retention compatible with “Host stop deadline and forced-termination attempts”; define truncation behavior that preserves the final reason.
- [ ] **UC-M02.05-C069-T07 · Success/refusal fixtures:** Capture “Host stop boundary” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M02.05-C069-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Host stop boundary” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M02.05-C069-T09 · Operator review:** Read the “Host stop boundary” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M02.05-C069-T10 · Diagnostic evidence:** Publish redacted “Host stop boundary” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M02.05-C070 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for host stop boundary; label unexecuted checks as untested.

- [ ] **UC-M02.05-C070-T01 · Evidence inventory:** List the “Host stop boundary” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M02.05-C070-T02 · Artifact references:** Record the exact “Host stop boundary” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M02.05-C070-T03 · Fixture references:** Attach the “Host stop boundary” fixture IDs, input identities and oracle definition; preserve the source counterexample “An infinite guest loop ignores all cooperative stop requests” as a distinct evidence case.
- [ ] **UC-M02.05-C070-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Host stop boundary”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M02.05-C070-T05 · Environment record:** Record the actual “Host stop boundary” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M02.05-C070-T06 · Expected versus observed:** Pair every “Host stop boundary” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M02.05-C070-T07 · Failure and limit records:** Attach “Host stop boundary” change/failure and bounds evidence where required; include uncovered “Host stop deadline and forced-termination attempts” and unresolved violations of “An uncooperative guest cannot prevent host-enforced stop”.
- [ ] **UC-M02.05-C070-T08 · Evidence hygiene:** Check the “Host stop boundary” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M02.05-C070-T09 · Reproduction review:** Have the “Host stop boundary” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M02.05-C070-T10 · Acceptance linkage:** Link the “Host stop boundary” evidence to its parent and UC-M02.05 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 08. Fairness and starvation

**Source delivery:** Define the supported fairness rule among work items or guest tasks.

**Source invariant:** One runnable task cannot exceed the declared starvation guarantee.

**Source negative case:** A busy task continuously requeues ahead of waiting work.

**Source bounded quantities:** Runnable population and maximum wait bound.

### UC-M02.05-C071 · Contract

**Original checklist item:** Specify fairness and starvation inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M02.05-C071-T01 · Scope statement:** Draft the operation boundary for “Fairness and starvation” within Guest execution loop and scheduling; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M02.05-C071-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Fairness and starvation”; record each producer, representation and missing-value meaning.
- [ ] **UC-M02.05-C071-T03 · Output inventory:** List the outputs of “Fairness and starvation” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M02.05-C071-T04 · Field dictionary:** Create a field-and-term dictionary for “Fairness and starvation”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M02.05-C071-T05 · Prerequisite contract:** Map “Fairness and starvation” to the source component prerequisites (UC-M02.02, UC-M02.04); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M02.05-C071-T06 · Authority map:** Identify who may produce, change and consume “Fairness and starvation”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M02.05-C071-T07 · Invariant clause:** Add a normative clause for “Fairness and starvation” that preserves “One runnable task cannot exceed the declared starvation guarantee”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M02.05-C071-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Fairness and starvation”; include the source counterexample “A busy task continuously requeues ahead of waiting work” and the intended safe disposition.
- [ ] **UC-M02.05-C071-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Runnable population and maximum wait bound” in the “Fairness and starvation” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M02.05-C071-T10 · Contract review:** Review the “Fairness and starvation” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M02.05-C072 · Delivery

**Original checklist item:** Define the supported fairness rule among work items or guest tasks.

- [ ] **UC-M02.05-C072-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Fairness and starvation”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M02.05-C072-T02 · Change plan:** Break the source delivery for “Fairness and starvation” into concrete edit targets and reviewable outputs; keep the UC-M02.05 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M02.05-C072-T03 · Core artifact:** Create the “Fairness and starvation” model, schema or inventory that realizes this source instruction: Define the supported fairness rule among work items or guest tasks.
- [ ] **UC-M02.05-C072-T04 · Concrete realization:** Populate “Fairness and starvation” with one concrete worked case; map every required entity or field to its source and flag any unmapped entry.
- [ ] **UC-M02.05-C072-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Fairness and starvation” needed to preserve “One runnable task cannot exceed the declared starvation guarantee”; record an enforcement gap where only a model exists.
- [ ] **UC-M02.05-C072-T06 · Dependency connection:** Connect the “Fairness and starvation” implementation to guest work dispatch, timers and the independent host stop path; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M02.05-C072-T07 · Resource behavior:** Account for “Runnable population and maximum wait bound” in “Fairness and starvation”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M02.05-C072-T08 · Delivery check:** Run the smallest real “Fairness and starvation” path and its adverse fixture “A busy task continuously requeues ahead of waiting work”; retain actual output, state effects and final disposition.
- [ ] **UC-M02.05-C072-T09 · Patch review:** Review the “Fairness and starvation” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M02.05-C072-T10 · Delivery handoff:** Publish the “Fairness and starvation” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M02.05-C073 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: One runnable task cannot exceed the declared starvation guarantee. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M02.05-C073-T01 · Named property:** Create a stable property/check name under this parent for “Fairness and starvation”; copy its required invariant exactly: “One runnable task cannot exceed the declared starvation guarantee”.
- [ ] **UC-M02.05-C073-T02 · Observable terms:** Define each term in the “Fairness and starvation” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M02.05-C073-T03 · Precondition set:** List the preconditions under which “One runnable task cannot exceed the declared starvation guarantee” must hold for “Fairness and starvation”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M02.05-C073-T04 · Transition coverage:** Map the “Fairness and starvation” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M02.05-C073-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Fairness and starvation”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M02.05-C073-T06 · Satisfying fixture:** Create a concrete “Fairness and starvation” case that satisfies “One runnable task cannot exceed the declared starvation guarantee”; record its expected observation before running the assertion or review.
- [ ] **UC-M02.05-C073-T07 · Violating fixture:** Create the source counterexample “A busy task continuously requeues ahead of waiting work” for “Fairness and starvation”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M02.05-C073-T08 · Enforcement evidence:** Exercise the “Fairness and starvation” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M02.05-C073-T09 · Regression linkage:** Link the “Fairness and starvation” property to changes in guest work dispatch, timers and the independent host stop path; record which dependency or contract changes require rerunning it.
- [ ] **UC-M02.05-C073-T10 · Property disposition:** Compare the satisfying and violating “Fairness and starvation” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M02.05-C074 · Integration

**Original checklist item:** Integrate fairness and starvation with guest work dispatch, timers and the independent host stop path; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M02.05-C074-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Fairness and starvation” across guest work dispatch, timers and the independent host stop path; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M02.05-C074-T02 · Field mapping:** Map every “Fairness and starvation” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M02.05-C074-T03 · Prerequisite identities:** Record the actual prerequisites for “Fairness and starvation” (source dependency list: UC-M02.02, UC-M02.04); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M02.05-C074-T04 · Ownership agreement:** Specify who owns “Fairness and starvation” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M02.05-C074-T05 · Handoff implementation:** Connect “Fairness and starvation” through the mapped seam using the real adapter or explicit specification reference; preserve “One runnable task cannot exceed the declared starvation guarantee” across the handoff.
- [ ] **UC-M02.05-C074-T06 · Absent-input case:** Omit one required “Fairness and starvation” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M02.05-C074-T07 · Stale-input case:** Supply an outdated “Fairness and starvation” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M02.05-C074-T08 · Incompatible-input case:** Supply an incompatible “Fairness and starvation” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M02.05-C074-T09 · Valid integration trace:** Run a valid “Fairness and starvation” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M02.05-C074-T10 · Seam review:** Reconcile the “Fairness and starvation” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M02.05-C075 · Valid-case test

**Original checklist item:** Run a valid-path fixture for fairness and starvation; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M02.05-C075-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Fairness and starvation” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M02.05-C075-T02 · Expected-result oracle:** Specify the “Fairness and starvation” expected result independently of the implementation output; include the property “One runnable task cannot exceed the declared starvation guarantee” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M02.05-C075-T03 · Fixture material:** Create the concrete “Fairness and starvation” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M02.05-C075-T04 · Target preparation:** Prepare the “Fairness and starvation” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M02.05-C075-T05 · Initial-state record:** Record the initial “Fairness and starvation” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M02.05-C075-T06 · Valid-path execution:** Execute the “Fairness and starvation” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M02.05-C075-T07 · Outcome comparison:** Compare every declared “Fairness and starvation” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M02.05-C075-T08 · State and bounds check:** Inspect the “Fairness and starvation” ownership/state effects and actual use of “Runnable population and maximum wait bound”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M02.05-C075-T09 · Repeatability check:** Repeat the same “Fairness and starvation” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M02.05-C075-T10 · Positive evidence:** Attach the “Fairness and starvation” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M02.05-C076 · Negative test

**Original checklist item:** Negative case: A busy task continuously requeues ahead of waiting work. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M02.05-C076-T01 · Adverse-case definition:** Create a test record for the exact “Fairness and starvation” source counterexample: “A busy task continuously requeues ahead of waiting work”; state which precondition or invariant it challenges.
- [ ] **UC-M02.05-C076-T02 · Safe fixture boundary:** Define the contained test boundary for “Fairness and starvation”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M02.05-C076-T03 · Valid control:** Construct a valid “Fairness and starvation” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M02.05-C076-T04 · Minimal adverse input:** Derive the “Fairness and starvation” adverse fixture from the control with the smallest documented change needed to reproduce “A busy task continuously requeues ahead of waiting work”; retain that change as reproducible data.
- [ ] **UC-M02.05-C076-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Fairness and starvation”; require “One runnable task cannot exceed the declared starvation guarantee” and forbid a false-success verdict.
- [ ] **UC-M02.05-C076-T06 · Adverse execution:** Exercise the “Fairness and starvation” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M02.05-C076-T07 · Effect inspection:** Inspect “Fairness and starvation” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M02.05-C076-T08 · Refusal versus failure:** Confirm the “Fairness and starvation” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M02.05-C076-T09 · Reset and retention:** Restore only the disposable “Fairness and starvation” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M02.05-C076-T10 · Negative regression:** Register the “Fairness and starvation” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M02.05-C077 · Change / failure test

**Original checklist item:** Exercise fairness and starvation when an uncooperative guest ignores cancellation while another guest must keep progressing; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M02.05-C077-T01 · Scenario record:** Write the “Fairness and starvation” change/failure scenario exactly as supplied: an uncooperative guest ignores cancellation while another guest must keep progressing; identify the property that must remain true: “One runnable task cannot exceed the declared starvation guarantee”.
- [ ] **UC-M02.05-C077-T02 · Baseline capture:** Create a known-valid “Fairness and starvation” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M02.05-C077-T03 · Injection map:** Locate the “Fairness and starvation” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M02.05-C077-T04 · Disposition oracle:** Define the legal intermediate and final “Fairness and starvation” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M02.05-C077-T05 · Controlled trigger:** Introduce the controlled “Fairness and starvation” scenario in the disposable fixture: an uncooperative guest ignores cancellation while another guest must keep progressing; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M02.05-C077-T06 · Intermediate inspection:** Inspect the “Fairness and starvation” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M02.05-C077-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Fairness and starvation”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M02.05-C077-T08 · Stale-evidence cleanup:** Invalidate superseded “Fairness and starvation” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M02.05-C077-T09 · Repeat and compare:** Repeat the selected “Fairness and starvation” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M02.05-C077-T10 · Failure evidence:** Publish the “Fairness and starvation” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M02.05-C078 · Bounds

**Original checklist item:** Choose, document and test limits for runnable population and maximum wait bound; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M02.05-C078-T01 · Quantity inventory:** Create a measurement inventory for “Fairness and starvation”: “Runnable population and maximum wait bound”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M02.05-C078-T02 · Measurement method:** Choose how to observe each “Fairness and starvation” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M02.05-C078-T03 · Budget decision:** Select justified resource and input limits for “Fairness and starvation”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M02.05-C078-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Fairness and starvation” cases for “Runnable population and maximum wait bound”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M02.05-C078-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Fairness and starvation” limit; preserve “One runnable task cannot exceed the declared starvation guarantee”.
- [ ] **UC-M02.05-C078-T06 · Normal measurement:** Run or review the normal “Fairness and starvation” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M02.05-C078-T07 · At-limit measurement:** Exercise the “Fairness and starvation” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M02.05-C078-T08 · Over-limit measurement:** Exercise the “Fairness and starvation” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M02.05-C078-T09 · Uncovered-scope report:** List the “Fairness and starvation” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M02.05-C078-T10 · Limit evidence:** Publish the selected “Fairness and starvation” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M02.05-C079 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for fairness and starvation with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M02.05-C079-T01 · Event inventory:** List the “Fairness and starvation” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M02.05-C079-T02 · Diagnostic schema:** Define nonsecret fields for “Fairness and starvation” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M02.05-C079-T03 · Failure mapping:** Map each documented “Fairness and starvation” refusal or error to a diagnostic outcome; include “A busy task continuously requeues ahead of waiting work” and prohibit conversion into a success message.
- [ ] **UC-M02.05-C079-T04 · Emission path:** Add the “Fairness and starvation” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M02.05-C079-T05 · Redaction check:** Test “Fairness and starvation” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M02.05-C079-T06 · Output budget:** Set and exercise bounded “Fairness and starvation” message size, rate and retention compatible with “Runnable population and maximum wait bound”; define truncation behavior that preserves the final reason.
- [ ] **UC-M02.05-C079-T07 · Success/refusal fixtures:** Capture “Fairness and starvation” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M02.05-C079-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Fairness and starvation” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M02.05-C079-T09 · Operator review:** Read the “Fairness and starvation” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M02.05-C079-T10 · Diagnostic evidence:** Publish redacted “Fairness and starvation” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M02.05-C080 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for fairness and starvation; label unexecuted checks as untested.

- [ ] **UC-M02.05-C080-T01 · Evidence inventory:** List the “Fairness and starvation” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M02.05-C080-T02 · Artifact references:** Record the exact “Fairness and starvation” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M02.05-C080-T03 · Fixture references:** Attach the “Fairness and starvation” fixture IDs, input identities and oracle definition; preserve the source counterexample “A busy task continuously requeues ahead of waiting work” as a distinct evidence case.
- [ ] **UC-M02.05-C080-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Fairness and starvation”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M02.05-C080-T05 · Environment record:** Record the actual “Fairness and starvation” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M02.05-C080-T06 · Expected versus observed:** Pair every “Fairness and starvation” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M02.05-C080-T07 · Failure and limit records:** Attach “Fairness and starvation” change/failure and bounds evidence where required; include uncovered “Runnable population and maximum wait bound” and unresolved violations of “One runnable task cannot exceed the declared starvation guarantee”.
- [ ] **UC-M02.05-C080-T08 · Evidence hygiene:** Check the “Fairness and starvation” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M02.05-C080-T09 · Reproduction review:** Have the “Fairness and starvation” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M02.05-C080-T10 · Acceptance linkage:** Link the “Fairness and starvation” evidence to its parent and UC-M02.05 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 09. Completion and yield semantics

**Source delivery:** Distinguish completion, yield, cancellation and execution failure.

**Source invariant:** A yield is not recorded as a completed invocation.

**Source negative case:** A yielded invocation publishes a final success prematurely.

**Source bounded quantities:** Yield frequency and completion record size.

### UC-M02.05-C081 · Contract

**Original checklist item:** Specify completion and yield semantics inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M02.05-C081-T01 · Scope statement:** Draft the operation boundary for “Completion and yield semantics” within Guest execution loop and scheduling; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M02.05-C081-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Completion and yield semantics”; record each producer, representation and missing-value meaning.
- [ ] **UC-M02.05-C081-T03 · Output inventory:** List the outputs of “Completion and yield semantics” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M02.05-C081-T04 · Field dictionary:** Create a field-and-term dictionary for “Completion and yield semantics”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M02.05-C081-T05 · Prerequisite contract:** Map “Completion and yield semantics” to the source component prerequisites (UC-M02.02, UC-M02.04); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M02.05-C081-T06 · Authority map:** Identify who may produce, change and consume “Completion and yield semantics”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M02.05-C081-T07 · Invariant clause:** Add a normative clause for “Completion and yield semantics” that preserves “A yield is not recorded as a completed invocation”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M02.05-C081-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Completion and yield semantics”; include the source counterexample “A yielded invocation publishes a final success prematurely” and the intended safe disposition.
- [ ] **UC-M02.05-C081-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Yield frequency and completion record size” in the “Completion and yield semantics” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M02.05-C081-T10 · Contract review:** Review the “Completion and yield semantics” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M02.05-C082 · Delivery

**Original checklist item:** Distinguish completion, yield, cancellation and execution failure.

- [ ] **UC-M02.05-C082-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Completion and yield semantics”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M02.05-C082-T02 · Change plan:** Break the source delivery for “Completion and yield semantics” into concrete edit targets and reviewable outputs; keep the UC-M02.05 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M02.05-C082-T03 · Core artifact:** Create the “Completion and yield semantics” model, schema or inventory that realizes this source instruction: Distinguish completion, yield, cancellation and execution failure.
- [ ] **UC-M02.05-C082-T04 · Concrete realization:** Populate “Completion and yield semantics” with one concrete worked case; map every required entity or field to its source and flag any unmapped entry.
- [ ] **UC-M02.05-C082-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Completion and yield semantics” needed to preserve “A yield is not recorded as a completed invocation”; record an enforcement gap where only a model exists.
- [ ] **UC-M02.05-C082-T06 · Dependency connection:** Connect the “Completion and yield semantics” implementation to guest work dispatch, timers and the independent host stop path; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M02.05-C082-T07 · Resource behavior:** Account for “Yield frequency and completion record size” in “Completion and yield semantics”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M02.05-C082-T08 · Delivery check:** Run the smallest real “Completion and yield semantics” path and its adverse fixture “A yielded invocation publishes a final success prematurely”; retain actual output, state effects and final disposition.
- [ ] **UC-M02.05-C082-T09 · Patch review:** Review the “Completion and yield semantics” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M02.05-C082-T10 · Delivery handoff:** Publish the “Completion and yield semantics” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M02.05-C083 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: A yield is not recorded as a completed invocation. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M02.05-C083-T01 · Named property:** Create a stable property/check name under this parent for “Completion and yield semantics”; copy its required invariant exactly: “A yield is not recorded as a completed invocation”.
- [ ] **UC-M02.05-C083-T02 · Observable terms:** Define each term in the “Completion and yield semantics” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M02.05-C083-T03 · Precondition set:** List the preconditions under which “A yield is not recorded as a completed invocation” must hold for “Completion and yield semantics”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M02.05-C083-T04 · Transition coverage:** Map the “Completion and yield semantics” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M02.05-C083-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Completion and yield semantics”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M02.05-C083-T06 · Satisfying fixture:** Create a concrete “Completion and yield semantics” case that satisfies “A yield is not recorded as a completed invocation”; record its expected observation before running the assertion or review.
- [ ] **UC-M02.05-C083-T07 · Violating fixture:** Create the source counterexample “A yielded invocation publishes a final success prematurely” for “Completion and yield semantics”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M02.05-C083-T08 · Enforcement evidence:** Exercise the “Completion and yield semantics” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M02.05-C083-T09 · Regression linkage:** Link the “Completion and yield semantics” property to changes in guest work dispatch, timers and the independent host stop path; record which dependency or contract changes require rerunning it.
- [ ] **UC-M02.05-C083-T10 · Property disposition:** Compare the satisfying and violating “Completion and yield semantics” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M02.05-C084 · Integration

**Original checklist item:** Integrate completion and yield semantics with guest work dispatch, timers and the independent host stop path; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M02.05-C084-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Completion and yield semantics” across guest work dispatch, timers and the independent host stop path; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M02.05-C084-T02 · Field mapping:** Map every “Completion and yield semantics” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M02.05-C084-T03 · Prerequisite identities:** Record the actual prerequisites for “Completion and yield semantics” (source dependency list: UC-M02.02, UC-M02.04); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M02.05-C084-T04 · Ownership agreement:** Specify who owns “Completion and yield semantics” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M02.05-C084-T05 · Handoff implementation:** Connect “Completion and yield semantics” through the mapped seam using the real adapter or explicit specification reference; preserve “A yield is not recorded as a completed invocation” across the handoff.
- [ ] **UC-M02.05-C084-T06 · Absent-input case:** Omit one required “Completion and yield semantics” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M02.05-C084-T07 · Stale-input case:** Supply an outdated “Completion and yield semantics” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M02.05-C084-T08 · Incompatible-input case:** Supply an incompatible “Completion and yield semantics” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M02.05-C084-T09 · Valid integration trace:** Run a valid “Completion and yield semantics” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M02.05-C084-T10 · Seam review:** Reconcile the “Completion and yield semantics” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M02.05-C085 · Valid-case test

**Original checklist item:** Run a valid-path fixture for completion and yield semantics; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M02.05-C085-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Completion and yield semantics” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M02.05-C085-T02 · Expected-result oracle:** Specify the “Completion and yield semantics” expected result independently of the implementation output; include the property “A yield is not recorded as a completed invocation” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M02.05-C085-T03 · Fixture material:** Create the concrete “Completion and yield semantics” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M02.05-C085-T04 · Target preparation:** Prepare the “Completion and yield semantics” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M02.05-C085-T05 · Initial-state record:** Record the initial “Completion and yield semantics” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M02.05-C085-T06 · Valid-path execution:** Execute the “Completion and yield semantics” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M02.05-C085-T07 · Outcome comparison:** Compare every declared “Completion and yield semantics” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M02.05-C085-T08 · State and bounds check:** Inspect the “Completion and yield semantics” ownership/state effects and actual use of “Yield frequency and completion record size”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M02.05-C085-T09 · Repeatability check:** Repeat the same “Completion and yield semantics” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M02.05-C085-T10 · Positive evidence:** Attach the “Completion and yield semantics” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M02.05-C086 · Negative test

**Original checklist item:** Negative case: A yielded invocation publishes a final success prematurely. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M02.05-C086-T01 · Adverse-case definition:** Create a test record for the exact “Completion and yield semantics” source counterexample: “A yielded invocation publishes a final success prematurely”; state which precondition or invariant it challenges.
- [ ] **UC-M02.05-C086-T02 · Safe fixture boundary:** Define the contained test boundary for “Completion and yield semantics”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M02.05-C086-T03 · Valid control:** Construct a valid “Completion and yield semantics” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M02.05-C086-T04 · Minimal adverse input:** Derive the “Completion and yield semantics” adverse fixture from the control with the smallest documented change needed to reproduce “A yielded invocation publishes a final success prematurely”; retain that change as reproducible data.
- [ ] **UC-M02.05-C086-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Completion and yield semantics”; require “A yield is not recorded as a completed invocation” and forbid a false-success verdict.
- [ ] **UC-M02.05-C086-T06 · Adverse execution:** Exercise the “Completion and yield semantics” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M02.05-C086-T07 · Effect inspection:** Inspect “Completion and yield semantics” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M02.05-C086-T08 · Refusal versus failure:** Confirm the “Completion and yield semantics” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M02.05-C086-T09 · Reset and retention:** Restore only the disposable “Completion and yield semantics” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M02.05-C086-T10 · Negative regression:** Register the “Completion and yield semantics” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M02.05-C087 · Change / failure test

**Original checklist item:** Exercise completion and yield semantics when an uncooperative guest ignores cancellation while another guest must keep progressing; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M02.05-C087-T01 · Scenario record:** Write the “Completion and yield semantics” change/failure scenario exactly as supplied: an uncooperative guest ignores cancellation while another guest must keep progressing; identify the property that must remain true: “A yield is not recorded as a completed invocation”.
- [ ] **UC-M02.05-C087-T02 · Baseline capture:** Create a known-valid “Completion and yield semantics” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M02.05-C087-T03 · Injection map:** Locate the “Completion and yield semantics” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M02.05-C087-T04 · Disposition oracle:** Define the legal intermediate and final “Completion and yield semantics” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M02.05-C087-T05 · Controlled trigger:** Introduce the controlled “Completion and yield semantics” scenario in the disposable fixture: an uncooperative guest ignores cancellation while another guest must keep progressing; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M02.05-C087-T06 · Intermediate inspection:** Inspect the “Completion and yield semantics” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M02.05-C087-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Completion and yield semantics”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M02.05-C087-T08 · Stale-evidence cleanup:** Invalidate superseded “Completion and yield semantics” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M02.05-C087-T09 · Repeat and compare:** Repeat the selected “Completion and yield semantics” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M02.05-C087-T10 · Failure evidence:** Publish the “Completion and yield semantics” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M02.05-C088 · Bounds

**Original checklist item:** Choose, document and test limits for yield frequency and completion record size; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M02.05-C088-T01 · Quantity inventory:** Create a measurement inventory for “Completion and yield semantics”: “Yield frequency and completion record size”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M02.05-C088-T02 · Measurement method:** Choose how to observe each “Completion and yield semantics” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M02.05-C088-T03 · Budget decision:** Select justified resource and input limits for “Completion and yield semantics”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M02.05-C088-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Completion and yield semantics” cases for “Yield frequency and completion record size”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M02.05-C088-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Completion and yield semantics” limit; preserve “A yield is not recorded as a completed invocation”.
- [ ] **UC-M02.05-C088-T06 · Normal measurement:** Run or review the normal “Completion and yield semantics” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M02.05-C088-T07 · At-limit measurement:** Exercise the “Completion and yield semantics” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M02.05-C088-T08 · Over-limit measurement:** Exercise the “Completion and yield semantics” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M02.05-C088-T09 · Uncovered-scope report:** List the “Completion and yield semantics” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M02.05-C088-T10 · Limit evidence:** Publish the selected “Completion and yield semantics” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M02.05-C089 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for completion and yield semantics with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M02.05-C089-T01 · Event inventory:** List the “Completion and yield semantics” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M02.05-C089-T02 · Diagnostic schema:** Define nonsecret fields for “Completion and yield semantics” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M02.05-C089-T03 · Failure mapping:** Map each documented “Completion and yield semantics” refusal or error to a diagnostic outcome; include “A yielded invocation publishes a final success prematurely” and prohibit conversion into a success message.
- [ ] **UC-M02.05-C089-T04 · Emission path:** Add the “Completion and yield semantics” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M02.05-C089-T05 · Redaction check:** Test “Completion and yield semantics” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M02.05-C089-T06 · Output budget:** Set and exercise bounded “Completion and yield semantics” message size, rate and retention compatible with “Yield frequency and completion record size”; define truncation behavior that preserves the final reason.
- [ ] **UC-M02.05-C089-T07 · Success/refusal fixtures:** Capture “Completion and yield semantics” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M02.05-C089-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Completion and yield semantics” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M02.05-C089-T09 · Operator review:** Read the “Completion and yield semantics” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M02.05-C089-T10 · Diagnostic evidence:** Publish redacted “Completion and yield semantics” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M02.05-C090 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for completion and yield semantics; label unexecuted checks as untested.

- [ ] **UC-M02.05-C090-T01 · Evidence inventory:** List the “Completion and yield semantics” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M02.05-C090-T02 · Artifact references:** Record the exact “Completion and yield semantics” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M02.05-C090-T03 · Fixture references:** Attach the “Completion and yield semantics” fixture IDs, input identities and oracle definition; preserve the source counterexample “A yielded invocation publishes a final success prematurely” as a distinct evidence case.
- [ ] **UC-M02.05-C090-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Completion and yield semantics”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M02.05-C090-T05 · Environment record:** Record the actual “Completion and yield semantics” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M02.05-C090-T06 · Expected versus observed:** Pair every “Completion and yield semantics” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M02.05-C090-T07 · Failure and limit records:** Attach “Completion and yield semantics” change/failure and bounds evidence where required; include uncovered “Yield frequency and completion record size” and unresolved violations of “A yield is not recorded as a completed invocation”.
- [ ] **UC-M02.05-C090-T08 · Evidence hygiene:** Check the “Completion and yield semantics” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M02.05-C090-T09 · Reproduction review:** Have the “Completion and yield semantics” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M02.05-C090-T10 · Acceptance linkage:** Link the “Completion and yield semantics” evidence to its parent and UC-M02.05 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 10. Scheduling qualification

**Source delivery:** Exercise busy loops, idle loops, timer activity and concurrent guest operation.

**Source invariant:** A non-terminating workload can be stopped without starving other guests.

**Source negative case:** One guest runs continuously while another performs bounded work.

**Source bounded quantities:** Test duration, guest count and latency observations.

### UC-M02.05-C091 · Contract

**Original checklist item:** Specify scheduling qualification inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M02.05-C091-T01 · Scope statement:** Draft the operation boundary for “Scheduling qualification” within Guest execution loop and scheduling; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M02.05-C091-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Scheduling qualification”; record each producer, representation and missing-value meaning.
- [ ] **UC-M02.05-C091-T03 · Output inventory:** List the outputs of “Scheduling qualification” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M02.05-C091-T04 · Field dictionary:** Create a field-and-term dictionary for “Scheduling qualification”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M02.05-C091-T05 · Prerequisite contract:** Map “Scheduling qualification” to the source component prerequisites (UC-M02.02, UC-M02.04); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M02.05-C091-T06 · Authority map:** Identify who may produce, change and consume “Scheduling qualification”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M02.05-C091-T07 · Invariant clause:** Add a normative clause for “Scheduling qualification” that preserves “A non-terminating workload can be stopped without starving other guests”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M02.05-C091-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Scheduling qualification”; include the source counterexample “One guest runs continuously while another performs bounded work” and the intended safe disposition.
- [ ] **UC-M02.05-C091-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Test duration, guest count and latency observations” in the “Scheduling qualification” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M02.05-C091-T10 · Contract review:** Review the “Scheduling qualification” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M02.05-C092 · Delivery

**Original checklist item:** Exercise busy loops, idle loops, timer activity and concurrent guest operation.

- [ ] **UC-M02.05-C092-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Scheduling qualification”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M02.05-C092-T02 · Change plan:** Break the source delivery for “Scheduling qualification” into concrete edit targets and reviewable outputs; keep the UC-M02.05 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M02.05-C092-T03 · Core artifact:** Create the “Scheduling qualification” fixture or harness for this source instruction: Exercise busy loops, idle loops, timer activity and concurrent guest operation.
- [ ] **UC-M02.05-C092-T04 · Concrete realization:** Connect the “Scheduling qualification” harness to its actual intended target, set the expected oracle before running it, and distinguish a mock/control run from a target run.
- [ ] **UC-M02.05-C092-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Scheduling qualification” needed to preserve “A non-terminating workload can be stopped without starving other guests”; record an enforcement gap where only a model exists.
- [ ] **UC-M02.05-C092-T06 · Dependency connection:** Connect the “Scheduling qualification” implementation to guest work dispatch, timers and the independent host stop path; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M02.05-C092-T07 · Resource behavior:** Account for “Test duration, guest count and latency observations” in “Scheduling qualification”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M02.05-C092-T08 · Delivery check:** Run the smallest real “Scheduling qualification” path and its adverse fixture “One guest runs continuously while another performs bounded work”; retain actual output, state effects and final disposition.
- [ ] **UC-M02.05-C092-T09 · Patch review:** Review the “Scheduling qualification” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M02.05-C092-T10 · Delivery handoff:** Publish the “Scheduling qualification” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M02.05-C093 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: A non-terminating workload can be stopped without starving other guests. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M02.05-C093-T01 · Named property:** Create a stable property/check name under this parent for “Scheduling qualification”; copy its required invariant exactly: “A non-terminating workload can be stopped without starving other guests”.
- [ ] **UC-M02.05-C093-T02 · Observable terms:** Define each term in the “Scheduling qualification” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M02.05-C093-T03 · Precondition set:** List the preconditions under which “A non-terminating workload can be stopped without starving other guests” must hold for “Scheduling qualification”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M02.05-C093-T04 · Transition coverage:** Map the “Scheduling qualification” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M02.05-C093-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Scheduling qualification”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M02.05-C093-T06 · Satisfying fixture:** Create a concrete “Scheduling qualification” case that satisfies “A non-terminating workload can be stopped without starving other guests”; record its expected observation before running the assertion or review.
- [ ] **UC-M02.05-C093-T07 · Violating fixture:** Create the source counterexample “One guest runs continuously while another performs bounded work” for “Scheduling qualification”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M02.05-C093-T08 · Enforcement evidence:** Exercise the “Scheduling qualification” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M02.05-C093-T09 · Regression linkage:** Link the “Scheduling qualification” property to changes in guest work dispatch, timers and the independent host stop path; record which dependency or contract changes require rerunning it.
- [ ] **UC-M02.05-C093-T10 · Property disposition:** Compare the satisfying and violating “Scheduling qualification” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M02.05-C094 · Integration

**Original checklist item:** Integrate scheduling qualification with guest work dispatch, timers and the independent host stop path; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M02.05-C094-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Scheduling qualification” across guest work dispatch, timers and the independent host stop path; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M02.05-C094-T02 · Field mapping:** Map every “Scheduling qualification” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M02.05-C094-T03 · Prerequisite identities:** Record the actual prerequisites for “Scheduling qualification” (source dependency list: UC-M02.02, UC-M02.04); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M02.05-C094-T04 · Ownership agreement:** Specify who owns “Scheduling qualification” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M02.05-C094-T05 · Handoff implementation:** Connect “Scheduling qualification” through the mapped seam using the real adapter or explicit specification reference; preserve “A non-terminating workload can be stopped without starving other guests” across the handoff.
- [ ] **UC-M02.05-C094-T06 · Absent-input case:** Omit one required “Scheduling qualification” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M02.05-C094-T07 · Stale-input case:** Supply an outdated “Scheduling qualification” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M02.05-C094-T08 · Incompatible-input case:** Supply an incompatible “Scheduling qualification” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M02.05-C094-T09 · Valid integration trace:** Run a valid “Scheduling qualification” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M02.05-C094-T10 · Seam review:** Reconcile the “Scheduling qualification” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M02.05-C095 · Valid-case test

**Original checklist item:** Run a valid-path fixture for scheduling qualification; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M02.05-C095-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Scheduling qualification” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M02.05-C095-T02 · Expected-result oracle:** Specify the “Scheduling qualification” expected result independently of the implementation output; include the property “A non-terminating workload can be stopped without starving other guests” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M02.05-C095-T03 · Fixture material:** Create the concrete “Scheduling qualification” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M02.05-C095-T04 · Target preparation:** Prepare the “Scheduling qualification” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M02.05-C095-T05 · Initial-state record:** Record the initial “Scheduling qualification” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M02.05-C095-T06 · Valid-path execution:** Execute the “Scheduling qualification” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M02.05-C095-T07 · Outcome comparison:** Compare every declared “Scheduling qualification” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M02.05-C095-T08 · State and bounds check:** Inspect the “Scheduling qualification” ownership/state effects and actual use of “Test duration, guest count and latency observations”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M02.05-C095-T09 · Repeatability check:** Repeat the same “Scheduling qualification” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M02.05-C095-T10 · Positive evidence:** Attach the “Scheduling qualification” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M02.05-C096 · Negative test

**Original checklist item:** Negative case: One guest runs continuously while another performs bounded work. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M02.05-C096-T01 · Adverse-case definition:** Create a test record for the exact “Scheduling qualification” source counterexample: “One guest runs continuously while another performs bounded work”; state which precondition or invariant it challenges.
- [ ] **UC-M02.05-C096-T02 · Safe fixture boundary:** Define the contained test boundary for “Scheduling qualification”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M02.05-C096-T03 · Valid control:** Construct a valid “Scheduling qualification” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M02.05-C096-T04 · Minimal adverse input:** Derive the “Scheduling qualification” adverse fixture from the control with the smallest documented change needed to reproduce “One guest runs continuously while another performs bounded work”; retain that change as reproducible data.
- [ ] **UC-M02.05-C096-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Scheduling qualification”; require “A non-terminating workload can be stopped without starving other guests” and forbid a false-success verdict.
- [ ] **UC-M02.05-C096-T06 · Adverse execution:** Exercise the “Scheduling qualification” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M02.05-C096-T07 · Effect inspection:** Inspect “Scheduling qualification” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M02.05-C096-T08 · Refusal versus failure:** Confirm the “Scheduling qualification” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M02.05-C096-T09 · Reset and retention:** Restore only the disposable “Scheduling qualification” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M02.05-C096-T10 · Negative regression:** Register the “Scheduling qualification” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M02.05-C097 · Change / failure test

**Original checklist item:** Exercise scheduling qualification when an uncooperative guest ignores cancellation while another guest must keep progressing; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M02.05-C097-T01 · Scenario record:** Write the “Scheduling qualification” change/failure scenario exactly as supplied: an uncooperative guest ignores cancellation while another guest must keep progressing; identify the property that must remain true: “A non-terminating workload can be stopped without starving other guests”.
- [ ] **UC-M02.05-C097-T02 · Baseline capture:** Create a known-valid “Scheduling qualification” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M02.05-C097-T03 · Injection map:** Locate the “Scheduling qualification” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M02.05-C097-T04 · Disposition oracle:** Define the legal intermediate and final “Scheduling qualification” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M02.05-C097-T05 · Controlled trigger:** Introduce the controlled “Scheduling qualification” scenario in the disposable fixture: an uncooperative guest ignores cancellation while another guest must keep progressing; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M02.05-C097-T06 · Intermediate inspection:** Inspect the “Scheduling qualification” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M02.05-C097-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Scheduling qualification”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M02.05-C097-T08 · Stale-evidence cleanup:** Invalidate superseded “Scheduling qualification” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M02.05-C097-T09 · Repeat and compare:** Repeat the selected “Scheduling qualification” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M02.05-C097-T10 · Failure evidence:** Publish the “Scheduling qualification” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M02.05-C098 · Bounds

**Original checklist item:** Choose, document and test limits for test duration, guest count and latency observations; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M02.05-C098-T01 · Quantity inventory:** Create a measurement inventory for “Scheduling qualification”: “Test duration, guest count and latency observations”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M02.05-C098-T02 · Measurement method:** Choose how to observe each “Scheduling qualification” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M02.05-C098-T03 · Budget decision:** Select justified resource and input limits for “Scheduling qualification”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M02.05-C098-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Scheduling qualification” cases for “Test duration, guest count and latency observations”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M02.05-C098-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Scheduling qualification” limit; preserve “A non-terminating workload can be stopped without starving other guests”.
- [ ] **UC-M02.05-C098-T06 · Normal measurement:** Run or review the normal “Scheduling qualification” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M02.05-C098-T07 · At-limit measurement:** Exercise the “Scheduling qualification” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M02.05-C098-T08 · Over-limit measurement:** Exercise the “Scheduling qualification” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M02.05-C098-T09 · Uncovered-scope report:** List the “Scheduling qualification” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M02.05-C098-T10 · Limit evidence:** Publish the selected “Scheduling qualification” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M02.05-C099 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for scheduling qualification with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M02.05-C099-T01 · Event inventory:** List the “Scheduling qualification” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M02.05-C099-T02 · Diagnostic schema:** Define nonsecret fields for “Scheduling qualification” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M02.05-C099-T03 · Failure mapping:** Map each documented “Scheduling qualification” refusal or error to a diagnostic outcome; include “One guest runs continuously while another performs bounded work” and prohibit conversion into a success message.
- [ ] **UC-M02.05-C099-T04 · Emission path:** Add the “Scheduling qualification” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M02.05-C099-T05 · Redaction check:** Test “Scheduling qualification” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M02.05-C099-T06 · Output budget:** Set and exercise bounded “Scheduling qualification” message size, rate and retention compatible with “Test duration, guest count and latency observations”; define truncation behavior that preserves the final reason.
- [ ] **UC-M02.05-C099-T07 · Success/refusal fixtures:** Capture “Scheduling qualification” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M02.05-C099-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Scheduling qualification” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M02.05-C099-T09 · Operator review:** Read the “Scheduling qualification” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M02.05-C099-T10 · Diagnostic evidence:** Publish redacted “Scheduling qualification” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M02.05-C100 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for scheduling qualification; label unexecuted checks as untested.

- [ ] **UC-M02.05-C100-T01 · Evidence inventory:** List the “Scheduling qualification” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M02.05-C100-T02 · Artifact references:** Record the exact “Scheduling qualification” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M02.05-C100-T03 · Fixture references:** Attach the “Scheduling qualification” fixture IDs, input identities and oracle definition; preserve the source counterexample “One guest runs continuously while another performs bounded work” as a distinct evidence case.
- [ ] **UC-M02.05-C100-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Scheduling qualification”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M02.05-C100-T05 · Environment record:** Record the actual “Scheduling qualification” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M02.05-C100-T06 · Expected versus observed:** Pair every “Scheduling qualification” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M02.05-C100-T07 · Failure and limit records:** Attach “Scheduling qualification” change/failure and bounds evidence where required; include uncovered “Test duration, guest count and latency observations” and unresolved violations of “A non-terminating workload can be stopped without starving other guests”.
- [ ] **UC-M02.05-C100-T08 · Evidence hygiene:** Check the “Scheduling qualification” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M02.05-C100-T09 · Reproduction review:** Have the “Scheduling qualification” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M02.05-C100-T10 · Acceptance linkage:** Link the “Scheduling qualification” evidence to its parent and UC-M02.05 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

