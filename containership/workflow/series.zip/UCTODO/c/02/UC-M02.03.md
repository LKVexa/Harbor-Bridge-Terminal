# UC-M02.03 — Linker, image layout and permissions

**To-Do Pack 2.0.0 · Baseline UC-2.2.0 · 100 parent checks × 10 subtasks = 1,000 to-dos**

[Master index](../../INDEX.md) · [Workstream index](../../w/02.md)

| Field | Preserved source value |
|---|---|
| Workstream | 02. Bootable unikernel guest |
| Milestone | B |
| Priority | P0 |
| Source assessment | MISSING |
| Scope | core or selected profile |
| Dependencies | [UC-M02.02](../02/UC-M02.02.md) |
| Source checklist pack | 1.0.0 |
| Original reference labels | [S1], [S2], [S3]. |

## Original requirement

Define executable sections, relocations, memory map, zero initialization, overflow bounds and supported image format.

**Original acceptance criterion:** Malformed images are rejected; executable and writable regions follow the selected platform protection policy.

**Source trace:** Original checklist `UC100/c/02/UC-M02.03.md` inside [s/checklists.zip](../../s/checklists.zip); exact parent records in [data/parents.jsonl](../../data/parents.jsonl). Original roadmap lines 166–176 are preserved in [s/roadmap.md](../../s/roadmap.md).

## How to use these lists

Every parent statement below is preserved verbatim. Its ten child tasks are proposed decomposition, not implemented capabilities or executed tests. Child IDs append `-T01` through `-T10` to the original parent ID. All begin unchecked / `TODO`. Design/review evidence does not establish runtime enforcement; observe the actual selected target where the parent requires it.

The source dependency graph and selected release profile determine applicability. The numbered child sequence is a local working order, not an added hard dependency graph. An unselected optional feature needs a recorded not-applicable rationale; missing prerequisites for selected work remain blockers. Numerical budgets, backends and trust mechanisms remain decisions unless fixed by the source. Test hostile cases only with synthetic inputs in authorized disposable environments.

## 01. Image format selection

**Source delivery:** Declare the exact guest image format and supported format features.

**Source invariant:** Unsupported format variants are rejected before execution.

**Source negative case:** An image uses an unimplemented optional header format.

**Source bounded quantities:** Header bytes and supported format variants.

### UC-M02.03-C001 · Contract

**Original checklist item:** Specify image format selection inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M02.03-C001-T01 · Scope statement:** Draft the operation boundary for “Image format selection” within Linker, image layout and permissions; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M02.03-C001-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Image format selection”; record each producer, representation and missing-value meaning.
- [ ] **UC-M02.03-C001-T03 · Output inventory:** List the outputs of “Image format selection” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M02.03-C001-T04 · Field dictionary:** Create a field-and-term dictionary for “Image format selection”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M02.03-C001-T05 · Prerequisite contract:** Map “Image format selection” to the source component prerequisites (UC-M02.02); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M02.03-C001-T06 · Authority map:** Identify who may produce, change and consume “Image format selection”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M02.03-C001-T07 · Invariant clause:** Add a normative clause for “Image format selection” that preserves “Unsupported format variants are rejected before execution”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M02.03-C001-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Image format selection”; include the source counterexample “An image uses an unimplemented optional header format” and the intended safe disposition.
- [ ] **UC-M02.03-C001-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Header bytes and supported format variants” in the “Image format selection” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M02.03-C001-T10 · Contract review:** Review the “Image format selection” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M02.03-C002 · Delivery

**Original checklist item:** Declare the exact guest image format and supported format features.

- [ ] **UC-M02.03-C002-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Image format selection”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M02.03-C002-T02 · Change plan:** Break the source delivery for “Image format selection” into concrete edit targets and reviewable outputs; keep the UC-M02.03 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M02.03-C002-T03 · Core artifact:** Create the “Image format selection” model, schema or inventory that realizes this source instruction: Declare the exact guest image format and supported format features.
- [ ] **UC-M02.03-C002-T04 · Concrete realization:** Populate “Image format selection” with one concrete worked case; map every required entity or field to its source and flag any unmapped entry.
- [ ] **UC-M02.03-C002-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Image format selection” needed to preserve “Unsupported format variants are rejected before execution”; record an enforcement gap where only a model exists.
- [ ] **UC-M02.03-C002-T06 · Dependency connection:** Connect the “Image format selection” implementation to the linker script, image validator and selected backend loader; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M02.03-C002-T07 · Resource behavior:** Account for “Header bytes and supported format variants” in “Image format selection”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M02.03-C002-T08 · Delivery check:** Run the smallest real “Image format selection” path and its adverse fixture “An image uses an unimplemented optional header format”; retain actual output, state effects and final disposition.
- [ ] **UC-M02.03-C002-T09 · Patch review:** Review the “Image format selection” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M02.03-C002-T10 · Delivery handoff:** Publish the “Image format selection” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M02.03-C003 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Unsupported format variants are rejected before execution. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M02.03-C003-T01 · Named property:** Create a stable property/check name under this parent for “Image format selection”; copy its required invariant exactly: “Unsupported format variants are rejected before execution”.
- [ ] **UC-M02.03-C003-T02 · Observable terms:** Define each term in the “Image format selection” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M02.03-C003-T03 · Precondition set:** List the preconditions under which “Unsupported format variants are rejected before execution” must hold for “Image format selection”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M02.03-C003-T04 · Transition coverage:** Map the “Image format selection” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M02.03-C003-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Image format selection”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M02.03-C003-T06 · Satisfying fixture:** Create a concrete “Image format selection” case that satisfies “Unsupported format variants are rejected before execution”; record its expected observation before running the assertion or review.
- [ ] **UC-M02.03-C003-T07 · Violating fixture:** Create the source counterexample “An image uses an unimplemented optional header format” for “Image format selection”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M02.03-C003-T08 · Enforcement evidence:** Exercise the “Image format selection” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M02.03-C003-T09 · Regression linkage:** Link the “Image format selection” property to changes in the linker script, image validator and selected backend loader; record which dependency or contract changes require rerunning it.
- [ ] **UC-M02.03-C003-T10 · Property disposition:** Compare the satisfying and violating “Image format selection” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M02.03-C004 · Integration

**Original checklist item:** Integrate image format selection with the linker script, image validator and selected backend loader; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M02.03-C004-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Image format selection” across the linker script, image validator and selected backend loader; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M02.03-C004-T02 · Field mapping:** Map every “Image format selection” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M02.03-C004-T03 · Prerequisite identities:** Record the actual prerequisites for “Image format selection” (source dependency list: UC-M02.02); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M02.03-C004-T04 · Ownership agreement:** Specify who owns “Image format selection” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M02.03-C004-T05 · Handoff implementation:** Connect “Image format selection” through the mapped seam using the real adapter or explicit specification reference; preserve “Unsupported format variants are rejected before execution” across the handoff.
- [ ] **UC-M02.03-C004-T06 · Absent-input case:** Omit one required “Image format selection” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M02.03-C004-T07 · Stale-input case:** Supply an outdated “Image format selection” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M02.03-C004-T08 · Incompatible-input case:** Supply an incompatible “Image format selection” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M02.03-C004-T09 · Valid integration trace:** Run a valid “Image format selection” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M02.03-C004-T10 · Seam review:** Reconcile the “Image format selection” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M02.03-C005 · Valid-case test

**Original checklist item:** Run a valid-path fixture for image format selection; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M02.03-C005-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Image format selection” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M02.03-C005-T02 · Expected-result oracle:** Specify the “Image format selection” expected result independently of the implementation output; include the property “Unsupported format variants are rejected before execution” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M02.03-C005-T03 · Fixture material:** Create the concrete “Image format selection” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M02.03-C005-T04 · Target preparation:** Prepare the “Image format selection” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M02.03-C005-T05 · Initial-state record:** Record the initial “Image format selection” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M02.03-C005-T06 · Valid-path execution:** Execute the “Image format selection” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M02.03-C005-T07 · Outcome comparison:** Compare every declared “Image format selection” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M02.03-C005-T08 · State and bounds check:** Inspect the “Image format selection” ownership/state effects and actual use of “Header bytes and supported format variants”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M02.03-C005-T09 · Repeatability check:** Repeat the same “Image format selection” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M02.03-C005-T10 · Positive evidence:** Attach the “Image format selection” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M02.03-C006 · Negative test

**Original checklist item:** Negative case: An image uses an unimplemented optional header format. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M02.03-C006-T01 · Adverse-case definition:** Create a test record for the exact “Image format selection” source counterexample: “An image uses an unimplemented optional header format”; state which precondition or invariant it challenges.
- [ ] **UC-M02.03-C006-T02 · Safe fixture boundary:** Define the contained test boundary for “Image format selection”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M02.03-C006-T03 · Valid control:** Construct a valid “Image format selection” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M02.03-C006-T04 · Minimal adverse input:** Derive the “Image format selection” adverse fixture from the control with the smallest documented change needed to reproduce “An image uses an unimplemented optional header format”; retain that change as reproducible data.
- [ ] **UC-M02.03-C006-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Image format selection”; require “Unsupported format variants are rejected before execution” and forbid a false-success verdict.
- [ ] **UC-M02.03-C006-T06 · Adverse execution:** Exercise the “Image format selection” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M02.03-C006-T07 · Effect inspection:** Inspect “Image format selection” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M02.03-C006-T08 · Refusal versus failure:** Confirm the “Image format selection” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M02.03-C006-T09 · Reset and retention:** Restore only the disposable “Image format selection” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M02.03-C006-T10 · Negative regression:** Register the “Image format selection” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M02.03-C007 · Change / failure test

**Original checklist item:** Exercise image format selection when a layout or protection setting changes between image construction and loading; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M02.03-C007-T01 · Scenario record:** Write the “Image format selection” change/failure scenario exactly as supplied: a layout or protection setting changes between image construction and loading; identify the property that must remain true: “Unsupported format variants are rejected before execution”.
- [ ] **UC-M02.03-C007-T02 · Baseline capture:** Create a known-valid “Image format selection” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M02.03-C007-T03 · Injection map:** Locate the “Image format selection” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M02.03-C007-T04 · Disposition oracle:** Define the legal intermediate and final “Image format selection” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M02.03-C007-T05 · Controlled trigger:** Introduce the controlled “Image format selection” scenario in the disposable fixture: a layout or protection setting changes between image construction and loading; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M02.03-C007-T06 · Intermediate inspection:** Inspect the “Image format selection” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M02.03-C007-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Image format selection”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M02.03-C007-T08 · Stale-evidence cleanup:** Invalidate superseded “Image format selection” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M02.03-C007-T09 · Repeat and compare:** Repeat the selected “Image format selection” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M02.03-C007-T10 · Failure evidence:** Publish the “Image format selection” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M02.03-C008 · Bounds

**Original checklist item:** Choose, document and test limits for header bytes and supported format variants; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M02.03-C008-T01 · Quantity inventory:** Create a measurement inventory for “Image format selection”: “Header bytes and supported format variants”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M02.03-C008-T02 · Measurement method:** Choose how to observe each “Image format selection” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M02.03-C008-T03 · Budget decision:** Select justified resource and input limits for “Image format selection”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M02.03-C008-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Image format selection” cases for “Header bytes and supported format variants”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M02.03-C008-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Image format selection” limit; preserve “Unsupported format variants are rejected before execution”.
- [ ] **UC-M02.03-C008-T06 · Normal measurement:** Run or review the normal “Image format selection” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M02.03-C008-T07 · At-limit measurement:** Exercise the “Image format selection” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M02.03-C008-T08 · Over-limit measurement:** Exercise the “Image format selection” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M02.03-C008-T09 · Uncovered-scope report:** List the “Image format selection” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M02.03-C008-T10 · Limit evidence:** Publish the selected “Image format selection” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M02.03-C009 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for image format selection with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M02.03-C009-T01 · Event inventory:** List the “Image format selection” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M02.03-C009-T02 · Diagnostic schema:** Define nonsecret fields for “Image format selection” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M02.03-C009-T03 · Failure mapping:** Map each documented “Image format selection” refusal or error to a diagnostic outcome; include “An image uses an unimplemented optional header format” and prohibit conversion into a success message.
- [ ] **UC-M02.03-C009-T04 · Emission path:** Add the “Image format selection” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M02.03-C009-T05 · Redaction check:** Test “Image format selection” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M02.03-C009-T06 · Output budget:** Set and exercise bounded “Image format selection” message size, rate and retention compatible with “Header bytes and supported format variants”; define truncation behavior that preserves the final reason.
- [ ] **UC-M02.03-C009-T07 · Success/refusal fixtures:** Capture “Image format selection” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M02.03-C009-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Image format selection” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M02.03-C009-T09 · Operator review:** Read the “Image format selection” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M02.03-C009-T10 · Diagnostic evidence:** Publish redacted “Image format selection” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M02.03-C010 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for image format selection; label unexecuted checks as untested.

- [ ] **UC-M02.03-C010-T01 · Evidence inventory:** List the “Image format selection” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M02.03-C010-T02 · Artifact references:** Record the exact “Image format selection” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M02.03-C010-T03 · Fixture references:** Attach the “Image format selection” fixture IDs, input identities and oracle definition; preserve the source counterexample “An image uses an unimplemented optional header format” as a distinct evidence case.
- [ ] **UC-M02.03-C010-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Image format selection”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M02.03-C010-T05 · Environment record:** Record the actual “Image format selection” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M02.03-C010-T06 · Expected versus observed:** Pair every “Image format selection” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M02.03-C010-T07 · Failure and limit records:** Attach “Image format selection” change/failure and bounds evidence where required; include uncovered “Header bytes and supported format variants” and unresolved violations of “Unsupported format variants are rejected before execution”.
- [ ] **UC-M02.03-C010-T08 · Evidence hygiene:** Check the “Image format selection” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M02.03-C010-T09 · Reproduction review:** Have the “Image format selection” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M02.03-C010-T10 · Acceptance linkage:** Link the “Image format selection” evidence to its parent and UC-M02.03 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 02. Section layout

**Source delivery:** Define executable, read-only, writable and zero-initialized image sections.

**Source invariant:** Section placement follows the selected guest memory map.

**Source negative case:** Two loadable sections overlap in an unsupported way.

**Source bounded quantities:** Section count and total mapped bytes.

### UC-M02.03-C011 · Contract

**Original checklist item:** Specify section layout inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M02.03-C011-T01 · Scope statement:** Draft the operation boundary for “Section layout” within Linker, image layout and permissions; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M02.03-C011-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Section layout”; record each producer, representation and missing-value meaning.
- [ ] **UC-M02.03-C011-T03 · Output inventory:** List the outputs of “Section layout” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M02.03-C011-T04 · Field dictionary:** Create a field-and-term dictionary for “Section layout”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M02.03-C011-T05 · Prerequisite contract:** Map “Section layout” to the source component prerequisites (UC-M02.02); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M02.03-C011-T06 · Authority map:** Identify who may produce, change and consume “Section layout”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M02.03-C011-T07 · Invariant clause:** Add a normative clause for “Section layout” that preserves “Section placement follows the selected guest memory map”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M02.03-C011-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Section layout”; include the source counterexample “Two loadable sections overlap in an unsupported way” and the intended safe disposition.
- [ ] **UC-M02.03-C011-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Section count and total mapped bytes” in the “Section layout” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M02.03-C011-T10 · Contract review:** Review the “Section layout” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M02.03-C012 · Delivery

**Original checklist item:** Define executable, read-only, writable and zero-initialized image sections.

- [ ] **UC-M02.03-C012-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Section layout”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M02.03-C012-T02 · Change plan:** Break the source delivery for “Section layout” into concrete edit targets and reviewable outputs; keep the UC-M02.03 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M02.03-C012-T03 · Core artifact:** Create the “Section layout” model, schema or inventory that realizes this source instruction: Define executable, read-only, writable and zero-initialized image sections.
- [ ] **UC-M02.03-C012-T04 · Concrete realization:** Populate “Section layout” with one concrete worked case; map every required entity or field to its source and flag any unmapped entry.
- [ ] **UC-M02.03-C012-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Section layout” needed to preserve “Section placement follows the selected guest memory map”; record an enforcement gap where only a model exists.
- [ ] **UC-M02.03-C012-T06 · Dependency connection:** Connect the “Section layout” implementation to the linker script, image validator and selected backend loader; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M02.03-C012-T07 · Resource behavior:** Account for “Section count and total mapped bytes” in “Section layout”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M02.03-C012-T08 · Delivery check:** Run the smallest real “Section layout” path and its adverse fixture “Two loadable sections overlap in an unsupported way”; retain actual output, state effects and final disposition.
- [ ] **UC-M02.03-C012-T09 · Patch review:** Review the “Section layout” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M02.03-C012-T10 · Delivery handoff:** Publish the “Section layout” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M02.03-C013 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Section placement follows the selected guest memory map. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M02.03-C013-T01 · Named property:** Create a stable property/check name under this parent for “Section layout”; copy its required invariant exactly: “Section placement follows the selected guest memory map”.
- [ ] **UC-M02.03-C013-T02 · Observable terms:** Define each term in the “Section layout” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M02.03-C013-T03 · Precondition set:** List the preconditions under which “Section placement follows the selected guest memory map” must hold for “Section layout”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M02.03-C013-T04 · Transition coverage:** Map the “Section layout” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M02.03-C013-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Section layout”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M02.03-C013-T06 · Satisfying fixture:** Create a concrete “Section layout” case that satisfies “Section placement follows the selected guest memory map”; record its expected observation before running the assertion or review.
- [ ] **UC-M02.03-C013-T07 · Violating fixture:** Create the source counterexample “Two loadable sections overlap in an unsupported way” for “Section layout”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M02.03-C013-T08 · Enforcement evidence:** Exercise the “Section layout” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M02.03-C013-T09 · Regression linkage:** Link the “Section layout” property to changes in the linker script, image validator and selected backend loader; record which dependency or contract changes require rerunning it.
- [ ] **UC-M02.03-C013-T10 · Property disposition:** Compare the satisfying and violating “Section layout” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M02.03-C014 · Integration

**Original checklist item:** Integrate section layout with the linker script, image validator and selected backend loader; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M02.03-C014-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Section layout” across the linker script, image validator and selected backend loader; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M02.03-C014-T02 · Field mapping:** Map every “Section layout” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M02.03-C014-T03 · Prerequisite identities:** Record the actual prerequisites for “Section layout” (source dependency list: UC-M02.02); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M02.03-C014-T04 · Ownership agreement:** Specify who owns “Section layout” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M02.03-C014-T05 · Handoff implementation:** Connect “Section layout” through the mapped seam using the real adapter or explicit specification reference; preserve “Section placement follows the selected guest memory map” across the handoff.
- [ ] **UC-M02.03-C014-T06 · Absent-input case:** Omit one required “Section layout” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M02.03-C014-T07 · Stale-input case:** Supply an outdated “Section layout” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M02.03-C014-T08 · Incompatible-input case:** Supply an incompatible “Section layout” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M02.03-C014-T09 · Valid integration trace:** Run a valid “Section layout” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M02.03-C014-T10 · Seam review:** Reconcile the “Section layout” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M02.03-C015 · Valid-case test

**Original checklist item:** Run a valid-path fixture for section layout; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M02.03-C015-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Section layout” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M02.03-C015-T02 · Expected-result oracle:** Specify the “Section layout” expected result independently of the implementation output; include the property “Section placement follows the selected guest memory map” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M02.03-C015-T03 · Fixture material:** Create the concrete “Section layout” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M02.03-C015-T04 · Target preparation:** Prepare the “Section layout” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M02.03-C015-T05 · Initial-state record:** Record the initial “Section layout” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M02.03-C015-T06 · Valid-path execution:** Execute the “Section layout” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M02.03-C015-T07 · Outcome comparison:** Compare every declared “Section layout” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M02.03-C015-T08 · State and bounds check:** Inspect the “Section layout” ownership/state effects and actual use of “Section count and total mapped bytes”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M02.03-C015-T09 · Repeatability check:** Repeat the same “Section layout” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M02.03-C015-T10 · Positive evidence:** Attach the “Section layout” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M02.03-C016 · Negative test

**Original checklist item:** Negative case: Two loadable sections overlap in an unsupported way. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M02.03-C016-T01 · Adverse-case definition:** Create a test record for the exact “Section layout” source counterexample: “Two loadable sections overlap in an unsupported way”; state which precondition or invariant it challenges.
- [ ] **UC-M02.03-C016-T02 · Safe fixture boundary:** Define the contained test boundary for “Section layout”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M02.03-C016-T03 · Valid control:** Construct a valid “Section layout” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M02.03-C016-T04 · Minimal adverse input:** Derive the “Section layout” adverse fixture from the control with the smallest documented change needed to reproduce “Two loadable sections overlap in an unsupported way”; retain that change as reproducible data.
- [ ] **UC-M02.03-C016-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Section layout”; require “Section placement follows the selected guest memory map” and forbid a false-success verdict.
- [ ] **UC-M02.03-C016-T06 · Adverse execution:** Exercise the “Section layout” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M02.03-C016-T07 · Effect inspection:** Inspect “Section layout” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M02.03-C016-T08 · Refusal versus failure:** Confirm the “Section layout” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M02.03-C016-T09 · Reset and retention:** Restore only the disposable “Section layout” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M02.03-C016-T10 · Negative regression:** Register the “Section layout” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M02.03-C017 · Change / failure test

**Original checklist item:** Exercise section layout when a layout or protection setting changes between image construction and loading; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M02.03-C017-T01 · Scenario record:** Write the “Section layout” change/failure scenario exactly as supplied: a layout or protection setting changes between image construction and loading; identify the property that must remain true: “Section placement follows the selected guest memory map”.
- [ ] **UC-M02.03-C017-T02 · Baseline capture:** Create a known-valid “Section layout” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M02.03-C017-T03 · Injection map:** Locate the “Section layout” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M02.03-C017-T04 · Disposition oracle:** Define the legal intermediate and final “Section layout” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M02.03-C017-T05 · Controlled trigger:** Introduce the controlled “Section layout” scenario in the disposable fixture: a layout or protection setting changes between image construction and loading; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M02.03-C017-T06 · Intermediate inspection:** Inspect the “Section layout” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M02.03-C017-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Section layout”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M02.03-C017-T08 · Stale-evidence cleanup:** Invalidate superseded “Section layout” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M02.03-C017-T09 · Repeat and compare:** Repeat the selected “Section layout” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M02.03-C017-T10 · Failure evidence:** Publish the “Section layout” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M02.03-C018 · Bounds

**Original checklist item:** Choose, document and test limits for section count and total mapped bytes; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M02.03-C018-T01 · Quantity inventory:** Create a measurement inventory for “Section layout”: “Section count and total mapped bytes”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M02.03-C018-T02 · Measurement method:** Choose how to observe each “Section layout” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M02.03-C018-T03 · Budget decision:** Select justified resource and input limits for “Section layout”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M02.03-C018-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Section layout” cases for “Section count and total mapped bytes”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M02.03-C018-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Section layout” limit; preserve “Section placement follows the selected guest memory map”.
- [ ] **UC-M02.03-C018-T06 · Normal measurement:** Run or review the normal “Section layout” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M02.03-C018-T07 · At-limit measurement:** Exercise the “Section layout” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M02.03-C018-T08 · Over-limit measurement:** Exercise the “Section layout” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M02.03-C018-T09 · Uncovered-scope report:** List the “Section layout” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M02.03-C018-T10 · Limit evidence:** Publish the selected “Section layout” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M02.03-C019 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for section layout with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M02.03-C019-T01 · Event inventory:** List the “Section layout” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M02.03-C019-T02 · Diagnostic schema:** Define nonsecret fields for “Section layout” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M02.03-C019-T03 · Failure mapping:** Map each documented “Section layout” refusal or error to a diagnostic outcome; include “Two loadable sections overlap in an unsupported way” and prohibit conversion into a success message.
- [ ] **UC-M02.03-C019-T04 · Emission path:** Add the “Section layout” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M02.03-C019-T05 · Redaction check:** Test “Section layout” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M02.03-C019-T06 · Output budget:** Set and exercise bounded “Section layout” message size, rate and retention compatible with “Section count and total mapped bytes”; define truncation behavior that preserves the final reason.
- [ ] **UC-M02.03-C019-T07 · Success/refusal fixtures:** Capture “Section layout” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M02.03-C019-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Section layout” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M02.03-C019-T09 · Operator review:** Read the “Section layout” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M02.03-C019-T10 · Diagnostic evidence:** Publish redacted “Section layout” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M02.03-C020 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for section layout; label unexecuted checks as untested.

- [ ] **UC-M02.03-C020-T01 · Evidence inventory:** List the “Section layout” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M02.03-C020-T02 · Artifact references:** Record the exact “Section layout” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M02.03-C020-T03 · Fixture references:** Attach the “Section layout” fixture IDs, input identities and oracle definition; preserve the source counterexample “Two loadable sections overlap in an unsupported way” as a distinct evidence case.
- [ ] **UC-M02.03-C020-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Section layout”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M02.03-C020-T05 · Environment record:** Record the actual “Section layout” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M02.03-C020-T06 · Expected versus observed:** Pair every “Section layout” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M02.03-C020-T07 · Failure and limit records:** Attach “Section layout” change/failure and bounds evidence where required; include uncovered “Section count and total mapped bytes” and unresolved violations of “Section placement follows the selected guest memory map”.
- [ ] **UC-M02.03-C020-T08 · Evidence hygiene:** Check the “Section layout” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M02.03-C020-T09 · Reproduction review:** Have the “Section layout” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M02.03-C020-T10 · Acceptance linkage:** Link the “Section layout” evidence to its parent and UC-M02.03 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 03. Entry and segment validation

**Source delivery:** Validate entry points, segment offsets, sizes and alignments.

**Source invariant:** Image references stay within their declared file and memory bounds.

**Source negative case:** A segment size overflows its end-address calculation.

**Source bounded quantities:** Segment count and arithmetic widths.

### UC-M02.03-C021 · Contract

**Original checklist item:** Specify entry and segment validation inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M02.03-C021-T01 · Scope statement:** Draft the operation boundary for “Entry and segment validation” within Linker, image layout and permissions; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M02.03-C021-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Entry and segment validation”; record each producer, representation and missing-value meaning.
- [ ] **UC-M02.03-C021-T03 · Output inventory:** List the outputs of “Entry and segment validation” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M02.03-C021-T04 · Field dictionary:** Create a field-and-term dictionary for “Entry and segment validation”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M02.03-C021-T05 · Prerequisite contract:** Map “Entry and segment validation” to the source component prerequisites (UC-M02.02); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M02.03-C021-T06 · Authority map:** Identify who may produce, change and consume “Entry and segment validation”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M02.03-C021-T07 · Invariant clause:** Add a normative clause for “Entry and segment validation” that preserves “Image references stay within their declared file and memory bounds”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M02.03-C021-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Entry and segment validation”; include the source counterexample “A segment size overflows its end-address calculation” and the intended safe disposition.
- [ ] **UC-M02.03-C021-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Segment count and arithmetic widths” in the “Entry and segment validation” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M02.03-C021-T10 · Contract review:** Review the “Entry and segment validation” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M02.03-C022 · Delivery

**Original checklist item:** Validate entry points, segment offsets, sizes and alignments.

- [ ] **UC-M02.03-C022-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Entry and segment validation”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M02.03-C022-T02 · Change plan:** Break the source delivery for “Entry and segment validation” into concrete edit targets and reviewable outputs; keep the UC-M02.03 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M02.03-C022-T03 · Core artifact:** Implement the smallest selected-profile change for “Entry and segment validation” that realizes this source instruction: Validate entry points, segment offsets, sizes and alignments.
- [ ] **UC-M02.03-C022-T04 · Concrete realization:** Trace “Entry and segment validation” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M02.03-C022-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Entry and segment validation” needed to preserve “Image references stay within their declared file and memory bounds”; record an enforcement gap where only a model exists.
- [ ] **UC-M02.03-C022-T06 · Dependency connection:** Connect the “Entry and segment validation” implementation to the linker script, image validator and selected backend loader; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M02.03-C022-T07 · Resource behavior:** Account for “Segment count and arithmetic widths” in “Entry and segment validation”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M02.03-C022-T08 · Delivery check:** Run the smallest real “Entry and segment validation” path and its adverse fixture “A segment size overflows its end-address calculation”; retain actual output, state effects and final disposition.
- [ ] **UC-M02.03-C022-T09 · Patch review:** Review the “Entry and segment validation” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M02.03-C022-T10 · Delivery handoff:** Publish the “Entry and segment validation” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M02.03-C023 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Image references stay within their declared file and memory bounds. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M02.03-C023-T01 · Named property:** Create a stable property/check name under this parent for “Entry and segment validation”; copy its required invariant exactly: “Image references stay within their declared file and memory bounds”.
- [ ] **UC-M02.03-C023-T02 · Observable terms:** Define each term in the “Entry and segment validation” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M02.03-C023-T03 · Precondition set:** List the preconditions under which “Image references stay within their declared file and memory bounds” must hold for “Entry and segment validation”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M02.03-C023-T04 · Transition coverage:** Map the “Entry and segment validation” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M02.03-C023-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Entry and segment validation”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M02.03-C023-T06 · Satisfying fixture:** Create a concrete “Entry and segment validation” case that satisfies “Image references stay within their declared file and memory bounds”; record its expected observation before running the assertion or review.
- [ ] **UC-M02.03-C023-T07 · Violating fixture:** Create the source counterexample “A segment size overflows its end-address calculation” for “Entry and segment validation”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M02.03-C023-T08 · Enforcement evidence:** Exercise the “Entry and segment validation” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M02.03-C023-T09 · Regression linkage:** Link the “Entry and segment validation” property to changes in the linker script, image validator and selected backend loader; record which dependency or contract changes require rerunning it.
- [ ] **UC-M02.03-C023-T10 · Property disposition:** Compare the satisfying and violating “Entry and segment validation” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M02.03-C024 · Integration

**Original checklist item:** Integrate entry and segment validation with the linker script, image validator and selected backend loader; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M02.03-C024-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Entry and segment validation” across the linker script, image validator and selected backend loader; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M02.03-C024-T02 · Field mapping:** Map every “Entry and segment validation” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M02.03-C024-T03 · Prerequisite identities:** Record the actual prerequisites for “Entry and segment validation” (source dependency list: UC-M02.02); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M02.03-C024-T04 · Ownership agreement:** Specify who owns “Entry and segment validation” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M02.03-C024-T05 · Handoff implementation:** Connect “Entry and segment validation” through the mapped seam using the real adapter or explicit specification reference; preserve “Image references stay within their declared file and memory bounds” across the handoff.
- [ ] **UC-M02.03-C024-T06 · Absent-input case:** Omit one required “Entry and segment validation” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M02.03-C024-T07 · Stale-input case:** Supply an outdated “Entry and segment validation” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M02.03-C024-T08 · Incompatible-input case:** Supply an incompatible “Entry and segment validation” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M02.03-C024-T09 · Valid integration trace:** Run a valid “Entry and segment validation” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M02.03-C024-T10 · Seam review:** Reconcile the “Entry and segment validation” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M02.03-C025 · Valid-case test

**Original checklist item:** Run a valid-path fixture for entry and segment validation; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M02.03-C025-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Entry and segment validation” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M02.03-C025-T02 · Expected-result oracle:** Specify the “Entry and segment validation” expected result independently of the implementation output; include the property “Image references stay within their declared file and memory bounds” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M02.03-C025-T03 · Fixture material:** Create the concrete “Entry and segment validation” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M02.03-C025-T04 · Target preparation:** Prepare the “Entry and segment validation” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M02.03-C025-T05 · Initial-state record:** Record the initial “Entry and segment validation” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M02.03-C025-T06 · Valid-path execution:** Execute the “Entry and segment validation” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M02.03-C025-T07 · Outcome comparison:** Compare every declared “Entry and segment validation” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M02.03-C025-T08 · State and bounds check:** Inspect the “Entry and segment validation” ownership/state effects and actual use of “Segment count and arithmetic widths”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M02.03-C025-T09 · Repeatability check:** Repeat the same “Entry and segment validation” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M02.03-C025-T10 · Positive evidence:** Attach the “Entry and segment validation” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M02.03-C026 · Negative test

**Original checklist item:** Negative case: A segment size overflows its end-address calculation. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M02.03-C026-T01 · Adverse-case definition:** Create a test record for the exact “Entry and segment validation” source counterexample: “A segment size overflows its end-address calculation”; state which precondition or invariant it challenges.
- [ ] **UC-M02.03-C026-T02 · Safe fixture boundary:** Define the contained test boundary for “Entry and segment validation”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M02.03-C026-T03 · Valid control:** Construct a valid “Entry and segment validation” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M02.03-C026-T04 · Minimal adverse input:** Derive the “Entry and segment validation” adverse fixture from the control with the smallest documented change needed to reproduce “A segment size overflows its end-address calculation”; retain that change as reproducible data.
- [ ] **UC-M02.03-C026-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Entry and segment validation”; require “Image references stay within their declared file and memory bounds” and forbid a false-success verdict.
- [ ] **UC-M02.03-C026-T06 · Adverse execution:** Exercise the “Entry and segment validation” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M02.03-C026-T07 · Effect inspection:** Inspect “Entry and segment validation” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M02.03-C026-T08 · Refusal versus failure:** Confirm the “Entry and segment validation” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M02.03-C026-T09 · Reset and retention:** Restore only the disposable “Entry and segment validation” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M02.03-C026-T10 · Negative regression:** Register the “Entry and segment validation” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M02.03-C027 · Change / failure test

**Original checklist item:** Exercise entry and segment validation when a layout or protection setting changes between image construction and loading; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M02.03-C027-T01 · Scenario record:** Write the “Entry and segment validation” change/failure scenario exactly as supplied: a layout or protection setting changes between image construction and loading; identify the property that must remain true: “Image references stay within their declared file and memory bounds”.
- [ ] **UC-M02.03-C027-T02 · Baseline capture:** Create a known-valid “Entry and segment validation” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M02.03-C027-T03 · Injection map:** Locate the “Entry and segment validation” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M02.03-C027-T04 · Disposition oracle:** Define the legal intermediate and final “Entry and segment validation” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M02.03-C027-T05 · Controlled trigger:** Introduce the controlled “Entry and segment validation” scenario in the disposable fixture: a layout or protection setting changes between image construction and loading; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M02.03-C027-T06 · Intermediate inspection:** Inspect the “Entry and segment validation” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M02.03-C027-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Entry and segment validation”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M02.03-C027-T08 · Stale-evidence cleanup:** Invalidate superseded “Entry and segment validation” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M02.03-C027-T09 · Repeat and compare:** Repeat the selected “Entry and segment validation” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M02.03-C027-T10 · Failure evidence:** Publish the “Entry and segment validation” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M02.03-C028 · Bounds

**Original checklist item:** Choose, document and test limits for segment count and arithmetic widths; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M02.03-C028-T01 · Quantity inventory:** Create a measurement inventory for “Entry and segment validation”: “Segment count and arithmetic widths”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M02.03-C028-T02 · Measurement method:** Choose how to observe each “Entry and segment validation” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M02.03-C028-T03 · Budget decision:** Select justified resource and input limits for “Entry and segment validation”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M02.03-C028-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Entry and segment validation” cases for “Segment count and arithmetic widths”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M02.03-C028-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Entry and segment validation” limit; preserve “Image references stay within their declared file and memory bounds”.
- [ ] **UC-M02.03-C028-T06 · Normal measurement:** Run or review the normal “Entry and segment validation” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M02.03-C028-T07 · At-limit measurement:** Exercise the “Entry and segment validation” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M02.03-C028-T08 · Over-limit measurement:** Exercise the “Entry and segment validation” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M02.03-C028-T09 · Uncovered-scope report:** List the “Entry and segment validation” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M02.03-C028-T10 · Limit evidence:** Publish the selected “Entry and segment validation” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M02.03-C029 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for entry and segment validation with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M02.03-C029-T01 · Event inventory:** List the “Entry and segment validation” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M02.03-C029-T02 · Diagnostic schema:** Define nonsecret fields for “Entry and segment validation” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M02.03-C029-T03 · Failure mapping:** Map each documented “Entry and segment validation” refusal or error to a diagnostic outcome; include “A segment size overflows its end-address calculation” and prohibit conversion into a success message.
- [ ] **UC-M02.03-C029-T04 · Emission path:** Add the “Entry and segment validation” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M02.03-C029-T05 · Redaction check:** Test “Entry and segment validation” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M02.03-C029-T06 · Output budget:** Set and exercise bounded “Entry and segment validation” message size, rate and retention compatible with “Segment count and arithmetic widths”; define truncation behavior that preserves the final reason.
- [ ] **UC-M02.03-C029-T07 · Success/refusal fixtures:** Capture “Entry and segment validation” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M02.03-C029-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Entry and segment validation” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M02.03-C029-T09 · Operator review:** Read the “Entry and segment validation” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M02.03-C029-T10 · Diagnostic evidence:** Publish redacted “Entry and segment validation” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M02.03-C030 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for entry and segment validation; label unexecuted checks as untested.

- [ ] **UC-M02.03-C030-T01 · Evidence inventory:** List the “Entry and segment validation” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M02.03-C030-T02 · Artifact references:** Record the exact “Entry and segment validation” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M02.03-C030-T03 · Fixture references:** Attach the “Entry and segment validation” fixture IDs, input identities and oracle definition; preserve the source counterexample “A segment size overflows its end-address calculation” as a distinct evidence case.
- [ ] **UC-M02.03-C030-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Entry and segment validation”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M02.03-C030-T05 · Environment record:** Record the actual “Entry and segment validation” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M02.03-C030-T06 · Expected versus observed:** Pair every “Entry and segment validation” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M02.03-C030-T07 · Failure and limit records:** Attach “Entry and segment validation” change/failure and bounds evidence where required; include uncovered “Segment count and arithmetic widths” and unresolved violations of “Image references stay within their declared file and memory bounds”.
- [ ] **UC-M02.03-C030-T08 · Evidence hygiene:** Check the “Entry and segment validation” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M02.03-C030-T09 · Reproduction review:** Have the “Entry and segment validation” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M02.03-C030-T10 · Acceptance linkage:** Link the “Entry and segment validation” evidence to its parent and UC-M02.03 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 04. Relocation handling

**Source delivery:** Specify supported relocation types and validate each relocation target.

**Source invariant:** Relocations cannot write outside their authorized target regions.

**Source negative case:** A relocation targets protected or unmapped guest memory.

**Source bounded quantities:** Relocation count and relocation processing time.

### UC-M02.03-C031 · Contract

**Original checklist item:** Specify relocation handling inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M02.03-C031-T01 · Scope statement:** Draft the operation boundary for “Relocation handling” within Linker, image layout and permissions; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M02.03-C031-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Relocation handling”; record each producer, representation and missing-value meaning.
- [ ] **UC-M02.03-C031-T03 · Output inventory:** List the outputs of “Relocation handling” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M02.03-C031-T04 · Field dictionary:** Create a field-and-term dictionary for “Relocation handling”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M02.03-C031-T05 · Prerequisite contract:** Map “Relocation handling” to the source component prerequisites (UC-M02.02); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M02.03-C031-T06 · Authority map:** Identify who may produce, change and consume “Relocation handling”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M02.03-C031-T07 · Invariant clause:** Add a normative clause for “Relocation handling” that preserves “Relocations cannot write outside their authorized target regions”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M02.03-C031-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Relocation handling”; include the source counterexample “A relocation targets protected or unmapped guest memory” and the intended safe disposition.
- [ ] **UC-M02.03-C031-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Relocation count and relocation processing time” in the “Relocation handling” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M02.03-C031-T10 · Contract review:** Review the “Relocation handling” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M02.03-C032 · Delivery

**Original checklist item:** Specify supported relocation types and validate each relocation target.

- [ ] **UC-M02.03-C032-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Relocation handling”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M02.03-C032-T02 · Change plan:** Break the source delivery for “Relocation handling” into concrete edit targets and reviewable outputs; keep the UC-M02.03 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M02.03-C032-T03 · Core artifact:** Create the “Relocation handling” model, schema or inventory that realizes this source instruction: Specify supported relocation types and validate each relocation target.
- [ ] **UC-M02.03-C032-T04 · Concrete realization:** Populate “Relocation handling” with one concrete worked case; map every required entity or field to its source and flag any unmapped entry.
- [ ] **UC-M02.03-C032-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Relocation handling” needed to preserve “Relocations cannot write outside their authorized target regions”; record an enforcement gap where only a model exists.
- [ ] **UC-M02.03-C032-T06 · Dependency connection:** Connect the “Relocation handling” implementation to the linker script, image validator and selected backend loader; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M02.03-C032-T07 · Resource behavior:** Account for “Relocation count and relocation processing time” in “Relocation handling”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M02.03-C032-T08 · Delivery check:** Run the smallest real “Relocation handling” path and its adverse fixture “A relocation targets protected or unmapped guest memory”; retain actual output, state effects and final disposition.
- [ ] **UC-M02.03-C032-T09 · Patch review:** Review the “Relocation handling” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M02.03-C032-T10 · Delivery handoff:** Publish the “Relocation handling” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M02.03-C033 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Relocations cannot write outside their authorized target regions. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M02.03-C033-T01 · Named property:** Create a stable property/check name under this parent for “Relocation handling”; copy its required invariant exactly: “Relocations cannot write outside their authorized target regions”.
- [ ] **UC-M02.03-C033-T02 · Observable terms:** Define each term in the “Relocation handling” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M02.03-C033-T03 · Precondition set:** List the preconditions under which “Relocations cannot write outside their authorized target regions” must hold for “Relocation handling”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M02.03-C033-T04 · Transition coverage:** Map the “Relocation handling” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M02.03-C033-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Relocation handling”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M02.03-C033-T06 · Satisfying fixture:** Create a concrete “Relocation handling” case that satisfies “Relocations cannot write outside their authorized target regions”; record its expected observation before running the assertion or review.
- [ ] **UC-M02.03-C033-T07 · Violating fixture:** Create the source counterexample “A relocation targets protected or unmapped guest memory” for “Relocation handling”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M02.03-C033-T08 · Enforcement evidence:** Exercise the “Relocation handling” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M02.03-C033-T09 · Regression linkage:** Link the “Relocation handling” property to changes in the linker script, image validator and selected backend loader; record which dependency or contract changes require rerunning it.
- [ ] **UC-M02.03-C033-T10 · Property disposition:** Compare the satisfying and violating “Relocation handling” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M02.03-C034 · Integration

**Original checklist item:** Integrate relocation handling with the linker script, image validator and selected backend loader; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M02.03-C034-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Relocation handling” across the linker script, image validator and selected backend loader; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M02.03-C034-T02 · Field mapping:** Map every “Relocation handling” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M02.03-C034-T03 · Prerequisite identities:** Record the actual prerequisites for “Relocation handling” (source dependency list: UC-M02.02); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M02.03-C034-T04 · Ownership agreement:** Specify who owns “Relocation handling” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M02.03-C034-T05 · Handoff implementation:** Connect “Relocation handling” through the mapped seam using the real adapter or explicit specification reference; preserve “Relocations cannot write outside their authorized target regions” across the handoff.
- [ ] **UC-M02.03-C034-T06 · Absent-input case:** Omit one required “Relocation handling” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M02.03-C034-T07 · Stale-input case:** Supply an outdated “Relocation handling” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M02.03-C034-T08 · Incompatible-input case:** Supply an incompatible “Relocation handling” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M02.03-C034-T09 · Valid integration trace:** Run a valid “Relocation handling” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M02.03-C034-T10 · Seam review:** Reconcile the “Relocation handling” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M02.03-C035 · Valid-case test

**Original checklist item:** Run a valid-path fixture for relocation handling; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M02.03-C035-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Relocation handling” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M02.03-C035-T02 · Expected-result oracle:** Specify the “Relocation handling” expected result independently of the implementation output; include the property “Relocations cannot write outside their authorized target regions” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M02.03-C035-T03 · Fixture material:** Create the concrete “Relocation handling” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M02.03-C035-T04 · Target preparation:** Prepare the “Relocation handling” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M02.03-C035-T05 · Initial-state record:** Record the initial “Relocation handling” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M02.03-C035-T06 · Valid-path execution:** Execute the “Relocation handling” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M02.03-C035-T07 · Outcome comparison:** Compare every declared “Relocation handling” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M02.03-C035-T08 · State and bounds check:** Inspect the “Relocation handling” ownership/state effects and actual use of “Relocation count and relocation processing time”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M02.03-C035-T09 · Repeatability check:** Repeat the same “Relocation handling” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M02.03-C035-T10 · Positive evidence:** Attach the “Relocation handling” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M02.03-C036 · Negative test

**Original checklist item:** Negative case: A relocation targets protected or unmapped guest memory. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M02.03-C036-T01 · Adverse-case definition:** Create a test record for the exact “Relocation handling” source counterexample: “A relocation targets protected or unmapped guest memory”; state which precondition or invariant it challenges.
- [ ] **UC-M02.03-C036-T02 · Safe fixture boundary:** Define the contained test boundary for “Relocation handling”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M02.03-C036-T03 · Valid control:** Construct a valid “Relocation handling” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M02.03-C036-T04 · Minimal adverse input:** Derive the “Relocation handling” adverse fixture from the control with the smallest documented change needed to reproduce “A relocation targets protected or unmapped guest memory”; retain that change as reproducible data.
- [ ] **UC-M02.03-C036-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Relocation handling”; require “Relocations cannot write outside their authorized target regions” and forbid a false-success verdict.
- [ ] **UC-M02.03-C036-T06 · Adverse execution:** Exercise the “Relocation handling” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M02.03-C036-T07 · Effect inspection:** Inspect “Relocation handling” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M02.03-C036-T08 · Refusal versus failure:** Confirm the “Relocation handling” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M02.03-C036-T09 · Reset and retention:** Restore only the disposable “Relocation handling” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M02.03-C036-T10 · Negative regression:** Register the “Relocation handling” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M02.03-C037 · Change / failure test

**Original checklist item:** Exercise relocation handling when a layout or protection setting changes between image construction and loading; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M02.03-C037-T01 · Scenario record:** Write the “Relocation handling” change/failure scenario exactly as supplied: a layout or protection setting changes between image construction and loading; identify the property that must remain true: “Relocations cannot write outside their authorized target regions”.
- [ ] **UC-M02.03-C037-T02 · Baseline capture:** Create a known-valid “Relocation handling” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M02.03-C037-T03 · Injection map:** Locate the “Relocation handling” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M02.03-C037-T04 · Disposition oracle:** Define the legal intermediate and final “Relocation handling” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M02.03-C037-T05 · Controlled trigger:** Introduce the controlled “Relocation handling” scenario in the disposable fixture: a layout or protection setting changes between image construction and loading; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M02.03-C037-T06 · Intermediate inspection:** Inspect the “Relocation handling” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M02.03-C037-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Relocation handling”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M02.03-C037-T08 · Stale-evidence cleanup:** Invalidate superseded “Relocation handling” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M02.03-C037-T09 · Repeat and compare:** Repeat the selected “Relocation handling” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M02.03-C037-T10 · Failure evidence:** Publish the “Relocation handling” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M02.03-C038 · Bounds

**Original checklist item:** Choose, document and test limits for relocation count and relocation processing time; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M02.03-C038-T01 · Quantity inventory:** Create a measurement inventory for “Relocation handling”: “Relocation count and relocation processing time”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M02.03-C038-T02 · Measurement method:** Choose how to observe each “Relocation handling” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M02.03-C038-T03 · Budget decision:** Select justified resource and input limits for “Relocation handling”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M02.03-C038-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Relocation handling” cases for “Relocation count and relocation processing time”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M02.03-C038-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Relocation handling” limit; preserve “Relocations cannot write outside their authorized target regions”.
- [ ] **UC-M02.03-C038-T06 · Normal measurement:** Run or review the normal “Relocation handling” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M02.03-C038-T07 · At-limit measurement:** Exercise the “Relocation handling” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M02.03-C038-T08 · Over-limit measurement:** Exercise the “Relocation handling” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M02.03-C038-T09 · Uncovered-scope report:** List the “Relocation handling” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M02.03-C038-T10 · Limit evidence:** Publish the selected “Relocation handling” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M02.03-C039 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for relocation handling with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M02.03-C039-T01 · Event inventory:** List the “Relocation handling” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M02.03-C039-T02 · Diagnostic schema:** Define nonsecret fields for “Relocation handling” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M02.03-C039-T03 · Failure mapping:** Map each documented “Relocation handling” refusal or error to a diagnostic outcome; include “A relocation targets protected or unmapped guest memory” and prohibit conversion into a success message.
- [ ] **UC-M02.03-C039-T04 · Emission path:** Add the “Relocation handling” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M02.03-C039-T05 · Redaction check:** Test “Relocation handling” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M02.03-C039-T06 · Output budget:** Set and exercise bounded “Relocation handling” message size, rate and retention compatible with “Relocation count and relocation processing time”; define truncation behavior that preserves the final reason.
- [ ] **UC-M02.03-C039-T07 · Success/refusal fixtures:** Capture “Relocation handling” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M02.03-C039-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Relocation handling” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M02.03-C039-T09 · Operator review:** Read the “Relocation handling” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M02.03-C039-T10 · Diagnostic evidence:** Publish redacted “Relocation handling” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M02.03-C040 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for relocation handling; label unexecuted checks as untested.

- [ ] **UC-M02.03-C040-T01 · Evidence inventory:** List the “Relocation handling” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M02.03-C040-T02 · Artifact references:** Record the exact “Relocation handling” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M02.03-C040-T03 · Fixture references:** Attach the “Relocation handling” fixture IDs, input identities and oracle definition; preserve the source counterexample “A relocation targets protected or unmapped guest memory” as a distinct evidence case.
- [ ] **UC-M02.03-C040-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Relocation handling”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M02.03-C040-T05 · Environment record:** Record the actual “Relocation handling” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M02.03-C040-T06 · Expected versus observed:** Pair every “Relocation handling” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M02.03-C040-T07 · Failure and limit records:** Attach “Relocation handling” change/failure and bounds evidence where required; include uncovered “Relocation count and relocation processing time” and unresolved violations of “Relocations cannot write outside their authorized target regions”.
- [ ] **UC-M02.03-C040-T08 · Evidence hygiene:** Check the “Relocation handling” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M02.03-C040-T09 · Reproduction review:** Have the “Relocation handling” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M02.03-C040-T10 · Acceptance linkage:** Link the “Relocation handling” evidence to its parent and UC-M02.03 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 05. Address-space map

**Source delivery:** Construct a non-ambiguous map for image, stack, heap and device regions.

**Source invariant:** Guest memory regions have documented nonconflicting ownership.

**Source negative case:** A device mapping overlaps the heap.

**Source bounded quantities:** Mapped region count and address-space size.

### UC-M02.03-C041 · Contract

**Original checklist item:** Specify address-space map inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M02.03-C041-T01 · Scope statement:** Draft the operation boundary for “Address-space map” within Linker, image layout and permissions; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M02.03-C041-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Address-space map”; record each producer, representation and missing-value meaning.
- [ ] **UC-M02.03-C041-T03 · Output inventory:** List the outputs of “Address-space map” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M02.03-C041-T04 · Field dictionary:** Create a field-and-term dictionary for “Address-space map”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M02.03-C041-T05 · Prerequisite contract:** Map “Address-space map” to the source component prerequisites (UC-M02.02); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M02.03-C041-T06 · Authority map:** Identify who may produce, change and consume “Address-space map”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M02.03-C041-T07 · Invariant clause:** Add a normative clause for “Address-space map” that preserves “Guest memory regions have documented nonconflicting ownership”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M02.03-C041-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Address-space map”; include the source counterexample “A device mapping overlaps the heap” and the intended safe disposition.
- [ ] **UC-M02.03-C041-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Mapped region count and address-space size” in the “Address-space map” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M02.03-C041-T10 · Contract review:** Review the “Address-space map” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M02.03-C042 · Delivery

**Original checklist item:** Construct a non-ambiguous map for image, stack, heap and device regions.

- [ ] **UC-M02.03-C042-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Address-space map”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M02.03-C042-T02 · Change plan:** Break the source delivery for “Address-space map” into concrete edit targets and reviewable outputs; keep the UC-M02.03 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M02.03-C042-T03 · Core artifact:** Implement the smallest selected-profile change for “Address-space map” that realizes this source instruction: Construct a non-ambiguous map for image, stack, heap and device regions.
- [ ] **UC-M02.03-C042-T04 · Concrete realization:** Trace “Address-space map” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M02.03-C042-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Address-space map” needed to preserve “Guest memory regions have documented nonconflicting ownership”; record an enforcement gap where only a model exists.
- [ ] **UC-M02.03-C042-T06 · Dependency connection:** Connect the “Address-space map” implementation to the linker script, image validator and selected backend loader; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M02.03-C042-T07 · Resource behavior:** Account for “Mapped region count and address-space size” in “Address-space map”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M02.03-C042-T08 · Delivery check:** Run the smallest real “Address-space map” path and its adverse fixture “A device mapping overlaps the heap”; retain actual output, state effects and final disposition.
- [ ] **UC-M02.03-C042-T09 · Patch review:** Review the “Address-space map” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M02.03-C042-T10 · Delivery handoff:** Publish the “Address-space map” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M02.03-C043 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Guest memory regions have documented nonconflicting ownership. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M02.03-C043-T01 · Named property:** Create a stable property/check name under this parent for “Address-space map”; copy its required invariant exactly: “Guest memory regions have documented nonconflicting ownership”.
- [ ] **UC-M02.03-C043-T02 · Observable terms:** Define each term in the “Address-space map” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M02.03-C043-T03 · Precondition set:** List the preconditions under which “Guest memory regions have documented nonconflicting ownership” must hold for “Address-space map”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M02.03-C043-T04 · Transition coverage:** Map the “Address-space map” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M02.03-C043-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Address-space map”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M02.03-C043-T06 · Satisfying fixture:** Create a concrete “Address-space map” case that satisfies “Guest memory regions have documented nonconflicting ownership”; record its expected observation before running the assertion or review.
- [ ] **UC-M02.03-C043-T07 · Violating fixture:** Create the source counterexample “A device mapping overlaps the heap” for “Address-space map”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M02.03-C043-T08 · Enforcement evidence:** Exercise the “Address-space map” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M02.03-C043-T09 · Regression linkage:** Link the “Address-space map” property to changes in the linker script, image validator and selected backend loader; record which dependency or contract changes require rerunning it.
- [ ] **UC-M02.03-C043-T10 · Property disposition:** Compare the satisfying and violating “Address-space map” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M02.03-C044 · Integration

**Original checklist item:** Integrate address-space map with the linker script, image validator and selected backend loader; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M02.03-C044-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Address-space map” across the linker script, image validator and selected backend loader; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M02.03-C044-T02 · Field mapping:** Map every “Address-space map” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M02.03-C044-T03 · Prerequisite identities:** Record the actual prerequisites for “Address-space map” (source dependency list: UC-M02.02); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M02.03-C044-T04 · Ownership agreement:** Specify who owns “Address-space map” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M02.03-C044-T05 · Handoff implementation:** Connect “Address-space map” through the mapped seam using the real adapter or explicit specification reference; preserve “Guest memory regions have documented nonconflicting ownership” across the handoff.
- [ ] **UC-M02.03-C044-T06 · Absent-input case:** Omit one required “Address-space map” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M02.03-C044-T07 · Stale-input case:** Supply an outdated “Address-space map” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M02.03-C044-T08 · Incompatible-input case:** Supply an incompatible “Address-space map” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M02.03-C044-T09 · Valid integration trace:** Run a valid “Address-space map” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M02.03-C044-T10 · Seam review:** Reconcile the “Address-space map” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M02.03-C045 · Valid-case test

**Original checklist item:** Run a valid-path fixture for address-space map; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M02.03-C045-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Address-space map” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M02.03-C045-T02 · Expected-result oracle:** Specify the “Address-space map” expected result independently of the implementation output; include the property “Guest memory regions have documented nonconflicting ownership” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M02.03-C045-T03 · Fixture material:** Create the concrete “Address-space map” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M02.03-C045-T04 · Target preparation:** Prepare the “Address-space map” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M02.03-C045-T05 · Initial-state record:** Record the initial “Address-space map” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M02.03-C045-T06 · Valid-path execution:** Execute the “Address-space map” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M02.03-C045-T07 · Outcome comparison:** Compare every declared “Address-space map” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M02.03-C045-T08 · State and bounds check:** Inspect the “Address-space map” ownership/state effects and actual use of “Mapped region count and address-space size”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M02.03-C045-T09 · Repeatability check:** Repeat the same “Address-space map” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M02.03-C045-T10 · Positive evidence:** Attach the “Address-space map” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M02.03-C046 · Negative test

**Original checklist item:** Negative case: A device mapping overlaps the heap. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M02.03-C046-T01 · Adverse-case definition:** Create a test record for the exact “Address-space map” source counterexample: “A device mapping overlaps the heap”; state which precondition or invariant it challenges.
- [ ] **UC-M02.03-C046-T02 · Safe fixture boundary:** Define the contained test boundary for “Address-space map”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M02.03-C046-T03 · Valid control:** Construct a valid “Address-space map” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M02.03-C046-T04 · Minimal adverse input:** Derive the “Address-space map” adverse fixture from the control with the smallest documented change needed to reproduce “A device mapping overlaps the heap”; retain that change as reproducible data.
- [ ] **UC-M02.03-C046-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Address-space map”; require “Guest memory regions have documented nonconflicting ownership” and forbid a false-success verdict.
- [ ] **UC-M02.03-C046-T06 · Adverse execution:** Exercise the “Address-space map” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M02.03-C046-T07 · Effect inspection:** Inspect “Address-space map” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M02.03-C046-T08 · Refusal versus failure:** Confirm the “Address-space map” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M02.03-C046-T09 · Reset and retention:** Restore only the disposable “Address-space map” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M02.03-C046-T10 · Negative regression:** Register the “Address-space map” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M02.03-C047 · Change / failure test

**Original checklist item:** Exercise address-space map when a layout or protection setting changes between image construction and loading; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M02.03-C047-T01 · Scenario record:** Write the “Address-space map” change/failure scenario exactly as supplied: a layout or protection setting changes between image construction and loading; identify the property that must remain true: “Guest memory regions have documented nonconflicting ownership”.
- [ ] **UC-M02.03-C047-T02 · Baseline capture:** Create a known-valid “Address-space map” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M02.03-C047-T03 · Injection map:** Locate the “Address-space map” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M02.03-C047-T04 · Disposition oracle:** Define the legal intermediate and final “Address-space map” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M02.03-C047-T05 · Controlled trigger:** Introduce the controlled “Address-space map” scenario in the disposable fixture: a layout or protection setting changes between image construction and loading; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M02.03-C047-T06 · Intermediate inspection:** Inspect the “Address-space map” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M02.03-C047-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Address-space map”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M02.03-C047-T08 · Stale-evidence cleanup:** Invalidate superseded “Address-space map” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M02.03-C047-T09 · Repeat and compare:** Repeat the selected “Address-space map” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M02.03-C047-T10 · Failure evidence:** Publish the “Address-space map” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M02.03-C048 · Bounds

**Original checklist item:** Choose, document and test limits for mapped region count and address-space size; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M02.03-C048-T01 · Quantity inventory:** Create a measurement inventory for “Address-space map”: “Mapped region count and address-space size”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M02.03-C048-T02 · Measurement method:** Choose how to observe each “Address-space map” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M02.03-C048-T03 · Budget decision:** Select justified resource and input limits for “Address-space map”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M02.03-C048-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Address-space map” cases for “Mapped region count and address-space size”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M02.03-C048-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Address-space map” limit; preserve “Guest memory regions have documented nonconflicting ownership”.
- [ ] **UC-M02.03-C048-T06 · Normal measurement:** Run or review the normal “Address-space map” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M02.03-C048-T07 · At-limit measurement:** Exercise the “Address-space map” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M02.03-C048-T08 · Over-limit measurement:** Exercise the “Address-space map” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M02.03-C048-T09 · Uncovered-scope report:** List the “Address-space map” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M02.03-C048-T10 · Limit evidence:** Publish the selected “Address-space map” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M02.03-C049 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for address-space map with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M02.03-C049-T01 · Event inventory:** List the “Address-space map” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M02.03-C049-T02 · Diagnostic schema:** Define nonsecret fields for “Address-space map” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M02.03-C049-T03 · Failure mapping:** Map each documented “Address-space map” refusal or error to a diagnostic outcome; include “A device mapping overlaps the heap” and prohibit conversion into a success message.
- [ ] **UC-M02.03-C049-T04 · Emission path:** Add the “Address-space map” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M02.03-C049-T05 · Redaction check:** Test “Address-space map” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M02.03-C049-T06 · Output budget:** Set and exercise bounded “Address-space map” message size, rate and retention compatible with “Mapped region count and address-space size”; define truncation behavior that preserves the final reason.
- [ ] **UC-M02.03-C049-T07 · Success/refusal fixtures:** Capture “Address-space map” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M02.03-C049-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Address-space map” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M02.03-C049-T09 · Operator review:** Read the “Address-space map” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M02.03-C049-T10 · Diagnostic evidence:** Publish redacted “Address-space map” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M02.03-C050 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for address-space map; label unexecuted checks as untested.

- [ ] **UC-M02.03-C050-T01 · Evidence inventory:** List the “Address-space map” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M02.03-C050-T02 · Artifact references:** Record the exact “Address-space map” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M02.03-C050-T03 · Fixture references:** Attach the “Address-space map” fixture IDs, input identities and oracle definition; preserve the source counterexample “A device mapping overlaps the heap” as a distinct evidence case.
- [ ] **UC-M02.03-C050-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Address-space map”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M02.03-C050-T05 · Environment record:** Record the actual “Address-space map” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M02.03-C050-T06 · Expected versus observed:** Pair every “Address-space map” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M02.03-C050-T07 · Failure and limit records:** Attach “Address-space map” change/failure and bounds evidence where required; include uncovered “Mapped region count and address-space size” and unresolved violations of “Guest memory regions have documented nonconflicting ownership”.
- [ ] **UC-M02.03-C050-T08 · Evidence hygiene:** Check the “Address-space map” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M02.03-C050-T09 · Reproduction review:** Have the “Address-space map” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M02.03-C050-T10 · Acceptance linkage:** Link the “Address-space map” evidence to its parent and UC-M02.03 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 06. Zero initialization

**Source delivery:** Initialize designated zero-fill regions using validated lengths.

**Source invariant:** Zero initialization cannot overwrite unrelated mapped data.

**Source negative case:** A malformed zero-fill size crosses a section boundary.

**Source bounded quantities:** Zero-fill bytes and initialization time.

### UC-M02.03-C051 · Contract

**Original checklist item:** Specify zero initialization inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M02.03-C051-T01 · Scope statement:** Draft the operation boundary for “Zero initialization” within Linker, image layout and permissions; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M02.03-C051-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Zero initialization”; record each producer, representation and missing-value meaning.
- [ ] **UC-M02.03-C051-T03 · Output inventory:** List the outputs of “Zero initialization” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M02.03-C051-T04 · Field dictionary:** Create a field-and-term dictionary for “Zero initialization”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M02.03-C051-T05 · Prerequisite contract:** Map “Zero initialization” to the source component prerequisites (UC-M02.02); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M02.03-C051-T06 · Authority map:** Identify who may produce, change and consume “Zero initialization”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M02.03-C051-T07 · Invariant clause:** Add a normative clause for “Zero initialization” that preserves “Zero initialization cannot overwrite unrelated mapped data”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M02.03-C051-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Zero initialization”; include the source counterexample “A malformed zero-fill size crosses a section boundary” and the intended safe disposition.
- [ ] **UC-M02.03-C051-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Zero-fill bytes and initialization time” in the “Zero initialization” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M02.03-C051-T10 · Contract review:** Review the “Zero initialization” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M02.03-C052 · Delivery

**Original checklist item:** Initialize designated zero-fill regions using validated lengths.

- [ ] **UC-M02.03-C052-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Zero initialization”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M02.03-C052-T02 · Change plan:** Break the source delivery for “Zero initialization” into concrete edit targets and reviewable outputs; keep the UC-M02.03 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M02.03-C052-T03 · Core artifact:** Implement the smallest selected-profile change for “Zero initialization” that realizes this source instruction: Initialize designated zero-fill regions using validated lengths.
- [ ] **UC-M02.03-C052-T04 · Concrete realization:** Trace “Zero initialization” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M02.03-C052-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Zero initialization” needed to preserve “Zero initialization cannot overwrite unrelated mapped data”; record an enforcement gap where only a model exists.
- [ ] **UC-M02.03-C052-T06 · Dependency connection:** Connect the “Zero initialization” implementation to the linker script, image validator and selected backend loader; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M02.03-C052-T07 · Resource behavior:** Account for “Zero-fill bytes and initialization time” in “Zero initialization”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M02.03-C052-T08 · Delivery check:** Run the smallest real “Zero initialization” path and its adverse fixture “A malformed zero-fill size crosses a section boundary”; retain actual output, state effects and final disposition.
- [ ] **UC-M02.03-C052-T09 · Patch review:** Review the “Zero initialization” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M02.03-C052-T10 · Delivery handoff:** Publish the “Zero initialization” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M02.03-C053 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Zero initialization cannot overwrite unrelated mapped data. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M02.03-C053-T01 · Named property:** Create a stable property/check name under this parent for “Zero initialization”; copy its required invariant exactly: “Zero initialization cannot overwrite unrelated mapped data”.
- [ ] **UC-M02.03-C053-T02 · Observable terms:** Define each term in the “Zero initialization” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M02.03-C053-T03 · Precondition set:** List the preconditions under which “Zero initialization cannot overwrite unrelated mapped data” must hold for “Zero initialization”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M02.03-C053-T04 · Transition coverage:** Map the “Zero initialization” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M02.03-C053-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Zero initialization”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M02.03-C053-T06 · Satisfying fixture:** Create a concrete “Zero initialization” case that satisfies “Zero initialization cannot overwrite unrelated mapped data”; record its expected observation before running the assertion or review.
- [ ] **UC-M02.03-C053-T07 · Violating fixture:** Create the source counterexample “A malformed zero-fill size crosses a section boundary” for “Zero initialization”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M02.03-C053-T08 · Enforcement evidence:** Exercise the “Zero initialization” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M02.03-C053-T09 · Regression linkage:** Link the “Zero initialization” property to changes in the linker script, image validator and selected backend loader; record which dependency or contract changes require rerunning it.
- [ ] **UC-M02.03-C053-T10 · Property disposition:** Compare the satisfying and violating “Zero initialization” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M02.03-C054 · Integration

**Original checklist item:** Integrate zero initialization with the linker script, image validator and selected backend loader; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M02.03-C054-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Zero initialization” across the linker script, image validator and selected backend loader; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M02.03-C054-T02 · Field mapping:** Map every “Zero initialization” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M02.03-C054-T03 · Prerequisite identities:** Record the actual prerequisites for “Zero initialization” (source dependency list: UC-M02.02); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M02.03-C054-T04 · Ownership agreement:** Specify who owns “Zero initialization” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M02.03-C054-T05 · Handoff implementation:** Connect “Zero initialization” through the mapped seam using the real adapter or explicit specification reference; preserve “Zero initialization cannot overwrite unrelated mapped data” across the handoff.
- [ ] **UC-M02.03-C054-T06 · Absent-input case:** Omit one required “Zero initialization” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M02.03-C054-T07 · Stale-input case:** Supply an outdated “Zero initialization” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M02.03-C054-T08 · Incompatible-input case:** Supply an incompatible “Zero initialization” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M02.03-C054-T09 · Valid integration trace:** Run a valid “Zero initialization” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M02.03-C054-T10 · Seam review:** Reconcile the “Zero initialization” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M02.03-C055 · Valid-case test

**Original checklist item:** Run a valid-path fixture for zero initialization; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M02.03-C055-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Zero initialization” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M02.03-C055-T02 · Expected-result oracle:** Specify the “Zero initialization” expected result independently of the implementation output; include the property “Zero initialization cannot overwrite unrelated mapped data” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M02.03-C055-T03 · Fixture material:** Create the concrete “Zero initialization” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M02.03-C055-T04 · Target preparation:** Prepare the “Zero initialization” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M02.03-C055-T05 · Initial-state record:** Record the initial “Zero initialization” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M02.03-C055-T06 · Valid-path execution:** Execute the “Zero initialization” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M02.03-C055-T07 · Outcome comparison:** Compare every declared “Zero initialization” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M02.03-C055-T08 · State and bounds check:** Inspect the “Zero initialization” ownership/state effects and actual use of “Zero-fill bytes and initialization time”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M02.03-C055-T09 · Repeatability check:** Repeat the same “Zero initialization” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M02.03-C055-T10 · Positive evidence:** Attach the “Zero initialization” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M02.03-C056 · Negative test

**Original checklist item:** Negative case: A malformed zero-fill size crosses a section boundary. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M02.03-C056-T01 · Adverse-case definition:** Create a test record for the exact “Zero initialization” source counterexample: “A malformed zero-fill size crosses a section boundary”; state which precondition or invariant it challenges.
- [ ] **UC-M02.03-C056-T02 · Safe fixture boundary:** Define the contained test boundary for “Zero initialization”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M02.03-C056-T03 · Valid control:** Construct a valid “Zero initialization” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M02.03-C056-T04 · Minimal adverse input:** Derive the “Zero initialization” adverse fixture from the control with the smallest documented change needed to reproduce “A malformed zero-fill size crosses a section boundary”; retain that change as reproducible data.
- [ ] **UC-M02.03-C056-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Zero initialization”; require “Zero initialization cannot overwrite unrelated mapped data” and forbid a false-success verdict.
- [ ] **UC-M02.03-C056-T06 · Adverse execution:** Exercise the “Zero initialization” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M02.03-C056-T07 · Effect inspection:** Inspect “Zero initialization” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M02.03-C056-T08 · Refusal versus failure:** Confirm the “Zero initialization” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M02.03-C056-T09 · Reset and retention:** Restore only the disposable “Zero initialization” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M02.03-C056-T10 · Negative regression:** Register the “Zero initialization” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M02.03-C057 · Change / failure test

**Original checklist item:** Exercise zero initialization when a layout or protection setting changes between image construction and loading; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M02.03-C057-T01 · Scenario record:** Write the “Zero initialization” change/failure scenario exactly as supplied: a layout or protection setting changes between image construction and loading; identify the property that must remain true: “Zero initialization cannot overwrite unrelated mapped data”.
- [ ] **UC-M02.03-C057-T02 · Baseline capture:** Create a known-valid “Zero initialization” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M02.03-C057-T03 · Injection map:** Locate the “Zero initialization” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M02.03-C057-T04 · Disposition oracle:** Define the legal intermediate and final “Zero initialization” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M02.03-C057-T05 · Controlled trigger:** Introduce the controlled “Zero initialization” scenario in the disposable fixture: a layout or protection setting changes between image construction and loading; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M02.03-C057-T06 · Intermediate inspection:** Inspect the “Zero initialization” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M02.03-C057-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Zero initialization”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M02.03-C057-T08 · Stale-evidence cleanup:** Invalidate superseded “Zero initialization” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M02.03-C057-T09 · Repeat and compare:** Repeat the selected “Zero initialization” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M02.03-C057-T10 · Failure evidence:** Publish the “Zero initialization” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M02.03-C058 · Bounds

**Original checklist item:** Choose, document and test limits for zero-fill bytes and initialization time; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M02.03-C058-T01 · Quantity inventory:** Create a measurement inventory for “Zero initialization”: “Zero-fill bytes and initialization time”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M02.03-C058-T02 · Measurement method:** Choose how to observe each “Zero initialization” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M02.03-C058-T03 · Budget decision:** Select justified resource and input limits for “Zero initialization”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M02.03-C058-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Zero initialization” cases for “Zero-fill bytes and initialization time”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M02.03-C058-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Zero initialization” limit; preserve “Zero initialization cannot overwrite unrelated mapped data”.
- [ ] **UC-M02.03-C058-T06 · Normal measurement:** Run or review the normal “Zero initialization” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M02.03-C058-T07 · At-limit measurement:** Exercise the “Zero initialization” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M02.03-C058-T08 · Over-limit measurement:** Exercise the “Zero initialization” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M02.03-C058-T09 · Uncovered-scope report:** List the “Zero initialization” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M02.03-C058-T10 · Limit evidence:** Publish the selected “Zero initialization” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M02.03-C059 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for zero initialization with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M02.03-C059-T01 · Event inventory:** List the “Zero initialization” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M02.03-C059-T02 · Diagnostic schema:** Define nonsecret fields for “Zero initialization” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M02.03-C059-T03 · Failure mapping:** Map each documented “Zero initialization” refusal or error to a diagnostic outcome; include “A malformed zero-fill size crosses a section boundary” and prohibit conversion into a success message.
- [ ] **UC-M02.03-C059-T04 · Emission path:** Add the “Zero initialization” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M02.03-C059-T05 · Redaction check:** Test “Zero initialization” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M02.03-C059-T06 · Output budget:** Set and exercise bounded “Zero initialization” message size, rate and retention compatible with “Zero-fill bytes and initialization time”; define truncation behavior that preserves the final reason.
- [ ] **UC-M02.03-C059-T07 · Success/refusal fixtures:** Capture “Zero initialization” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M02.03-C059-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Zero initialization” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M02.03-C059-T09 · Operator review:** Read the “Zero initialization” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M02.03-C059-T10 · Diagnostic evidence:** Publish redacted “Zero initialization” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M02.03-C060 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for zero initialization; label unexecuted checks as untested.

- [ ] **UC-M02.03-C060-T01 · Evidence inventory:** List the “Zero initialization” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M02.03-C060-T02 · Artifact references:** Record the exact “Zero initialization” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M02.03-C060-T03 · Fixture references:** Attach the “Zero initialization” fixture IDs, input identities and oracle definition; preserve the source counterexample “A malformed zero-fill size crosses a section boundary” as a distinct evidence case.
- [ ] **UC-M02.03-C060-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Zero initialization”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M02.03-C060-T05 · Environment record:** Record the actual “Zero initialization” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M02.03-C060-T06 · Expected versus observed:** Pair every “Zero initialization” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M02.03-C060-T07 · Failure and limit records:** Attach “Zero initialization” change/failure and bounds evidence where required; include uncovered “Zero-fill bytes and initialization time” and unresolved violations of “Zero initialization cannot overwrite unrelated mapped data”.
- [ ] **UC-M02.03-C060-T08 · Evidence hygiene:** Check the “Zero initialization” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M02.03-C060-T09 · Reproduction review:** Have the “Zero initialization” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M02.03-C060-T10 · Acceptance linkage:** Link the “Zero initialization” evidence to its parent and UC-M02.03 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 07. Write/execute policy

**Source delivery:** Apply the selected platform's documented writable/executable-region policy.

**Source invariant:** Protection claims match the capabilities actually enforced by the backend.

**Source negative case:** A writable region is advertised as non-executable without enforcement.

**Source bounded quantities:** Permission transitions and region count.

### UC-M02.03-C061 · Contract

**Original checklist item:** Specify write/execute policy inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M02.03-C061-T01 · Scope statement:** Draft the operation boundary for “Write/execute policy” within Linker, image layout and permissions; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M02.03-C061-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Write/execute policy”; record each producer, representation and missing-value meaning.
- [ ] **UC-M02.03-C061-T03 · Output inventory:** List the outputs of “Write/execute policy” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M02.03-C061-T04 · Field dictionary:** Create a field-and-term dictionary for “Write/execute policy”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M02.03-C061-T05 · Prerequisite contract:** Map “Write/execute policy” to the source component prerequisites (UC-M02.02); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M02.03-C061-T06 · Authority map:** Identify who may produce, change and consume “Write/execute policy”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M02.03-C061-T07 · Invariant clause:** Add a normative clause for “Write/execute policy” that preserves “Protection claims match the capabilities actually enforced by the backend”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M02.03-C061-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Write/execute policy”; include the source counterexample “A writable region is advertised as non-executable without enforcement” and the intended safe disposition.
- [ ] **UC-M02.03-C061-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Permission transitions and region count” in the “Write/execute policy” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M02.03-C061-T10 · Contract review:** Review the “Write/execute policy” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M02.03-C062 · Delivery

**Original checklist item:** Apply the selected platform's documented writable/executable-region policy.

- [ ] **UC-M02.03-C062-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Write/execute policy”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M02.03-C062-T02 · Change plan:** Break the source delivery for “Write/execute policy” into concrete edit targets and reviewable outputs; keep the UC-M02.03 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M02.03-C062-T03 · Core artifact:** Implement the smallest selected-profile change for “Write/execute policy” that realizes this source instruction: Apply the selected platform's documented writable/executable-region policy.
- [ ] **UC-M02.03-C062-T04 · Concrete realization:** Trace “Write/execute policy” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M02.03-C062-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Write/execute policy” needed to preserve “Protection claims match the capabilities actually enforced by the backend”; record an enforcement gap where only a model exists.
- [ ] **UC-M02.03-C062-T06 · Dependency connection:** Connect the “Write/execute policy” implementation to the linker script, image validator and selected backend loader; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M02.03-C062-T07 · Resource behavior:** Account for “Permission transitions and region count” in “Write/execute policy”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M02.03-C062-T08 · Delivery check:** Run the smallest real “Write/execute policy” path and its adverse fixture “A writable region is advertised as non-executable without enforcement”; retain actual output, state effects and final disposition.
- [ ] **UC-M02.03-C062-T09 · Patch review:** Review the “Write/execute policy” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M02.03-C062-T10 · Delivery handoff:** Publish the “Write/execute policy” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M02.03-C063 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Protection claims match the capabilities actually enforced by the backend. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M02.03-C063-T01 · Named property:** Create a stable property/check name under this parent for “Write/execute policy”; copy its required invariant exactly: “Protection claims match the capabilities actually enforced by the backend”.
- [ ] **UC-M02.03-C063-T02 · Observable terms:** Define each term in the “Write/execute policy” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M02.03-C063-T03 · Precondition set:** List the preconditions under which “Protection claims match the capabilities actually enforced by the backend” must hold for “Write/execute policy”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M02.03-C063-T04 · Transition coverage:** Map the “Write/execute policy” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M02.03-C063-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Write/execute policy”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M02.03-C063-T06 · Satisfying fixture:** Create a concrete “Write/execute policy” case that satisfies “Protection claims match the capabilities actually enforced by the backend”; record its expected observation before running the assertion or review.
- [ ] **UC-M02.03-C063-T07 · Violating fixture:** Create the source counterexample “A writable region is advertised as non-executable without enforcement” for “Write/execute policy”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M02.03-C063-T08 · Enforcement evidence:** Exercise the “Write/execute policy” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M02.03-C063-T09 · Regression linkage:** Link the “Write/execute policy” property to changes in the linker script, image validator and selected backend loader; record which dependency or contract changes require rerunning it.
- [ ] **UC-M02.03-C063-T10 · Property disposition:** Compare the satisfying and violating “Write/execute policy” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M02.03-C064 · Integration

**Original checklist item:** Integrate write/execute policy with the linker script, image validator and selected backend loader; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M02.03-C064-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Write/execute policy” across the linker script, image validator and selected backend loader; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M02.03-C064-T02 · Field mapping:** Map every “Write/execute policy” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M02.03-C064-T03 · Prerequisite identities:** Record the actual prerequisites for “Write/execute policy” (source dependency list: UC-M02.02); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M02.03-C064-T04 · Ownership agreement:** Specify who owns “Write/execute policy” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M02.03-C064-T05 · Handoff implementation:** Connect “Write/execute policy” through the mapped seam using the real adapter or explicit specification reference; preserve “Protection claims match the capabilities actually enforced by the backend” across the handoff.
- [ ] **UC-M02.03-C064-T06 · Absent-input case:** Omit one required “Write/execute policy” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M02.03-C064-T07 · Stale-input case:** Supply an outdated “Write/execute policy” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M02.03-C064-T08 · Incompatible-input case:** Supply an incompatible “Write/execute policy” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M02.03-C064-T09 · Valid integration trace:** Run a valid “Write/execute policy” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M02.03-C064-T10 · Seam review:** Reconcile the “Write/execute policy” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M02.03-C065 · Valid-case test

**Original checklist item:** Run a valid-path fixture for write/execute policy; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M02.03-C065-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Write/execute policy” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M02.03-C065-T02 · Expected-result oracle:** Specify the “Write/execute policy” expected result independently of the implementation output; include the property “Protection claims match the capabilities actually enforced by the backend” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M02.03-C065-T03 · Fixture material:** Create the concrete “Write/execute policy” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M02.03-C065-T04 · Target preparation:** Prepare the “Write/execute policy” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M02.03-C065-T05 · Initial-state record:** Record the initial “Write/execute policy” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M02.03-C065-T06 · Valid-path execution:** Execute the “Write/execute policy” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M02.03-C065-T07 · Outcome comparison:** Compare every declared “Write/execute policy” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M02.03-C065-T08 · State and bounds check:** Inspect the “Write/execute policy” ownership/state effects and actual use of “Permission transitions and region count”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M02.03-C065-T09 · Repeatability check:** Repeat the same “Write/execute policy” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M02.03-C065-T10 · Positive evidence:** Attach the “Write/execute policy” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M02.03-C066 · Negative test

**Original checklist item:** Negative case: A writable region is advertised as non-executable without enforcement. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M02.03-C066-T01 · Adverse-case definition:** Create a test record for the exact “Write/execute policy” source counterexample: “A writable region is advertised as non-executable without enforcement”; state which precondition or invariant it challenges.
- [ ] **UC-M02.03-C066-T02 · Safe fixture boundary:** Define the contained test boundary for “Write/execute policy”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M02.03-C066-T03 · Valid control:** Construct a valid “Write/execute policy” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M02.03-C066-T04 · Minimal adverse input:** Derive the “Write/execute policy” adverse fixture from the control with the smallest documented change needed to reproduce “A writable region is advertised as non-executable without enforcement”; retain that change as reproducible data.
- [ ] **UC-M02.03-C066-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Write/execute policy”; require “Protection claims match the capabilities actually enforced by the backend” and forbid a false-success verdict.
- [ ] **UC-M02.03-C066-T06 · Adverse execution:** Exercise the “Write/execute policy” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M02.03-C066-T07 · Effect inspection:** Inspect “Write/execute policy” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M02.03-C066-T08 · Refusal versus failure:** Confirm the “Write/execute policy” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M02.03-C066-T09 · Reset and retention:** Restore only the disposable “Write/execute policy” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M02.03-C066-T10 · Negative regression:** Register the “Write/execute policy” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M02.03-C067 · Change / failure test

**Original checklist item:** Exercise write/execute policy when a layout or protection setting changes between image construction and loading; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M02.03-C067-T01 · Scenario record:** Write the “Write/execute policy” change/failure scenario exactly as supplied: a layout or protection setting changes between image construction and loading; identify the property that must remain true: “Protection claims match the capabilities actually enforced by the backend”.
- [ ] **UC-M02.03-C067-T02 · Baseline capture:** Create a known-valid “Write/execute policy” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M02.03-C067-T03 · Injection map:** Locate the “Write/execute policy” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M02.03-C067-T04 · Disposition oracle:** Define the legal intermediate and final “Write/execute policy” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M02.03-C067-T05 · Controlled trigger:** Introduce the controlled “Write/execute policy” scenario in the disposable fixture: a layout or protection setting changes between image construction and loading; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M02.03-C067-T06 · Intermediate inspection:** Inspect the “Write/execute policy” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M02.03-C067-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Write/execute policy”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M02.03-C067-T08 · Stale-evidence cleanup:** Invalidate superseded “Write/execute policy” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M02.03-C067-T09 · Repeat and compare:** Repeat the selected “Write/execute policy” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M02.03-C067-T10 · Failure evidence:** Publish the “Write/execute policy” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M02.03-C068 · Bounds

**Original checklist item:** Choose, document and test limits for permission transitions and region count; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M02.03-C068-T01 · Quantity inventory:** Create a measurement inventory for “Write/execute policy”: “Permission transitions and region count”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M02.03-C068-T02 · Measurement method:** Choose how to observe each “Write/execute policy” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M02.03-C068-T03 · Budget decision:** Select justified resource and input limits for “Write/execute policy”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M02.03-C068-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Write/execute policy” cases for “Permission transitions and region count”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M02.03-C068-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Write/execute policy” limit; preserve “Protection claims match the capabilities actually enforced by the backend”.
- [ ] **UC-M02.03-C068-T06 · Normal measurement:** Run or review the normal “Write/execute policy” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M02.03-C068-T07 · At-limit measurement:** Exercise the “Write/execute policy” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M02.03-C068-T08 · Over-limit measurement:** Exercise the “Write/execute policy” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M02.03-C068-T09 · Uncovered-scope report:** List the “Write/execute policy” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M02.03-C068-T10 · Limit evidence:** Publish the selected “Write/execute policy” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M02.03-C069 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for write/execute policy with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M02.03-C069-T01 · Event inventory:** List the “Write/execute policy” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M02.03-C069-T02 · Diagnostic schema:** Define nonsecret fields for “Write/execute policy” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M02.03-C069-T03 · Failure mapping:** Map each documented “Write/execute policy” refusal or error to a diagnostic outcome; include “A writable region is advertised as non-executable without enforcement” and prohibit conversion into a success message.
- [ ] **UC-M02.03-C069-T04 · Emission path:** Add the “Write/execute policy” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M02.03-C069-T05 · Redaction check:** Test “Write/execute policy” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M02.03-C069-T06 · Output budget:** Set and exercise bounded “Write/execute policy” message size, rate and retention compatible with “Permission transitions and region count”; define truncation behavior that preserves the final reason.
- [ ] **UC-M02.03-C069-T07 · Success/refusal fixtures:** Capture “Write/execute policy” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M02.03-C069-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Write/execute policy” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M02.03-C069-T09 · Operator review:** Read the “Write/execute policy” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M02.03-C069-T10 · Diagnostic evidence:** Publish redacted “Write/execute policy” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M02.03-C070 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for write/execute policy; label unexecuted checks as untested.

- [ ] **UC-M02.03-C070-T01 · Evidence inventory:** List the “Write/execute policy” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M02.03-C070-T02 · Artifact references:** Record the exact “Write/execute policy” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M02.03-C070-T03 · Fixture references:** Attach the “Write/execute policy” fixture IDs, input identities and oracle definition; preserve the source counterexample “A writable region is advertised as non-executable without enforcement” as a distinct evidence case.
- [ ] **UC-M02.03-C070-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Write/execute policy”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M02.03-C070-T05 · Environment record:** Record the actual “Write/execute policy” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M02.03-C070-T06 · Expected versus observed:** Pair every “Write/execute policy” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M02.03-C070-T07 · Failure and limit records:** Attach “Write/execute policy” change/failure and bounds evidence where required; include uncovered “Permission transitions and region count” and unresolved violations of “Protection claims match the capabilities actually enforced by the backend”.
- [ ] **UC-M02.03-C070-T08 · Evidence hygiene:** Check the “Write/execute policy” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M02.03-C070-T09 · Reproduction review:** Have the “Write/execute policy” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M02.03-C070-T10 · Acceptance linkage:** Link the “Write/execute policy” evidence to its parent and UC-M02.03 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 08. Image size limits

**Source delivery:** Reject guest images whose file or expanded memory layout exceeds selected budgets.

**Source invariant:** Admission accounts for in-memory expansion rather than file size alone.

**Source negative case:** A tiny file declares an excessive zero-fill segment.

**Source bounded quantities:** Image bytes, expanded bytes and validation memory.

### UC-M02.03-C071 · Contract

**Original checklist item:** Specify image size limits inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M02.03-C071-T01 · Scope statement:** Draft the operation boundary for “Image size limits” within Linker, image layout and permissions; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M02.03-C071-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Image size limits”; record each producer, representation and missing-value meaning.
- [ ] **UC-M02.03-C071-T03 · Output inventory:** List the outputs of “Image size limits” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M02.03-C071-T04 · Field dictionary:** Create a field-and-term dictionary for “Image size limits”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M02.03-C071-T05 · Prerequisite contract:** Map “Image size limits” to the source component prerequisites (UC-M02.02); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M02.03-C071-T06 · Authority map:** Identify who may produce, change and consume “Image size limits”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M02.03-C071-T07 · Invariant clause:** Add a normative clause for “Image size limits” that preserves “Admission accounts for in-memory expansion rather than file size alone”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M02.03-C071-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Image size limits”; include the source counterexample “A tiny file declares an excessive zero-fill segment” and the intended safe disposition.
- [ ] **UC-M02.03-C071-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Image bytes, expanded bytes and validation memory” in the “Image size limits” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M02.03-C071-T10 · Contract review:** Review the “Image size limits” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M02.03-C072 · Delivery

**Original checklist item:** Reject guest images whose file or expanded memory layout exceeds selected budgets.

- [ ] **UC-M02.03-C072-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Image size limits”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M02.03-C072-T02 · Change plan:** Break the source delivery for “Image size limits” into concrete edit targets and reviewable outputs; keep the UC-M02.03 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M02.03-C072-T03 · Core artifact:** Implement the smallest selected-profile change for “Image size limits” that realizes this source instruction: Reject guest images whose file or expanded memory layout exceeds selected budgets.
- [ ] **UC-M02.03-C072-T04 · Concrete realization:** Trace “Image size limits” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M02.03-C072-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Image size limits” needed to preserve “Admission accounts for in-memory expansion rather than file size alone”; record an enforcement gap where only a model exists.
- [ ] **UC-M02.03-C072-T06 · Dependency connection:** Connect the “Image size limits” implementation to the linker script, image validator and selected backend loader; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M02.03-C072-T07 · Resource behavior:** Account for “Image bytes, expanded bytes and validation memory” in “Image size limits”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M02.03-C072-T08 · Delivery check:** Run the smallest real “Image size limits” path and its adverse fixture “A tiny file declares an excessive zero-fill segment”; retain actual output, state effects and final disposition.
- [ ] **UC-M02.03-C072-T09 · Patch review:** Review the “Image size limits” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M02.03-C072-T10 · Delivery handoff:** Publish the “Image size limits” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M02.03-C073 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Admission accounts for in-memory expansion rather than file size alone. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M02.03-C073-T01 · Named property:** Create a stable property/check name under this parent for “Image size limits”; copy its required invariant exactly: “Admission accounts for in-memory expansion rather than file size alone”.
- [ ] **UC-M02.03-C073-T02 · Observable terms:** Define each term in the “Image size limits” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M02.03-C073-T03 · Precondition set:** List the preconditions under which “Admission accounts for in-memory expansion rather than file size alone” must hold for “Image size limits”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M02.03-C073-T04 · Transition coverage:** Map the “Image size limits” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M02.03-C073-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Image size limits”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M02.03-C073-T06 · Satisfying fixture:** Create a concrete “Image size limits” case that satisfies “Admission accounts for in-memory expansion rather than file size alone”; record its expected observation before running the assertion or review.
- [ ] **UC-M02.03-C073-T07 · Violating fixture:** Create the source counterexample “A tiny file declares an excessive zero-fill segment” for “Image size limits”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M02.03-C073-T08 · Enforcement evidence:** Exercise the “Image size limits” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M02.03-C073-T09 · Regression linkage:** Link the “Image size limits” property to changes in the linker script, image validator and selected backend loader; record which dependency or contract changes require rerunning it.
- [ ] **UC-M02.03-C073-T10 · Property disposition:** Compare the satisfying and violating “Image size limits” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M02.03-C074 · Integration

**Original checklist item:** Integrate image size limits with the linker script, image validator and selected backend loader; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M02.03-C074-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Image size limits” across the linker script, image validator and selected backend loader; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M02.03-C074-T02 · Field mapping:** Map every “Image size limits” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M02.03-C074-T03 · Prerequisite identities:** Record the actual prerequisites for “Image size limits” (source dependency list: UC-M02.02); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M02.03-C074-T04 · Ownership agreement:** Specify who owns “Image size limits” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M02.03-C074-T05 · Handoff implementation:** Connect “Image size limits” through the mapped seam using the real adapter or explicit specification reference; preserve “Admission accounts for in-memory expansion rather than file size alone” across the handoff.
- [ ] **UC-M02.03-C074-T06 · Absent-input case:** Omit one required “Image size limits” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M02.03-C074-T07 · Stale-input case:** Supply an outdated “Image size limits” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M02.03-C074-T08 · Incompatible-input case:** Supply an incompatible “Image size limits” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M02.03-C074-T09 · Valid integration trace:** Run a valid “Image size limits” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M02.03-C074-T10 · Seam review:** Reconcile the “Image size limits” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M02.03-C075 · Valid-case test

**Original checklist item:** Run a valid-path fixture for image size limits; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M02.03-C075-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Image size limits” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M02.03-C075-T02 · Expected-result oracle:** Specify the “Image size limits” expected result independently of the implementation output; include the property “Admission accounts for in-memory expansion rather than file size alone” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M02.03-C075-T03 · Fixture material:** Create the concrete “Image size limits” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M02.03-C075-T04 · Target preparation:** Prepare the “Image size limits” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M02.03-C075-T05 · Initial-state record:** Record the initial “Image size limits” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M02.03-C075-T06 · Valid-path execution:** Execute the “Image size limits” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M02.03-C075-T07 · Outcome comparison:** Compare every declared “Image size limits” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M02.03-C075-T08 · State and bounds check:** Inspect the “Image size limits” ownership/state effects and actual use of “Image bytes, expanded bytes and validation memory”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M02.03-C075-T09 · Repeatability check:** Repeat the same “Image size limits” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M02.03-C075-T10 · Positive evidence:** Attach the “Image size limits” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M02.03-C076 · Negative test

**Original checklist item:** Negative case: A tiny file declares an excessive zero-fill segment. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M02.03-C076-T01 · Adverse-case definition:** Create a test record for the exact “Image size limits” source counterexample: “A tiny file declares an excessive zero-fill segment”; state which precondition or invariant it challenges.
- [ ] **UC-M02.03-C076-T02 · Safe fixture boundary:** Define the contained test boundary for “Image size limits”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M02.03-C076-T03 · Valid control:** Construct a valid “Image size limits” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M02.03-C076-T04 · Minimal adverse input:** Derive the “Image size limits” adverse fixture from the control with the smallest documented change needed to reproduce “A tiny file declares an excessive zero-fill segment”; retain that change as reproducible data.
- [ ] **UC-M02.03-C076-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Image size limits”; require “Admission accounts for in-memory expansion rather than file size alone” and forbid a false-success verdict.
- [ ] **UC-M02.03-C076-T06 · Adverse execution:** Exercise the “Image size limits” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M02.03-C076-T07 · Effect inspection:** Inspect “Image size limits” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M02.03-C076-T08 · Refusal versus failure:** Confirm the “Image size limits” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M02.03-C076-T09 · Reset and retention:** Restore only the disposable “Image size limits” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M02.03-C076-T10 · Negative regression:** Register the “Image size limits” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M02.03-C077 · Change / failure test

**Original checklist item:** Exercise image size limits when a layout or protection setting changes between image construction and loading; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M02.03-C077-T01 · Scenario record:** Write the “Image size limits” change/failure scenario exactly as supplied: a layout or protection setting changes between image construction and loading; identify the property that must remain true: “Admission accounts for in-memory expansion rather than file size alone”.
- [ ] **UC-M02.03-C077-T02 · Baseline capture:** Create a known-valid “Image size limits” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M02.03-C077-T03 · Injection map:** Locate the “Image size limits” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M02.03-C077-T04 · Disposition oracle:** Define the legal intermediate and final “Image size limits” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M02.03-C077-T05 · Controlled trigger:** Introduce the controlled “Image size limits” scenario in the disposable fixture: a layout or protection setting changes between image construction and loading; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M02.03-C077-T06 · Intermediate inspection:** Inspect the “Image size limits” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M02.03-C077-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Image size limits”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M02.03-C077-T08 · Stale-evidence cleanup:** Invalidate superseded “Image size limits” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M02.03-C077-T09 · Repeat and compare:** Repeat the selected “Image size limits” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M02.03-C077-T10 · Failure evidence:** Publish the “Image size limits” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M02.03-C078 · Bounds

**Original checklist item:** Choose, document and test limits for image bytes, expanded bytes and validation memory; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M02.03-C078-T01 · Quantity inventory:** Create a measurement inventory for “Image size limits”: “Image bytes, expanded bytes and validation memory”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M02.03-C078-T02 · Measurement method:** Choose how to observe each “Image size limits” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M02.03-C078-T03 · Budget decision:** Select justified resource and input limits for “Image size limits”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M02.03-C078-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Image size limits” cases for “Image bytes, expanded bytes and validation memory”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M02.03-C078-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Image size limits” limit; preserve “Admission accounts for in-memory expansion rather than file size alone”.
- [ ] **UC-M02.03-C078-T06 · Normal measurement:** Run or review the normal “Image size limits” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M02.03-C078-T07 · At-limit measurement:** Exercise the “Image size limits” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M02.03-C078-T08 · Over-limit measurement:** Exercise the “Image size limits” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M02.03-C078-T09 · Uncovered-scope report:** List the “Image size limits” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M02.03-C078-T10 · Limit evidence:** Publish the selected “Image size limits” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M02.03-C079 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for image size limits with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M02.03-C079-T01 · Event inventory:** List the “Image size limits” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M02.03-C079-T02 · Diagnostic schema:** Define nonsecret fields for “Image size limits” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M02.03-C079-T03 · Failure mapping:** Map each documented “Image size limits” refusal or error to a diagnostic outcome; include “A tiny file declares an excessive zero-fill segment” and prohibit conversion into a success message.
- [ ] **UC-M02.03-C079-T04 · Emission path:** Add the “Image size limits” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M02.03-C079-T05 · Redaction check:** Test “Image size limits” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M02.03-C079-T06 · Output budget:** Set and exercise bounded “Image size limits” message size, rate and retention compatible with “Image bytes, expanded bytes and validation memory”; define truncation behavior that preserves the final reason.
- [ ] **UC-M02.03-C079-T07 · Success/refusal fixtures:** Capture “Image size limits” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M02.03-C079-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Image size limits” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M02.03-C079-T09 · Operator review:** Read the “Image size limits” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M02.03-C079-T10 · Diagnostic evidence:** Publish redacted “Image size limits” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M02.03-C080 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for image size limits; label unexecuted checks as untested.

- [ ] **UC-M02.03-C080-T01 · Evidence inventory:** List the “Image size limits” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M02.03-C080-T02 · Artifact references:** Record the exact “Image size limits” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M02.03-C080-T03 · Fixture references:** Attach the “Image size limits” fixture IDs, input identities and oracle definition; preserve the source counterexample “A tiny file declares an excessive zero-fill segment” as a distinct evidence case.
- [ ] **UC-M02.03-C080-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Image size limits”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M02.03-C080-T05 · Environment record:** Record the actual “Image size limits” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M02.03-C080-T06 · Expected versus observed:** Pair every “Image size limits” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M02.03-C080-T07 · Failure and limit records:** Attach “Image size limits” change/failure and bounds evidence where required; include uncovered “Image bytes, expanded bytes and validation memory” and unresolved violations of “Admission accounts for in-memory expansion rather than file size alone”.
- [ ] **UC-M02.03-C080-T08 · Evidence hygiene:** Check the “Image size limits” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M02.03-C080-T09 · Reproduction review:** Have the “Image size limits” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M02.03-C080-T10 · Acceptance linkage:** Link the “Image size limits” evidence to its parent and UC-M02.03 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 09. Malformed-image corpus

**Source delivery:** Maintain positive and malformed image fixtures for the selected loader.

**Source invariant:** Malformed layout handling is deterministic and bounded.

**Source negative case:** An image contains truncated headers and conflicting segment sizes.

**Source bounded quantities:** Corpus count, fixture bytes and test deadline.

### UC-M02.03-C081 · Contract

**Original checklist item:** Specify malformed-image corpus inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M02.03-C081-T01 · Scope statement:** Draft the operation boundary for “Malformed-image corpus” within Linker, image layout and permissions; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M02.03-C081-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Malformed-image corpus”; record each producer, representation and missing-value meaning.
- [ ] **UC-M02.03-C081-T03 · Output inventory:** List the outputs of “Malformed-image corpus” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M02.03-C081-T04 · Field dictionary:** Create a field-and-term dictionary for “Malformed-image corpus”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M02.03-C081-T05 · Prerequisite contract:** Map “Malformed-image corpus” to the source component prerequisites (UC-M02.02); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M02.03-C081-T06 · Authority map:** Identify who may produce, change and consume “Malformed-image corpus”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M02.03-C081-T07 · Invariant clause:** Add a normative clause for “Malformed-image corpus” that preserves “Malformed layout handling is deterministic and bounded”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M02.03-C081-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Malformed-image corpus”; include the source counterexample “An image contains truncated headers and conflicting segment sizes” and the intended safe disposition.
- [ ] **UC-M02.03-C081-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Corpus count, fixture bytes and test deadline” in the “Malformed-image corpus” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M02.03-C081-T10 · Contract review:** Review the “Malformed-image corpus” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M02.03-C082 · Delivery

**Original checklist item:** Maintain positive and malformed image fixtures for the selected loader.

- [ ] **UC-M02.03-C082-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Malformed-image corpus”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M02.03-C082-T02 · Change plan:** Break the source delivery for “Malformed-image corpus” into concrete edit targets and reviewable outputs; keep the UC-M02.03 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M02.03-C082-T03 · Core artifact:** Implement the smallest selected-profile change for “Malformed-image corpus” that realizes this source instruction: Maintain positive and malformed image fixtures for the selected loader.
- [ ] **UC-M02.03-C082-T04 · Concrete realization:** Trace “Malformed-image corpus” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M02.03-C082-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Malformed-image corpus” needed to preserve “Malformed layout handling is deterministic and bounded”; record an enforcement gap where only a model exists.
- [ ] **UC-M02.03-C082-T06 · Dependency connection:** Connect the “Malformed-image corpus” implementation to the linker script, image validator and selected backend loader; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M02.03-C082-T07 · Resource behavior:** Account for “Corpus count, fixture bytes and test deadline” in “Malformed-image corpus”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M02.03-C082-T08 · Delivery check:** Run the smallest real “Malformed-image corpus” path and its adverse fixture “An image contains truncated headers and conflicting segment sizes”; retain actual output, state effects and final disposition.
- [ ] **UC-M02.03-C082-T09 · Patch review:** Review the “Malformed-image corpus” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M02.03-C082-T10 · Delivery handoff:** Publish the “Malformed-image corpus” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M02.03-C083 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Malformed layout handling is deterministic and bounded. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M02.03-C083-T01 · Named property:** Create a stable property/check name under this parent for “Malformed-image corpus”; copy its required invariant exactly: “Malformed layout handling is deterministic and bounded”.
- [ ] **UC-M02.03-C083-T02 · Observable terms:** Define each term in the “Malformed-image corpus” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M02.03-C083-T03 · Precondition set:** List the preconditions under which “Malformed layout handling is deterministic and bounded” must hold for “Malformed-image corpus”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M02.03-C083-T04 · Transition coverage:** Map the “Malformed-image corpus” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M02.03-C083-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Malformed-image corpus”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M02.03-C083-T06 · Satisfying fixture:** Create a concrete “Malformed-image corpus” case that satisfies “Malformed layout handling is deterministic and bounded”; record its expected observation before running the assertion or review.
- [ ] **UC-M02.03-C083-T07 · Violating fixture:** Create the source counterexample “An image contains truncated headers and conflicting segment sizes” for “Malformed-image corpus”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M02.03-C083-T08 · Enforcement evidence:** Exercise the “Malformed-image corpus” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M02.03-C083-T09 · Regression linkage:** Link the “Malformed-image corpus” property to changes in the linker script, image validator and selected backend loader; record which dependency or contract changes require rerunning it.
- [ ] **UC-M02.03-C083-T10 · Property disposition:** Compare the satisfying and violating “Malformed-image corpus” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M02.03-C084 · Integration

**Original checklist item:** Integrate malformed-image corpus with the linker script, image validator and selected backend loader; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M02.03-C084-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Malformed-image corpus” across the linker script, image validator and selected backend loader; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M02.03-C084-T02 · Field mapping:** Map every “Malformed-image corpus” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M02.03-C084-T03 · Prerequisite identities:** Record the actual prerequisites for “Malformed-image corpus” (source dependency list: UC-M02.02); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M02.03-C084-T04 · Ownership agreement:** Specify who owns “Malformed-image corpus” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M02.03-C084-T05 · Handoff implementation:** Connect “Malformed-image corpus” through the mapped seam using the real adapter or explicit specification reference; preserve “Malformed layout handling is deterministic and bounded” across the handoff.
- [ ] **UC-M02.03-C084-T06 · Absent-input case:** Omit one required “Malformed-image corpus” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M02.03-C084-T07 · Stale-input case:** Supply an outdated “Malformed-image corpus” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M02.03-C084-T08 · Incompatible-input case:** Supply an incompatible “Malformed-image corpus” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M02.03-C084-T09 · Valid integration trace:** Run a valid “Malformed-image corpus” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M02.03-C084-T10 · Seam review:** Reconcile the “Malformed-image corpus” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M02.03-C085 · Valid-case test

**Original checklist item:** Run a valid-path fixture for malformed-image corpus; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M02.03-C085-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Malformed-image corpus” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M02.03-C085-T02 · Expected-result oracle:** Specify the “Malformed-image corpus” expected result independently of the implementation output; include the property “Malformed layout handling is deterministic and bounded” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M02.03-C085-T03 · Fixture material:** Create the concrete “Malformed-image corpus” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M02.03-C085-T04 · Target preparation:** Prepare the “Malformed-image corpus” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M02.03-C085-T05 · Initial-state record:** Record the initial “Malformed-image corpus” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M02.03-C085-T06 · Valid-path execution:** Execute the “Malformed-image corpus” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M02.03-C085-T07 · Outcome comparison:** Compare every declared “Malformed-image corpus” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M02.03-C085-T08 · State and bounds check:** Inspect the “Malformed-image corpus” ownership/state effects and actual use of “Corpus count, fixture bytes and test deadline”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M02.03-C085-T09 · Repeatability check:** Repeat the same “Malformed-image corpus” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M02.03-C085-T10 · Positive evidence:** Attach the “Malformed-image corpus” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M02.03-C086 · Negative test

**Original checklist item:** Negative case: An image contains truncated headers and conflicting segment sizes. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M02.03-C086-T01 · Adverse-case definition:** Create a test record for the exact “Malformed-image corpus” source counterexample: “An image contains truncated headers and conflicting segment sizes”; state which precondition or invariant it challenges.
- [ ] **UC-M02.03-C086-T02 · Safe fixture boundary:** Define the contained test boundary for “Malformed-image corpus”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M02.03-C086-T03 · Valid control:** Construct a valid “Malformed-image corpus” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M02.03-C086-T04 · Minimal adverse input:** Derive the “Malformed-image corpus” adverse fixture from the control with the smallest documented change needed to reproduce “An image contains truncated headers and conflicting segment sizes”; retain that change as reproducible data.
- [ ] **UC-M02.03-C086-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Malformed-image corpus”; require “Malformed layout handling is deterministic and bounded” and forbid a false-success verdict.
- [ ] **UC-M02.03-C086-T06 · Adverse execution:** Exercise the “Malformed-image corpus” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M02.03-C086-T07 · Effect inspection:** Inspect “Malformed-image corpus” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M02.03-C086-T08 · Refusal versus failure:** Confirm the “Malformed-image corpus” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M02.03-C086-T09 · Reset and retention:** Restore only the disposable “Malformed-image corpus” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M02.03-C086-T10 · Negative regression:** Register the “Malformed-image corpus” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M02.03-C087 · Change / failure test

**Original checklist item:** Exercise malformed-image corpus when a layout or protection setting changes between image construction and loading; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M02.03-C087-T01 · Scenario record:** Write the “Malformed-image corpus” change/failure scenario exactly as supplied: a layout or protection setting changes between image construction and loading; identify the property that must remain true: “Malformed layout handling is deterministic and bounded”.
- [ ] **UC-M02.03-C087-T02 · Baseline capture:** Create a known-valid “Malformed-image corpus” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M02.03-C087-T03 · Injection map:** Locate the “Malformed-image corpus” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M02.03-C087-T04 · Disposition oracle:** Define the legal intermediate and final “Malformed-image corpus” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M02.03-C087-T05 · Controlled trigger:** Introduce the controlled “Malformed-image corpus” scenario in the disposable fixture: a layout or protection setting changes between image construction and loading; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M02.03-C087-T06 · Intermediate inspection:** Inspect the “Malformed-image corpus” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M02.03-C087-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Malformed-image corpus”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M02.03-C087-T08 · Stale-evidence cleanup:** Invalidate superseded “Malformed-image corpus” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M02.03-C087-T09 · Repeat and compare:** Repeat the selected “Malformed-image corpus” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M02.03-C087-T10 · Failure evidence:** Publish the “Malformed-image corpus” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M02.03-C088 · Bounds

**Original checklist item:** Choose, document and test limits for corpus count, fixture bytes and test deadline; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M02.03-C088-T01 · Quantity inventory:** Create a measurement inventory for “Malformed-image corpus”: “Corpus count, fixture bytes and test deadline”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M02.03-C088-T02 · Measurement method:** Choose how to observe each “Malformed-image corpus” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M02.03-C088-T03 · Budget decision:** Select justified resource and input limits for “Malformed-image corpus”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M02.03-C088-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Malformed-image corpus” cases for “Corpus count, fixture bytes and test deadline”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M02.03-C088-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Malformed-image corpus” limit; preserve “Malformed layout handling is deterministic and bounded”.
- [ ] **UC-M02.03-C088-T06 · Normal measurement:** Run or review the normal “Malformed-image corpus” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M02.03-C088-T07 · At-limit measurement:** Exercise the “Malformed-image corpus” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M02.03-C088-T08 · Over-limit measurement:** Exercise the “Malformed-image corpus” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M02.03-C088-T09 · Uncovered-scope report:** List the “Malformed-image corpus” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M02.03-C088-T10 · Limit evidence:** Publish the selected “Malformed-image corpus” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M02.03-C089 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for malformed-image corpus with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M02.03-C089-T01 · Event inventory:** List the “Malformed-image corpus” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M02.03-C089-T02 · Diagnostic schema:** Define nonsecret fields for “Malformed-image corpus” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M02.03-C089-T03 · Failure mapping:** Map each documented “Malformed-image corpus” refusal or error to a diagnostic outcome; include “An image contains truncated headers and conflicting segment sizes” and prohibit conversion into a success message.
- [ ] **UC-M02.03-C089-T04 · Emission path:** Add the “Malformed-image corpus” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M02.03-C089-T05 · Redaction check:** Test “Malformed-image corpus” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M02.03-C089-T06 · Output budget:** Set and exercise bounded “Malformed-image corpus” message size, rate and retention compatible with “Corpus count, fixture bytes and test deadline”; define truncation behavior that preserves the final reason.
- [ ] **UC-M02.03-C089-T07 · Success/refusal fixtures:** Capture “Malformed-image corpus” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M02.03-C089-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Malformed-image corpus” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M02.03-C089-T09 · Operator review:** Read the “Malformed-image corpus” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M02.03-C089-T10 · Diagnostic evidence:** Publish redacted “Malformed-image corpus” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M02.03-C090 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for malformed-image corpus; label unexecuted checks as untested.

- [ ] **UC-M02.03-C090-T01 · Evidence inventory:** List the “Malformed-image corpus” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M02.03-C090-T02 · Artifact references:** Record the exact “Malformed-image corpus” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M02.03-C090-T03 · Fixture references:** Attach the “Malformed-image corpus” fixture IDs, input identities and oracle definition; preserve the source counterexample “An image contains truncated headers and conflicting segment sizes” as a distinct evidence case.
- [ ] **UC-M02.03-C090-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Malformed-image corpus”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M02.03-C090-T05 · Environment record:** Record the actual “Malformed-image corpus” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M02.03-C090-T06 · Expected versus observed:** Pair every “Malformed-image corpus” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M02.03-C090-T07 · Failure and limit records:** Attach “Malformed-image corpus” change/failure and bounds evidence where required; include uncovered “Corpus count, fixture bytes and test deadline” and unresolved violations of “Malformed layout handling is deterministic and bounded”.
- [ ] **UC-M02.03-C090-T08 · Evidence hygiene:** Check the “Malformed-image corpus” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M02.03-C090-T09 · Reproduction review:** Have the “Malformed-image corpus” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M02.03-C090-T10 · Acceptance linkage:** Link the “Malformed-image corpus” evidence to its parent and UC-M02.03 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 10. Layout evidence

**Source delivery:** Publish the accepted image layout and effective memory permissions with its digest.

**Source invariant:** Layout evidence identifies the exact image and platform policy tested.

**Source negative case:** A layout report is reused after the linker script changes.

**Source bounded quantities:** Report bytes and evidence retention.

### UC-M02.03-C091 · Contract

**Original checklist item:** Specify layout evidence inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M02.03-C091-T01 · Scope statement:** Draft the operation boundary for “Layout evidence” within Linker, image layout and permissions; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M02.03-C091-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Layout evidence”; record each producer, representation and missing-value meaning.
- [ ] **UC-M02.03-C091-T03 · Output inventory:** List the outputs of “Layout evidence” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M02.03-C091-T04 · Field dictionary:** Create a field-and-term dictionary for “Layout evidence”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M02.03-C091-T05 · Prerequisite contract:** Map “Layout evidence” to the source component prerequisites (UC-M02.02); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M02.03-C091-T06 · Authority map:** Identify who may produce, change and consume “Layout evidence”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M02.03-C091-T07 · Invariant clause:** Add a normative clause for “Layout evidence” that preserves “Layout evidence identifies the exact image and platform policy tested”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M02.03-C091-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Layout evidence”; include the source counterexample “A layout report is reused after the linker script changes” and the intended safe disposition.
- [ ] **UC-M02.03-C091-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Report bytes and evidence retention” in the “Layout evidence” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M02.03-C091-T10 · Contract review:** Review the “Layout evidence” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M02.03-C092 · Delivery

**Original checklist item:** Publish the accepted image layout and effective memory permissions with its digest.

- [ ] **UC-M02.03-C092-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Layout evidence”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M02.03-C092-T02 · Change plan:** Break the source delivery for “Layout evidence” into concrete edit targets and reviewable outputs; keep the UC-M02.03 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M02.03-C092-T03 · Core artifact:** Create the “Layout evidence” output artifact for this source instruction: Publish the accepted image layout and effective memory permissions with its digest.
- [ ] **UC-M02.03-C092-T04 · Concrete realization:** Populate the “Layout evidence” artifact from identified observations; keep unknown, failed and unexecuted results distinct and exclude unapproved sensitive material.
- [ ] **UC-M02.03-C092-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Layout evidence” needed to preserve “Layout evidence identifies the exact image and platform policy tested”; record an enforcement gap where only a model exists.
- [ ] **UC-M02.03-C092-T06 · Dependency connection:** Connect the “Layout evidence” implementation to the linker script, image validator and selected backend loader; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M02.03-C092-T07 · Resource behavior:** Account for “Report bytes and evidence retention” in “Layout evidence”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M02.03-C092-T08 · Delivery check:** Run the smallest real “Layout evidence” path and its adverse fixture “A layout report is reused after the linker script changes”; retain actual output, state effects and final disposition.
- [ ] **UC-M02.03-C092-T09 · Patch review:** Review the “Layout evidence” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M02.03-C092-T10 · Delivery handoff:** Publish the “Layout evidence” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M02.03-C093 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Layout evidence identifies the exact image and platform policy tested. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M02.03-C093-T01 · Named property:** Create a stable property/check name under this parent for “Layout evidence”; copy its required invariant exactly: “Layout evidence identifies the exact image and platform policy tested”.
- [ ] **UC-M02.03-C093-T02 · Observable terms:** Define each term in the “Layout evidence” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M02.03-C093-T03 · Precondition set:** List the preconditions under which “Layout evidence identifies the exact image and platform policy tested” must hold for “Layout evidence”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M02.03-C093-T04 · Transition coverage:** Map the “Layout evidence” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M02.03-C093-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Layout evidence”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M02.03-C093-T06 · Satisfying fixture:** Create a concrete “Layout evidence” case that satisfies “Layout evidence identifies the exact image and platform policy tested”; record its expected observation before running the assertion or review.
- [ ] **UC-M02.03-C093-T07 · Violating fixture:** Create the source counterexample “A layout report is reused after the linker script changes” for “Layout evidence”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M02.03-C093-T08 · Enforcement evidence:** Exercise the “Layout evidence” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M02.03-C093-T09 · Regression linkage:** Link the “Layout evidence” property to changes in the linker script, image validator and selected backend loader; record which dependency or contract changes require rerunning it.
- [ ] **UC-M02.03-C093-T10 · Property disposition:** Compare the satisfying and violating “Layout evidence” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M02.03-C094 · Integration

**Original checklist item:** Integrate layout evidence with the linker script, image validator and selected backend loader; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M02.03-C094-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Layout evidence” across the linker script, image validator and selected backend loader; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M02.03-C094-T02 · Field mapping:** Map every “Layout evidence” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M02.03-C094-T03 · Prerequisite identities:** Record the actual prerequisites for “Layout evidence” (source dependency list: UC-M02.02); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M02.03-C094-T04 · Ownership agreement:** Specify who owns “Layout evidence” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M02.03-C094-T05 · Handoff implementation:** Connect “Layout evidence” through the mapped seam using the real adapter or explicit specification reference; preserve “Layout evidence identifies the exact image and platform policy tested” across the handoff.
- [ ] **UC-M02.03-C094-T06 · Absent-input case:** Omit one required “Layout evidence” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M02.03-C094-T07 · Stale-input case:** Supply an outdated “Layout evidence” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M02.03-C094-T08 · Incompatible-input case:** Supply an incompatible “Layout evidence” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M02.03-C094-T09 · Valid integration trace:** Run a valid “Layout evidence” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M02.03-C094-T10 · Seam review:** Reconcile the “Layout evidence” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M02.03-C095 · Valid-case test

**Original checklist item:** Run a valid-path fixture for layout evidence; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M02.03-C095-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Layout evidence” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M02.03-C095-T02 · Expected-result oracle:** Specify the “Layout evidence” expected result independently of the implementation output; include the property “Layout evidence identifies the exact image and platform policy tested” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M02.03-C095-T03 · Fixture material:** Create the concrete “Layout evidence” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M02.03-C095-T04 · Target preparation:** Prepare the “Layout evidence” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M02.03-C095-T05 · Initial-state record:** Record the initial “Layout evidence” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M02.03-C095-T06 · Valid-path execution:** Execute the “Layout evidence” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M02.03-C095-T07 · Outcome comparison:** Compare every declared “Layout evidence” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M02.03-C095-T08 · State and bounds check:** Inspect the “Layout evidence” ownership/state effects and actual use of “Report bytes and evidence retention”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M02.03-C095-T09 · Repeatability check:** Repeat the same “Layout evidence” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M02.03-C095-T10 · Positive evidence:** Attach the “Layout evidence” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M02.03-C096 · Negative test

**Original checklist item:** Negative case: A layout report is reused after the linker script changes. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M02.03-C096-T01 · Adverse-case definition:** Create a test record for the exact “Layout evidence” source counterexample: “A layout report is reused after the linker script changes”; state which precondition or invariant it challenges.
- [ ] **UC-M02.03-C096-T02 · Safe fixture boundary:** Define the contained test boundary for “Layout evidence”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M02.03-C096-T03 · Valid control:** Construct a valid “Layout evidence” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M02.03-C096-T04 · Minimal adverse input:** Derive the “Layout evidence” adverse fixture from the control with the smallest documented change needed to reproduce “A layout report is reused after the linker script changes”; retain that change as reproducible data.
- [ ] **UC-M02.03-C096-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Layout evidence”; require “Layout evidence identifies the exact image and platform policy tested” and forbid a false-success verdict.
- [ ] **UC-M02.03-C096-T06 · Adverse execution:** Exercise the “Layout evidence” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M02.03-C096-T07 · Effect inspection:** Inspect “Layout evidence” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M02.03-C096-T08 · Refusal versus failure:** Confirm the “Layout evidence” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M02.03-C096-T09 · Reset and retention:** Restore only the disposable “Layout evidence” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M02.03-C096-T10 · Negative regression:** Register the “Layout evidence” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M02.03-C097 · Change / failure test

**Original checklist item:** Exercise layout evidence when a layout or protection setting changes between image construction and loading; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M02.03-C097-T01 · Scenario record:** Write the “Layout evidence” change/failure scenario exactly as supplied: a layout or protection setting changes between image construction and loading; identify the property that must remain true: “Layout evidence identifies the exact image and platform policy tested”.
- [ ] **UC-M02.03-C097-T02 · Baseline capture:** Create a known-valid “Layout evidence” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M02.03-C097-T03 · Injection map:** Locate the “Layout evidence” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M02.03-C097-T04 · Disposition oracle:** Define the legal intermediate and final “Layout evidence” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M02.03-C097-T05 · Controlled trigger:** Introduce the controlled “Layout evidence” scenario in the disposable fixture: a layout or protection setting changes between image construction and loading; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M02.03-C097-T06 · Intermediate inspection:** Inspect the “Layout evidence” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M02.03-C097-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Layout evidence”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M02.03-C097-T08 · Stale-evidence cleanup:** Invalidate superseded “Layout evidence” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M02.03-C097-T09 · Repeat and compare:** Repeat the selected “Layout evidence” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M02.03-C097-T10 · Failure evidence:** Publish the “Layout evidence” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M02.03-C098 · Bounds

**Original checklist item:** Choose, document and test limits for report bytes and evidence retention; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M02.03-C098-T01 · Quantity inventory:** Create a measurement inventory for “Layout evidence”: “Report bytes and evidence retention”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M02.03-C098-T02 · Measurement method:** Choose how to observe each “Layout evidence” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M02.03-C098-T03 · Budget decision:** Select justified resource and input limits for “Layout evidence”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M02.03-C098-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Layout evidence” cases for “Report bytes and evidence retention”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M02.03-C098-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Layout evidence” limit; preserve “Layout evidence identifies the exact image and platform policy tested”.
- [ ] **UC-M02.03-C098-T06 · Normal measurement:** Run or review the normal “Layout evidence” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M02.03-C098-T07 · At-limit measurement:** Exercise the “Layout evidence” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M02.03-C098-T08 · Over-limit measurement:** Exercise the “Layout evidence” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M02.03-C098-T09 · Uncovered-scope report:** List the “Layout evidence” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M02.03-C098-T10 · Limit evidence:** Publish the selected “Layout evidence” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M02.03-C099 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for layout evidence with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M02.03-C099-T01 · Event inventory:** List the “Layout evidence” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M02.03-C099-T02 · Diagnostic schema:** Define nonsecret fields for “Layout evidence” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M02.03-C099-T03 · Failure mapping:** Map each documented “Layout evidence” refusal or error to a diagnostic outcome; include “A layout report is reused after the linker script changes” and prohibit conversion into a success message.
- [ ] **UC-M02.03-C099-T04 · Emission path:** Add the “Layout evidence” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M02.03-C099-T05 · Redaction check:** Test “Layout evidence” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M02.03-C099-T06 · Output budget:** Set and exercise bounded “Layout evidence” message size, rate and retention compatible with “Report bytes and evidence retention”; define truncation behavior that preserves the final reason.
- [ ] **UC-M02.03-C099-T07 · Success/refusal fixtures:** Capture “Layout evidence” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M02.03-C099-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Layout evidence” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M02.03-C099-T09 · Operator review:** Read the “Layout evidence” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M02.03-C099-T10 · Diagnostic evidence:** Publish redacted “Layout evidence” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M02.03-C100 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for layout evidence; label unexecuted checks as untested.

- [ ] **UC-M02.03-C100-T01 · Evidence inventory:** List the “Layout evidence” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M02.03-C100-T02 · Artifact references:** Record the exact “Layout evidence” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M02.03-C100-T03 · Fixture references:** Attach the “Layout evidence” fixture IDs, input identities and oracle definition; preserve the source counterexample “A layout report is reused after the linker script changes” as a distinct evidence case.
- [ ] **UC-M02.03-C100-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Layout evidence”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M02.03-C100-T05 · Environment record:** Record the actual “Layout evidence” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M02.03-C100-T06 · Expected versus observed:** Pair every “Layout evidence” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M02.03-C100-T07 · Failure and limit records:** Attach “Layout evidence” change/failure and bounds evidence where required; include uncovered “Report bytes and evidence retention” and unresolved violations of “Layout evidence identifies the exact image and platform policy tested”.
- [ ] **UC-M02.03-C100-T08 · Evidence hygiene:** Check the “Layout evidence” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M02.03-C100-T09 · Reproduction review:** Have the “Layout evidence” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M02.03-C100-T10 · Acceptance linkage:** Link the “Layout evidence” evidence to its parent and UC-M02.03 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

