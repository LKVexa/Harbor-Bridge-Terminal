# UC-M02.02 — Boot ABI and startup path

**To-Do Pack 2.0.0 · Baseline UC-2.2.0 · 100 parent checks × 10 subtasks = 1,000 to-dos**

[Master index](../../INDEX.md) · [Workstream index](../../w/02.md)

| Field | Preserved source value |
|---|---|
| Workstream | 02. Bootable unikernel guest |
| Milestone | B |
| Priority | P0 |
| Source assessment | MISSING |
| Scope | core or selected profile |
| Dependencies | [UC-M02.01](../02/UC-M02.01.md) |
| Source checklist pack | 1.0.0 |
| Original reference labels | [S1], [S2], [S3]. |

## Original requirement

Implement the selected architecture entry point, boot information validation, stack setup and platform startup sequence.

**Original acceptance criterion:** The chosen VMM loads the image and reaches a guest-originated ready signal without a conventional guest OS boot.

**Source trace:** Original checklist `UC100/c/02/UC-M02.02.md` inside [s/checklists.zip](../../s/checklists.zip); exact parent records in [data/parents.jsonl](../../data/parents.jsonl). Original roadmap lines 155–165 are preserved in [s/roadmap.md](../../s/roadmap.md).

## How to use these lists

Every parent statement below is preserved verbatim. Its ten child tasks are proposed decomposition, not implemented capabilities or executed tests. Child IDs append `-T01` through `-T10` to the original parent ID. All begin unchecked / `TODO`. Design/review evidence does not establish runtime enforcement; observe the actual selected target where the parent requires it.

The source dependency graph and selected release profile determine applicability. The numbered child sequence is a local working order, not an added hard dependency graph. An unselected optional feature needs a recorded not-applicable rationale; missing prerequisites for selected work remain blockers. Numerical budgets, backends and trust mechanisms remain decisions unless fixed by the source. Test hostile cases only with synthetic inputs in authorized disposable environments.

## 01. Architecture entry point

**Source delivery:** Implement the selected architecture's entry symbol and initial control transfer.

**Source invariant:** Execution starts at the documented guest entry point.

**Source negative case:** The image specifies an entry address outside its executable region.

**Source bounded quantities:** Entry metadata size and startup instruction budget.

### UC-M02.02-C001 · Contract

**Original checklist item:** Specify architecture entry point inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M02.02-C001-T01 · Scope statement:** Draft the operation boundary for “Architecture entry point” within Boot ABI and startup path; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M02.02-C001-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Architecture entry point”; record each producer, representation and missing-value meaning.
- [ ] **UC-M02.02-C001-T03 · Output inventory:** List the outputs of “Architecture entry point” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M02.02-C001-T04 · Field dictionary:** Create a field-and-term dictionary for “Architecture entry point”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M02.02-C001-T05 · Prerequisite contract:** Map “Architecture entry point” to the source component prerequisites (UC-M02.01); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M02.02-C001-T06 · Authority map:** Identify who may produce, change and consume “Architecture entry point”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M02.02-C001-T07 · Invariant clause:** Add a normative clause for “Architecture entry point” that preserves “Execution starts at the documented guest entry point”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M02.02-C001-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Architecture entry point”; include the source counterexample “The image specifies an entry address outside its executable region” and the intended safe disposition.
- [ ] **UC-M02.02-C001-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Entry metadata size and startup instruction budget” in the “Architecture entry point” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M02.02-C001-T10 · Contract review:** Review the “Architecture entry point” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M02.02-C002 · Delivery

**Original checklist item:** Implement the selected architecture's entry symbol and initial control transfer.

- [ ] **UC-M02.02-C002-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Architecture entry point”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M02.02-C002-T02 · Change plan:** Break the source delivery for “Architecture entry point” into concrete edit targets and reviewable outputs; keep the UC-M02.02 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M02.02-C002-T03 · Core artifact:** Implement the smallest selected-profile change for “Architecture entry point” that realizes this source instruction: Implement the selected architecture's entry symbol and initial control transfer.
- [ ] **UC-M02.02-C002-T04 · Concrete realization:** Trace “Architecture entry point” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M02.02-C002-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Architecture entry point” needed to preserve “Execution starts at the documented guest entry point”; record an enforcement gap where only a model exists.
- [ ] **UC-M02.02-C002-T06 · Dependency connection:** Connect the “Architecture entry point” implementation to the selected loader, guest startup sequence and ready-signal receiver; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M02.02-C002-T07 · Resource behavior:** Account for “Entry metadata size and startup instruction budget” in “Architecture entry point”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M02.02-C002-T08 · Delivery check:** Run the smallest real “Architecture entry point” path and its adverse fixture “The image specifies an entry address outside its executable region”; retain actual output, state effects and final disposition.
- [ ] **UC-M02.02-C002-T09 · Patch review:** Review the “Architecture entry point” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M02.02-C002-T10 · Delivery handoff:** Publish the “Architecture entry point” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M02.02-C003 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Execution starts at the documented guest entry point. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M02.02-C003-T01 · Named property:** Create a stable property/check name under this parent for “Architecture entry point”; copy its required invariant exactly: “Execution starts at the documented guest entry point”.
- [ ] **UC-M02.02-C003-T02 · Observable terms:** Define each term in the “Architecture entry point” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M02.02-C003-T03 · Precondition set:** List the preconditions under which “Execution starts at the documented guest entry point” must hold for “Architecture entry point”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M02.02-C003-T04 · Transition coverage:** Map the “Architecture entry point” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M02.02-C003-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Architecture entry point”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M02.02-C003-T06 · Satisfying fixture:** Create a concrete “Architecture entry point” case that satisfies “Execution starts at the documented guest entry point”; record its expected observation before running the assertion or review.
- [ ] **UC-M02.02-C003-T07 · Violating fixture:** Create the source counterexample “The image specifies an entry address outside its executable region” for “Architecture entry point”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M02.02-C003-T08 · Enforcement evidence:** Exercise the “Architecture entry point” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M02.02-C003-T09 · Regression linkage:** Link the “Architecture entry point” property to changes in the selected loader, guest startup sequence and ready-signal receiver; record which dependency or contract changes require rerunning it.
- [ ] **UC-M02.02-C003-T10 · Property disposition:** Compare the satisfying and violating “Architecture entry point” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M02.02-C004 · Integration

**Original checklist item:** Integrate architecture entry point with the selected loader, guest startup sequence and ready-signal receiver; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M02.02-C004-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Architecture entry point” across the selected loader, guest startup sequence and ready-signal receiver; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M02.02-C004-T02 · Field mapping:** Map every “Architecture entry point” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M02.02-C004-T03 · Prerequisite identities:** Record the actual prerequisites for “Architecture entry point” (source dependency list: UC-M02.01); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M02.02-C004-T04 · Ownership agreement:** Specify who owns “Architecture entry point” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M02.02-C004-T05 · Handoff implementation:** Connect “Architecture entry point” through the mapped seam using the real adapter or explicit specification reference; preserve “Execution starts at the documented guest entry point” across the handoff.
- [ ] **UC-M02.02-C004-T06 · Absent-input case:** Omit one required “Architecture entry point” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M02.02-C004-T07 · Stale-input case:** Supply an outdated “Architecture entry point” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M02.02-C004-T08 · Incompatible-input case:** Supply an incompatible “Architecture entry point” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M02.02-C004-T09 · Valid integration trace:** Run a valid “Architecture entry point” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M02.02-C004-T10 · Seam review:** Reconcile the “Architecture entry point” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M02.02-C005 · Valid-case test

**Original checklist item:** Run a valid-path fixture for architecture entry point; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M02.02-C005-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Architecture entry point” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M02.02-C005-T02 · Expected-result oracle:** Specify the “Architecture entry point” expected result independently of the implementation output; include the property “Execution starts at the documented guest entry point” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M02.02-C005-T03 · Fixture material:** Create the concrete “Architecture entry point” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M02.02-C005-T04 · Target preparation:** Prepare the “Architecture entry point” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M02.02-C005-T05 · Initial-state record:** Record the initial “Architecture entry point” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M02.02-C005-T06 · Valid-path execution:** Execute the “Architecture entry point” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M02.02-C005-T07 · Outcome comparison:** Compare every declared “Architecture entry point” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M02.02-C005-T08 · State and bounds check:** Inspect the “Architecture entry point” ownership/state effects and actual use of “Entry metadata size and startup instruction budget”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M02.02-C005-T09 · Repeatability check:** Repeat the same “Architecture entry point” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M02.02-C005-T10 · Positive evidence:** Attach the “Architecture entry point” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M02.02-C006 · Negative test

**Original checklist item:** Negative case: The image specifies an entry address outside its executable region. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M02.02-C006-T01 · Adverse-case definition:** Create a test record for the exact “Architecture entry point” source counterexample: “The image specifies an entry address outside its executable region”; state which precondition or invariant it challenges.
- [ ] **UC-M02.02-C006-T02 · Safe fixture boundary:** Define the contained test boundary for “Architecture entry point”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M02.02-C006-T03 · Valid control:** Construct a valid “Architecture entry point” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M02.02-C006-T04 · Minimal adverse input:** Derive the “Architecture entry point” adverse fixture from the control with the smallest documented change needed to reproduce “The image specifies an entry address outside its executable region”; retain that change as reproducible data.
- [ ] **UC-M02.02-C006-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Architecture entry point”; require “Execution starts at the documented guest entry point” and forbid a false-success verdict.
- [ ] **UC-M02.02-C006-T06 · Adverse execution:** Exercise the “Architecture entry point” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M02.02-C006-T07 · Effect inspection:** Inspect “Architecture entry point” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M02.02-C006-T08 · Refusal versus failure:** Confirm the “Architecture entry point” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M02.02-C006-T09 · Reset and retention:** Restore only the disposable “Architecture entry point” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M02.02-C006-T10 · Negative regression:** Register the “Architecture entry point” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M02.02-C007 · Change / failure test

**Original checklist item:** Exercise architecture entry point when startup is interrupted before guest readiness has been emitted; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M02.02-C007-T01 · Scenario record:** Write the “Architecture entry point” change/failure scenario exactly as supplied: startup is interrupted before guest readiness has been emitted; identify the property that must remain true: “Execution starts at the documented guest entry point”.
- [ ] **UC-M02.02-C007-T02 · Baseline capture:** Create a known-valid “Architecture entry point” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M02.02-C007-T03 · Injection map:** Locate the “Architecture entry point” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M02.02-C007-T04 · Disposition oracle:** Define the legal intermediate and final “Architecture entry point” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M02.02-C007-T05 · Controlled trigger:** Introduce the controlled “Architecture entry point” scenario in the disposable fixture: startup is interrupted before guest readiness has been emitted; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M02.02-C007-T06 · Intermediate inspection:** Inspect the “Architecture entry point” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M02.02-C007-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Architecture entry point”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M02.02-C007-T08 · Stale-evidence cleanup:** Invalidate superseded “Architecture entry point” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M02.02-C007-T09 · Repeat and compare:** Repeat the selected “Architecture entry point” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M02.02-C007-T10 · Failure evidence:** Publish the “Architecture entry point” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M02.02-C008 · Bounds

**Original checklist item:** Choose, document and test limits for entry metadata size and startup instruction budget; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M02.02-C008-T01 · Quantity inventory:** Create a measurement inventory for “Architecture entry point”: “Entry metadata size and startup instruction budget”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M02.02-C008-T02 · Measurement method:** Choose how to observe each “Architecture entry point” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M02.02-C008-T03 · Budget decision:** Select justified resource and input limits for “Architecture entry point”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M02.02-C008-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Architecture entry point” cases for “Entry metadata size and startup instruction budget”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M02.02-C008-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Architecture entry point” limit; preserve “Execution starts at the documented guest entry point”.
- [ ] **UC-M02.02-C008-T06 · Normal measurement:** Run or review the normal “Architecture entry point” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M02.02-C008-T07 · At-limit measurement:** Exercise the “Architecture entry point” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M02.02-C008-T08 · Over-limit measurement:** Exercise the “Architecture entry point” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M02.02-C008-T09 · Uncovered-scope report:** List the “Architecture entry point” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M02.02-C008-T10 · Limit evidence:** Publish the selected “Architecture entry point” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M02.02-C009 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for architecture entry point with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M02.02-C009-T01 · Event inventory:** List the “Architecture entry point” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M02.02-C009-T02 · Diagnostic schema:** Define nonsecret fields for “Architecture entry point” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M02.02-C009-T03 · Failure mapping:** Map each documented “Architecture entry point” refusal or error to a diagnostic outcome; include “The image specifies an entry address outside its executable region” and prohibit conversion into a success message.
- [ ] **UC-M02.02-C009-T04 · Emission path:** Add the “Architecture entry point” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M02.02-C009-T05 · Redaction check:** Test “Architecture entry point” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M02.02-C009-T06 · Output budget:** Set and exercise bounded “Architecture entry point” message size, rate and retention compatible with “Entry metadata size and startup instruction budget”; define truncation behavior that preserves the final reason.
- [ ] **UC-M02.02-C009-T07 · Success/refusal fixtures:** Capture “Architecture entry point” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M02.02-C009-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Architecture entry point” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M02.02-C009-T09 · Operator review:** Read the “Architecture entry point” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M02.02-C009-T10 · Diagnostic evidence:** Publish redacted “Architecture entry point” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M02.02-C010 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for architecture entry point; label unexecuted checks as untested.

- [ ] **UC-M02.02-C010-T01 · Evidence inventory:** List the “Architecture entry point” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M02.02-C010-T02 · Artifact references:** Record the exact “Architecture entry point” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M02.02-C010-T03 · Fixture references:** Attach the “Architecture entry point” fixture IDs, input identities and oracle definition; preserve the source counterexample “The image specifies an entry address outside its executable region” as a distinct evidence case.
- [ ] **UC-M02.02-C010-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Architecture entry point”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M02.02-C010-T05 · Environment record:** Record the actual “Architecture entry point” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M02.02-C010-T06 · Expected versus observed:** Pair every “Architecture entry point” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M02.02-C010-T07 · Failure and limit records:** Attach “Architecture entry point” change/failure and bounds evidence where required; include uncovered “Entry metadata size and startup instruction budget” and unresolved violations of “Execution starts at the documented guest entry point”.
- [ ] **UC-M02.02-C010-T08 · Evidence hygiene:** Check the “Architecture entry point” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M02.02-C010-T09 · Reproduction review:** Have the “Architecture entry point” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M02.02-C010-T10 · Acceptance linkage:** Link the “Architecture entry point” evidence to its parent and UC-M02.02 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 02. Boot information layout

**Source delivery:** Define the supported boot-information structures and version fields.

**Source invariant:** Boot data has one validated representation before use.

**Source negative case:** The loader supplies an unsupported boot-information version.

**Source bounded quantities:** Boot structure size and descriptor count.

### UC-M02.02-C011 · Contract

**Original checklist item:** Specify boot information layout inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M02.02-C011-T01 · Scope statement:** Draft the operation boundary for “Boot information layout” within Boot ABI and startup path; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M02.02-C011-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Boot information layout”; record each producer, representation and missing-value meaning.
- [ ] **UC-M02.02-C011-T03 · Output inventory:** List the outputs of “Boot information layout” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M02.02-C011-T04 · Field dictionary:** Create a field-and-term dictionary for “Boot information layout”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M02.02-C011-T05 · Prerequisite contract:** Map “Boot information layout” to the source component prerequisites (UC-M02.01); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M02.02-C011-T06 · Authority map:** Identify who may produce, change and consume “Boot information layout”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M02.02-C011-T07 · Invariant clause:** Add a normative clause for “Boot information layout” that preserves “Boot data has one validated representation before use”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M02.02-C011-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Boot information layout”; include the source counterexample “The loader supplies an unsupported boot-information version” and the intended safe disposition.
- [ ] **UC-M02.02-C011-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Boot structure size and descriptor count” in the “Boot information layout” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M02.02-C011-T10 · Contract review:** Review the “Boot information layout” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M02.02-C012 · Delivery

**Original checklist item:** Define the supported boot-information structures and version fields.

- [ ] **UC-M02.02-C012-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Boot information layout”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M02.02-C012-T02 · Change plan:** Break the source delivery for “Boot information layout” into concrete edit targets and reviewable outputs; keep the UC-M02.02 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M02.02-C012-T03 · Core artifact:** Create the “Boot information layout” model, schema or inventory that realizes this source instruction: Define the supported boot-information structures and version fields.
- [ ] **UC-M02.02-C012-T04 · Concrete realization:** Populate “Boot information layout” with one concrete worked case; map every required entity or field to its source and flag any unmapped entry.
- [ ] **UC-M02.02-C012-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Boot information layout” needed to preserve “Boot data has one validated representation before use”; record an enforcement gap where only a model exists.
- [ ] **UC-M02.02-C012-T06 · Dependency connection:** Connect the “Boot information layout” implementation to the selected loader, guest startup sequence and ready-signal receiver; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M02.02-C012-T07 · Resource behavior:** Account for “Boot structure size and descriptor count” in “Boot information layout”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M02.02-C012-T08 · Delivery check:** Run the smallest real “Boot information layout” path and its adverse fixture “The loader supplies an unsupported boot-information version”; retain actual output, state effects and final disposition.
- [ ] **UC-M02.02-C012-T09 · Patch review:** Review the “Boot information layout” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M02.02-C012-T10 · Delivery handoff:** Publish the “Boot information layout” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M02.02-C013 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Boot data has one validated representation before use. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M02.02-C013-T01 · Named property:** Create a stable property/check name under this parent for “Boot information layout”; copy its required invariant exactly: “Boot data has one validated representation before use”.
- [ ] **UC-M02.02-C013-T02 · Observable terms:** Define each term in the “Boot information layout” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M02.02-C013-T03 · Precondition set:** List the preconditions under which “Boot data has one validated representation before use” must hold for “Boot information layout”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M02.02-C013-T04 · Transition coverage:** Map the “Boot information layout” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M02.02-C013-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Boot information layout”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M02.02-C013-T06 · Satisfying fixture:** Create a concrete “Boot information layout” case that satisfies “Boot data has one validated representation before use”; record its expected observation before running the assertion or review.
- [ ] **UC-M02.02-C013-T07 · Violating fixture:** Create the source counterexample “The loader supplies an unsupported boot-information version” for “Boot information layout”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M02.02-C013-T08 · Enforcement evidence:** Exercise the “Boot information layout” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M02.02-C013-T09 · Regression linkage:** Link the “Boot information layout” property to changes in the selected loader, guest startup sequence and ready-signal receiver; record which dependency or contract changes require rerunning it.
- [ ] **UC-M02.02-C013-T10 · Property disposition:** Compare the satisfying and violating “Boot information layout” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M02.02-C014 · Integration

**Original checklist item:** Integrate boot information layout with the selected loader, guest startup sequence and ready-signal receiver; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M02.02-C014-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Boot information layout” across the selected loader, guest startup sequence and ready-signal receiver; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M02.02-C014-T02 · Field mapping:** Map every “Boot information layout” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M02.02-C014-T03 · Prerequisite identities:** Record the actual prerequisites for “Boot information layout” (source dependency list: UC-M02.01); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M02.02-C014-T04 · Ownership agreement:** Specify who owns “Boot information layout” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M02.02-C014-T05 · Handoff implementation:** Connect “Boot information layout” through the mapped seam using the real adapter or explicit specification reference; preserve “Boot data has one validated representation before use” across the handoff.
- [ ] **UC-M02.02-C014-T06 · Absent-input case:** Omit one required “Boot information layout” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M02.02-C014-T07 · Stale-input case:** Supply an outdated “Boot information layout” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M02.02-C014-T08 · Incompatible-input case:** Supply an incompatible “Boot information layout” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M02.02-C014-T09 · Valid integration trace:** Run a valid “Boot information layout” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M02.02-C014-T10 · Seam review:** Reconcile the “Boot information layout” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M02.02-C015 · Valid-case test

**Original checklist item:** Run a valid-path fixture for boot information layout; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M02.02-C015-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Boot information layout” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M02.02-C015-T02 · Expected-result oracle:** Specify the “Boot information layout” expected result independently of the implementation output; include the property “Boot data has one validated representation before use” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M02.02-C015-T03 · Fixture material:** Create the concrete “Boot information layout” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M02.02-C015-T04 · Target preparation:** Prepare the “Boot information layout” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M02.02-C015-T05 · Initial-state record:** Record the initial “Boot information layout” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M02.02-C015-T06 · Valid-path execution:** Execute the “Boot information layout” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M02.02-C015-T07 · Outcome comparison:** Compare every declared “Boot information layout” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M02.02-C015-T08 · State and bounds check:** Inspect the “Boot information layout” ownership/state effects and actual use of “Boot structure size and descriptor count”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M02.02-C015-T09 · Repeatability check:** Repeat the same “Boot information layout” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M02.02-C015-T10 · Positive evidence:** Attach the “Boot information layout” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M02.02-C016 · Negative test

**Original checklist item:** Negative case: The loader supplies an unsupported boot-information version. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M02.02-C016-T01 · Adverse-case definition:** Create a test record for the exact “Boot information layout” source counterexample: “The loader supplies an unsupported boot-information version”; state which precondition or invariant it challenges.
- [ ] **UC-M02.02-C016-T02 · Safe fixture boundary:** Define the contained test boundary for “Boot information layout”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M02.02-C016-T03 · Valid control:** Construct a valid “Boot information layout” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M02.02-C016-T04 · Minimal adverse input:** Derive the “Boot information layout” adverse fixture from the control with the smallest documented change needed to reproduce “The loader supplies an unsupported boot-information version”; retain that change as reproducible data.
- [ ] **UC-M02.02-C016-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Boot information layout”; require “Boot data has one validated representation before use” and forbid a false-success verdict.
- [ ] **UC-M02.02-C016-T06 · Adverse execution:** Exercise the “Boot information layout” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M02.02-C016-T07 · Effect inspection:** Inspect “Boot information layout” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M02.02-C016-T08 · Refusal versus failure:** Confirm the “Boot information layout” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M02.02-C016-T09 · Reset and retention:** Restore only the disposable “Boot information layout” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M02.02-C016-T10 · Negative regression:** Register the “Boot information layout” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M02.02-C017 · Change / failure test

**Original checklist item:** Exercise boot information layout when startup is interrupted before guest readiness has been emitted; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M02.02-C017-T01 · Scenario record:** Write the “Boot information layout” change/failure scenario exactly as supplied: startup is interrupted before guest readiness has been emitted; identify the property that must remain true: “Boot data has one validated representation before use”.
- [ ] **UC-M02.02-C017-T02 · Baseline capture:** Create a known-valid “Boot information layout” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M02.02-C017-T03 · Injection map:** Locate the “Boot information layout” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M02.02-C017-T04 · Disposition oracle:** Define the legal intermediate and final “Boot information layout” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M02.02-C017-T05 · Controlled trigger:** Introduce the controlled “Boot information layout” scenario in the disposable fixture: startup is interrupted before guest readiness has been emitted; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M02.02-C017-T06 · Intermediate inspection:** Inspect the “Boot information layout” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M02.02-C017-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Boot information layout”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M02.02-C017-T08 · Stale-evidence cleanup:** Invalidate superseded “Boot information layout” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M02.02-C017-T09 · Repeat and compare:** Repeat the selected “Boot information layout” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M02.02-C017-T10 · Failure evidence:** Publish the “Boot information layout” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M02.02-C018 · Bounds

**Original checklist item:** Choose, document and test limits for boot structure size and descriptor count; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M02.02-C018-T01 · Quantity inventory:** Create a measurement inventory for “Boot information layout”: “Boot structure size and descriptor count”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M02.02-C018-T02 · Measurement method:** Choose how to observe each “Boot information layout” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M02.02-C018-T03 · Budget decision:** Select justified resource and input limits for “Boot information layout”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M02.02-C018-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Boot information layout” cases for “Boot structure size and descriptor count”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M02.02-C018-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Boot information layout” limit; preserve “Boot data has one validated representation before use”.
- [ ] **UC-M02.02-C018-T06 · Normal measurement:** Run or review the normal “Boot information layout” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M02.02-C018-T07 · At-limit measurement:** Exercise the “Boot information layout” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M02.02-C018-T08 · Over-limit measurement:** Exercise the “Boot information layout” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M02.02-C018-T09 · Uncovered-scope report:** List the “Boot information layout” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M02.02-C018-T10 · Limit evidence:** Publish the selected “Boot information layout” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M02.02-C019 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for boot information layout with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M02.02-C019-T01 · Event inventory:** List the “Boot information layout” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M02.02-C019-T02 · Diagnostic schema:** Define nonsecret fields for “Boot information layout” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M02.02-C019-T03 · Failure mapping:** Map each documented “Boot information layout” refusal or error to a diagnostic outcome; include “The loader supplies an unsupported boot-information version” and prohibit conversion into a success message.
- [ ] **UC-M02.02-C019-T04 · Emission path:** Add the “Boot information layout” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M02.02-C019-T05 · Redaction check:** Test “Boot information layout” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M02.02-C019-T06 · Output budget:** Set and exercise bounded “Boot information layout” message size, rate and retention compatible with “Boot structure size and descriptor count”; define truncation behavior that preserves the final reason.
- [ ] **UC-M02.02-C019-T07 · Success/refusal fixtures:** Capture “Boot information layout” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M02.02-C019-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Boot information layout” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M02.02-C019-T09 · Operator review:** Read the “Boot information layout” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M02.02-C019-T10 · Diagnostic evidence:** Publish redacted “Boot information layout” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M02.02-C020 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for boot information layout; label unexecuted checks as untested.

- [ ] **UC-M02.02-C020-T01 · Evidence inventory:** List the “Boot information layout” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M02.02-C020-T02 · Artifact references:** Record the exact “Boot information layout” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M02.02-C020-T03 · Fixture references:** Attach the “Boot information layout” fixture IDs, input identities and oracle definition; preserve the source counterexample “The loader supplies an unsupported boot-information version” as a distinct evidence case.
- [ ] **UC-M02.02-C020-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Boot information layout”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M02.02-C020-T05 · Environment record:** Record the actual “Boot information layout” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M02.02-C020-T06 · Expected versus observed:** Pair every “Boot information layout” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M02.02-C020-T07 · Failure and limit records:** Attach “Boot information layout” change/failure and bounds evidence where required; include uncovered “Boot structure size and descriptor count” and unresolved violations of “Boot data has one validated representation before use”.
- [ ] **UC-M02.02-C020-T08 · Evidence hygiene:** Check the “Boot information layout” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M02.02-C020-T09 · Reproduction review:** Have the “Boot information layout” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M02.02-C020-T10 · Acceptance linkage:** Link the “Boot information layout” evidence to its parent and UC-M02.02 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 03. Boot pointer validation

**Source delivery:** Validate addresses, lengths and alignments in boot-provided data.

**Source invariant:** Boot pointers remain within allowed guest-addressable regions.

**Source negative case:** A descriptor points beyond the supplied memory range.

**Source bounded quantities:** Pointer count and validation steps.

### UC-M02.02-C021 · Contract

**Original checklist item:** Specify boot pointer validation inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M02.02-C021-T01 · Scope statement:** Draft the operation boundary for “Boot pointer validation” within Boot ABI and startup path; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M02.02-C021-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Boot pointer validation”; record each producer, representation and missing-value meaning.
- [ ] **UC-M02.02-C021-T03 · Output inventory:** List the outputs of “Boot pointer validation” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M02.02-C021-T04 · Field dictionary:** Create a field-and-term dictionary for “Boot pointer validation”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M02.02-C021-T05 · Prerequisite contract:** Map “Boot pointer validation” to the source component prerequisites (UC-M02.01); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M02.02-C021-T06 · Authority map:** Identify who may produce, change and consume “Boot pointer validation”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M02.02-C021-T07 · Invariant clause:** Add a normative clause for “Boot pointer validation” that preserves “Boot pointers remain within allowed guest-addressable regions”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M02.02-C021-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Boot pointer validation”; include the source counterexample “A descriptor points beyond the supplied memory range” and the intended safe disposition.
- [ ] **UC-M02.02-C021-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Pointer count and validation steps” in the “Boot pointer validation” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M02.02-C021-T10 · Contract review:** Review the “Boot pointer validation” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M02.02-C022 · Delivery

**Original checklist item:** Validate addresses, lengths and alignments in boot-provided data.

- [ ] **UC-M02.02-C022-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Boot pointer validation”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M02.02-C022-T02 · Change plan:** Break the source delivery for “Boot pointer validation” into concrete edit targets and reviewable outputs; keep the UC-M02.02 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M02.02-C022-T03 · Core artifact:** Implement the smallest selected-profile change for “Boot pointer validation” that realizes this source instruction: Validate addresses, lengths and alignments in boot-provided data.
- [ ] **UC-M02.02-C022-T04 · Concrete realization:** Trace “Boot pointer validation” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M02.02-C022-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Boot pointer validation” needed to preserve “Boot pointers remain within allowed guest-addressable regions”; record an enforcement gap where only a model exists.
- [ ] **UC-M02.02-C022-T06 · Dependency connection:** Connect the “Boot pointer validation” implementation to the selected loader, guest startup sequence and ready-signal receiver; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M02.02-C022-T07 · Resource behavior:** Account for “Pointer count and validation steps” in “Boot pointer validation”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M02.02-C022-T08 · Delivery check:** Run the smallest real “Boot pointer validation” path and its adverse fixture “A descriptor points beyond the supplied memory range”; retain actual output, state effects and final disposition.
- [ ] **UC-M02.02-C022-T09 · Patch review:** Review the “Boot pointer validation” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M02.02-C022-T10 · Delivery handoff:** Publish the “Boot pointer validation” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M02.02-C023 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Boot pointers remain within allowed guest-addressable regions. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M02.02-C023-T01 · Named property:** Create a stable property/check name under this parent for “Boot pointer validation”; copy its required invariant exactly: “Boot pointers remain within allowed guest-addressable regions”.
- [ ] **UC-M02.02-C023-T02 · Observable terms:** Define each term in the “Boot pointer validation” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M02.02-C023-T03 · Precondition set:** List the preconditions under which “Boot pointers remain within allowed guest-addressable regions” must hold for “Boot pointer validation”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M02.02-C023-T04 · Transition coverage:** Map the “Boot pointer validation” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M02.02-C023-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Boot pointer validation”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M02.02-C023-T06 · Satisfying fixture:** Create a concrete “Boot pointer validation” case that satisfies “Boot pointers remain within allowed guest-addressable regions”; record its expected observation before running the assertion or review.
- [ ] **UC-M02.02-C023-T07 · Violating fixture:** Create the source counterexample “A descriptor points beyond the supplied memory range” for “Boot pointer validation”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M02.02-C023-T08 · Enforcement evidence:** Exercise the “Boot pointer validation” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M02.02-C023-T09 · Regression linkage:** Link the “Boot pointer validation” property to changes in the selected loader, guest startup sequence and ready-signal receiver; record which dependency or contract changes require rerunning it.
- [ ] **UC-M02.02-C023-T10 · Property disposition:** Compare the satisfying and violating “Boot pointer validation” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M02.02-C024 · Integration

**Original checklist item:** Integrate boot pointer validation with the selected loader, guest startup sequence and ready-signal receiver; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M02.02-C024-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Boot pointer validation” across the selected loader, guest startup sequence and ready-signal receiver; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M02.02-C024-T02 · Field mapping:** Map every “Boot pointer validation” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M02.02-C024-T03 · Prerequisite identities:** Record the actual prerequisites for “Boot pointer validation” (source dependency list: UC-M02.01); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M02.02-C024-T04 · Ownership agreement:** Specify who owns “Boot pointer validation” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M02.02-C024-T05 · Handoff implementation:** Connect “Boot pointer validation” through the mapped seam using the real adapter or explicit specification reference; preserve “Boot pointers remain within allowed guest-addressable regions” across the handoff.
- [ ] **UC-M02.02-C024-T06 · Absent-input case:** Omit one required “Boot pointer validation” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M02.02-C024-T07 · Stale-input case:** Supply an outdated “Boot pointer validation” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M02.02-C024-T08 · Incompatible-input case:** Supply an incompatible “Boot pointer validation” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M02.02-C024-T09 · Valid integration trace:** Run a valid “Boot pointer validation” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M02.02-C024-T10 · Seam review:** Reconcile the “Boot pointer validation” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M02.02-C025 · Valid-case test

**Original checklist item:** Run a valid-path fixture for boot pointer validation; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M02.02-C025-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Boot pointer validation” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M02.02-C025-T02 · Expected-result oracle:** Specify the “Boot pointer validation” expected result independently of the implementation output; include the property “Boot pointers remain within allowed guest-addressable regions” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M02.02-C025-T03 · Fixture material:** Create the concrete “Boot pointer validation” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M02.02-C025-T04 · Target preparation:** Prepare the “Boot pointer validation” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M02.02-C025-T05 · Initial-state record:** Record the initial “Boot pointer validation” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M02.02-C025-T06 · Valid-path execution:** Execute the “Boot pointer validation” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M02.02-C025-T07 · Outcome comparison:** Compare every declared “Boot pointer validation” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M02.02-C025-T08 · State and bounds check:** Inspect the “Boot pointer validation” ownership/state effects and actual use of “Pointer count and validation steps”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M02.02-C025-T09 · Repeatability check:** Repeat the same “Boot pointer validation” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M02.02-C025-T10 · Positive evidence:** Attach the “Boot pointer validation” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M02.02-C026 · Negative test

**Original checklist item:** Negative case: A descriptor points beyond the supplied memory range. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M02.02-C026-T01 · Adverse-case definition:** Create a test record for the exact “Boot pointer validation” source counterexample: “A descriptor points beyond the supplied memory range”; state which precondition or invariant it challenges.
- [ ] **UC-M02.02-C026-T02 · Safe fixture boundary:** Define the contained test boundary for “Boot pointer validation”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M02.02-C026-T03 · Valid control:** Construct a valid “Boot pointer validation” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M02.02-C026-T04 · Minimal adverse input:** Derive the “Boot pointer validation” adverse fixture from the control with the smallest documented change needed to reproduce “A descriptor points beyond the supplied memory range”; retain that change as reproducible data.
- [ ] **UC-M02.02-C026-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Boot pointer validation”; require “Boot pointers remain within allowed guest-addressable regions” and forbid a false-success verdict.
- [ ] **UC-M02.02-C026-T06 · Adverse execution:** Exercise the “Boot pointer validation” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M02.02-C026-T07 · Effect inspection:** Inspect “Boot pointer validation” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M02.02-C026-T08 · Refusal versus failure:** Confirm the “Boot pointer validation” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M02.02-C026-T09 · Reset and retention:** Restore only the disposable “Boot pointer validation” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M02.02-C026-T10 · Negative regression:** Register the “Boot pointer validation” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M02.02-C027 · Change / failure test

**Original checklist item:** Exercise boot pointer validation when startup is interrupted before guest readiness has been emitted; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M02.02-C027-T01 · Scenario record:** Write the “Boot pointer validation” change/failure scenario exactly as supplied: startup is interrupted before guest readiness has been emitted; identify the property that must remain true: “Boot pointers remain within allowed guest-addressable regions”.
- [ ] **UC-M02.02-C027-T02 · Baseline capture:** Create a known-valid “Boot pointer validation” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M02.02-C027-T03 · Injection map:** Locate the “Boot pointer validation” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M02.02-C027-T04 · Disposition oracle:** Define the legal intermediate and final “Boot pointer validation” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M02.02-C027-T05 · Controlled trigger:** Introduce the controlled “Boot pointer validation” scenario in the disposable fixture: startup is interrupted before guest readiness has been emitted; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M02.02-C027-T06 · Intermediate inspection:** Inspect the “Boot pointer validation” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M02.02-C027-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Boot pointer validation”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M02.02-C027-T08 · Stale-evidence cleanup:** Invalidate superseded “Boot pointer validation” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M02.02-C027-T09 · Repeat and compare:** Repeat the selected “Boot pointer validation” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M02.02-C027-T10 · Failure evidence:** Publish the “Boot pointer validation” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M02.02-C028 · Bounds

**Original checklist item:** Choose, document and test limits for pointer count and validation steps; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M02.02-C028-T01 · Quantity inventory:** Create a measurement inventory for “Boot pointer validation”: “Pointer count and validation steps”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M02.02-C028-T02 · Measurement method:** Choose how to observe each “Boot pointer validation” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M02.02-C028-T03 · Budget decision:** Select justified resource and input limits for “Boot pointer validation”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M02.02-C028-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Boot pointer validation” cases for “Pointer count and validation steps”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M02.02-C028-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Boot pointer validation” limit; preserve “Boot pointers remain within allowed guest-addressable regions”.
- [ ] **UC-M02.02-C028-T06 · Normal measurement:** Run or review the normal “Boot pointer validation” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M02.02-C028-T07 · At-limit measurement:** Exercise the “Boot pointer validation” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M02.02-C028-T08 · Over-limit measurement:** Exercise the “Boot pointer validation” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M02.02-C028-T09 · Uncovered-scope report:** List the “Boot pointer validation” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M02.02-C028-T10 · Limit evidence:** Publish the selected “Boot pointer validation” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M02.02-C029 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for boot pointer validation with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M02.02-C029-T01 · Event inventory:** List the “Boot pointer validation” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M02.02-C029-T02 · Diagnostic schema:** Define nonsecret fields for “Boot pointer validation” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M02.02-C029-T03 · Failure mapping:** Map each documented “Boot pointer validation” refusal or error to a diagnostic outcome; include “A descriptor points beyond the supplied memory range” and prohibit conversion into a success message.
- [ ] **UC-M02.02-C029-T04 · Emission path:** Add the “Boot pointer validation” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M02.02-C029-T05 · Redaction check:** Test “Boot pointer validation” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M02.02-C029-T06 · Output budget:** Set and exercise bounded “Boot pointer validation” message size, rate and retention compatible with “Pointer count and validation steps”; define truncation behavior that preserves the final reason.
- [ ] **UC-M02.02-C029-T07 · Success/refusal fixtures:** Capture “Boot pointer validation” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M02.02-C029-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Boot pointer validation” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M02.02-C029-T09 · Operator review:** Read the “Boot pointer validation” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M02.02-C029-T10 · Diagnostic evidence:** Publish redacted “Boot pointer validation” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M02.02-C030 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for boot pointer validation; label unexecuted checks as untested.

- [ ] **UC-M02.02-C030-T01 · Evidence inventory:** List the “Boot pointer validation” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M02.02-C030-T02 · Artifact references:** Record the exact “Boot pointer validation” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M02.02-C030-T03 · Fixture references:** Attach the “Boot pointer validation” fixture IDs, input identities and oracle definition; preserve the source counterexample “A descriptor points beyond the supplied memory range” as a distinct evidence case.
- [ ] **UC-M02.02-C030-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Boot pointer validation”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M02.02-C030-T05 · Environment record:** Record the actual “Boot pointer validation” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M02.02-C030-T06 · Expected versus observed:** Pair every “Boot pointer validation” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M02.02-C030-T07 · Failure and limit records:** Attach “Boot pointer validation” change/failure and bounds evidence where required; include uncovered “Pointer count and validation steps” and unresolved violations of “Boot pointers remain within allowed guest-addressable regions”.
- [ ] **UC-M02.02-C030-T08 · Evidence hygiene:** Check the “Boot pointer validation” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M02.02-C030-T09 · Reproduction review:** Have the “Boot pointer validation” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M02.02-C030-T10 · Acceptance linkage:** Link the “Boot pointer validation” evidence to its parent and UC-M02.02 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 04. Initial stack setup

**Source delivery:** Establish the initial stack with documented alignment, ownership and limits.

**Source invariant:** Startup does not run on an uninitialized or out-of-range stack.

**Source negative case:** A configured stack overlaps a protected image section.

**Source bounded quantities:** Stack bytes and maximum startup call depth.

### UC-M02.02-C031 · Contract

**Original checklist item:** Specify initial stack setup inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M02.02-C031-T01 · Scope statement:** Draft the operation boundary for “Initial stack setup” within Boot ABI and startup path; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M02.02-C031-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Initial stack setup”; record each producer, representation and missing-value meaning.
- [ ] **UC-M02.02-C031-T03 · Output inventory:** List the outputs of “Initial stack setup” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M02.02-C031-T04 · Field dictionary:** Create a field-and-term dictionary for “Initial stack setup”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M02.02-C031-T05 · Prerequisite contract:** Map “Initial stack setup” to the source component prerequisites (UC-M02.01); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M02.02-C031-T06 · Authority map:** Identify who may produce, change and consume “Initial stack setup”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M02.02-C031-T07 · Invariant clause:** Add a normative clause for “Initial stack setup” that preserves “Startup does not run on an uninitialized or out-of-range stack”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M02.02-C031-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Initial stack setup”; include the source counterexample “A configured stack overlaps a protected image section” and the intended safe disposition.
- [ ] **UC-M02.02-C031-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Stack bytes and maximum startup call depth” in the “Initial stack setup” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M02.02-C031-T10 · Contract review:** Review the “Initial stack setup” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M02.02-C032 · Delivery

**Original checklist item:** Establish the initial stack with documented alignment, ownership and limits.

- [ ] **UC-M02.02-C032-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Initial stack setup”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M02.02-C032-T02 · Change plan:** Break the source delivery for “Initial stack setup” into concrete edit targets and reviewable outputs; keep the UC-M02.02 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M02.02-C032-T03 · Core artifact:** Implement the smallest selected-profile change for “Initial stack setup” that realizes this source instruction: Establish the initial stack with documented alignment, ownership and limits.
- [ ] **UC-M02.02-C032-T04 · Concrete realization:** Trace “Initial stack setup” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M02.02-C032-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Initial stack setup” needed to preserve “Startup does not run on an uninitialized or out-of-range stack”; record an enforcement gap where only a model exists.
- [ ] **UC-M02.02-C032-T06 · Dependency connection:** Connect the “Initial stack setup” implementation to the selected loader, guest startup sequence and ready-signal receiver; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M02.02-C032-T07 · Resource behavior:** Account for “Stack bytes and maximum startup call depth” in “Initial stack setup”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M02.02-C032-T08 · Delivery check:** Run the smallest real “Initial stack setup” path and its adverse fixture “A configured stack overlaps a protected image section”; retain actual output, state effects and final disposition.
- [ ] **UC-M02.02-C032-T09 · Patch review:** Review the “Initial stack setup” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M02.02-C032-T10 · Delivery handoff:** Publish the “Initial stack setup” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M02.02-C033 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Startup does not run on an uninitialized or out-of-range stack. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M02.02-C033-T01 · Named property:** Create a stable property/check name under this parent for “Initial stack setup”; copy its required invariant exactly: “Startup does not run on an uninitialized or out-of-range stack”.
- [ ] **UC-M02.02-C033-T02 · Observable terms:** Define each term in the “Initial stack setup” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M02.02-C033-T03 · Precondition set:** List the preconditions under which “Startup does not run on an uninitialized or out-of-range stack” must hold for “Initial stack setup”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M02.02-C033-T04 · Transition coverage:** Map the “Initial stack setup” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M02.02-C033-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Initial stack setup”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M02.02-C033-T06 · Satisfying fixture:** Create a concrete “Initial stack setup” case that satisfies “Startup does not run on an uninitialized or out-of-range stack”; record its expected observation before running the assertion or review.
- [ ] **UC-M02.02-C033-T07 · Violating fixture:** Create the source counterexample “A configured stack overlaps a protected image section” for “Initial stack setup”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M02.02-C033-T08 · Enforcement evidence:** Exercise the “Initial stack setup” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M02.02-C033-T09 · Regression linkage:** Link the “Initial stack setup” property to changes in the selected loader, guest startup sequence and ready-signal receiver; record which dependency or contract changes require rerunning it.
- [ ] **UC-M02.02-C033-T10 · Property disposition:** Compare the satisfying and violating “Initial stack setup” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M02.02-C034 · Integration

**Original checklist item:** Integrate initial stack setup with the selected loader, guest startup sequence and ready-signal receiver; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M02.02-C034-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Initial stack setup” across the selected loader, guest startup sequence and ready-signal receiver; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M02.02-C034-T02 · Field mapping:** Map every “Initial stack setup” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M02.02-C034-T03 · Prerequisite identities:** Record the actual prerequisites for “Initial stack setup” (source dependency list: UC-M02.01); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M02.02-C034-T04 · Ownership agreement:** Specify who owns “Initial stack setup” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M02.02-C034-T05 · Handoff implementation:** Connect “Initial stack setup” through the mapped seam using the real adapter or explicit specification reference; preserve “Startup does not run on an uninitialized or out-of-range stack” across the handoff.
- [ ] **UC-M02.02-C034-T06 · Absent-input case:** Omit one required “Initial stack setup” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M02.02-C034-T07 · Stale-input case:** Supply an outdated “Initial stack setup” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M02.02-C034-T08 · Incompatible-input case:** Supply an incompatible “Initial stack setup” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M02.02-C034-T09 · Valid integration trace:** Run a valid “Initial stack setup” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M02.02-C034-T10 · Seam review:** Reconcile the “Initial stack setup” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M02.02-C035 · Valid-case test

**Original checklist item:** Run a valid-path fixture for initial stack setup; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M02.02-C035-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Initial stack setup” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M02.02-C035-T02 · Expected-result oracle:** Specify the “Initial stack setup” expected result independently of the implementation output; include the property “Startup does not run on an uninitialized or out-of-range stack” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M02.02-C035-T03 · Fixture material:** Create the concrete “Initial stack setup” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M02.02-C035-T04 · Target preparation:** Prepare the “Initial stack setup” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M02.02-C035-T05 · Initial-state record:** Record the initial “Initial stack setup” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M02.02-C035-T06 · Valid-path execution:** Execute the “Initial stack setup” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M02.02-C035-T07 · Outcome comparison:** Compare every declared “Initial stack setup” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M02.02-C035-T08 · State and bounds check:** Inspect the “Initial stack setup” ownership/state effects and actual use of “Stack bytes and maximum startup call depth”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M02.02-C035-T09 · Repeatability check:** Repeat the same “Initial stack setup” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M02.02-C035-T10 · Positive evidence:** Attach the “Initial stack setup” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M02.02-C036 · Negative test

**Original checklist item:** Negative case: A configured stack overlaps a protected image section. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M02.02-C036-T01 · Adverse-case definition:** Create a test record for the exact “Initial stack setup” source counterexample: “A configured stack overlaps a protected image section”; state which precondition or invariant it challenges.
- [ ] **UC-M02.02-C036-T02 · Safe fixture boundary:** Define the contained test boundary for “Initial stack setup”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M02.02-C036-T03 · Valid control:** Construct a valid “Initial stack setup” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M02.02-C036-T04 · Minimal adverse input:** Derive the “Initial stack setup” adverse fixture from the control with the smallest documented change needed to reproduce “A configured stack overlaps a protected image section”; retain that change as reproducible data.
- [ ] **UC-M02.02-C036-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Initial stack setup”; require “Startup does not run on an uninitialized or out-of-range stack” and forbid a false-success verdict.
- [ ] **UC-M02.02-C036-T06 · Adverse execution:** Exercise the “Initial stack setup” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M02.02-C036-T07 · Effect inspection:** Inspect “Initial stack setup” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M02.02-C036-T08 · Refusal versus failure:** Confirm the “Initial stack setup” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M02.02-C036-T09 · Reset and retention:** Restore only the disposable “Initial stack setup” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M02.02-C036-T10 · Negative regression:** Register the “Initial stack setup” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M02.02-C037 · Change / failure test

**Original checklist item:** Exercise initial stack setup when startup is interrupted before guest readiness has been emitted; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M02.02-C037-T01 · Scenario record:** Write the “Initial stack setup” change/failure scenario exactly as supplied: startup is interrupted before guest readiness has been emitted; identify the property that must remain true: “Startup does not run on an uninitialized or out-of-range stack”.
- [ ] **UC-M02.02-C037-T02 · Baseline capture:** Create a known-valid “Initial stack setup” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M02.02-C037-T03 · Injection map:** Locate the “Initial stack setup” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M02.02-C037-T04 · Disposition oracle:** Define the legal intermediate and final “Initial stack setup” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M02.02-C037-T05 · Controlled trigger:** Introduce the controlled “Initial stack setup” scenario in the disposable fixture: startup is interrupted before guest readiness has been emitted; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M02.02-C037-T06 · Intermediate inspection:** Inspect the “Initial stack setup” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M02.02-C037-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Initial stack setup”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M02.02-C037-T08 · Stale-evidence cleanup:** Invalidate superseded “Initial stack setup” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M02.02-C037-T09 · Repeat and compare:** Repeat the selected “Initial stack setup” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M02.02-C037-T10 · Failure evidence:** Publish the “Initial stack setup” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M02.02-C038 · Bounds

**Original checklist item:** Choose, document and test limits for stack bytes and maximum startup call depth; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M02.02-C038-T01 · Quantity inventory:** Create a measurement inventory for “Initial stack setup”: “Stack bytes and maximum startup call depth”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M02.02-C038-T02 · Measurement method:** Choose how to observe each “Initial stack setup” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M02.02-C038-T03 · Budget decision:** Select justified resource and input limits for “Initial stack setup”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M02.02-C038-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Initial stack setup” cases for “Stack bytes and maximum startup call depth”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M02.02-C038-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Initial stack setup” limit; preserve “Startup does not run on an uninitialized or out-of-range stack”.
- [ ] **UC-M02.02-C038-T06 · Normal measurement:** Run or review the normal “Initial stack setup” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M02.02-C038-T07 · At-limit measurement:** Exercise the “Initial stack setup” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M02.02-C038-T08 · Over-limit measurement:** Exercise the “Initial stack setup” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M02.02-C038-T09 · Uncovered-scope report:** List the “Initial stack setup” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M02.02-C038-T10 · Limit evidence:** Publish the selected “Initial stack setup” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M02.02-C039 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for initial stack setup with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M02.02-C039-T01 · Event inventory:** List the “Initial stack setup” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M02.02-C039-T02 · Diagnostic schema:** Define nonsecret fields for “Initial stack setup” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M02.02-C039-T03 · Failure mapping:** Map each documented “Initial stack setup” refusal or error to a diagnostic outcome; include “A configured stack overlaps a protected image section” and prohibit conversion into a success message.
- [ ] **UC-M02.02-C039-T04 · Emission path:** Add the “Initial stack setup” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M02.02-C039-T05 · Redaction check:** Test “Initial stack setup” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M02.02-C039-T06 · Output budget:** Set and exercise bounded “Initial stack setup” message size, rate and retention compatible with “Stack bytes and maximum startup call depth”; define truncation behavior that preserves the final reason.
- [ ] **UC-M02.02-C039-T07 · Success/refusal fixtures:** Capture “Initial stack setup” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M02.02-C039-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Initial stack setup” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M02.02-C039-T09 · Operator review:** Read the “Initial stack setup” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M02.02-C039-T10 · Diagnostic evidence:** Publish redacted “Initial stack setup” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M02.02-C040 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for initial stack setup; label unexecuted checks as untested.

- [ ] **UC-M02.02-C040-T01 · Evidence inventory:** List the “Initial stack setup” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M02.02-C040-T02 · Artifact references:** Record the exact “Initial stack setup” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M02.02-C040-T03 · Fixture references:** Attach the “Initial stack setup” fixture IDs, input identities and oracle definition; preserve the source counterexample “A configured stack overlaps a protected image section” as a distinct evidence case.
- [ ] **UC-M02.02-C040-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Initial stack setup”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M02.02-C040-T05 · Environment record:** Record the actual “Initial stack setup” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M02.02-C040-T06 · Expected versus observed:** Pair every “Initial stack setup” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M02.02-C040-T07 · Failure and limit records:** Attach “Initial stack setup” change/failure and bounds evidence where required; include uncovered “Stack bytes and maximum startup call depth” and unresolved violations of “Startup does not run on an uninitialized or out-of-range stack”.
- [ ] **UC-M02.02-C040-T08 · Evidence hygiene:** Check the “Initial stack setup” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M02.02-C040-T09 · Reproduction review:** Have the “Initial stack setup” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M02.02-C040-T10 · Acceptance linkage:** Link the “Initial stack setup” evidence to its parent and UC-M02.02 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 05. Early memory initialization

**Source delivery:** Initialize required zeroed data and platform bookkeeping before library startup.

**Source invariant:** Application-visible initialization follows the selected ABI.

**Source negative case:** Uninitialized global storage changes the first invocation result.

**Source bounded quantities:** Initialization bytes and boot latency.

### UC-M02.02-C041 · Contract

**Original checklist item:** Specify early memory initialization inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M02.02-C041-T01 · Scope statement:** Draft the operation boundary for “Early memory initialization” within Boot ABI and startup path; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M02.02-C041-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Early memory initialization”; record each producer, representation and missing-value meaning.
- [ ] **UC-M02.02-C041-T03 · Output inventory:** List the outputs of “Early memory initialization” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M02.02-C041-T04 · Field dictionary:** Create a field-and-term dictionary for “Early memory initialization”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M02.02-C041-T05 · Prerequisite contract:** Map “Early memory initialization” to the source component prerequisites (UC-M02.01); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M02.02-C041-T06 · Authority map:** Identify who may produce, change and consume “Early memory initialization”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M02.02-C041-T07 · Invariant clause:** Add a normative clause for “Early memory initialization” that preserves “Application-visible initialization follows the selected ABI”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M02.02-C041-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Early memory initialization”; include the source counterexample “Uninitialized global storage changes the first invocation result” and the intended safe disposition.
- [ ] **UC-M02.02-C041-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Initialization bytes and boot latency” in the “Early memory initialization” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M02.02-C041-T10 · Contract review:** Review the “Early memory initialization” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M02.02-C042 · Delivery

**Original checklist item:** Initialize required zeroed data and platform bookkeeping before library startup.

- [ ] **UC-M02.02-C042-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Early memory initialization”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M02.02-C042-T02 · Change plan:** Break the source delivery for “Early memory initialization” into concrete edit targets and reviewable outputs; keep the UC-M02.02 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M02.02-C042-T03 · Core artifact:** Implement the smallest selected-profile change for “Early memory initialization” that realizes this source instruction: Initialize required zeroed data and platform bookkeeping before library startup.
- [ ] **UC-M02.02-C042-T04 · Concrete realization:** Trace “Early memory initialization” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M02.02-C042-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Early memory initialization” needed to preserve “Application-visible initialization follows the selected ABI”; record an enforcement gap where only a model exists.
- [ ] **UC-M02.02-C042-T06 · Dependency connection:** Connect the “Early memory initialization” implementation to the selected loader, guest startup sequence and ready-signal receiver; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M02.02-C042-T07 · Resource behavior:** Account for “Initialization bytes and boot latency” in “Early memory initialization”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M02.02-C042-T08 · Delivery check:** Run the smallest real “Early memory initialization” path and its adverse fixture “Uninitialized global storage changes the first invocation result”; retain actual output, state effects and final disposition.
- [ ] **UC-M02.02-C042-T09 · Patch review:** Review the “Early memory initialization” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M02.02-C042-T10 · Delivery handoff:** Publish the “Early memory initialization” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M02.02-C043 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Application-visible initialization follows the selected ABI. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M02.02-C043-T01 · Named property:** Create a stable property/check name under this parent for “Early memory initialization”; copy its required invariant exactly: “Application-visible initialization follows the selected ABI”.
- [ ] **UC-M02.02-C043-T02 · Observable terms:** Define each term in the “Early memory initialization” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M02.02-C043-T03 · Precondition set:** List the preconditions under which “Application-visible initialization follows the selected ABI” must hold for “Early memory initialization”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M02.02-C043-T04 · Transition coverage:** Map the “Early memory initialization” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M02.02-C043-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Early memory initialization”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M02.02-C043-T06 · Satisfying fixture:** Create a concrete “Early memory initialization” case that satisfies “Application-visible initialization follows the selected ABI”; record its expected observation before running the assertion or review.
- [ ] **UC-M02.02-C043-T07 · Violating fixture:** Create the source counterexample “Uninitialized global storage changes the first invocation result” for “Early memory initialization”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M02.02-C043-T08 · Enforcement evidence:** Exercise the “Early memory initialization” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M02.02-C043-T09 · Regression linkage:** Link the “Early memory initialization” property to changes in the selected loader, guest startup sequence and ready-signal receiver; record which dependency or contract changes require rerunning it.
- [ ] **UC-M02.02-C043-T10 · Property disposition:** Compare the satisfying and violating “Early memory initialization” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M02.02-C044 · Integration

**Original checklist item:** Integrate early memory initialization with the selected loader, guest startup sequence and ready-signal receiver; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M02.02-C044-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Early memory initialization” across the selected loader, guest startup sequence and ready-signal receiver; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M02.02-C044-T02 · Field mapping:** Map every “Early memory initialization” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M02.02-C044-T03 · Prerequisite identities:** Record the actual prerequisites for “Early memory initialization” (source dependency list: UC-M02.01); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M02.02-C044-T04 · Ownership agreement:** Specify who owns “Early memory initialization” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M02.02-C044-T05 · Handoff implementation:** Connect “Early memory initialization” through the mapped seam using the real adapter or explicit specification reference; preserve “Application-visible initialization follows the selected ABI” across the handoff.
- [ ] **UC-M02.02-C044-T06 · Absent-input case:** Omit one required “Early memory initialization” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M02.02-C044-T07 · Stale-input case:** Supply an outdated “Early memory initialization” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M02.02-C044-T08 · Incompatible-input case:** Supply an incompatible “Early memory initialization” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M02.02-C044-T09 · Valid integration trace:** Run a valid “Early memory initialization” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M02.02-C044-T10 · Seam review:** Reconcile the “Early memory initialization” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M02.02-C045 · Valid-case test

**Original checklist item:** Run a valid-path fixture for early memory initialization; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M02.02-C045-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Early memory initialization” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M02.02-C045-T02 · Expected-result oracle:** Specify the “Early memory initialization” expected result independently of the implementation output; include the property “Application-visible initialization follows the selected ABI” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M02.02-C045-T03 · Fixture material:** Create the concrete “Early memory initialization” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M02.02-C045-T04 · Target preparation:** Prepare the “Early memory initialization” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M02.02-C045-T05 · Initial-state record:** Record the initial “Early memory initialization” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M02.02-C045-T06 · Valid-path execution:** Execute the “Early memory initialization” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M02.02-C045-T07 · Outcome comparison:** Compare every declared “Early memory initialization” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M02.02-C045-T08 · State and bounds check:** Inspect the “Early memory initialization” ownership/state effects and actual use of “Initialization bytes and boot latency”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M02.02-C045-T09 · Repeatability check:** Repeat the same “Early memory initialization” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M02.02-C045-T10 · Positive evidence:** Attach the “Early memory initialization” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M02.02-C046 · Negative test

**Original checklist item:** Negative case: Uninitialized global storage changes the first invocation result. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M02.02-C046-T01 · Adverse-case definition:** Create a test record for the exact “Early memory initialization” source counterexample: “Uninitialized global storage changes the first invocation result”; state which precondition or invariant it challenges.
- [ ] **UC-M02.02-C046-T02 · Safe fixture boundary:** Define the contained test boundary for “Early memory initialization”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M02.02-C046-T03 · Valid control:** Construct a valid “Early memory initialization” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M02.02-C046-T04 · Minimal adverse input:** Derive the “Early memory initialization” adverse fixture from the control with the smallest documented change needed to reproduce “Uninitialized global storage changes the first invocation result”; retain that change as reproducible data.
- [ ] **UC-M02.02-C046-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Early memory initialization”; require “Application-visible initialization follows the selected ABI” and forbid a false-success verdict.
- [ ] **UC-M02.02-C046-T06 · Adverse execution:** Exercise the “Early memory initialization” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M02.02-C046-T07 · Effect inspection:** Inspect “Early memory initialization” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M02.02-C046-T08 · Refusal versus failure:** Confirm the “Early memory initialization” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M02.02-C046-T09 · Reset and retention:** Restore only the disposable “Early memory initialization” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M02.02-C046-T10 · Negative regression:** Register the “Early memory initialization” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M02.02-C047 · Change / failure test

**Original checklist item:** Exercise early memory initialization when startup is interrupted before guest readiness has been emitted; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M02.02-C047-T01 · Scenario record:** Write the “Early memory initialization” change/failure scenario exactly as supplied: startup is interrupted before guest readiness has been emitted; identify the property that must remain true: “Application-visible initialization follows the selected ABI”.
- [ ] **UC-M02.02-C047-T02 · Baseline capture:** Create a known-valid “Early memory initialization” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M02.02-C047-T03 · Injection map:** Locate the “Early memory initialization” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M02.02-C047-T04 · Disposition oracle:** Define the legal intermediate and final “Early memory initialization” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M02.02-C047-T05 · Controlled trigger:** Introduce the controlled “Early memory initialization” scenario in the disposable fixture: startup is interrupted before guest readiness has been emitted; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M02.02-C047-T06 · Intermediate inspection:** Inspect the “Early memory initialization” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M02.02-C047-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Early memory initialization”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M02.02-C047-T08 · Stale-evidence cleanup:** Invalidate superseded “Early memory initialization” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M02.02-C047-T09 · Repeat and compare:** Repeat the selected “Early memory initialization” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M02.02-C047-T10 · Failure evidence:** Publish the “Early memory initialization” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M02.02-C048 · Bounds

**Original checklist item:** Choose, document and test limits for initialization bytes and boot latency; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M02.02-C048-T01 · Quantity inventory:** Create a measurement inventory for “Early memory initialization”: “Initialization bytes and boot latency”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M02.02-C048-T02 · Measurement method:** Choose how to observe each “Early memory initialization” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M02.02-C048-T03 · Budget decision:** Select justified resource and input limits for “Early memory initialization”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M02.02-C048-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Early memory initialization” cases for “Initialization bytes and boot latency”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M02.02-C048-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Early memory initialization” limit; preserve “Application-visible initialization follows the selected ABI”.
- [ ] **UC-M02.02-C048-T06 · Normal measurement:** Run or review the normal “Early memory initialization” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M02.02-C048-T07 · At-limit measurement:** Exercise the “Early memory initialization” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M02.02-C048-T08 · Over-limit measurement:** Exercise the “Early memory initialization” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M02.02-C048-T09 · Uncovered-scope report:** List the “Early memory initialization” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M02.02-C048-T10 · Limit evidence:** Publish the selected “Early memory initialization” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M02.02-C049 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for early memory initialization with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M02.02-C049-T01 · Event inventory:** List the “Early memory initialization” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M02.02-C049-T02 · Diagnostic schema:** Define nonsecret fields for “Early memory initialization” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M02.02-C049-T03 · Failure mapping:** Map each documented “Early memory initialization” refusal or error to a diagnostic outcome; include “Uninitialized global storage changes the first invocation result” and prohibit conversion into a success message.
- [ ] **UC-M02.02-C049-T04 · Emission path:** Add the “Early memory initialization” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M02.02-C049-T05 · Redaction check:** Test “Early memory initialization” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M02.02-C049-T06 · Output budget:** Set and exercise bounded “Early memory initialization” message size, rate and retention compatible with “Initialization bytes and boot latency”; define truncation behavior that preserves the final reason.
- [ ] **UC-M02.02-C049-T07 · Success/refusal fixtures:** Capture “Early memory initialization” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M02.02-C049-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Early memory initialization” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M02.02-C049-T09 · Operator review:** Read the “Early memory initialization” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M02.02-C049-T10 · Diagnostic evidence:** Publish redacted “Early memory initialization” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M02.02-C050 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for early memory initialization; label unexecuted checks as untested.

- [ ] **UC-M02.02-C050-T01 · Evidence inventory:** List the “Early memory initialization” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M02.02-C050-T02 · Artifact references:** Record the exact “Early memory initialization” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M02.02-C050-T03 · Fixture references:** Attach the “Early memory initialization” fixture IDs, input identities and oracle definition; preserve the source counterexample “Uninitialized global storage changes the first invocation result” as a distinct evidence case.
- [ ] **UC-M02.02-C050-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Early memory initialization”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M02.02-C050-T05 · Environment record:** Record the actual “Early memory initialization” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M02.02-C050-T06 · Expected versus observed:** Pair every “Early memory initialization” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M02.02-C050-T07 · Failure and limit records:** Attach “Early memory initialization” change/failure and bounds evidence where required; include uncovered “Initialization bytes and boot latency” and unresolved violations of “Application-visible initialization follows the selected ABI”.
- [ ] **UC-M02.02-C050-T08 · Evidence hygiene:** Check the “Early memory initialization” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M02.02-C050-T09 · Reproduction review:** Have the “Early memory initialization” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M02.02-C050-T10 · Acceptance linkage:** Link the “Early memory initialization” evidence to its parent and UC-M02.02 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 06. Platform bring-up order

**Source delivery:** Order platform, memory and required device initialization dependencies.

**Source invariant:** Application startup cannot bypass required platform initialization.

**Source negative case:** The workload uses a console before its driver is initialized.

**Source bounded quantities:** Startup stages and per-stage deadlines.

### UC-M02.02-C051 · Contract

**Original checklist item:** Specify platform bring-up order inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M02.02-C051-T01 · Scope statement:** Draft the operation boundary for “Platform bring-up order” within Boot ABI and startup path; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M02.02-C051-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Platform bring-up order”; record each producer, representation and missing-value meaning.
- [ ] **UC-M02.02-C051-T03 · Output inventory:** List the outputs of “Platform bring-up order” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M02.02-C051-T04 · Field dictionary:** Create a field-and-term dictionary for “Platform bring-up order”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M02.02-C051-T05 · Prerequisite contract:** Map “Platform bring-up order” to the source component prerequisites (UC-M02.01); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M02.02-C051-T06 · Authority map:** Identify who may produce, change and consume “Platform bring-up order”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M02.02-C051-T07 · Invariant clause:** Add a normative clause for “Platform bring-up order” that preserves “Application startup cannot bypass required platform initialization”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M02.02-C051-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Platform bring-up order”; include the source counterexample “The workload uses a console before its driver is initialized” and the intended safe disposition.
- [ ] **UC-M02.02-C051-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Startup stages and per-stage deadlines” in the “Platform bring-up order” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M02.02-C051-T10 · Contract review:** Review the “Platform bring-up order” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M02.02-C052 · Delivery

**Original checklist item:** Order platform, memory and required device initialization dependencies.

- [ ] **UC-M02.02-C052-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Platform bring-up order”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M02.02-C052-T02 · Change plan:** Break the source delivery for “Platform bring-up order” into concrete edit targets and reviewable outputs; keep the UC-M02.02 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M02.02-C052-T03 · Core artifact:** Implement the smallest selected-profile change for “Platform bring-up order” that realizes this source instruction: Order platform, memory and required device initialization dependencies.
- [ ] **UC-M02.02-C052-T04 · Concrete realization:** Trace “Platform bring-up order” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M02.02-C052-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Platform bring-up order” needed to preserve “Application startup cannot bypass required platform initialization”; record an enforcement gap where only a model exists.
- [ ] **UC-M02.02-C052-T06 · Dependency connection:** Connect the “Platform bring-up order” implementation to the selected loader, guest startup sequence and ready-signal receiver; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M02.02-C052-T07 · Resource behavior:** Account for “Startup stages and per-stage deadlines” in “Platform bring-up order”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M02.02-C052-T08 · Delivery check:** Run the smallest real “Platform bring-up order” path and its adverse fixture “The workload uses a console before its driver is initialized”; retain actual output, state effects and final disposition.
- [ ] **UC-M02.02-C052-T09 · Patch review:** Review the “Platform bring-up order” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M02.02-C052-T10 · Delivery handoff:** Publish the “Platform bring-up order” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M02.02-C053 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Application startup cannot bypass required platform initialization. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M02.02-C053-T01 · Named property:** Create a stable property/check name under this parent for “Platform bring-up order”; copy its required invariant exactly: “Application startup cannot bypass required platform initialization”.
- [ ] **UC-M02.02-C053-T02 · Observable terms:** Define each term in the “Platform bring-up order” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M02.02-C053-T03 · Precondition set:** List the preconditions under which “Application startup cannot bypass required platform initialization” must hold for “Platform bring-up order”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M02.02-C053-T04 · Transition coverage:** Map the “Platform bring-up order” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M02.02-C053-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Platform bring-up order”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M02.02-C053-T06 · Satisfying fixture:** Create a concrete “Platform bring-up order” case that satisfies “Application startup cannot bypass required platform initialization”; record its expected observation before running the assertion or review.
- [ ] **UC-M02.02-C053-T07 · Violating fixture:** Create the source counterexample “The workload uses a console before its driver is initialized” for “Platform bring-up order”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M02.02-C053-T08 · Enforcement evidence:** Exercise the “Platform bring-up order” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M02.02-C053-T09 · Regression linkage:** Link the “Platform bring-up order” property to changes in the selected loader, guest startup sequence and ready-signal receiver; record which dependency or contract changes require rerunning it.
- [ ] **UC-M02.02-C053-T10 · Property disposition:** Compare the satisfying and violating “Platform bring-up order” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M02.02-C054 · Integration

**Original checklist item:** Integrate platform bring-up order with the selected loader, guest startup sequence and ready-signal receiver; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M02.02-C054-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Platform bring-up order” across the selected loader, guest startup sequence and ready-signal receiver; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M02.02-C054-T02 · Field mapping:** Map every “Platform bring-up order” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M02.02-C054-T03 · Prerequisite identities:** Record the actual prerequisites for “Platform bring-up order” (source dependency list: UC-M02.01); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M02.02-C054-T04 · Ownership agreement:** Specify who owns “Platform bring-up order” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M02.02-C054-T05 · Handoff implementation:** Connect “Platform bring-up order” through the mapped seam using the real adapter or explicit specification reference; preserve “Application startup cannot bypass required platform initialization” across the handoff.
- [ ] **UC-M02.02-C054-T06 · Absent-input case:** Omit one required “Platform bring-up order” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M02.02-C054-T07 · Stale-input case:** Supply an outdated “Platform bring-up order” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M02.02-C054-T08 · Incompatible-input case:** Supply an incompatible “Platform bring-up order” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M02.02-C054-T09 · Valid integration trace:** Run a valid “Platform bring-up order” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M02.02-C054-T10 · Seam review:** Reconcile the “Platform bring-up order” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M02.02-C055 · Valid-case test

**Original checklist item:** Run a valid-path fixture for platform bring-up order; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M02.02-C055-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Platform bring-up order” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M02.02-C055-T02 · Expected-result oracle:** Specify the “Platform bring-up order” expected result independently of the implementation output; include the property “Application startup cannot bypass required platform initialization” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M02.02-C055-T03 · Fixture material:** Create the concrete “Platform bring-up order” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M02.02-C055-T04 · Target preparation:** Prepare the “Platform bring-up order” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M02.02-C055-T05 · Initial-state record:** Record the initial “Platform bring-up order” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M02.02-C055-T06 · Valid-path execution:** Execute the “Platform bring-up order” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M02.02-C055-T07 · Outcome comparison:** Compare every declared “Platform bring-up order” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M02.02-C055-T08 · State and bounds check:** Inspect the “Platform bring-up order” ownership/state effects and actual use of “Startup stages and per-stage deadlines”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M02.02-C055-T09 · Repeatability check:** Repeat the same “Platform bring-up order” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M02.02-C055-T10 · Positive evidence:** Attach the “Platform bring-up order” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M02.02-C056 · Negative test

**Original checklist item:** Negative case: The workload uses a console before its driver is initialized. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M02.02-C056-T01 · Adverse-case definition:** Create a test record for the exact “Platform bring-up order” source counterexample: “The workload uses a console before its driver is initialized”; state which precondition or invariant it challenges.
- [ ] **UC-M02.02-C056-T02 · Safe fixture boundary:** Define the contained test boundary for “Platform bring-up order”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M02.02-C056-T03 · Valid control:** Construct a valid “Platform bring-up order” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M02.02-C056-T04 · Minimal adverse input:** Derive the “Platform bring-up order” adverse fixture from the control with the smallest documented change needed to reproduce “The workload uses a console before its driver is initialized”; retain that change as reproducible data.
- [ ] **UC-M02.02-C056-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Platform bring-up order”; require “Application startup cannot bypass required platform initialization” and forbid a false-success verdict.
- [ ] **UC-M02.02-C056-T06 · Adverse execution:** Exercise the “Platform bring-up order” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M02.02-C056-T07 · Effect inspection:** Inspect “Platform bring-up order” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M02.02-C056-T08 · Refusal versus failure:** Confirm the “Platform bring-up order” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M02.02-C056-T09 · Reset and retention:** Restore only the disposable “Platform bring-up order” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M02.02-C056-T10 · Negative regression:** Register the “Platform bring-up order” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M02.02-C057 · Change / failure test

**Original checklist item:** Exercise platform bring-up order when startup is interrupted before guest readiness has been emitted; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M02.02-C057-T01 · Scenario record:** Write the “Platform bring-up order” change/failure scenario exactly as supplied: startup is interrupted before guest readiness has been emitted; identify the property that must remain true: “Application startup cannot bypass required platform initialization”.
- [ ] **UC-M02.02-C057-T02 · Baseline capture:** Create a known-valid “Platform bring-up order” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M02.02-C057-T03 · Injection map:** Locate the “Platform bring-up order” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M02.02-C057-T04 · Disposition oracle:** Define the legal intermediate and final “Platform bring-up order” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M02.02-C057-T05 · Controlled trigger:** Introduce the controlled “Platform bring-up order” scenario in the disposable fixture: startup is interrupted before guest readiness has been emitted; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M02.02-C057-T06 · Intermediate inspection:** Inspect the “Platform bring-up order” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M02.02-C057-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Platform bring-up order”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M02.02-C057-T08 · Stale-evidence cleanup:** Invalidate superseded “Platform bring-up order” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M02.02-C057-T09 · Repeat and compare:** Repeat the selected “Platform bring-up order” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M02.02-C057-T10 · Failure evidence:** Publish the “Platform bring-up order” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M02.02-C058 · Bounds

**Original checklist item:** Choose, document and test limits for startup stages and per-stage deadlines; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M02.02-C058-T01 · Quantity inventory:** Create a measurement inventory for “Platform bring-up order”: “Startup stages and per-stage deadlines”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M02.02-C058-T02 · Measurement method:** Choose how to observe each “Platform bring-up order” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M02.02-C058-T03 · Budget decision:** Select justified resource and input limits for “Platform bring-up order”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M02.02-C058-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Platform bring-up order” cases for “Startup stages and per-stage deadlines”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M02.02-C058-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Platform bring-up order” limit; preserve “Application startup cannot bypass required platform initialization”.
- [ ] **UC-M02.02-C058-T06 · Normal measurement:** Run or review the normal “Platform bring-up order” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M02.02-C058-T07 · At-limit measurement:** Exercise the “Platform bring-up order” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M02.02-C058-T08 · Over-limit measurement:** Exercise the “Platform bring-up order” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M02.02-C058-T09 · Uncovered-scope report:** List the “Platform bring-up order” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M02.02-C058-T10 · Limit evidence:** Publish the selected “Platform bring-up order” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M02.02-C059 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for platform bring-up order with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M02.02-C059-T01 · Event inventory:** List the “Platform bring-up order” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M02.02-C059-T02 · Diagnostic schema:** Define nonsecret fields for “Platform bring-up order” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M02.02-C059-T03 · Failure mapping:** Map each documented “Platform bring-up order” refusal or error to a diagnostic outcome; include “The workload uses a console before its driver is initialized” and prohibit conversion into a success message.
- [ ] **UC-M02.02-C059-T04 · Emission path:** Add the “Platform bring-up order” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M02.02-C059-T05 · Redaction check:** Test “Platform bring-up order” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M02.02-C059-T06 · Output budget:** Set and exercise bounded “Platform bring-up order” message size, rate and retention compatible with “Startup stages and per-stage deadlines”; define truncation behavior that preserves the final reason.
- [ ] **UC-M02.02-C059-T07 · Success/refusal fixtures:** Capture “Platform bring-up order” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M02.02-C059-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Platform bring-up order” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M02.02-C059-T09 · Operator review:** Read the “Platform bring-up order” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M02.02-C059-T10 · Diagnostic evidence:** Publish redacted “Platform bring-up order” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M02.02-C060 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for platform bring-up order; label unexecuted checks as untested.

- [ ] **UC-M02.02-C060-T01 · Evidence inventory:** List the “Platform bring-up order” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M02.02-C060-T02 · Artifact references:** Record the exact “Platform bring-up order” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M02.02-C060-T03 · Fixture references:** Attach the “Platform bring-up order” fixture IDs, input identities and oracle definition; preserve the source counterexample “The workload uses a console before its driver is initialized” as a distinct evidence case.
- [ ] **UC-M02.02-C060-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Platform bring-up order”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M02.02-C060-T05 · Environment record:** Record the actual “Platform bring-up order” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M02.02-C060-T06 · Expected versus observed:** Pair every “Platform bring-up order” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M02.02-C060-T07 · Failure and limit records:** Attach “Platform bring-up order” change/failure and bounds evidence where required; include uncovered “Startup stages and per-stage deadlines” and unresolved violations of “Application startup cannot bypass required platform initialization”.
- [ ] **UC-M02.02-C060-T08 · Evidence hygiene:** Check the “Platform bring-up order” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M02.02-C060-T09 · Reproduction review:** Have the “Platform bring-up order” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M02.02-C060-T10 · Acceptance linkage:** Link the “Platform bring-up order” evidence to its parent and UC-M02.02 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 07. Boot configuration binding

**Source delivery:** Bind boot parameters to the selected image, architecture and guest generation.

**Source invariant:** Boot parameters cannot silently target a different image or ABI.

**Source negative case:** Parameters from another generation are replayed at startup.

**Source bounded quantities:** Parameter bytes and supported option count.

### UC-M02.02-C061 · Contract

**Original checklist item:** Specify boot configuration binding inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M02.02-C061-T01 · Scope statement:** Draft the operation boundary for “Boot configuration binding” within Boot ABI and startup path; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M02.02-C061-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Boot configuration binding”; record each producer, representation and missing-value meaning.
- [ ] **UC-M02.02-C061-T03 · Output inventory:** List the outputs of “Boot configuration binding” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M02.02-C061-T04 · Field dictionary:** Create a field-and-term dictionary for “Boot configuration binding”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M02.02-C061-T05 · Prerequisite contract:** Map “Boot configuration binding” to the source component prerequisites (UC-M02.01); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M02.02-C061-T06 · Authority map:** Identify who may produce, change and consume “Boot configuration binding”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M02.02-C061-T07 · Invariant clause:** Add a normative clause for “Boot configuration binding” that preserves “Boot parameters cannot silently target a different image or ABI”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M02.02-C061-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Boot configuration binding”; include the source counterexample “Parameters from another generation are replayed at startup” and the intended safe disposition.
- [ ] **UC-M02.02-C061-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Parameter bytes and supported option count” in the “Boot configuration binding” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M02.02-C061-T10 · Contract review:** Review the “Boot configuration binding” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M02.02-C062 · Delivery

**Original checklist item:** Bind boot parameters to the selected image, architecture and guest generation.

- [ ] **UC-M02.02-C062-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Boot configuration binding”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M02.02-C062-T02 · Change plan:** Break the source delivery for “Boot configuration binding” into concrete edit targets and reviewable outputs; keep the UC-M02.02 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M02.02-C062-T03 · Core artifact:** Implement the smallest selected-profile change for “Boot configuration binding” that realizes this source instruction: Bind boot parameters to the selected image, architecture and guest generation.
- [ ] **UC-M02.02-C062-T04 · Concrete realization:** Trace “Boot configuration binding” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M02.02-C062-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Boot configuration binding” needed to preserve “Boot parameters cannot silently target a different image or ABI”; record an enforcement gap where only a model exists.
- [ ] **UC-M02.02-C062-T06 · Dependency connection:** Connect the “Boot configuration binding” implementation to the selected loader, guest startup sequence and ready-signal receiver; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M02.02-C062-T07 · Resource behavior:** Account for “Parameter bytes and supported option count” in “Boot configuration binding”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M02.02-C062-T08 · Delivery check:** Run the smallest real “Boot configuration binding” path and its adverse fixture “Parameters from another generation are replayed at startup”; retain actual output, state effects and final disposition.
- [ ] **UC-M02.02-C062-T09 · Patch review:** Review the “Boot configuration binding” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M02.02-C062-T10 · Delivery handoff:** Publish the “Boot configuration binding” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M02.02-C063 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Boot parameters cannot silently target a different image or ABI. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M02.02-C063-T01 · Named property:** Create a stable property/check name under this parent for “Boot configuration binding”; copy its required invariant exactly: “Boot parameters cannot silently target a different image or ABI”.
- [ ] **UC-M02.02-C063-T02 · Observable terms:** Define each term in the “Boot configuration binding” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M02.02-C063-T03 · Precondition set:** List the preconditions under which “Boot parameters cannot silently target a different image or ABI” must hold for “Boot configuration binding”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M02.02-C063-T04 · Transition coverage:** Map the “Boot configuration binding” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M02.02-C063-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Boot configuration binding”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M02.02-C063-T06 · Satisfying fixture:** Create a concrete “Boot configuration binding” case that satisfies “Boot parameters cannot silently target a different image or ABI”; record its expected observation before running the assertion or review.
- [ ] **UC-M02.02-C063-T07 · Violating fixture:** Create the source counterexample “Parameters from another generation are replayed at startup” for “Boot configuration binding”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M02.02-C063-T08 · Enforcement evidence:** Exercise the “Boot configuration binding” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M02.02-C063-T09 · Regression linkage:** Link the “Boot configuration binding” property to changes in the selected loader, guest startup sequence and ready-signal receiver; record which dependency or contract changes require rerunning it.
- [ ] **UC-M02.02-C063-T10 · Property disposition:** Compare the satisfying and violating “Boot configuration binding” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M02.02-C064 · Integration

**Original checklist item:** Integrate boot configuration binding with the selected loader, guest startup sequence and ready-signal receiver; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M02.02-C064-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Boot configuration binding” across the selected loader, guest startup sequence and ready-signal receiver; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M02.02-C064-T02 · Field mapping:** Map every “Boot configuration binding” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M02.02-C064-T03 · Prerequisite identities:** Record the actual prerequisites for “Boot configuration binding” (source dependency list: UC-M02.01); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M02.02-C064-T04 · Ownership agreement:** Specify who owns “Boot configuration binding” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M02.02-C064-T05 · Handoff implementation:** Connect “Boot configuration binding” through the mapped seam using the real adapter or explicit specification reference; preserve “Boot parameters cannot silently target a different image or ABI” across the handoff.
- [ ] **UC-M02.02-C064-T06 · Absent-input case:** Omit one required “Boot configuration binding” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M02.02-C064-T07 · Stale-input case:** Supply an outdated “Boot configuration binding” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M02.02-C064-T08 · Incompatible-input case:** Supply an incompatible “Boot configuration binding” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M02.02-C064-T09 · Valid integration trace:** Run a valid “Boot configuration binding” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M02.02-C064-T10 · Seam review:** Reconcile the “Boot configuration binding” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M02.02-C065 · Valid-case test

**Original checklist item:** Run a valid-path fixture for boot configuration binding; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M02.02-C065-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Boot configuration binding” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M02.02-C065-T02 · Expected-result oracle:** Specify the “Boot configuration binding” expected result independently of the implementation output; include the property “Boot parameters cannot silently target a different image or ABI” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M02.02-C065-T03 · Fixture material:** Create the concrete “Boot configuration binding” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M02.02-C065-T04 · Target preparation:** Prepare the “Boot configuration binding” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M02.02-C065-T05 · Initial-state record:** Record the initial “Boot configuration binding” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M02.02-C065-T06 · Valid-path execution:** Execute the “Boot configuration binding” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M02.02-C065-T07 · Outcome comparison:** Compare every declared “Boot configuration binding” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M02.02-C065-T08 · State and bounds check:** Inspect the “Boot configuration binding” ownership/state effects and actual use of “Parameter bytes and supported option count”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M02.02-C065-T09 · Repeatability check:** Repeat the same “Boot configuration binding” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M02.02-C065-T10 · Positive evidence:** Attach the “Boot configuration binding” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M02.02-C066 · Negative test

**Original checklist item:** Negative case: Parameters from another generation are replayed at startup. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M02.02-C066-T01 · Adverse-case definition:** Create a test record for the exact “Boot configuration binding” source counterexample: “Parameters from another generation are replayed at startup”; state which precondition or invariant it challenges.
- [ ] **UC-M02.02-C066-T02 · Safe fixture boundary:** Define the contained test boundary for “Boot configuration binding”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M02.02-C066-T03 · Valid control:** Construct a valid “Boot configuration binding” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M02.02-C066-T04 · Minimal adverse input:** Derive the “Boot configuration binding” adverse fixture from the control with the smallest documented change needed to reproduce “Parameters from another generation are replayed at startup”; retain that change as reproducible data.
- [ ] **UC-M02.02-C066-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Boot configuration binding”; require “Boot parameters cannot silently target a different image or ABI” and forbid a false-success verdict.
- [ ] **UC-M02.02-C066-T06 · Adverse execution:** Exercise the “Boot configuration binding” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M02.02-C066-T07 · Effect inspection:** Inspect “Boot configuration binding” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M02.02-C066-T08 · Refusal versus failure:** Confirm the “Boot configuration binding” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M02.02-C066-T09 · Reset and retention:** Restore only the disposable “Boot configuration binding” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M02.02-C066-T10 · Negative regression:** Register the “Boot configuration binding” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M02.02-C067 · Change / failure test

**Original checklist item:** Exercise boot configuration binding when startup is interrupted before guest readiness has been emitted; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M02.02-C067-T01 · Scenario record:** Write the “Boot configuration binding” change/failure scenario exactly as supplied: startup is interrupted before guest readiness has been emitted; identify the property that must remain true: “Boot parameters cannot silently target a different image or ABI”.
- [ ] **UC-M02.02-C067-T02 · Baseline capture:** Create a known-valid “Boot configuration binding” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M02.02-C067-T03 · Injection map:** Locate the “Boot configuration binding” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M02.02-C067-T04 · Disposition oracle:** Define the legal intermediate and final “Boot configuration binding” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M02.02-C067-T05 · Controlled trigger:** Introduce the controlled “Boot configuration binding” scenario in the disposable fixture: startup is interrupted before guest readiness has been emitted; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M02.02-C067-T06 · Intermediate inspection:** Inspect the “Boot configuration binding” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M02.02-C067-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Boot configuration binding”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M02.02-C067-T08 · Stale-evidence cleanup:** Invalidate superseded “Boot configuration binding” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M02.02-C067-T09 · Repeat and compare:** Repeat the selected “Boot configuration binding” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M02.02-C067-T10 · Failure evidence:** Publish the “Boot configuration binding” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M02.02-C068 · Bounds

**Original checklist item:** Choose, document and test limits for parameter bytes and supported option count; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M02.02-C068-T01 · Quantity inventory:** Create a measurement inventory for “Boot configuration binding”: “Parameter bytes and supported option count”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M02.02-C068-T02 · Measurement method:** Choose how to observe each “Boot configuration binding” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M02.02-C068-T03 · Budget decision:** Select justified resource and input limits for “Boot configuration binding”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M02.02-C068-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Boot configuration binding” cases for “Parameter bytes and supported option count”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M02.02-C068-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Boot configuration binding” limit; preserve “Boot parameters cannot silently target a different image or ABI”.
- [ ] **UC-M02.02-C068-T06 · Normal measurement:** Run or review the normal “Boot configuration binding” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M02.02-C068-T07 · At-limit measurement:** Exercise the “Boot configuration binding” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M02.02-C068-T08 · Over-limit measurement:** Exercise the “Boot configuration binding” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M02.02-C068-T09 · Uncovered-scope report:** List the “Boot configuration binding” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M02.02-C068-T10 · Limit evidence:** Publish the selected “Boot configuration binding” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M02.02-C069 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for boot configuration binding with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M02.02-C069-T01 · Event inventory:** List the “Boot configuration binding” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M02.02-C069-T02 · Diagnostic schema:** Define nonsecret fields for “Boot configuration binding” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M02.02-C069-T03 · Failure mapping:** Map each documented “Boot configuration binding” refusal or error to a diagnostic outcome; include “Parameters from another generation are replayed at startup” and prohibit conversion into a success message.
- [ ] **UC-M02.02-C069-T04 · Emission path:** Add the “Boot configuration binding” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M02.02-C069-T05 · Redaction check:** Test “Boot configuration binding” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M02.02-C069-T06 · Output budget:** Set and exercise bounded “Boot configuration binding” message size, rate and retention compatible with “Parameter bytes and supported option count”; define truncation behavior that preserves the final reason.
- [ ] **UC-M02.02-C069-T07 · Success/refusal fixtures:** Capture “Boot configuration binding” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M02.02-C069-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Boot configuration binding” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M02.02-C069-T09 · Operator review:** Read the “Boot configuration binding” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M02.02-C069-T10 · Diagnostic evidence:** Publish redacted “Boot configuration binding” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M02.02-C070 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for boot configuration binding; label unexecuted checks as untested.

- [ ] **UC-M02.02-C070-T01 · Evidence inventory:** List the “Boot configuration binding” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M02.02-C070-T02 · Artifact references:** Record the exact “Boot configuration binding” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M02.02-C070-T03 · Fixture references:** Attach the “Boot configuration binding” fixture IDs, input identities and oracle definition; preserve the source counterexample “Parameters from another generation are replayed at startup” as a distinct evidence case.
- [ ] **UC-M02.02-C070-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Boot configuration binding”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M02.02-C070-T05 · Environment record:** Record the actual “Boot configuration binding” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M02.02-C070-T06 · Expected versus observed:** Pair every “Boot configuration binding” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M02.02-C070-T07 · Failure and limit records:** Attach “Boot configuration binding” change/failure and bounds evidence where required; include uncovered “Parameter bytes and supported option count” and unresolved violations of “Boot parameters cannot silently target a different image or ABI”.
- [ ] **UC-M02.02-C070-T08 · Evidence hygiene:** Check the “Boot configuration binding” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M02.02-C070-T09 · Reproduction review:** Have the “Boot configuration binding” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M02.02-C070-T10 · Acceptance linkage:** Link the “Boot configuration binding” evidence to its parent and UC-M02.02 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 08. Guest-originated ready signal

**Source delivery:** Emit a ready signal from the guest only after required initialization succeeds.

**Source invariant:** Host process creation alone does not establish guest readiness.

**Source negative case:** The launcher declares readiness before receiving a guest signal.

**Source bounded quantities:** Ready-signal bytes and readiness deadline.

### UC-M02.02-C071 · Contract

**Original checklist item:** Specify guest-originated ready signal inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M02.02-C071-T01 · Scope statement:** Draft the operation boundary for “Guest-originated ready signal” within Boot ABI and startup path; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M02.02-C071-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Guest-originated ready signal”; record each producer, representation and missing-value meaning.
- [ ] **UC-M02.02-C071-T03 · Output inventory:** List the outputs of “Guest-originated ready signal” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M02.02-C071-T04 · Field dictionary:** Create a field-and-term dictionary for “Guest-originated ready signal”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M02.02-C071-T05 · Prerequisite contract:** Map “Guest-originated ready signal” to the source component prerequisites (UC-M02.01); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M02.02-C071-T06 · Authority map:** Identify who may produce, change and consume “Guest-originated ready signal”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M02.02-C071-T07 · Invariant clause:** Add a normative clause for “Guest-originated ready signal” that preserves “Host process creation alone does not establish guest readiness”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M02.02-C071-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Guest-originated ready signal”; include the source counterexample “The launcher declares readiness before receiving a guest signal” and the intended safe disposition.
- [ ] **UC-M02.02-C071-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Ready-signal bytes and readiness deadline” in the “Guest-originated ready signal” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M02.02-C071-T10 · Contract review:** Review the “Guest-originated ready signal” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M02.02-C072 · Delivery

**Original checklist item:** Emit a ready signal from the guest only after required initialization succeeds.

- [ ] **UC-M02.02-C072-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Guest-originated ready signal”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M02.02-C072-T02 · Change plan:** Break the source delivery for “Guest-originated ready signal” into concrete edit targets and reviewable outputs; keep the UC-M02.02 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M02.02-C072-T03 · Core artifact:** Implement the smallest selected-profile change for “Guest-originated ready signal” that realizes this source instruction: Emit a ready signal from the guest only after required initialization succeeds.
- [ ] **UC-M02.02-C072-T04 · Concrete realization:** Trace “Guest-originated ready signal” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M02.02-C072-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Guest-originated ready signal” needed to preserve “Host process creation alone does not establish guest readiness”; record an enforcement gap where only a model exists.
- [ ] **UC-M02.02-C072-T06 · Dependency connection:** Connect the “Guest-originated ready signal” implementation to the selected loader, guest startup sequence and ready-signal receiver; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M02.02-C072-T07 · Resource behavior:** Account for “Ready-signal bytes and readiness deadline” in “Guest-originated ready signal”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M02.02-C072-T08 · Delivery check:** Run the smallest real “Guest-originated ready signal” path and its adverse fixture “The launcher declares readiness before receiving a guest signal”; retain actual output, state effects and final disposition.
- [ ] **UC-M02.02-C072-T09 · Patch review:** Review the “Guest-originated ready signal” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M02.02-C072-T10 · Delivery handoff:** Publish the “Guest-originated ready signal” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M02.02-C073 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Host process creation alone does not establish guest readiness. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M02.02-C073-T01 · Named property:** Create a stable property/check name under this parent for “Guest-originated ready signal”; copy its required invariant exactly: “Host process creation alone does not establish guest readiness”.
- [ ] **UC-M02.02-C073-T02 · Observable terms:** Define each term in the “Guest-originated ready signal” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M02.02-C073-T03 · Precondition set:** List the preconditions under which “Host process creation alone does not establish guest readiness” must hold for “Guest-originated ready signal”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M02.02-C073-T04 · Transition coverage:** Map the “Guest-originated ready signal” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M02.02-C073-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Guest-originated ready signal”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M02.02-C073-T06 · Satisfying fixture:** Create a concrete “Guest-originated ready signal” case that satisfies “Host process creation alone does not establish guest readiness”; record its expected observation before running the assertion or review.
- [ ] **UC-M02.02-C073-T07 · Violating fixture:** Create the source counterexample “The launcher declares readiness before receiving a guest signal” for “Guest-originated ready signal”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M02.02-C073-T08 · Enforcement evidence:** Exercise the “Guest-originated ready signal” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M02.02-C073-T09 · Regression linkage:** Link the “Guest-originated ready signal” property to changes in the selected loader, guest startup sequence and ready-signal receiver; record which dependency or contract changes require rerunning it.
- [ ] **UC-M02.02-C073-T10 · Property disposition:** Compare the satisfying and violating “Guest-originated ready signal” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M02.02-C074 · Integration

**Original checklist item:** Integrate guest-originated ready signal with the selected loader, guest startup sequence and ready-signal receiver; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M02.02-C074-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Guest-originated ready signal” across the selected loader, guest startup sequence and ready-signal receiver; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M02.02-C074-T02 · Field mapping:** Map every “Guest-originated ready signal” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M02.02-C074-T03 · Prerequisite identities:** Record the actual prerequisites for “Guest-originated ready signal” (source dependency list: UC-M02.01); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M02.02-C074-T04 · Ownership agreement:** Specify who owns “Guest-originated ready signal” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M02.02-C074-T05 · Handoff implementation:** Connect “Guest-originated ready signal” through the mapped seam using the real adapter or explicit specification reference; preserve “Host process creation alone does not establish guest readiness” across the handoff.
- [ ] **UC-M02.02-C074-T06 · Absent-input case:** Omit one required “Guest-originated ready signal” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M02.02-C074-T07 · Stale-input case:** Supply an outdated “Guest-originated ready signal” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M02.02-C074-T08 · Incompatible-input case:** Supply an incompatible “Guest-originated ready signal” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M02.02-C074-T09 · Valid integration trace:** Run a valid “Guest-originated ready signal” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M02.02-C074-T10 · Seam review:** Reconcile the “Guest-originated ready signal” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M02.02-C075 · Valid-case test

**Original checklist item:** Run a valid-path fixture for guest-originated ready signal; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M02.02-C075-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Guest-originated ready signal” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M02.02-C075-T02 · Expected-result oracle:** Specify the “Guest-originated ready signal” expected result independently of the implementation output; include the property “Host process creation alone does not establish guest readiness” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M02.02-C075-T03 · Fixture material:** Create the concrete “Guest-originated ready signal” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M02.02-C075-T04 · Target preparation:** Prepare the “Guest-originated ready signal” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M02.02-C075-T05 · Initial-state record:** Record the initial “Guest-originated ready signal” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M02.02-C075-T06 · Valid-path execution:** Execute the “Guest-originated ready signal” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M02.02-C075-T07 · Outcome comparison:** Compare every declared “Guest-originated ready signal” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M02.02-C075-T08 · State and bounds check:** Inspect the “Guest-originated ready signal” ownership/state effects and actual use of “Ready-signal bytes and readiness deadline”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M02.02-C075-T09 · Repeatability check:** Repeat the same “Guest-originated ready signal” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M02.02-C075-T10 · Positive evidence:** Attach the “Guest-originated ready signal” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M02.02-C076 · Negative test

**Original checklist item:** Negative case: The launcher declares readiness before receiving a guest signal. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M02.02-C076-T01 · Adverse-case definition:** Create a test record for the exact “Guest-originated ready signal” source counterexample: “The launcher declares readiness before receiving a guest signal”; state which precondition or invariant it challenges.
- [ ] **UC-M02.02-C076-T02 · Safe fixture boundary:** Define the contained test boundary for “Guest-originated ready signal”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M02.02-C076-T03 · Valid control:** Construct a valid “Guest-originated ready signal” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M02.02-C076-T04 · Minimal adverse input:** Derive the “Guest-originated ready signal” adverse fixture from the control with the smallest documented change needed to reproduce “The launcher declares readiness before receiving a guest signal”; retain that change as reproducible data.
- [ ] **UC-M02.02-C076-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Guest-originated ready signal”; require “Host process creation alone does not establish guest readiness” and forbid a false-success verdict.
- [ ] **UC-M02.02-C076-T06 · Adverse execution:** Exercise the “Guest-originated ready signal” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M02.02-C076-T07 · Effect inspection:** Inspect “Guest-originated ready signal” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M02.02-C076-T08 · Refusal versus failure:** Confirm the “Guest-originated ready signal” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M02.02-C076-T09 · Reset and retention:** Restore only the disposable “Guest-originated ready signal” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M02.02-C076-T10 · Negative regression:** Register the “Guest-originated ready signal” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M02.02-C077 · Change / failure test

**Original checklist item:** Exercise guest-originated ready signal when startup is interrupted before guest readiness has been emitted; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M02.02-C077-T01 · Scenario record:** Write the “Guest-originated ready signal” change/failure scenario exactly as supplied: startup is interrupted before guest readiness has been emitted; identify the property that must remain true: “Host process creation alone does not establish guest readiness”.
- [ ] **UC-M02.02-C077-T02 · Baseline capture:** Create a known-valid “Guest-originated ready signal” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M02.02-C077-T03 · Injection map:** Locate the “Guest-originated ready signal” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M02.02-C077-T04 · Disposition oracle:** Define the legal intermediate and final “Guest-originated ready signal” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M02.02-C077-T05 · Controlled trigger:** Introduce the controlled “Guest-originated ready signal” scenario in the disposable fixture: startup is interrupted before guest readiness has been emitted; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M02.02-C077-T06 · Intermediate inspection:** Inspect the “Guest-originated ready signal” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M02.02-C077-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Guest-originated ready signal”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M02.02-C077-T08 · Stale-evidence cleanup:** Invalidate superseded “Guest-originated ready signal” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M02.02-C077-T09 · Repeat and compare:** Repeat the selected “Guest-originated ready signal” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M02.02-C077-T10 · Failure evidence:** Publish the “Guest-originated ready signal” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M02.02-C078 · Bounds

**Original checklist item:** Choose, document and test limits for ready-signal bytes and readiness deadline; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M02.02-C078-T01 · Quantity inventory:** Create a measurement inventory for “Guest-originated ready signal”: “Ready-signal bytes and readiness deadline”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M02.02-C078-T02 · Measurement method:** Choose how to observe each “Guest-originated ready signal” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M02.02-C078-T03 · Budget decision:** Select justified resource and input limits for “Guest-originated ready signal”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M02.02-C078-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Guest-originated ready signal” cases for “Ready-signal bytes and readiness deadline”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M02.02-C078-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Guest-originated ready signal” limit; preserve “Host process creation alone does not establish guest readiness”.
- [ ] **UC-M02.02-C078-T06 · Normal measurement:** Run or review the normal “Guest-originated ready signal” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M02.02-C078-T07 · At-limit measurement:** Exercise the “Guest-originated ready signal” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M02.02-C078-T08 · Over-limit measurement:** Exercise the “Guest-originated ready signal” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M02.02-C078-T09 · Uncovered-scope report:** List the “Guest-originated ready signal” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M02.02-C078-T10 · Limit evidence:** Publish the selected “Guest-originated ready signal” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M02.02-C079 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for guest-originated ready signal with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M02.02-C079-T01 · Event inventory:** List the “Guest-originated ready signal” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M02.02-C079-T02 · Diagnostic schema:** Define nonsecret fields for “Guest-originated ready signal” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M02.02-C079-T03 · Failure mapping:** Map each documented “Guest-originated ready signal” refusal or error to a diagnostic outcome; include “The launcher declares readiness before receiving a guest signal” and prohibit conversion into a success message.
- [ ] **UC-M02.02-C079-T04 · Emission path:** Add the “Guest-originated ready signal” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M02.02-C079-T05 · Redaction check:** Test “Guest-originated ready signal” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M02.02-C079-T06 · Output budget:** Set and exercise bounded “Guest-originated ready signal” message size, rate and retention compatible with “Ready-signal bytes and readiness deadline”; define truncation behavior that preserves the final reason.
- [ ] **UC-M02.02-C079-T07 · Success/refusal fixtures:** Capture “Guest-originated ready signal” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M02.02-C079-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Guest-originated ready signal” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M02.02-C079-T09 · Operator review:** Read the “Guest-originated ready signal” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M02.02-C079-T10 · Diagnostic evidence:** Publish redacted “Guest-originated ready signal” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M02.02-C080 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for guest-originated ready signal; label unexecuted checks as untested.

- [ ] **UC-M02.02-C080-T01 · Evidence inventory:** List the “Guest-originated ready signal” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M02.02-C080-T02 · Artifact references:** Record the exact “Guest-originated ready signal” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M02.02-C080-T03 · Fixture references:** Attach the “Guest-originated ready signal” fixture IDs, input identities and oracle definition; preserve the source counterexample “The launcher declares readiness before receiving a guest signal” as a distinct evidence case.
- [ ] **UC-M02.02-C080-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Guest-originated ready signal”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M02.02-C080-T05 · Environment record:** Record the actual “Guest-originated ready signal” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M02.02-C080-T06 · Expected versus observed:** Pair every “Guest-originated ready signal” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M02.02-C080-T07 · Failure and limit records:** Attach “Guest-originated ready signal” change/failure and bounds evidence where required; include uncovered “Ready-signal bytes and readiness deadline” and unresolved violations of “Host process creation alone does not establish guest readiness”.
- [ ] **UC-M02.02-C080-T08 · Evidence hygiene:** Check the “Guest-originated ready signal” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M02.02-C080-T09 · Reproduction review:** Have the “Guest-originated ready signal” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M02.02-C080-T10 · Acceptance linkage:** Link the “Guest-originated ready signal” evidence to its parent and UC-M02.02 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 09. Startup failure reporting

**Source delivery:** Return bounded stage-specific failures for rejected or incomplete boot.

**Source invariant:** An early boot failure does not become a successful ready state.

**Source negative case:** Initialization fails after partial device setup.

**Source bounded quantities:** Failure record size and cleanup timeout.

### UC-M02.02-C081 · Contract

**Original checklist item:** Specify startup failure reporting inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M02.02-C081-T01 · Scope statement:** Draft the operation boundary for “Startup failure reporting” within Boot ABI and startup path; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M02.02-C081-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Startup failure reporting”; record each producer, representation and missing-value meaning.
- [ ] **UC-M02.02-C081-T03 · Output inventory:** List the outputs of “Startup failure reporting” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M02.02-C081-T04 · Field dictionary:** Create a field-and-term dictionary for “Startup failure reporting”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M02.02-C081-T05 · Prerequisite contract:** Map “Startup failure reporting” to the source component prerequisites (UC-M02.01); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M02.02-C081-T06 · Authority map:** Identify who may produce, change and consume “Startup failure reporting”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M02.02-C081-T07 · Invariant clause:** Add a normative clause for “Startup failure reporting” that preserves “An early boot failure does not become a successful ready state”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M02.02-C081-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Startup failure reporting”; include the source counterexample “Initialization fails after partial device setup” and the intended safe disposition.
- [ ] **UC-M02.02-C081-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Failure record size and cleanup timeout” in the “Startup failure reporting” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M02.02-C081-T10 · Contract review:** Review the “Startup failure reporting” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M02.02-C082 · Delivery

**Original checklist item:** Return bounded stage-specific failures for rejected or incomplete boot.

- [ ] **UC-M02.02-C082-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Startup failure reporting”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M02.02-C082-T02 · Change plan:** Break the source delivery for “Startup failure reporting” into concrete edit targets and reviewable outputs; keep the UC-M02.02 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M02.02-C082-T03 · Core artifact:** Implement the smallest selected-profile change for “Startup failure reporting” that realizes this source instruction: Return bounded stage-specific failures for rejected or incomplete boot.
- [ ] **UC-M02.02-C082-T04 · Concrete realization:** Trace “Startup failure reporting” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M02.02-C082-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Startup failure reporting” needed to preserve “An early boot failure does not become a successful ready state”; record an enforcement gap where only a model exists.
- [ ] **UC-M02.02-C082-T06 · Dependency connection:** Connect the “Startup failure reporting” implementation to the selected loader, guest startup sequence and ready-signal receiver; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M02.02-C082-T07 · Resource behavior:** Account for “Failure record size and cleanup timeout” in “Startup failure reporting”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M02.02-C082-T08 · Delivery check:** Run the smallest real “Startup failure reporting” path and its adverse fixture “Initialization fails after partial device setup”; retain actual output, state effects and final disposition.
- [ ] **UC-M02.02-C082-T09 · Patch review:** Review the “Startup failure reporting” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M02.02-C082-T10 · Delivery handoff:** Publish the “Startup failure reporting” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M02.02-C083 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: An early boot failure does not become a successful ready state. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M02.02-C083-T01 · Named property:** Create a stable property/check name under this parent for “Startup failure reporting”; copy its required invariant exactly: “An early boot failure does not become a successful ready state”.
- [ ] **UC-M02.02-C083-T02 · Observable terms:** Define each term in the “Startup failure reporting” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M02.02-C083-T03 · Precondition set:** List the preconditions under which “An early boot failure does not become a successful ready state” must hold for “Startup failure reporting”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M02.02-C083-T04 · Transition coverage:** Map the “Startup failure reporting” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M02.02-C083-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Startup failure reporting”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M02.02-C083-T06 · Satisfying fixture:** Create a concrete “Startup failure reporting” case that satisfies “An early boot failure does not become a successful ready state”; record its expected observation before running the assertion or review.
- [ ] **UC-M02.02-C083-T07 · Violating fixture:** Create the source counterexample “Initialization fails after partial device setup” for “Startup failure reporting”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M02.02-C083-T08 · Enforcement evidence:** Exercise the “Startup failure reporting” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M02.02-C083-T09 · Regression linkage:** Link the “Startup failure reporting” property to changes in the selected loader, guest startup sequence and ready-signal receiver; record which dependency or contract changes require rerunning it.
- [ ] **UC-M02.02-C083-T10 · Property disposition:** Compare the satisfying and violating “Startup failure reporting” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M02.02-C084 · Integration

**Original checklist item:** Integrate startup failure reporting with the selected loader, guest startup sequence and ready-signal receiver; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M02.02-C084-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Startup failure reporting” across the selected loader, guest startup sequence and ready-signal receiver; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M02.02-C084-T02 · Field mapping:** Map every “Startup failure reporting” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M02.02-C084-T03 · Prerequisite identities:** Record the actual prerequisites for “Startup failure reporting” (source dependency list: UC-M02.01); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M02.02-C084-T04 · Ownership agreement:** Specify who owns “Startup failure reporting” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M02.02-C084-T05 · Handoff implementation:** Connect “Startup failure reporting” through the mapped seam using the real adapter or explicit specification reference; preserve “An early boot failure does not become a successful ready state” across the handoff.
- [ ] **UC-M02.02-C084-T06 · Absent-input case:** Omit one required “Startup failure reporting” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M02.02-C084-T07 · Stale-input case:** Supply an outdated “Startup failure reporting” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M02.02-C084-T08 · Incompatible-input case:** Supply an incompatible “Startup failure reporting” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M02.02-C084-T09 · Valid integration trace:** Run a valid “Startup failure reporting” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M02.02-C084-T10 · Seam review:** Reconcile the “Startup failure reporting” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M02.02-C085 · Valid-case test

**Original checklist item:** Run a valid-path fixture for startup failure reporting; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M02.02-C085-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Startup failure reporting” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M02.02-C085-T02 · Expected-result oracle:** Specify the “Startup failure reporting” expected result independently of the implementation output; include the property “An early boot failure does not become a successful ready state” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M02.02-C085-T03 · Fixture material:** Create the concrete “Startup failure reporting” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M02.02-C085-T04 · Target preparation:** Prepare the “Startup failure reporting” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M02.02-C085-T05 · Initial-state record:** Record the initial “Startup failure reporting” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M02.02-C085-T06 · Valid-path execution:** Execute the “Startup failure reporting” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M02.02-C085-T07 · Outcome comparison:** Compare every declared “Startup failure reporting” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M02.02-C085-T08 · State and bounds check:** Inspect the “Startup failure reporting” ownership/state effects and actual use of “Failure record size and cleanup timeout”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M02.02-C085-T09 · Repeatability check:** Repeat the same “Startup failure reporting” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M02.02-C085-T10 · Positive evidence:** Attach the “Startup failure reporting” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M02.02-C086 · Negative test

**Original checklist item:** Negative case: Initialization fails after partial device setup. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M02.02-C086-T01 · Adverse-case definition:** Create a test record for the exact “Startup failure reporting” source counterexample: “Initialization fails after partial device setup”; state which precondition or invariant it challenges.
- [ ] **UC-M02.02-C086-T02 · Safe fixture boundary:** Define the contained test boundary for “Startup failure reporting”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M02.02-C086-T03 · Valid control:** Construct a valid “Startup failure reporting” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M02.02-C086-T04 · Minimal adverse input:** Derive the “Startup failure reporting” adverse fixture from the control with the smallest documented change needed to reproduce “Initialization fails after partial device setup”; retain that change as reproducible data.
- [ ] **UC-M02.02-C086-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Startup failure reporting”; require “An early boot failure does not become a successful ready state” and forbid a false-success verdict.
- [ ] **UC-M02.02-C086-T06 · Adverse execution:** Exercise the “Startup failure reporting” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M02.02-C086-T07 · Effect inspection:** Inspect “Startup failure reporting” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M02.02-C086-T08 · Refusal versus failure:** Confirm the “Startup failure reporting” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M02.02-C086-T09 · Reset and retention:** Restore only the disposable “Startup failure reporting” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M02.02-C086-T10 · Negative regression:** Register the “Startup failure reporting” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M02.02-C087 · Change / failure test

**Original checklist item:** Exercise startup failure reporting when startup is interrupted before guest readiness has been emitted; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M02.02-C087-T01 · Scenario record:** Write the “Startup failure reporting” change/failure scenario exactly as supplied: startup is interrupted before guest readiness has been emitted; identify the property that must remain true: “An early boot failure does not become a successful ready state”.
- [ ] **UC-M02.02-C087-T02 · Baseline capture:** Create a known-valid “Startup failure reporting” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M02.02-C087-T03 · Injection map:** Locate the “Startup failure reporting” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M02.02-C087-T04 · Disposition oracle:** Define the legal intermediate and final “Startup failure reporting” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M02.02-C087-T05 · Controlled trigger:** Introduce the controlled “Startup failure reporting” scenario in the disposable fixture: startup is interrupted before guest readiness has been emitted; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M02.02-C087-T06 · Intermediate inspection:** Inspect the “Startup failure reporting” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M02.02-C087-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Startup failure reporting”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M02.02-C087-T08 · Stale-evidence cleanup:** Invalidate superseded “Startup failure reporting” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M02.02-C087-T09 · Repeat and compare:** Repeat the selected “Startup failure reporting” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M02.02-C087-T10 · Failure evidence:** Publish the “Startup failure reporting” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M02.02-C088 · Bounds

**Original checklist item:** Choose, document and test limits for failure record size and cleanup timeout; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M02.02-C088-T01 · Quantity inventory:** Create a measurement inventory for “Startup failure reporting”: “Failure record size and cleanup timeout”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M02.02-C088-T02 · Measurement method:** Choose how to observe each “Startup failure reporting” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M02.02-C088-T03 · Budget decision:** Select justified resource and input limits for “Startup failure reporting”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M02.02-C088-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Startup failure reporting” cases for “Failure record size and cleanup timeout”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M02.02-C088-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Startup failure reporting” limit; preserve “An early boot failure does not become a successful ready state”.
- [ ] **UC-M02.02-C088-T06 · Normal measurement:** Run or review the normal “Startup failure reporting” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M02.02-C088-T07 · At-limit measurement:** Exercise the “Startup failure reporting” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M02.02-C088-T08 · Over-limit measurement:** Exercise the “Startup failure reporting” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M02.02-C088-T09 · Uncovered-scope report:** List the “Startup failure reporting” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M02.02-C088-T10 · Limit evidence:** Publish the selected “Startup failure reporting” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M02.02-C089 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for startup failure reporting with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M02.02-C089-T01 · Event inventory:** List the “Startup failure reporting” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M02.02-C089-T02 · Diagnostic schema:** Define nonsecret fields for “Startup failure reporting” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M02.02-C089-T03 · Failure mapping:** Map each documented “Startup failure reporting” refusal or error to a diagnostic outcome; include “Initialization fails after partial device setup” and prohibit conversion into a success message.
- [ ] **UC-M02.02-C089-T04 · Emission path:** Add the “Startup failure reporting” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M02.02-C089-T05 · Redaction check:** Test “Startup failure reporting” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M02.02-C089-T06 · Output budget:** Set and exercise bounded “Startup failure reporting” message size, rate and retention compatible with “Failure record size and cleanup timeout”; define truncation behavior that preserves the final reason.
- [ ] **UC-M02.02-C089-T07 · Success/refusal fixtures:** Capture “Startup failure reporting” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M02.02-C089-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Startup failure reporting” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M02.02-C089-T09 · Operator review:** Read the “Startup failure reporting” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M02.02-C089-T10 · Diagnostic evidence:** Publish redacted “Startup failure reporting” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M02.02-C090 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for startup failure reporting; label unexecuted checks as untested.

- [ ] **UC-M02.02-C090-T01 · Evidence inventory:** List the “Startup failure reporting” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M02.02-C090-T02 · Artifact references:** Record the exact “Startup failure reporting” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M02.02-C090-T03 · Fixture references:** Attach the “Startup failure reporting” fixture IDs, input identities and oracle definition; preserve the source counterexample “Initialization fails after partial device setup” as a distinct evidence case.
- [ ] **UC-M02.02-C090-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Startup failure reporting”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M02.02-C090-T05 · Environment record:** Record the actual “Startup failure reporting” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M02.02-C090-T06 · Expected versus observed:** Pair every “Startup failure reporting” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M02.02-C090-T07 · Failure and limit records:** Attach “Startup failure reporting” change/failure and bounds evidence where required; include uncovered “Failure record size and cleanup timeout” and unresolved violations of “An early boot failure does not become a successful ready state”.
- [ ] **UC-M02.02-C090-T08 · Evidence hygiene:** Check the “Startup failure reporting” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M02.02-C090-T09 · Reproduction review:** Have the “Startup failure reporting” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M02.02-C090-T10 · Acceptance linkage:** Link the “Startup failure reporting” evidence to its parent and UC-M02.02 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 10. Boot-path qualification

**Source delivery:** Exercise the complete selected VMM-to-guest startup path from the built image.

**Source invariant:** Boot qualification demonstrates guest execution without a conventional guest OS boot.

**Source negative case:** A host emulator stub replaces the actual guest entry path.

**Source bounded quantities:** Boot repetitions and supported configuration matrix.

### UC-M02.02-C091 · Contract

**Original checklist item:** Specify boot-path qualification inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M02.02-C091-T01 · Scope statement:** Draft the operation boundary for “Boot-path qualification” within Boot ABI and startup path; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M02.02-C091-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Boot-path qualification”; record each producer, representation and missing-value meaning.
- [ ] **UC-M02.02-C091-T03 · Output inventory:** List the outputs of “Boot-path qualification” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M02.02-C091-T04 · Field dictionary:** Create a field-and-term dictionary for “Boot-path qualification”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M02.02-C091-T05 · Prerequisite contract:** Map “Boot-path qualification” to the source component prerequisites (UC-M02.01); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M02.02-C091-T06 · Authority map:** Identify who may produce, change and consume “Boot-path qualification”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M02.02-C091-T07 · Invariant clause:** Add a normative clause for “Boot-path qualification” that preserves “Boot qualification demonstrates guest execution without a conventional guest OS boot”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M02.02-C091-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Boot-path qualification”; include the source counterexample “A host emulator stub replaces the actual guest entry path” and the intended safe disposition.
- [ ] **UC-M02.02-C091-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Boot repetitions and supported configuration matrix” in the “Boot-path qualification” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M02.02-C091-T10 · Contract review:** Review the “Boot-path qualification” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M02.02-C092 · Delivery

**Original checklist item:** Exercise the complete selected VMM-to-guest startup path from the built image.

- [ ] **UC-M02.02-C092-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Boot-path qualification”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M02.02-C092-T02 · Change plan:** Break the source delivery for “Boot-path qualification” into concrete edit targets and reviewable outputs; keep the UC-M02.02 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M02.02-C092-T03 · Core artifact:** Create the “Boot-path qualification” fixture or harness for this source instruction: Exercise the complete selected VMM-to-guest startup path from the built image.
- [ ] **UC-M02.02-C092-T04 · Concrete realization:** Connect the “Boot-path qualification” harness to its actual intended target, set the expected oracle before running it, and distinguish a mock/control run from a target run.
- [ ] **UC-M02.02-C092-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Boot-path qualification” needed to preserve “Boot qualification demonstrates guest execution without a conventional guest OS boot”; record an enforcement gap where only a model exists.
- [ ] **UC-M02.02-C092-T06 · Dependency connection:** Connect the “Boot-path qualification” implementation to the selected loader, guest startup sequence and ready-signal receiver; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M02.02-C092-T07 · Resource behavior:** Account for “Boot repetitions and supported configuration matrix” in “Boot-path qualification”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M02.02-C092-T08 · Delivery check:** Run the smallest real “Boot-path qualification” path and its adverse fixture “A host emulator stub replaces the actual guest entry path”; retain actual output, state effects and final disposition.
- [ ] **UC-M02.02-C092-T09 · Patch review:** Review the “Boot-path qualification” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M02.02-C092-T10 · Delivery handoff:** Publish the “Boot-path qualification” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M02.02-C093 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Boot qualification demonstrates guest execution without a conventional guest OS boot. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M02.02-C093-T01 · Named property:** Create a stable property/check name under this parent for “Boot-path qualification”; copy its required invariant exactly: “Boot qualification demonstrates guest execution without a conventional guest OS boot”.
- [ ] **UC-M02.02-C093-T02 · Observable terms:** Define each term in the “Boot-path qualification” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M02.02-C093-T03 · Precondition set:** List the preconditions under which “Boot qualification demonstrates guest execution without a conventional guest OS boot” must hold for “Boot-path qualification”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M02.02-C093-T04 · Transition coverage:** Map the “Boot-path qualification” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M02.02-C093-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Boot-path qualification”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M02.02-C093-T06 · Satisfying fixture:** Create a concrete “Boot-path qualification” case that satisfies “Boot qualification demonstrates guest execution without a conventional guest OS boot”; record its expected observation before running the assertion or review.
- [ ] **UC-M02.02-C093-T07 · Violating fixture:** Create the source counterexample “A host emulator stub replaces the actual guest entry path” for “Boot-path qualification”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M02.02-C093-T08 · Enforcement evidence:** Exercise the “Boot-path qualification” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M02.02-C093-T09 · Regression linkage:** Link the “Boot-path qualification” property to changes in the selected loader, guest startup sequence and ready-signal receiver; record which dependency or contract changes require rerunning it.
- [ ] **UC-M02.02-C093-T10 · Property disposition:** Compare the satisfying and violating “Boot-path qualification” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M02.02-C094 · Integration

**Original checklist item:** Integrate boot-path qualification with the selected loader, guest startup sequence and ready-signal receiver; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M02.02-C094-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Boot-path qualification” across the selected loader, guest startup sequence and ready-signal receiver; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M02.02-C094-T02 · Field mapping:** Map every “Boot-path qualification” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M02.02-C094-T03 · Prerequisite identities:** Record the actual prerequisites for “Boot-path qualification” (source dependency list: UC-M02.01); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M02.02-C094-T04 · Ownership agreement:** Specify who owns “Boot-path qualification” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M02.02-C094-T05 · Handoff implementation:** Connect “Boot-path qualification” through the mapped seam using the real adapter or explicit specification reference; preserve “Boot qualification demonstrates guest execution without a conventional guest OS boot” across the handoff.
- [ ] **UC-M02.02-C094-T06 · Absent-input case:** Omit one required “Boot-path qualification” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M02.02-C094-T07 · Stale-input case:** Supply an outdated “Boot-path qualification” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M02.02-C094-T08 · Incompatible-input case:** Supply an incompatible “Boot-path qualification” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M02.02-C094-T09 · Valid integration trace:** Run a valid “Boot-path qualification” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M02.02-C094-T10 · Seam review:** Reconcile the “Boot-path qualification” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M02.02-C095 · Valid-case test

**Original checklist item:** Run a valid-path fixture for boot-path qualification; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M02.02-C095-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Boot-path qualification” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M02.02-C095-T02 · Expected-result oracle:** Specify the “Boot-path qualification” expected result independently of the implementation output; include the property “Boot qualification demonstrates guest execution without a conventional guest OS boot” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M02.02-C095-T03 · Fixture material:** Create the concrete “Boot-path qualification” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M02.02-C095-T04 · Target preparation:** Prepare the “Boot-path qualification” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M02.02-C095-T05 · Initial-state record:** Record the initial “Boot-path qualification” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M02.02-C095-T06 · Valid-path execution:** Execute the “Boot-path qualification” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M02.02-C095-T07 · Outcome comparison:** Compare every declared “Boot-path qualification” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M02.02-C095-T08 · State and bounds check:** Inspect the “Boot-path qualification” ownership/state effects and actual use of “Boot repetitions and supported configuration matrix”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M02.02-C095-T09 · Repeatability check:** Repeat the same “Boot-path qualification” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M02.02-C095-T10 · Positive evidence:** Attach the “Boot-path qualification” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M02.02-C096 · Negative test

**Original checklist item:** Negative case: A host emulator stub replaces the actual guest entry path. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M02.02-C096-T01 · Adverse-case definition:** Create a test record for the exact “Boot-path qualification” source counterexample: “A host emulator stub replaces the actual guest entry path”; state which precondition or invariant it challenges.
- [ ] **UC-M02.02-C096-T02 · Safe fixture boundary:** Define the contained test boundary for “Boot-path qualification”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M02.02-C096-T03 · Valid control:** Construct a valid “Boot-path qualification” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M02.02-C096-T04 · Minimal adverse input:** Derive the “Boot-path qualification” adverse fixture from the control with the smallest documented change needed to reproduce “A host emulator stub replaces the actual guest entry path”; retain that change as reproducible data.
- [ ] **UC-M02.02-C096-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Boot-path qualification”; require “Boot qualification demonstrates guest execution without a conventional guest OS boot” and forbid a false-success verdict.
- [ ] **UC-M02.02-C096-T06 · Adverse execution:** Exercise the “Boot-path qualification” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M02.02-C096-T07 · Effect inspection:** Inspect “Boot-path qualification” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M02.02-C096-T08 · Refusal versus failure:** Confirm the “Boot-path qualification” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M02.02-C096-T09 · Reset and retention:** Restore only the disposable “Boot-path qualification” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M02.02-C096-T10 · Negative regression:** Register the “Boot-path qualification” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M02.02-C097 · Change / failure test

**Original checklist item:** Exercise boot-path qualification when startup is interrupted before guest readiness has been emitted; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M02.02-C097-T01 · Scenario record:** Write the “Boot-path qualification” change/failure scenario exactly as supplied: startup is interrupted before guest readiness has been emitted; identify the property that must remain true: “Boot qualification demonstrates guest execution without a conventional guest OS boot”.
- [ ] **UC-M02.02-C097-T02 · Baseline capture:** Create a known-valid “Boot-path qualification” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M02.02-C097-T03 · Injection map:** Locate the “Boot-path qualification” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M02.02-C097-T04 · Disposition oracle:** Define the legal intermediate and final “Boot-path qualification” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M02.02-C097-T05 · Controlled trigger:** Introduce the controlled “Boot-path qualification” scenario in the disposable fixture: startup is interrupted before guest readiness has been emitted; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M02.02-C097-T06 · Intermediate inspection:** Inspect the “Boot-path qualification” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M02.02-C097-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Boot-path qualification”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M02.02-C097-T08 · Stale-evidence cleanup:** Invalidate superseded “Boot-path qualification” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M02.02-C097-T09 · Repeat and compare:** Repeat the selected “Boot-path qualification” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M02.02-C097-T10 · Failure evidence:** Publish the “Boot-path qualification” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M02.02-C098 · Bounds

**Original checklist item:** Choose, document and test limits for boot repetitions and supported configuration matrix; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M02.02-C098-T01 · Quantity inventory:** Create a measurement inventory for “Boot-path qualification”: “Boot repetitions and supported configuration matrix”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M02.02-C098-T02 · Measurement method:** Choose how to observe each “Boot-path qualification” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M02.02-C098-T03 · Budget decision:** Select justified resource and input limits for “Boot-path qualification”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M02.02-C098-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Boot-path qualification” cases for “Boot repetitions and supported configuration matrix”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M02.02-C098-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Boot-path qualification” limit; preserve “Boot qualification demonstrates guest execution without a conventional guest OS boot”.
- [ ] **UC-M02.02-C098-T06 · Normal measurement:** Run or review the normal “Boot-path qualification” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M02.02-C098-T07 · At-limit measurement:** Exercise the “Boot-path qualification” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M02.02-C098-T08 · Over-limit measurement:** Exercise the “Boot-path qualification” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M02.02-C098-T09 · Uncovered-scope report:** List the “Boot-path qualification” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M02.02-C098-T10 · Limit evidence:** Publish the selected “Boot-path qualification” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M02.02-C099 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for boot-path qualification with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M02.02-C099-T01 · Event inventory:** List the “Boot-path qualification” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M02.02-C099-T02 · Diagnostic schema:** Define nonsecret fields for “Boot-path qualification” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M02.02-C099-T03 · Failure mapping:** Map each documented “Boot-path qualification” refusal or error to a diagnostic outcome; include “A host emulator stub replaces the actual guest entry path” and prohibit conversion into a success message.
- [ ] **UC-M02.02-C099-T04 · Emission path:** Add the “Boot-path qualification” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M02.02-C099-T05 · Redaction check:** Test “Boot-path qualification” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M02.02-C099-T06 · Output budget:** Set and exercise bounded “Boot-path qualification” message size, rate and retention compatible with “Boot repetitions and supported configuration matrix”; define truncation behavior that preserves the final reason.
- [ ] **UC-M02.02-C099-T07 · Success/refusal fixtures:** Capture “Boot-path qualification” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M02.02-C099-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Boot-path qualification” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M02.02-C099-T09 · Operator review:** Read the “Boot-path qualification” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M02.02-C099-T10 · Diagnostic evidence:** Publish redacted “Boot-path qualification” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M02.02-C100 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for boot-path qualification; label unexecuted checks as untested.

- [ ] **UC-M02.02-C100-T01 · Evidence inventory:** List the “Boot-path qualification” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M02.02-C100-T02 · Artifact references:** Record the exact “Boot-path qualification” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M02.02-C100-T03 · Fixture references:** Attach the “Boot-path qualification” fixture IDs, input identities and oracle definition; preserve the source counterexample “A host emulator stub replaces the actual guest entry path” as a distinct evidence case.
- [ ] **UC-M02.02-C100-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Boot-path qualification”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M02.02-C100-T05 · Environment record:** Record the actual “Boot-path qualification” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M02.02-C100-T06 · Expected versus observed:** Pair every “Boot-path qualification” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M02.02-C100-T07 · Failure and limit records:** Attach “Boot-path qualification” change/failure and bounds evidence where required; include uncovered “Boot repetitions and supported configuration matrix” and unresolved violations of “Boot qualification demonstrates guest execution without a conventional guest OS boot”.
- [ ] **UC-M02.02-C100-T08 · Evidence hygiene:** Check the “Boot-path qualification” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M02.02-C100-T09 · Reproduction review:** Have the “Boot-path qualification” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M02.02-C100-T10 · Acceptance linkage:** Link the “Boot-path qualification” evidence to its parent and UC-M02.02 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

