# UC-M02.06 — Clock and entropy interfaces

**To-Do Pack 2.0.0 · Baseline UC-2.2.0 · 100 parent checks × 10 subtasks = 1,000 to-dos**

[Master index](../../INDEX.md) · [Workstream index](../../w/02.md)

| Field | Preserved source value |
|---|---|
| Workstream | 02. Bootable unikernel guest |
| Milestone | B |
| Priority | P0 |
| Source assessment | MISSING |
| Scope | core or selected profile |
| Dependencies | [UC-M02.02](../02/UC-M02.02.md) |
| Source checklist pack | 1.0.0 |
| Original reference labels | [S1], [S2], [S3]. |

## Original requirement

Keep deterministic simulation time separate from real monotonic time and cryptographic randomness; validate boot-time availability.

**Original acceptance criterion:** Replay uses recorded inputs while security keys never derive from deterministic witness seeds or replay clocks.

**Source trace:** Original checklist `UC100/c/02/UC-M02.06.md` inside [s/checklists.zip](../../s/checklists.zip); exact parent records in [data/parents.jsonl](../../data/parents.jsonl). Original roadmap lines 199–209 are preserved in [s/roadmap.md](../../s/roadmap.md).

## How to use these lists

Every parent statement below is preserved verbatim. Its ten child tasks are proposed decomposition, not implemented capabilities or executed tests. Child IDs append `-T01` through `-T10` to the original parent ID. All begin unchecked / `TODO`. Design/review evidence does not establish runtime enforcement; observe the actual selected target where the parent requires it.

The source dependency graph and selected release profile determine applicability. The numbered child sequence is a local working order, not an added hard dependency graph. An unselected optional feature needs a recorded not-applicable rationale; missing prerequisites for selected work remain blockers. Numerical budgets, backends and trust mechanisms remain decisions unless fixed by the source. Test hostile cases only with synthetic inputs in authorized disposable environments.

## 01. Clock-domain separation

**Source delivery:** Expose distinct simulation, monotonic and civil-time concepts where needed.

**Source invariant:** Deterministic simulation time is not used as a security clock.

**Source negative case:** A replay clock is used to evaluate a live credential lifetime.

**Source bounded quantities:** Clock sources and conversion count.

### UC-M02.06-C001 · Contract

**Original checklist item:** Specify clock-domain separation inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M02.06-C001-T01 · Scope statement:** Draft the operation boundary for “Clock-domain separation” within Clock and entropy interfaces; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M02.06-C001-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Clock-domain separation”; record each producer, representation and missing-value meaning.
- [ ] **UC-M02.06-C001-T03 · Output inventory:** List the outputs of “Clock-domain separation” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M02.06-C001-T04 · Field dictionary:** Create a field-and-term dictionary for “Clock-domain separation”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M02.06-C001-T05 · Prerequisite contract:** Map “Clock-domain separation” to the source component prerequisites (UC-M02.02); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M02.06-C001-T06 · Authority map:** Identify who may produce, change and consume “Clock-domain separation”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M02.06-C001-T07 · Invariant clause:** Add a normative clause for “Clock-domain separation” that preserves “Deterministic simulation time is not used as a security clock”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M02.06-C001-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Clock-domain separation”; include the source counterexample “A replay clock is used to evaluate a live credential lifetime” and the intended safe disposition.
- [ ] **UC-M02.06-C001-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Clock sources and conversion count” in the “Clock-domain separation” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M02.06-C001-T10 · Contract review:** Review the “Clock-domain separation” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M02.06-C002 · Delivery

**Original checklist item:** Expose distinct simulation, monotonic and civil-time concepts where needed.

- [ ] **UC-M02.06-C002-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Clock-domain separation”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M02.06-C002-T02 · Change plan:** Break the source delivery for “Clock-domain separation” into concrete edit targets and reviewable outputs; keep the UC-M02.06 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M02.06-C002-T03 · Core artifact:** Implement the smallest selected-profile change for “Clock-domain separation” that realizes this source instruction: Expose distinct simulation, monotonic and civil-time concepts where needed.
- [ ] **UC-M02.06-C002-T04 · Concrete realization:** Trace “Clock-domain separation” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M02.06-C002-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Clock-domain separation” needed to preserve “Deterministic simulation time is not used as a security clock”; record an enforcement gap where only a model exists.
- [ ] **UC-M02.06-C002-T06 · Dependency connection:** Connect the “Clock-domain separation” implementation to guest clock adapters, entropy consumers and replay input records; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M02.06-C002-T07 · Resource behavior:** Account for “Clock sources and conversion count” in “Clock-domain separation”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M02.06-C002-T08 · Delivery check:** Run the smallest real “Clock-domain separation” path and its adverse fixture “A replay clock is used to evaluate a live credential lifetime”; retain actual output, state effects and final disposition.
- [ ] **UC-M02.06-C002-T09 · Patch review:** Review the “Clock-domain separation” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M02.06-C002-T10 · Delivery handoff:** Publish the “Clock-domain separation” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M02.06-C003 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Deterministic simulation time is not used as a security clock. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M02.06-C003-T01 · Named property:** Create a stable property/check name under this parent for “Clock-domain separation”; copy its required invariant exactly: “Deterministic simulation time is not used as a security clock”.
- [ ] **UC-M02.06-C003-T02 · Observable terms:** Define each term in the “Clock-domain separation” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M02.06-C003-T03 · Precondition set:** List the preconditions under which “Deterministic simulation time is not used as a security clock” must hold for “Clock-domain separation”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M02.06-C003-T04 · Transition coverage:** Map the “Clock-domain separation” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M02.06-C003-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Clock-domain separation”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M02.06-C003-T06 · Satisfying fixture:** Create a concrete “Clock-domain separation” case that satisfies “Deterministic simulation time is not used as a security clock”; record its expected observation before running the assertion or review.
- [ ] **UC-M02.06-C003-T07 · Violating fixture:** Create the source counterexample “A replay clock is used to evaluate a live credential lifetime” for “Clock-domain separation”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M02.06-C003-T08 · Enforcement evidence:** Exercise the “Clock-domain separation” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M02.06-C003-T09 · Regression linkage:** Link the “Clock-domain separation” property to changes in guest clock adapters, entropy consumers and replay input records; record which dependency or contract changes require rerunning it.
- [ ] **UC-M02.06-C003-T10 · Property disposition:** Compare the satisfying and violating “Clock-domain separation” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M02.06-C004 · Integration

**Original checklist item:** Integrate clock-domain separation with guest clock adapters, entropy consumers and replay input records; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M02.06-C004-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Clock-domain separation” across guest clock adapters, entropy consumers and replay input records; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M02.06-C004-T02 · Field mapping:** Map every “Clock-domain separation” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M02.06-C004-T03 · Prerequisite identities:** Record the actual prerequisites for “Clock-domain separation” (source dependency list: UC-M02.02); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M02.06-C004-T04 · Ownership agreement:** Specify who owns “Clock-domain separation” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M02.06-C004-T05 · Handoff implementation:** Connect “Clock-domain separation” through the mapped seam using the real adapter or explicit specification reference; preserve “Deterministic simulation time is not used as a security clock” across the handoff.
- [ ] **UC-M02.06-C004-T06 · Absent-input case:** Omit one required “Clock-domain separation” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M02.06-C004-T07 · Stale-input case:** Supply an outdated “Clock-domain separation” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M02.06-C004-T08 · Incompatible-input case:** Supply an incompatible “Clock-domain separation” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M02.06-C004-T09 · Valid integration trace:** Run a valid “Clock-domain separation” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M02.06-C004-T10 · Seam review:** Reconcile the “Clock-domain separation” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M02.06-C005 · Valid-case test

**Original checklist item:** Run a valid-path fixture for clock-domain separation; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M02.06-C005-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Clock-domain separation” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M02.06-C005-T02 · Expected-result oracle:** Specify the “Clock-domain separation” expected result independently of the implementation output; include the property “Deterministic simulation time is not used as a security clock” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M02.06-C005-T03 · Fixture material:** Create the concrete “Clock-domain separation” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M02.06-C005-T04 · Target preparation:** Prepare the “Clock-domain separation” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M02.06-C005-T05 · Initial-state record:** Record the initial “Clock-domain separation” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M02.06-C005-T06 · Valid-path execution:** Execute the “Clock-domain separation” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M02.06-C005-T07 · Outcome comparison:** Compare every declared “Clock-domain separation” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M02.06-C005-T08 · State and bounds check:** Inspect the “Clock-domain separation” ownership/state effects and actual use of “Clock sources and conversion count”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M02.06-C005-T09 · Repeatability check:** Repeat the same “Clock-domain separation” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M02.06-C005-T10 · Positive evidence:** Attach the “Clock-domain separation” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M02.06-C006 · Negative test

**Original checklist item:** Negative case: A replay clock is used to evaluate a live credential lifetime. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M02.06-C006-T01 · Adverse-case definition:** Create a test record for the exact “Clock-domain separation” source counterexample: “A replay clock is used to evaluate a live credential lifetime”; state which precondition or invariant it challenges.
- [ ] **UC-M02.06-C006-T02 · Safe fixture boundary:** Define the contained test boundary for “Clock-domain separation”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M02.06-C006-T03 · Valid control:** Construct a valid “Clock-domain separation” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M02.06-C006-T04 · Minimal adverse input:** Derive the “Clock-domain separation” adverse fixture from the control with the smallest documented change needed to reproduce “A replay clock is used to evaluate a live credential lifetime”; retain that change as reproducible data.
- [ ] **UC-M02.06-C006-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Clock-domain separation”; require “Deterministic simulation time is not used as a security clock” and forbid a false-success verdict.
- [ ] **UC-M02.06-C006-T06 · Adverse execution:** Exercise the “Clock-domain separation” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M02.06-C006-T07 · Effect inspection:** Inspect “Clock-domain separation” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M02.06-C006-T08 · Refusal versus failure:** Confirm the “Clock-domain separation” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M02.06-C006-T09 · Reset and retention:** Restore only the disposable “Clock-domain separation” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M02.06-C006-T10 · Negative regression:** Register the “Clock-domain separation” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M02.06-C007 · Change / failure test

**Original checklist item:** Exercise clock-domain separation when a replay is restored while live clock availability or entropy delivery changes; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M02.06-C007-T01 · Scenario record:** Write the “Clock-domain separation” change/failure scenario exactly as supplied: a replay is restored while live clock availability or entropy delivery changes; identify the property that must remain true: “Deterministic simulation time is not used as a security clock”.
- [ ] **UC-M02.06-C007-T02 · Baseline capture:** Create a known-valid “Clock-domain separation” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M02.06-C007-T03 · Injection map:** Locate the “Clock-domain separation” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M02.06-C007-T04 · Disposition oracle:** Define the legal intermediate and final “Clock-domain separation” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M02.06-C007-T05 · Controlled trigger:** Introduce the controlled “Clock-domain separation” scenario in the disposable fixture: a replay is restored while live clock availability or entropy delivery changes; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M02.06-C007-T06 · Intermediate inspection:** Inspect the “Clock-domain separation” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M02.06-C007-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Clock-domain separation”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M02.06-C007-T08 · Stale-evidence cleanup:** Invalidate superseded “Clock-domain separation” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M02.06-C007-T09 · Repeat and compare:** Repeat the selected “Clock-domain separation” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M02.06-C007-T10 · Failure evidence:** Publish the “Clock-domain separation” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M02.06-C008 · Bounds

**Original checklist item:** Choose, document and test limits for clock sources and conversion count; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M02.06-C008-T01 · Quantity inventory:** Create a measurement inventory for “Clock-domain separation”: “Clock sources and conversion count”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M02.06-C008-T02 · Measurement method:** Choose how to observe each “Clock-domain separation” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M02.06-C008-T03 · Budget decision:** Select justified resource and input limits for “Clock-domain separation”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M02.06-C008-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Clock-domain separation” cases for “Clock sources and conversion count”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M02.06-C008-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Clock-domain separation” limit; preserve “Deterministic simulation time is not used as a security clock”.
- [ ] **UC-M02.06-C008-T06 · Normal measurement:** Run or review the normal “Clock-domain separation” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M02.06-C008-T07 · At-limit measurement:** Exercise the “Clock-domain separation” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M02.06-C008-T08 · Over-limit measurement:** Exercise the “Clock-domain separation” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M02.06-C008-T09 · Uncovered-scope report:** List the “Clock-domain separation” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M02.06-C008-T10 · Limit evidence:** Publish the selected “Clock-domain separation” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M02.06-C009 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for clock-domain separation with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M02.06-C009-T01 · Event inventory:** List the “Clock-domain separation” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M02.06-C009-T02 · Diagnostic schema:** Define nonsecret fields for “Clock-domain separation” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M02.06-C009-T03 · Failure mapping:** Map each documented “Clock-domain separation” refusal or error to a diagnostic outcome; include “A replay clock is used to evaluate a live credential lifetime” and prohibit conversion into a success message.
- [ ] **UC-M02.06-C009-T04 · Emission path:** Add the “Clock-domain separation” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M02.06-C009-T05 · Redaction check:** Test “Clock-domain separation” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M02.06-C009-T06 · Output budget:** Set and exercise bounded “Clock-domain separation” message size, rate and retention compatible with “Clock sources and conversion count”; define truncation behavior that preserves the final reason.
- [ ] **UC-M02.06-C009-T07 · Success/refusal fixtures:** Capture “Clock-domain separation” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M02.06-C009-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Clock-domain separation” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M02.06-C009-T09 · Operator review:** Read the “Clock-domain separation” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M02.06-C009-T10 · Diagnostic evidence:** Publish redacted “Clock-domain separation” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M02.06-C010 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for clock-domain separation; label unexecuted checks as untested.

- [ ] **UC-M02.06-C010-T01 · Evidence inventory:** List the “Clock-domain separation” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M02.06-C010-T02 · Artifact references:** Record the exact “Clock-domain separation” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M02.06-C010-T03 · Fixture references:** Attach the “Clock-domain separation” fixture IDs, input identities and oracle definition; preserve the source counterexample “A replay clock is used to evaluate a live credential lifetime” as a distinct evidence case.
- [ ] **UC-M02.06-C010-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Clock-domain separation”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M02.06-C010-T05 · Environment record:** Record the actual “Clock-domain separation” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M02.06-C010-T06 · Expected versus observed:** Pair every “Clock-domain separation” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M02.06-C010-T07 · Failure and limit records:** Attach “Clock-domain separation” change/failure and bounds evidence where required; include uncovered “Clock sources and conversion count” and unresolved violations of “Deterministic simulation time is not used as a security clock”.
- [ ] **UC-M02.06-C010-T08 · Evidence hygiene:** Check the “Clock-domain separation” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M02.06-C010-T09 · Reproduction review:** Have the “Clock-domain separation” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M02.06-C010-T10 · Acceptance linkage:** Link the “Clock-domain separation” evidence to its parent and UC-M02.06 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 02. Monotonic time adapter

**Source delivery:** Provide a monotonic source suitable for guest or host deadline handling.

**Source invariant:** Deadline progress does not depend on civil-time adjustments.

**Source negative case:** The civil clock moves backward during a running deadline.

**Source bounded quantities:** Clock resolution and maximum timing drift.

### UC-M02.06-C011 · Contract

**Original checklist item:** Specify monotonic time adapter inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M02.06-C011-T01 · Scope statement:** Draft the operation boundary for “Monotonic time adapter” within Clock and entropy interfaces; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M02.06-C011-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Monotonic time adapter”; record each producer, representation and missing-value meaning.
- [ ] **UC-M02.06-C011-T03 · Output inventory:** List the outputs of “Monotonic time adapter” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M02.06-C011-T04 · Field dictionary:** Create a field-and-term dictionary for “Monotonic time adapter”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M02.06-C011-T05 · Prerequisite contract:** Map “Monotonic time adapter” to the source component prerequisites (UC-M02.02); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M02.06-C011-T06 · Authority map:** Identify who may produce, change and consume “Monotonic time adapter”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M02.06-C011-T07 · Invariant clause:** Add a normative clause for “Monotonic time adapter” that preserves “Deadline progress does not depend on civil-time adjustments”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M02.06-C011-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Monotonic time adapter”; include the source counterexample “The civil clock moves backward during a running deadline” and the intended safe disposition.
- [ ] **UC-M02.06-C011-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Clock resolution and maximum timing drift” in the “Monotonic time adapter” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M02.06-C011-T10 · Contract review:** Review the “Monotonic time adapter” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M02.06-C012 · Delivery

**Original checklist item:** Provide a monotonic source suitable for guest or host deadline handling.

- [ ] **UC-M02.06-C012-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Monotonic time adapter”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M02.06-C012-T02 · Change plan:** Break the source delivery for “Monotonic time adapter” into concrete edit targets and reviewable outputs; keep the UC-M02.06 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M02.06-C012-T03 · Core artifact:** Implement the smallest selected-profile change for “Monotonic time adapter” that realizes this source instruction: Provide a monotonic source suitable for guest or host deadline handling.
- [ ] **UC-M02.06-C012-T04 · Concrete realization:** Trace “Monotonic time adapter” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M02.06-C012-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Monotonic time adapter” needed to preserve “Deadline progress does not depend on civil-time adjustments”; record an enforcement gap where only a model exists.
- [ ] **UC-M02.06-C012-T06 · Dependency connection:** Connect the “Monotonic time adapter” implementation to guest clock adapters, entropy consumers and replay input records; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M02.06-C012-T07 · Resource behavior:** Account for “Clock resolution and maximum timing drift” in “Monotonic time adapter”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M02.06-C012-T08 · Delivery check:** Run the smallest real “Monotonic time adapter” path and its adverse fixture “The civil clock moves backward during a running deadline”; retain actual output, state effects and final disposition.
- [ ] **UC-M02.06-C012-T09 · Patch review:** Review the “Monotonic time adapter” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M02.06-C012-T10 · Delivery handoff:** Publish the “Monotonic time adapter” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M02.06-C013 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Deadline progress does not depend on civil-time adjustments. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M02.06-C013-T01 · Named property:** Create a stable property/check name under this parent for “Monotonic time adapter”; copy its required invariant exactly: “Deadline progress does not depend on civil-time adjustments”.
- [ ] **UC-M02.06-C013-T02 · Observable terms:** Define each term in the “Monotonic time adapter” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M02.06-C013-T03 · Precondition set:** List the preconditions under which “Deadline progress does not depend on civil-time adjustments” must hold for “Monotonic time adapter”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M02.06-C013-T04 · Transition coverage:** Map the “Monotonic time adapter” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M02.06-C013-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Monotonic time adapter”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M02.06-C013-T06 · Satisfying fixture:** Create a concrete “Monotonic time adapter” case that satisfies “Deadline progress does not depend on civil-time adjustments”; record its expected observation before running the assertion or review.
- [ ] **UC-M02.06-C013-T07 · Violating fixture:** Create the source counterexample “The civil clock moves backward during a running deadline” for “Monotonic time adapter”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M02.06-C013-T08 · Enforcement evidence:** Exercise the “Monotonic time adapter” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M02.06-C013-T09 · Regression linkage:** Link the “Monotonic time adapter” property to changes in guest clock adapters, entropy consumers and replay input records; record which dependency or contract changes require rerunning it.
- [ ] **UC-M02.06-C013-T10 · Property disposition:** Compare the satisfying and violating “Monotonic time adapter” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M02.06-C014 · Integration

**Original checklist item:** Integrate monotonic time adapter with guest clock adapters, entropy consumers and replay input records; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M02.06-C014-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Monotonic time adapter” across guest clock adapters, entropy consumers and replay input records; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M02.06-C014-T02 · Field mapping:** Map every “Monotonic time adapter” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M02.06-C014-T03 · Prerequisite identities:** Record the actual prerequisites for “Monotonic time adapter” (source dependency list: UC-M02.02); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M02.06-C014-T04 · Ownership agreement:** Specify who owns “Monotonic time adapter” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M02.06-C014-T05 · Handoff implementation:** Connect “Monotonic time adapter” through the mapped seam using the real adapter or explicit specification reference; preserve “Deadline progress does not depend on civil-time adjustments” across the handoff.
- [ ] **UC-M02.06-C014-T06 · Absent-input case:** Omit one required “Monotonic time adapter” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M02.06-C014-T07 · Stale-input case:** Supply an outdated “Monotonic time adapter” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M02.06-C014-T08 · Incompatible-input case:** Supply an incompatible “Monotonic time adapter” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M02.06-C014-T09 · Valid integration trace:** Run a valid “Monotonic time adapter” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M02.06-C014-T10 · Seam review:** Reconcile the “Monotonic time adapter” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M02.06-C015 · Valid-case test

**Original checklist item:** Run a valid-path fixture for monotonic time adapter; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M02.06-C015-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Monotonic time adapter” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M02.06-C015-T02 · Expected-result oracle:** Specify the “Monotonic time adapter” expected result independently of the implementation output; include the property “Deadline progress does not depend on civil-time adjustments” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M02.06-C015-T03 · Fixture material:** Create the concrete “Monotonic time adapter” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M02.06-C015-T04 · Target preparation:** Prepare the “Monotonic time adapter” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M02.06-C015-T05 · Initial-state record:** Record the initial “Monotonic time adapter” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M02.06-C015-T06 · Valid-path execution:** Execute the “Monotonic time adapter” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M02.06-C015-T07 · Outcome comparison:** Compare every declared “Monotonic time adapter” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M02.06-C015-T08 · State and bounds check:** Inspect the “Monotonic time adapter” ownership/state effects and actual use of “Clock resolution and maximum timing drift”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M02.06-C015-T09 · Repeatability check:** Repeat the same “Monotonic time adapter” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M02.06-C015-T10 · Positive evidence:** Attach the “Monotonic time adapter” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M02.06-C016 · Negative test

**Original checklist item:** Negative case: The civil clock moves backward during a running deadline. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M02.06-C016-T01 · Adverse-case definition:** Create a test record for the exact “Monotonic time adapter” source counterexample: “The civil clock moves backward during a running deadline”; state which precondition or invariant it challenges.
- [ ] **UC-M02.06-C016-T02 · Safe fixture boundary:** Define the contained test boundary for “Monotonic time adapter”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M02.06-C016-T03 · Valid control:** Construct a valid “Monotonic time adapter” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M02.06-C016-T04 · Minimal adverse input:** Derive the “Monotonic time adapter” adverse fixture from the control with the smallest documented change needed to reproduce “The civil clock moves backward during a running deadline”; retain that change as reproducible data.
- [ ] **UC-M02.06-C016-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Monotonic time adapter”; require “Deadline progress does not depend on civil-time adjustments” and forbid a false-success verdict.
- [ ] **UC-M02.06-C016-T06 · Adverse execution:** Exercise the “Monotonic time adapter” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M02.06-C016-T07 · Effect inspection:** Inspect “Monotonic time adapter” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M02.06-C016-T08 · Refusal versus failure:** Confirm the “Monotonic time adapter” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M02.06-C016-T09 · Reset and retention:** Restore only the disposable “Monotonic time adapter” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M02.06-C016-T10 · Negative regression:** Register the “Monotonic time adapter” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M02.06-C017 · Change / failure test

**Original checklist item:** Exercise monotonic time adapter when a replay is restored while live clock availability or entropy delivery changes; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M02.06-C017-T01 · Scenario record:** Write the “Monotonic time adapter” change/failure scenario exactly as supplied: a replay is restored while live clock availability or entropy delivery changes; identify the property that must remain true: “Deadline progress does not depend on civil-time adjustments”.
- [ ] **UC-M02.06-C017-T02 · Baseline capture:** Create a known-valid “Monotonic time adapter” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M02.06-C017-T03 · Injection map:** Locate the “Monotonic time adapter” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M02.06-C017-T04 · Disposition oracle:** Define the legal intermediate and final “Monotonic time adapter” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M02.06-C017-T05 · Controlled trigger:** Introduce the controlled “Monotonic time adapter” scenario in the disposable fixture: a replay is restored while live clock availability or entropy delivery changes; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M02.06-C017-T06 · Intermediate inspection:** Inspect the “Monotonic time adapter” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M02.06-C017-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Monotonic time adapter”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M02.06-C017-T08 · Stale-evidence cleanup:** Invalidate superseded “Monotonic time adapter” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M02.06-C017-T09 · Repeat and compare:** Repeat the selected “Monotonic time adapter” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M02.06-C017-T10 · Failure evidence:** Publish the “Monotonic time adapter” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M02.06-C018 · Bounds

**Original checklist item:** Choose, document and test limits for clock resolution and maximum timing drift; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M02.06-C018-T01 · Quantity inventory:** Create a measurement inventory for “Monotonic time adapter”: “Clock resolution and maximum timing drift”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M02.06-C018-T02 · Measurement method:** Choose how to observe each “Monotonic time adapter” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M02.06-C018-T03 · Budget decision:** Select justified resource and input limits for “Monotonic time adapter”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M02.06-C018-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Monotonic time adapter” cases for “Clock resolution and maximum timing drift”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M02.06-C018-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Monotonic time adapter” limit; preserve “Deadline progress does not depend on civil-time adjustments”.
- [ ] **UC-M02.06-C018-T06 · Normal measurement:** Run or review the normal “Monotonic time adapter” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M02.06-C018-T07 · At-limit measurement:** Exercise the “Monotonic time adapter” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M02.06-C018-T08 · Over-limit measurement:** Exercise the “Monotonic time adapter” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M02.06-C018-T09 · Uncovered-scope report:** List the “Monotonic time adapter” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M02.06-C018-T10 · Limit evidence:** Publish the selected “Monotonic time adapter” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M02.06-C019 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for monotonic time adapter with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M02.06-C019-T01 · Event inventory:** List the “Monotonic time adapter” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M02.06-C019-T02 · Diagnostic schema:** Define nonsecret fields for “Monotonic time adapter” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M02.06-C019-T03 · Failure mapping:** Map each documented “Monotonic time adapter” refusal or error to a diagnostic outcome; include “The civil clock moves backward during a running deadline” and prohibit conversion into a success message.
- [ ] **UC-M02.06-C019-T04 · Emission path:** Add the “Monotonic time adapter” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M02.06-C019-T05 · Redaction check:** Test “Monotonic time adapter” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M02.06-C019-T06 · Output budget:** Set and exercise bounded “Monotonic time adapter” message size, rate and retention compatible with “Clock resolution and maximum timing drift”; define truncation behavior that preserves the final reason.
- [ ] **UC-M02.06-C019-T07 · Success/refusal fixtures:** Capture “Monotonic time adapter” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M02.06-C019-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Monotonic time adapter” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M02.06-C019-T09 · Operator review:** Read the “Monotonic time adapter” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M02.06-C019-T10 · Diagnostic evidence:** Publish redacted “Monotonic time adapter” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M02.06-C020 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for monotonic time adapter; label unexecuted checks as untested.

- [ ] **UC-M02.06-C020-T01 · Evidence inventory:** List the “Monotonic time adapter” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M02.06-C020-T02 · Artifact references:** Record the exact “Monotonic time adapter” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M02.06-C020-T03 · Fixture references:** Attach the “Monotonic time adapter” fixture IDs, input identities and oracle definition; preserve the source counterexample “The civil clock moves backward during a running deadline” as a distinct evidence case.
- [ ] **UC-M02.06-C020-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Monotonic time adapter”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M02.06-C020-T05 · Environment record:** Record the actual “Monotonic time adapter” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M02.06-C020-T06 · Expected versus observed:** Pair every “Monotonic time adapter” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M02.06-C020-T07 · Failure and limit records:** Attach “Monotonic time adapter” change/failure and bounds evidence where required; include uncovered “Clock resolution and maximum timing drift” and unresolved violations of “Deadline progress does not depend on civil-time adjustments”.
- [ ] **UC-M02.06-C020-T08 · Evidence hygiene:** Check the “Monotonic time adapter” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M02.06-C020-T09 · Reproduction review:** Have the “Monotonic time adapter” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M02.06-C020-T10 · Acceptance linkage:** Link the “Monotonic time adapter” evidence to its parent and UC-M02.06 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 03. Simulation clock

**Source delivery:** Implement a deterministic simulation clock driven by recorded inputs.

**Source invariant:** Replay advances according to the declared simulation sequence.

**Source negative case:** A replay reads live wall time and changes its output.

**Source bounded quantities:** Recorded tick count and simulation range.

### UC-M02.06-C021 · Contract

**Original checklist item:** Specify simulation clock inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M02.06-C021-T01 · Scope statement:** Draft the operation boundary for “Simulation clock” within Clock and entropy interfaces; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M02.06-C021-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Simulation clock”; record each producer, representation and missing-value meaning.
- [ ] **UC-M02.06-C021-T03 · Output inventory:** List the outputs of “Simulation clock” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M02.06-C021-T04 · Field dictionary:** Create a field-and-term dictionary for “Simulation clock”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M02.06-C021-T05 · Prerequisite contract:** Map “Simulation clock” to the source component prerequisites (UC-M02.02); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M02.06-C021-T06 · Authority map:** Identify who may produce, change and consume “Simulation clock”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M02.06-C021-T07 · Invariant clause:** Add a normative clause for “Simulation clock” that preserves “Replay advances according to the declared simulation sequence”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M02.06-C021-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Simulation clock”; include the source counterexample “A replay reads live wall time and changes its output” and the intended safe disposition.
- [ ] **UC-M02.06-C021-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Recorded tick count and simulation range” in the “Simulation clock” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M02.06-C021-T10 · Contract review:** Review the “Simulation clock” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M02.06-C022 · Delivery

**Original checklist item:** Implement a deterministic simulation clock driven by recorded inputs.

- [ ] **UC-M02.06-C022-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Simulation clock”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M02.06-C022-T02 · Change plan:** Break the source delivery for “Simulation clock” into concrete edit targets and reviewable outputs; keep the UC-M02.06 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M02.06-C022-T03 · Core artifact:** Implement the smallest selected-profile change for “Simulation clock” that realizes this source instruction: Implement a deterministic simulation clock driven by recorded inputs.
- [ ] **UC-M02.06-C022-T04 · Concrete realization:** Trace “Simulation clock” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M02.06-C022-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Simulation clock” needed to preserve “Replay advances according to the declared simulation sequence”; record an enforcement gap where only a model exists.
- [ ] **UC-M02.06-C022-T06 · Dependency connection:** Connect the “Simulation clock” implementation to guest clock adapters, entropy consumers and replay input records; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M02.06-C022-T07 · Resource behavior:** Account for “Recorded tick count and simulation range” in “Simulation clock”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M02.06-C022-T08 · Delivery check:** Run the smallest real “Simulation clock” path and its adverse fixture “A replay reads live wall time and changes its output”; retain actual output, state effects and final disposition.
- [ ] **UC-M02.06-C022-T09 · Patch review:** Review the “Simulation clock” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M02.06-C022-T10 · Delivery handoff:** Publish the “Simulation clock” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M02.06-C023 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Replay advances according to the declared simulation sequence. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M02.06-C023-T01 · Named property:** Create a stable property/check name under this parent for “Simulation clock”; copy its required invariant exactly: “Replay advances according to the declared simulation sequence”.
- [ ] **UC-M02.06-C023-T02 · Observable terms:** Define each term in the “Simulation clock” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M02.06-C023-T03 · Precondition set:** List the preconditions under which “Replay advances according to the declared simulation sequence” must hold for “Simulation clock”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M02.06-C023-T04 · Transition coverage:** Map the “Simulation clock” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M02.06-C023-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Simulation clock”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M02.06-C023-T06 · Satisfying fixture:** Create a concrete “Simulation clock” case that satisfies “Replay advances according to the declared simulation sequence”; record its expected observation before running the assertion or review.
- [ ] **UC-M02.06-C023-T07 · Violating fixture:** Create the source counterexample “A replay reads live wall time and changes its output” for “Simulation clock”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M02.06-C023-T08 · Enforcement evidence:** Exercise the “Simulation clock” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M02.06-C023-T09 · Regression linkage:** Link the “Simulation clock” property to changes in guest clock adapters, entropy consumers and replay input records; record which dependency or contract changes require rerunning it.
- [ ] **UC-M02.06-C023-T10 · Property disposition:** Compare the satisfying and violating “Simulation clock” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M02.06-C024 · Integration

**Original checklist item:** Integrate simulation clock with guest clock adapters, entropy consumers and replay input records; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M02.06-C024-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Simulation clock” across guest clock adapters, entropy consumers and replay input records; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M02.06-C024-T02 · Field mapping:** Map every “Simulation clock” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M02.06-C024-T03 · Prerequisite identities:** Record the actual prerequisites for “Simulation clock” (source dependency list: UC-M02.02); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M02.06-C024-T04 · Ownership agreement:** Specify who owns “Simulation clock” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M02.06-C024-T05 · Handoff implementation:** Connect “Simulation clock” through the mapped seam using the real adapter or explicit specification reference; preserve “Replay advances according to the declared simulation sequence” across the handoff.
- [ ] **UC-M02.06-C024-T06 · Absent-input case:** Omit one required “Simulation clock” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M02.06-C024-T07 · Stale-input case:** Supply an outdated “Simulation clock” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M02.06-C024-T08 · Incompatible-input case:** Supply an incompatible “Simulation clock” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M02.06-C024-T09 · Valid integration trace:** Run a valid “Simulation clock” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M02.06-C024-T10 · Seam review:** Reconcile the “Simulation clock” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M02.06-C025 · Valid-case test

**Original checklist item:** Run a valid-path fixture for simulation clock; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M02.06-C025-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Simulation clock” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M02.06-C025-T02 · Expected-result oracle:** Specify the “Simulation clock” expected result independently of the implementation output; include the property “Replay advances according to the declared simulation sequence” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M02.06-C025-T03 · Fixture material:** Create the concrete “Simulation clock” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M02.06-C025-T04 · Target preparation:** Prepare the “Simulation clock” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M02.06-C025-T05 · Initial-state record:** Record the initial “Simulation clock” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M02.06-C025-T06 · Valid-path execution:** Execute the “Simulation clock” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M02.06-C025-T07 · Outcome comparison:** Compare every declared “Simulation clock” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M02.06-C025-T08 · State and bounds check:** Inspect the “Simulation clock” ownership/state effects and actual use of “Recorded tick count and simulation range”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M02.06-C025-T09 · Repeatability check:** Repeat the same “Simulation clock” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M02.06-C025-T10 · Positive evidence:** Attach the “Simulation clock” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M02.06-C026 · Negative test

**Original checklist item:** Negative case: A replay reads live wall time and changes its output. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M02.06-C026-T01 · Adverse-case definition:** Create a test record for the exact “Simulation clock” source counterexample: “A replay reads live wall time and changes its output”; state which precondition or invariant it challenges.
- [ ] **UC-M02.06-C026-T02 · Safe fixture boundary:** Define the contained test boundary for “Simulation clock”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M02.06-C026-T03 · Valid control:** Construct a valid “Simulation clock” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M02.06-C026-T04 · Minimal adverse input:** Derive the “Simulation clock” adverse fixture from the control with the smallest documented change needed to reproduce “A replay reads live wall time and changes its output”; retain that change as reproducible data.
- [ ] **UC-M02.06-C026-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Simulation clock”; require “Replay advances according to the declared simulation sequence” and forbid a false-success verdict.
- [ ] **UC-M02.06-C026-T06 · Adverse execution:** Exercise the “Simulation clock” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M02.06-C026-T07 · Effect inspection:** Inspect “Simulation clock” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M02.06-C026-T08 · Refusal versus failure:** Confirm the “Simulation clock” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M02.06-C026-T09 · Reset and retention:** Restore only the disposable “Simulation clock” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M02.06-C026-T10 · Negative regression:** Register the “Simulation clock” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M02.06-C027 · Change / failure test

**Original checklist item:** Exercise simulation clock when a replay is restored while live clock availability or entropy delivery changes; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M02.06-C027-T01 · Scenario record:** Write the “Simulation clock” change/failure scenario exactly as supplied: a replay is restored while live clock availability or entropy delivery changes; identify the property that must remain true: “Replay advances according to the declared simulation sequence”.
- [ ] **UC-M02.06-C027-T02 · Baseline capture:** Create a known-valid “Simulation clock” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M02.06-C027-T03 · Injection map:** Locate the “Simulation clock” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M02.06-C027-T04 · Disposition oracle:** Define the legal intermediate and final “Simulation clock” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M02.06-C027-T05 · Controlled trigger:** Introduce the controlled “Simulation clock” scenario in the disposable fixture: a replay is restored while live clock availability or entropy delivery changes; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M02.06-C027-T06 · Intermediate inspection:** Inspect the “Simulation clock” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M02.06-C027-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Simulation clock”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M02.06-C027-T08 · Stale-evidence cleanup:** Invalidate superseded “Simulation clock” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M02.06-C027-T09 · Repeat and compare:** Repeat the selected “Simulation clock” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M02.06-C027-T10 · Failure evidence:** Publish the “Simulation clock” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M02.06-C028 · Bounds

**Original checklist item:** Choose, document and test limits for recorded tick count and simulation range; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M02.06-C028-T01 · Quantity inventory:** Create a measurement inventory for “Simulation clock”: “Recorded tick count and simulation range”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M02.06-C028-T02 · Measurement method:** Choose how to observe each “Simulation clock” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M02.06-C028-T03 · Budget decision:** Select justified resource and input limits for “Simulation clock”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M02.06-C028-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Simulation clock” cases for “Recorded tick count and simulation range”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M02.06-C028-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Simulation clock” limit; preserve “Replay advances according to the declared simulation sequence”.
- [ ] **UC-M02.06-C028-T06 · Normal measurement:** Run or review the normal “Simulation clock” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M02.06-C028-T07 · At-limit measurement:** Exercise the “Simulation clock” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M02.06-C028-T08 · Over-limit measurement:** Exercise the “Simulation clock” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M02.06-C028-T09 · Uncovered-scope report:** List the “Simulation clock” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M02.06-C028-T10 · Limit evidence:** Publish the selected “Simulation clock” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M02.06-C029 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for simulation clock with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M02.06-C029-T01 · Event inventory:** List the “Simulation clock” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M02.06-C029-T02 · Diagnostic schema:** Define nonsecret fields for “Simulation clock” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M02.06-C029-T03 · Failure mapping:** Map each documented “Simulation clock” refusal or error to a diagnostic outcome; include “A replay reads live wall time and changes its output” and prohibit conversion into a success message.
- [ ] **UC-M02.06-C029-T04 · Emission path:** Add the “Simulation clock” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M02.06-C029-T05 · Redaction check:** Test “Simulation clock” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M02.06-C029-T06 · Output budget:** Set and exercise bounded “Simulation clock” message size, rate and retention compatible with “Recorded tick count and simulation range”; define truncation behavior that preserves the final reason.
- [ ] **UC-M02.06-C029-T07 · Success/refusal fixtures:** Capture “Simulation clock” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M02.06-C029-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Simulation clock” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M02.06-C029-T09 · Operator review:** Read the “Simulation clock” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M02.06-C029-T10 · Diagnostic evidence:** Publish redacted “Simulation clock” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M02.06-C030 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for simulation clock; label unexecuted checks as untested.

- [ ] **UC-M02.06-C030-T01 · Evidence inventory:** List the “Simulation clock” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M02.06-C030-T02 · Artifact references:** Record the exact “Simulation clock” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M02.06-C030-T03 · Fixture references:** Attach the “Simulation clock” fixture IDs, input identities and oracle definition; preserve the source counterexample “A replay reads live wall time and changes its output” as a distinct evidence case.
- [ ] **UC-M02.06-C030-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Simulation clock”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M02.06-C030-T05 · Environment record:** Record the actual “Simulation clock” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M02.06-C030-T06 · Expected versus observed:** Pair every “Simulation clock” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M02.06-C030-T07 · Failure and limit records:** Attach “Simulation clock” change/failure and bounds evidence where required; include uncovered “Recorded tick count and simulation range” and unresolved violations of “Replay advances according to the declared simulation sequence”.
- [ ] **UC-M02.06-C030-T08 · Evidence hygiene:** Check the “Simulation clock” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M02.06-C030-T09 · Reproduction review:** Have the “Simulation clock” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M02.06-C030-T10 · Acceptance linkage:** Link the “Simulation clock” evidence to its parent and UC-M02.06 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 04. Entropy source selection

**Source delivery:** Select the approved platform entropy interface for security-sensitive randomness.

**Source invariant:** Security randomness never derives from witness seeds.

**Source negative case:** A fixed witness seed is used to generate an identity key.

**Source bounded quantities:** Entropy request bytes and call rate.

### UC-M02.06-C031 · Contract

**Original checklist item:** Specify entropy source selection inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M02.06-C031-T01 · Scope statement:** Draft the operation boundary for “Entropy source selection” within Clock and entropy interfaces; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M02.06-C031-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Entropy source selection”; record each producer, representation and missing-value meaning.
- [ ] **UC-M02.06-C031-T03 · Output inventory:** List the outputs of “Entropy source selection” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M02.06-C031-T04 · Field dictionary:** Create a field-and-term dictionary for “Entropy source selection”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M02.06-C031-T05 · Prerequisite contract:** Map “Entropy source selection” to the source component prerequisites (UC-M02.02); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M02.06-C031-T06 · Authority map:** Identify who may produce, change and consume “Entropy source selection”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M02.06-C031-T07 · Invariant clause:** Add a normative clause for “Entropy source selection” that preserves “Security randomness never derives from witness seeds”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M02.06-C031-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Entropy source selection”; include the source counterexample “A fixed witness seed is used to generate an identity key” and the intended safe disposition.
- [ ] **UC-M02.06-C031-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Entropy request bytes and call rate” in the “Entropy source selection” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M02.06-C031-T10 · Contract review:** Review the “Entropy source selection” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M02.06-C032 · Delivery

**Original checklist item:** Select the approved platform entropy interface for security-sensitive randomness.

- [ ] **UC-M02.06-C032-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Entropy source selection”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M02.06-C032-T02 · Change plan:** Break the source delivery for “Entropy source selection” into concrete edit targets and reviewable outputs; keep the UC-M02.06 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M02.06-C032-T03 · Core artifact:** Prepare the “Entropy source selection” decision record for this source instruction: Select the approved platform entropy interface for security-sensitive randomness.
- [ ] **UC-M02.06-C032-T04 · Concrete realization:** Evaluate the “Entropy source selection” choice against its declared constraints; record the exact selected target/configuration and rejected alternatives, leaving unverified compatibility as a blocker.
- [ ] **UC-M02.06-C032-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Entropy source selection” needed to preserve “Security randomness never derives from witness seeds”; record an enforcement gap where only a model exists.
- [ ] **UC-M02.06-C032-T06 · Dependency connection:** Connect the “Entropy source selection” implementation to guest clock adapters, entropy consumers and replay input records; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M02.06-C032-T07 · Resource behavior:** Account for “Entropy request bytes and call rate” in “Entropy source selection”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M02.06-C032-T08 · Delivery check:** Run the smallest real “Entropy source selection” path and its adverse fixture “A fixed witness seed is used to generate an identity key”; retain actual output, state effects and final disposition.
- [ ] **UC-M02.06-C032-T09 · Patch review:** Review the “Entropy source selection” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M02.06-C032-T10 · Delivery handoff:** Publish the “Entropy source selection” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M02.06-C033 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Security randomness never derives from witness seeds. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M02.06-C033-T01 · Named property:** Create a stable property/check name under this parent for “Entropy source selection”; copy its required invariant exactly: “Security randomness never derives from witness seeds”.
- [ ] **UC-M02.06-C033-T02 · Observable terms:** Define each term in the “Entropy source selection” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M02.06-C033-T03 · Precondition set:** List the preconditions under which “Security randomness never derives from witness seeds” must hold for “Entropy source selection”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M02.06-C033-T04 · Transition coverage:** Map the “Entropy source selection” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M02.06-C033-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Entropy source selection”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M02.06-C033-T06 · Satisfying fixture:** Create a concrete “Entropy source selection” case that satisfies “Security randomness never derives from witness seeds”; record its expected observation before running the assertion or review.
- [ ] **UC-M02.06-C033-T07 · Violating fixture:** Create the source counterexample “A fixed witness seed is used to generate an identity key” for “Entropy source selection”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M02.06-C033-T08 · Enforcement evidence:** Exercise the “Entropy source selection” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M02.06-C033-T09 · Regression linkage:** Link the “Entropy source selection” property to changes in guest clock adapters, entropy consumers and replay input records; record which dependency or contract changes require rerunning it.
- [ ] **UC-M02.06-C033-T10 · Property disposition:** Compare the satisfying and violating “Entropy source selection” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M02.06-C034 · Integration

**Original checklist item:** Integrate entropy source selection with guest clock adapters, entropy consumers and replay input records; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M02.06-C034-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Entropy source selection” across guest clock adapters, entropy consumers and replay input records; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M02.06-C034-T02 · Field mapping:** Map every “Entropy source selection” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M02.06-C034-T03 · Prerequisite identities:** Record the actual prerequisites for “Entropy source selection” (source dependency list: UC-M02.02); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M02.06-C034-T04 · Ownership agreement:** Specify who owns “Entropy source selection” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M02.06-C034-T05 · Handoff implementation:** Connect “Entropy source selection” through the mapped seam using the real adapter or explicit specification reference; preserve “Security randomness never derives from witness seeds” across the handoff.
- [ ] **UC-M02.06-C034-T06 · Absent-input case:** Omit one required “Entropy source selection” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M02.06-C034-T07 · Stale-input case:** Supply an outdated “Entropy source selection” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M02.06-C034-T08 · Incompatible-input case:** Supply an incompatible “Entropy source selection” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M02.06-C034-T09 · Valid integration trace:** Run a valid “Entropy source selection” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M02.06-C034-T10 · Seam review:** Reconcile the “Entropy source selection” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M02.06-C035 · Valid-case test

**Original checklist item:** Run a valid-path fixture for entropy source selection; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M02.06-C035-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Entropy source selection” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M02.06-C035-T02 · Expected-result oracle:** Specify the “Entropy source selection” expected result independently of the implementation output; include the property “Security randomness never derives from witness seeds” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M02.06-C035-T03 · Fixture material:** Create the concrete “Entropy source selection” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M02.06-C035-T04 · Target preparation:** Prepare the “Entropy source selection” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M02.06-C035-T05 · Initial-state record:** Record the initial “Entropy source selection” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M02.06-C035-T06 · Valid-path execution:** Execute the “Entropy source selection” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M02.06-C035-T07 · Outcome comparison:** Compare every declared “Entropy source selection” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M02.06-C035-T08 · State and bounds check:** Inspect the “Entropy source selection” ownership/state effects and actual use of “Entropy request bytes and call rate”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M02.06-C035-T09 · Repeatability check:** Repeat the same “Entropy source selection” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M02.06-C035-T10 · Positive evidence:** Attach the “Entropy source selection” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M02.06-C036 · Negative test

**Original checklist item:** Negative case: A fixed witness seed is used to generate an identity key. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M02.06-C036-T01 · Adverse-case definition:** Create a test record for the exact “Entropy source selection” source counterexample: “A fixed witness seed is used to generate an identity key”; state which precondition or invariant it challenges.
- [ ] **UC-M02.06-C036-T02 · Safe fixture boundary:** Define the contained test boundary for “Entropy source selection”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M02.06-C036-T03 · Valid control:** Construct a valid “Entropy source selection” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M02.06-C036-T04 · Minimal adverse input:** Derive the “Entropy source selection” adverse fixture from the control with the smallest documented change needed to reproduce “A fixed witness seed is used to generate an identity key”; retain that change as reproducible data.
- [ ] **UC-M02.06-C036-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Entropy source selection”; require “Security randomness never derives from witness seeds” and forbid a false-success verdict.
- [ ] **UC-M02.06-C036-T06 · Adverse execution:** Exercise the “Entropy source selection” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M02.06-C036-T07 · Effect inspection:** Inspect “Entropy source selection” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M02.06-C036-T08 · Refusal versus failure:** Confirm the “Entropy source selection” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M02.06-C036-T09 · Reset and retention:** Restore only the disposable “Entropy source selection” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M02.06-C036-T10 · Negative regression:** Register the “Entropy source selection” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M02.06-C037 · Change / failure test

**Original checklist item:** Exercise entropy source selection when a replay is restored while live clock availability or entropy delivery changes; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M02.06-C037-T01 · Scenario record:** Write the “Entropy source selection” change/failure scenario exactly as supplied: a replay is restored while live clock availability or entropy delivery changes; identify the property that must remain true: “Security randomness never derives from witness seeds”.
- [ ] **UC-M02.06-C037-T02 · Baseline capture:** Create a known-valid “Entropy source selection” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M02.06-C037-T03 · Injection map:** Locate the “Entropy source selection” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M02.06-C037-T04 · Disposition oracle:** Define the legal intermediate and final “Entropy source selection” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M02.06-C037-T05 · Controlled trigger:** Introduce the controlled “Entropy source selection” scenario in the disposable fixture: a replay is restored while live clock availability or entropy delivery changes; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M02.06-C037-T06 · Intermediate inspection:** Inspect the “Entropy source selection” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M02.06-C037-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Entropy source selection”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M02.06-C037-T08 · Stale-evidence cleanup:** Invalidate superseded “Entropy source selection” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M02.06-C037-T09 · Repeat and compare:** Repeat the selected “Entropy source selection” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M02.06-C037-T10 · Failure evidence:** Publish the “Entropy source selection” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M02.06-C038 · Bounds

**Original checklist item:** Choose, document and test limits for entropy request bytes and call rate; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M02.06-C038-T01 · Quantity inventory:** Create a measurement inventory for “Entropy source selection”: “Entropy request bytes and call rate”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M02.06-C038-T02 · Measurement method:** Choose how to observe each “Entropy source selection” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M02.06-C038-T03 · Budget decision:** Select justified resource and input limits for “Entropy source selection”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M02.06-C038-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Entropy source selection” cases for “Entropy request bytes and call rate”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M02.06-C038-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Entropy source selection” limit; preserve “Security randomness never derives from witness seeds”.
- [ ] **UC-M02.06-C038-T06 · Normal measurement:** Run or review the normal “Entropy source selection” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M02.06-C038-T07 · At-limit measurement:** Exercise the “Entropy source selection” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M02.06-C038-T08 · Over-limit measurement:** Exercise the “Entropy source selection” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M02.06-C038-T09 · Uncovered-scope report:** List the “Entropy source selection” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M02.06-C038-T10 · Limit evidence:** Publish the selected “Entropy source selection” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M02.06-C039 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for entropy source selection with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M02.06-C039-T01 · Event inventory:** List the “Entropy source selection” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M02.06-C039-T02 · Diagnostic schema:** Define nonsecret fields for “Entropy source selection” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M02.06-C039-T03 · Failure mapping:** Map each documented “Entropy source selection” refusal or error to a diagnostic outcome; include “A fixed witness seed is used to generate an identity key” and prohibit conversion into a success message.
- [ ] **UC-M02.06-C039-T04 · Emission path:** Add the “Entropy source selection” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M02.06-C039-T05 · Redaction check:** Test “Entropy source selection” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M02.06-C039-T06 · Output budget:** Set and exercise bounded “Entropy source selection” message size, rate and retention compatible with “Entropy request bytes and call rate”; define truncation behavior that preserves the final reason.
- [ ] **UC-M02.06-C039-T07 · Success/refusal fixtures:** Capture “Entropy source selection” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M02.06-C039-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Entropy source selection” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M02.06-C039-T09 · Operator review:** Read the “Entropy source selection” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M02.06-C039-T10 · Diagnostic evidence:** Publish redacted “Entropy source selection” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M02.06-C040 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for entropy source selection; label unexecuted checks as untested.

- [ ] **UC-M02.06-C040-T01 · Evidence inventory:** List the “Entropy source selection” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M02.06-C040-T02 · Artifact references:** Record the exact “Entropy source selection” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M02.06-C040-T03 · Fixture references:** Attach the “Entropy source selection” fixture IDs, input identities and oracle definition; preserve the source counterexample “A fixed witness seed is used to generate an identity key” as a distinct evidence case.
- [ ] **UC-M02.06-C040-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Entropy source selection”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M02.06-C040-T05 · Environment record:** Record the actual “Entropy source selection” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M02.06-C040-T06 · Expected versus observed:** Pair every “Entropy source selection” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M02.06-C040-T07 · Failure and limit records:** Attach “Entropy source selection” change/failure and bounds evidence where required; include uncovered “Entropy request bytes and call rate” and unresolved violations of “Security randomness never derives from witness seeds”.
- [ ] **UC-M02.06-C040-T08 · Evidence hygiene:** Check the “Entropy source selection” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M02.06-C040-T09 · Reproduction review:** Have the “Entropy source selection” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M02.06-C040-T10 · Acceptance linkage:** Link the “Entropy source selection” evidence to its parent and UC-M02.06 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 05. Boot availability checks

**Source delivery:** Check required clocks and entropy availability before enabling dependent operations.

**Source invariant:** Unavailable security randomness blocks operations that require it.

**Source negative case:** The platform reports ready while its required entropy interface is absent.

**Source bounded quantities:** Boot check deadline and retry limit.

### UC-M02.06-C041 · Contract

**Original checklist item:** Specify boot availability checks inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M02.06-C041-T01 · Scope statement:** Draft the operation boundary for “Boot availability checks” within Clock and entropy interfaces; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M02.06-C041-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Boot availability checks”; record each producer, representation and missing-value meaning.
- [ ] **UC-M02.06-C041-T03 · Output inventory:** List the outputs of “Boot availability checks” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M02.06-C041-T04 · Field dictionary:** Create a field-and-term dictionary for “Boot availability checks”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M02.06-C041-T05 · Prerequisite contract:** Map “Boot availability checks” to the source component prerequisites (UC-M02.02); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M02.06-C041-T06 · Authority map:** Identify who may produce, change and consume “Boot availability checks”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M02.06-C041-T07 · Invariant clause:** Add a normative clause for “Boot availability checks” that preserves “Unavailable security randomness blocks operations that require it”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M02.06-C041-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Boot availability checks”; include the source counterexample “The platform reports ready while its required entropy interface is absent” and the intended safe disposition.
- [ ] **UC-M02.06-C041-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Boot check deadline and retry limit” in the “Boot availability checks” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M02.06-C041-T10 · Contract review:** Review the “Boot availability checks” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M02.06-C042 · Delivery

**Original checklist item:** Check required clocks and entropy availability before enabling dependent operations.

- [ ] **UC-M02.06-C042-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Boot availability checks”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M02.06-C042-T02 · Change plan:** Break the source delivery for “Boot availability checks” into concrete edit targets and reviewable outputs; keep the UC-M02.06 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M02.06-C042-T03 · Core artifact:** Create the “Boot availability checks” fixture or harness for this source instruction: Check required clocks and entropy availability before enabling dependent operations.
- [ ] **UC-M02.06-C042-T04 · Concrete realization:** Connect the “Boot availability checks” harness to its actual intended target, set the expected oracle before running it, and distinguish a mock/control run from a target run.
- [ ] **UC-M02.06-C042-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Boot availability checks” needed to preserve “Unavailable security randomness blocks operations that require it”; record an enforcement gap where only a model exists.
- [ ] **UC-M02.06-C042-T06 · Dependency connection:** Connect the “Boot availability checks” implementation to guest clock adapters, entropy consumers and replay input records; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M02.06-C042-T07 · Resource behavior:** Account for “Boot check deadline and retry limit” in “Boot availability checks”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M02.06-C042-T08 · Delivery check:** Run the smallest real “Boot availability checks” path and its adverse fixture “The platform reports ready while its required entropy interface is absent”; retain actual output, state effects and final disposition.
- [ ] **UC-M02.06-C042-T09 · Patch review:** Review the “Boot availability checks” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M02.06-C042-T10 · Delivery handoff:** Publish the “Boot availability checks” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M02.06-C043 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Unavailable security randomness blocks operations that require it. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M02.06-C043-T01 · Named property:** Create a stable property/check name under this parent for “Boot availability checks”; copy its required invariant exactly: “Unavailable security randomness blocks operations that require it”.
- [ ] **UC-M02.06-C043-T02 · Observable terms:** Define each term in the “Boot availability checks” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M02.06-C043-T03 · Precondition set:** List the preconditions under which “Unavailable security randomness blocks operations that require it” must hold for “Boot availability checks”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M02.06-C043-T04 · Transition coverage:** Map the “Boot availability checks” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M02.06-C043-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Boot availability checks”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M02.06-C043-T06 · Satisfying fixture:** Create a concrete “Boot availability checks” case that satisfies “Unavailable security randomness blocks operations that require it”; record its expected observation before running the assertion or review.
- [ ] **UC-M02.06-C043-T07 · Violating fixture:** Create the source counterexample “The platform reports ready while its required entropy interface is absent” for “Boot availability checks”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M02.06-C043-T08 · Enforcement evidence:** Exercise the “Boot availability checks” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M02.06-C043-T09 · Regression linkage:** Link the “Boot availability checks” property to changes in guest clock adapters, entropy consumers and replay input records; record which dependency or contract changes require rerunning it.
- [ ] **UC-M02.06-C043-T10 · Property disposition:** Compare the satisfying and violating “Boot availability checks” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M02.06-C044 · Integration

**Original checklist item:** Integrate boot availability checks with guest clock adapters, entropy consumers and replay input records; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M02.06-C044-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Boot availability checks” across guest clock adapters, entropy consumers and replay input records; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M02.06-C044-T02 · Field mapping:** Map every “Boot availability checks” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M02.06-C044-T03 · Prerequisite identities:** Record the actual prerequisites for “Boot availability checks” (source dependency list: UC-M02.02); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M02.06-C044-T04 · Ownership agreement:** Specify who owns “Boot availability checks” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M02.06-C044-T05 · Handoff implementation:** Connect “Boot availability checks” through the mapped seam using the real adapter or explicit specification reference; preserve “Unavailable security randomness blocks operations that require it” across the handoff.
- [ ] **UC-M02.06-C044-T06 · Absent-input case:** Omit one required “Boot availability checks” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M02.06-C044-T07 · Stale-input case:** Supply an outdated “Boot availability checks” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M02.06-C044-T08 · Incompatible-input case:** Supply an incompatible “Boot availability checks” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M02.06-C044-T09 · Valid integration trace:** Run a valid “Boot availability checks” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M02.06-C044-T10 · Seam review:** Reconcile the “Boot availability checks” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M02.06-C045 · Valid-case test

**Original checklist item:** Run a valid-path fixture for boot availability checks; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M02.06-C045-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Boot availability checks” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M02.06-C045-T02 · Expected-result oracle:** Specify the “Boot availability checks” expected result independently of the implementation output; include the property “Unavailable security randomness blocks operations that require it” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M02.06-C045-T03 · Fixture material:** Create the concrete “Boot availability checks” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M02.06-C045-T04 · Target preparation:** Prepare the “Boot availability checks” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M02.06-C045-T05 · Initial-state record:** Record the initial “Boot availability checks” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M02.06-C045-T06 · Valid-path execution:** Execute the “Boot availability checks” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M02.06-C045-T07 · Outcome comparison:** Compare every declared “Boot availability checks” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M02.06-C045-T08 · State and bounds check:** Inspect the “Boot availability checks” ownership/state effects and actual use of “Boot check deadline and retry limit”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M02.06-C045-T09 · Repeatability check:** Repeat the same “Boot availability checks” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M02.06-C045-T10 · Positive evidence:** Attach the “Boot availability checks” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M02.06-C046 · Negative test

**Original checklist item:** Negative case: The platform reports ready while its required entropy interface is absent. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M02.06-C046-T01 · Adverse-case definition:** Create a test record for the exact “Boot availability checks” source counterexample: “The platform reports ready while its required entropy interface is absent”; state which precondition or invariant it challenges.
- [ ] **UC-M02.06-C046-T02 · Safe fixture boundary:** Define the contained test boundary for “Boot availability checks”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M02.06-C046-T03 · Valid control:** Construct a valid “Boot availability checks” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M02.06-C046-T04 · Minimal adverse input:** Derive the “Boot availability checks” adverse fixture from the control with the smallest documented change needed to reproduce “The platform reports ready while its required entropy interface is absent”; retain that change as reproducible data.
- [ ] **UC-M02.06-C046-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Boot availability checks”; require “Unavailable security randomness blocks operations that require it” and forbid a false-success verdict.
- [ ] **UC-M02.06-C046-T06 · Adverse execution:** Exercise the “Boot availability checks” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M02.06-C046-T07 · Effect inspection:** Inspect “Boot availability checks” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M02.06-C046-T08 · Refusal versus failure:** Confirm the “Boot availability checks” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M02.06-C046-T09 · Reset and retention:** Restore only the disposable “Boot availability checks” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M02.06-C046-T10 · Negative regression:** Register the “Boot availability checks” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M02.06-C047 · Change / failure test

**Original checklist item:** Exercise boot availability checks when a replay is restored while live clock availability or entropy delivery changes; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M02.06-C047-T01 · Scenario record:** Write the “Boot availability checks” change/failure scenario exactly as supplied: a replay is restored while live clock availability or entropy delivery changes; identify the property that must remain true: “Unavailable security randomness blocks operations that require it”.
- [ ] **UC-M02.06-C047-T02 · Baseline capture:** Create a known-valid “Boot availability checks” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M02.06-C047-T03 · Injection map:** Locate the “Boot availability checks” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M02.06-C047-T04 · Disposition oracle:** Define the legal intermediate and final “Boot availability checks” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M02.06-C047-T05 · Controlled trigger:** Introduce the controlled “Boot availability checks” scenario in the disposable fixture: a replay is restored while live clock availability or entropy delivery changes; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M02.06-C047-T06 · Intermediate inspection:** Inspect the “Boot availability checks” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M02.06-C047-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Boot availability checks”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M02.06-C047-T08 · Stale-evidence cleanup:** Invalidate superseded “Boot availability checks” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M02.06-C047-T09 · Repeat and compare:** Repeat the selected “Boot availability checks” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M02.06-C047-T10 · Failure evidence:** Publish the “Boot availability checks” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M02.06-C048 · Bounds

**Original checklist item:** Choose, document and test limits for boot check deadline and retry limit; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M02.06-C048-T01 · Quantity inventory:** Create a measurement inventory for “Boot availability checks”: “Boot check deadline and retry limit”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M02.06-C048-T02 · Measurement method:** Choose how to observe each “Boot availability checks” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M02.06-C048-T03 · Budget decision:** Select justified resource and input limits for “Boot availability checks”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M02.06-C048-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Boot availability checks” cases for “Boot check deadline and retry limit”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M02.06-C048-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Boot availability checks” limit; preserve “Unavailable security randomness blocks operations that require it”.
- [ ] **UC-M02.06-C048-T06 · Normal measurement:** Run or review the normal “Boot availability checks” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M02.06-C048-T07 · At-limit measurement:** Exercise the “Boot availability checks” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M02.06-C048-T08 · Over-limit measurement:** Exercise the “Boot availability checks” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M02.06-C048-T09 · Uncovered-scope report:** List the “Boot availability checks” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M02.06-C048-T10 · Limit evidence:** Publish the selected “Boot availability checks” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M02.06-C049 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for boot availability checks with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M02.06-C049-T01 · Event inventory:** List the “Boot availability checks” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M02.06-C049-T02 · Diagnostic schema:** Define nonsecret fields for “Boot availability checks” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M02.06-C049-T03 · Failure mapping:** Map each documented “Boot availability checks” refusal or error to a diagnostic outcome; include “The platform reports ready while its required entropy interface is absent” and prohibit conversion into a success message.
- [ ] **UC-M02.06-C049-T04 · Emission path:** Add the “Boot availability checks” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M02.06-C049-T05 · Redaction check:** Test “Boot availability checks” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M02.06-C049-T06 · Output budget:** Set and exercise bounded “Boot availability checks” message size, rate and retention compatible with “Boot check deadline and retry limit”; define truncation behavior that preserves the final reason.
- [ ] **UC-M02.06-C049-T07 · Success/refusal fixtures:** Capture “Boot availability checks” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M02.06-C049-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Boot availability checks” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M02.06-C049-T09 · Operator review:** Read the “Boot availability checks” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M02.06-C049-T10 · Diagnostic evidence:** Publish redacted “Boot availability checks” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M02.06-C050 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for boot availability checks; label unexecuted checks as untested.

- [ ] **UC-M02.06-C050-T01 · Evidence inventory:** List the “Boot availability checks” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M02.06-C050-T02 · Artifact references:** Record the exact “Boot availability checks” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M02.06-C050-T03 · Fixture references:** Attach the “Boot availability checks” fixture IDs, input identities and oracle definition; preserve the source counterexample “The platform reports ready while its required entropy interface is absent” as a distinct evidence case.
- [ ] **UC-M02.06-C050-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Boot availability checks”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M02.06-C050-T05 · Environment record:** Record the actual “Boot availability checks” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M02.06-C050-T06 · Expected versus observed:** Pair every “Boot availability checks” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M02.06-C050-T07 · Failure and limit records:** Attach “Boot availability checks” change/failure and bounds evidence where required; include uncovered “Boot check deadline and retry limit” and unresolved violations of “Unavailable security randomness blocks operations that require it”.
- [ ] **UC-M02.06-C050-T08 · Evidence hygiene:** Check the “Boot availability checks” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M02.06-C050-T09 · Reproduction review:** Have the “Boot availability checks” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M02.06-C050-T10 · Acceptance linkage:** Link the “Boot availability checks” evidence to its parent and UC-M02.06 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 06. Entropy failure behavior

**Source delivery:** Define explicit errors for unavailable or failed randomness requests.

**Source invariant:** Entropy failure cannot silently fall back to deterministic values.

**Source negative case:** A failed entropy read returns a zero-filled buffer as success.

**Source bounded quantities:** Failure retries and diagnostic size.

### UC-M02.06-C051 · Contract

**Original checklist item:** Specify entropy failure behavior inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M02.06-C051-T01 · Scope statement:** Draft the operation boundary for “Entropy failure behavior” within Clock and entropy interfaces; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M02.06-C051-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Entropy failure behavior”; record each producer, representation and missing-value meaning.
- [ ] **UC-M02.06-C051-T03 · Output inventory:** List the outputs of “Entropy failure behavior” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M02.06-C051-T04 · Field dictionary:** Create a field-and-term dictionary for “Entropy failure behavior”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M02.06-C051-T05 · Prerequisite contract:** Map “Entropy failure behavior” to the source component prerequisites (UC-M02.02); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M02.06-C051-T06 · Authority map:** Identify who may produce, change and consume “Entropy failure behavior”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M02.06-C051-T07 · Invariant clause:** Add a normative clause for “Entropy failure behavior” that preserves “Entropy failure cannot silently fall back to deterministic values”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M02.06-C051-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Entropy failure behavior”; include the source counterexample “A failed entropy read returns a zero-filled buffer as success” and the intended safe disposition.
- [ ] **UC-M02.06-C051-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Failure retries and diagnostic size” in the “Entropy failure behavior” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M02.06-C051-T10 · Contract review:** Review the “Entropy failure behavior” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M02.06-C052 · Delivery

**Original checklist item:** Define explicit errors for unavailable or failed randomness requests.

- [ ] **UC-M02.06-C052-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Entropy failure behavior”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M02.06-C052-T02 · Change plan:** Break the source delivery for “Entropy failure behavior” into concrete edit targets and reviewable outputs; keep the UC-M02.06 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M02.06-C052-T03 · Core artifact:** Create the “Entropy failure behavior” model, schema or inventory that realizes this source instruction: Define explicit errors for unavailable or failed randomness requests.
- [ ] **UC-M02.06-C052-T04 · Concrete realization:** Populate “Entropy failure behavior” with one concrete worked case; map every required entity or field to its source and flag any unmapped entry.
- [ ] **UC-M02.06-C052-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Entropy failure behavior” needed to preserve “Entropy failure cannot silently fall back to deterministic values”; record an enforcement gap where only a model exists.
- [ ] **UC-M02.06-C052-T06 · Dependency connection:** Connect the “Entropy failure behavior” implementation to guest clock adapters, entropy consumers and replay input records; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M02.06-C052-T07 · Resource behavior:** Account for “Failure retries and diagnostic size” in “Entropy failure behavior”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M02.06-C052-T08 · Delivery check:** Run the smallest real “Entropy failure behavior” path and its adverse fixture “A failed entropy read returns a zero-filled buffer as success”; retain actual output, state effects and final disposition.
- [ ] **UC-M02.06-C052-T09 · Patch review:** Review the “Entropy failure behavior” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M02.06-C052-T10 · Delivery handoff:** Publish the “Entropy failure behavior” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M02.06-C053 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Entropy failure cannot silently fall back to deterministic values. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M02.06-C053-T01 · Named property:** Create a stable property/check name under this parent for “Entropy failure behavior”; copy its required invariant exactly: “Entropy failure cannot silently fall back to deterministic values”.
- [ ] **UC-M02.06-C053-T02 · Observable terms:** Define each term in the “Entropy failure behavior” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M02.06-C053-T03 · Precondition set:** List the preconditions under which “Entropy failure cannot silently fall back to deterministic values” must hold for “Entropy failure behavior”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M02.06-C053-T04 · Transition coverage:** Map the “Entropy failure behavior” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M02.06-C053-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Entropy failure behavior”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M02.06-C053-T06 · Satisfying fixture:** Create a concrete “Entropy failure behavior” case that satisfies “Entropy failure cannot silently fall back to deterministic values”; record its expected observation before running the assertion or review.
- [ ] **UC-M02.06-C053-T07 · Violating fixture:** Create the source counterexample “A failed entropy read returns a zero-filled buffer as success” for “Entropy failure behavior”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M02.06-C053-T08 · Enforcement evidence:** Exercise the “Entropy failure behavior” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M02.06-C053-T09 · Regression linkage:** Link the “Entropy failure behavior” property to changes in guest clock adapters, entropy consumers and replay input records; record which dependency or contract changes require rerunning it.
- [ ] **UC-M02.06-C053-T10 · Property disposition:** Compare the satisfying and violating “Entropy failure behavior” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M02.06-C054 · Integration

**Original checklist item:** Integrate entropy failure behavior with guest clock adapters, entropy consumers and replay input records; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M02.06-C054-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Entropy failure behavior” across guest clock adapters, entropy consumers and replay input records; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M02.06-C054-T02 · Field mapping:** Map every “Entropy failure behavior” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M02.06-C054-T03 · Prerequisite identities:** Record the actual prerequisites for “Entropy failure behavior” (source dependency list: UC-M02.02); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M02.06-C054-T04 · Ownership agreement:** Specify who owns “Entropy failure behavior” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M02.06-C054-T05 · Handoff implementation:** Connect “Entropy failure behavior” through the mapped seam using the real adapter or explicit specification reference; preserve “Entropy failure cannot silently fall back to deterministic values” across the handoff.
- [ ] **UC-M02.06-C054-T06 · Absent-input case:** Omit one required “Entropy failure behavior” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M02.06-C054-T07 · Stale-input case:** Supply an outdated “Entropy failure behavior” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M02.06-C054-T08 · Incompatible-input case:** Supply an incompatible “Entropy failure behavior” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M02.06-C054-T09 · Valid integration trace:** Run a valid “Entropy failure behavior” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M02.06-C054-T10 · Seam review:** Reconcile the “Entropy failure behavior” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M02.06-C055 · Valid-case test

**Original checklist item:** Run a valid-path fixture for entropy failure behavior; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M02.06-C055-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Entropy failure behavior” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M02.06-C055-T02 · Expected-result oracle:** Specify the “Entropy failure behavior” expected result independently of the implementation output; include the property “Entropy failure cannot silently fall back to deterministic values” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M02.06-C055-T03 · Fixture material:** Create the concrete “Entropy failure behavior” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M02.06-C055-T04 · Target preparation:** Prepare the “Entropy failure behavior” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M02.06-C055-T05 · Initial-state record:** Record the initial “Entropy failure behavior” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M02.06-C055-T06 · Valid-path execution:** Execute the “Entropy failure behavior” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M02.06-C055-T07 · Outcome comparison:** Compare every declared “Entropy failure behavior” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M02.06-C055-T08 · State and bounds check:** Inspect the “Entropy failure behavior” ownership/state effects and actual use of “Failure retries and diagnostic size”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M02.06-C055-T09 · Repeatability check:** Repeat the same “Entropy failure behavior” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M02.06-C055-T10 · Positive evidence:** Attach the “Entropy failure behavior” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M02.06-C056 · Negative test

**Original checklist item:** Negative case: A failed entropy read returns a zero-filled buffer as success. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M02.06-C056-T01 · Adverse-case definition:** Create a test record for the exact “Entropy failure behavior” source counterexample: “A failed entropy read returns a zero-filled buffer as success”; state which precondition or invariant it challenges.
- [ ] **UC-M02.06-C056-T02 · Safe fixture boundary:** Define the contained test boundary for “Entropy failure behavior”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M02.06-C056-T03 · Valid control:** Construct a valid “Entropy failure behavior” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M02.06-C056-T04 · Minimal adverse input:** Derive the “Entropy failure behavior” adverse fixture from the control with the smallest documented change needed to reproduce “A failed entropy read returns a zero-filled buffer as success”; retain that change as reproducible data.
- [ ] **UC-M02.06-C056-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Entropy failure behavior”; require “Entropy failure cannot silently fall back to deterministic values” and forbid a false-success verdict.
- [ ] **UC-M02.06-C056-T06 · Adverse execution:** Exercise the “Entropy failure behavior” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M02.06-C056-T07 · Effect inspection:** Inspect “Entropy failure behavior” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M02.06-C056-T08 · Refusal versus failure:** Confirm the “Entropy failure behavior” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M02.06-C056-T09 · Reset and retention:** Restore only the disposable “Entropy failure behavior” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M02.06-C056-T10 · Negative regression:** Register the “Entropy failure behavior” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M02.06-C057 · Change / failure test

**Original checklist item:** Exercise entropy failure behavior when a replay is restored while live clock availability or entropy delivery changes; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M02.06-C057-T01 · Scenario record:** Write the “Entropy failure behavior” change/failure scenario exactly as supplied: a replay is restored while live clock availability or entropy delivery changes; identify the property that must remain true: “Entropy failure cannot silently fall back to deterministic values”.
- [ ] **UC-M02.06-C057-T02 · Baseline capture:** Create a known-valid “Entropy failure behavior” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M02.06-C057-T03 · Injection map:** Locate the “Entropy failure behavior” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M02.06-C057-T04 · Disposition oracle:** Define the legal intermediate and final “Entropy failure behavior” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M02.06-C057-T05 · Controlled trigger:** Introduce the controlled “Entropy failure behavior” scenario in the disposable fixture: a replay is restored while live clock availability or entropy delivery changes; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M02.06-C057-T06 · Intermediate inspection:** Inspect the “Entropy failure behavior” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M02.06-C057-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Entropy failure behavior”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M02.06-C057-T08 · Stale-evidence cleanup:** Invalidate superseded “Entropy failure behavior” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M02.06-C057-T09 · Repeat and compare:** Repeat the selected “Entropy failure behavior” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M02.06-C057-T10 · Failure evidence:** Publish the “Entropy failure behavior” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M02.06-C058 · Bounds

**Original checklist item:** Choose, document and test limits for failure retries and diagnostic size; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M02.06-C058-T01 · Quantity inventory:** Create a measurement inventory for “Entropy failure behavior”: “Failure retries and diagnostic size”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M02.06-C058-T02 · Measurement method:** Choose how to observe each “Entropy failure behavior” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M02.06-C058-T03 · Budget decision:** Select justified resource and input limits for “Entropy failure behavior”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M02.06-C058-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Entropy failure behavior” cases for “Failure retries and diagnostic size”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M02.06-C058-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Entropy failure behavior” limit; preserve “Entropy failure cannot silently fall back to deterministic values”.
- [ ] **UC-M02.06-C058-T06 · Normal measurement:** Run or review the normal “Entropy failure behavior” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M02.06-C058-T07 · At-limit measurement:** Exercise the “Entropy failure behavior” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M02.06-C058-T08 · Over-limit measurement:** Exercise the “Entropy failure behavior” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M02.06-C058-T09 · Uncovered-scope report:** List the “Entropy failure behavior” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M02.06-C058-T10 · Limit evidence:** Publish the selected “Entropy failure behavior” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M02.06-C059 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for entropy failure behavior with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M02.06-C059-T01 · Event inventory:** List the “Entropy failure behavior” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M02.06-C059-T02 · Diagnostic schema:** Define nonsecret fields for “Entropy failure behavior” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M02.06-C059-T03 · Failure mapping:** Map each documented “Entropy failure behavior” refusal or error to a diagnostic outcome; include “A failed entropy read returns a zero-filled buffer as success” and prohibit conversion into a success message.
- [ ] **UC-M02.06-C059-T04 · Emission path:** Add the “Entropy failure behavior” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M02.06-C059-T05 · Redaction check:** Test “Entropy failure behavior” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M02.06-C059-T06 · Output budget:** Set and exercise bounded “Entropy failure behavior” message size, rate and retention compatible with “Failure retries and diagnostic size”; define truncation behavior that preserves the final reason.
- [ ] **UC-M02.06-C059-T07 · Success/refusal fixtures:** Capture “Entropy failure behavior” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M02.06-C059-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Entropy failure behavior” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M02.06-C059-T09 · Operator review:** Read the “Entropy failure behavior” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M02.06-C059-T10 · Diagnostic evidence:** Publish redacted “Entropy failure behavior” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M02.06-C060 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for entropy failure behavior; label unexecuted checks as untested.

- [ ] **UC-M02.06-C060-T01 · Evidence inventory:** List the “Entropy failure behavior” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M02.06-C060-T02 · Artifact references:** Record the exact “Entropy failure behavior” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M02.06-C060-T03 · Fixture references:** Attach the “Entropy failure behavior” fixture IDs, input identities and oracle definition; preserve the source counterexample “A failed entropy read returns a zero-filled buffer as success” as a distinct evidence case.
- [ ] **UC-M02.06-C060-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Entropy failure behavior”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M02.06-C060-T05 · Environment record:** Record the actual “Entropy failure behavior” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M02.06-C060-T06 · Expected versus observed:** Pair every “Entropy failure behavior” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M02.06-C060-T07 · Failure and limit records:** Attach “Entropy failure behavior” change/failure and bounds evidence where required; include uncovered “Failure retries and diagnostic size” and unresolved violations of “Entropy failure cannot silently fall back to deterministic values”.
- [ ] **UC-M02.06-C060-T08 · Evidence hygiene:** Check the “Entropy failure behavior” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M02.06-C060-T09 · Reproduction review:** Have the “Entropy failure behavior” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M02.06-C060-T10 · Acceptance linkage:** Link the “Entropy failure behavior” evidence to its parent and UC-M02.06 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 07. Clock conversion bounds

**Source delivery:** Validate units, ranges and arithmetic when converting time representations.

**Source invariant:** Time conversion cannot wrap a deadline into the past or distant future.

**Source negative case:** A very large duration overflows during unit conversion.

**Source bounded quantities:** Duration range and arithmetic width.

### UC-M02.06-C061 · Contract

**Original checklist item:** Specify clock conversion bounds inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M02.06-C061-T01 · Scope statement:** Draft the operation boundary for “Clock conversion bounds” within Clock and entropy interfaces; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M02.06-C061-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Clock conversion bounds”; record each producer, representation and missing-value meaning.
- [ ] **UC-M02.06-C061-T03 · Output inventory:** List the outputs of “Clock conversion bounds” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M02.06-C061-T04 · Field dictionary:** Create a field-and-term dictionary for “Clock conversion bounds”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M02.06-C061-T05 · Prerequisite contract:** Map “Clock conversion bounds” to the source component prerequisites (UC-M02.02); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M02.06-C061-T06 · Authority map:** Identify who may produce, change and consume “Clock conversion bounds”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M02.06-C061-T07 · Invariant clause:** Add a normative clause for “Clock conversion bounds” that preserves “Time conversion cannot wrap a deadline into the past or distant future”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M02.06-C061-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Clock conversion bounds”; include the source counterexample “A very large duration overflows during unit conversion” and the intended safe disposition.
- [ ] **UC-M02.06-C061-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Duration range and arithmetic width” in the “Clock conversion bounds” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M02.06-C061-T10 · Contract review:** Review the “Clock conversion bounds” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M02.06-C062 · Delivery

**Original checklist item:** Validate units, ranges and arithmetic when converting time representations.

- [ ] **UC-M02.06-C062-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Clock conversion bounds”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M02.06-C062-T02 · Change plan:** Break the source delivery for “Clock conversion bounds” into concrete edit targets and reviewable outputs; keep the UC-M02.06 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M02.06-C062-T03 · Core artifact:** Implement the smallest selected-profile change for “Clock conversion bounds” that realizes this source instruction: Validate units, ranges and arithmetic when converting time representations.
- [ ] **UC-M02.06-C062-T04 · Concrete realization:** Trace “Clock conversion bounds” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M02.06-C062-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Clock conversion bounds” needed to preserve “Time conversion cannot wrap a deadline into the past or distant future”; record an enforcement gap where only a model exists.
- [ ] **UC-M02.06-C062-T06 · Dependency connection:** Connect the “Clock conversion bounds” implementation to guest clock adapters, entropy consumers and replay input records; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M02.06-C062-T07 · Resource behavior:** Account for “Duration range and arithmetic width” in “Clock conversion bounds”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M02.06-C062-T08 · Delivery check:** Run the smallest real “Clock conversion bounds” path and its adverse fixture “A very large duration overflows during unit conversion”; retain actual output, state effects and final disposition.
- [ ] **UC-M02.06-C062-T09 · Patch review:** Review the “Clock conversion bounds” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M02.06-C062-T10 · Delivery handoff:** Publish the “Clock conversion bounds” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M02.06-C063 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Time conversion cannot wrap a deadline into the past or distant future. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M02.06-C063-T01 · Named property:** Create a stable property/check name under this parent for “Clock conversion bounds”; copy its required invariant exactly: “Time conversion cannot wrap a deadline into the past or distant future”.
- [ ] **UC-M02.06-C063-T02 · Observable terms:** Define each term in the “Clock conversion bounds” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M02.06-C063-T03 · Precondition set:** List the preconditions under which “Time conversion cannot wrap a deadline into the past or distant future” must hold for “Clock conversion bounds”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M02.06-C063-T04 · Transition coverage:** Map the “Clock conversion bounds” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M02.06-C063-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Clock conversion bounds”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M02.06-C063-T06 · Satisfying fixture:** Create a concrete “Clock conversion bounds” case that satisfies “Time conversion cannot wrap a deadline into the past or distant future”; record its expected observation before running the assertion or review.
- [ ] **UC-M02.06-C063-T07 · Violating fixture:** Create the source counterexample “A very large duration overflows during unit conversion” for “Clock conversion bounds”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M02.06-C063-T08 · Enforcement evidence:** Exercise the “Clock conversion bounds” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M02.06-C063-T09 · Regression linkage:** Link the “Clock conversion bounds” property to changes in guest clock adapters, entropy consumers and replay input records; record which dependency or contract changes require rerunning it.
- [ ] **UC-M02.06-C063-T10 · Property disposition:** Compare the satisfying and violating “Clock conversion bounds” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M02.06-C064 · Integration

**Original checklist item:** Integrate clock conversion bounds with guest clock adapters, entropy consumers and replay input records; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M02.06-C064-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Clock conversion bounds” across guest clock adapters, entropy consumers and replay input records; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M02.06-C064-T02 · Field mapping:** Map every “Clock conversion bounds” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M02.06-C064-T03 · Prerequisite identities:** Record the actual prerequisites for “Clock conversion bounds” (source dependency list: UC-M02.02); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M02.06-C064-T04 · Ownership agreement:** Specify who owns “Clock conversion bounds” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M02.06-C064-T05 · Handoff implementation:** Connect “Clock conversion bounds” through the mapped seam using the real adapter or explicit specification reference; preserve “Time conversion cannot wrap a deadline into the past or distant future” across the handoff.
- [ ] **UC-M02.06-C064-T06 · Absent-input case:** Omit one required “Clock conversion bounds” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M02.06-C064-T07 · Stale-input case:** Supply an outdated “Clock conversion bounds” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M02.06-C064-T08 · Incompatible-input case:** Supply an incompatible “Clock conversion bounds” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M02.06-C064-T09 · Valid integration trace:** Run a valid “Clock conversion bounds” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M02.06-C064-T10 · Seam review:** Reconcile the “Clock conversion bounds” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M02.06-C065 · Valid-case test

**Original checklist item:** Run a valid-path fixture for clock conversion bounds; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M02.06-C065-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Clock conversion bounds” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M02.06-C065-T02 · Expected-result oracle:** Specify the “Clock conversion bounds” expected result independently of the implementation output; include the property “Time conversion cannot wrap a deadline into the past or distant future” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M02.06-C065-T03 · Fixture material:** Create the concrete “Clock conversion bounds” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M02.06-C065-T04 · Target preparation:** Prepare the “Clock conversion bounds” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M02.06-C065-T05 · Initial-state record:** Record the initial “Clock conversion bounds” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M02.06-C065-T06 · Valid-path execution:** Execute the “Clock conversion bounds” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M02.06-C065-T07 · Outcome comparison:** Compare every declared “Clock conversion bounds” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M02.06-C065-T08 · State and bounds check:** Inspect the “Clock conversion bounds” ownership/state effects and actual use of “Duration range and arithmetic width”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M02.06-C065-T09 · Repeatability check:** Repeat the same “Clock conversion bounds” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M02.06-C065-T10 · Positive evidence:** Attach the “Clock conversion bounds” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M02.06-C066 · Negative test

**Original checklist item:** Negative case: A very large duration overflows during unit conversion. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M02.06-C066-T01 · Adverse-case definition:** Create a test record for the exact “Clock conversion bounds” source counterexample: “A very large duration overflows during unit conversion”; state which precondition or invariant it challenges.
- [ ] **UC-M02.06-C066-T02 · Safe fixture boundary:** Define the contained test boundary for “Clock conversion bounds”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M02.06-C066-T03 · Valid control:** Construct a valid “Clock conversion bounds” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M02.06-C066-T04 · Minimal adverse input:** Derive the “Clock conversion bounds” adverse fixture from the control with the smallest documented change needed to reproduce “A very large duration overflows during unit conversion”; retain that change as reproducible data.
- [ ] **UC-M02.06-C066-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Clock conversion bounds”; require “Time conversion cannot wrap a deadline into the past or distant future” and forbid a false-success verdict.
- [ ] **UC-M02.06-C066-T06 · Adverse execution:** Exercise the “Clock conversion bounds” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M02.06-C066-T07 · Effect inspection:** Inspect “Clock conversion bounds” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M02.06-C066-T08 · Refusal versus failure:** Confirm the “Clock conversion bounds” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M02.06-C066-T09 · Reset and retention:** Restore only the disposable “Clock conversion bounds” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M02.06-C066-T10 · Negative regression:** Register the “Clock conversion bounds” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M02.06-C067 · Change / failure test

**Original checklist item:** Exercise clock conversion bounds when a replay is restored while live clock availability or entropy delivery changes; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M02.06-C067-T01 · Scenario record:** Write the “Clock conversion bounds” change/failure scenario exactly as supplied: a replay is restored while live clock availability or entropy delivery changes; identify the property that must remain true: “Time conversion cannot wrap a deadline into the past or distant future”.
- [ ] **UC-M02.06-C067-T02 · Baseline capture:** Create a known-valid “Clock conversion bounds” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M02.06-C067-T03 · Injection map:** Locate the “Clock conversion bounds” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M02.06-C067-T04 · Disposition oracle:** Define the legal intermediate and final “Clock conversion bounds” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M02.06-C067-T05 · Controlled trigger:** Introduce the controlled “Clock conversion bounds” scenario in the disposable fixture: a replay is restored while live clock availability or entropy delivery changes; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M02.06-C067-T06 · Intermediate inspection:** Inspect the “Clock conversion bounds” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M02.06-C067-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Clock conversion bounds”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M02.06-C067-T08 · Stale-evidence cleanup:** Invalidate superseded “Clock conversion bounds” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M02.06-C067-T09 · Repeat and compare:** Repeat the selected “Clock conversion bounds” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M02.06-C067-T10 · Failure evidence:** Publish the “Clock conversion bounds” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M02.06-C068 · Bounds

**Original checklist item:** Choose, document and test limits for duration range and arithmetic width; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M02.06-C068-T01 · Quantity inventory:** Create a measurement inventory for “Clock conversion bounds”: “Duration range and arithmetic width”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M02.06-C068-T02 · Measurement method:** Choose how to observe each “Clock conversion bounds” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M02.06-C068-T03 · Budget decision:** Select justified resource and input limits for “Clock conversion bounds”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M02.06-C068-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Clock conversion bounds” cases for “Duration range and arithmetic width”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M02.06-C068-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Clock conversion bounds” limit; preserve “Time conversion cannot wrap a deadline into the past or distant future”.
- [ ] **UC-M02.06-C068-T06 · Normal measurement:** Run or review the normal “Clock conversion bounds” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M02.06-C068-T07 · At-limit measurement:** Exercise the “Clock conversion bounds” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M02.06-C068-T08 · Over-limit measurement:** Exercise the “Clock conversion bounds” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M02.06-C068-T09 · Uncovered-scope report:** List the “Clock conversion bounds” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M02.06-C068-T10 · Limit evidence:** Publish the selected “Clock conversion bounds” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M02.06-C069 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for clock conversion bounds with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M02.06-C069-T01 · Event inventory:** List the “Clock conversion bounds” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M02.06-C069-T02 · Diagnostic schema:** Define nonsecret fields for “Clock conversion bounds” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M02.06-C069-T03 · Failure mapping:** Map each documented “Clock conversion bounds” refusal or error to a diagnostic outcome; include “A very large duration overflows during unit conversion” and prohibit conversion into a success message.
- [ ] **UC-M02.06-C069-T04 · Emission path:** Add the “Clock conversion bounds” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M02.06-C069-T05 · Redaction check:** Test “Clock conversion bounds” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M02.06-C069-T06 · Output budget:** Set and exercise bounded “Clock conversion bounds” message size, rate and retention compatible with “Duration range and arithmetic width”; define truncation behavior that preserves the final reason.
- [ ] **UC-M02.06-C069-T07 · Success/refusal fixtures:** Capture “Clock conversion bounds” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M02.06-C069-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Clock conversion bounds” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M02.06-C069-T09 · Operator review:** Read the “Clock conversion bounds” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M02.06-C069-T10 · Diagnostic evidence:** Publish redacted “Clock conversion bounds” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M02.06-C070 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for clock conversion bounds; label unexecuted checks as untested.

- [ ] **UC-M02.06-C070-T01 · Evidence inventory:** List the “Clock conversion bounds” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M02.06-C070-T02 · Artifact references:** Record the exact “Clock conversion bounds” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M02.06-C070-T03 · Fixture references:** Attach the “Clock conversion bounds” fixture IDs, input identities and oracle definition; preserve the source counterexample “A very large duration overflows during unit conversion” as a distinct evidence case.
- [ ] **UC-M02.06-C070-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Clock conversion bounds”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M02.06-C070-T05 · Environment record:** Record the actual “Clock conversion bounds” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M02.06-C070-T06 · Expected versus observed:** Pair every “Clock conversion bounds” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M02.06-C070-T07 · Failure and limit records:** Attach “Clock conversion bounds” change/failure and bounds evidence where required; include uncovered “Duration range and arithmetic width” and unresolved violations of “Time conversion cannot wrap a deadline into the past or distant future”.
- [ ] **UC-M02.06-C070-T08 · Evidence hygiene:** Check the “Clock conversion bounds” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M02.06-C070-T09 · Reproduction review:** Have the “Clock conversion bounds” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M02.06-C070-T10 · Acceptance linkage:** Link the “Clock conversion bounds” evidence to its parent and UC-M02.06 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 08. Replay input recording

**Source delivery:** Record nondeterministic inputs required by the declared replay profile.

**Source invariant:** Replay claims identify any unrecorded clock or entropy influence.

**Source negative case:** A failure depends on an unrecorded external timing input.

**Source bounded quantities:** Trace bytes and recorded input count.

### UC-M02.06-C071 · Contract

**Original checklist item:** Specify replay input recording inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M02.06-C071-T01 · Scope statement:** Draft the operation boundary for “Replay input recording” within Clock and entropy interfaces; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M02.06-C071-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Replay input recording”; record each producer, representation and missing-value meaning.
- [ ] **UC-M02.06-C071-T03 · Output inventory:** List the outputs of “Replay input recording” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M02.06-C071-T04 · Field dictionary:** Create a field-and-term dictionary for “Replay input recording”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M02.06-C071-T05 · Prerequisite contract:** Map “Replay input recording” to the source component prerequisites (UC-M02.02); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M02.06-C071-T06 · Authority map:** Identify who may produce, change and consume “Replay input recording”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M02.06-C071-T07 · Invariant clause:** Add a normative clause for “Replay input recording” that preserves “Replay claims identify any unrecorded clock or entropy influence”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M02.06-C071-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Replay input recording”; include the source counterexample “A failure depends on an unrecorded external timing input” and the intended safe disposition.
- [ ] **UC-M02.06-C071-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Trace bytes and recorded input count” in the “Replay input recording” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M02.06-C071-T10 · Contract review:** Review the “Replay input recording” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M02.06-C072 · Delivery

**Original checklist item:** Record nondeterministic inputs required by the declared replay profile.

- [ ] **UC-M02.06-C072-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Replay input recording”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M02.06-C072-T02 · Change plan:** Break the source delivery for “Replay input recording” into concrete edit targets and reviewable outputs; keep the UC-M02.06 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M02.06-C072-T03 · Core artifact:** Create the “Replay input recording” model, schema or inventory that realizes this source instruction: Record nondeterministic inputs required by the declared replay profile.
- [ ] **UC-M02.06-C072-T04 · Concrete realization:** Populate “Replay input recording” with one concrete worked case; map every required entity or field to its source and flag any unmapped entry.
- [ ] **UC-M02.06-C072-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Replay input recording” needed to preserve “Replay claims identify any unrecorded clock or entropy influence”; record an enforcement gap where only a model exists.
- [ ] **UC-M02.06-C072-T06 · Dependency connection:** Connect the “Replay input recording” implementation to guest clock adapters, entropy consumers and replay input records; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M02.06-C072-T07 · Resource behavior:** Account for “Trace bytes and recorded input count” in “Replay input recording”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M02.06-C072-T08 · Delivery check:** Run the smallest real “Replay input recording” path and its adverse fixture “A failure depends on an unrecorded external timing input”; retain actual output, state effects and final disposition.
- [ ] **UC-M02.06-C072-T09 · Patch review:** Review the “Replay input recording” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M02.06-C072-T10 · Delivery handoff:** Publish the “Replay input recording” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M02.06-C073 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Replay claims identify any unrecorded clock or entropy influence. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M02.06-C073-T01 · Named property:** Create a stable property/check name under this parent for “Replay input recording”; copy its required invariant exactly: “Replay claims identify any unrecorded clock or entropy influence”.
- [ ] **UC-M02.06-C073-T02 · Observable terms:** Define each term in the “Replay input recording” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M02.06-C073-T03 · Precondition set:** List the preconditions under which “Replay claims identify any unrecorded clock or entropy influence” must hold for “Replay input recording”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M02.06-C073-T04 · Transition coverage:** Map the “Replay input recording” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M02.06-C073-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Replay input recording”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M02.06-C073-T06 · Satisfying fixture:** Create a concrete “Replay input recording” case that satisfies “Replay claims identify any unrecorded clock or entropy influence”; record its expected observation before running the assertion or review.
- [ ] **UC-M02.06-C073-T07 · Violating fixture:** Create the source counterexample “A failure depends on an unrecorded external timing input” for “Replay input recording”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M02.06-C073-T08 · Enforcement evidence:** Exercise the “Replay input recording” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M02.06-C073-T09 · Regression linkage:** Link the “Replay input recording” property to changes in guest clock adapters, entropy consumers and replay input records; record which dependency or contract changes require rerunning it.
- [ ] **UC-M02.06-C073-T10 · Property disposition:** Compare the satisfying and violating “Replay input recording” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M02.06-C074 · Integration

**Original checklist item:** Integrate replay input recording with guest clock adapters, entropy consumers and replay input records; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M02.06-C074-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Replay input recording” across guest clock adapters, entropy consumers and replay input records; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M02.06-C074-T02 · Field mapping:** Map every “Replay input recording” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M02.06-C074-T03 · Prerequisite identities:** Record the actual prerequisites for “Replay input recording” (source dependency list: UC-M02.02); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M02.06-C074-T04 · Ownership agreement:** Specify who owns “Replay input recording” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M02.06-C074-T05 · Handoff implementation:** Connect “Replay input recording” through the mapped seam using the real adapter or explicit specification reference; preserve “Replay claims identify any unrecorded clock or entropy influence” across the handoff.
- [ ] **UC-M02.06-C074-T06 · Absent-input case:** Omit one required “Replay input recording” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M02.06-C074-T07 · Stale-input case:** Supply an outdated “Replay input recording” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M02.06-C074-T08 · Incompatible-input case:** Supply an incompatible “Replay input recording” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M02.06-C074-T09 · Valid integration trace:** Run a valid “Replay input recording” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M02.06-C074-T10 · Seam review:** Reconcile the “Replay input recording” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M02.06-C075 · Valid-case test

**Original checklist item:** Run a valid-path fixture for replay input recording; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M02.06-C075-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Replay input recording” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M02.06-C075-T02 · Expected-result oracle:** Specify the “Replay input recording” expected result independently of the implementation output; include the property “Replay claims identify any unrecorded clock or entropy influence” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M02.06-C075-T03 · Fixture material:** Create the concrete “Replay input recording” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M02.06-C075-T04 · Target preparation:** Prepare the “Replay input recording” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M02.06-C075-T05 · Initial-state record:** Record the initial “Replay input recording” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M02.06-C075-T06 · Valid-path execution:** Execute the “Replay input recording” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M02.06-C075-T07 · Outcome comparison:** Compare every declared “Replay input recording” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M02.06-C075-T08 · State and bounds check:** Inspect the “Replay input recording” ownership/state effects and actual use of “Trace bytes and recorded input count”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M02.06-C075-T09 · Repeatability check:** Repeat the same “Replay input recording” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M02.06-C075-T10 · Positive evidence:** Attach the “Replay input recording” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M02.06-C076 · Negative test

**Original checklist item:** Negative case: A failure depends on an unrecorded external timing input. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M02.06-C076-T01 · Adverse-case definition:** Create a test record for the exact “Replay input recording” source counterexample: “A failure depends on an unrecorded external timing input”; state which precondition or invariant it challenges.
- [ ] **UC-M02.06-C076-T02 · Safe fixture boundary:** Define the contained test boundary for “Replay input recording”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M02.06-C076-T03 · Valid control:** Construct a valid “Replay input recording” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M02.06-C076-T04 · Minimal adverse input:** Derive the “Replay input recording” adverse fixture from the control with the smallest documented change needed to reproduce “A failure depends on an unrecorded external timing input”; retain that change as reproducible data.
- [ ] **UC-M02.06-C076-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Replay input recording”; require “Replay claims identify any unrecorded clock or entropy influence” and forbid a false-success verdict.
- [ ] **UC-M02.06-C076-T06 · Adverse execution:** Exercise the “Replay input recording” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M02.06-C076-T07 · Effect inspection:** Inspect “Replay input recording” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M02.06-C076-T08 · Refusal versus failure:** Confirm the “Replay input recording” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M02.06-C076-T09 · Reset and retention:** Restore only the disposable “Replay input recording” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M02.06-C076-T10 · Negative regression:** Register the “Replay input recording” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M02.06-C077 · Change / failure test

**Original checklist item:** Exercise replay input recording when a replay is restored while live clock availability or entropy delivery changes; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M02.06-C077-T01 · Scenario record:** Write the “Replay input recording” change/failure scenario exactly as supplied: a replay is restored while live clock availability or entropy delivery changes; identify the property that must remain true: “Replay claims identify any unrecorded clock or entropy influence”.
- [ ] **UC-M02.06-C077-T02 · Baseline capture:** Create a known-valid “Replay input recording” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M02.06-C077-T03 · Injection map:** Locate the “Replay input recording” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M02.06-C077-T04 · Disposition oracle:** Define the legal intermediate and final “Replay input recording” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M02.06-C077-T05 · Controlled trigger:** Introduce the controlled “Replay input recording” scenario in the disposable fixture: a replay is restored while live clock availability or entropy delivery changes; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M02.06-C077-T06 · Intermediate inspection:** Inspect the “Replay input recording” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M02.06-C077-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Replay input recording”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M02.06-C077-T08 · Stale-evidence cleanup:** Invalidate superseded “Replay input recording” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M02.06-C077-T09 · Repeat and compare:** Repeat the selected “Replay input recording” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M02.06-C077-T10 · Failure evidence:** Publish the “Replay input recording” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M02.06-C078 · Bounds

**Original checklist item:** Choose, document and test limits for trace bytes and recorded input count; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M02.06-C078-T01 · Quantity inventory:** Create a measurement inventory for “Replay input recording”: “Trace bytes and recorded input count”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M02.06-C078-T02 · Measurement method:** Choose how to observe each “Replay input recording” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M02.06-C078-T03 · Budget decision:** Select justified resource and input limits for “Replay input recording”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M02.06-C078-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Replay input recording” cases for “Trace bytes and recorded input count”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M02.06-C078-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Replay input recording” limit; preserve “Replay claims identify any unrecorded clock or entropy influence”.
- [ ] **UC-M02.06-C078-T06 · Normal measurement:** Run or review the normal “Replay input recording” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M02.06-C078-T07 · At-limit measurement:** Exercise the “Replay input recording” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M02.06-C078-T08 · Over-limit measurement:** Exercise the “Replay input recording” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M02.06-C078-T09 · Uncovered-scope report:** List the “Replay input recording” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M02.06-C078-T10 · Limit evidence:** Publish the selected “Replay input recording” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M02.06-C079 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for replay input recording with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M02.06-C079-T01 · Event inventory:** List the “Replay input recording” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M02.06-C079-T02 · Diagnostic schema:** Define nonsecret fields for “Replay input recording” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M02.06-C079-T03 · Failure mapping:** Map each documented “Replay input recording” refusal or error to a diagnostic outcome; include “A failure depends on an unrecorded external timing input” and prohibit conversion into a success message.
- [ ] **UC-M02.06-C079-T04 · Emission path:** Add the “Replay input recording” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M02.06-C079-T05 · Redaction check:** Test “Replay input recording” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M02.06-C079-T06 · Output budget:** Set and exercise bounded “Replay input recording” message size, rate and retention compatible with “Trace bytes and recorded input count”; define truncation behavior that preserves the final reason.
- [ ] **UC-M02.06-C079-T07 · Success/refusal fixtures:** Capture “Replay input recording” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M02.06-C079-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Replay input recording” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M02.06-C079-T09 · Operator review:** Read the “Replay input recording” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M02.06-C079-T10 · Diagnostic evidence:** Publish redacted “Replay input recording” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M02.06-C080 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for replay input recording; label unexecuted checks as untested.

- [ ] **UC-M02.06-C080-T01 · Evidence inventory:** List the “Replay input recording” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M02.06-C080-T02 · Artifact references:** Record the exact “Replay input recording” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M02.06-C080-T03 · Fixture references:** Attach the “Replay input recording” fixture IDs, input identities and oracle definition; preserve the source counterexample “A failure depends on an unrecorded external timing input” as a distinct evidence case.
- [ ] **UC-M02.06-C080-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Replay input recording”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M02.06-C080-T05 · Environment record:** Record the actual “Replay input recording” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M02.06-C080-T06 · Expected versus observed:** Pair every “Replay input recording” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M02.06-C080-T07 · Failure and limit records:** Attach “Replay input recording” change/failure and bounds evidence where required; include uncovered “Trace bytes and recorded input count” and unresolved violations of “Replay claims identify any unrecorded clock or entropy influence”.
- [ ] **UC-M02.06-C080-T08 · Evidence hygiene:** Check the “Replay input recording” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M02.06-C080-T09 · Reproduction review:** Have the “Replay input recording” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M02.06-C080-T10 · Acceptance linkage:** Link the “Replay input recording” evidence to its parent and UC-M02.06 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 09. Security and replay separation

**Source delivery:** Prevent replay artifacts from containing live secrets or recreating production credentials.

**Source invariant:** Replaying an invocation cannot reproduce an active security identity.

**Source negative case:** A restored replay seed recreates a secret injection token.

**Source bounded quantities:** Sensitive-field count and artifact inspection size.

### UC-M02.06-C081 · Contract

**Original checklist item:** Specify security and replay separation inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M02.06-C081-T01 · Scope statement:** Draft the operation boundary for “Security and replay separation” within Clock and entropy interfaces; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M02.06-C081-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Security and replay separation”; record each producer, representation and missing-value meaning.
- [ ] **UC-M02.06-C081-T03 · Output inventory:** List the outputs of “Security and replay separation” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M02.06-C081-T04 · Field dictionary:** Create a field-and-term dictionary for “Security and replay separation”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M02.06-C081-T05 · Prerequisite contract:** Map “Security and replay separation” to the source component prerequisites (UC-M02.02); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M02.06-C081-T06 · Authority map:** Identify who may produce, change and consume “Security and replay separation”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M02.06-C081-T07 · Invariant clause:** Add a normative clause for “Security and replay separation” that preserves “Replaying an invocation cannot reproduce an active security identity”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M02.06-C081-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Security and replay separation”; include the source counterexample “A restored replay seed recreates a secret injection token” and the intended safe disposition.
- [ ] **UC-M02.06-C081-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Sensitive-field count and artifact inspection size” in the “Security and replay separation” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M02.06-C081-T10 · Contract review:** Review the “Security and replay separation” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M02.06-C082 · Delivery

**Original checklist item:** Prevent replay artifacts from containing live secrets or recreating production credentials.

- [ ] **UC-M02.06-C082-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Security and replay separation”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M02.06-C082-T02 · Change plan:** Break the source delivery for “Security and replay separation” into concrete edit targets and reviewable outputs; keep the UC-M02.06 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M02.06-C082-T03 · Core artifact:** Implement the smallest selected-profile change for “Security and replay separation” that realizes this source instruction: Prevent replay artifacts from containing live secrets or recreating production credentials.
- [ ] **UC-M02.06-C082-T04 · Concrete realization:** Trace “Security and replay separation” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M02.06-C082-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Security and replay separation” needed to preserve “Replaying an invocation cannot reproduce an active security identity”; record an enforcement gap where only a model exists.
- [ ] **UC-M02.06-C082-T06 · Dependency connection:** Connect the “Security and replay separation” implementation to guest clock adapters, entropy consumers and replay input records; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M02.06-C082-T07 · Resource behavior:** Account for “Sensitive-field count and artifact inspection size” in “Security and replay separation”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M02.06-C082-T08 · Delivery check:** Run the smallest real “Security and replay separation” path and its adverse fixture “A restored replay seed recreates a secret injection token”; retain actual output, state effects and final disposition.
- [ ] **UC-M02.06-C082-T09 · Patch review:** Review the “Security and replay separation” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M02.06-C082-T10 · Delivery handoff:** Publish the “Security and replay separation” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M02.06-C083 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Replaying an invocation cannot reproduce an active security identity. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M02.06-C083-T01 · Named property:** Create a stable property/check name under this parent for “Security and replay separation”; copy its required invariant exactly: “Replaying an invocation cannot reproduce an active security identity”.
- [ ] **UC-M02.06-C083-T02 · Observable terms:** Define each term in the “Security and replay separation” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M02.06-C083-T03 · Precondition set:** List the preconditions under which “Replaying an invocation cannot reproduce an active security identity” must hold for “Security and replay separation”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M02.06-C083-T04 · Transition coverage:** Map the “Security and replay separation” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M02.06-C083-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Security and replay separation”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M02.06-C083-T06 · Satisfying fixture:** Create a concrete “Security and replay separation” case that satisfies “Replaying an invocation cannot reproduce an active security identity”; record its expected observation before running the assertion or review.
- [ ] **UC-M02.06-C083-T07 · Violating fixture:** Create the source counterexample “A restored replay seed recreates a secret injection token” for “Security and replay separation”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M02.06-C083-T08 · Enforcement evidence:** Exercise the “Security and replay separation” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M02.06-C083-T09 · Regression linkage:** Link the “Security and replay separation” property to changes in guest clock adapters, entropy consumers and replay input records; record which dependency or contract changes require rerunning it.
- [ ] **UC-M02.06-C083-T10 · Property disposition:** Compare the satisfying and violating “Security and replay separation” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M02.06-C084 · Integration

**Original checklist item:** Integrate security and replay separation with guest clock adapters, entropy consumers and replay input records; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M02.06-C084-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Security and replay separation” across guest clock adapters, entropy consumers and replay input records; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M02.06-C084-T02 · Field mapping:** Map every “Security and replay separation” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M02.06-C084-T03 · Prerequisite identities:** Record the actual prerequisites for “Security and replay separation” (source dependency list: UC-M02.02); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M02.06-C084-T04 · Ownership agreement:** Specify who owns “Security and replay separation” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M02.06-C084-T05 · Handoff implementation:** Connect “Security and replay separation” through the mapped seam using the real adapter or explicit specification reference; preserve “Replaying an invocation cannot reproduce an active security identity” across the handoff.
- [ ] **UC-M02.06-C084-T06 · Absent-input case:** Omit one required “Security and replay separation” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M02.06-C084-T07 · Stale-input case:** Supply an outdated “Security and replay separation” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M02.06-C084-T08 · Incompatible-input case:** Supply an incompatible “Security and replay separation” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M02.06-C084-T09 · Valid integration trace:** Run a valid “Security and replay separation” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M02.06-C084-T10 · Seam review:** Reconcile the “Security and replay separation” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M02.06-C085 · Valid-case test

**Original checklist item:** Run a valid-path fixture for security and replay separation; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M02.06-C085-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Security and replay separation” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M02.06-C085-T02 · Expected-result oracle:** Specify the “Security and replay separation” expected result independently of the implementation output; include the property “Replaying an invocation cannot reproduce an active security identity” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M02.06-C085-T03 · Fixture material:** Create the concrete “Security and replay separation” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M02.06-C085-T04 · Target preparation:** Prepare the “Security and replay separation” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M02.06-C085-T05 · Initial-state record:** Record the initial “Security and replay separation” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M02.06-C085-T06 · Valid-path execution:** Execute the “Security and replay separation” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M02.06-C085-T07 · Outcome comparison:** Compare every declared “Security and replay separation” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M02.06-C085-T08 · State and bounds check:** Inspect the “Security and replay separation” ownership/state effects and actual use of “Sensitive-field count and artifact inspection size”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M02.06-C085-T09 · Repeatability check:** Repeat the same “Security and replay separation” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M02.06-C085-T10 · Positive evidence:** Attach the “Security and replay separation” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M02.06-C086 · Negative test

**Original checklist item:** Negative case: A restored replay seed recreates a secret injection token. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M02.06-C086-T01 · Adverse-case definition:** Create a test record for the exact “Security and replay separation” source counterexample: “A restored replay seed recreates a secret injection token”; state which precondition or invariant it challenges.
- [ ] **UC-M02.06-C086-T02 · Safe fixture boundary:** Define the contained test boundary for “Security and replay separation”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M02.06-C086-T03 · Valid control:** Construct a valid “Security and replay separation” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M02.06-C086-T04 · Minimal adverse input:** Derive the “Security and replay separation” adverse fixture from the control with the smallest documented change needed to reproduce “A restored replay seed recreates a secret injection token”; retain that change as reproducible data.
- [ ] **UC-M02.06-C086-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Security and replay separation”; require “Replaying an invocation cannot reproduce an active security identity” and forbid a false-success verdict.
- [ ] **UC-M02.06-C086-T06 · Adverse execution:** Exercise the “Security and replay separation” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M02.06-C086-T07 · Effect inspection:** Inspect “Security and replay separation” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M02.06-C086-T08 · Refusal versus failure:** Confirm the “Security and replay separation” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M02.06-C086-T09 · Reset and retention:** Restore only the disposable “Security and replay separation” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M02.06-C086-T10 · Negative regression:** Register the “Security and replay separation” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M02.06-C087 · Change / failure test

**Original checklist item:** Exercise security and replay separation when a replay is restored while live clock availability or entropy delivery changes; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M02.06-C087-T01 · Scenario record:** Write the “Security and replay separation” change/failure scenario exactly as supplied: a replay is restored while live clock availability or entropy delivery changes; identify the property that must remain true: “Replaying an invocation cannot reproduce an active security identity”.
- [ ] **UC-M02.06-C087-T02 · Baseline capture:** Create a known-valid “Security and replay separation” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M02.06-C087-T03 · Injection map:** Locate the “Security and replay separation” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M02.06-C087-T04 · Disposition oracle:** Define the legal intermediate and final “Security and replay separation” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M02.06-C087-T05 · Controlled trigger:** Introduce the controlled “Security and replay separation” scenario in the disposable fixture: a replay is restored while live clock availability or entropy delivery changes; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M02.06-C087-T06 · Intermediate inspection:** Inspect the “Security and replay separation” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M02.06-C087-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Security and replay separation”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M02.06-C087-T08 · Stale-evidence cleanup:** Invalidate superseded “Security and replay separation” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M02.06-C087-T09 · Repeat and compare:** Repeat the selected “Security and replay separation” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M02.06-C087-T10 · Failure evidence:** Publish the “Security and replay separation” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M02.06-C088 · Bounds

**Original checklist item:** Choose, document and test limits for sensitive-field count and artifact inspection size; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M02.06-C088-T01 · Quantity inventory:** Create a measurement inventory for “Security and replay separation”: “Sensitive-field count and artifact inspection size”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M02.06-C088-T02 · Measurement method:** Choose how to observe each “Security and replay separation” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M02.06-C088-T03 · Budget decision:** Select justified resource and input limits for “Security and replay separation”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M02.06-C088-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Security and replay separation” cases for “Sensitive-field count and artifact inspection size”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M02.06-C088-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Security and replay separation” limit; preserve “Replaying an invocation cannot reproduce an active security identity”.
- [ ] **UC-M02.06-C088-T06 · Normal measurement:** Run or review the normal “Security and replay separation” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M02.06-C088-T07 · At-limit measurement:** Exercise the “Security and replay separation” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M02.06-C088-T08 · Over-limit measurement:** Exercise the “Security and replay separation” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M02.06-C088-T09 · Uncovered-scope report:** List the “Security and replay separation” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M02.06-C088-T10 · Limit evidence:** Publish the selected “Security and replay separation” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M02.06-C089 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for security and replay separation with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M02.06-C089-T01 · Event inventory:** List the “Security and replay separation” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M02.06-C089-T02 · Diagnostic schema:** Define nonsecret fields for “Security and replay separation” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M02.06-C089-T03 · Failure mapping:** Map each documented “Security and replay separation” refusal or error to a diagnostic outcome; include “A restored replay seed recreates a secret injection token” and prohibit conversion into a success message.
- [ ] **UC-M02.06-C089-T04 · Emission path:** Add the “Security and replay separation” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M02.06-C089-T05 · Redaction check:** Test “Security and replay separation” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M02.06-C089-T06 · Output budget:** Set and exercise bounded “Security and replay separation” message size, rate and retention compatible with “Sensitive-field count and artifact inspection size”; define truncation behavior that preserves the final reason.
- [ ] **UC-M02.06-C089-T07 · Success/refusal fixtures:** Capture “Security and replay separation” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M02.06-C089-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Security and replay separation” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M02.06-C089-T09 · Operator review:** Read the “Security and replay separation” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M02.06-C089-T10 · Diagnostic evidence:** Publish redacted “Security and replay separation” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M02.06-C090 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for security and replay separation; label unexecuted checks as untested.

- [ ] **UC-M02.06-C090-T01 · Evidence inventory:** List the “Security and replay separation” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M02.06-C090-T02 · Artifact references:** Record the exact “Security and replay separation” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M02.06-C090-T03 · Fixture references:** Attach the “Security and replay separation” fixture IDs, input identities and oracle definition; preserve the source counterexample “A restored replay seed recreates a secret injection token” as a distinct evidence case.
- [ ] **UC-M02.06-C090-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Security and replay separation”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M02.06-C090-T05 · Environment record:** Record the actual “Security and replay separation” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M02.06-C090-T06 · Expected versus observed:** Pair every “Security and replay separation” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M02.06-C090-T07 · Failure and limit records:** Attach “Security and replay separation” change/failure and bounds evidence where required; include uncovered “Sensitive-field count and artifact inspection size” and unresolved violations of “Replaying an invocation cannot reproduce an active security identity”.
- [ ] **UC-M02.06-C090-T08 · Evidence hygiene:** Check the “Security and replay separation” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M02.06-C090-T09 · Reproduction review:** Have the “Security and replay separation” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M02.06-C090-T10 · Acceptance linkage:** Link the “Security and replay separation” evidence to its parent and UC-M02.06 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 10. Clock/entropy conformance

**Source delivery:** Test time adjustments, entropy refusal and deterministic replay independently.

**Source invariant:** Replay correctness and secure randomness have separate verdicts.

**Source negative case:** A passing deterministic replay is treated as entropy qualification.

**Source bounded quantities:** Source matrix and repeated test budget.

### UC-M02.06-C091 · Contract

**Original checklist item:** Specify clock/entropy conformance inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M02.06-C091-T01 · Scope statement:** Draft the operation boundary for “Clock/entropy conformance” within Clock and entropy interfaces; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M02.06-C091-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Clock/entropy conformance”; record each producer, representation and missing-value meaning.
- [ ] **UC-M02.06-C091-T03 · Output inventory:** List the outputs of “Clock/entropy conformance” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M02.06-C091-T04 · Field dictionary:** Create a field-and-term dictionary for “Clock/entropy conformance”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M02.06-C091-T05 · Prerequisite contract:** Map “Clock/entropy conformance” to the source component prerequisites (UC-M02.02); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M02.06-C091-T06 · Authority map:** Identify who may produce, change and consume “Clock/entropy conformance”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M02.06-C091-T07 · Invariant clause:** Add a normative clause for “Clock/entropy conformance” that preserves “Replay correctness and secure randomness have separate verdicts”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M02.06-C091-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Clock/entropy conformance”; include the source counterexample “A passing deterministic replay is treated as entropy qualification” and the intended safe disposition.
- [ ] **UC-M02.06-C091-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Source matrix and repeated test budget” in the “Clock/entropy conformance” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M02.06-C091-T10 · Contract review:** Review the “Clock/entropy conformance” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M02.06-C092 · Delivery

**Original checklist item:** Test time adjustments, entropy refusal and deterministic replay independently.

- [ ] **UC-M02.06-C092-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Clock/entropy conformance”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M02.06-C092-T02 · Change plan:** Break the source delivery for “Clock/entropy conformance” into concrete edit targets and reviewable outputs; keep the UC-M02.06 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M02.06-C092-T03 · Core artifact:** Create the “Clock/entropy conformance” fixture or harness for this source instruction: Test time adjustments, entropy refusal and deterministic replay independently.
- [ ] **UC-M02.06-C092-T04 · Concrete realization:** Connect the “Clock/entropy conformance” harness to its actual intended target, set the expected oracle before running it, and distinguish a mock/control run from a target run.
- [ ] **UC-M02.06-C092-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Clock/entropy conformance” needed to preserve “Replay correctness and secure randomness have separate verdicts”; record an enforcement gap where only a model exists.
- [ ] **UC-M02.06-C092-T06 · Dependency connection:** Connect the “Clock/entropy conformance” implementation to guest clock adapters, entropy consumers and replay input records; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M02.06-C092-T07 · Resource behavior:** Account for “Source matrix and repeated test budget” in “Clock/entropy conformance”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M02.06-C092-T08 · Delivery check:** Run the smallest real “Clock/entropy conformance” path and its adverse fixture “A passing deterministic replay is treated as entropy qualification”; retain actual output, state effects and final disposition.
- [ ] **UC-M02.06-C092-T09 · Patch review:** Review the “Clock/entropy conformance” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M02.06-C092-T10 · Delivery handoff:** Publish the “Clock/entropy conformance” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M02.06-C093 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Replay correctness and secure randomness have separate verdicts. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M02.06-C093-T01 · Named property:** Create a stable property/check name under this parent for “Clock/entropy conformance”; copy its required invariant exactly: “Replay correctness and secure randomness have separate verdicts”.
- [ ] **UC-M02.06-C093-T02 · Observable terms:** Define each term in the “Clock/entropy conformance” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M02.06-C093-T03 · Precondition set:** List the preconditions under which “Replay correctness and secure randomness have separate verdicts” must hold for “Clock/entropy conformance”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M02.06-C093-T04 · Transition coverage:** Map the “Clock/entropy conformance” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M02.06-C093-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Clock/entropy conformance”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M02.06-C093-T06 · Satisfying fixture:** Create a concrete “Clock/entropy conformance” case that satisfies “Replay correctness and secure randomness have separate verdicts”; record its expected observation before running the assertion or review.
- [ ] **UC-M02.06-C093-T07 · Violating fixture:** Create the source counterexample “A passing deterministic replay is treated as entropy qualification” for “Clock/entropy conformance”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M02.06-C093-T08 · Enforcement evidence:** Exercise the “Clock/entropy conformance” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M02.06-C093-T09 · Regression linkage:** Link the “Clock/entropy conformance” property to changes in guest clock adapters, entropy consumers and replay input records; record which dependency or contract changes require rerunning it.
- [ ] **UC-M02.06-C093-T10 · Property disposition:** Compare the satisfying and violating “Clock/entropy conformance” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M02.06-C094 · Integration

**Original checklist item:** Integrate clock/entropy conformance with guest clock adapters, entropy consumers and replay input records; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M02.06-C094-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Clock/entropy conformance” across guest clock adapters, entropy consumers and replay input records; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M02.06-C094-T02 · Field mapping:** Map every “Clock/entropy conformance” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M02.06-C094-T03 · Prerequisite identities:** Record the actual prerequisites for “Clock/entropy conformance” (source dependency list: UC-M02.02); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M02.06-C094-T04 · Ownership agreement:** Specify who owns “Clock/entropy conformance” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M02.06-C094-T05 · Handoff implementation:** Connect “Clock/entropy conformance” through the mapped seam using the real adapter or explicit specification reference; preserve “Replay correctness and secure randomness have separate verdicts” across the handoff.
- [ ] **UC-M02.06-C094-T06 · Absent-input case:** Omit one required “Clock/entropy conformance” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M02.06-C094-T07 · Stale-input case:** Supply an outdated “Clock/entropy conformance” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M02.06-C094-T08 · Incompatible-input case:** Supply an incompatible “Clock/entropy conformance” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M02.06-C094-T09 · Valid integration trace:** Run a valid “Clock/entropy conformance” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M02.06-C094-T10 · Seam review:** Reconcile the “Clock/entropy conformance” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M02.06-C095 · Valid-case test

**Original checklist item:** Run a valid-path fixture for clock/entropy conformance; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M02.06-C095-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Clock/entropy conformance” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M02.06-C095-T02 · Expected-result oracle:** Specify the “Clock/entropy conformance” expected result independently of the implementation output; include the property “Replay correctness and secure randomness have separate verdicts” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M02.06-C095-T03 · Fixture material:** Create the concrete “Clock/entropy conformance” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M02.06-C095-T04 · Target preparation:** Prepare the “Clock/entropy conformance” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M02.06-C095-T05 · Initial-state record:** Record the initial “Clock/entropy conformance” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M02.06-C095-T06 · Valid-path execution:** Execute the “Clock/entropy conformance” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M02.06-C095-T07 · Outcome comparison:** Compare every declared “Clock/entropy conformance” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M02.06-C095-T08 · State and bounds check:** Inspect the “Clock/entropy conformance” ownership/state effects and actual use of “Source matrix and repeated test budget”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M02.06-C095-T09 · Repeatability check:** Repeat the same “Clock/entropy conformance” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M02.06-C095-T10 · Positive evidence:** Attach the “Clock/entropy conformance” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M02.06-C096 · Negative test

**Original checklist item:** Negative case: A passing deterministic replay is treated as entropy qualification. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M02.06-C096-T01 · Adverse-case definition:** Create a test record for the exact “Clock/entropy conformance” source counterexample: “A passing deterministic replay is treated as entropy qualification”; state which precondition or invariant it challenges.
- [ ] **UC-M02.06-C096-T02 · Safe fixture boundary:** Define the contained test boundary for “Clock/entropy conformance”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M02.06-C096-T03 · Valid control:** Construct a valid “Clock/entropy conformance” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M02.06-C096-T04 · Minimal adverse input:** Derive the “Clock/entropy conformance” adverse fixture from the control with the smallest documented change needed to reproduce “A passing deterministic replay is treated as entropy qualification”; retain that change as reproducible data.
- [ ] **UC-M02.06-C096-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Clock/entropy conformance”; require “Replay correctness and secure randomness have separate verdicts” and forbid a false-success verdict.
- [ ] **UC-M02.06-C096-T06 · Adverse execution:** Exercise the “Clock/entropy conformance” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M02.06-C096-T07 · Effect inspection:** Inspect “Clock/entropy conformance” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M02.06-C096-T08 · Refusal versus failure:** Confirm the “Clock/entropy conformance” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M02.06-C096-T09 · Reset and retention:** Restore only the disposable “Clock/entropy conformance” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M02.06-C096-T10 · Negative regression:** Register the “Clock/entropy conformance” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M02.06-C097 · Change / failure test

**Original checklist item:** Exercise clock/entropy conformance when a replay is restored while live clock availability or entropy delivery changes; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M02.06-C097-T01 · Scenario record:** Write the “Clock/entropy conformance” change/failure scenario exactly as supplied: a replay is restored while live clock availability or entropy delivery changes; identify the property that must remain true: “Replay correctness and secure randomness have separate verdicts”.
- [ ] **UC-M02.06-C097-T02 · Baseline capture:** Create a known-valid “Clock/entropy conformance” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M02.06-C097-T03 · Injection map:** Locate the “Clock/entropy conformance” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M02.06-C097-T04 · Disposition oracle:** Define the legal intermediate and final “Clock/entropy conformance” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M02.06-C097-T05 · Controlled trigger:** Introduce the controlled “Clock/entropy conformance” scenario in the disposable fixture: a replay is restored while live clock availability or entropy delivery changes; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M02.06-C097-T06 · Intermediate inspection:** Inspect the “Clock/entropy conformance” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M02.06-C097-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Clock/entropy conformance”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M02.06-C097-T08 · Stale-evidence cleanup:** Invalidate superseded “Clock/entropy conformance” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M02.06-C097-T09 · Repeat and compare:** Repeat the selected “Clock/entropy conformance” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M02.06-C097-T10 · Failure evidence:** Publish the “Clock/entropy conformance” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M02.06-C098 · Bounds

**Original checklist item:** Choose, document and test limits for source matrix and repeated test budget; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M02.06-C098-T01 · Quantity inventory:** Create a measurement inventory for “Clock/entropy conformance”: “Source matrix and repeated test budget”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M02.06-C098-T02 · Measurement method:** Choose how to observe each “Clock/entropy conformance” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M02.06-C098-T03 · Budget decision:** Select justified resource and input limits for “Clock/entropy conformance”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M02.06-C098-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Clock/entropy conformance” cases for “Source matrix and repeated test budget”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M02.06-C098-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Clock/entropy conformance” limit; preserve “Replay correctness and secure randomness have separate verdicts”.
- [ ] **UC-M02.06-C098-T06 · Normal measurement:** Run or review the normal “Clock/entropy conformance” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M02.06-C098-T07 · At-limit measurement:** Exercise the “Clock/entropy conformance” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M02.06-C098-T08 · Over-limit measurement:** Exercise the “Clock/entropy conformance” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M02.06-C098-T09 · Uncovered-scope report:** List the “Clock/entropy conformance” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M02.06-C098-T10 · Limit evidence:** Publish the selected “Clock/entropy conformance” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M02.06-C099 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for clock/entropy conformance with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M02.06-C099-T01 · Event inventory:** List the “Clock/entropy conformance” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M02.06-C099-T02 · Diagnostic schema:** Define nonsecret fields for “Clock/entropy conformance” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M02.06-C099-T03 · Failure mapping:** Map each documented “Clock/entropy conformance” refusal or error to a diagnostic outcome; include “A passing deterministic replay is treated as entropy qualification” and prohibit conversion into a success message.
- [ ] **UC-M02.06-C099-T04 · Emission path:** Add the “Clock/entropy conformance” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M02.06-C099-T05 · Redaction check:** Test “Clock/entropy conformance” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M02.06-C099-T06 · Output budget:** Set and exercise bounded “Clock/entropy conformance” message size, rate and retention compatible with “Source matrix and repeated test budget”; define truncation behavior that preserves the final reason.
- [ ] **UC-M02.06-C099-T07 · Success/refusal fixtures:** Capture “Clock/entropy conformance” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M02.06-C099-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Clock/entropy conformance” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M02.06-C099-T09 · Operator review:** Read the “Clock/entropy conformance” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M02.06-C099-T10 · Diagnostic evidence:** Publish redacted “Clock/entropy conformance” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M02.06-C100 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for clock/entropy conformance; label unexecuted checks as untested.

- [ ] **UC-M02.06-C100-T01 · Evidence inventory:** List the “Clock/entropy conformance” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M02.06-C100-T02 · Artifact references:** Record the exact “Clock/entropy conformance” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M02.06-C100-T03 · Fixture references:** Attach the “Clock/entropy conformance” fixture IDs, input identities and oracle definition; preserve the source counterexample “A passing deterministic replay is treated as entropy qualification” as a distinct evidence case.
- [ ] **UC-M02.06-C100-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Clock/entropy conformance”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M02.06-C100-T05 · Environment record:** Record the actual “Clock/entropy conformance” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M02.06-C100-T06 · Expected versus observed:** Pair every “Clock/entropy conformance” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M02.06-C100-T07 · Failure and limit records:** Attach “Clock/entropy conformance” change/failure and bounds evidence where required; include uncovered “Source matrix and repeated test budget” and unresolved violations of “Replay correctness and secure randomness have separate verdicts”.
- [ ] **UC-M02.06-C100-T08 · Evidence hygiene:** Check the “Clock/entropy conformance” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M02.06-C100-T09 · Reproduction review:** Have the “Clock/entropy conformance” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M02.06-C100-T10 · Acceptance linkage:** Link the “Clock/entropy conformance” evidence to its parent and UC-M02.06 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

