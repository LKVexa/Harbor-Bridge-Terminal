# UC-M02.01 — Chosen library-OS integration

**To-Do Pack 2.0.0 · Baseline UC-2.2.0 · 100 parent checks × 10 subtasks = 1,000 to-dos**

[Master index](../../INDEX.md) · [Workstream index](../../w/02.md)

| Field | Preserved source value |
|---|---|
| Workstream | 02. Bootable unikernel guest |
| Milestone | B |
| Priority | P0 |
| Source assessment | MISSING |
| Scope | core or selected profile |
| Dependencies | [UC-M01.07](../01/UC-M01.07.md) |
| Source checklist pack | 1.0.0 |
| Original reference labels | [S1], [S2], [S3]. |

## Original requirement

Choose one initial target such as a selected Unikraft configuration or a Solo5-compatible library OS. Port one supported C engine/workload first, not all runtimes at once.

**Original acceptance criterion:** A clean build links the application and only required OS libraries into a guest image, not a host Python command.

**Source trace:** Original checklist `UC100/c/02/UC-M02.01.md` inside [s/checklists.zip](../../s/checklists.zip); exact parent records in [data/parents.jsonl](../../data/parents.jsonl). Original roadmap lines 144–154 are preserved in [s/roadmap.md](../../s/roadmap.md).

## How to use these lists

Every parent statement below is preserved verbatim. Its ten child tasks are proposed decomposition, not implemented capabilities or executed tests. Child IDs append `-T01` through `-T10` to the original parent ID. All begin unchecked / `TODO`. Design/review evidence does not establish runtime enforcement; observe the actual selected target where the parent requires it.

The source dependency graph and selected release profile determine applicability. The numbered child sequence is a local working order, not an added hard dependency graph. An unselected optional feature needs a recorded not-applicable rationale; missing prerequisites for selected work remain blockers. Numerical budgets, backends and trust mechanisms remain decisions unless fixed by the source. Test hostile cases only with synthetic inputs in authorized disposable environments.

## 01. Initial target decision

**Source delivery:** Select one library OS, guest architecture and supported execution environment for the first slice.

**Source invariant:** The selected target is explicit rather than an unspecified universal backend.

**Source negative case:** A build combines incompatible library-OS and guest assumptions.

**Source bounded quantities:** Target count and supported configuration combinations.

### UC-M02.01-C001 · Contract

**Original checklist item:** Specify initial target decision inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M02.01-C001-T01 · Scope statement:** Draft the operation boundary for “Initial target decision” within Chosen library-OS integration; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M02.01-C001-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Initial target decision”; record each producer, representation and missing-value meaning.
- [ ] **UC-M02.01-C001-T03 · Output inventory:** List the outputs of “Initial target decision” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M02.01-C001-T04 · Field dictionary:** Create a field-and-term dictionary for “Initial target decision”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M02.01-C001-T05 · Prerequisite contract:** Map “Initial target decision” to the source component prerequisites (UC-M01.07); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M02.01-C001-T06 · Authority map:** Identify who may produce, change and consume “Initial target decision”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M02.01-C001-T07 · Invariant clause:** Add a normative clause for “Initial target decision” that preserves “The selected target is explicit rather than an unspecified universal backend”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M02.01-C001-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Initial target decision”; include the source counterexample “A build combines incompatible library-OS and guest assumptions” and the intended safe disposition.
- [ ] **UC-M02.01-C001-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Target count and supported configuration combinations” in the “Initial target decision” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M02.01-C001-T10 · Contract review:** Review the “Initial target decision” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M02.01-C002 · Delivery

**Original checklist item:** Select one library OS, guest architecture and supported execution environment for the first slice.

- [ ] **UC-M02.01-C002-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Initial target decision”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M02.01-C002-T02 · Change plan:** Break the source delivery for “Initial target decision” into concrete edit targets and reviewable outputs; keep the UC-M02.01 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M02.01-C002-T03 · Core artifact:** Prepare the “Initial target decision” decision record for this source instruction: Select one library OS, guest architecture and supported execution environment for the first slice.
- [ ] **UC-M02.01-C002-T04 · Concrete realization:** Evaluate the “Initial target decision” choice against its declared constraints; record the exact selected target/configuration and rejected alternatives, leaving unverified compatibility as a blocker.
- [ ] **UC-M02.01-C002-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Initial target decision” needed to preserve “The selected target is explicit rather than an unspecified universal backend”; record an enforcement gap where only a model exists.
- [ ] **UC-M02.01-C002-T06 · Dependency connection:** Connect the “Initial target decision” implementation to the selected engine portability layer, library OS and image build recipe; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M02.01-C002-T07 · Resource behavior:** Account for “Target count and supported configuration combinations” in “Initial target decision”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M02.01-C002-T08 · Delivery check:** Run the smallest real “Initial target decision” path and its adverse fixture “A build combines incompatible library-OS and guest assumptions”; retain actual output, state effects and final disposition.
- [ ] **UC-M02.01-C002-T09 · Patch review:** Review the “Initial target decision” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M02.01-C002-T10 · Delivery handoff:** Publish the “Initial target decision” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M02.01-C003 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: The selected target is explicit rather than an unspecified universal backend. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M02.01-C003-T01 · Named property:** Create a stable property/check name under this parent for “Initial target decision”; copy its required invariant exactly: “The selected target is explicit rather than an unspecified universal backend”.
- [ ] **UC-M02.01-C003-T02 · Observable terms:** Define each term in the “Initial target decision” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M02.01-C003-T03 · Precondition set:** List the preconditions under which “The selected target is explicit rather than an unspecified universal backend” must hold for “Initial target decision”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M02.01-C003-T04 · Transition coverage:** Map the “Initial target decision” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M02.01-C003-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Initial target decision”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M02.01-C003-T06 · Satisfying fixture:** Create a concrete “Initial target decision” case that satisfies “The selected target is explicit rather than an unspecified universal backend”; record its expected observation before running the assertion or review.
- [ ] **UC-M02.01-C003-T07 · Violating fixture:** Create the source counterexample “A build combines incompatible library-OS and guest assumptions” for “Initial target decision”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M02.01-C003-T08 · Enforcement evidence:** Exercise the “Initial target decision” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M02.01-C003-T09 · Regression linkage:** Link the “Initial target decision” property to changes in the selected engine portability layer, library OS and image build recipe; record which dependency or contract changes require rerunning it.
- [ ] **UC-M02.01-C003-T10 · Property disposition:** Compare the satisfying and violating “Initial target decision” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M02.01-C004 · Integration

**Original checklist item:** Integrate initial target decision with the selected engine portability layer, library OS and image build recipe; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M02.01-C004-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Initial target decision” across the selected engine portability layer, library OS and image build recipe; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M02.01-C004-T02 · Field mapping:** Map every “Initial target decision” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M02.01-C004-T03 · Prerequisite identities:** Record the actual prerequisites for “Initial target decision” (source dependency list: UC-M01.07); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M02.01-C004-T04 · Ownership agreement:** Specify who owns “Initial target decision” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M02.01-C004-T05 · Handoff implementation:** Connect “Initial target decision” through the mapped seam using the real adapter or explicit specification reference; preserve “The selected target is explicit rather than an unspecified universal backend” across the handoff.
- [ ] **UC-M02.01-C004-T06 · Absent-input case:** Omit one required “Initial target decision” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M02.01-C004-T07 · Stale-input case:** Supply an outdated “Initial target decision” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M02.01-C004-T08 · Incompatible-input case:** Supply an incompatible “Initial target decision” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M02.01-C004-T09 · Valid integration trace:** Run a valid “Initial target decision” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M02.01-C004-T10 · Seam review:** Reconcile the “Initial target decision” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M02.01-C005 · Valid-case test

**Original checklist item:** Run a valid-path fixture for initial target decision; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M02.01-C005-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Initial target decision” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M02.01-C005-T02 · Expected-result oracle:** Specify the “Initial target decision” expected result independently of the implementation output; include the property “The selected target is explicit rather than an unspecified universal backend” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M02.01-C005-T03 · Fixture material:** Create the concrete “Initial target decision” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M02.01-C005-T04 · Target preparation:** Prepare the “Initial target decision” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M02.01-C005-T05 · Initial-state record:** Record the initial “Initial target decision” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M02.01-C005-T06 · Valid-path execution:** Execute the “Initial target decision” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M02.01-C005-T07 · Outcome comparison:** Compare every declared “Initial target decision” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M02.01-C005-T08 · State and bounds check:** Inspect the “Initial target decision” ownership/state effects and actual use of “Target count and supported configuration combinations”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M02.01-C005-T09 · Repeatability check:** Repeat the same “Initial target decision” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M02.01-C005-T10 · Positive evidence:** Attach the “Initial target decision” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M02.01-C006 · Negative test

**Original checklist item:** Negative case: A build combines incompatible library-OS and guest assumptions. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M02.01-C006-T01 · Adverse-case definition:** Create a test record for the exact “Initial target decision” source counterexample: “A build combines incompatible library-OS and guest assumptions”; state which precondition or invariant it challenges.
- [ ] **UC-M02.01-C006-T02 · Safe fixture boundary:** Define the contained test boundary for “Initial target decision”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M02.01-C006-T03 · Valid control:** Construct a valid “Initial target decision” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M02.01-C006-T04 · Minimal adverse input:** Derive the “Initial target decision” adverse fixture from the control with the smallest documented change needed to reproduce “A build combines incompatible library-OS and guest assumptions”; retain that change as reproducible data.
- [ ] **UC-M02.01-C006-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Initial target decision”; require “The selected target is explicit rather than an unspecified universal backend” and forbid a false-success verdict.
- [ ] **UC-M02.01-C006-T06 · Adverse execution:** Exercise the “Initial target decision” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M02.01-C006-T07 · Effect inspection:** Inspect “Initial target decision” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M02.01-C006-T08 · Refusal versus failure:** Confirm the “Initial target decision” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M02.01-C006-T09 · Reset and retention:** Restore only the disposable “Initial target decision” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M02.01-C006-T10 · Negative regression:** Register the “Initial target decision” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M02.01-C007 · Change / failure test

**Original checklist item:** Exercise initial target decision when the selected library-OS configuration changes and a clean guest rebuild is required; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M02.01-C007-T01 · Scenario record:** Write the “Initial target decision” change/failure scenario exactly as supplied: the selected library-OS configuration changes and a clean guest rebuild is required; identify the property that must remain true: “The selected target is explicit rather than an unspecified universal backend”.
- [ ] **UC-M02.01-C007-T02 · Baseline capture:** Create a known-valid “Initial target decision” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M02.01-C007-T03 · Injection map:** Locate the “Initial target decision” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M02.01-C007-T04 · Disposition oracle:** Define the legal intermediate and final “Initial target decision” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M02.01-C007-T05 · Controlled trigger:** Introduce the controlled “Initial target decision” scenario in the disposable fixture: the selected library-OS configuration changes and a clean guest rebuild is required; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M02.01-C007-T06 · Intermediate inspection:** Inspect the “Initial target decision” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M02.01-C007-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Initial target decision”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M02.01-C007-T08 · Stale-evidence cleanup:** Invalidate superseded “Initial target decision” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M02.01-C007-T09 · Repeat and compare:** Repeat the selected “Initial target decision” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M02.01-C007-T10 · Failure evidence:** Publish the “Initial target decision” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M02.01-C008 · Bounds

**Original checklist item:** Choose, document and test limits for target count and supported configuration combinations; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M02.01-C008-T01 · Quantity inventory:** Create a measurement inventory for “Initial target decision”: “Target count and supported configuration combinations”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M02.01-C008-T02 · Measurement method:** Choose how to observe each “Initial target decision” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M02.01-C008-T03 · Budget decision:** Select justified resource and input limits for “Initial target decision”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M02.01-C008-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Initial target decision” cases for “Target count and supported configuration combinations”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M02.01-C008-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Initial target decision” limit; preserve “The selected target is explicit rather than an unspecified universal backend”.
- [ ] **UC-M02.01-C008-T06 · Normal measurement:** Run or review the normal “Initial target decision” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M02.01-C008-T07 · At-limit measurement:** Exercise the “Initial target decision” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M02.01-C008-T08 · Over-limit measurement:** Exercise the “Initial target decision” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M02.01-C008-T09 · Uncovered-scope report:** List the “Initial target decision” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M02.01-C008-T10 · Limit evidence:** Publish the selected “Initial target decision” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M02.01-C009 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for initial target decision with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M02.01-C009-T01 · Event inventory:** List the “Initial target decision” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M02.01-C009-T02 · Diagnostic schema:** Define nonsecret fields for “Initial target decision” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M02.01-C009-T03 · Failure mapping:** Map each documented “Initial target decision” refusal or error to a diagnostic outcome; include “A build combines incompatible library-OS and guest assumptions” and prohibit conversion into a success message.
- [ ] **UC-M02.01-C009-T04 · Emission path:** Add the “Initial target decision” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M02.01-C009-T05 · Redaction check:** Test “Initial target decision” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M02.01-C009-T06 · Output budget:** Set and exercise bounded “Initial target decision” message size, rate and retention compatible with “Target count and supported configuration combinations”; define truncation behavior that preserves the final reason.
- [ ] **UC-M02.01-C009-T07 · Success/refusal fixtures:** Capture “Initial target decision” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M02.01-C009-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Initial target decision” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M02.01-C009-T09 · Operator review:** Read the “Initial target decision” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M02.01-C009-T10 · Diagnostic evidence:** Publish redacted “Initial target decision” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M02.01-C010 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for initial target decision; label unexecuted checks as untested.

- [ ] **UC-M02.01-C010-T01 · Evidence inventory:** List the “Initial target decision” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M02.01-C010-T02 · Artifact references:** Record the exact “Initial target decision” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M02.01-C010-T03 · Fixture references:** Attach the “Initial target decision” fixture IDs, input identities and oracle definition; preserve the source counterexample “A build combines incompatible library-OS and guest assumptions” as a distinct evidence case.
- [ ] **UC-M02.01-C010-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Initial target decision”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M02.01-C010-T05 · Environment record:** Record the actual “Initial target decision” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M02.01-C010-T06 · Expected versus observed:** Pair every “Initial target decision” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M02.01-C010-T07 · Failure and limit records:** Attach “Initial target decision” change/failure and bounds evidence where required; include uncovered “Target count and supported configuration combinations” and unresolved violations of “The selected target is explicit rather than an unspecified universal backend”.
- [ ] **UC-M02.01-C010-T08 · Evidence hygiene:** Check the “Initial target decision” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M02.01-C010-T09 · Reproduction review:** Have the “Initial target decision” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M02.01-C010-T10 · Acceptance linkage:** Link the “Initial target decision” evidence to its parent and UC-M02.01 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 02. Runtime dependency survey

**Source delivery:** Identify the chosen C engine's required allocation, I/O, clock and termination interfaces.

**Source invariant:** Every required host dependency has an approved guest replacement or explicit blocker.

**Source negative case:** A hidden host system call remains in the engine.

**Source bounded quantities:** Imported symbol count and dependency closure size.

### UC-M02.01-C011 · Contract

**Original checklist item:** Specify runtime dependency survey inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M02.01-C011-T01 · Scope statement:** Draft the operation boundary for “Runtime dependency survey” within Chosen library-OS integration; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M02.01-C011-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Runtime dependency survey”; record each producer, representation and missing-value meaning.
- [ ] **UC-M02.01-C011-T03 · Output inventory:** List the outputs of “Runtime dependency survey” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M02.01-C011-T04 · Field dictionary:** Create a field-and-term dictionary for “Runtime dependency survey”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M02.01-C011-T05 · Prerequisite contract:** Map “Runtime dependency survey” to the source component prerequisites (UC-M01.07); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M02.01-C011-T06 · Authority map:** Identify who may produce, change and consume “Runtime dependency survey”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M02.01-C011-T07 · Invariant clause:** Add a normative clause for “Runtime dependency survey” that preserves “Every required host dependency has an approved guest replacement or explicit blocker”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M02.01-C011-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Runtime dependency survey”; include the source counterexample “A hidden host system call remains in the engine” and the intended safe disposition.
- [ ] **UC-M02.01-C011-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Imported symbol count and dependency closure size” in the “Runtime dependency survey” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M02.01-C011-T10 · Contract review:** Review the “Runtime dependency survey” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M02.01-C012 · Delivery

**Original checklist item:** Identify the chosen C engine's required allocation, I/O, clock and termination interfaces.

- [ ] **UC-M02.01-C012-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Runtime dependency survey”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M02.01-C012-T02 · Change plan:** Break the source delivery for “Runtime dependency survey” into concrete edit targets and reviewable outputs; keep the UC-M02.01 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M02.01-C012-T03 · Core artifact:** Create the “Runtime dependency survey” model, schema or inventory that realizes this source instruction: Identify the chosen C engine's required allocation, I/O, clock and termination interfaces.
- [ ] **UC-M02.01-C012-T04 · Concrete realization:** Populate “Runtime dependency survey” with one concrete worked case; map every required entity or field to its source and flag any unmapped entry.
- [ ] **UC-M02.01-C012-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Runtime dependency survey” needed to preserve “Every required host dependency has an approved guest replacement or explicit blocker”; record an enforcement gap where only a model exists.
- [ ] **UC-M02.01-C012-T06 · Dependency connection:** Connect the “Runtime dependency survey” implementation to the selected engine portability layer, library OS and image build recipe; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M02.01-C012-T07 · Resource behavior:** Account for “Imported symbol count and dependency closure size” in “Runtime dependency survey”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M02.01-C012-T08 · Delivery check:** Run the smallest real “Runtime dependency survey” path and its adverse fixture “A hidden host system call remains in the engine”; retain actual output, state effects and final disposition.
- [ ] **UC-M02.01-C012-T09 · Patch review:** Review the “Runtime dependency survey” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M02.01-C012-T10 · Delivery handoff:** Publish the “Runtime dependency survey” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M02.01-C013 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Every required host dependency has an approved guest replacement or explicit blocker. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M02.01-C013-T01 · Named property:** Create a stable property/check name under this parent for “Runtime dependency survey”; copy its required invariant exactly: “Every required host dependency has an approved guest replacement or explicit blocker”.
- [ ] **UC-M02.01-C013-T02 · Observable terms:** Define each term in the “Runtime dependency survey” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M02.01-C013-T03 · Precondition set:** List the preconditions under which “Every required host dependency has an approved guest replacement or explicit blocker” must hold for “Runtime dependency survey”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M02.01-C013-T04 · Transition coverage:** Map the “Runtime dependency survey” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M02.01-C013-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Runtime dependency survey”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M02.01-C013-T06 · Satisfying fixture:** Create a concrete “Runtime dependency survey” case that satisfies “Every required host dependency has an approved guest replacement or explicit blocker”; record its expected observation before running the assertion or review.
- [ ] **UC-M02.01-C013-T07 · Violating fixture:** Create the source counterexample “A hidden host system call remains in the engine” for “Runtime dependency survey”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M02.01-C013-T08 · Enforcement evidence:** Exercise the “Runtime dependency survey” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M02.01-C013-T09 · Regression linkage:** Link the “Runtime dependency survey” property to changes in the selected engine portability layer, library OS and image build recipe; record which dependency or contract changes require rerunning it.
- [ ] **UC-M02.01-C013-T10 · Property disposition:** Compare the satisfying and violating “Runtime dependency survey” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M02.01-C014 · Integration

**Original checklist item:** Integrate runtime dependency survey with the selected engine portability layer, library OS and image build recipe; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M02.01-C014-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Runtime dependency survey” across the selected engine portability layer, library OS and image build recipe; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M02.01-C014-T02 · Field mapping:** Map every “Runtime dependency survey” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M02.01-C014-T03 · Prerequisite identities:** Record the actual prerequisites for “Runtime dependency survey” (source dependency list: UC-M01.07); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M02.01-C014-T04 · Ownership agreement:** Specify who owns “Runtime dependency survey” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M02.01-C014-T05 · Handoff implementation:** Connect “Runtime dependency survey” through the mapped seam using the real adapter or explicit specification reference; preserve “Every required host dependency has an approved guest replacement or explicit blocker” across the handoff.
- [ ] **UC-M02.01-C014-T06 · Absent-input case:** Omit one required “Runtime dependency survey” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M02.01-C014-T07 · Stale-input case:** Supply an outdated “Runtime dependency survey” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M02.01-C014-T08 · Incompatible-input case:** Supply an incompatible “Runtime dependency survey” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M02.01-C014-T09 · Valid integration trace:** Run a valid “Runtime dependency survey” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M02.01-C014-T10 · Seam review:** Reconcile the “Runtime dependency survey” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M02.01-C015 · Valid-case test

**Original checklist item:** Run a valid-path fixture for runtime dependency survey; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M02.01-C015-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Runtime dependency survey” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M02.01-C015-T02 · Expected-result oracle:** Specify the “Runtime dependency survey” expected result independently of the implementation output; include the property “Every required host dependency has an approved guest replacement or explicit blocker” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M02.01-C015-T03 · Fixture material:** Create the concrete “Runtime dependency survey” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M02.01-C015-T04 · Target preparation:** Prepare the “Runtime dependency survey” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M02.01-C015-T05 · Initial-state record:** Record the initial “Runtime dependency survey” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M02.01-C015-T06 · Valid-path execution:** Execute the “Runtime dependency survey” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M02.01-C015-T07 · Outcome comparison:** Compare every declared “Runtime dependency survey” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M02.01-C015-T08 · State and bounds check:** Inspect the “Runtime dependency survey” ownership/state effects and actual use of “Imported symbol count and dependency closure size”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M02.01-C015-T09 · Repeatability check:** Repeat the same “Runtime dependency survey” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M02.01-C015-T10 · Positive evidence:** Attach the “Runtime dependency survey” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M02.01-C016 · Negative test

**Original checklist item:** Negative case: A hidden host system call remains in the engine. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M02.01-C016-T01 · Adverse-case definition:** Create a test record for the exact “Runtime dependency survey” source counterexample: “A hidden host system call remains in the engine”; state which precondition or invariant it challenges.
- [ ] **UC-M02.01-C016-T02 · Safe fixture boundary:** Define the contained test boundary for “Runtime dependency survey”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M02.01-C016-T03 · Valid control:** Construct a valid “Runtime dependency survey” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M02.01-C016-T04 · Minimal adverse input:** Derive the “Runtime dependency survey” adverse fixture from the control with the smallest documented change needed to reproduce “A hidden host system call remains in the engine”; retain that change as reproducible data.
- [ ] **UC-M02.01-C016-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Runtime dependency survey”; require “Every required host dependency has an approved guest replacement or explicit blocker” and forbid a false-success verdict.
- [ ] **UC-M02.01-C016-T06 · Adverse execution:** Exercise the “Runtime dependency survey” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M02.01-C016-T07 · Effect inspection:** Inspect “Runtime dependency survey” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M02.01-C016-T08 · Refusal versus failure:** Confirm the “Runtime dependency survey” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M02.01-C016-T09 · Reset and retention:** Restore only the disposable “Runtime dependency survey” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M02.01-C016-T10 · Negative regression:** Register the “Runtime dependency survey” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M02.01-C017 · Change / failure test

**Original checklist item:** Exercise runtime dependency survey when the selected library-OS configuration changes and a clean guest rebuild is required; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M02.01-C017-T01 · Scenario record:** Write the “Runtime dependency survey” change/failure scenario exactly as supplied: the selected library-OS configuration changes and a clean guest rebuild is required; identify the property that must remain true: “Every required host dependency has an approved guest replacement or explicit blocker”.
- [ ] **UC-M02.01-C017-T02 · Baseline capture:** Create a known-valid “Runtime dependency survey” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M02.01-C017-T03 · Injection map:** Locate the “Runtime dependency survey” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M02.01-C017-T04 · Disposition oracle:** Define the legal intermediate and final “Runtime dependency survey” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M02.01-C017-T05 · Controlled trigger:** Introduce the controlled “Runtime dependency survey” scenario in the disposable fixture: the selected library-OS configuration changes and a clean guest rebuild is required; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M02.01-C017-T06 · Intermediate inspection:** Inspect the “Runtime dependency survey” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M02.01-C017-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Runtime dependency survey”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M02.01-C017-T08 · Stale-evidence cleanup:** Invalidate superseded “Runtime dependency survey” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M02.01-C017-T09 · Repeat and compare:** Repeat the selected “Runtime dependency survey” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M02.01-C017-T10 · Failure evidence:** Publish the “Runtime dependency survey” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M02.01-C018 · Bounds

**Original checklist item:** Choose, document and test limits for imported symbol count and dependency closure size; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M02.01-C018-T01 · Quantity inventory:** Create a measurement inventory for “Runtime dependency survey”: “Imported symbol count and dependency closure size”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M02.01-C018-T02 · Measurement method:** Choose how to observe each “Runtime dependency survey” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M02.01-C018-T03 · Budget decision:** Select justified resource and input limits for “Runtime dependency survey”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M02.01-C018-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Runtime dependency survey” cases for “Imported symbol count and dependency closure size”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M02.01-C018-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Runtime dependency survey” limit; preserve “Every required host dependency has an approved guest replacement or explicit blocker”.
- [ ] **UC-M02.01-C018-T06 · Normal measurement:** Run or review the normal “Runtime dependency survey” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M02.01-C018-T07 · At-limit measurement:** Exercise the “Runtime dependency survey” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M02.01-C018-T08 · Over-limit measurement:** Exercise the “Runtime dependency survey” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M02.01-C018-T09 · Uncovered-scope report:** List the “Runtime dependency survey” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M02.01-C018-T10 · Limit evidence:** Publish the selected “Runtime dependency survey” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M02.01-C019 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for runtime dependency survey with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M02.01-C019-T01 · Event inventory:** List the “Runtime dependency survey” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M02.01-C019-T02 · Diagnostic schema:** Define nonsecret fields for “Runtime dependency survey” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M02.01-C019-T03 · Failure mapping:** Map each documented “Runtime dependency survey” refusal or error to a diagnostic outcome; include “A hidden host system call remains in the engine” and prohibit conversion into a success message.
- [ ] **UC-M02.01-C019-T04 · Emission path:** Add the “Runtime dependency survey” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M02.01-C019-T05 · Redaction check:** Test “Runtime dependency survey” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M02.01-C019-T06 · Output budget:** Set and exercise bounded “Runtime dependency survey” message size, rate and retention compatible with “Imported symbol count and dependency closure size”; define truncation behavior that preserves the final reason.
- [ ] **UC-M02.01-C019-T07 · Success/refusal fixtures:** Capture “Runtime dependency survey” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M02.01-C019-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Runtime dependency survey” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M02.01-C019-T09 · Operator review:** Read the “Runtime dependency survey” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M02.01-C019-T10 · Diagnostic evidence:** Publish redacted “Runtime dependency survey” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M02.01-C020 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for runtime dependency survey; label unexecuted checks as untested.

- [ ] **UC-M02.01-C020-T01 · Evidence inventory:** List the “Runtime dependency survey” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M02.01-C020-T02 · Artifact references:** Record the exact “Runtime dependency survey” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M02.01-C020-T03 · Fixture references:** Attach the “Runtime dependency survey” fixture IDs, input identities and oracle definition; preserve the source counterexample “A hidden host system call remains in the engine” as a distinct evidence case.
- [ ] **UC-M02.01-C020-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Runtime dependency survey”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M02.01-C020-T05 · Environment record:** Record the actual “Runtime dependency survey” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M02.01-C020-T06 · Expected versus observed:** Pair every “Runtime dependency survey” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M02.01-C020-T07 · Failure and limit records:** Attach “Runtime dependency survey” change/failure and bounds evidence where required; include uncovered “Imported symbol count and dependency closure size” and unresolved violations of “Every required host dependency has an approved guest replacement or explicit blocker”.
- [ ] **UC-M02.01-C020-T08 · Evidence hygiene:** Check the “Runtime dependency survey” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M02.01-C020-T09 · Reproduction review:** Have the “Runtime dependency survey” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M02.01-C020-T10 · Acceptance linkage:** Link the “Runtime dependency survey” evidence to its parent and UC-M02.01 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 03. Minimal application selection

**Source delivery:** Choose one small nontrivial application with observable input and output.

**Source invariant:** A no-op boot alone does not qualify the application integration.

**Source negative case:** The guest emits ready but never executes the selected workload.

**Source bounded quantities:** Application input size and expected execution budget.

### UC-M02.01-C021 · Contract

**Original checklist item:** Specify minimal application selection inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M02.01-C021-T01 · Scope statement:** Draft the operation boundary for “Minimal application selection” within Chosen library-OS integration; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M02.01-C021-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Minimal application selection”; record each producer, representation and missing-value meaning.
- [ ] **UC-M02.01-C021-T03 · Output inventory:** List the outputs of “Minimal application selection” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M02.01-C021-T04 · Field dictionary:** Create a field-and-term dictionary for “Minimal application selection”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M02.01-C021-T05 · Prerequisite contract:** Map “Minimal application selection” to the source component prerequisites (UC-M01.07); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M02.01-C021-T06 · Authority map:** Identify who may produce, change and consume “Minimal application selection”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M02.01-C021-T07 · Invariant clause:** Add a normative clause for “Minimal application selection” that preserves “A no-op boot alone does not qualify the application integration”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M02.01-C021-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Minimal application selection”; include the source counterexample “The guest emits ready but never executes the selected workload” and the intended safe disposition.
- [ ] **UC-M02.01-C021-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Application input size and expected execution budget” in the “Minimal application selection” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M02.01-C021-T10 · Contract review:** Review the “Minimal application selection” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M02.01-C022 · Delivery

**Original checklist item:** Choose one small nontrivial application with observable input and output.

- [ ] **UC-M02.01-C022-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Minimal application selection”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M02.01-C022-T02 · Change plan:** Break the source delivery for “Minimal application selection” into concrete edit targets and reviewable outputs; keep the UC-M02.01 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M02.01-C022-T03 · Core artifact:** Prepare the “Minimal application selection” decision record for this source instruction: Choose one small nontrivial application with observable input and output.
- [ ] **UC-M02.01-C022-T04 · Concrete realization:** Evaluate the “Minimal application selection” choice against its declared constraints; record the exact selected target/configuration and rejected alternatives, leaving unverified compatibility as a blocker.
- [ ] **UC-M02.01-C022-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Minimal application selection” needed to preserve “A no-op boot alone does not qualify the application integration”; record an enforcement gap where only a model exists.
- [ ] **UC-M02.01-C022-T06 · Dependency connection:** Connect the “Minimal application selection” implementation to the selected engine portability layer, library OS and image build recipe; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M02.01-C022-T07 · Resource behavior:** Account for “Application input size and expected execution budget” in “Minimal application selection”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M02.01-C022-T08 · Delivery check:** Run the smallest real “Minimal application selection” path and its adverse fixture “The guest emits ready but never executes the selected workload”; retain actual output, state effects and final disposition.
- [ ] **UC-M02.01-C022-T09 · Patch review:** Review the “Minimal application selection” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M02.01-C022-T10 · Delivery handoff:** Publish the “Minimal application selection” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M02.01-C023 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: A no-op boot alone does not qualify the application integration. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M02.01-C023-T01 · Named property:** Create a stable property/check name under this parent for “Minimal application selection”; copy its required invariant exactly: “A no-op boot alone does not qualify the application integration”.
- [ ] **UC-M02.01-C023-T02 · Observable terms:** Define each term in the “Minimal application selection” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M02.01-C023-T03 · Precondition set:** List the preconditions under which “A no-op boot alone does not qualify the application integration” must hold for “Minimal application selection”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M02.01-C023-T04 · Transition coverage:** Map the “Minimal application selection” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M02.01-C023-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Minimal application selection”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M02.01-C023-T06 · Satisfying fixture:** Create a concrete “Minimal application selection” case that satisfies “A no-op boot alone does not qualify the application integration”; record its expected observation before running the assertion or review.
- [ ] **UC-M02.01-C023-T07 · Violating fixture:** Create the source counterexample “The guest emits ready but never executes the selected workload” for “Minimal application selection”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M02.01-C023-T08 · Enforcement evidence:** Exercise the “Minimal application selection” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M02.01-C023-T09 · Regression linkage:** Link the “Minimal application selection” property to changes in the selected engine portability layer, library OS and image build recipe; record which dependency or contract changes require rerunning it.
- [ ] **UC-M02.01-C023-T10 · Property disposition:** Compare the satisfying and violating “Minimal application selection” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M02.01-C024 · Integration

**Original checklist item:** Integrate minimal application selection with the selected engine portability layer, library OS and image build recipe; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M02.01-C024-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Minimal application selection” across the selected engine portability layer, library OS and image build recipe; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M02.01-C024-T02 · Field mapping:** Map every “Minimal application selection” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M02.01-C024-T03 · Prerequisite identities:** Record the actual prerequisites for “Minimal application selection” (source dependency list: UC-M01.07); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M02.01-C024-T04 · Ownership agreement:** Specify who owns “Minimal application selection” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M02.01-C024-T05 · Handoff implementation:** Connect “Minimal application selection” through the mapped seam using the real adapter or explicit specification reference; preserve “A no-op boot alone does not qualify the application integration” across the handoff.
- [ ] **UC-M02.01-C024-T06 · Absent-input case:** Omit one required “Minimal application selection” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M02.01-C024-T07 · Stale-input case:** Supply an outdated “Minimal application selection” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M02.01-C024-T08 · Incompatible-input case:** Supply an incompatible “Minimal application selection” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M02.01-C024-T09 · Valid integration trace:** Run a valid “Minimal application selection” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M02.01-C024-T10 · Seam review:** Reconcile the “Minimal application selection” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M02.01-C025 · Valid-case test

**Original checklist item:** Run a valid-path fixture for minimal application selection; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M02.01-C025-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Minimal application selection” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M02.01-C025-T02 · Expected-result oracle:** Specify the “Minimal application selection” expected result independently of the implementation output; include the property “A no-op boot alone does not qualify the application integration” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M02.01-C025-T03 · Fixture material:** Create the concrete “Minimal application selection” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M02.01-C025-T04 · Target preparation:** Prepare the “Minimal application selection” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M02.01-C025-T05 · Initial-state record:** Record the initial “Minimal application selection” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M02.01-C025-T06 · Valid-path execution:** Execute the “Minimal application selection” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M02.01-C025-T07 · Outcome comparison:** Compare every declared “Minimal application selection” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M02.01-C025-T08 · State and bounds check:** Inspect the “Minimal application selection” ownership/state effects and actual use of “Application input size and expected execution budget”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M02.01-C025-T09 · Repeatability check:** Repeat the same “Minimal application selection” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M02.01-C025-T10 · Positive evidence:** Attach the “Minimal application selection” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M02.01-C026 · Negative test

**Original checklist item:** Negative case: The guest emits ready but never executes the selected workload. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M02.01-C026-T01 · Adverse-case definition:** Create a test record for the exact “Minimal application selection” source counterexample: “The guest emits ready but never executes the selected workload”; state which precondition or invariant it challenges.
- [ ] **UC-M02.01-C026-T02 · Safe fixture boundary:** Define the contained test boundary for “Minimal application selection”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M02.01-C026-T03 · Valid control:** Construct a valid “Minimal application selection” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M02.01-C026-T04 · Minimal adverse input:** Derive the “Minimal application selection” adverse fixture from the control with the smallest documented change needed to reproduce “The guest emits ready but never executes the selected workload”; retain that change as reproducible data.
- [ ] **UC-M02.01-C026-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Minimal application selection”; require “A no-op boot alone does not qualify the application integration” and forbid a false-success verdict.
- [ ] **UC-M02.01-C026-T06 · Adverse execution:** Exercise the “Minimal application selection” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M02.01-C026-T07 · Effect inspection:** Inspect “Minimal application selection” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M02.01-C026-T08 · Refusal versus failure:** Confirm the “Minimal application selection” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M02.01-C026-T09 · Reset and retention:** Restore only the disposable “Minimal application selection” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M02.01-C026-T10 · Negative regression:** Register the “Minimal application selection” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M02.01-C027 · Change / failure test

**Original checklist item:** Exercise minimal application selection when the selected library-OS configuration changes and a clean guest rebuild is required; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M02.01-C027-T01 · Scenario record:** Write the “Minimal application selection” change/failure scenario exactly as supplied: the selected library-OS configuration changes and a clean guest rebuild is required; identify the property that must remain true: “A no-op boot alone does not qualify the application integration”.
- [ ] **UC-M02.01-C027-T02 · Baseline capture:** Create a known-valid “Minimal application selection” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M02.01-C027-T03 · Injection map:** Locate the “Minimal application selection” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M02.01-C027-T04 · Disposition oracle:** Define the legal intermediate and final “Minimal application selection” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M02.01-C027-T05 · Controlled trigger:** Introduce the controlled “Minimal application selection” scenario in the disposable fixture: the selected library-OS configuration changes and a clean guest rebuild is required; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M02.01-C027-T06 · Intermediate inspection:** Inspect the “Minimal application selection” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M02.01-C027-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Minimal application selection”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M02.01-C027-T08 · Stale-evidence cleanup:** Invalidate superseded “Minimal application selection” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M02.01-C027-T09 · Repeat and compare:** Repeat the selected “Minimal application selection” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M02.01-C027-T10 · Failure evidence:** Publish the “Minimal application selection” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M02.01-C028 · Bounds

**Original checklist item:** Choose, document and test limits for application input size and expected execution budget; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M02.01-C028-T01 · Quantity inventory:** Create a measurement inventory for “Minimal application selection”: “Application input size and expected execution budget”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M02.01-C028-T02 · Measurement method:** Choose how to observe each “Minimal application selection” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M02.01-C028-T03 · Budget decision:** Select justified resource and input limits for “Minimal application selection”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M02.01-C028-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Minimal application selection” cases for “Application input size and expected execution budget”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M02.01-C028-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Minimal application selection” limit; preserve “A no-op boot alone does not qualify the application integration”.
- [ ] **UC-M02.01-C028-T06 · Normal measurement:** Run or review the normal “Minimal application selection” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M02.01-C028-T07 · At-limit measurement:** Exercise the “Minimal application selection” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M02.01-C028-T08 · Over-limit measurement:** Exercise the “Minimal application selection” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M02.01-C028-T09 · Uncovered-scope report:** List the “Minimal application selection” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M02.01-C028-T10 · Limit evidence:** Publish the selected “Minimal application selection” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M02.01-C029 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for minimal application selection with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M02.01-C029-T01 · Event inventory:** List the “Minimal application selection” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M02.01-C029-T02 · Diagnostic schema:** Define nonsecret fields for “Minimal application selection” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M02.01-C029-T03 · Failure mapping:** Map each documented “Minimal application selection” refusal or error to a diagnostic outcome; include “The guest emits ready but never executes the selected workload” and prohibit conversion into a success message.
- [ ] **UC-M02.01-C029-T04 · Emission path:** Add the “Minimal application selection” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M02.01-C029-T05 · Redaction check:** Test “Minimal application selection” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M02.01-C029-T06 · Output budget:** Set and exercise bounded “Minimal application selection” message size, rate and retention compatible with “Application input size and expected execution budget”; define truncation behavior that preserves the final reason.
- [ ] **UC-M02.01-C029-T07 · Success/refusal fixtures:** Capture “Minimal application selection” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M02.01-C029-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Minimal application selection” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M02.01-C029-T09 · Operator review:** Read the “Minimal application selection” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M02.01-C029-T10 · Diagnostic evidence:** Publish redacted “Minimal application selection” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M02.01-C030 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for minimal application selection; label unexecuted checks as untested.

- [ ] **UC-M02.01-C030-T01 · Evidence inventory:** List the “Minimal application selection” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M02.01-C030-T02 · Artifact references:** Record the exact “Minimal application selection” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M02.01-C030-T03 · Fixture references:** Attach the “Minimal application selection” fixture IDs, input identities and oracle definition; preserve the source counterexample “The guest emits ready but never executes the selected workload” as a distinct evidence case.
- [ ] **UC-M02.01-C030-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Minimal application selection”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M02.01-C030-T05 · Environment record:** Record the actual “Minimal application selection” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M02.01-C030-T06 · Expected versus observed:** Pair every “Minimal application selection” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M02.01-C030-T07 · Failure and limit records:** Attach “Minimal application selection” change/failure and bounds evidence where required; include uncovered “Application input size and expected execution budget” and unresolved violations of “A no-op boot alone does not qualify the application integration”.
- [ ] **UC-M02.01-C030-T08 · Evidence hygiene:** Check the “Minimal application selection” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M02.01-C030-T09 · Reproduction review:** Have the “Minimal application selection” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M02.01-C030-T10 · Acceptance linkage:** Link the “Minimal application selection” evidence to its parent and UC-M02.01 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 04. Library selection

**Source delivery:** Link only the operating-system libraries required by the chosen application and platform.

**Source invariant:** Unused functionality is not enabled without a documented dependency.

**Source negative case:** An unused network stack is pulled into the offline profile.

**Source bounded quantities:** Linked library count and resulting image footprint.

### UC-M02.01-C031 · Contract

**Original checklist item:** Specify library selection inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M02.01-C031-T01 · Scope statement:** Draft the operation boundary for “Library selection” within Chosen library-OS integration; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M02.01-C031-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Library selection”; record each producer, representation and missing-value meaning.
- [ ] **UC-M02.01-C031-T03 · Output inventory:** List the outputs of “Library selection” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M02.01-C031-T04 · Field dictionary:** Create a field-and-term dictionary for “Library selection”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M02.01-C031-T05 · Prerequisite contract:** Map “Library selection” to the source component prerequisites (UC-M01.07); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M02.01-C031-T06 · Authority map:** Identify who may produce, change and consume “Library selection”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M02.01-C031-T07 · Invariant clause:** Add a normative clause for “Library selection” that preserves “Unused functionality is not enabled without a documented dependency”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M02.01-C031-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Library selection”; include the source counterexample “An unused network stack is pulled into the offline profile” and the intended safe disposition.
- [ ] **UC-M02.01-C031-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Linked library count and resulting image footprint” in the “Library selection” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M02.01-C031-T10 · Contract review:** Review the “Library selection” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M02.01-C032 · Delivery

**Original checklist item:** Link only the operating-system libraries required by the chosen application and platform.

- [ ] **UC-M02.01-C032-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Library selection”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M02.01-C032-T02 · Change plan:** Break the source delivery for “Library selection” into concrete edit targets and reviewable outputs; keep the UC-M02.01 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M02.01-C032-T03 · Core artifact:** Implement the smallest selected-profile change for “Library selection” that realizes this source instruction: Link only the operating-system libraries required by the chosen application and platform.
- [ ] **UC-M02.01-C032-T04 · Concrete realization:** Trace “Library selection” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M02.01-C032-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Library selection” needed to preserve “Unused functionality is not enabled without a documented dependency”; record an enforcement gap where only a model exists.
- [ ] **UC-M02.01-C032-T06 · Dependency connection:** Connect the “Library selection” implementation to the selected engine portability layer, library OS and image build recipe; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M02.01-C032-T07 · Resource behavior:** Account for “Linked library count and resulting image footprint” in “Library selection”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M02.01-C032-T08 · Delivery check:** Run the smallest real “Library selection” path and its adverse fixture “An unused network stack is pulled into the offline profile”; retain actual output, state effects and final disposition.
- [ ] **UC-M02.01-C032-T09 · Patch review:** Review the “Library selection” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M02.01-C032-T10 · Delivery handoff:** Publish the “Library selection” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M02.01-C033 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Unused functionality is not enabled without a documented dependency. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M02.01-C033-T01 · Named property:** Create a stable property/check name under this parent for “Library selection”; copy its required invariant exactly: “Unused functionality is not enabled without a documented dependency”.
- [ ] **UC-M02.01-C033-T02 · Observable terms:** Define each term in the “Library selection” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M02.01-C033-T03 · Precondition set:** List the preconditions under which “Unused functionality is not enabled without a documented dependency” must hold for “Library selection”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M02.01-C033-T04 · Transition coverage:** Map the “Library selection” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M02.01-C033-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Library selection”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M02.01-C033-T06 · Satisfying fixture:** Create a concrete “Library selection” case that satisfies “Unused functionality is not enabled without a documented dependency”; record its expected observation before running the assertion or review.
- [ ] **UC-M02.01-C033-T07 · Violating fixture:** Create the source counterexample “An unused network stack is pulled into the offline profile” for “Library selection”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M02.01-C033-T08 · Enforcement evidence:** Exercise the “Library selection” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M02.01-C033-T09 · Regression linkage:** Link the “Library selection” property to changes in the selected engine portability layer, library OS and image build recipe; record which dependency or contract changes require rerunning it.
- [ ] **UC-M02.01-C033-T10 · Property disposition:** Compare the satisfying and violating “Library selection” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M02.01-C034 · Integration

**Original checklist item:** Integrate library selection with the selected engine portability layer, library OS and image build recipe; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M02.01-C034-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Library selection” across the selected engine portability layer, library OS and image build recipe; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M02.01-C034-T02 · Field mapping:** Map every “Library selection” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M02.01-C034-T03 · Prerequisite identities:** Record the actual prerequisites for “Library selection” (source dependency list: UC-M01.07); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M02.01-C034-T04 · Ownership agreement:** Specify who owns “Library selection” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M02.01-C034-T05 · Handoff implementation:** Connect “Library selection” through the mapped seam using the real adapter or explicit specification reference; preserve “Unused functionality is not enabled without a documented dependency” across the handoff.
- [ ] **UC-M02.01-C034-T06 · Absent-input case:** Omit one required “Library selection” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M02.01-C034-T07 · Stale-input case:** Supply an outdated “Library selection” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M02.01-C034-T08 · Incompatible-input case:** Supply an incompatible “Library selection” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M02.01-C034-T09 · Valid integration trace:** Run a valid “Library selection” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M02.01-C034-T10 · Seam review:** Reconcile the “Library selection” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M02.01-C035 · Valid-case test

**Original checklist item:** Run a valid-path fixture for library selection; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M02.01-C035-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Library selection” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M02.01-C035-T02 · Expected-result oracle:** Specify the “Library selection” expected result independently of the implementation output; include the property “Unused functionality is not enabled without a documented dependency” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M02.01-C035-T03 · Fixture material:** Create the concrete “Library selection” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M02.01-C035-T04 · Target preparation:** Prepare the “Library selection” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M02.01-C035-T05 · Initial-state record:** Record the initial “Library selection” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M02.01-C035-T06 · Valid-path execution:** Execute the “Library selection” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M02.01-C035-T07 · Outcome comparison:** Compare every declared “Library selection” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M02.01-C035-T08 · State and bounds check:** Inspect the “Library selection” ownership/state effects and actual use of “Linked library count and resulting image footprint”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M02.01-C035-T09 · Repeatability check:** Repeat the same “Library selection” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M02.01-C035-T10 · Positive evidence:** Attach the “Library selection” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M02.01-C036 · Negative test

**Original checklist item:** Negative case: An unused network stack is pulled into the offline profile. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M02.01-C036-T01 · Adverse-case definition:** Create a test record for the exact “Library selection” source counterexample: “An unused network stack is pulled into the offline profile”; state which precondition or invariant it challenges.
- [ ] **UC-M02.01-C036-T02 · Safe fixture boundary:** Define the contained test boundary for “Library selection”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M02.01-C036-T03 · Valid control:** Construct a valid “Library selection” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M02.01-C036-T04 · Minimal adverse input:** Derive the “Library selection” adverse fixture from the control with the smallest documented change needed to reproduce “An unused network stack is pulled into the offline profile”; retain that change as reproducible data.
- [ ] **UC-M02.01-C036-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Library selection”; require “Unused functionality is not enabled without a documented dependency” and forbid a false-success verdict.
- [ ] **UC-M02.01-C036-T06 · Adverse execution:** Exercise the “Library selection” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M02.01-C036-T07 · Effect inspection:** Inspect “Library selection” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M02.01-C036-T08 · Refusal versus failure:** Confirm the “Library selection” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M02.01-C036-T09 · Reset and retention:** Restore only the disposable “Library selection” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M02.01-C036-T10 · Negative regression:** Register the “Library selection” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M02.01-C037 · Change / failure test

**Original checklist item:** Exercise library selection when the selected library-OS configuration changes and a clean guest rebuild is required; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M02.01-C037-T01 · Scenario record:** Write the “Library selection” change/failure scenario exactly as supplied: the selected library-OS configuration changes and a clean guest rebuild is required; identify the property that must remain true: “Unused functionality is not enabled without a documented dependency”.
- [ ] **UC-M02.01-C037-T02 · Baseline capture:** Create a known-valid “Library selection” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M02.01-C037-T03 · Injection map:** Locate the “Library selection” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M02.01-C037-T04 · Disposition oracle:** Define the legal intermediate and final “Library selection” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M02.01-C037-T05 · Controlled trigger:** Introduce the controlled “Library selection” scenario in the disposable fixture: the selected library-OS configuration changes and a clean guest rebuild is required; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M02.01-C037-T06 · Intermediate inspection:** Inspect the “Library selection” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M02.01-C037-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Library selection”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M02.01-C037-T08 · Stale-evidence cleanup:** Invalidate superseded “Library selection” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M02.01-C037-T09 · Repeat and compare:** Repeat the selected “Library selection” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M02.01-C037-T10 · Failure evidence:** Publish the “Library selection” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M02.01-C038 · Bounds

**Original checklist item:** Choose, document and test limits for linked library count and resulting image footprint; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M02.01-C038-T01 · Quantity inventory:** Create a measurement inventory for “Library selection”: “Linked library count and resulting image footprint”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M02.01-C038-T02 · Measurement method:** Choose how to observe each “Library selection” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M02.01-C038-T03 · Budget decision:** Select justified resource and input limits for “Library selection”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M02.01-C038-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Library selection” cases for “Linked library count and resulting image footprint”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M02.01-C038-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Library selection” limit; preserve “Unused functionality is not enabled without a documented dependency”.
- [ ] **UC-M02.01-C038-T06 · Normal measurement:** Run or review the normal “Library selection” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M02.01-C038-T07 · At-limit measurement:** Exercise the “Library selection” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M02.01-C038-T08 · Over-limit measurement:** Exercise the “Library selection” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M02.01-C038-T09 · Uncovered-scope report:** List the “Library selection” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M02.01-C038-T10 · Limit evidence:** Publish the selected “Library selection” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M02.01-C039 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for library selection with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M02.01-C039-T01 · Event inventory:** List the “Library selection” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M02.01-C039-T02 · Diagnostic schema:** Define nonsecret fields for “Library selection” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M02.01-C039-T03 · Failure mapping:** Map each documented “Library selection” refusal or error to a diagnostic outcome; include “An unused network stack is pulled into the offline profile” and prohibit conversion into a success message.
- [ ] **UC-M02.01-C039-T04 · Emission path:** Add the “Library selection” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M02.01-C039-T05 · Redaction check:** Test “Library selection” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M02.01-C039-T06 · Output budget:** Set and exercise bounded “Library selection” message size, rate and retention compatible with “Linked library count and resulting image footprint”; define truncation behavior that preserves the final reason.
- [ ] **UC-M02.01-C039-T07 · Success/refusal fixtures:** Capture “Library selection” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M02.01-C039-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Library selection” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M02.01-C039-T09 · Operator review:** Read the “Library selection” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M02.01-C039-T10 · Diagnostic evidence:** Publish redacted “Library selection” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M02.01-C040 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for library selection; label unexecuted checks as untested.

- [ ] **UC-M02.01-C040-T01 · Evidence inventory:** List the “Library selection” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M02.01-C040-T02 · Artifact references:** Record the exact “Library selection” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M02.01-C040-T03 · Fixture references:** Attach the “Library selection” fixture IDs, input identities and oracle definition; preserve the source counterexample “An unused network stack is pulled into the offline profile” as a distinct evidence case.
- [ ] **UC-M02.01-C040-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Library selection”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M02.01-C040-T05 · Environment record:** Record the actual “Library selection” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M02.01-C040-T06 · Expected versus observed:** Pair every “Library selection” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M02.01-C040-T07 · Failure and limit records:** Attach “Library selection” change/failure and bounds evidence where required; include uncovered “Linked library count and resulting image footprint” and unresolved violations of “Unused functionality is not enabled without a documented dependency”.
- [ ] **UC-M02.01-C040-T08 · Evidence hygiene:** Check the “Library selection” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M02.01-C040-T09 · Reproduction review:** Have the “Library selection” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M02.01-C040-T10 · Acceptance linkage:** Link the “Library selection” evidence to its parent and UC-M02.01 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 05. Engine portability layer

**Source delivery:** Implement narrow guest-compatible wrappers for required engine services.

**Source invariant:** Guest execution does not invoke a host Python command as its substitute.

**Source negative case:** A portability wrapper shells out to the management process.

**Source bounded quantities:** Wrapper count and guest service-call volume.

### UC-M02.01-C041 · Contract

**Original checklist item:** Specify engine portability layer inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M02.01-C041-T01 · Scope statement:** Draft the operation boundary for “Engine portability layer” within Chosen library-OS integration; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M02.01-C041-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Engine portability layer”; record each producer, representation and missing-value meaning.
- [ ] **UC-M02.01-C041-T03 · Output inventory:** List the outputs of “Engine portability layer” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M02.01-C041-T04 · Field dictionary:** Create a field-and-term dictionary for “Engine portability layer”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M02.01-C041-T05 · Prerequisite contract:** Map “Engine portability layer” to the source component prerequisites (UC-M01.07); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M02.01-C041-T06 · Authority map:** Identify who may produce, change and consume “Engine portability layer”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M02.01-C041-T07 · Invariant clause:** Add a normative clause for “Engine portability layer” that preserves “Guest execution does not invoke a host Python command as its substitute”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M02.01-C041-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Engine portability layer”; include the source counterexample “A portability wrapper shells out to the management process” and the intended safe disposition.
- [ ] **UC-M02.01-C041-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Wrapper count and guest service-call volume” in the “Engine portability layer” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M02.01-C041-T10 · Contract review:** Review the “Engine portability layer” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M02.01-C042 · Delivery

**Original checklist item:** Implement narrow guest-compatible wrappers for required engine services.

- [ ] **UC-M02.01-C042-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Engine portability layer”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M02.01-C042-T02 · Change plan:** Break the source delivery for “Engine portability layer” into concrete edit targets and reviewable outputs; keep the UC-M02.01 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M02.01-C042-T03 · Core artifact:** Implement the smallest selected-profile change for “Engine portability layer” that realizes this source instruction: Implement narrow guest-compatible wrappers for required engine services.
- [ ] **UC-M02.01-C042-T04 · Concrete realization:** Trace “Engine portability layer” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M02.01-C042-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Engine portability layer” needed to preserve “Guest execution does not invoke a host Python command as its substitute”; record an enforcement gap where only a model exists.
- [ ] **UC-M02.01-C042-T06 · Dependency connection:** Connect the “Engine portability layer” implementation to the selected engine portability layer, library OS and image build recipe; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M02.01-C042-T07 · Resource behavior:** Account for “Wrapper count and guest service-call volume” in “Engine portability layer”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M02.01-C042-T08 · Delivery check:** Run the smallest real “Engine portability layer” path and its adverse fixture “A portability wrapper shells out to the management process”; retain actual output, state effects and final disposition.
- [ ] **UC-M02.01-C042-T09 · Patch review:** Review the “Engine portability layer” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M02.01-C042-T10 · Delivery handoff:** Publish the “Engine portability layer” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M02.01-C043 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Guest execution does not invoke a host Python command as its substitute. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M02.01-C043-T01 · Named property:** Create a stable property/check name under this parent for “Engine portability layer”; copy its required invariant exactly: “Guest execution does not invoke a host Python command as its substitute”.
- [ ] **UC-M02.01-C043-T02 · Observable terms:** Define each term in the “Engine portability layer” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M02.01-C043-T03 · Precondition set:** List the preconditions under which “Guest execution does not invoke a host Python command as its substitute” must hold for “Engine portability layer”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M02.01-C043-T04 · Transition coverage:** Map the “Engine portability layer” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M02.01-C043-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Engine portability layer”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M02.01-C043-T06 · Satisfying fixture:** Create a concrete “Engine portability layer” case that satisfies “Guest execution does not invoke a host Python command as its substitute”; record its expected observation before running the assertion or review.
- [ ] **UC-M02.01-C043-T07 · Violating fixture:** Create the source counterexample “A portability wrapper shells out to the management process” for “Engine portability layer”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M02.01-C043-T08 · Enforcement evidence:** Exercise the “Engine portability layer” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M02.01-C043-T09 · Regression linkage:** Link the “Engine portability layer” property to changes in the selected engine portability layer, library OS and image build recipe; record which dependency or contract changes require rerunning it.
- [ ] **UC-M02.01-C043-T10 · Property disposition:** Compare the satisfying and violating “Engine portability layer” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M02.01-C044 · Integration

**Original checklist item:** Integrate engine portability layer with the selected engine portability layer, library OS and image build recipe; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M02.01-C044-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Engine portability layer” across the selected engine portability layer, library OS and image build recipe; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M02.01-C044-T02 · Field mapping:** Map every “Engine portability layer” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M02.01-C044-T03 · Prerequisite identities:** Record the actual prerequisites for “Engine portability layer” (source dependency list: UC-M01.07); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M02.01-C044-T04 · Ownership agreement:** Specify who owns “Engine portability layer” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M02.01-C044-T05 · Handoff implementation:** Connect “Engine portability layer” through the mapped seam using the real adapter or explicit specification reference; preserve “Guest execution does not invoke a host Python command as its substitute” across the handoff.
- [ ] **UC-M02.01-C044-T06 · Absent-input case:** Omit one required “Engine portability layer” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M02.01-C044-T07 · Stale-input case:** Supply an outdated “Engine portability layer” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M02.01-C044-T08 · Incompatible-input case:** Supply an incompatible “Engine portability layer” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M02.01-C044-T09 · Valid integration trace:** Run a valid “Engine portability layer” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M02.01-C044-T10 · Seam review:** Reconcile the “Engine portability layer” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M02.01-C045 · Valid-case test

**Original checklist item:** Run a valid-path fixture for engine portability layer; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M02.01-C045-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Engine portability layer” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M02.01-C045-T02 · Expected-result oracle:** Specify the “Engine portability layer” expected result independently of the implementation output; include the property “Guest execution does not invoke a host Python command as its substitute” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M02.01-C045-T03 · Fixture material:** Create the concrete “Engine portability layer” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M02.01-C045-T04 · Target preparation:** Prepare the “Engine portability layer” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M02.01-C045-T05 · Initial-state record:** Record the initial “Engine portability layer” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M02.01-C045-T06 · Valid-path execution:** Execute the “Engine portability layer” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M02.01-C045-T07 · Outcome comparison:** Compare every declared “Engine portability layer” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M02.01-C045-T08 · State and bounds check:** Inspect the “Engine portability layer” ownership/state effects and actual use of “Wrapper count and guest service-call volume”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M02.01-C045-T09 · Repeatability check:** Repeat the same “Engine portability layer” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M02.01-C045-T10 · Positive evidence:** Attach the “Engine portability layer” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M02.01-C046 · Negative test

**Original checklist item:** Negative case: A portability wrapper shells out to the management process. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M02.01-C046-T01 · Adverse-case definition:** Create a test record for the exact “Engine portability layer” source counterexample: “A portability wrapper shells out to the management process”; state which precondition or invariant it challenges.
- [ ] **UC-M02.01-C046-T02 · Safe fixture boundary:** Define the contained test boundary for “Engine portability layer”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M02.01-C046-T03 · Valid control:** Construct a valid “Engine portability layer” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M02.01-C046-T04 · Minimal adverse input:** Derive the “Engine portability layer” adverse fixture from the control with the smallest documented change needed to reproduce “A portability wrapper shells out to the management process”; retain that change as reproducible data.
- [ ] **UC-M02.01-C046-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Engine portability layer”; require “Guest execution does not invoke a host Python command as its substitute” and forbid a false-success verdict.
- [ ] **UC-M02.01-C046-T06 · Adverse execution:** Exercise the “Engine portability layer” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M02.01-C046-T07 · Effect inspection:** Inspect “Engine portability layer” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M02.01-C046-T08 · Refusal versus failure:** Confirm the “Engine portability layer” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M02.01-C046-T09 · Reset and retention:** Restore only the disposable “Engine portability layer” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M02.01-C046-T10 · Negative regression:** Register the “Engine portability layer” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M02.01-C047 · Change / failure test

**Original checklist item:** Exercise engine portability layer when the selected library-OS configuration changes and a clean guest rebuild is required; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M02.01-C047-T01 · Scenario record:** Write the “Engine portability layer” change/failure scenario exactly as supplied: the selected library-OS configuration changes and a clean guest rebuild is required; identify the property that must remain true: “Guest execution does not invoke a host Python command as its substitute”.
- [ ] **UC-M02.01-C047-T02 · Baseline capture:** Create a known-valid “Engine portability layer” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M02.01-C047-T03 · Injection map:** Locate the “Engine portability layer” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M02.01-C047-T04 · Disposition oracle:** Define the legal intermediate and final “Engine portability layer” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M02.01-C047-T05 · Controlled trigger:** Introduce the controlled “Engine portability layer” scenario in the disposable fixture: the selected library-OS configuration changes and a clean guest rebuild is required; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M02.01-C047-T06 · Intermediate inspection:** Inspect the “Engine portability layer” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M02.01-C047-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Engine portability layer”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M02.01-C047-T08 · Stale-evidence cleanup:** Invalidate superseded “Engine portability layer” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M02.01-C047-T09 · Repeat and compare:** Repeat the selected “Engine portability layer” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M02.01-C047-T10 · Failure evidence:** Publish the “Engine portability layer” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M02.01-C048 · Bounds

**Original checklist item:** Choose, document and test limits for wrapper count and guest service-call volume; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M02.01-C048-T01 · Quantity inventory:** Create a measurement inventory for “Engine portability layer”: “Wrapper count and guest service-call volume”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M02.01-C048-T02 · Measurement method:** Choose how to observe each “Engine portability layer” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M02.01-C048-T03 · Budget decision:** Select justified resource and input limits for “Engine portability layer”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M02.01-C048-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Engine portability layer” cases for “Wrapper count and guest service-call volume”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M02.01-C048-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Engine portability layer” limit; preserve “Guest execution does not invoke a host Python command as its substitute”.
- [ ] **UC-M02.01-C048-T06 · Normal measurement:** Run or review the normal “Engine portability layer” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M02.01-C048-T07 · At-limit measurement:** Exercise the “Engine portability layer” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M02.01-C048-T08 · Over-limit measurement:** Exercise the “Engine portability layer” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M02.01-C048-T09 · Uncovered-scope report:** List the “Engine portability layer” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M02.01-C048-T10 · Limit evidence:** Publish the selected “Engine portability layer” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M02.01-C049 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for engine portability layer with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M02.01-C049-T01 · Event inventory:** List the “Engine portability layer” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M02.01-C049-T02 · Diagnostic schema:** Define nonsecret fields for “Engine portability layer” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M02.01-C049-T03 · Failure mapping:** Map each documented “Engine portability layer” refusal or error to a diagnostic outcome; include “A portability wrapper shells out to the management process” and prohibit conversion into a success message.
- [ ] **UC-M02.01-C049-T04 · Emission path:** Add the “Engine portability layer” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M02.01-C049-T05 · Redaction check:** Test “Engine portability layer” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M02.01-C049-T06 · Output budget:** Set and exercise bounded “Engine portability layer” message size, rate and retention compatible with “Wrapper count and guest service-call volume”; define truncation behavior that preserves the final reason.
- [ ] **UC-M02.01-C049-T07 · Success/refusal fixtures:** Capture “Engine portability layer” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M02.01-C049-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Engine portability layer” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M02.01-C049-T09 · Operator review:** Read the “Engine portability layer” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M02.01-C049-T10 · Diagnostic evidence:** Publish redacted “Engine portability layer” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M02.01-C050 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for engine portability layer; label unexecuted checks as untested.

- [ ] **UC-M02.01-C050-T01 · Evidence inventory:** List the “Engine portability layer” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M02.01-C050-T02 · Artifact references:** Record the exact “Engine portability layer” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M02.01-C050-T03 · Fixture references:** Attach the “Engine portability layer” fixture IDs, input identities and oracle definition; preserve the source counterexample “A portability wrapper shells out to the management process” as a distinct evidence case.
- [ ] **UC-M02.01-C050-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Engine portability layer”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M02.01-C050-T05 · Environment record:** Record the actual “Engine portability layer” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M02.01-C050-T06 · Expected versus observed:** Pair every “Engine portability layer” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M02.01-C050-T07 · Failure and limit records:** Attach “Engine portability layer” change/failure and bounds evidence where required; include uncovered “Wrapper count and guest service-call volume” and unresolved violations of “Guest execution does not invoke a host Python command as its substitute”.
- [ ] **UC-M02.01-C050-T08 · Evidence hygiene:** Check the “Engine portability layer” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M02.01-C050-T09 · Reproduction review:** Have the “Engine portability layer” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M02.01-C050-T10 · Acceptance linkage:** Link the “Engine portability layer” evidence to its parent and UC-M02.01 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 06. Build configuration

**Source delivery:** Create an explicit target configuration for engine, application and library-OS options.

**Source invariant:** The configuration identifies one reproducible supported guest profile.

**Source negative case:** Implicit host environment defaults change the selected platform.

**Source bounded quantities:** Configuration size and option combinations.

### UC-M02.01-C051 · Contract

**Original checklist item:** Specify build configuration inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M02.01-C051-T01 · Scope statement:** Draft the operation boundary for “Build configuration” within Chosen library-OS integration; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M02.01-C051-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Build configuration”; record each producer, representation and missing-value meaning.
- [ ] **UC-M02.01-C051-T03 · Output inventory:** List the outputs of “Build configuration” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M02.01-C051-T04 · Field dictionary:** Create a field-and-term dictionary for “Build configuration”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M02.01-C051-T05 · Prerequisite contract:** Map “Build configuration” to the source component prerequisites (UC-M01.07); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M02.01-C051-T06 · Authority map:** Identify who may produce, change and consume “Build configuration”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M02.01-C051-T07 · Invariant clause:** Add a normative clause for “Build configuration” that preserves “The configuration identifies one reproducible supported guest profile”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M02.01-C051-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Build configuration”; include the source counterexample “Implicit host environment defaults change the selected platform” and the intended safe disposition.
- [ ] **UC-M02.01-C051-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Configuration size and option combinations” in the “Build configuration” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M02.01-C051-T10 · Contract review:** Review the “Build configuration” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M02.01-C052 · Delivery

**Original checklist item:** Create an explicit target configuration for engine, application and library-OS options.

- [ ] **UC-M02.01-C052-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Build configuration”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M02.01-C052-T02 · Change plan:** Break the source delivery for “Build configuration” into concrete edit targets and reviewable outputs; keep the UC-M02.01 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M02.01-C052-T03 · Core artifact:** Implement the smallest selected-profile change for “Build configuration” that realizes this source instruction: Create an explicit target configuration for engine, application and library-OS options.
- [ ] **UC-M02.01-C052-T04 · Concrete realization:** Trace “Build configuration” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M02.01-C052-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Build configuration” needed to preserve “The configuration identifies one reproducible supported guest profile”; record an enforcement gap where only a model exists.
- [ ] **UC-M02.01-C052-T06 · Dependency connection:** Connect the “Build configuration” implementation to the selected engine portability layer, library OS and image build recipe; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M02.01-C052-T07 · Resource behavior:** Account for “Configuration size and option combinations” in “Build configuration”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M02.01-C052-T08 · Delivery check:** Run the smallest real “Build configuration” path and its adverse fixture “Implicit host environment defaults change the selected platform”; retain actual output, state effects and final disposition.
- [ ] **UC-M02.01-C052-T09 · Patch review:** Review the “Build configuration” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M02.01-C052-T10 · Delivery handoff:** Publish the “Build configuration” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M02.01-C053 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: The configuration identifies one reproducible supported guest profile. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M02.01-C053-T01 · Named property:** Create a stable property/check name under this parent for “Build configuration”; copy its required invariant exactly: “The configuration identifies one reproducible supported guest profile”.
- [ ] **UC-M02.01-C053-T02 · Observable terms:** Define each term in the “Build configuration” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M02.01-C053-T03 · Precondition set:** List the preconditions under which “The configuration identifies one reproducible supported guest profile” must hold for “Build configuration”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M02.01-C053-T04 · Transition coverage:** Map the “Build configuration” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M02.01-C053-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Build configuration”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M02.01-C053-T06 · Satisfying fixture:** Create a concrete “Build configuration” case that satisfies “The configuration identifies one reproducible supported guest profile”; record its expected observation before running the assertion or review.
- [ ] **UC-M02.01-C053-T07 · Violating fixture:** Create the source counterexample “Implicit host environment defaults change the selected platform” for “Build configuration”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M02.01-C053-T08 · Enforcement evidence:** Exercise the “Build configuration” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M02.01-C053-T09 · Regression linkage:** Link the “Build configuration” property to changes in the selected engine portability layer, library OS and image build recipe; record which dependency or contract changes require rerunning it.
- [ ] **UC-M02.01-C053-T10 · Property disposition:** Compare the satisfying and violating “Build configuration” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M02.01-C054 · Integration

**Original checklist item:** Integrate build configuration with the selected engine portability layer, library OS and image build recipe; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M02.01-C054-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Build configuration” across the selected engine portability layer, library OS and image build recipe; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M02.01-C054-T02 · Field mapping:** Map every “Build configuration” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M02.01-C054-T03 · Prerequisite identities:** Record the actual prerequisites for “Build configuration” (source dependency list: UC-M01.07); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M02.01-C054-T04 · Ownership agreement:** Specify who owns “Build configuration” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M02.01-C054-T05 · Handoff implementation:** Connect “Build configuration” through the mapped seam using the real adapter or explicit specification reference; preserve “The configuration identifies one reproducible supported guest profile” across the handoff.
- [ ] **UC-M02.01-C054-T06 · Absent-input case:** Omit one required “Build configuration” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M02.01-C054-T07 · Stale-input case:** Supply an outdated “Build configuration” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M02.01-C054-T08 · Incompatible-input case:** Supply an incompatible “Build configuration” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M02.01-C054-T09 · Valid integration trace:** Run a valid “Build configuration” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M02.01-C054-T10 · Seam review:** Reconcile the “Build configuration” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M02.01-C055 · Valid-case test

**Original checklist item:** Run a valid-path fixture for build configuration; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M02.01-C055-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Build configuration” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M02.01-C055-T02 · Expected-result oracle:** Specify the “Build configuration” expected result independently of the implementation output; include the property “The configuration identifies one reproducible supported guest profile” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M02.01-C055-T03 · Fixture material:** Create the concrete “Build configuration” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M02.01-C055-T04 · Target preparation:** Prepare the “Build configuration” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M02.01-C055-T05 · Initial-state record:** Record the initial “Build configuration” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M02.01-C055-T06 · Valid-path execution:** Execute the “Build configuration” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M02.01-C055-T07 · Outcome comparison:** Compare every declared “Build configuration” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M02.01-C055-T08 · State and bounds check:** Inspect the “Build configuration” ownership/state effects and actual use of “Configuration size and option combinations”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M02.01-C055-T09 · Repeatability check:** Repeat the same “Build configuration” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M02.01-C055-T10 · Positive evidence:** Attach the “Build configuration” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M02.01-C056 · Negative test

**Original checklist item:** Negative case: Implicit host environment defaults change the selected platform. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M02.01-C056-T01 · Adverse-case definition:** Create a test record for the exact “Build configuration” source counterexample: “Implicit host environment defaults change the selected platform”; state which precondition or invariant it challenges.
- [ ] **UC-M02.01-C056-T02 · Safe fixture boundary:** Define the contained test boundary for “Build configuration”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M02.01-C056-T03 · Valid control:** Construct a valid “Build configuration” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M02.01-C056-T04 · Minimal adverse input:** Derive the “Build configuration” adverse fixture from the control with the smallest documented change needed to reproduce “Implicit host environment defaults change the selected platform”; retain that change as reproducible data.
- [ ] **UC-M02.01-C056-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Build configuration”; require “The configuration identifies one reproducible supported guest profile” and forbid a false-success verdict.
- [ ] **UC-M02.01-C056-T06 · Adverse execution:** Exercise the “Build configuration” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M02.01-C056-T07 · Effect inspection:** Inspect “Build configuration” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M02.01-C056-T08 · Refusal versus failure:** Confirm the “Build configuration” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M02.01-C056-T09 · Reset and retention:** Restore only the disposable “Build configuration” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M02.01-C056-T10 · Negative regression:** Register the “Build configuration” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M02.01-C057 · Change / failure test

**Original checklist item:** Exercise build configuration when the selected library-OS configuration changes and a clean guest rebuild is required; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M02.01-C057-T01 · Scenario record:** Write the “Build configuration” change/failure scenario exactly as supplied: the selected library-OS configuration changes and a clean guest rebuild is required; identify the property that must remain true: “The configuration identifies one reproducible supported guest profile”.
- [ ] **UC-M02.01-C057-T02 · Baseline capture:** Create a known-valid “Build configuration” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M02.01-C057-T03 · Injection map:** Locate the “Build configuration” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M02.01-C057-T04 · Disposition oracle:** Define the legal intermediate and final “Build configuration” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M02.01-C057-T05 · Controlled trigger:** Introduce the controlled “Build configuration” scenario in the disposable fixture: the selected library-OS configuration changes and a clean guest rebuild is required; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M02.01-C057-T06 · Intermediate inspection:** Inspect the “Build configuration” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M02.01-C057-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Build configuration”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M02.01-C057-T08 · Stale-evidence cleanup:** Invalidate superseded “Build configuration” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M02.01-C057-T09 · Repeat and compare:** Repeat the selected “Build configuration” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M02.01-C057-T10 · Failure evidence:** Publish the “Build configuration” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M02.01-C058 · Bounds

**Original checklist item:** Choose, document and test limits for configuration size and option combinations; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M02.01-C058-T01 · Quantity inventory:** Create a measurement inventory for “Build configuration”: “Configuration size and option combinations”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M02.01-C058-T02 · Measurement method:** Choose how to observe each “Build configuration” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M02.01-C058-T03 · Budget decision:** Select justified resource and input limits for “Build configuration”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M02.01-C058-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Build configuration” cases for “Configuration size and option combinations”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M02.01-C058-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Build configuration” limit; preserve “The configuration identifies one reproducible supported guest profile”.
- [ ] **UC-M02.01-C058-T06 · Normal measurement:** Run or review the normal “Build configuration” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M02.01-C058-T07 · At-limit measurement:** Exercise the “Build configuration” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M02.01-C058-T08 · Over-limit measurement:** Exercise the “Build configuration” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M02.01-C058-T09 · Uncovered-scope report:** List the “Build configuration” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M02.01-C058-T10 · Limit evidence:** Publish the selected “Build configuration” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M02.01-C059 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for build configuration with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M02.01-C059-T01 · Event inventory:** List the “Build configuration” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M02.01-C059-T02 · Diagnostic schema:** Define nonsecret fields for “Build configuration” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M02.01-C059-T03 · Failure mapping:** Map each documented “Build configuration” refusal or error to a diagnostic outcome; include “Implicit host environment defaults change the selected platform” and prohibit conversion into a success message.
- [ ] **UC-M02.01-C059-T04 · Emission path:** Add the “Build configuration” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M02.01-C059-T05 · Redaction check:** Test “Build configuration” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M02.01-C059-T06 · Output budget:** Set and exercise bounded “Build configuration” message size, rate and retention compatible with “Configuration size and option combinations”; define truncation behavior that preserves the final reason.
- [ ] **UC-M02.01-C059-T07 · Success/refusal fixtures:** Capture “Build configuration” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M02.01-C059-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Build configuration” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M02.01-C059-T09 · Operator review:** Read the “Build configuration” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M02.01-C059-T10 · Diagnostic evidence:** Publish redacted “Build configuration” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M02.01-C060 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for build configuration; label unexecuted checks as untested.

- [ ] **UC-M02.01-C060-T01 · Evidence inventory:** List the “Build configuration” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M02.01-C060-T02 · Artifact references:** Record the exact “Build configuration” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M02.01-C060-T03 · Fixture references:** Attach the “Build configuration” fixture IDs, input identities and oracle definition; preserve the source counterexample “Implicit host environment defaults change the selected platform” as a distinct evidence case.
- [ ] **UC-M02.01-C060-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Build configuration”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M02.01-C060-T05 · Environment record:** Record the actual “Build configuration” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M02.01-C060-T06 · Expected versus observed:** Pair every “Build configuration” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M02.01-C060-T07 · Failure and limit records:** Attach “Build configuration” change/failure and bounds evidence where required; include uncovered “Configuration size and option combinations” and unresolved violations of “The configuration identifies one reproducible supported guest profile”.
- [ ] **UC-M02.01-C060-T08 · Evidence hygiene:** Check the “Build configuration” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M02.01-C060-T09 · Reproduction review:** Have the “Build configuration” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M02.01-C060-T10 · Acceptance linkage:** Link the “Build configuration” evidence to its parent and UC-M02.01 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 07. Link validation

**Source delivery:** Check unresolved symbols and host-only dependencies in the linked guest.

**Source invariant:** The final application and required OS functionality are in the guest artifact.

**Source negative case:** A host executable is mislabeled as a bootable guest image.

**Source bounded quantities:** Symbol table size and validation runtime.

### UC-M02.01-C061 · Contract

**Original checklist item:** Specify link validation inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M02.01-C061-T01 · Scope statement:** Draft the operation boundary for “Link validation” within Chosen library-OS integration; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M02.01-C061-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Link validation”; record each producer, representation and missing-value meaning.
- [ ] **UC-M02.01-C061-T03 · Output inventory:** List the outputs of “Link validation” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M02.01-C061-T04 · Field dictionary:** Create a field-and-term dictionary for “Link validation”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M02.01-C061-T05 · Prerequisite contract:** Map “Link validation” to the source component prerequisites (UC-M01.07); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M02.01-C061-T06 · Authority map:** Identify who may produce, change and consume “Link validation”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M02.01-C061-T07 · Invariant clause:** Add a normative clause for “Link validation” that preserves “The final application and required OS functionality are in the guest artifact”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M02.01-C061-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Link validation”; include the source counterexample “A host executable is mislabeled as a bootable guest image” and the intended safe disposition.
- [ ] **UC-M02.01-C061-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Symbol table size and validation runtime” in the “Link validation” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M02.01-C061-T10 · Contract review:** Review the “Link validation” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M02.01-C062 · Delivery

**Original checklist item:** Check unresolved symbols and host-only dependencies in the linked guest.

- [ ] **UC-M02.01-C062-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Link validation”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M02.01-C062-T02 · Change plan:** Break the source delivery for “Link validation” into concrete edit targets and reviewable outputs; keep the UC-M02.01 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M02.01-C062-T03 · Core artifact:** Create the “Link validation” fixture or harness for this source instruction: Check unresolved symbols and host-only dependencies in the linked guest.
- [ ] **UC-M02.01-C062-T04 · Concrete realization:** Connect the “Link validation” harness to its actual intended target, set the expected oracle before running it, and distinguish a mock/control run from a target run.
- [ ] **UC-M02.01-C062-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Link validation” needed to preserve “The final application and required OS functionality are in the guest artifact”; record an enforcement gap where only a model exists.
- [ ] **UC-M02.01-C062-T06 · Dependency connection:** Connect the “Link validation” implementation to the selected engine portability layer, library OS and image build recipe; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M02.01-C062-T07 · Resource behavior:** Account for “Symbol table size and validation runtime” in “Link validation”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M02.01-C062-T08 · Delivery check:** Run the smallest real “Link validation” path and its adverse fixture “A host executable is mislabeled as a bootable guest image”; retain actual output, state effects and final disposition.
- [ ] **UC-M02.01-C062-T09 · Patch review:** Review the “Link validation” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M02.01-C062-T10 · Delivery handoff:** Publish the “Link validation” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M02.01-C063 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: The final application and required OS functionality are in the guest artifact. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M02.01-C063-T01 · Named property:** Create a stable property/check name under this parent for “Link validation”; copy its required invariant exactly: “The final application and required OS functionality are in the guest artifact”.
- [ ] **UC-M02.01-C063-T02 · Observable terms:** Define each term in the “Link validation” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M02.01-C063-T03 · Precondition set:** List the preconditions under which “The final application and required OS functionality are in the guest artifact” must hold for “Link validation”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M02.01-C063-T04 · Transition coverage:** Map the “Link validation” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M02.01-C063-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Link validation”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M02.01-C063-T06 · Satisfying fixture:** Create a concrete “Link validation” case that satisfies “The final application and required OS functionality are in the guest artifact”; record its expected observation before running the assertion or review.
- [ ] **UC-M02.01-C063-T07 · Violating fixture:** Create the source counterexample “A host executable is mislabeled as a bootable guest image” for “Link validation”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M02.01-C063-T08 · Enforcement evidence:** Exercise the “Link validation” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M02.01-C063-T09 · Regression linkage:** Link the “Link validation” property to changes in the selected engine portability layer, library OS and image build recipe; record which dependency or contract changes require rerunning it.
- [ ] **UC-M02.01-C063-T10 · Property disposition:** Compare the satisfying and violating “Link validation” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M02.01-C064 · Integration

**Original checklist item:** Integrate link validation with the selected engine portability layer, library OS and image build recipe; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M02.01-C064-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Link validation” across the selected engine portability layer, library OS and image build recipe; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M02.01-C064-T02 · Field mapping:** Map every “Link validation” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M02.01-C064-T03 · Prerequisite identities:** Record the actual prerequisites for “Link validation” (source dependency list: UC-M01.07); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M02.01-C064-T04 · Ownership agreement:** Specify who owns “Link validation” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M02.01-C064-T05 · Handoff implementation:** Connect “Link validation” through the mapped seam using the real adapter or explicit specification reference; preserve “The final application and required OS functionality are in the guest artifact” across the handoff.
- [ ] **UC-M02.01-C064-T06 · Absent-input case:** Omit one required “Link validation” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M02.01-C064-T07 · Stale-input case:** Supply an outdated “Link validation” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M02.01-C064-T08 · Incompatible-input case:** Supply an incompatible “Link validation” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M02.01-C064-T09 · Valid integration trace:** Run a valid “Link validation” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M02.01-C064-T10 · Seam review:** Reconcile the “Link validation” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M02.01-C065 · Valid-case test

**Original checklist item:** Run a valid-path fixture for link validation; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M02.01-C065-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Link validation” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M02.01-C065-T02 · Expected-result oracle:** Specify the “Link validation” expected result independently of the implementation output; include the property “The final application and required OS functionality are in the guest artifact” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M02.01-C065-T03 · Fixture material:** Create the concrete “Link validation” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M02.01-C065-T04 · Target preparation:** Prepare the “Link validation” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M02.01-C065-T05 · Initial-state record:** Record the initial “Link validation” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M02.01-C065-T06 · Valid-path execution:** Execute the “Link validation” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M02.01-C065-T07 · Outcome comparison:** Compare every declared “Link validation” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M02.01-C065-T08 · State and bounds check:** Inspect the “Link validation” ownership/state effects and actual use of “Symbol table size and validation runtime”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M02.01-C065-T09 · Repeatability check:** Repeat the same “Link validation” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M02.01-C065-T10 · Positive evidence:** Attach the “Link validation” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M02.01-C066 · Negative test

**Original checklist item:** Negative case: A host executable is mislabeled as a bootable guest image. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M02.01-C066-T01 · Adverse-case definition:** Create a test record for the exact “Link validation” source counterexample: “A host executable is mislabeled as a bootable guest image”; state which precondition or invariant it challenges.
- [ ] **UC-M02.01-C066-T02 · Safe fixture boundary:** Define the contained test boundary for “Link validation”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M02.01-C066-T03 · Valid control:** Construct a valid “Link validation” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M02.01-C066-T04 · Minimal adverse input:** Derive the “Link validation” adverse fixture from the control with the smallest documented change needed to reproduce “A host executable is mislabeled as a bootable guest image”; retain that change as reproducible data.
- [ ] **UC-M02.01-C066-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Link validation”; require “The final application and required OS functionality are in the guest artifact” and forbid a false-success verdict.
- [ ] **UC-M02.01-C066-T06 · Adverse execution:** Exercise the “Link validation” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M02.01-C066-T07 · Effect inspection:** Inspect “Link validation” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M02.01-C066-T08 · Refusal versus failure:** Confirm the “Link validation” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M02.01-C066-T09 · Reset and retention:** Restore only the disposable “Link validation” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M02.01-C066-T10 · Negative regression:** Register the “Link validation” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M02.01-C067 · Change / failure test

**Original checklist item:** Exercise link validation when the selected library-OS configuration changes and a clean guest rebuild is required; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M02.01-C067-T01 · Scenario record:** Write the “Link validation” change/failure scenario exactly as supplied: the selected library-OS configuration changes and a clean guest rebuild is required; identify the property that must remain true: “The final application and required OS functionality are in the guest artifact”.
- [ ] **UC-M02.01-C067-T02 · Baseline capture:** Create a known-valid “Link validation” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M02.01-C067-T03 · Injection map:** Locate the “Link validation” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M02.01-C067-T04 · Disposition oracle:** Define the legal intermediate and final “Link validation” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M02.01-C067-T05 · Controlled trigger:** Introduce the controlled “Link validation” scenario in the disposable fixture: the selected library-OS configuration changes and a clean guest rebuild is required; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M02.01-C067-T06 · Intermediate inspection:** Inspect the “Link validation” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M02.01-C067-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Link validation”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M02.01-C067-T08 · Stale-evidence cleanup:** Invalidate superseded “Link validation” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M02.01-C067-T09 · Repeat and compare:** Repeat the selected “Link validation” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M02.01-C067-T10 · Failure evidence:** Publish the “Link validation” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M02.01-C068 · Bounds

**Original checklist item:** Choose, document and test limits for symbol table size and validation runtime; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M02.01-C068-T01 · Quantity inventory:** Create a measurement inventory for “Link validation”: “Symbol table size and validation runtime”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M02.01-C068-T02 · Measurement method:** Choose how to observe each “Link validation” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M02.01-C068-T03 · Budget decision:** Select justified resource and input limits for “Link validation”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M02.01-C068-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Link validation” cases for “Symbol table size and validation runtime”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M02.01-C068-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Link validation” limit; preserve “The final application and required OS functionality are in the guest artifact”.
- [ ] **UC-M02.01-C068-T06 · Normal measurement:** Run or review the normal “Link validation” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M02.01-C068-T07 · At-limit measurement:** Exercise the “Link validation” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M02.01-C068-T08 · Over-limit measurement:** Exercise the “Link validation” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M02.01-C068-T09 · Uncovered-scope report:** List the “Link validation” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M02.01-C068-T10 · Limit evidence:** Publish the selected “Link validation” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M02.01-C069 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for link validation with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M02.01-C069-T01 · Event inventory:** List the “Link validation” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M02.01-C069-T02 · Diagnostic schema:** Define nonsecret fields for “Link validation” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M02.01-C069-T03 · Failure mapping:** Map each documented “Link validation” refusal or error to a diagnostic outcome; include “A host executable is mislabeled as a bootable guest image” and prohibit conversion into a success message.
- [ ] **UC-M02.01-C069-T04 · Emission path:** Add the “Link validation” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M02.01-C069-T05 · Redaction check:** Test “Link validation” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M02.01-C069-T06 · Output budget:** Set and exercise bounded “Link validation” message size, rate and retention compatible with “Symbol table size and validation runtime”; define truncation behavior that preserves the final reason.
- [ ] **UC-M02.01-C069-T07 · Success/refusal fixtures:** Capture “Link validation” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M02.01-C069-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Link validation” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M02.01-C069-T09 · Operator review:** Read the “Link validation” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M02.01-C069-T10 · Diagnostic evidence:** Publish redacted “Link validation” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M02.01-C070 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for link validation; label unexecuted checks as untested.

- [ ] **UC-M02.01-C070-T01 · Evidence inventory:** List the “Link validation” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M02.01-C070-T02 · Artifact references:** Record the exact “Link validation” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M02.01-C070-T03 · Fixture references:** Attach the “Link validation” fixture IDs, input identities and oracle definition; preserve the source counterexample “A host executable is mislabeled as a bootable guest image” as a distinct evidence case.
- [ ] **UC-M02.01-C070-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Link validation”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M02.01-C070-T05 · Environment record:** Record the actual “Link validation” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M02.01-C070-T06 · Expected versus observed:** Pair every “Link validation” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M02.01-C070-T07 · Failure and limit records:** Attach “Link validation” change/failure and bounds evidence where required; include uncovered “Symbol table size and validation runtime” and unresolved violations of “The final application and required OS functionality are in the guest artifact”.
- [ ] **UC-M02.01-C070-T08 · Evidence hygiene:** Check the “Link validation” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M02.01-C070-T09 · Reproduction review:** Have the “Link validation” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M02.01-C070-T10 · Acceptance linkage:** Link the “Link validation” evidence to its parent and UC-M02.01 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 08. Application input path

**Source delivery:** Provide the selected workload with a defined guest-side input mechanism.

**Source invariant:** Application inputs enter through the declared guest interface.

**Source negative case:** An input is read from an unrelated host workspace path.

**Source bounded quantities:** Input bytes and transfer buffer size.

### UC-M02.01-C071 · Contract

**Original checklist item:** Specify application input path inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M02.01-C071-T01 · Scope statement:** Draft the operation boundary for “Application input path” within Chosen library-OS integration; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M02.01-C071-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Application input path”; record each producer, representation and missing-value meaning.
- [ ] **UC-M02.01-C071-T03 · Output inventory:** List the outputs of “Application input path” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M02.01-C071-T04 · Field dictionary:** Create a field-and-term dictionary for “Application input path”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M02.01-C071-T05 · Prerequisite contract:** Map “Application input path” to the source component prerequisites (UC-M01.07); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M02.01-C071-T06 · Authority map:** Identify who may produce, change and consume “Application input path”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M02.01-C071-T07 · Invariant clause:** Add a normative clause for “Application input path” that preserves “Application inputs enter through the declared guest interface”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M02.01-C071-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Application input path”; include the source counterexample “An input is read from an unrelated host workspace path” and the intended safe disposition.
- [ ] **UC-M02.01-C071-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Input bytes and transfer buffer size” in the “Application input path” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M02.01-C071-T10 · Contract review:** Review the “Application input path” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M02.01-C072 · Delivery

**Original checklist item:** Provide the selected workload with a defined guest-side input mechanism.

- [ ] **UC-M02.01-C072-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Application input path”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M02.01-C072-T02 · Change plan:** Break the source delivery for “Application input path” into concrete edit targets and reviewable outputs; keep the UC-M02.01 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M02.01-C072-T03 · Core artifact:** Implement the smallest selected-profile change for “Application input path” that realizes this source instruction: Provide the selected workload with a defined guest-side input mechanism.
- [ ] **UC-M02.01-C072-T04 · Concrete realization:** Trace “Application input path” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M02.01-C072-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Application input path” needed to preserve “Application inputs enter through the declared guest interface”; record an enforcement gap where only a model exists.
- [ ] **UC-M02.01-C072-T06 · Dependency connection:** Connect the “Application input path” implementation to the selected engine portability layer, library OS and image build recipe; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M02.01-C072-T07 · Resource behavior:** Account for “Input bytes and transfer buffer size” in “Application input path”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M02.01-C072-T08 · Delivery check:** Run the smallest real “Application input path” path and its adverse fixture “An input is read from an unrelated host workspace path”; retain actual output, state effects and final disposition.
- [ ] **UC-M02.01-C072-T09 · Patch review:** Review the “Application input path” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M02.01-C072-T10 · Delivery handoff:** Publish the “Application input path” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M02.01-C073 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Application inputs enter through the declared guest interface. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M02.01-C073-T01 · Named property:** Create a stable property/check name under this parent for “Application input path”; copy its required invariant exactly: “Application inputs enter through the declared guest interface”.
- [ ] **UC-M02.01-C073-T02 · Observable terms:** Define each term in the “Application input path” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M02.01-C073-T03 · Precondition set:** List the preconditions under which “Application inputs enter through the declared guest interface” must hold for “Application input path”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M02.01-C073-T04 · Transition coverage:** Map the “Application input path” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M02.01-C073-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Application input path”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M02.01-C073-T06 · Satisfying fixture:** Create a concrete “Application input path” case that satisfies “Application inputs enter through the declared guest interface”; record its expected observation before running the assertion or review.
- [ ] **UC-M02.01-C073-T07 · Violating fixture:** Create the source counterexample “An input is read from an unrelated host workspace path” for “Application input path”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M02.01-C073-T08 · Enforcement evidence:** Exercise the “Application input path” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M02.01-C073-T09 · Regression linkage:** Link the “Application input path” property to changes in the selected engine portability layer, library OS and image build recipe; record which dependency or contract changes require rerunning it.
- [ ] **UC-M02.01-C073-T10 · Property disposition:** Compare the satisfying and violating “Application input path” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M02.01-C074 · Integration

**Original checklist item:** Integrate application input path with the selected engine portability layer, library OS and image build recipe; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M02.01-C074-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Application input path” across the selected engine portability layer, library OS and image build recipe; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M02.01-C074-T02 · Field mapping:** Map every “Application input path” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M02.01-C074-T03 · Prerequisite identities:** Record the actual prerequisites for “Application input path” (source dependency list: UC-M01.07); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M02.01-C074-T04 · Ownership agreement:** Specify who owns “Application input path” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M02.01-C074-T05 · Handoff implementation:** Connect “Application input path” through the mapped seam using the real adapter or explicit specification reference; preserve “Application inputs enter through the declared guest interface” across the handoff.
- [ ] **UC-M02.01-C074-T06 · Absent-input case:** Omit one required “Application input path” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M02.01-C074-T07 · Stale-input case:** Supply an outdated “Application input path” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M02.01-C074-T08 · Incompatible-input case:** Supply an incompatible “Application input path” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M02.01-C074-T09 · Valid integration trace:** Run a valid “Application input path” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M02.01-C074-T10 · Seam review:** Reconcile the “Application input path” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M02.01-C075 · Valid-case test

**Original checklist item:** Run a valid-path fixture for application input path; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M02.01-C075-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Application input path” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M02.01-C075-T02 · Expected-result oracle:** Specify the “Application input path” expected result independently of the implementation output; include the property “Application inputs enter through the declared guest interface” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M02.01-C075-T03 · Fixture material:** Create the concrete “Application input path” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M02.01-C075-T04 · Target preparation:** Prepare the “Application input path” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M02.01-C075-T05 · Initial-state record:** Record the initial “Application input path” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M02.01-C075-T06 · Valid-path execution:** Execute the “Application input path” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M02.01-C075-T07 · Outcome comparison:** Compare every declared “Application input path” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M02.01-C075-T08 · State and bounds check:** Inspect the “Application input path” ownership/state effects and actual use of “Input bytes and transfer buffer size”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M02.01-C075-T09 · Repeatability check:** Repeat the same “Application input path” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M02.01-C075-T10 · Positive evidence:** Attach the “Application input path” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M02.01-C076 · Negative test

**Original checklist item:** Negative case: An input is read from an unrelated host workspace path. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M02.01-C076-T01 · Adverse-case definition:** Create a test record for the exact “Application input path” source counterexample: “An input is read from an unrelated host workspace path”; state which precondition or invariant it challenges.
- [ ] **UC-M02.01-C076-T02 · Safe fixture boundary:** Define the contained test boundary for “Application input path”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M02.01-C076-T03 · Valid control:** Construct a valid “Application input path” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M02.01-C076-T04 · Minimal adverse input:** Derive the “Application input path” adverse fixture from the control with the smallest documented change needed to reproduce “An input is read from an unrelated host workspace path”; retain that change as reproducible data.
- [ ] **UC-M02.01-C076-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Application input path”; require “Application inputs enter through the declared guest interface” and forbid a false-success verdict.
- [ ] **UC-M02.01-C076-T06 · Adverse execution:** Exercise the “Application input path” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M02.01-C076-T07 · Effect inspection:** Inspect “Application input path” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M02.01-C076-T08 · Refusal versus failure:** Confirm the “Application input path” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M02.01-C076-T09 · Reset and retention:** Restore only the disposable “Application input path” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M02.01-C076-T10 · Negative regression:** Register the “Application input path” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M02.01-C077 · Change / failure test

**Original checklist item:** Exercise application input path when the selected library-OS configuration changes and a clean guest rebuild is required; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M02.01-C077-T01 · Scenario record:** Write the “Application input path” change/failure scenario exactly as supplied: the selected library-OS configuration changes and a clean guest rebuild is required; identify the property that must remain true: “Application inputs enter through the declared guest interface”.
- [ ] **UC-M02.01-C077-T02 · Baseline capture:** Create a known-valid “Application input path” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M02.01-C077-T03 · Injection map:** Locate the “Application input path” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M02.01-C077-T04 · Disposition oracle:** Define the legal intermediate and final “Application input path” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M02.01-C077-T05 · Controlled trigger:** Introduce the controlled “Application input path” scenario in the disposable fixture: the selected library-OS configuration changes and a clean guest rebuild is required; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M02.01-C077-T06 · Intermediate inspection:** Inspect the “Application input path” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M02.01-C077-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Application input path”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M02.01-C077-T08 · Stale-evidence cleanup:** Invalidate superseded “Application input path” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M02.01-C077-T09 · Repeat and compare:** Repeat the selected “Application input path” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M02.01-C077-T10 · Failure evidence:** Publish the “Application input path” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M02.01-C078 · Bounds

**Original checklist item:** Choose, document and test limits for input bytes and transfer buffer size; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M02.01-C078-T01 · Quantity inventory:** Create a measurement inventory for “Application input path”: “Input bytes and transfer buffer size”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M02.01-C078-T02 · Measurement method:** Choose how to observe each “Application input path” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M02.01-C078-T03 · Budget decision:** Select justified resource and input limits for “Application input path”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M02.01-C078-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Application input path” cases for “Input bytes and transfer buffer size”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M02.01-C078-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Application input path” limit; preserve “Application inputs enter through the declared guest interface”.
- [ ] **UC-M02.01-C078-T06 · Normal measurement:** Run or review the normal “Application input path” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M02.01-C078-T07 · At-limit measurement:** Exercise the “Application input path” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M02.01-C078-T08 · Over-limit measurement:** Exercise the “Application input path” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M02.01-C078-T09 · Uncovered-scope report:** List the “Application input path” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M02.01-C078-T10 · Limit evidence:** Publish the selected “Application input path” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M02.01-C079 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for application input path with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M02.01-C079-T01 · Event inventory:** List the “Application input path” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M02.01-C079-T02 · Diagnostic schema:** Define nonsecret fields for “Application input path” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M02.01-C079-T03 · Failure mapping:** Map each documented “Application input path” refusal or error to a diagnostic outcome; include “An input is read from an unrelated host workspace path” and prohibit conversion into a success message.
- [ ] **UC-M02.01-C079-T04 · Emission path:** Add the “Application input path” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M02.01-C079-T05 · Redaction check:** Test “Application input path” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M02.01-C079-T06 · Output budget:** Set and exercise bounded “Application input path” message size, rate and retention compatible with “Input bytes and transfer buffer size”; define truncation behavior that preserves the final reason.
- [ ] **UC-M02.01-C079-T07 · Success/refusal fixtures:** Capture “Application input path” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M02.01-C079-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Application input path” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M02.01-C079-T09 · Operator review:** Read the “Application input path” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M02.01-C079-T10 · Diagnostic evidence:** Publish redacted “Application input path” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M02.01-C080 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for application input path; label unexecuted checks as untested.

- [ ] **UC-M02.01-C080-T01 · Evidence inventory:** List the “Application input path” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M02.01-C080-T02 · Artifact references:** Record the exact “Application input path” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M02.01-C080-T03 · Fixture references:** Attach the “Application input path” fixture IDs, input identities and oracle definition; preserve the source counterexample “An input is read from an unrelated host workspace path” as a distinct evidence case.
- [ ] **UC-M02.01-C080-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Application input path”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M02.01-C080-T05 · Environment record:** Record the actual “Application input path” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M02.01-C080-T06 · Expected versus observed:** Pair every “Application input path” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M02.01-C080-T07 · Failure and limit records:** Attach “Application input path” change/failure and bounds evidence where required; include uncovered “Input bytes and transfer buffer size” and unresolved violations of “Application inputs enter through the declared guest interface”.
- [ ] **UC-M02.01-C080-T08 · Evidence hygiene:** Check the “Application input path” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M02.01-C080-T09 · Reproduction review:** Have the “Application input path” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M02.01-C080-T10 · Acceptance linkage:** Link the “Application input path” evidence to its parent and UC-M02.01 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 09. Application output path

**Source delivery:** Return application output through a bounded observable guest interface.

**Source invariant:** The emitted result is attributable to guest execution.

**Source negative case:** The host fabricates a success output after guest boot failure.

**Source bounded quantities:** Output bytes and completion deadline.

### UC-M02.01-C081 · Contract

**Original checklist item:** Specify application output path inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M02.01-C081-T01 · Scope statement:** Draft the operation boundary for “Application output path” within Chosen library-OS integration; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M02.01-C081-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Application output path”; record each producer, representation and missing-value meaning.
- [ ] **UC-M02.01-C081-T03 · Output inventory:** List the outputs of “Application output path” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M02.01-C081-T04 · Field dictionary:** Create a field-and-term dictionary for “Application output path”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M02.01-C081-T05 · Prerequisite contract:** Map “Application output path” to the source component prerequisites (UC-M01.07); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M02.01-C081-T06 · Authority map:** Identify who may produce, change and consume “Application output path”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M02.01-C081-T07 · Invariant clause:** Add a normative clause for “Application output path” that preserves “The emitted result is attributable to guest execution”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M02.01-C081-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Application output path”; include the source counterexample “The host fabricates a success output after guest boot failure” and the intended safe disposition.
- [ ] **UC-M02.01-C081-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Output bytes and completion deadline” in the “Application output path” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M02.01-C081-T10 · Contract review:** Review the “Application output path” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M02.01-C082 · Delivery

**Original checklist item:** Return application output through a bounded observable guest interface.

- [ ] **UC-M02.01-C082-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Application output path”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M02.01-C082-T02 · Change plan:** Break the source delivery for “Application output path” into concrete edit targets and reviewable outputs; keep the UC-M02.01 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M02.01-C082-T03 · Core artifact:** Implement the smallest selected-profile change for “Application output path” that realizes this source instruction: Return application output through a bounded observable guest interface.
- [ ] **UC-M02.01-C082-T04 · Concrete realization:** Trace “Application output path” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M02.01-C082-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Application output path” needed to preserve “The emitted result is attributable to guest execution”; record an enforcement gap where only a model exists.
- [ ] **UC-M02.01-C082-T06 · Dependency connection:** Connect the “Application output path” implementation to the selected engine portability layer, library OS and image build recipe; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M02.01-C082-T07 · Resource behavior:** Account for “Output bytes and completion deadline” in “Application output path”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M02.01-C082-T08 · Delivery check:** Run the smallest real “Application output path” path and its adverse fixture “The host fabricates a success output after guest boot failure”; retain actual output, state effects and final disposition.
- [ ] **UC-M02.01-C082-T09 · Patch review:** Review the “Application output path” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M02.01-C082-T10 · Delivery handoff:** Publish the “Application output path” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M02.01-C083 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: The emitted result is attributable to guest execution. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M02.01-C083-T01 · Named property:** Create a stable property/check name under this parent for “Application output path”; copy its required invariant exactly: “The emitted result is attributable to guest execution”.
- [ ] **UC-M02.01-C083-T02 · Observable terms:** Define each term in the “Application output path” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M02.01-C083-T03 · Precondition set:** List the preconditions under which “The emitted result is attributable to guest execution” must hold for “Application output path”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M02.01-C083-T04 · Transition coverage:** Map the “Application output path” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M02.01-C083-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Application output path”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M02.01-C083-T06 · Satisfying fixture:** Create a concrete “Application output path” case that satisfies “The emitted result is attributable to guest execution”; record its expected observation before running the assertion or review.
- [ ] **UC-M02.01-C083-T07 · Violating fixture:** Create the source counterexample “The host fabricates a success output after guest boot failure” for “Application output path”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M02.01-C083-T08 · Enforcement evidence:** Exercise the “Application output path” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M02.01-C083-T09 · Regression linkage:** Link the “Application output path” property to changes in the selected engine portability layer, library OS and image build recipe; record which dependency or contract changes require rerunning it.
- [ ] **UC-M02.01-C083-T10 · Property disposition:** Compare the satisfying and violating “Application output path” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M02.01-C084 · Integration

**Original checklist item:** Integrate application output path with the selected engine portability layer, library OS and image build recipe; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M02.01-C084-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Application output path” across the selected engine portability layer, library OS and image build recipe; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M02.01-C084-T02 · Field mapping:** Map every “Application output path” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M02.01-C084-T03 · Prerequisite identities:** Record the actual prerequisites for “Application output path” (source dependency list: UC-M01.07); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M02.01-C084-T04 · Ownership agreement:** Specify who owns “Application output path” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M02.01-C084-T05 · Handoff implementation:** Connect “Application output path” through the mapped seam using the real adapter or explicit specification reference; preserve “The emitted result is attributable to guest execution” across the handoff.
- [ ] **UC-M02.01-C084-T06 · Absent-input case:** Omit one required “Application output path” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M02.01-C084-T07 · Stale-input case:** Supply an outdated “Application output path” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M02.01-C084-T08 · Incompatible-input case:** Supply an incompatible “Application output path” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M02.01-C084-T09 · Valid integration trace:** Run a valid “Application output path” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M02.01-C084-T10 · Seam review:** Reconcile the “Application output path” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M02.01-C085 · Valid-case test

**Original checklist item:** Run a valid-path fixture for application output path; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M02.01-C085-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Application output path” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M02.01-C085-T02 · Expected-result oracle:** Specify the “Application output path” expected result independently of the implementation output; include the property “The emitted result is attributable to guest execution” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M02.01-C085-T03 · Fixture material:** Create the concrete “Application output path” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M02.01-C085-T04 · Target preparation:** Prepare the “Application output path” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M02.01-C085-T05 · Initial-state record:** Record the initial “Application output path” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M02.01-C085-T06 · Valid-path execution:** Execute the “Application output path” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M02.01-C085-T07 · Outcome comparison:** Compare every declared “Application output path” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M02.01-C085-T08 · State and bounds check:** Inspect the “Application output path” ownership/state effects and actual use of “Output bytes and completion deadline”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M02.01-C085-T09 · Repeatability check:** Repeat the same “Application output path” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M02.01-C085-T10 · Positive evidence:** Attach the “Application output path” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M02.01-C086 · Negative test

**Original checklist item:** Negative case: The host fabricates a success output after guest boot failure. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M02.01-C086-T01 · Adverse-case definition:** Create a test record for the exact “Application output path” source counterexample: “The host fabricates a success output after guest boot failure”; state which precondition or invariant it challenges.
- [ ] **UC-M02.01-C086-T02 · Safe fixture boundary:** Define the contained test boundary for “Application output path”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M02.01-C086-T03 · Valid control:** Construct a valid “Application output path” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M02.01-C086-T04 · Minimal adverse input:** Derive the “Application output path” adverse fixture from the control with the smallest documented change needed to reproduce “The host fabricates a success output after guest boot failure”; retain that change as reproducible data.
- [ ] **UC-M02.01-C086-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Application output path”; require “The emitted result is attributable to guest execution” and forbid a false-success verdict.
- [ ] **UC-M02.01-C086-T06 · Adverse execution:** Exercise the “Application output path” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M02.01-C086-T07 · Effect inspection:** Inspect “Application output path” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M02.01-C086-T08 · Refusal versus failure:** Confirm the “Application output path” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M02.01-C086-T09 · Reset and retention:** Restore only the disposable “Application output path” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M02.01-C086-T10 · Negative regression:** Register the “Application output path” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M02.01-C087 · Change / failure test

**Original checklist item:** Exercise application output path when the selected library-OS configuration changes and a clean guest rebuild is required; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M02.01-C087-T01 · Scenario record:** Write the “Application output path” change/failure scenario exactly as supplied: the selected library-OS configuration changes and a clean guest rebuild is required; identify the property that must remain true: “The emitted result is attributable to guest execution”.
- [ ] **UC-M02.01-C087-T02 · Baseline capture:** Create a known-valid “Application output path” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M02.01-C087-T03 · Injection map:** Locate the “Application output path” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M02.01-C087-T04 · Disposition oracle:** Define the legal intermediate and final “Application output path” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M02.01-C087-T05 · Controlled trigger:** Introduce the controlled “Application output path” scenario in the disposable fixture: the selected library-OS configuration changes and a clean guest rebuild is required; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M02.01-C087-T06 · Intermediate inspection:** Inspect the “Application output path” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M02.01-C087-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Application output path”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M02.01-C087-T08 · Stale-evidence cleanup:** Invalidate superseded “Application output path” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M02.01-C087-T09 · Repeat and compare:** Repeat the selected “Application output path” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M02.01-C087-T10 · Failure evidence:** Publish the “Application output path” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M02.01-C088 · Bounds

**Original checklist item:** Choose, document and test limits for output bytes and completion deadline; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M02.01-C088-T01 · Quantity inventory:** Create a measurement inventory for “Application output path”: “Output bytes and completion deadline”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M02.01-C088-T02 · Measurement method:** Choose how to observe each “Application output path” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M02.01-C088-T03 · Budget decision:** Select justified resource and input limits for “Application output path”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M02.01-C088-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Application output path” cases for “Output bytes and completion deadline”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M02.01-C088-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Application output path” limit; preserve “The emitted result is attributable to guest execution”.
- [ ] **UC-M02.01-C088-T06 · Normal measurement:** Run or review the normal “Application output path” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M02.01-C088-T07 · At-limit measurement:** Exercise the “Application output path” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M02.01-C088-T08 · Over-limit measurement:** Exercise the “Application output path” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M02.01-C088-T09 · Uncovered-scope report:** List the “Application output path” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M02.01-C088-T10 · Limit evidence:** Publish the selected “Application output path” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M02.01-C089 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for application output path with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M02.01-C089-T01 · Event inventory:** List the “Application output path” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M02.01-C089-T02 · Diagnostic schema:** Define nonsecret fields for “Application output path” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M02.01-C089-T03 · Failure mapping:** Map each documented “Application output path” refusal or error to a diagnostic outcome; include “The host fabricates a success output after guest boot failure” and prohibit conversion into a success message.
- [ ] **UC-M02.01-C089-T04 · Emission path:** Add the “Application output path” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M02.01-C089-T05 · Redaction check:** Test “Application output path” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M02.01-C089-T06 · Output budget:** Set and exercise bounded “Application output path” message size, rate and retention compatible with “Output bytes and completion deadline”; define truncation behavior that preserves the final reason.
- [ ] **UC-M02.01-C089-T07 · Success/refusal fixtures:** Capture “Application output path” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M02.01-C089-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Application output path” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M02.01-C089-T09 · Operator review:** Read the “Application output path” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M02.01-C089-T10 · Diagnostic evidence:** Publish redacted “Application output path” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M02.01-C090 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for application output path; label unexecuted checks as untested.

- [ ] **UC-M02.01-C090-T01 · Evidence inventory:** List the “Application output path” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M02.01-C090-T02 · Artifact references:** Record the exact “Application output path” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M02.01-C090-T03 · Fixture references:** Attach the “Application output path” fixture IDs, input identities and oracle definition; preserve the source counterexample “The host fabricates a success output after guest boot failure” as a distinct evidence case.
- [ ] **UC-M02.01-C090-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Application output path”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M02.01-C090-T05 · Environment record:** Record the actual “Application output path” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M02.01-C090-T06 · Expected versus observed:** Pair every “Application output path” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M02.01-C090-T07 · Failure and limit records:** Attach “Application output path” change/failure and bounds evidence where required; include uncovered “Output bytes and completion deadline” and unresolved violations of “The emitted result is attributable to guest execution”.
- [ ] **UC-M02.01-C090-T08 · Evidence hygiene:** Check the “Application output path” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M02.01-C090-T09 · Reproduction review:** Have the “Application output path” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M02.01-C090-T10 · Acceptance linkage:** Link the “Application output path” evidence to its parent and UC-M02.01 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 10. Clean-build acceptance

**Source delivery:** Build the guest from a clean declared dependency set and retain its identity.

**Source invariant:** The acceptance artifact is a linked guest image rather than a host launch script.

**Source negative case:** A clean build succeeds only because of undeclared cached files.

**Source bounded quantities:** Build time, temporary storage and clean-build repetitions.

### UC-M02.01-C091 · Contract

**Original checklist item:** Specify clean-build acceptance inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M02.01-C091-T01 · Scope statement:** Draft the operation boundary for “Clean-build acceptance” within Chosen library-OS integration; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M02.01-C091-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Clean-build acceptance”; record each producer, representation and missing-value meaning.
- [ ] **UC-M02.01-C091-T03 · Output inventory:** List the outputs of “Clean-build acceptance” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M02.01-C091-T04 · Field dictionary:** Create a field-and-term dictionary for “Clean-build acceptance”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M02.01-C091-T05 · Prerequisite contract:** Map “Clean-build acceptance” to the source component prerequisites (UC-M01.07); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M02.01-C091-T06 · Authority map:** Identify who may produce, change and consume “Clean-build acceptance”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M02.01-C091-T07 · Invariant clause:** Add a normative clause for “Clean-build acceptance” that preserves “The acceptance artifact is a linked guest image rather than a host launch script”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M02.01-C091-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Clean-build acceptance”; include the source counterexample “A clean build succeeds only because of undeclared cached files” and the intended safe disposition.
- [ ] **UC-M02.01-C091-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Build time, temporary storage and clean-build repetitions” in the “Clean-build acceptance” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M02.01-C091-T10 · Contract review:** Review the “Clean-build acceptance” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M02.01-C092 · Delivery

**Original checklist item:** Build the guest from a clean declared dependency set and retain its identity.

- [ ] **UC-M02.01-C092-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Clean-build acceptance”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M02.01-C092-T02 · Change plan:** Break the source delivery for “Clean-build acceptance” into concrete edit targets and reviewable outputs; keep the UC-M02.01 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M02.01-C092-T03 · Core artifact:** Implement the smallest selected-profile change for “Clean-build acceptance” that realizes this source instruction: Build the guest from a clean declared dependency set and retain its identity.
- [ ] **UC-M02.01-C092-T04 · Concrete realization:** Trace “Clean-build acceptance” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M02.01-C092-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Clean-build acceptance” needed to preserve “The acceptance artifact is a linked guest image rather than a host launch script”; record an enforcement gap where only a model exists.
- [ ] **UC-M02.01-C092-T06 · Dependency connection:** Connect the “Clean-build acceptance” implementation to the selected engine portability layer, library OS and image build recipe; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M02.01-C092-T07 · Resource behavior:** Account for “Build time, temporary storage and clean-build repetitions” in “Clean-build acceptance”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M02.01-C092-T08 · Delivery check:** Run the smallest real “Clean-build acceptance” path and its adverse fixture “A clean build succeeds only because of undeclared cached files”; retain actual output, state effects and final disposition.
- [ ] **UC-M02.01-C092-T09 · Patch review:** Review the “Clean-build acceptance” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M02.01-C092-T10 · Delivery handoff:** Publish the “Clean-build acceptance” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M02.01-C093 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: The acceptance artifact is a linked guest image rather than a host launch script. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M02.01-C093-T01 · Named property:** Create a stable property/check name under this parent for “Clean-build acceptance”; copy its required invariant exactly: “The acceptance artifact is a linked guest image rather than a host launch script”.
- [ ] **UC-M02.01-C093-T02 · Observable terms:** Define each term in the “Clean-build acceptance” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M02.01-C093-T03 · Precondition set:** List the preconditions under which “The acceptance artifact is a linked guest image rather than a host launch script” must hold for “Clean-build acceptance”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M02.01-C093-T04 · Transition coverage:** Map the “Clean-build acceptance” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M02.01-C093-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Clean-build acceptance”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M02.01-C093-T06 · Satisfying fixture:** Create a concrete “Clean-build acceptance” case that satisfies “The acceptance artifact is a linked guest image rather than a host launch script”; record its expected observation before running the assertion or review.
- [ ] **UC-M02.01-C093-T07 · Violating fixture:** Create the source counterexample “A clean build succeeds only because of undeclared cached files” for “Clean-build acceptance”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M02.01-C093-T08 · Enforcement evidence:** Exercise the “Clean-build acceptance” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M02.01-C093-T09 · Regression linkage:** Link the “Clean-build acceptance” property to changes in the selected engine portability layer, library OS and image build recipe; record which dependency or contract changes require rerunning it.
- [ ] **UC-M02.01-C093-T10 · Property disposition:** Compare the satisfying and violating “Clean-build acceptance” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M02.01-C094 · Integration

**Original checklist item:** Integrate clean-build acceptance with the selected engine portability layer, library OS and image build recipe; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M02.01-C094-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Clean-build acceptance” across the selected engine portability layer, library OS and image build recipe; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M02.01-C094-T02 · Field mapping:** Map every “Clean-build acceptance” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M02.01-C094-T03 · Prerequisite identities:** Record the actual prerequisites for “Clean-build acceptance” (source dependency list: UC-M01.07); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M02.01-C094-T04 · Ownership agreement:** Specify who owns “Clean-build acceptance” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M02.01-C094-T05 · Handoff implementation:** Connect “Clean-build acceptance” through the mapped seam using the real adapter or explicit specification reference; preserve “The acceptance artifact is a linked guest image rather than a host launch script” across the handoff.
- [ ] **UC-M02.01-C094-T06 · Absent-input case:** Omit one required “Clean-build acceptance” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M02.01-C094-T07 · Stale-input case:** Supply an outdated “Clean-build acceptance” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M02.01-C094-T08 · Incompatible-input case:** Supply an incompatible “Clean-build acceptance” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M02.01-C094-T09 · Valid integration trace:** Run a valid “Clean-build acceptance” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M02.01-C094-T10 · Seam review:** Reconcile the “Clean-build acceptance” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M02.01-C095 · Valid-case test

**Original checklist item:** Run a valid-path fixture for clean-build acceptance; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M02.01-C095-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Clean-build acceptance” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M02.01-C095-T02 · Expected-result oracle:** Specify the “Clean-build acceptance” expected result independently of the implementation output; include the property “The acceptance artifact is a linked guest image rather than a host launch script” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M02.01-C095-T03 · Fixture material:** Create the concrete “Clean-build acceptance” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M02.01-C095-T04 · Target preparation:** Prepare the “Clean-build acceptance” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M02.01-C095-T05 · Initial-state record:** Record the initial “Clean-build acceptance” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M02.01-C095-T06 · Valid-path execution:** Execute the “Clean-build acceptance” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M02.01-C095-T07 · Outcome comparison:** Compare every declared “Clean-build acceptance” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M02.01-C095-T08 · State and bounds check:** Inspect the “Clean-build acceptance” ownership/state effects and actual use of “Build time, temporary storage and clean-build repetitions”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M02.01-C095-T09 · Repeatability check:** Repeat the same “Clean-build acceptance” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M02.01-C095-T10 · Positive evidence:** Attach the “Clean-build acceptance” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M02.01-C096 · Negative test

**Original checklist item:** Negative case: A clean build succeeds only because of undeclared cached files. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M02.01-C096-T01 · Adverse-case definition:** Create a test record for the exact “Clean-build acceptance” source counterexample: “A clean build succeeds only because of undeclared cached files”; state which precondition or invariant it challenges.
- [ ] **UC-M02.01-C096-T02 · Safe fixture boundary:** Define the contained test boundary for “Clean-build acceptance”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M02.01-C096-T03 · Valid control:** Construct a valid “Clean-build acceptance” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M02.01-C096-T04 · Minimal adverse input:** Derive the “Clean-build acceptance” adverse fixture from the control with the smallest documented change needed to reproduce “A clean build succeeds only because of undeclared cached files”; retain that change as reproducible data.
- [ ] **UC-M02.01-C096-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Clean-build acceptance”; require “The acceptance artifact is a linked guest image rather than a host launch script” and forbid a false-success verdict.
- [ ] **UC-M02.01-C096-T06 · Adverse execution:** Exercise the “Clean-build acceptance” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M02.01-C096-T07 · Effect inspection:** Inspect “Clean-build acceptance” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M02.01-C096-T08 · Refusal versus failure:** Confirm the “Clean-build acceptance” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M02.01-C096-T09 · Reset and retention:** Restore only the disposable “Clean-build acceptance” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M02.01-C096-T10 · Negative regression:** Register the “Clean-build acceptance” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M02.01-C097 · Change / failure test

**Original checklist item:** Exercise clean-build acceptance when the selected library-OS configuration changes and a clean guest rebuild is required; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M02.01-C097-T01 · Scenario record:** Write the “Clean-build acceptance” change/failure scenario exactly as supplied: the selected library-OS configuration changes and a clean guest rebuild is required; identify the property that must remain true: “The acceptance artifact is a linked guest image rather than a host launch script”.
- [ ] **UC-M02.01-C097-T02 · Baseline capture:** Create a known-valid “Clean-build acceptance” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M02.01-C097-T03 · Injection map:** Locate the “Clean-build acceptance” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M02.01-C097-T04 · Disposition oracle:** Define the legal intermediate and final “Clean-build acceptance” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M02.01-C097-T05 · Controlled trigger:** Introduce the controlled “Clean-build acceptance” scenario in the disposable fixture: the selected library-OS configuration changes and a clean guest rebuild is required; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M02.01-C097-T06 · Intermediate inspection:** Inspect the “Clean-build acceptance” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M02.01-C097-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Clean-build acceptance”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M02.01-C097-T08 · Stale-evidence cleanup:** Invalidate superseded “Clean-build acceptance” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M02.01-C097-T09 · Repeat and compare:** Repeat the selected “Clean-build acceptance” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M02.01-C097-T10 · Failure evidence:** Publish the “Clean-build acceptance” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M02.01-C098 · Bounds

**Original checklist item:** Choose, document and test limits for build time, temporary storage and clean-build repetitions; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M02.01-C098-T01 · Quantity inventory:** Create a measurement inventory for “Clean-build acceptance”: “Build time, temporary storage and clean-build repetitions”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M02.01-C098-T02 · Measurement method:** Choose how to observe each “Clean-build acceptance” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M02.01-C098-T03 · Budget decision:** Select justified resource and input limits for “Clean-build acceptance”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M02.01-C098-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Clean-build acceptance” cases for “Build time, temporary storage and clean-build repetitions”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M02.01-C098-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Clean-build acceptance” limit; preserve “The acceptance artifact is a linked guest image rather than a host launch script”.
- [ ] **UC-M02.01-C098-T06 · Normal measurement:** Run or review the normal “Clean-build acceptance” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M02.01-C098-T07 · At-limit measurement:** Exercise the “Clean-build acceptance” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M02.01-C098-T08 · Over-limit measurement:** Exercise the “Clean-build acceptance” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M02.01-C098-T09 · Uncovered-scope report:** List the “Clean-build acceptance” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M02.01-C098-T10 · Limit evidence:** Publish the selected “Clean-build acceptance” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M02.01-C099 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for clean-build acceptance with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M02.01-C099-T01 · Event inventory:** List the “Clean-build acceptance” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M02.01-C099-T02 · Diagnostic schema:** Define nonsecret fields for “Clean-build acceptance” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M02.01-C099-T03 · Failure mapping:** Map each documented “Clean-build acceptance” refusal or error to a diagnostic outcome; include “A clean build succeeds only because of undeclared cached files” and prohibit conversion into a success message.
- [ ] **UC-M02.01-C099-T04 · Emission path:** Add the “Clean-build acceptance” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M02.01-C099-T05 · Redaction check:** Test “Clean-build acceptance” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M02.01-C099-T06 · Output budget:** Set and exercise bounded “Clean-build acceptance” message size, rate and retention compatible with “Build time, temporary storage and clean-build repetitions”; define truncation behavior that preserves the final reason.
- [ ] **UC-M02.01-C099-T07 · Success/refusal fixtures:** Capture “Clean-build acceptance” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M02.01-C099-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Clean-build acceptance” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M02.01-C099-T09 · Operator review:** Read the “Clean-build acceptance” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M02.01-C099-T10 · Diagnostic evidence:** Publish redacted “Clean-build acceptance” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M02.01-C100 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for clean-build acceptance; label unexecuted checks as untested.

- [ ] **UC-M02.01-C100-T01 · Evidence inventory:** List the “Clean-build acceptance” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M02.01-C100-T02 · Artifact references:** Record the exact “Clean-build acceptance” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M02.01-C100-T03 · Fixture references:** Attach the “Clean-build acceptance” fixture IDs, input identities and oracle definition; preserve the source counterexample “A clean build succeeds only because of undeclared cached files” as a distinct evidence case.
- [ ] **UC-M02.01-C100-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Clean-build acceptance”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M02.01-C100-T05 · Environment record:** Record the actual “Clean-build acceptance” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M02.01-C100-T06 · Expected versus observed:** Pair every “Clean-build acceptance” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M02.01-C100-T07 · Failure and limit records:** Attach “Clean-build acceptance” change/failure and bounds evidence where required; include uncovered “Build time, temporary storage and clean-build repetitions” and unresolved violations of “The acceptance artifact is a linked guest image rather than a host launch script”.
- [ ] **UC-M02.01-C100-T08 · Evidence hygiene:** Check the “Clean-build acceptance” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M02.01-C100-T09 · Reproduction review:** Have the “Clean-build acceptance” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M02.01-C100-T10 · Acceptance linkage:** Link the “Clean-build acceptance” evidence to its parent and UC-M02.01 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

