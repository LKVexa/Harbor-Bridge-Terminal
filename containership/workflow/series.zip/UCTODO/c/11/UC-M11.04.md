# UC-M11.04 — Leases, fencing and ownership transfer

**To-Do Pack 2.0.0 · Baseline UC-2.2.0 · 100 parent checks × 10 subtasks = 1,000 to-dos**

[Master index](../../INDEX.md) · [Workstream index](../../w/11.md)

| Field | Preserved source value |
|---|---|
| Workstream | 11. Optional multi-host federation |
| Milestone | D |
| Priority | P2 |
| Source assessment | MISSING |
| Scope | optional multi host |
| Dependencies | [UC-M01.05](../01/UC-M01.05.md), [UC-M11.03](../11/UC-M11.03.md) |
| Source checklist pack | 1.0.0 |
| Original reference labels | [S4], [S6]. |

## Original requirement

Use epochs/fencing tokens to prevent old workers from committing after ownership moves or leases expire.

**Original acceptance criterion:** An isolated previous owner cannot mutate committed state after a new owner is activated.

**Source trace:** Original checklist `UC100/c/11/UC-M11.04.md` inside [s/checklists.zip](../../s/checklists.zip); exact parent records in [data/parents.jsonl](../../data/parents.jsonl). Original roadmap lines 1032–1042 are preserved in [s/roadmap.md](../../s/roadmap.md).

## How to use these lists

Every parent statement below is preserved verbatim. Its ten child tasks are proposed decomposition, not implemented capabilities or executed tests. Child IDs append `-T01` through `-T10` to the original parent ID. All begin unchecked / `TODO`. Design/review evidence does not establish runtime enforcement; observe the actual selected target where the parent requires it.

The source dependency graph and selected release profile determine applicability. The numbered child sequence is a local working order, not an added hard dependency graph. An unselected optional feature needs a recorded not-applicable rationale; missing prerequisites for selected work remain blockers. Numerical budgets, backends and trust mechanisms remain decisions unless fixed by the source. Test hostile cases only with synthetic inputs in authorized disposable environments.

## 01. Ownership identity

**Source delivery:** Bind resource ownership to worker, workload, generation and epoch.

**Source invariant:** A display name or connection alone cannot establish current ownership.

**Source negative case:** A reconnected old worker claims ownership using its previous name.

**Source bounded quantities:** Ownership records and lookup time.

### UC-M11.04-C001 · Contract

**Original checklist item:** Specify ownership identity inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M11.04-C001-T01 · Scope statement:** Draft the operation boundary for “Ownership identity” within Leases, fencing and ownership transfer; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M11.04-C001-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Ownership identity”; record each producer, representation and missing-value meaning.
- [ ] **UC-M11.04-C001-T03 · Output inventory:** List the outputs of “Ownership identity” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M11.04-C001-T04 · Field dictionary:** Create a field-and-term dictionary for “Ownership identity”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M11.04-C001-T05 · Prerequisite contract:** Map “Ownership identity” to the source component prerequisites (UC-M01.05, UC-M11.03); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M11.04-C001-T06 · Authority map:** Identify who may produce, change and consume “Ownership identity”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M11.04-C001-T07 · Invariant clause:** Add a normative clause for “Ownership identity” that preserves “A display name or connection alone cannot establish current ownership”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M11.04-C001-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Ownership identity”; include the source counterexample “A reconnected old worker claims ownership using its previous name” and the intended safe disposition.
- [ ] **UC-M11.04-C001-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Ownership records and lookup time” in the “Ownership identity” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M11.04-C001-T10 · Contract review:** Review the “Ownership identity” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M11.04-C002 · Delivery

**Original checklist item:** Bind resource ownership to worker, workload, generation and epoch.

- [ ] **UC-M11.04-C002-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Ownership identity”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M11.04-C002-T02 · Change plan:** Break the source delivery for “Ownership identity” into concrete edit targets and reviewable outputs; keep the UC-M11.04 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M11.04-C002-T03 · Core artifact:** Implement the smallest selected-profile change for “Ownership identity” that realizes this source instruction: Bind resource ownership to worker, workload, generation and epoch.
- [ ] **UC-M11.04-C002-T04 · Concrete realization:** Trace “Ownership identity” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M11.04-C002-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Ownership identity” needed to preserve “A display name or connection alone cannot establish current ownership”; record an enforcement gap where only a model exists.
- [ ] **UC-M11.04-C002-T06 · Dependency connection:** Connect the “Ownership identity” implementation to consensus-backed ownership, lease epochs and commit-time downstream fencing; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M11.04-C002-T07 · Resource behavior:** Account for “Ownership records and lookup time” in “Ownership identity”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M11.04-C002-T08 · Delivery check:** Run the smallest real “Ownership identity” path and its adverse fixture “A reconnected old worker claims ownership using its previous name”; retain actual output, state effects and final disposition.
- [ ] **UC-M11.04-C002-T09 · Patch review:** Review the “Ownership identity” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M11.04-C002-T10 · Delivery handoff:** Publish the “Ownership identity” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M11.04-C003 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: A display name or connection alone cannot establish current ownership. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M11.04-C003-T01 · Named property:** Create a stable property/check name under this parent for “Ownership identity”; copy its required invariant exactly: “A display name or connection alone cannot establish current ownership”.
- [ ] **UC-M11.04-C003-T02 · Observable terms:** Define each term in the “Ownership identity” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M11.04-C003-T03 · Precondition set:** List the preconditions under which “A display name or connection alone cannot establish current ownership” must hold for “Ownership identity”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M11.04-C003-T04 · Transition coverage:** Map the “Ownership identity” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M11.04-C003-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Ownership identity”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M11.04-C003-T06 · Satisfying fixture:** Create a concrete “Ownership identity” case that satisfies “A display name or connection alone cannot establish current ownership”; record its expected observation before running the assertion or review.
- [ ] **UC-M11.04-C003-T07 · Violating fixture:** Create the source counterexample “A reconnected old worker claims ownership using its previous name” for “Ownership identity”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M11.04-C003-T08 · Enforcement evidence:** Exercise the “Ownership identity” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M11.04-C003-T09 · Regression linkage:** Link the “Ownership identity” property to changes in consensus-backed ownership, lease epochs and commit-time downstream fencing; record which dependency or contract changes require rerunning it.
- [ ] **UC-M11.04-C003-T10 · Property disposition:** Compare the satisfying and violating “Ownership identity” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M11.04-C004 · Integration

**Original checklist item:** Integrate ownership identity with consensus-backed ownership, lease epochs and commit-time downstream fencing; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M11.04-C004-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Ownership identity” across consensus-backed ownership, lease epochs and commit-time downstream fencing; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M11.04-C004-T02 · Field mapping:** Map every “Ownership identity” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M11.04-C004-T03 · Prerequisite identities:** Record the actual prerequisites for “Ownership identity” (source dependency list: UC-M01.05, UC-M11.03); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M11.04-C004-T04 · Ownership agreement:** Specify who owns “Ownership identity” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M11.04-C004-T05 · Handoff implementation:** Connect “Ownership identity” through the mapped seam using the real adapter or explicit specification reference; preserve “A display name or connection alone cannot establish current ownership” across the handoff.
- [ ] **UC-M11.04-C004-T06 · Absent-input case:** Omit one required “Ownership identity” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M11.04-C004-T07 · Stale-input case:** Supply an outdated “Ownership identity” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M11.04-C004-T08 · Incompatible-input case:** Supply an incompatible “Ownership identity” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M11.04-C004-T09 · Valid integration trace:** Run a valid “Ownership identity” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M11.04-C004-T10 · Seam review:** Reconcile the “Ownership identity” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M11.04-C005 · Valid-case test

**Original checklist item:** Run a valid-path fixture for ownership identity; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M11.04-C005-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Ownership identity” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M11.04-C005-T02 · Expected-result oracle:** Specify the “Ownership identity” expected result independently of the implementation output; include the property “A display name or connection alone cannot establish current ownership” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M11.04-C005-T03 · Fixture material:** Create the concrete “Ownership identity” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M11.04-C005-T04 · Target preparation:** Prepare the “Ownership identity” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M11.04-C005-T05 · Initial-state record:** Record the initial “Ownership identity” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M11.04-C005-T06 · Valid-path execution:** Execute the “Ownership identity” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M11.04-C005-T07 · Outcome comparison:** Compare every declared “Ownership identity” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M11.04-C005-T08 · State and bounds check:** Inspect the “Ownership identity” ownership/state effects and actual use of “Ownership records and lookup time”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M11.04-C005-T09 · Repeatability check:** Repeat the same “Ownership identity” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M11.04-C005-T10 · Positive evidence:** Attach the “Ownership identity” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M11.04-C006 · Negative test

**Original checklist item:** Negative case: A reconnected old worker claims ownership using its previous name. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M11.04-C006-T01 · Adverse-case definition:** Create a test record for the exact “Ownership identity” source counterexample: “A reconnected old worker claims ownership using its previous name”; state which precondition or invariant it challenges.
- [ ] **UC-M11.04-C006-T02 · Safe fixture boundary:** Define the contained test boundary for “Ownership identity”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M11.04-C006-T03 · Valid control:** Construct a valid “Ownership identity” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M11.04-C006-T04 · Minimal adverse input:** Derive the “Ownership identity” adverse fixture from the control with the smallest documented change needed to reproduce “A reconnected old worker claims ownership using its previous name”; retain that change as reproducible data.
- [ ] **UC-M11.04-C006-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Ownership identity”; require “A display name or connection alone cannot establish current ownership” and forbid a false-success verdict.
- [ ] **UC-M11.04-C006-T06 · Adverse execution:** Exercise the “Ownership identity” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M11.04-C006-T07 · Effect inspection:** Inspect “Ownership identity” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M11.04-C006-T08 · Refusal versus failure:** Confirm the “Ownership identity” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M11.04-C006-T09 · Reset and retention:** Restore only the disposable “Ownership identity” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M11.04-C006-T10 · Negative regression:** Register the “Ownership identity” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M11.04-C007 · Change / failure test

**Original checklist item:** Exercise ownership identity when an isolated previous owner resumes after a new owner has been activated; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M11.04-C007-T01 · Scenario record:** Write the “Ownership identity” change/failure scenario exactly as supplied: an isolated previous owner resumes after a new owner has been activated; identify the property that must remain true: “A display name or connection alone cannot establish current ownership”.
- [ ] **UC-M11.04-C007-T02 · Baseline capture:** Create a known-valid “Ownership identity” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M11.04-C007-T03 · Injection map:** Locate the “Ownership identity” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M11.04-C007-T04 · Disposition oracle:** Define the legal intermediate and final “Ownership identity” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M11.04-C007-T05 · Controlled trigger:** Introduce the controlled “Ownership identity” scenario in the disposable fixture: an isolated previous owner resumes after a new owner has been activated; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M11.04-C007-T06 · Intermediate inspection:** Inspect the “Ownership identity” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M11.04-C007-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Ownership identity”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M11.04-C007-T08 · Stale-evidence cleanup:** Invalidate superseded “Ownership identity” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M11.04-C007-T09 · Repeat and compare:** Repeat the selected “Ownership identity” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M11.04-C007-T10 · Failure evidence:** Publish the “Ownership identity” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M11.04-C008 · Bounds

**Original checklist item:** Choose, document and test limits for ownership records and lookup time; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M11.04-C008-T01 · Quantity inventory:** Create a measurement inventory for “Ownership identity”: “Ownership records and lookup time”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M11.04-C008-T02 · Measurement method:** Choose how to observe each “Ownership identity” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M11.04-C008-T03 · Budget decision:** Select justified resource and input limits for “Ownership identity”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M11.04-C008-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Ownership identity” cases for “Ownership records and lookup time”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M11.04-C008-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Ownership identity” limit; preserve “A display name or connection alone cannot establish current ownership”.
- [ ] **UC-M11.04-C008-T06 · Normal measurement:** Run or review the normal “Ownership identity” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M11.04-C008-T07 · At-limit measurement:** Exercise the “Ownership identity” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M11.04-C008-T08 · Over-limit measurement:** Exercise the “Ownership identity” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M11.04-C008-T09 · Uncovered-scope report:** List the “Ownership identity” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M11.04-C008-T10 · Limit evidence:** Publish the selected “Ownership identity” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M11.04-C009 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for ownership identity with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M11.04-C009-T01 · Event inventory:** List the “Ownership identity” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M11.04-C009-T02 · Diagnostic schema:** Define nonsecret fields for “Ownership identity” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M11.04-C009-T03 · Failure mapping:** Map each documented “Ownership identity” refusal or error to a diagnostic outcome; include “A reconnected old worker claims ownership using its previous name” and prohibit conversion into a success message.
- [ ] **UC-M11.04-C009-T04 · Emission path:** Add the “Ownership identity” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M11.04-C009-T05 · Redaction check:** Test “Ownership identity” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M11.04-C009-T06 · Output budget:** Set and exercise bounded “Ownership identity” message size, rate and retention compatible with “Ownership records and lookup time”; define truncation behavior that preserves the final reason.
- [ ] **UC-M11.04-C009-T07 · Success/refusal fixtures:** Capture “Ownership identity” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M11.04-C009-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Ownership identity” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M11.04-C009-T09 · Operator review:** Read the “Ownership identity” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M11.04-C009-T10 · Diagnostic evidence:** Publish redacted “Ownership identity” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M11.04-C010 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for ownership identity; label unexecuted checks as untested.

- [ ] **UC-M11.04-C010-T01 · Evidence inventory:** List the “Ownership identity” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M11.04-C010-T02 · Artifact references:** Record the exact “Ownership identity” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M11.04-C010-T03 · Fixture references:** Attach the “Ownership identity” fixture IDs, input identities and oracle definition; preserve the source counterexample “A reconnected old worker claims ownership using its previous name” as a distinct evidence case.
- [ ] **UC-M11.04-C010-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Ownership identity”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M11.04-C010-T05 · Environment record:** Record the actual “Ownership identity” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M11.04-C010-T06 · Expected versus observed:** Pair every “Ownership identity” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M11.04-C010-T07 · Failure and limit records:** Attach “Ownership identity” change/failure and bounds evidence where required; include uncovered “Ownership records and lookup time” and unresolved violations of “A display name or connection alone cannot establish current ownership”.
- [ ] **UC-M11.04-C010-T08 · Evidence hygiene:** Check the “Ownership identity” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M11.04-C010-T09 · Reproduction review:** Have the “Ownership identity” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M11.04-C010-T10 · Acceptance linkage:** Link the “Ownership identity” evidence to its parent and UC-M11.04 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 02. Lease semantics

**Source delivery:** Define lease duration, renewal and expiry using the selected timing assumptions.

**Source invariant:** Lease authority is bounded and explicitly conditional on its clock model.

**Source negative case:** A worker treats an expired lease as indefinitely valid.

**Source bounded quantities:** Lease lifetime and renewal rate.

### UC-M11.04-C011 · Contract

**Original checklist item:** Specify lease semantics inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M11.04-C011-T01 · Scope statement:** Draft the operation boundary for “Lease semantics” within Leases, fencing and ownership transfer; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M11.04-C011-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Lease semantics”; record each producer, representation and missing-value meaning.
- [ ] **UC-M11.04-C011-T03 · Output inventory:** List the outputs of “Lease semantics” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M11.04-C011-T04 · Field dictionary:** Create a field-and-term dictionary for “Lease semantics”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M11.04-C011-T05 · Prerequisite contract:** Map “Lease semantics” to the source component prerequisites (UC-M01.05, UC-M11.03); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M11.04-C011-T06 · Authority map:** Identify who may produce, change and consume “Lease semantics”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M11.04-C011-T07 · Invariant clause:** Add a normative clause for “Lease semantics” that preserves “Lease authority is bounded and explicitly conditional on its clock model”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M11.04-C011-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Lease semantics”; include the source counterexample “A worker treats an expired lease as indefinitely valid” and the intended safe disposition.
- [ ] **UC-M11.04-C011-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Lease lifetime and renewal rate” in the “Lease semantics” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M11.04-C011-T10 · Contract review:** Review the “Lease semantics” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M11.04-C012 · Delivery

**Original checklist item:** Define lease duration, renewal and expiry using the selected timing assumptions.

- [ ] **UC-M11.04-C012-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Lease semantics”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M11.04-C012-T02 · Change plan:** Break the source delivery for “Lease semantics” into concrete edit targets and reviewable outputs; keep the UC-M11.04 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M11.04-C012-T03 · Core artifact:** Create the “Lease semantics” model, schema or inventory that realizes this source instruction: Define lease duration, renewal and expiry using the selected timing assumptions.
- [ ] **UC-M11.04-C012-T04 · Concrete realization:** Populate “Lease semantics” with one concrete worked case; map every required entity or field to its source and flag any unmapped entry.
- [ ] **UC-M11.04-C012-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Lease semantics” needed to preserve “Lease authority is bounded and explicitly conditional on its clock model”; record an enforcement gap where only a model exists.
- [ ] **UC-M11.04-C012-T06 · Dependency connection:** Connect the “Lease semantics” implementation to consensus-backed ownership, lease epochs and commit-time downstream fencing; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M11.04-C012-T07 · Resource behavior:** Account for “Lease lifetime and renewal rate” in “Lease semantics”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M11.04-C012-T08 · Delivery check:** Run the smallest real “Lease semantics” path and its adverse fixture “A worker treats an expired lease as indefinitely valid”; retain actual output, state effects and final disposition.
- [ ] **UC-M11.04-C012-T09 · Patch review:** Review the “Lease semantics” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M11.04-C012-T10 · Delivery handoff:** Publish the “Lease semantics” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M11.04-C013 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Lease authority is bounded and explicitly conditional on its clock model. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M11.04-C013-T01 · Named property:** Create a stable property/check name under this parent for “Lease semantics”; copy its required invariant exactly: “Lease authority is bounded and explicitly conditional on its clock model”.
- [ ] **UC-M11.04-C013-T02 · Observable terms:** Define each term in the “Lease semantics” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M11.04-C013-T03 · Precondition set:** List the preconditions under which “Lease authority is bounded and explicitly conditional on its clock model” must hold for “Lease semantics”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M11.04-C013-T04 · Transition coverage:** Map the “Lease semantics” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M11.04-C013-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Lease semantics”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M11.04-C013-T06 · Satisfying fixture:** Create a concrete “Lease semantics” case that satisfies “Lease authority is bounded and explicitly conditional on its clock model”; record its expected observation before running the assertion or review.
- [ ] **UC-M11.04-C013-T07 · Violating fixture:** Create the source counterexample “A worker treats an expired lease as indefinitely valid” for “Lease semantics”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M11.04-C013-T08 · Enforcement evidence:** Exercise the “Lease semantics” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M11.04-C013-T09 · Regression linkage:** Link the “Lease semantics” property to changes in consensus-backed ownership, lease epochs and commit-time downstream fencing; record which dependency or contract changes require rerunning it.
- [ ] **UC-M11.04-C013-T10 · Property disposition:** Compare the satisfying and violating “Lease semantics” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M11.04-C014 · Integration

**Original checklist item:** Integrate lease semantics with consensus-backed ownership, lease epochs and commit-time downstream fencing; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M11.04-C014-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Lease semantics” across consensus-backed ownership, lease epochs and commit-time downstream fencing; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M11.04-C014-T02 · Field mapping:** Map every “Lease semantics” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M11.04-C014-T03 · Prerequisite identities:** Record the actual prerequisites for “Lease semantics” (source dependency list: UC-M01.05, UC-M11.03); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M11.04-C014-T04 · Ownership agreement:** Specify who owns “Lease semantics” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M11.04-C014-T05 · Handoff implementation:** Connect “Lease semantics” through the mapped seam using the real adapter or explicit specification reference; preserve “Lease authority is bounded and explicitly conditional on its clock model” across the handoff.
- [ ] **UC-M11.04-C014-T06 · Absent-input case:** Omit one required “Lease semantics” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M11.04-C014-T07 · Stale-input case:** Supply an outdated “Lease semantics” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M11.04-C014-T08 · Incompatible-input case:** Supply an incompatible “Lease semantics” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M11.04-C014-T09 · Valid integration trace:** Run a valid “Lease semantics” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M11.04-C014-T10 · Seam review:** Reconcile the “Lease semantics” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M11.04-C015 · Valid-case test

**Original checklist item:** Run a valid-path fixture for lease semantics; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M11.04-C015-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Lease semantics” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M11.04-C015-T02 · Expected-result oracle:** Specify the “Lease semantics” expected result independently of the implementation output; include the property “Lease authority is bounded and explicitly conditional on its clock model” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M11.04-C015-T03 · Fixture material:** Create the concrete “Lease semantics” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M11.04-C015-T04 · Target preparation:** Prepare the “Lease semantics” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M11.04-C015-T05 · Initial-state record:** Record the initial “Lease semantics” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M11.04-C015-T06 · Valid-path execution:** Execute the “Lease semantics” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M11.04-C015-T07 · Outcome comparison:** Compare every declared “Lease semantics” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M11.04-C015-T08 · State and bounds check:** Inspect the “Lease semantics” ownership/state effects and actual use of “Lease lifetime and renewal rate”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M11.04-C015-T09 · Repeatability check:** Repeat the same “Lease semantics” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M11.04-C015-T10 · Positive evidence:** Attach the “Lease semantics” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M11.04-C016 · Negative test

**Original checklist item:** Negative case: A worker treats an expired lease as indefinitely valid. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M11.04-C016-T01 · Adverse-case definition:** Create a test record for the exact “Lease semantics” source counterexample: “A worker treats an expired lease as indefinitely valid”; state which precondition or invariant it challenges.
- [ ] **UC-M11.04-C016-T02 · Safe fixture boundary:** Define the contained test boundary for “Lease semantics”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M11.04-C016-T03 · Valid control:** Construct a valid “Lease semantics” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M11.04-C016-T04 · Minimal adverse input:** Derive the “Lease semantics” adverse fixture from the control with the smallest documented change needed to reproduce “A worker treats an expired lease as indefinitely valid”; retain that change as reproducible data.
- [ ] **UC-M11.04-C016-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Lease semantics”; require “Lease authority is bounded and explicitly conditional on its clock model” and forbid a false-success verdict.
- [ ] **UC-M11.04-C016-T06 · Adverse execution:** Exercise the “Lease semantics” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M11.04-C016-T07 · Effect inspection:** Inspect “Lease semantics” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M11.04-C016-T08 · Refusal versus failure:** Confirm the “Lease semantics” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M11.04-C016-T09 · Reset and retention:** Restore only the disposable “Lease semantics” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M11.04-C016-T10 · Negative regression:** Register the “Lease semantics” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M11.04-C017 · Change / failure test

**Original checklist item:** Exercise lease semantics when an isolated previous owner resumes after a new owner has been activated; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M11.04-C017-T01 · Scenario record:** Write the “Lease semantics” change/failure scenario exactly as supplied: an isolated previous owner resumes after a new owner has been activated; identify the property that must remain true: “Lease authority is bounded and explicitly conditional on its clock model”.
- [ ] **UC-M11.04-C017-T02 · Baseline capture:** Create a known-valid “Lease semantics” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M11.04-C017-T03 · Injection map:** Locate the “Lease semantics” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M11.04-C017-T04 · Disposition oracle:** Define the legal intermediate and final “Lease semantics” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M11.04-C017-T05 · Controlled trigger:** Introduce the controlled “Lease semantics” scenario in the disposable fixture: an isolated previous owner resumes after a new owner has been activated; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M11.04-C017-T06 · Intermediate inspection:** Inspect the “Lease semantics” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M11.04-C017-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Lease semantics”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M11.04-C017-T08 · Stale-evidence cleanup:** Invalidate superseded “Lease semantics” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M11.04-C017-T09 · Repeat and compare:** Repeat the selected “Lease semantics” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M11.04-C017-T10 · Failure evidence:** Publish the “Lease semantics” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M11.04-C018 · Bounds

**Original checklist item:** Choose, document and test limits for lease lifetime and renewal rate; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M11.04-C018-T01 · Quantity inventory:** Create a measurement inventory for “Lease semantics”: “Lease lifetime and renewal rate”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M11.04-C018-T02 · Measurement method:** Choose how to observe each “Lease semantics” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M11.04-C018-T03 · Budget decision:** Select justified resource and input limits for “Lease semantics”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M11.04-C018-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Lease semantics” cases for “Lease lifetime and renewal rate”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M11.04-C018-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Lease semantics” limit; preserve “Lease authority is bounded and explicitly conditional on its clock model”.
- [ ] **UC-M11.04-C018-T06 · Normal measurement:** Run or review the normal “Lease semantics” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M11.04-C018-T07 · At-limit measurement:** Exercise the “Lease semantics” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M11.04-C018-T08 · Over-limit measurement:** Exercise the “Lease semantics” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M11.04-C018-T09 · Uncovered-scope report:** List the “Lease semantics” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M11.04-C018-T10 · Limit evidence:** Publish the selected “Lease semantics” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M11.04-C019 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for lease semantics with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M11.04-C019-T01 · Event inventory:** List the “Lease semantics” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M11.04-C019-T02 · Diagnostic schema:** Define nonsecret fields for “Lease semantics” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M11.04-C019-T03 · Failure mapping:** Map each documented “Lease semantics” refusal or error to a diagnostic outcome; include “A worker treats an expired lease as indefinitely valid” and prohibit conversion into a success message.
- [ ] **UC-M11.04-C019-T04 · Emission path:** Add the “Lease semantics” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M11.04-C019-T05 · Redaction check:** Test “Lease semantics” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M11.04-C019-T06 · Output budget:** Set and exercise bounded “Lease semantics” message size, rate and retention compatible with “Lease lifetime and renewal rate”; define truncation behavior that preserves the final reason.
- [ ] **UC-M11.04-C019-T07 · Success/refusal fixtures:** Capture “Lease semantics” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M11.04-C019-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Lease semantics” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M11.04-C019-T09 · Operator review:** Read the “Lease semantics” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M11.04-C019-T10 · Diagnostic evidence:** Publish redacted “Lease semantics” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M11.04-C020 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for lease semantics; label unexecuted checks as untested.

- [ ] **UC-M11.04-C020-T01 · Evidence inventory:** List the “Lease semantics” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M11.04-C020-T02 · Artifact references:** Record the exact “Lease semantics” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M11.04-C020-T03 · Fixture references:** Attach the “Lease semantics” fixture IDs, input identities and oracle definition; preserve the source counterexample “A worker treats an expired lease as indefinitely valid” as a distinct evidence case.
- [ ] **UC-M11.04-C020-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Lease semantics”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M11.04-C020-T05 · Environment record:** Record the actual “Lease semantics” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M11.04-C020-T06 · Expected versus observed:** Pair every “Lease semantics” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M11.04-C020-T07 · Failure and limit records:** Attach “Lease semantics” change/failure and bounds evidence where required; include uncovered “Lease lifetime and renewal rate” and unresolved violations of “Lease authority is bounded and explicitly conditional on its clock model”.
- [ ] **UC-M11.04-C020-T08 · Evidence hygiene:** Check the “Lease semantics” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M11.04-C020-T09 · Reproduction review:** Have the “Lease semantics” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M11.04-C020-T10 · Acceptance linkage:** Link the “Lease semantics” evidence to its parent and UC-M11.04 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 03. Fencing token allocation

**Source delivery:** Issue monotonic or otherwise correctly ordered fencing authority through the control store.

**Source invariant:** A newer owner has distinguishable authority from an older owner.

**Source negative case:** Two owners receive indistinguishable fencing tokens.

**Source bounded quantities:** Token range and allocation concurrency.

### UC-M11.04-C021 · Contract

**Original checklist item:** Specify fencing token allocation inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M11.04-C021-T01 · Scope statement:** Draft the operation boundary for “Fencing token allocation” within Leases, fencing and ownership transfer; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M11.04-C021-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Fencing token allocation”; record each producer, representation and missing-value meaning.
- [ ] **UC-M11.04-C021-T03 · Output inventory:** List the outputs of “Fencing token allocation” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M11.04-C021-T04 · Field dictionary:** Create a field-and-term dictionary for “Fencing token allocation”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M11.04-C021-T05 · Prerequisite contract:** Map “Fencing token allocation” to the source component prerequisites (UC-M01.05, UC-M11.03); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M11.04-C021-T06 · Authority map:** Identify who may produce, change and consume “Fencing token allocation”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M11.04-C021-T07 · Invariant clause:** Add a normative clause for “Fencing token allocation” that preserves “A newer owner has distinguishable authority from an older owner”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M11.04-C021-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Fencing token allocation”; include the source counterexample “Two owners receive indistinguishable fencing tokens” and the intended safe disposition.
- [ ] **UC-M11.04-C021-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Token range and allocation concurrency” in the “Fencing token allocation” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M11.04-C021-T10 · Contract review:** Review the “Fencing token allocation” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M11.04-C022 · Delivery

**Original checklist item:** Issue monotonic or otherwise correctly ordered fencing authority through the control store.

- [ ] **UC-M11.04-C022-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Fencing token allocation”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M11.04-C022-T02 · Change plan:** Break the source delivery for “Fencing token allocation” into concrete edit targets and reviewable outputs; keep the UC-M11.04 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M11.04-C022-T03 · Core artifact:** Implement the smallest selected-profile change for “Fencing token allocation” that realizes this source instruction: Issue monotonic or otherwise correctly ordered fencing authority through the control store.
- [ ] **UC-M11.04-C022-T04 · Concrete realization:** Trace “Fencing token allocation” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M11.04-C022-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Fencing token allocation” needed to preserve “A newer owner has distinguishable authority from an older owner”; record an enforcement gap where only a model exists.
- [ ] **UC-M11.04-C022-T06 · Dependency connection:** Connect the “Fencing token allocation” implementation to consensus-backed ownership, lease epochs and commit-time downstream fencing; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M11.04-C022-T07 · Resource behavior:** Account for “Token range and allocation concurrency” in “Fencing token allocation”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M11.04-C022-T08 · Delivery check:** Run the smallest real “Fencing token allocation” path and its adverse fixture “Two owners receive indistinguishable fencing tokens”; retain actual output, state effects and final disposition.
- [ ] **UC-M11.04-C022-T09 · Patch review:** Review the “Fencing token allocation” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M11.04-C022-T10 · Delivery handoff:** Publish the “Fencing token allocation” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M11.04-C023 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: A newer owner has distinguishable authority from an older owner. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M11.04-C023-T01 · Named property:** Create a stable property/check name under this parent for “Fencing token allocation”; copy its required invariant exactly: “A newer owner has distinguishable authority from an older owner”.
- [ ] **UC-M11.04-C023-T02 · Observable terms:** Define each term in the “Fencing token allocation” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M11.04-C023-T03 · Precondition set:** List the preconditions under which “A newer owner has distinguishable authority from an older owner” must hold for “Fencing token allocation”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M11.04-C023-T04 · Transition coverage:** Map the “Fencing token allocation” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M11.04-C023-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Fencing token allocation”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M11.04-C023-T06 · Satisfying fixture:** Create a concrete “Fencing token allocation” case that satisfies “A newer owner has distinguishable authority from an older owner”; record its expected observation before running the assertion or review.
- [ ] **UC-M11.04-C023-T07 · Violating fixture:** Create the source counterexample “Two owners receive indistinguishable fencing tokens” for “Fencing token allocation”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M11.04-C023-T08 · Enforcement evidence:** Exercise the “Fencing token allocation” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M11.04-C023-T09 · Regression linkage:** Link the “Fencing token allocation” property to changes in consensus-backed ownership, lease epochs and commit-time downstream fencing; record which dependency or contract changes require rerunning it.
- [ ] **UC-M11.04-C023-T10 · Property disposition:** Compare the satisfying and violating “Fencing token allocation” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M11.04-C024 · Integration

**Original checklist item:** Integrate fencing token allocation with consensus-backed ownership, lease epochs and commit-time downstream fencing; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M11.04-C024-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Fencing token allocation” across consensus-backed ownership, lease epochs and commit-time downstream fencing; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M11.04-C024-T02 · Field mapping:** Map every “Fencing token allocation” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M11.04-C024-T03 · Prerequisite identities:** Record the actual prerequisites for “Fencing token allocation” (source dependency list: UC-M01.05, UC-M11.03); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M11.04-C024-T04 · Ownership agreement:** Specify who owns “Fencing token allocation” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M11.04-C024-T05 · Handoff implementation:** Connect “Fencing token allocation” through the mapped seam using the real adapter or explicit specification reference; preserve “A newer owner has distinguishable authority from an older owner” across the handoff.
- [ ] **UC-M11.04-C024-T06 · Absent-input case:** Omit one required “Fencing token allocation” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M11.04-C024-T07 · Stale-input case:** Supply an outdated “Fencing token allocation” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M11.04-C024-T08 · Incompatible-input case:** Supply an incompatible “Fencing token allocation” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M11.04-C024-T09 · Valid integration trace:** Run a valid “Fencing token allocation” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M11.04-C024-T10 · Seam review:** Reconcile the “Fencing token allocation” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M11.04-C025 · Valid-case test

**Original checklist item:** Run a valid-path fixture for fencing token allocation; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M11.04-C025-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Fencing token allocation” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M11.04-C025-T02 · Expected-result oracle:** Specify the “Fencing token allocation” expected result independently of the implementation output; include the property “A newer owner has distinguishable authority from an older owner” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M11.04-C025-T03 · Fixture material:** Create the concrete “Fencing token allocation” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M11.04-C025-T04 · Target preparation:** Prepare the “Fencing token allocation” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M11.04-C025-T05 · Initial-state record:** Record the initial “Fencing token allocation” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M11.04-C025-T06 · Valid-path execution:** Execute the “Fencing token allocation” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M11.04-C025-T07 · Outcome comparison:** Compare every declared “Fencing token allocation” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M11.04-C025-T08 · State and bounds check:** Inspect the “Fencing token allocation” ownership/state effects and actual use of “Token range and allocation concurrency”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M11.04-C025-T09 · Repeatability check:** Repeat the same “Fencing token allocation” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M11.04-C025-T10 · Positive evidence:** Attach the “Fencing token allocation” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M11.04-C026 · Negative test

**Original checklist item:** Negative case: Two owners receive indistinguishable fencing tokens. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M11.04-C026-T01 · Adverse-case definition:** Create a test record for the exact “Fencing token allocation” source counterexample: “Two owners receive indistinguishable fencing tokens”; state which precondition or invariant it challenges.
- [ ] **UC-M11.04-C026-T02 · Safe fixture boundary:** Define the contained test boundary for “Fencing token allocation”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M11.04-C026-T03 · Valid control:** Construct a valid “Fencing token allocation” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M11.04-C026-T04 · Minimal adverse input:** Derive the “Fencing token allocation” adverse fixture from the control with the smallest documented change needed to reproduce “Two owners receive indistinguishable fencing tokens”; retain that change as reproducible data.
- [ ] **UC-M11.04-C026-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Fencing token allocation”; require “A newer owner has distinguishable authority from an older owner” and forbid a false-success verdict.
- [ ] **UC-M11.04-C026-T06 · Adverse execution:** Exercise the “Fencing token allocation” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M11.04-C026-T07 · Effect inspection:** Inspect “Fencing token allocation” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M11.04-C026-T08 · Refusal versus failure:** Confirm the “Fencing token allocation” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M11.04-C026-T09 · Reset and retention:** Restore only the disposable “Fencing token allocation” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M11.04-C026-T10 · Negative regression:** Register the “Fencing token allocation” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M11.04-C027 · Change / failure test

**Original checklist item:** Exercise fencing token allocation when an isolated previous owner resumes after a new owner has been activated; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M11.04-C027-T01 · Scenario record:** Write the “Fencing token allocation” change/failure scenario exactly as supplied: an isolated previous owner resumes after a new owner has been activated; identify the property that must remain true: “A newer owner has distinguishable authority from an older owner”.
- [ ] **UC-M11.04-C027-T02 · Baseline capture:** Create a known-valid “Fencing token allocation” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M11.04-C027-T03 · Injection map:** Locate the “Fencing token allocation” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M11.04-C027-T04 · Disposition oracle:** Define the legal intermediate and final “Fencing token allocation” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M11.04-C027-T05 · Controlled trigger:** Introduce the controlled “Fencing token allocation” scenario in the disposable fixture: an isolated previous owner resumes after a new owner has been activated; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M11.04-C027-T06 · Intermediate inspection:** Inspect the “Fencing token allocation” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M11.04-C027-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Fencing token allocation”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M11.04-C027-T08 · Stale-evidence cleanup:** Invalidate superseded “Fencing token allocation” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M11.04-C027-T09 · Repeat and compare:** Repeat the selected “Fencing token allocation” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M11.04-C027-T10 · Failure evidence:** Publish the “Fencing token allocation” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M11.04-C028 · Bounds

**Original checklist item:** Choose, document and test limits for token range and allocation concurrency; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M11.04-C028-T01 · Quantity inventory:** Create a measurement inventory for “Fencing token allocation”: “Token range and allocation concurrency”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M11.04-C028-T02 · Measurement method:** Choose how to observe each “Fencing token allocation” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M11.04-C028-T03 · Budget decision:** Select justified resource and input limits for “Fencing token allocation”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M11.04-C028-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Fencing token allocation” cases for “Token range and allocation concurrency”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M11.04-C028-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Fencing token allocation” limit; preserve “A newer owner has distinguishable authority from an older owner”.
- [ ] **UC-M11.04-C028-T06 · Normal measurement:** Run or review the normal “Fencing token allocation” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M11.04-C028-T07 · At-limit measurement:** Exercise the “Fencing token allocation” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M11.04-C028-T08 · Over-limit measurement:** Exercise the “Fencing token allocation” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M11.04-C028-T09 · Uncovered-scope report:** List the “Fencing token allocation” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M11.04-C028-T10 · Limit evidence:** Publish the selected “Fencing token allocation” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M11.04-C029 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for fencing token allocation with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M11.04-C029-T01 · Event inventory:** List the “Fencing token allocation” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M11.04-C029-T02 · Diagnostic schema:** Define nonsecret fields for “Fencing token allocation” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M11.04-C029-T03 · Failure mapping:** Map each documented “Fencing token allocation” refusal or error to a diagnostic outcome; include “Two owners receive indistinguishable fencing tokens” and prohibit conversion into a success message.
- [ ] **UC-M11.04-C029-T04 · Emission path:** Add the “Fencing token allocation” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M11.04-C029-T05 · Redaction check:** Test “Fencing token allocation” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M11.04-C029-T06 · Output budget:** Set and exercise bounded “Fencing token allocation” message size, rate and retention compatible with “Token range and allocation concurrency”; define truncation behavior that preserves the final reason.
- [ ] **UC-M11.04-C029-T07 · Success/refusal fixtures:** Capture “Fencing token allocation” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M11.04-C029-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Fencing token allocation” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M11.04-C029-T09 · Operator review:** Read the “Fencing token allocation” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M11.04-C029-T10 · Diagnostic evidence:** Publish redacted “Fencing token allocation” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M11.04-C030 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for fencing token allocation; label unexecuted checks as untested.

- [ ] **UC-M11.04-C030-T01 · Evidence inventory:** List the “Fencing token allocation” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M11.04-C030-T02 · Artifact references:** Record the exact “Fencing token allocation” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M11.04-C030-T03 · Fixture references:** Attach the “Fencing token allocation” fixture IDs, input identities and oracle definition; preserve the source counterexample “Two owners receive indistinguishable fencing tokens” as a distinct evidence case.
- [ ] **UC-M11.04-C030-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Fencing token allocation”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M11.04-C030-T05 · Environment record:** Record the actual “Fencing token allocation” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M11.04-C030-T06 · Expected versus observed:** Pair every “Fencing token allocation” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M11.04-C030-T07 · Failure and limit records:** Attach “Fencing token allocation” change/failure and bounds evidence where required; include uncovered “Token range and allocation concurrency” and unresolved violations of “A newer owner has distinguishable authority from an older owner”.
- [ ] **UC-M11.04-C030-T08 · Evidence hygiene:** Check the “Fencing token allocation” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M11.04-C030-T09 · Reproduction review:** Have the “Fencing token allocation” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M11.04-C030-T10 · Acceptance linkage:** Link the “Fencing token allocation” evidence to its parent and UC-M11.04 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 04. Commit-time fencing

**Source delivery:** Validate current fencing authority at the actual state/effect commit boundary.

**Source invariant:** An old owner cannot commit merely because its request was once accepted.

**Source negative case:** A delayed old-owner write arrives after new ownership activation.

**Source bounded quantities:** Commit checks and validation latency.

### UC-M11.04-C031 · Contract

**Original checklist item:** Specify commit-time fencing inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M11.04-C031-T01 · Scope statement:** Draft the operation boundary for “Commit-time fencing” within Leases, fencing and ownership transfer; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M11.04-C031-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Commit-time fencing”; record each producer, representation and missing-value meaning.
- [ ] **UC-M11.04-C031-T03 · Output inventory:** List the outputs of “Commit-time fencing” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M11.04-C031-T04 · Field dictionary:** Create a field-and-term dictionary for “Commit-time fencing”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M11.04-C031-T05 · Prerequisite contract:** Map “Commit-time fencing” to the source component prerequisites (UC-M01.05, UC-M11.03); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M11.04-C031-T06 · Authority map:** Identify who may produce, change and consume “Commit-time fencing”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M11.04-C031-T07 · Invariant clause:** Add a normative clause for “Commit-time fencing” that preserves “An old owner cannot commit merely because its request was once accepted”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M11.04-C031-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Commit-time fencing”; include the source counterexample “A delayed old-owner write arrives after new ownership activation” and the intended safe disposition.
- [ ] **UC-M11.04-C031-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Commit checks and validation latency” in the “Commit-time fencing” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M11.04-C031-T10 · Contract review:** Review the “Commit-time fencing” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M11.04-C032 · Delivery

**Original checklist item:** Validate current fencing authority at the actual state/effect commit boundary.

- [ ] **UC-M11.04-C032-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Commit-time fencing”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M11.04-C032-T02 · Change plan:** Break the source delivery for “Commit-time fencing” into concrete edit targets and reviewable outputs; keep the UC-M11.04 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M11.04-C032-T03 · Core artifact:** Implement the smallest selected-profile change for “Commit-time fencing” that realizes this source instruction: Validate current fencing authority at the actual state/effect commit boundary.
- [ ] **UC-M11.04-C032-T04 · Concrete realization:** Trace “Commit-time fencing” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M11.04-C032-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Commit-time fencing” needed to preserve “An old owner cannot commit merely because its request was once accepted”; record an enforcement gap where only a model exists.
- [ ] **UC-M11.04-C032-T06 · Dependency connection:** Connect the “Commit-time fencing” implementation to consensus-backed ownership, lease epochs and commit-time downstream fencing; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M11.04-C032-T07 · Resource behavior:** Account for “Commit checks and validation latency” in “Commit-time fencing”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M11.04-C032-T08 · Delivery check:** Run the smallest real “Commit-time fencing” path and its adverse fixture “A delayed old-owner write arrives after new ownership activation”; retain actual output, state effects and final disposition.
- [ ] **UC-M11.04-C032-T09 · Patch review:** Review the “Commit-time fencing” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M11.04-C032-T10 · Delivery handoff:** Publish the “Commit-time fencing” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M11.04-C033 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: An old owner cannot commit merely because its request was once accepted. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M11.04-C033-T01 · Named property:** Create a stable property/check name under this parent for “Commit-time fencing”; copy its required invariant exactly: “An old owner cannot commit merely because its request was once accepted”.
- [ ] **UC-M11.04-C033-T02 · Observable terms:** Define each term in the “Commit-time fencing” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M11.04-C033-T03 · Precondition set:** List the preconditions under which “An old owner cannot commit merely because its request was once accepted” must hold for “Commit-time fencing”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M11.04-C033-T04 · Transition coverage:** Map the “Commit-time fencing” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M11.04-C033-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Commit-time fencing”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M11.04-C033-T06 · Satisfying fixture:** Create a concrete “Commit-time fencing” case that satisfies “An old owner cannot commit merely because its request was once accepted”; record its expected observation before running the assertion or review.
- [ ] **UC-M11.04-C033-T07 · Violating fixture:** Create the source counterexample “A delayed old-owner write arrives after new ownership activation” for “Commit-time fencing”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M11.04-C033-T08 · Enforcement evidence:** Exercise the “Commit-time fencing” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M11.04-C033-T09 · Regression linkage:** Link the “Commit-time fencing” property to changes in consensus-backed ownership, lease epochs and commit-time downstream fencing; record which dependency or contract changes require rerunning it.
- [ ] **UC-M11.04-C033-T10 · Property disposition:** Compare the satisfying and violating “Commit-time fencing” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M11.04-C034 · Integration

**Original checklist item:** Integrate commit-time fencing with consensus-backed ownership, lease epochs and commit-time downstream fencing; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M11.04-C034-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Commit-time fencing” across consensus-backed ownership, lease epochs and commit-time downstream fencing; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M11.04-C034-T02 · Field mapping:** Map every “Commit-time fencing” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M11.04-C034-T03 · Prerequisite identities:** Record the actual prerequisites for “Commit-time fencing” (source dependency list: UC-M01.05, UC-M11.03); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M11.04-C034-T04 · Ownership agreement:** Specify who owns “Commit-time fencing” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M11.04-C034-T05 · Handoff implementation:** Connect “Commit-time fencing” through the mapped seam using the real adapter or explicit specification reference; preserve “An old owner cannot commit merely because its request was once accepted” across the handoff.
- [ ] **UC-M11.04-C034-T06 · Absent-input case:** Omit one required “Commit-time fencing” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M11.04-C034-T07 · Stale-input case:** Supply an outdated “Commit-time fencing” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M11.04-C034-T08 · Incompatible-input case:** Supply an incompatible “Commit-time fencing” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M11.04-C034-T09 · Valid integration trace:** Run a valid “Commit-time fencing” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M11.04-C034-T10 · Seam review:** Reconcile the “Commit-time fencing” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M11.04-C035 · Valid-case test

**Original checklist item:** Run a valid-path fixture for commit-time fencing; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M11.04-C035-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Commit-time fencing” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M11.04-C035-T02 · Expected-result oracle:** Specify the “Commit-time fencing” expected result independently of the implementation output; include the property “An old owner cannot commit merely because its request was once accepted” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M11.04-C035-T03 · Fixture material:** Create the concrete “Commit-time fencing” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M11.04-C035-T04 · Target preparation:** Prepare the “Commit-time fencing” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M11.04-C035-T05 · Initial-state record:** Record the initial “Commit-time fencing” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M11.04-C035-T06 · Valid-path execution:** Execute the “Commit-time fencing” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M11.04-C035-T07 · Outcome comparison:** Compare every declared “Commit-time fencing” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M11.04-C035-T08 · State and bounds check:** Inspect the “Commit-time fencing” ownership/state effects and actual use of “Commit checks and validation latency”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M11.04-C035-T09 · Repeatability check:** Repeat the same “Commit-time fencing” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M11.04-C035-T10 · Positive evidence:** Attach the “Commit-time fencing” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M11.04-C036 · Negative test

**Original checklist item:** Negative case: A delayed old-owner write arrives after new ownership activation. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M11.04-C036-T01 · Adverse-case definition:** Create a test record for the exact “Commit-time fencing” source counterexample: “A delayed old-owner write arrives after new ownership activation”; state which precondition or invariant it challenges.
- [ ] **UC-M11.04-C036-T02 · Safe fixture boundary:** Define the contained test boundary for “Commit-time fencing”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M11.04-C036-T03 · Valid control:** Construct a valid “Commit-time fencing” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M11.04-C036-T04 · Minimal adverse input:** Derive the “Commit-time fencing” adverse fixture from the control with the smallest documented change needed to reproduce “A delayed old-owner write arrives after new ownership activation”; retain that change as reproducible data.
- [ ] **UC-M11.04-C036-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Commit-time fencing”; require “An old owner cannot commit merely because its request was once accepted” and forbid a false-success verdict.
- [ ] **UC-M11.04-C036-T06 · Adverse execution:** Exercise the “Commit-time fencing” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M11.04-C036-T07 · Effect inspection:** Inspect “Commit-time fencing” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M11.04-C036-T08 · Refusal versus failure:** Confirm the “Commit-time fencing” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M11.04-C036-T09 · Reset and retention:** Restore only the disposable “Commit-time fencing” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M11.04-C036-T10 · Negative regression:** Register the “Commit-time fencing” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M11.04-C037 · Change / failure test

**Original checklist item:** Exercise commit-time fencing when an isolated previous owner resumes after a new owner has been activated; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M11.04-C037-T01 · Scenario record:** Write the “Commit-time fencing” change/failure scenario exactly as supplied: an isolated previous owner resumes after a new owner has been activated; identify the property that must remain true: “An old owner cannot commit merely because its request was once accepted”.
- [ ] **UC-M11.04-C037-T02 · Baseline capture:** Create a known-valid “Commit-time fencing” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M11.04-C037-T03 · Injection map:** Locate the “Commit-time fencing” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M11.04-C037-T04 · Disposition oracle:** Define the legal intermediate and final “Commit-time fencing” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M11.04-C037-T05 · Controlled trigger:** Introduce the controlled “Commit-time fencing” scenario in the disposable fixture: an isolated previous owner resumes after a new owner has been activated; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M11.04-C037-T06 · Intermediate inspection:** Inspect the “Commit-time fencing” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M11.04-C037-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Commit-time fencing”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M11.04-C037-T08 · Stale-evidence cleanup:** Invalidate superseded “Commit-time fencing” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M11.04-C037-T09 · Repeat and compare:** Repeat the selected “Commit-time fencing” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M11.04-C037-T10 · Failure evidence:** Publish the “Commit-time fencing” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M11.04-C038 · Bounds

**Original checklist item:** Choose, document and test limits for commit checks and validation latency; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M11.04-C038-T01 · Quantity inventory:** Create a measurement inventory for “Commit-time fencing”: “Commit checks and validation latency”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M11.04-C038-T02 · Measurement method:** Choose how to observe each “Commit-time fencing” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M11.04-C038-T03 · Budget decision:** Select justified resource and input limits for “Commit-time fencing”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M11.04-C038-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Commit-time fencing” cases for “Commit checks and validation latency”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M11.04-C038-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Commit-time fencing” limit; preserve “An old owner cannot commit merely because its request was once accepted”.
- [ ] **UC-M11.04-C038-T06 · Normal measurement:** Run or review the normal “Commit-time fencing” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M11.04-C038-T07 · At-limit measurement:** Exercise the “Commit-time fencing” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M11.04-C038-T08 · Over-limit measurement:** Exercise the “Commit-time fencing” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M11.04-C038-T09 · Uncovered-scope report:** List the “Commit-time fencing” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M11.04-C038-T10 · Limit evidence:** Publish the selected “Commit-time fencing” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M11.04-C039 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for commit-time fencing with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M11.04-C039-T01 · Event inventory:** List the “Commit-time fencing” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M11.04-C039-T02 · Diagnostic schema:** Define nonsecret fields for “Commit-time fencing” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M11.04-C039-T03 · Failure mapping:** Map each documented “Commit-time fencing” refusal or error to a diagnostic outcome; include “A delayed old-owner write arrives after new ownership activation” and prohibit conversion into a success message.
- [ ] **UC-M11.04-C039-T04 · Emission path:** Add the “Commit-time fencing” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M11.04-C039-T05 · Redaction check:** Test “Commit-time fencing” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M11.04-C039-T06 · Output budget:** Set and exercise bounded “Commit-time fencing” message size, rate and retention compatible with “Commit checks and validation latency”; define truncation behavior that preserves the final reason.
- [ ] **UC-M11.04-C039-T07 · Success/refusal fixtures:** Capture “Commit-time fencing” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M11.04-C039-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Commit-time fencing” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M11.04-C039-T09 · Operator review:** Read the “Commit-time fencing” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M11.04-C039-T10 · Diagnostic evidence:** Publish redacted “Commit-time fencing” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M11.04-C040 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for commit-time fencing; label unexecuted checks as untested.

- [ ] **UC-M11.04-C040-T01 · Evidence inventory:** List the “Commit-time fencing” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M11.04-C040-T02 · Artifact references:** Record the exact “Commit-time fencing” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M11.04-C040-T03 · Fixture references:** Attach the “Commit-time fencing” fixture IDs, input identities and oracle definition; preserve the source counterexample “A delayed old-owner write arrives after new ownership activation” as a distinct evidence case.
- [ ] **UC-M11.04-C040-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Commit-time fencing”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M11.04-C040-T05 · Environment record:** Record the actual “Commit-time fencing” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M11.04-C040-T06 · Expected versus observed:** Pair every “Commit-time fencing” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M11.04-C040-T07 · Failure and limit records:** Attach “Commit-time fencing” change/failure and bounds evidence where required; include uncovered “Commit checks and validation latency” and unresolved violations of “An old owner cannot commit merely because its request was once accepted”.
- [ ] **UC-M11.04-C040-T08 · Evidence hygiene:** Check the “Commit-time fencing” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M11.04-C040-T09 · Reproduction review:** Have the “Commit-time fencing” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M11.04-C040-T10 · Acceptance linkage:** Link the “Commit-time fencing” evidence to its parent and UC-M11.04 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 05. Lease renewal checks

**Source delivery:** Allow renewal only for the currently authorized owner and epoch.

**Source invariant:** A stale worker cannot renew an obsolete ownership grant.

**Source negative case:** A partitioned former owner renews against stale local metadata.

**Source bounded quantities:** Renewal requests and stale records.

### UC-M11.04-C041 · Contract

**Original checklist item:** Specify lease renewal checks inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M11.04-C041-T01 · Scope statement:** Draft the operation boundary for “Lease renewal checks” within Leases, fencing and ownership transfer; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M11.04-C041-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Lease renewal checks”; record each producer, representation and missing-value meaning.
- [ ] **UC-M11.04-C041-T03 · Output inventory:** List the outputs of “Lease renewal checks” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M11.04-C041-T04 · Field dictionary:** Create a field-and-term dictionary for “Lease renewal checks”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M11.04-C041-T05 · Prerequisite contract:** Map “Lease renewal checks” to the source component prerequisites (UC-M01.05, UC-M11.03); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M11.04-C041-T06 · Authority map:** Identify who may produce, change and consume “Lease renewal checks”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M11.04-C041-T07 · Invariant clause:** Add a normative clause for “Lease renewal checks” that preserves “A stale worker cannot renew an obsolete ownership grant”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M11.04-C041-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Lease renewal checks”; include the source counterexample “A partitioned former owner renews against stale local metadata” and the intended safe disposition.
- [ ] **UC-M11.04-C041-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Renewal requests and stale records” in the “Lease renewal checks” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M11.04-C041-T10 · Contract review:** Review the “Lease renewal checks” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M11.04-C042 · Delivery

**Original checklist item:** Allow renewal only for the currently authorized owner and epoch.

- [ ] **UC-M11.04-C042-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Lease renewal checks”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M11.04-C042-T02 · Change plan:** Break the source delivery for “Lease renewal checks” into concrete edit targets and reviewable outputs; keep the UC-M11.04 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M11.04-C042-T03 · Core artifact:** Implement the smallest selected-profile change for “Lease renewal checks” that realizes this source instruction: Allow renewal only for the currently authorized owner and epoch.
- [ ] **UC-M11.04-C042-T04 · Concrete realization:** Trace “Lease renewal checks” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M11.04-C042-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Lease renewal checks” needed to preserve “A stale worker cannot renew an obsolete ownership grant”; record an enforcement gap where only a model exists.
- [ ] **UC-M11.04-C042-T06 · Dependency connection:** Connect the “Lease renewal checks” implementation to consensus-backed ownership, lease epochs and commit-time downstream fencing; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M11.04-C042-T07 · Resource behavior:** Account for “Renewal requests and stale records” in “Lease renewal checks”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M11.04-C042-T08 · Delivery check:** Run the smallest real “Lease renewal checks” path and its adverse fixture “A partitioned former owner renews against stale local metadata”; retain actual output, state effects and final disposition.
- [ ] **UC-M11.04-C042-T09 · Patch review:** Review the “Lease renewal checks” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M11.04-C042-T10 · Delivery handoff:** Publish the “Lease renewal checks” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M11.04-C043 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: A stale worker cannot renew an obsolete ownership grant. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M11.04-C043-T01 · Named property:** Create a stable property/check name under this parent for “Lease renewal checks”; copy its required invariant exactly: “A stale worker cannot renew an obsolete ownership grant”.
- [ ] **UC-M11.04-C043-T02 · Observable terms:** Define each term in the “Lease renewal checks” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M11.04-C043-T03 · Precondition set:** List the preconditions under which “A stale worker cannot renew an obsolete ownership grant” must hold for “Lease renewal checks”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M11.04-C043-T04 · Transition coverage:** Map the “Lease renewal checks” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M11.04-C043-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Lease renewal checks”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M11.04-C043-T06 · Satisfying fixture:** Create a concrete “Lease renewal checks” case that satisfies “A stale worker cannot renew an obsolete ownership grant”; record its expected observation before running the assertion or review.
- [ ] **UC-M11.04-C043-T07 · Violating fixture:** Create the source counterexample “A partitioned former owner renews against stale local metadata” for “Lease renewal checks”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M11.04-C043-T08 · Enforcement evidence:** Exercise the “Lease renewal checks” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M11.04-C043-T09 · Regression linkage:** Link the “Lease renewal checks” property to changes in consensus-backed ownership, lease epochs and commit-time downstream fencing; record which dependency or contract changes require rerunning it.
- [ ] **UC-M11.04-C043-T10 · Property disposition:** Compare the satisfying and violating “Lease renewal checks” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M11.04-C044 · Integration

**Original checklist item:** Integrate lease renewal checks with consensus-backed ownership, lease epochs and commit-time downstream fencing; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M11.04-C044-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Lease renewal checks” across consensus-backed ownership, lease epochs and commit-time downstream fencing; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M11.04-C044-T02 · Field mapping:** Map every “Lease renewal checks” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M11.04-C044-T03 · Prerequisite identities:** Record the actual prerequisites for “Lease renewal checks” (source dependency list: UC-M01.05, UC-M11.03); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M11.04-C044-T04 · Ownership agreement:** Specify who owns “Lease renewal checks” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M11.04-C044-T05 · Handoff implementation:** Connect “Lease renewal checks” through the mapped seam using the real adapter or explicit specification reference; preserve “A stale worker cannot renew an obsolete ownership grant” across the handoff.
- [ ] **UC-M11.04-C044-T06 · Absent-input case:** Omit one required “Lease renewal checks” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M11.04-C044-T07 · Stale-input case:** Supply an outdated “Lease renewal checks” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M11.04-C044-T08 · Incompatible-input case:** Supply an incompatible “Lease renewal checks” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M11.04-C044-T09 · Valid integration trace:** Run a valid “Lease renewal checks” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M11.04-C044-T10 · Seam review:** Reconcile the “Lease renewal checks” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M11.04-C045 · Valid-case test

**Original checklist item:** Run a valid-path fixture for lease renewal checks; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M11.04-C045-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Lease renewal checks” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M11.04-C045-T02 · Expected-result oracle:** Specify the “Lease renewal checks” expected result independently of the implementation output; include the property “A stale worker cannot renew an obsolete ownership grant” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M11.04-C045-T03 · Fixture material:** Create the concrete “Lease renewal checks” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M11.04-C045-T04 · Target preparation:** Prepare the “Lease renewal checks” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M11.04-C045-T05 · Initial-state record:** Record the initial “Lease renewal checks” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M11.04-C045-T06 · Valid-path execution:** Execute the “Lease renewal checks” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M11.04-C045-T07 · Outcome comparison:** Compare every declared “Lease renewal checks” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M11.04-C045-T08 · State and bounds check:** Inspect the “Lease renewal checks” ownership/state effects and actual use of “Renewal requests and stale records”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M11.04-C045-T09 · Repeatability check:** Repeat the same “Lease renewal checks” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M11.04-C045-T10 · Positive evidence:** Attach the “Lease renewal checks” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M11.04-C046 · Negative test

**Original checklist item:** Negative case: A partitioned former owner renews against stale local metadata. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M11.04-C046-T01 · Adverse-case definition:** Create a test record for the exact “Lease renewal checks” source counterexample: “A partitioned former owner renews against stale local metadata”; state which precondition or invariant it challenges.
- [ ] **UC-M11.04-C046-T02 · Safe fixture boundary:** Define the contained test boundary for “Lease renewal checks”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M11.04-C046-T03 · Valid control:** Construct a valid “Lease renewal checks” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M11.04-C046-T04 · Minimal adverse input:** Derive the “Lease renewal checks” adverse fixture from the control with the smallest documented change needed to reproduce “A partitioned former owner renews against stale local metadata”; retain that change as reproducible data.
- [ ] **UC-M11.04-C046-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Lease renewal checks”; require “A stale worker cannot renew an obsolete ownership grant” and forbid a false-success verdict.
- [ ] **UC-M11.04-C046-T06 · Adverse execution:** Exercise the “Lease renewal checks” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M11.04-C046-T07 · Effect inspection:** Inspect “Lease renewal checks” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M11.04-C046-T08 · Refusal versus failure:** Confirm the “Lease renewal checks” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M11.04-C046-T09 · Reset and retention:** Restore only the disposable “Lease renewal checks” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M11.04-C046-T10 · Negative regression:** Register the “Lease renewal checks” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M11.04-C047 · Change / failure test

**Original checklist item:** Exercise lease renewal checks when an isolated previous owner resumes after a new owner has been activated; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M11.04-C047-T01 · Scenario record:** Write the “Lease renewal checks” change/failure scenario exactly as supplied: an isolated previous owner resumes after a new owner has been activated; identify the property that must remain true: “A stale worker cannot renew an obsolete ownership grant”.
- [ ] **UC-M11.04-C047-T02 · Baseline capture:** Create a known-valid “Lease renewal checks” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M11.04-C047-T03 · Injection map:** Locate the “Lease renewal checks” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M11.04-C047-T04 · Disposition oracle:** Define the legal intermediate and final “Lease renewal checks” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M11.04-C047-T05 · Controlled trigger:** Introduce the controlled “Lease renewal checks” scenario in the disposable fixture: an isolated previous owner resumes after a new owner has been activated; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M11.04-C047-T06 · Intermediate inspection:** Inspect the “Lease renewal checks” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M11.04-C047-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Lease renewal checks”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M11.04-C047-T08 · Stale-evidence cleanup:** Invalidate superseded “Lease renewal checks” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M11.04-C047-T09 · Repeat and compare:** Repeat the selected “Lease renewal checks” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M11.04-C047-T10 · Failure evidence:** Publish the “Lease renewal checks” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M11.04-C048 · Bounds

**Original checklist item:** Choose, document and test limits for renewal requests and stale records; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M11.04-C048-T01 · Quantity inventory:** Create a measurement inventory for “Lease renewal checks”: “Renewal requests and stale records”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M11.04-C048-T02 · Measurement method:** Choose how to observe each “Lease renewal checks” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M11.04-C048-T03 · Budget decision:** Select justified resource and input limits for “Lease renewal checks”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M11.04-C048-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Lease renewal checks” cases for “Renewal requests and stale records”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M11.04-C048-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Lease renewal checks” limit; preserve “A stale worker cannot renew an obsolete ownership grant”.
- [ ] **UC-M11.04-C048-T06 · Normal measurement:** Run or review the normal “Lease renewal checks” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M11.04-C048-T07 · At-limit measurement:** Exercise the “Lease renewal checks” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M11.04-C048-T08 · Over-limit measurement:** Exercise the “Lease renewal checks” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M11.04-C048-T09 · Uncovered-scope report:** List the “Lease renewal checks” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M11.04-C048-T10 · Limit evidence:** Publish the selected “Lease renewal checks” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M11.04-C049 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for lease renewal checks with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M11.04-C049-T01 · Event inventory:** List the “Lease renewal checks” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M11.04-C049-T02 · Diagnostic schema:** Define nonsecret fields for “Lease renewal checks” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M11.04-C049-T03 · Failure mapping:** Map each documented “Lease renewal checks” refusal or error to a diagnostic outcome; include “A partitioned former owner renews against stale local metadata” and prohibit conversion into a success message.
- [ ] **UC-M11.04-C049-T04 · Emission path:** Add the “Lease renewal checks” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M11.04-C049-T05 · Redaction check:** Test “Lease renewal checks” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M11.04-C049-T06 · Output budget:** Set and exercise bounded “Lease renewal checks” message size, rate and retention compatible with “Renewal requests and stale records”; define truncation behavior that preserves the final reason.
- [ ] **UC-M11.04-C049-T07 · Success/refusal fixtures:** Capture “Lease renewal checks” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M11.04-C049-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Lease renewal checks” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M11.04-C049-T09 · Operator review:** Read the “Lease renewal checks” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M11.04-C049-T10 · Diagnostic evidence:** Publish redacted “Lease renewal checks” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M11.04-C050 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for lease renewal checks; label unexecuted checks as untested.

- [ ] **UC-M11.04-C050-T01 · Evidence inventory:** List the “Lease renewal checks” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M11.04-C050-T02 · Artifact references:** Record the exact “Lease renewal checks” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M11.04-C050-T03 · Fixture references:** Attach the “Lease renewal checks” fixture IDs, input identities and oracle definition; preserve the source counterexample “A partitioned former owner renews against stale local metadata” as a distinct evidence case.
- [ ] **UC-M11.04-C050-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Lease renewal checks”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M11.04-C050-T05 · Environment record:** Record the actual “Lease renewal checks” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M11.04-C050-T06 · Expected versus observed:** Pair every “Lease renewal checks” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M11.04-C050-T07 · Failure and limit records:** Attach “Lease renewal checks” change/failure and bounds evidence where required; include uncovered “Renewal requests and stale records” and unresolved violations of “A stale worker cannot renew an obsolete ownership grant”.
- [ ] **UC-M11.04-C050-T08 · Evidence hygiene:** Check the “Lease renewal checks” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M11.04-C050-T09 · Reproduction review:** Have the “Lease renewal checks” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M11.04-C050-T10 · Acceptance linkage:** Link the “Lease renewal checks” evidence to its parent and UC-M11.04 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 06. Ownership transfer protocol

**Source delivery:** Coordinate draining, fencing and activation of a new owner.

**Source invariant:** Transfer cannot activate conflicting writers without a documented safe disposition.

**Source negative case:** The new owner starts before the old owner's commit authority is fenced.

**Source bounded quantities:** Transfer steps and handoff deadline.

### UC-M11.04-C051 · Contract

**Original checklist item:** Specify ownership transfer protocol inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M11.04-C051-T01 · Scope statement:** Draft the operation boundary for “Ownership transfer protocol” within Leases, fencing and ownership transfer; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M11.04-C051-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Ownership transfer protocol”; record each producer, representation and missing-value meaning.
- [ ] **UC-M11.04-C051-T03 · Output inventory:** List the outputs of “Ownership transfer protocol” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M11.04-C051-T04 · Field dictionary:** Create a field-and-term dictionary for “Ownership transfer protocol”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M11.04-C051-T05 · Prerequisite contract:** Map “Ownership transfer protocol” to the source component prerequisites (UC-M01.05, UC-M11.03); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M11.04-C051-T06 · Authority map:** Identify who may produce, change and consume “Ownership transfer protocol”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M11.04-C051-T07 · Invariant clause:** Add a normative clause for “Ownership transfer protocol” that preserves “Transfer cannot activate conflicting writers without a documented safe disposition”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M11.04-C051-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Ownership transfer protocol”; include the source counterexample “The new owner starts before the old owner's commit authority is fenced” and the intended safe disposition.
- [ ] **UC-M11.04-C051-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Transfer steps and handoff deadline” in the “Ownership transfer protocol” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M11.04-C051-T10 · Contract review:** Review the “Ownership transfer protocol” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M11.04-C052 · Delivery

**Original checklist item:** Coordinate draining, fencing and activation of a new owner.

- [ ] **UC-M11.04-C052-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Ownership transfer protocol”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M11.04-C052-T02 · Change plan:** Break the source delivery for “Ownership transfer protocol” into concrete edit targets and reviewable outputs; keep the UC-M11.04 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M11.04-C052-T03 · Core artifact:** Implement the smallest selected-profile change for “Ownership transfer protocol” that realizes this source instruction: Coordinate draining, fencing and activation of a new owner.
- [ ] **UC-M11.04-C052-T04 · Concrete realization:** Trace “Ownership transfer protocol” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M11.04-C052-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Ownership transfer protocol” needed to preserve “Transfer cannot activate conflicting writers without a documented safe disposition”; record an enforcement gap where only a model exists.
- [ ] **UC-M11.04-C052-T06 · Dependency connection:** Connect the “Ownership transfer protocol” implementation to consensus-backed ownership, lease epochs and commit-time downstream fencing; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M11.04-C052-T07 · Resource behavior:** Account for “Transfer steps and handoff deadline” in “Ownership transfer protocol”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M11.04-C052-T08 · Delivery check:** Run the smallest real “Ownership transfer protocol” path and its adverse fixture “The new owner starts before the old owner's commit authority is fenced”; retain actual output, state effects and final disposition.
- [ ] **UC-M11.04-C052-T09 · Patch review:** Review the “Ownership transfer protocol” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M11.04-C052-T10 · Delivery handoff:** Publish the “Ownership transfer protocol” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M11.04-C053 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Transfer cannot activate conflicting writers without a documented safe disposition. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M11.04-C053-T01 · Named property:** Create a stable property/check name under this parent for “Ownership transfer protocol”; copy its required invariant exactly: “Transfer cannot activate conflicting writers without a documented safe disposition”.
- [ ] **UC-M11.04-C053-T02 · Observable terms:** Define each term in the “Ownership transfer protocol” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M11.04-C053-T03 · Precondition set:** List the preconditions under which “Transfer cannot activate conflicting writers without a documented safe disposition” must hold for “Ownership transfer protocol”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M11.04-C053-T04 · Transition coverage:** Map the “Ownership transfer protocol” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M11.04-C053-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Ownership transfer protocol”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M11.04-C053-T06 · Satisfying fixture:** Create a concrete “Ownership transfer protocol” case that satisfies “Transfer cannot activate conflicting writers without a documented safe disposition”; record its expected observation before running the assertion or review.
- [ ] **UC-M11.04-C053-T07 · Violating fixture:** Create the source counterexample “The new owner starts before the old owner's commit authority is fenced” for “Ownership transfer protocol”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M11.04-C053-T08 · Enforcement evidence:** Exercise the “Ownership transfer protocol” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M11.04-C053-T09 · Regression linkage:** Link the “Ownership transfer protocol” property to changes in consensus-backed ownership, lease epochs and commit-time downstream fencing; record which dependency or contract changes require rerunning it.
- [ ] **UC-M11.04-C053-T10 · Property disposition:** Compare the satisfying and violating “Ownership transfer protocol” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M11.04-C054 · Integration

**Original checklist item:** Integrate ownership transfer protocol with consensus-backed ownership, lease epochs and commit-time downstream fencing; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M11.04-C054-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Ownership transfer protocol” across consensus-backed ownership, lease epochs and commit-time downstream fencing; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M11.04-C054-T02 · Field mapping:** Map every “Ownership transfer protocol” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M11.04-C054-T03 · Prerequisite identities:** Record the actual prerequisites for “Ownership transfer protocol” (source dependency list: UC-M01.05, UC-M11.03); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M11.04-C054-T04 · Ownership agreement:** Specify who owns “Ownership transfer protocol” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M11.04-C054-T05 · Handoff implementation:** Connect “Ownership transfer protocol” through the mapped seam using the real adapter or explicit specification reference; preserve “Transfer cannot activate conflicting writers without a documented safe disposition” across the handoff.
- [ ] **UC-M11.04-C054-T06 · Absent-input case:** Omit one required “Ownership transfer protocol” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M11.04-C054-T07 · Stale-input case:** Supply an outdated “Ownership transfer protocol” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M11.04-C054-T08 · Incompatible-input case:** Supply an incompatible “Ownership transfer protocol” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M11.04-C054-T09 · Valid integration trace:** Run a valid “Ownership transfer protocol” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M11.04-C054-T10 · Seam review:** Reconcile the “Ownership transfer protocol” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M11.04-C055 · Valid-case test

**Original checklist item:** Run a valid-path fixture for ownership transfer protocol; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M11.04-C055-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Ownership transfer protocol” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M11.04-C055-T02 · Expected-result oracle:** Specify the “Ownership transfer protocol” expected result independently of the implementation output; include the property “Transfer cannot activate conflicting writers without a documented safe disposition” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M11.04-C055-T03 · Fixture material:** Create the concrete “Ownership transfer protocol” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M11.04-C055-T04 · Target preparation:** Prepare the “Ownership transfer protocol” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M11.04-C055-T05 · Initial-state record:** Record the initial “Ownership transfer protocol” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M11.04-C055-T06 · Valid-path execution:** Execute the “Ownership transfer protocol” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M11.04-C055-T07 · Outcome comparison:** Compare every declared “Ownership transfer protocol” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M11.04-C055-T08 · State and bounds check:** Inspect the “Ownership transfer protocol” ownership/state effects and actual use of “Transfer steps and handoff deadline”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M11.04-C055-T09 · Repeatability check:** Repeat the same “Ownership transfer protocol” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M11.04-C055-T10 · Positive evidence:** Attach the “Ownership transfer protocol” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M11.04-C056 · Negative test

**Original checklist item:** Negative case: The new owner starts before the old owner's commit authority is fenced. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M11.04-C056-T01 · Adverse-case definition:** Create a test record for the exact “Ownership transfer protocol” source counterexample: “The new owner starts before the old owner's commit authority is fenced”; state which precondition or invariant it challenges.
- [ ] **UC-M11.04-C056-T02 · Safe fixture boundary:** Define the contained test boundary for “Ownership transfer protocol”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M11.04-C056-T03 · Valid control:** Construct a valid “Ownership transfer protocol” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M11.04-C056-T04 · Minimal adverse input:** Derive the “Ownership transfer protocol” adverse fixture from the control with the smallest documented change needed to reproduce “The new owner starts before the old owner's commit authority is fenced”; retain that change as reproducible data.
- [ ] **UC-M11.04-C056-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Ownership transfer protocol”; require “Transfer cannot activate conflicting writers without a documented safe disposition” and forbid a false-success verdict.
- [ ] **UC-M11.04-C056-T06 · Adverse execution:** Exercise the “Ownership transfer protocol” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M11.04-C056-T07 · Effect inspection:** Inspect “Ownership transfer protocol” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M11.04-C056-T08 · Refusal versus failure:** Confirm the “Ownership transfer protocol” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M11.04-C056-T09 · Reset and retention:** Restore only the disposable “Ownership transfer protocol” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M11.04-C056-T10 · Negative regression:** Register the “Ownership transfer protocol” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M11.04-C057 · Change / failure test

**Original checklist item:** Exercise ownership transfer protocol when an isolated previous owner resumes after a new owner has been activated; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M11.04-C057-T01 · Scenario record:** Write the “Ownership transfer protocol” change/failure scenario exactly as supplied: an isolated previous owner resumes after a new owner has been activated; identify the property that must remain true: “Transfer cannot activate conflicting writers without a documented safe disposition”.
- [ ] **UC-M11.04-C057-T02 · Baseline capture:** Create a known-valid “Ownership transfer protocol” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M11.04-C057-T03 · Injection map:** Locate the “Ownership transfer protocol” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M11.04-C057-T04 · Disposition oracle:** Define the legal intermediate and final “Ownership transfer protocol” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M11.04-C057-T05 · Controlled trigger:** Introduce the controlled “Ownership transfer protocol” scenario in the disposable fixture: an isolated previous owner resumes after a new owner has been activated; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M11.04-C057-T06 · Intermediate inspection:** Inspect the “Ownership transfer protocol” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M11.04-C057-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Ownership transfer protocol”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M11.04-C057-T08 · Stale-evidence cleanup:** Invalidate superseded “Ownership transfer protocol” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M11.04-C057-T09 · Repeat and compare:** Repeat the selected “Ownership transfer protocol” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M11.04-C057-T10 · Failure evidence:** Publish the “Ownership transfer protocol” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M11.04-C058 · Bounds

**Original checklist item:** Choose, document and test limits for transfer steps and handoff deadline; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M11.04-C058-T01 · Quantity inventory:** Create a measurement inventory for “Ownership transfer protocol”: “Transfer steps and handoff deadline”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M11.04-C058-T02 · Measurement method:** Choose how to observe each “Ownership transfer protocol” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M11.04-C058-T03 · Budget decision:** Select justified resource and input limits for “Ownership transfer protocol”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M11.04-C058-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Ownership transfer protocol” cases for “Transfer steps and handoff deadline”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M11.04-C058-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Ownership transfer protocol” limit; preserve “Transfer cannot activate conflicting writers without a documented safe disposition”.
- [ ] **UC-M11.04-C058-T06 · Normal measurement:** Run or review the normal “Ownership transfer protocol” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M11.04-C058-T07 · At-limit measurement:** Exercise the “Ownership transfer protocol” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M11.04-C058-T08 · Over-limit measurement:** Exercise the “Ownership transfer protocol” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M11.04-C058-T09 · Uncovered-scope report:** List the “Ownership transfer protocol” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M11.04-C058-T10 · Limit evidence:** Publish the selected “Ownership transfer protocol” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M11.04-C059 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for ownership transfer protocol with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M11.04-C059-T01 · Event inventory:** List the “Ownership transfer protocol” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M11.04-C059-T02 · Diagnostic schema:** Define nonsecret fields for “Ownership transfer protocol” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M11.04-C059-T03 · Failure mapping:** Map each documented “Ownership transfer protocol” refusal or error to a diagnostic outcome; include “The new owner starts before the old owner's commit authority is fenced” and prohibit conversion into a success message.
- [ ] **UC-M11.04-C059-T04 · Emission path:** Add the “Ownership transfer protocol” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M11.04-C059-T05 · Redaction check:** Test “Ownership transfer protocol” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M11.04-C059-T06 · Output budget:** Set and exercise bounded “Ownership transfer protocol” message size, rate and retention compatible with “Transfer steps and handoff deadline”; define truncation behavior that preserves the final reason.
- [ ] **UC-M11.04-C059-T07 · Success/refusal fixtures:** Capture “Ownership transfer protocol” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M11.04-C059-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Ownership transfer protocol” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M11.04-C059-T09 · Operator review:** Read the “Ownership transfer protocol” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M11.04-C059-T10 · Diagnostic evidence:** Publish redacted “Ownership transfer protocol” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M11.04-C060 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for ownership transfer protocol; label unexecuted checks as untested.

- [ ] **UC-M11.04-C060-T01 · Evidence inventory:** List the “Ownership transfer protocol” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M11.04-C060-T02 · Artifact references:** Record the exact “Ownership transfer protocol” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M11.04-C060-T03 · Fixture references:** Attach the “Ownership transfer protocol” fixture IDs, input identities and oracle definition; preserve the source counterexample “The new owner starts before the old owner's commit authority is fenced” as a distinct evidence case.
- [ ] **UC-M11.04-C060-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Ownership transfer protocol”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M11.04-C060-T05 · Environment record:** Record the actual “Ownership transfer protocol” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M11.04-C060-T06 · Expected versus observed:** Pair every “Ownership transfer protocol” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M11.04-C060-T07 · Failure and limit records:** Attach “Ownership transfer protocol” change/failure and bounds evidence where required; include uncovered “Transfer steps and handoff deadline” and unresolved violations of “Transfer cannot activate conflicting writers without a documented safe disposition”.
- [ ] **UC-M11.04-C060-T08 · Evidence hygiene:** Check the “Ownership transfer protocol” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M11.04-C060-T09 · Reproduction review:** Have the “Ownership transfer protocol” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M11.04-C060-T10 · Acceptance linkage:** Link the “Ownership transfer protocol” evidence to its parent and UC-M11.04 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 07. Partitioned-owner behavior

**Source delivery:** Refuse or constrain work when a worker cannot establish current authority.

**Source invariant:** Isolation from the controller does not grant continued unlimited commit rights.

**Source negative case:** A partitioned worker continues publishing writes after expiry.

**Source bounded quantities:** Partition duration and retained pending work.

### UC-M11.04-C061 · Contract

**Original checklist item:** Specify partitioned-owner behavior inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M11.04-C061-T01 · Scope statement:** Draft the operation boundary for “Partitioned-owner behavior” within Leases, fencing and ownership transfer; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M11.04-C061-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Partitioned-owner behavior”; record each producer, representation and missing-value meaning.
- [ ] **UC-M11.04-C061-T03 · Output inventory:** List the outputs of “Partitioned-owner behavior” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M11.04-C061-T04 · Field dictionary:** Create a field-and-term dictionary for “Partitioned-owner behavior”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M11.04-C061-T05 · Prerequisite contract:** Map “Partitioned-owner behavior” to the source component prerequisites (UC-M01.05, UC-M11.03); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M11.04-C061-T06 · Authority map:** Identify who may produce, change and consume “Partitioned-owner behavior”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M11.04-C061-T07 · Invariant clause:** Add a normative clause for “Partitioned-owner behavior” that preserves “Isolation from the controller does not grant continued unlimited commit rights”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M11.04-C061-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Partitioned-owner behavior”; include the source counterexample “A partitioned worker continues publishing writes after expiry” and the intended safe disposition.
- [ ] **UC-M11.04-C061-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Partition duration and retained pending work” in the “Partitioned-owner behavior” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M11.04-C061-T10 · Contract review:** Review the “Partitioned-owner behavior” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M11.04-C062 · Delivery

**Original checklist item:** Refuse or constrain work when a worker cannot establish current authority.

- [ ] **UC-M11.04-C062-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Partitioned-owner behavior”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M11.04-C062-T02 · Change plan:** Break the source delivery for “Partitioned-owner behavior” into concrete edit targets and reviewable outputs; keep the UC-M11.04 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M11.04-C062-T03 · Core artifact:** Implement the smallest selected-profile change for “Partitioned-owner behavior” that realizes this source instruction: Refuse or constrain work when a worker cannot establish current authority.
- [ ] **UC-M11.04-C062-T04 · Concrete realization:** Trace “Partitioned-owner behavior” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M11.04-C062-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Partitioned-owner behavior” needed to preserve “Isolation from the controller does not grant continued unlimited commit rights”; record an enforcement gap where only a model exists.
- [ ] **UC-M11.04-C062-T06 · Dependency connection:** Connect the “Partitioned-owner behavior” implementation to consensus-backed ownership, lease epochs and commit-time downstream fencing; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M11.04-C062-T07 · Resource behavior:** Account for “Partition duration and retained pending work” in “Partitioned-owner behavior”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M11.04-C062-T08 · Delivery check:** Run the smallest real “Partitioned-owner behavior” path and its adverse fixture “A partitioned worker continues publishing writes after expiry”; retain actual output, state effects and final disposition.
- [ ] **UC-M11.04-C062-T09 · Patch review:** Review the “Partitioned-owner behavior” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M11.04-C062-T10 · Delivery handoff:** Publish the “Partitioned-owner behavior” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M11.04-C063 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Isolation from the controller does not grant continued unlimited commit rights. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M11.04-C063-T01 · Named property:** Create a stable property/check name under this parent for “Partitioned-owner behavior”; copy its required invariant exactly: “Isolation from the controller does not grant continued unlimited commit rights”.
- [ ] **UC-M11.04-C063-T02 · Observable terms:** Define each term in the “Partitioned-owner behavior” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M11.04-C063-T03 · Precondition set:** List the preconditions under which “Isolation from the controller does not grant continued unlimited commit rights” must hold for “Partitioned-owner behavior”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M11.04-C063-T04 · Transition coverage:** Map the “Partitioned-owner behavior” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M11.04-C063-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Partitioned-owner behavior”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M11.04-C063-T06 · Satisfying fixture:** Create a concrete “Partitioned-owner behavior” case that satisfies “Isolation from the controller does not grant continued unlimited commit rights”; record its expected observation before running the assertion or review.
- [ ] **UC-M11.04-C063-T07 · Violating fixture:** Create the source counterexample “A partitioned worker continues publishing writes after expiry” for “Partitioned-owner behavior”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M11.04-C063-T08 · Enforcement evidence:** Exercise the “Partitioned-owner behavior” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M11.04-C063-T09 · Regression linkage:** Link the “Partitioned-owner behavior” property to changes in consensus-backed ownership, lease epochs and commit-time downstream fencing; record which dependency or contract changes require rerunning it.
- [ ] **UC-M11.04-C063-T10 · Property disposition:** Compare the satisfying and violating “Partitioned-owner behavior” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M11.04-C064 · Integration

**Original checklist item:** Integrate partitioned-owner behavior with consensus-backed ownership, lease epochs and commit-time downstream fencing; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M11.04-C064-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Partitioned-owner behavior” across consensus-backed ownership, lease epochs and commit-time downstream fencing; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M11.04-C064-T02 · Field mapping:** Map every “Partitioned-owner behavior” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M11.04-C064-T03 · Prerequisite identities:** Record the actual prerequisites for “Partitioned-owner behavior” (source dependency list: UC-M01.05, UC-M11.03); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M11.04-C064-T04 · Ownership agreement:** Specify who owns “Partitioned-owner behavior” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M11.04-C064-T05 · Handoff implementation:** Connect “Partitioned-owner behavior” through the mapped seam using the real adapter or explicit specification reference; preserve “Isolation from the controller does not grant continued unlimited commit rights” across the handoff.
- [ ] **UC-M11.04-C064-T06 · Absent-input case:** Omit one required “Partitioned-owner behavior” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M11.04-C064-T07 · Stale-input case:** Supply an outdated “Partitioned-owner behavior” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M11.04-C064-T08 · Incompatible-input case:** Supply an incompatible “Partitioned-owner behavior” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M11.04-C064-T09 · Valid integration trace:** Run a valid “Partitioned-owner behavior” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M11.04-C064-T10 · Seam review:** Reconcile the “Partitioned-owner behavior” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M11.04-C065 · Valid-case test

**Original checklist item:** Run a valid-path fixture for partitioned-owner behavior; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M11.04-C065-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Partitioned-owner behavior” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M11.04-C065-T02 · Expected-result oracle:** Specify the “Partitioned-owner behavior” expected result independently of the implementation output; include the property “Isolation from the controller does not grant continued unlimited commit rights” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M11.04-C065-T03 · Fixture material:** Create the concrete “Partitioned-owner behavior” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M11.04-C065-T04 · Target preparation:** Prepare the “Partitioned-owner behavior” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M11.04-C065-T05 · Initial-state record:** Record the initial “Partitioned-owner behavior” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M11.04-C065-T06 · Valid-path execution:** Execute the “Partitioned-owner behavior” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M11.04-C065-T07 · Outcome comparison:** Compare every declared “Partitioned-owner behavior” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M11.04-C065-T08 · State and bounds check:** Inspect the “Partitioned-owner behavior” ownership/state effects and actual use of “Partition duration and retained pending work”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M11.04-C065-T09 · Repeatability check:** Repeat the same “Partitioned-owner behavior” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M11.04-C065-T10 · Positive evidence:** Attach the “Partitioned-owner behavior” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M11.04-C066 · Negative test

**Original checklist item:** Negative case: A partitioned worker continues publishing writes after expiry. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M11.04-C066-T01 · Adverse-case definition:** Create a test record for the exact “Partitioned-owner behavior” source counterexample: “A partitioned worker continues publishing writes after expiry”; state which precondition or invariant it challenges.
- [ ] **UC-M11.04-C066-T02 · Safe fixture boundary:** Define the contained test boundary for “Partitioned-owner behavior”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M11.04-C066-T03 · Valid control:** Construct a valid “Partitioned-owner behavior” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M11.04-C066-T04 · Minimal adverse input:** Derive the “Partitioned-owner behavior” adverse fixture from the control with the smallest documented change needed to reproduce “A partitioned worker continues publishing writes after expiry”; retain that change as reproducible data.
- [ ] **UC-M11.04-C066-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Partitioned-owner behavior”; require “Isolation from the controller does not grant continued unlimited commit rights” and forbid a false-success verdict.
- [ ] **UC-M11.04-C066-T06 · Adverse execution:** Exercise the “Partitioned-owner behavior” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M11.04-C066-T07 · Effect inspection:** Inspect “Partitioned-owner behavior” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M11.04-C066-T08 · Refusal versus failure:** Confirm the “Partitioned-owner behavior” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M11.04-C066-T09 · Reset and retention:** Restore only the disposable “Partitioned-owner behavior” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M11.04-C066-T10 · Negative regression:** Register the “Partitioned-owner behavior” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M11.04-C067 · Change / failure test

**Original checklist item:** Exercise partitioned-owner behavior when an isolated previous owner resumes after a new owner has been activated; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M11.04-C067-T01 · Scenario record:** Write the “Partitioned-owner behavior” change/failure scenario exactly as supplied: an isolated previous owner resumes after a new owner has been activated; identify the property that must remain true: “Isolation from the controller does not grant continued unlimited commit rights”.
- [ ] **UC-M11.04-C067-T02 · Baseline capture:** Create a known-valid “Partitioned-owner behavior” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M11.04-C067-T03 · Injection map:** Locate the “Partitioned-owner behavior” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M11.04-C067-T04 · Disposition oracle:** Define the legal intermediate and final “Partitioned-owner behavior” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M11.04-C067-T05 · Controlled trigger:** Introduce the controlled “Partitioned-owner behavior” scenario in the disposable fixture: an isolated previous owner resumes after a new owner has been activated; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M11.04-C067-T06 · Intermediate inspection:** Inspect the “Partitioned-owner behavior” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M11.04-C067-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Partitioned-owner behavior”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M11.04-C067-T08 · Stale-evidence cleanup:** Invalidate superseded “Partitioned-owner behavior” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M11.04-C067-T09 · Repeat and compare:** Repeat the selected “Partitioned-owner behavior” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M11.04-C067-T10 · Failure evidence:** Publish the “Partitioned-owner behavior” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M11.04-C068 · Bounds

**Original checklist item:** Choose, document and test limits for partition duration and retained pending work; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M11.04-C068-T01 · Quantity inventory:** Create a measurement inventory for “Partitioned-owner behavior”: “Partition duration and retained pending work”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M11.04-C068-T02 · Measurement method:** Choose how to observe each “Partitioned-owner behavior” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M11.04-C068-T03 · Budget decision:** Select justified resource and input limits for “Partitioned-owner behavior”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M11.04-C068-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Partitioned-owner behavior” cases for “Partition duration and retained pending work”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M11.04-C068-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Partitioned-owner behavior” limit; preserve “Isolation from the controller does not grant continued unlimited commit rights”.
- [ ] **UC-M11.04-C068-T06 · Normal measurement:** Run or review the normal “Partitioned-owner behavior” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M11.04-C068-T07 · At-limit measurement:** Exercise the “Partitioned-owner behavior” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M11.04-C068-T08 · Over-limit measurement:** Exercise the “Partitioned-owner behavior” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M11.04-C068-T09 · Uncovered-scope report:** List the “Partitioned-owner behavior” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M11.04-C068-T10 · Limit evidence:** Publish the selected “Partitioned-owner behavior” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M11.04-C069 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for partitioned-owner behavior with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M11.04-C069-T01 · Event inventory:** List the “Partitioned-owner behavior” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M11.04-C069-T02 · Diagnostic schema:** Define nonsecret fields for “Partitioned-owner behavior” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M11.04-C069-T03 · Failure mapping:** Map each documented “Partitioned-owner behavior” refusal or error to a diagnostic outcome; include “A partitioned worker continues publishing writes after expiry” and prohibit conversion into a success message.
- [ ] **UC-M11.04-C069-T04 · Emission path:** Add the “Partitioned-owner behavior” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M11.04-C069-T05 · Redaction check:** Test “Partitioned-owner behavior” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M11.04-C069-T06 · Output budget:** Set and exercise bounded “Partitioned-owner behavior” message size, rate and retention compatible with “Partition duration and retained pending work”; define truncation behavior that preserves the final reason.
- [ ] **UC-M11.04-C069-T07 · Success/refusal fixtures:** Capture “Partitioned-owner behavior” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M11.04-C069-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Partitioned-owner behavior” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M11.04-C069-T09 · Operator review:** Read the “Partitioned-owner behavior” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M11.04-C069-T10 · Diagnostic evidence:** Publish redacted “Partitioned-owner behavior” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M11.04-C070 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for partitioned-owner behavior; label unexecuted checks as untested.

- [ ] **UC-M11.04-C070-T01 · Evidence inventory:** List the “Partitioned-owner behavior” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M11.04-C070-T02 · Artifact references:** Record the exact “Partitioned-owner behavior” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M11.04-C070-T03 · Fixture references:** Attach the “Partitioned-owner behavior” fixture IDs, input identities and oracle definition; preserve the source counterexample “A partitioned worker continues publishing writes after expiry” as a distinct evidence case.
- [ ] **UC-M11.04-C070-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Partitioned-owner behavior”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M11.04-C070-T05 · Environment record:** Record the actual “Partitioned-owner behavior” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M11.04-C070-T06 · Expected versus observed:** Pair every “Partitioned-owner behavior” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M11.04-C070-T07 · Failure and limit records:** Attach “Partitioned-owner behavior” change/failure and bounds evidence where required; include uncovered “Partition duration and retained pending work” and unresolved violations of “Isolation from the controller does not grant continued unlimited commit rights”.
- [ ] **UC-M11.04-C070-T08 · Evidence hygiene:** Check the “Partitioned-owner behavior” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M11.04-C070-T09 · Reproduction review:** Have the “Partitioned-owner behavior” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M11.04-C070-T10 · Acceptance linkage:** Link the “Partitioned-owner behavior” evidence to its parent and UC-M11.04 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 08. External resource fencing

**Source delivery:** Apply fencing to storage or effects outside the controller where required.

**Source invariant:** Control-plane ownership changes are enforced at downstream mutation boundaries.

**Source negative case:** A database accepts a stale owner's token after the controller transferred ownership.

**Source bounded quantities:** External resources and fencing checks.

### UC-M11.04-C071 · Contract

**Original checklist item:** Specify external resource fencing inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M11.04-C071-T01 · Scope statement:** Draft the operation boundary for “External resource fencing” within Leases, fencing and ownership transfer; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M11.04-C071-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “External resource fencing”; record each producer, representation and missing-value meaning.
- [ ] **UC-M11.04-C071-T03 · Output inventory:** List the outputs of “External resource fencing” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M11.04-C071-T04 · Field dictionary:** Create a field-and-term dictionary for “External resource fencing”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M11.04-C071-T05 · Prerequisite contract:** Map “External resource fencing” to the source component prerequisites (UC-M01.05, UC-M11.03); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M11.04-C071-T06 · Authority map:** Identify who may produce, change and consume “External resource fencing”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M11.04-C071-T07 · Invariant clause:** Add a normative clause for “External resource fencing” that preserves “Control-plane ownership changes are enforced at downstream mutation boundaries”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M11.04-C071-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “External resource fencing”; include the source counterexample “A database accepts a stale owner's token after the controller transferred ownership” and the intended safe disposition.
- [ ] **UC-M11.04-C071-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “External resources and fencing checks” in the “External resource fencing” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M11.04-C071-T10 · Contract review:** Review the “External resource fencing” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M11.04-C072 · Delivery

**Original checklist item:** Apply fencing to storage or effects outside the controller where required.

- [ ] **UC-M11.04-C072-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “External resource fencing”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M11.04-C072-T02 · Change plan:** Break the source delivery for “External resource fencing” into concrete edit targets and reviewable outputs; keep the UC-M11.04 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M11.04-C072-T03 · Core artifact:** Implement the smallest selected-profile change for “External resource fencing” that realizes this source instruction: Apply fencing to storage or effects outside the controller where required.
- [ ] **UC-M11.04-C072-T04 · Concrete realization:** Trace “External resource fencing” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M11.04-C072-T05 · Invariant protection:** Add the actual guard, check or review criterion for “External resource fencing” needed to preserve “Control-plane ownership changes are enforced at downstream mutation boundaries”; record an enforcement gap where only a model exists.
- [ ] **UC-M11.04-C072-T06 · Dependency connection:** Connect the “External resource fencing” implementation to consensus-backed ownership, lease epochs and commit-time downstream fencing; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M11.04-C072-T07 · Resource behavior:** Account for “External resources and fencing checks” in “External resource fencing”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M11.04-C072-T08 · Delivery check:** Run the smallest real “External resource fencing” path and its adverse fixture “A database accepts a stale owner's token after the controller transferred ownership”; retain actual output, state effects and final disposition.
- [ ] **UC-M11.04-C072-T09 · Patch review:** Review the “External resource fencing” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M11.04-C072-T10 · Delivery handoff:** Publish the “External resource fencing” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M11.04-C073 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Control-plane ownership changes are enforced at downstream mutation boundaries. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M11.04-C073-T01 · Named property:** Create a stable property/check name under this parent for “External resource fencing”; copy its required invariant exactly: “Control-plane ownership changes are enforced at downstream mutation boundaries”.
- [ ] **UC-M11.04-C073-T02 · Observable terms:** Define each term in the “External resource fencing” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M11.04-C073-T03 · Precondition set:** List the preconditions under which “Control-plane ownership changes are enforced at downstream mutation boundaries” must hold for “External resource fencing”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M11.04-C073-T04 · Transition coverage:** Map the “External resource fencing” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M11.04-C073-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “External resource fencing”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M11.04-C073-T06 · Satisfying fixture:** Create a concrete “External resource fencing” case that satisfies “Control-plane ownership changes are enforced at downstream mutation boundaries”; record its expected observation before running the assertion or review.
- [ ] **UC-M11.04-C073-T07 · Violating fixture:** Create the source counterexample “A database accepts a stale owner's token after the controller transferred ownership” for “External resource fencing”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M11.04-C073-T08 · Enforcement evidence:** Exercise the “External resource fencing” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M11.04-C073-T09 · Regression linkage:** Link the “External resource fencing” property to changes in consensus-backed ownership, lease epochs and commit-time downstream fencing; record which dependency or contract changes require rerunning it.
- [ ] **UC-M11.04-C073-T10 · Property disposition:** Compare the satisfying and violating “External resource fencing” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M11.04-C074 · Integration

**Original checklist item:** Integrate external resource fencing with consensus-backed ownership, lease epochs and commit-time downstream fencing; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M11.04-C074-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “External resource fencing” across consensus-backed ownership, lease epochs and commit-time downstream fencing; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M11.04-C074-T02 · Field mapping:** Map every “External resource fencing” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M11.04-C074-T03 · Prerequisite identities:** Record the actual prerequisites for “External resource fencing” (source dependency list: UC-M01.05, UC-M11.03); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M11.04-C074-T04 · Ownership agreement:** Specify who owns “External resource fencing” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M11.04-C074-T05 · Handoff implementation:** Connect “External resource fencing” through the mapped seam using the real adapter or explicit specification reference; preserve “Control-plane ownership changes are enforced at downstream mutation boundaries” across the handoff.
- [ ] **UC-M11.04-C074-T06 · Absent-input case:** Omit one required “External resource fencing” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M11.04-C074-T07 · Stale-input case:** Supply an outdated “External resource fencing” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M11.04-C074-T08 · Incompatible-input case:** Supply an incompatible “External resource fencing” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M11.04-C074-T09 · Valid integration trace:** Run a valid “External resource fencing” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M11.04-C074-T10 · Seam review:** Reconcile the “External resource fencing” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M11.04-C075 · Valid-case test

**Original checklist item:** Run a valid-path fixture for external resource fencing; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M11.04-C075-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “External resource fencing” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M11.04-C075-T02 · Expected-result oracle:** Specify the “External resource fencing” expected result independently of the implementation output; include the property “Control-plane ownership changes are enforced at downstream mutation boundaries” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M11.04-C075-T03 · Fixture material:** Create the concrete “External resource fencing” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M11.04-C075-T04 · Target preparation:** Prepare the “External resource fencing” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M11.04-C075-T05 · Initial-state record:** Record the initial “External resource fencing” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M11.04-C075-T06 · Valid-path execution:** Execute the “External resource fencing” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M11.04-C075-T07 · Outcome comparison:** Compare every declared “External resource fencing” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M11.04-C075-T08 · State and bounds check:** Inspect the “External resource fencing” ownership/state effects and actual use of “External resources and fencing checks”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M11.04-C075-T09 · Repeatability check:** Repeat the same “External resource fencing” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M11.04-C075-T10 · Positive evidence:** Attach the “External resource fencing” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M11.04-C076 · Negative test

**Original checklist item:** Negative case: A database accepts a stale owner's token after the controller transferred ownership. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M11.04-C076-T01 · Adverse-case definition:** Create a test record for the exact “External resource fencing” source counterexample: “A database accepts a stale owner's token after the controller transferred ownership”; state which precondition or invariant it challenges.
- [ ] **UC-M11.04-C076-T02 · Safe fixture boundary:** Define the contained test boundary for “External resource fencing”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M11.04-C076-T03 · Valid control:** Construct a valid “External resource fencing” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M11.04-C076-T04 · Minimal adverse input:** Derive the “External resource fencing” adverse fixture from the control with the smallest documented change needed to reproduce “A database accepts a stale owner's token after the controller transferred ownership”; retain that change as reproducible data.
- [ ] **UC-M11.04-C076-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “External resource fencing”; require “Control-plane ownership changes are enforced at downstream mutation boundaries” and forbid a false-success verdict.
- [ ] **UC-M11.04-C076-T06 · Adverse execution:** Exercise the “External resource fencing” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M11.04-C076-T07 · Effect inspection:** Inspect “External resource fencing” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M11.04-C076-T08 · Refusal versus failure:** Confirm the “External resource fencing” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M11.04-C076-T09 · Reset and retention:** Restore only the disposable “External resource fencing” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M11.04-C076-T10 · Negative regression:** Register the “External resource fencing” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M11.04-C077 · Change / failure test

**Original checklist item:** Exercise external resource fencing when an isolated previous owner resumes after a new owner has been activated; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M11.04-C077-T01 · Scenario record:** Write the “External resource fencing” change/failure scenario exactly as supplied: an isolated previous owner resumes after a new owner has been activated; identify the property that must remain true: “Control-plane ownership changes are enforced at downstream mutation boundaries”.
- [ ] **UC-M11.04-C077-T02 · Baseline capture:** Create a known-valid “External resource fencing” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M11.04-C077-T03 · Injection map:** Locate the “External resource fencing” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M11.04-C077-T04 · Disposition oracle:** Define the legal intermediate and final “External resource fencing” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M11.04-C077-T05 · Controlled trigger:** Introduce the controlled “External resource fencing” scenario in the disposable fixture: an isolated previous owner resumes after a new owner has been activated; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M11.04-C077-T06 · Intermediate inspection:** Inspect the “External resource fencing” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M11.04-C077-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “External resource fencing”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M11.04-C077-T08 · Stale-evidence cleanup:** Invalidate superseded “External resource fencing” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M11.04-C077-T09 · Repeat and compare:** Repeat the selected “External resource fencing” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M11.04-C077-T10 · Failure evidence:** Publish the “External resource fencing” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M11.04-C078 · Bounds

**Original checklist item:** Choose, document and test limits for external resources and fencing checks; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M11.04-C078-T01 · Quantity inventory:** Create a measurement inventory for “External resource fencing”: “External resources and fencing checks”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M11.04-C078-T02 · Measurement method:** Choose how to observe each “External resource fencing” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M11.04-C078-T03 · Budget decision:** Select justified resource and input limits for “External resource fencing”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M11.04-C078-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “External resource fencing” cases for “External resources and fencing checks”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M11.04-C078-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “External resource fencing” limit; preserve “Control-plane ownership changes are enforced at downstream mutation boundaries”.
- [ ] **UC-M11.04-C078-T06 · Normal measurement:** Run or review the normal “External resource fencing” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M11.04-C078-T07 · At-limit measurement:** Exercise the “External resource fencing” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M11.04-C078-T08 · Over-limit measurement:** Exercise the “External resource fencing” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M11.04-C078-T09 · Uncovered-scope report:** List the “External resource fencing” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M11.04-C078-T10 · Limit evidence:** Publish the selected “External resource fencing” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M11.04-C079 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for external resource fencing with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M11.04-C079-T01 · Event inventory:** List the “External resource fencing” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M11.04-C079-T02 · Diagnostic schema:** Define nonsecret fields for “External resource fencing” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M11.04-C079-T03 · Failure mapping:** Map each documented “External resource fencing” refusal or error to a diagnostic outcome; include “A database accepts a stale owner's token after the controller transferred ownership” and prohibit conversion into a success message.
- [ ] **UC-M11.04-C079-T04 · Emission path:** Add the “External resource fencing” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M11.04-C079-T05 · Redaction check:** Test “External resource fencing” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M11.04-C079-T06 · Output budget:** Set and exercise bounded “External resource fencing” message size, rate and retention compatible with “External resources and fencing checks”; define truncation behavior that preserves the final reason.
- [ ] **UC-M11.04-C079-T07 · Success/refusal fixtures:** Capture “External resource fencing” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M11.04-C079-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “External resource fencing” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M11.04-C079-T09 · Operator review:** Read the “External resource fencing” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M11.04-C079-T10 · Diagnostic evidence:** Publish redacted “External resource fencing” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M11.04-C080 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for external resource fencing; label unexecuted checks as untested.

- [ ] **UC-M11.04-C080-T01 · Evidence inventory:** List the “External resource fencing” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M11.04-C080-T02 · Artifact references:** Record the exact “External resource fencing” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M11.04-C080-T03 · Fixture references:** Attach the “External resource fencing” fixture IDs, input identities and oracle definition; preserve the source counterexample “A database accepts a stale owner's token after the controller transferred ownership” as a distinct evidence case.
- [ ] **UC-M11.04-C080-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “External resource fencing”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M11.04-C080-T05 · Environment record:** Record the actual “External resource fencing” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M11.04-C080-T06 · Expected versus observed:** Pair every “External resource fencing” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M11.04-C080-T07 · Failure and limit records:** Attach “External resource fencing” change/failure and bounds evidence where required; include uncovered “External resources and fencing checks” and unresolved violations of “Control-plane ownership changes are enforced at downstream mutation boundaries”.
- [ ] **UC-M11.04-C080-T08 · Evidence hygiene:** Check the “External resource fencing” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M11.04-C080-T09 · Reproduction review:** Have the “External resource fencing” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M11.04-C080-T10 · Acceptance linkage:** Link the “External resource fencing” evidence to its parent and UC-M11.04 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 09. Recovery and token reuse

**Source delivery:** Preserve fencing order across restoration and controller restart.

**Source invariant:** Restoring backups cannot reuse an already superseded authority token.

**Source negative case:** An old backup resets the fencing counter.

**Source bounded quantities:** Retained epochs and recovery scan size.

### UC-M11.04-C081 · Contract

**Original checklist item:** Specify recovery and token reuse inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M11.04-C081-T01 · Scope statement:** Draft the operation boundary for “Recovery and token reuse” within Leases, fencing and ownership transfer; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M11.04-C081-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Recovery and token reuse”; record each producer, representation and missing-value meaning.
- [ ] **UC-M11.04-C081-T03 · Output inventory:** List the outputs of “Recovery and token reuse” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M11.04-C081-T04 · Field dictionary:** Create a field-and-term dictionary for “Recovery and token reuse”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M11.04-C081-T05 · Prerequisite contract:** Map “Recovery and token reuse” to the source component prerequisites (UC-M01.05, UC-M11.03); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M11.04-C081-T06 · Authority map:** Identify who may produce, change and consume “Recovery and token reuse”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M11.04-C081-T07 · Invariant clause:** Add a normative clause for “Recovery and token reuse” that preserves “Restoring backups cannot reuse an already superseded authority token”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M11.04-C081-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Recovery and token reuse”; include the source counterexample “An old backup resets the fencing counter” and the intended safe disposition.
- [ ] **UC-M11.04-C081-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Retained epochs and recovery scan size” in the “Recovery and token reuse” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M11.04-C081-T10 · Contract review:** Review the “Recovery and token reuse” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M11.04-C082 · Delivery

**Original checklist item:** Preserve fencing order across restoration and controller restart.

- [ ] **UC-M11.04-C082-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Recovery and token reuse”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M11.04-C082-T02 · Change plan:** Break the source delivery for “Recovery and token reuse” into concrete edit targets and reviewable outputs; keep the UC-M11.04 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M11.04-C082-T03 · Core artifact:** Implement the smallest selected-profile change for “Recovery and token reuse” that realizes this source instruction: Preserve fencing order across restoration and controller restart.
- [ ] **UC-M11.04-C082-T04 · Concrete realization:** Trace “Recovery and token reuse” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M11.04-C082-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Recovery and token reuse” needed to preserve “Restoring backups cannot reuse an already superseded authority token”; record an enforcement gap where only a model exists.
- [ ] **UC-M11.04-C082-T06 · Dependency connection:** Connect the “Recovery and token reuse” implementation to consensus-backed ownership, lease epochs and commit-time downstream fencing; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M11.04-C082-T07 · Resource behavior:** Account for “Retained epochs and recovery scan size” in “Recovery and token reuse”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M11.04-C082-T08 · Delivery check:** Run the smallest real “Recovery and token reuse” path and its adverse fixture “An old backup resets the fencing counter”; retain actual output, state effects and final disposition.
- [ ] **UC-M11.04-C082-T09 · Patch review:** Review the “Recovery and token reuse” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M11.04-C082-T10 · Delivery handoff:** Publish the “Recovery and token reuse” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M11.04-C083 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Restoring backups cannot reuse an already superseded authority token. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M11.04-C083-T01 · Named property:** Create a stable property/check name under this parent for “Recovery and token reuse”; copy its required invariant exactly: “Restoring backups cannot reuse an already superseded authority token”.
- [ ] **UC-M11.04-C083-T02 · Observable terms:** Define each term in the “Recovery and token reuse” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M11.04-C083-T03 · Precondition set:** List the preconditions under which “Restoring backups cannot reuse an already superseded authority token” must hold for “Recovery and token reuse”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M11.04-C083-T04 · Transition coverage:** Map the “Recovery and token reuse” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M11.04-C083-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Recovery and token reuse”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M11.04-C083-T06 · Satisfying fixture:** Create a concrete “Recovery and token reuse” case that satisfies “Restoring backups cannot reuse an already superseded authority token”; record its expected observation before running the assertion or review.
- [ ] **UC-M11.04-C083-T07 · Violating fixture:** Create the source counterexample “An old backup resets the fencing counter” for “Recovery and token reuse”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M11.04-C083-T08 · Enforcement evidence:** Exercise the “Recovery and token reuse” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M11.04-C083-T09 · Regression linkage:** Link the “Recovery and token reuse” property to changes in consensus-backed ownership, lease epochs and commit-time downstream fencing; record which dependency or contract changes require rerunning it.
- [ ] **UC-M11.04-C083-T10 · Property disposition:** Compare the satisfying and violating “Recovery and token reuse” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M11.04-C084 · Integration

**Original checklist item:** Integrate recovery and token reuse with consensus-backed ownership, lease epochs and commit-time downstream fencing; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M11.04-C084-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Recovery and token reuse” across consensus-backed ownership, lease epochs and commit-time downstream fencing; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M11.04-C084-T02 · Field mapping:** Map every “Recovery and token reuse” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M11.04-C084-T03 · Prerequisite identities:** Record the actual prerequisites for “Recovery and token reuse” (source dependency list: UC-M01.05, UC-M11.03); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M11.04-C084-T04 · Ownership agreement:** Specify who owns “Recovery and token reuse” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M11.04-C084-T05 · Handoff implementation:** Connect “Recovery and token reuse” through the mapped seam using the real adapter or explicit specification reference; preserve “Restoring backups cannot reuse an already superseded authority token” across the handoff.
- [ ] **UC-M11.04-C084-T06 · Absent-input case:** Omit one required “Recovery and token reuse” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M11.04-C084-T07 · Stale-input case:** Supply an outdated “Recovery and token reuse” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M11.04-C084-T08 · Incompatible-input case:** Supply an incompatible “Recovery and token reuse” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M11.04-C084-T09 · Valid integration trace:** Run a valid “Recovery and token reuse” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M11.04-C084-T10 · Seam review:** Reconcile the “Recovery and token reuse” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M11.04-C085 · Valid-case test

**Original checklist item:** Run a valid-path fixture for recovery and token reuse; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M11.04-C085-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Recovery and token reuse” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M11.04-C085-T02 · Expected-result oracle:** Specify the “Recovery and token reuse” expected result independently of the implementation output; include the property “Restoring backups cannot reuse an already superseded authority token” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M11.04-C085-T03 · Fixture material:** Create the concrete “Recovery and token reuse” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M11.04-C085-T04 · Target preparation:** Prepare the “Recovery and token reuse” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M11.04-C085-T05 · Initial-state record:** Record the initial “Recovery and token reuse” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M11.04-C085-T06 · Valid-path execution:** Execute the “Recovery and token reuse” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M11.04-C085-T07 · Outcome comparison:** Compare every declared “Recovery and token reuse” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M11.04-C085-T08 · State and bounds check:** Inspect the “Recovery and token reuse” ownership/state effects and actual use of “Retained epochs and recovery scan size”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M11.04-C085-T09 · Repeatability check:** Repeat the same “Recovery and token reuse” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M11.04-C085-T10 · Positive evidence:** Attach the “Recovery and token reuse” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M11.04-C086 · Negative test

**Original checklist item:** Negative case: An old backup resets the fencing counter. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M11.04-C086-T01 · Adverse-case definition:** Create a test record for the exact “Recovery and token reuse” source counterexample: “An old backup resets the fencing counter”; state which precondition or invariant it challenges.
- [ ] **UC-M11.04-C086-T02 · Safe fixture boundary:** Define the contained test boundary for “Recovery and token reuse”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M11.04-C086-T03 · Valid control:** Construct a valid “Recovery and token reuse” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M11.04-C086-T04 · Minimal adverse input:** Derive the “Recovery and token reuse” adverse fixture from the control with the smallest documented change needed to reproduce “An old backup resets the fencing counter”; retain that change as reproducible data.
- [ ] **UC-M11.04-C086-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Recovery and token reuse”; require “Restoring backups cannot reuse an already superseded authority token” and forbid a false-success verdict.
- [ ] **UC-M11.04-C086-T06 · Adverse execution:** Exercise the “Recovery and token reuse” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M11.04-C086-T07 · Effect inspection:** Inspect “Recovery and token reuse” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M11.04-C086-T08 · Refusal versus failure:** Confirm the “Recovery and token reuse” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M11.04-C086-T09 · Reset and retention:** Restore only the disposable “Recovery and token reuse” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M11.04-C086-T10 · Negative regression:** Register the “Recovery and token reuse” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M11.04-C087 · Change / failure test

**Original checklist item:** Exercise recovery and token reuse when an isolated previous owner resumes after a new owner has been activated; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M11.04-C087-T01 · Scenario record:** Write the “Recovery and token reuse” change/failure scenario exactly as supplied: an isolated previous owner resumes after a new owner has been activated; identify the property that must remain true: “Restoring backups cannot reuse an already superseded authority token”.
- [ ] **UC-M11.04-C087-T02 · Baseline capture:** Create a known-valid “Recovery and token reuse” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M11.04-C087-T03 · Injection map:** Locate the “Recovery and token reuse” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M11.04-C087-T04 · Disposition oracle:** Define the legal intermediate and final “Recovery and token reuse” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M11.04-C087-T05 · Controlled trigger:** Introduce the controlled “Recovery and token reuse” scenario in the disposable fixture: an isolated previous owner resumes after a new owner has been activated; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M11.04-C087-T06 · Intermediate inspection:** Inspect the “Recovery and token reuse” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M11.04-C087-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Recovery and token reuse”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M11.04-C087-T08 · Stale-evidence cleanup:** Invalidate superseded “Recovery and token reuse” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M11.04-C087-T09 · Repeat and compare:** Repeat the selected “Recovery and token reuse” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M11.04-C087-T10 · Failure evidence:** Publish the “Recovery and token reuse” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M11.04-C088 · Bounds

**Original checklist item:** Choose, document and test limits for retained epochs and recovery scan size; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M11.04-C088-T01 · Quantity inventory:** Create a measurement inventory for “Recovery and token reuse”: “Retained epochs and recovery scan size”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M11.04-C088-T02 · Measurement method:** Choose how to observe each “Recovery and token reuse” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M11.04-C088-T03 · Budget decision:** Select justified resource and input limits for “Recovery and token reuse”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M11.04-C088-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Recovery and token reuse” cases for “Retained epochs and recovery scan size”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M11.04-C088-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Recovery and token reuse” limit; preserve “Restoring backups cannot reuse an already superseded authority token”.
- [ ] **UC-M11.04-C088-T06 · Normal measurement:** Run or review the normal “Recovery and token reuse” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M11.04-C088-T07 · At-limit measurement:** Exercise the “Recovery and token reuse” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M11.04-C088-T08 · Over-limit measurement:** Exercise the “Recovery and token reuse” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M11.04-C088-T09 · Uncovered-scope report:** List the “Recovery and token reuse” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M11.04-C088-T10 · Limit evidence:** Publish the selected “Recovery and token reuse” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M11.04-C089 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for recovery and token reuse with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M11.04-C089-T01 · Event inventory:** List the “Recovery and token reuse” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M11.04-C089-T02 · Diagnostic schema:** Define nonsecret fields for “Recovery and token reuse” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M11.04-C089-T03 · Failure mapping:** Map each documented “Recovery and token reuse” refusal or error to a diagnostic outcome; include “An old backup resets the fencing counter” and prohibit conversion into a success message.
- [ ] **UC-M11.04-C089-T04 · Emission path:** Add the “Recovery and token reuse” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M11.04-C089-T05 · Redaction check:** Test “Recovery and token reuse” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M11.04-C089-T06 · Output budget:** Set and exercise bounded “Recovery and token reuse” message size, rate and retention compatible with “Retained epochs and recovery scan size”; define truncation behavior that preserves the final reason.
- [ ] **UC-M11.04-C089-T07 · Success/refusal fixtures:** Capture “Recovery and token reuse” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M11.04-C089-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Recovery and token reuse” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M11.04-C089-T09 · Operator review:** Read the “Recovery and token reuse” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M11.04-C089-T10 · Diagnostic evidence:** Publish redacted “Recovery and token reuse” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M11.04-C090 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for recovery and token reuse; label unexecuted checks as untested.

- [ ] **UC-M11.04-C090-T01 · Evidence inventory:** List the “Recovery and token reuse” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M11.04-C090-T02 · Artifact references:** Record the exact “Recovery and token reuse” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M11.04-C090-T03 · Fixture references:** Attach the “Recovery and token reuse” fixture IDs, input identities and oracle definition; preserve the source counterexample “An old backup resets the fencing counter” as a distinct evidence case.
- [ ] **UC-M11.04-C090-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Recovery and token reuse”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M11.04-C090-T05 · Environment record:** Record the actual “Recovery and token reuse” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M11.04-C090-T06 · Expected versus observed:** Pair every “Recovery and token reuse” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M11.04-C090-T07 · Failure and limit records:** Attach “Recovery and token reuse” change/failure and bounds evidence where required; include uncovered “Retained epochs and recovery scan size” and unresolved violations of “Restoring backups cannot reuse an already superseded authority token”.
- [ ] **UC-M11.04-C090-T08 · Evidence hygiene:** Check the “Recovery and token reuse” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M11.04-C090-T09 · Reproduction review:** Have the “Recovery and token reuse” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M11.04-C090-T10 · Acceptance linkage:** Link the “Recovery and token reuse” evidence to its parent and UC-M11.04 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 10. Fencing qualification

**Source delivery:** Isolate an old owner, activate a new one and attempt stale commits.

**Source invariant:** The previous owner cannot mutate committed state after transfer.

**Source negative case:** The old worker's delayed write overwrites the new owner's state.

**Source bounded quantities:** Worker pairs and delayed-commit trials.

### UC-M11.04-C091 · Contract

**Original checklist item:** Specify fencing qualification inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M11.04-C091-T01 · Scope statement:** Draft the operation boundary for “Fencing qualification” within Leases, fencing and ownership transfer; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M11.04-C091-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Fencing qualification”; record each producer, representation and missing-value meaning.
- [ ] **UC-M11.04-C091-T03 · Output inventory:** List the outputs of “Fencing qualification” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M11.04-C091-T04 · Field dictionary:** Create a field-and-term dictionary for “Fencing qualification”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M11.04-C091-T05 · Prerequisite contract:** Map “Fencing qualification” to the source component prerequisites (UC-M01.05, UC-M11.03); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M11.04-C091-T06 · Authority map:** Identify who may produce, change and consume “Fencing qualification”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M11.04-C091-T07 · Invariant clause:** Add a normative clause for “Fencing qualification” that preserves “The previous owner cannot mutate committed state after transfer”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M11.04-C091-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Fencing qualification”; include the source counterexample “The old worker's delayed write overwrites the new owner's state” and the intended safe disposition.
- [ ] **UC-M11.04-C091-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Worker pairs and delayed-commit trials” in the “Fencing qualification” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M11.04-C091-T10 · Contract review:** Review the “Fencing qualification” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M11.04-C092 · Delivery

**Original checklist item:** Isolate an old owner, activate a new one and attempt stale commits.

- [ ] **UC-M11.04-C092-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Fencing qualification”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M11.04-C092-T02 · Change plan:** Break the source delivery for “Fencing qualification” into concrete edit targets and reviewable outputs; keep the UC-M11.04 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M11.04-C092-T03 · Core artifact:** Implement the smallest selected-profile change for “Fencing qualification” that realizes this source instruction: Isolate an old owner, activate a new one and attempt stale commits.
- [ ] **UC-M11.04-C092-T04 · Concrete realization:** Trace “Fencing qualification” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M11.04-C092-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Fencing qualification” needed to preserve “The previous owner cannot mutate committed state after transfer”; record an enforcement gap where only a model exists.
- [ ] **UC-M11.04-C092-T06 · Dependency connection:** Connect the “Fencing qualification” implementation to consensus-backed ownership, lease epochs and commit-time downstream fencing; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M11.04-C092-T07 · Resource behavior:** Account for “Worker pairs and delayed-commit trials” in “Fencing qualification”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M11.04-C092-T08 · Delivery check:** Run the smallest real “Fencing qualification” path and its adverse fixture “The old worker's delayed write overwrites the new owner's state”; retain actual output, state effects and final disposition.
- [ ] **UC-M11.04-C092-T09 · Patch review:** Review the “Fencing qualification” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M11.04-C092-T10 · Delivery handoff:** Publish the “Fencing qualification” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M11.04-C093 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: The previous owner cannot mutate committed state after transfer. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M11.04-C093-T01 · Named property:** Create a stable property/check name under this parent for “Fencing qualification”; copy its required invariant exactly: “The previous owner cannot mutate committed state after transfer”.
- [ ] **UC-M11.04-C093-T02 · Observable terms:** Define each term in the “Fencing qualification” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M11.04-C093-T03 · Precondition set:** List the preconditions under which “The previous owner cannot mutate committed state after transfer” must hold for “Fencing qualification”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M11.04-C093-T04 · Transition coverage:** Map the “Fencing qualification” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M11.04-C093-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Fencing qualification”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M11.04-C093-T06 · Satisfying fixture:** Create a concrete “Fencing qualification” case that satisfies “The previous owner cannot mutate committed state after transfer”; record its expected observation before running the assertion or review.
- [ ] **UC-M11.04-C093-T07 · Violating fixture:** Create the source counterexample “The old worker's delayed write overwrites the new owner's state” for “Fencing qualification”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M11.04-C093-T08 · Enforcement evidence:** Exercise the “Fencing qualification” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M11.04-C093-T09 · Regression linkage:** Link the “Fencing qualification” property to changes in consensus-backed ownership, lease epochs and commit-time downstream fencing; record which dependency or contract changes require rerunning it.
- [ ] **UC-M11.04-C093-T10 · Property disposition:** Compare the satisfying and violating “Fencing qualification” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M11.04-C094 · Integration

**Original checklist item:** Integrate fencing qualification with consensus-backed ownership, lease epochs and commit-time downstream fencing; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M11.04-C094-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Fencing qualification” across consensus-backed ownership, lease epochs and commit-time downstream fencing; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M11.04-C094-T02 · Field mapping:** Map every “Fencing qualification” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M11.04-C094-T03 · Prerequisite identities:** Record the actual prerequisites for “Fencing qualification” (source dependency list: UC-M01.05, UC-M11.03); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M11.04-C094-T04 · Ownership agreement:** Specify who owns “Fencing qualification” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M11.04-C094-T05 · Handoff implementation:** Connect “Fencing qualification” through the mapped seam using the real adapter or explicit specification reference; preserve “The previous owner cannot mutate committed state after transfer” across the handoff.
- [ ] **UC-M11.04-C094-T06 · Absent-input case:** Omit one required “Fencing qualification” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M11.04-C094-T07 · Stale-input case:** Supply an outdated “Fencing qualification” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M11.04-C094-T08 · Incompatible-input case:** Supply an incompatible “Fencing qualification” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M11.04-C094-T09 · Valid integration trace:** Run a valid “Fencing qualification” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M11.04-C094-T10 · Seam review:** Reconcile the “Fencing qualification” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M11.04-C095 · Valid-case test

**Original checklist item:** Run a valid-path fixture for fencing qualification; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M11.04-C095-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Fencing qualification” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M11.04-C095-T02 · Expected-result oracle:** Specify the “Fencing qualification” expected result independently of the implementation output; include the property “The previous owner cannot mutate committed state after transfer” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M11.04-C095-T03 · Fixture material:** Create the concrete “Fencing qualification” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M11.04-C095-T04 · Target preparation:** Prepare the “Fencing qualification” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M11.04-C095-T05 · Initial-state record:** Record the initial “Fencing qualification” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M11.04-C095-T06 · Valid-path execution:** Execute the “Fencing qualification” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M11.04-C095-T07 · Outcome comparison:** Compare every declared “Fencing qualification” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M11.04-C095-T08 · State and bounds check:** Inspect the “Fencing qualification” ownership/state effects and actual use of “Worker pairs and delayed-commit trials”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M11.04-C095-T09 · Repeatability check:** Repeat the same “Fencing qualification” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M11.04-C095-T10 · Positive evidence:** Attach the “Fencing qualification” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M11.04-C096 · Negative test

**Original checklist item:** Negative case: The old worker's delayed write overwrites the new owner's state. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M11.04-C096-T01 · Adverse-case definition:** Create a test record for the exact “Fencing qualification” source counterexample: “The old worker's delayed write overwrites the new owner's state”; state which precondition or invariant it challenges.
- [ ] **UC-M11.04-C096-T02 · Safe fixture boundary:** Define the contained test boundary for “Fencing qualification”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M11.04-C096-T03 · Valid control:** Construct a valid “Fencing qualification” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M11.04-C096-T04 · Minimal adverse input:** Derive the “Fencing qualification” adverse fixture from the control with the smallest documented change needed to reproduce “The old worker's delayed write overwrites the new owner's state”; retain that change as reproducible data.
- [ ] **UC-M11.04-C096-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Fencing qualification”; require “The previous owner cannot mutate committed state after transfer” and forbid a false-success verdict.
- [ ] **UC-M11.04-C096-T06 · Adverse execution:** Exercise the “Fencing qualification” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M11.04-C096-T07 · Effect inspection:** Inspect “Fencing qualification” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M11.04-C096-T08 · Refusal versus failure:** Confirm the “Fencing qualification” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M11.04-C096-T09 · Reset and retention:** Restore only the disposable “Fencing qualification” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M11.04-C096-T10 · Negative regression:** Register the “Fencing qualification” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M11.04-C097 · Change / failure test

**Original checklist item:** Exercise fencing qualification when an isolated previous owner resumes after a new owner has been activated; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M11.04-C097-T01 · Scenario record:** Write the “Fencing qualification” change/failure scenario exactly as supplied: an isolated previous owner resumes after a new owner has been activated; identify the property that must remain true: “The previous owner cannot mutate committed state after transfer”.
- [ ] **UC-M11.04-C097-T02 · Baseline capture:** Create a known-valid “Fencing qualification” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M11.04-C097-T03 · Injection map:** Locate the “Fencing qualification” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M11.04-C097-T04 · Disposition oracle:** Define the legal intermediate and final “Fencing qualification” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M11.04-C097-T05 · Controlled trigger:** Introduce the controlled “Fencing qualification” scenario in the disposable fixture: an isolated previous owner resumes after a new owner has been activated; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M11.04-C097-T06 · Intermediate inspection:** Inspect the “Fencing qualification” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M11.04-C097-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Fencing qualification”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M11.04-C097-T08 · Stale-evidence cleanup:** Invalidate superseded “Fencing qualification” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M11.04-C097-T09 · Repeat and compare:** Repeat the selected “Fencing qualification” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M11.04-C097-T10 · Failure evidence:** Publish the “Fencing qualification” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M11.04-C098 · Bounds

**Original checklist item:** Choose, document and test limits for worker pairs and delayed-commit trials; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M11.04-C098-T01 · Quantity inventory:** Create a measurement inventory for “Fencing qualification”: “Worker pairs and delayed-commit trials”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M11.04-C098-T02 · Measurement method:** Choose how to observe each “Fencing qualification” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M11.04-C098-T03 · Budget decision:** Select justified resource and input limits for “Fencing qualification”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M11.04-C098-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Fencing qualification” cases for “Worker pairs and delayed-commit trials”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M11.04-C098-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Fencing qualification” limit; preserve “The previous owner cannot mutate committed state after transfer”.
- [ ] **UC-M11.04-C098-T06 · Normal measurement:** Run or review the normal “Fencing qualification” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M11.04-C098-T07 · At-limit measurement:** Exercise the “Fencing qualification” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M11.04-C098-T08 · Over-limit measurement:** Exercise the “Fencing qualification” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M11.04-C098-T09 · Uncovered-scope report:** List the “Fencing qualification” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M11.04-C098-T10 · Limit evidence:** Publish the selected “Fencing qualification” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M11.04-C099 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for fencing qualification with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M11.04-C099-T01 · Event inventory:** List the “Fencing qualification” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M11.04-C099-T02 · Diagnostic schema:** Define nonsecret fields for “Fencing qualification” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M11.04-C099-T03 · Failure mapping:** Map each documented “Fencing qualification” refusal or error to a diagnostic outcome; include “The old worker's delayed write overwrites the new owner's state” and prohibit conversion into a success message.
- [ ] **UC-M11.04-C099-T04 · Emission path:** Add the “Fencing qualification” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M11.04-C099-T05 · Redaction check:** Test “Fencing qualification” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M11.04-C099-T06 · Output budget:** Set and exercise bounded “Fencing qualification” message size, rate and retention compatible with “Worker pairs and delayed-commit trials”; define truncation behavior that preserves the final reason.
- [ ] **UC-M11.04-C099-T07 · Success/refusal fixtures:** Capture “Fencing qualification” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M11.04-C099-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Fencing qualification” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M11.04-C099-T09 · Operator review:** Read the “Fencing qualification” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M11.04-C099-T10 · Diagnostic evidence:** Publish redacted “Fencing qualification” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M11.04-C100 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for fencing qualification; label unexecuted checks as untested.

- [ ] **UC-M11.04-C100-T01 · Evidence inventory:** List the “Fencing qualification” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M11.04-C100-T02 · Artifact references:** Record the exact “Fencing qualification” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M11.04-C100-T03 · Fixture references:** Attach the “Fencing qualification” fixture IDs, input identities and oracle definition; preserve the source counterexample “The old worker's delayed write overwrites the new owner's state” as a distinct evidence case.
- [ ] **UC-M11.04-C100-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Fencing qualification”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M11.04-C100-T05 · Environment record:** Record the actual “Fencing qualification” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M11.04-C100-T06 · Expected versus observed:** Pair every “Fencing qualification” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M11.04-C100-T07 · Failure and limit records:** Attach “Fencing qualification” change/failure and bounds evidence where required; include uncovered “Worker pairs and delayed-commit trials” and unresolved violations of “The previous owner cannot mutate committed state after transfer”.
- [ ] **UC-M11.04-C100-T08 · Evidence hygiene:** Check the “Fencing qualification” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M11.04-C100-T09 · Reproduction review:** Have the “Fencing qualification” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M11.04-C100-T10 · Acceptance linkage:** Link the “Fencing qualification” evidence to its parent and UC-M11.04 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

