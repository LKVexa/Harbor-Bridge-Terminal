# UC-M11.05 — Partition and failure-domain placement

**To-Do Pack 2.0.0 · Baseline UC-2.2.0 · 100 parent checks × 10 subtasks = 1,000 to-dos**

[Master index](../../INDEX.md) · [Workstream index](../../w/11.md)

| Field | Preserved source value |
|---|---|
| Workstream | 11. Optional multi-host federation |
| Milestone | D |
| Priority | P2 |
| Source assessment | MISSING |
| Scope | optional multi host |
| Dependencies | [UC-M05.02](../05/UC-M05.02.md), [UC-M11.04](../11/UC-M11.04.md) |
| Source checklist pack | 1.0.0 |
| Original reference labels | [S4], [S6]. |

## Original requirement

Model independent hosts/zones and partial connectivity; avoid treating four interpreters on one host as four fault domains.

**Original acceptance criterion:** Loss of one selected fault domain preserves the explicitly promised replicas and never double-commits state.

**Source trace:** Original checklist `UC100/c/11/UC-M11.05.md` inside [s/checklists.zip](../../s/checklists.zip); exact parent records in [data/parents.jsonl](../../data/parents.jsonl). Original roadmap lines 1043–1053 are preserved in [s/roadmap.md](../../s/roadmap.md).

## How to use these lists

Every parent statement below is preserved verbatim. Its ten child tasks are proposed decomposition, not implemented capabilities or executed tests. Child IDs append `-T01` through `-T10` to the original parent ID. All begin unchecked / `TODO`. Design/review evidence does not establish runtime enforcement; observe the actual selected target where the parent requires it.

The source dependency graph and selected release profile determine applicability. The numbered child sequence is a local working order, not an added hard dependency graph. An unselected optional feature needs a recorded not-applicable rationale; missing prerequisites for selected work remain blockers. Numerical budgets, backends and trust mechanisms remain decisions unless fixed by the source. Test hostile cases only with synthetic inputs in authorized disposable environments.

## 01. Failure-domain inventory

**Source delivery:** Model actual independent hosts and any selected zones or shared infrastructure.

**Source invariant:** Multiple interpreters on one host are not counted as independent host domains.

**Source negative case:** Four local processes are labeled four independent machines.

**Source bounded quantities:** Domains, hosts and metadata size.

### UC-M11.05-C001 · Contract

**Original checklist item:** Specify failure-domain inventory inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M11.05-C001-T01 · Scope statement:** Draft the operation boundary for “Failure-domain inventory” within Partition and failure-domain placement; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M11.05-C001-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Failure-domain inventory”; record each producer, representation and missing-value meaning.
- [ ] **UC-M11.05-C001-T03 · Output inventory:** List the outputs of “Failure-domain inventory” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M11.05-C001-T04 · Field dictionary:** Create a field-and-term dictionary for “Failure-domain inventory”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M11.05-C001-T05 · Prerequisite contract:** Map “Failure-domain inventory” to the source component prerequisites (UC-M05.02, UC-M11.04); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M11.05-C001-T06 · Authority map:** Identify who may produce, change and consume “Failure-domain inventory”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M11.05-C001-T07 · Invariant clause:** Add a normative clause for “Failure-domain inventory” that preserves “Multiple interpreters on one host are not counted as independent host domains”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M11.05-C001-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Failure-domain inventory”; include the source counterexample “Four local processes are labeled four independent machines” and the intended safe disposition.
- [ ] **UC-M11.05-C001-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Domains, hosts and metadata size” in the “Failure-domain inventory” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M11.05-C001-T10 · Contract review:** Review the “Failure-domain inventory” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M11.05-C002 · Delivery

**Original checklist item:** Model actual independent hosts and any selected zones or shared infrastructure.

- [ ] **UC-M11.05-C002-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Failure-domain inventory”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M11.05-C002-T02 · Change plan:** Break the source delivery for “Failure-domain inventory” into concrete edit targets and reviewable outputs; keep the UC-M11.05 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M11.05-C002-T03 · Core artifact:** Implement the smallest selected-profile change for “Failure-domain inventory” that realizes this source instruction: Model actual independent hosts and any selected zones or shared infrastructure.
- [ ] **UC-M11.05-C002-T04 · Concrete realization:** Trace “Failure-domain inventory” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M11.05-C002-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Failure-domain inventory” needed to preserve “Multiple interpreters on one host are not counted as independent host domains”; record an enforcement gap where only a model exists.
- [ ] **UC-M11.05-C002-T06 · Dependency connection:** Connect the “Failure-domain inventory” implementation to actual failure-domain inventory, resource-aware placement and ownership fencing; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M11.05-C002-T07 · Resource behavior:** Account for “Domains, hosts and metadata size” in “Failure-domain inventory”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M11.05-C002-T08 · Delivery check:** Run the smallest real “Failure-domain inventory” path and its adverse fixture “Four local processes are labeled four independent machines”; retain actual output, state effects and final disposition.
- [ ] **UC-M11.05-C002-T09 · Patch review:** Review the “Failure-domain inventory” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M11.05-C002-T10 · Delivery handoff:** Publish the “Failure-domain inventory” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M11.05-C003 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Multiple interpreters on one host are not counted as independent host domains. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M11.05-C003-T01 · Named property:** Create a stable property/check name under this parent for “Failure-domain inventory”; copy its required invariant exactly: “Multiple interpreters on one host are not counted as independent host domains”.
- [ ] **UC-M11.05-C003-T02 · Observable terms:** Define each term in the “Failure-domain inventory” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M11.05-C003-T03 · Precondition set:** List the preconditions under which “Multiple interpreters on one host are not counted as independent host domains” must hold for “Failure-domain inventory”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M11.05-C003-T04 · Transition coverage:** Map the “Failure-domain inventory” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M11.05-C003-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Failure-domain inventory”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M11.05-C003-T06 · Satisfying fixture:** Create a concrete “Failure-domain inventory” case that satisfies “Multiple interpreters on one host are not counted as independent host domains”; record its expected observation before running the assertion or review.
- [ ] **UC-M11.05-C003-T07 · Violating fixture:** Create the source counterexample “Four local processes are labeled four independent machines” for “Failure-domain inventory”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M11.05-C003-T08 · Enforcement evidence:** Exercise the “Failure-domain inventory” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M11.05-C003-T09 · Regression linkage:** Link the “Failure-domain inventory” property to changes in actual failure-domain inventory, resource-aware placement and ownership fencing; record which dependency or contract changes require rerunning it.
- [ ] **UC-M11.05-C003-T10 · Property disposition:** Compare the satisfying and violating “Failure-domain inventory” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M11.05-C004 · Integration

**Original checklist item:** Integrate failure-domain inventory with actual failure-domain inventory, resource-aware placement and ownership fencing; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M11.05-C004-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Failure-domain inventory” across actual failure-domain inventory, resource-aware placement and ownership fencing; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M11.05-C004-T02 · Field mapping:** Map every “Failure-domain inventory” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M11.05-C004-T03 · Prerequisite identities:** Record the actual prerequisites for “Failure-domain inventory” (source dependency list: UC-M05.02, UC-M11.04); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M11.05-C004-T04 · Ownership agreement:** Specify who owns “Failure-domain inventory” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M11.05-C004-T05 · Handoff implementation:** Connect “Failure-domain inventory” through the mapped seam using the real adapter or explicit specification reference; preserve “Multiple interpreters on one host are not counted as independent host domains” across the handoff.
- [ ] **UC-M11.05-C004-T06 · Absent-input case:** Omit one required “Failure-domain inventory” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M11.05-C004-T07 · Stale-input case:** Supply an outdated “Failure-domain inventory” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M11.05-C004-T08 · Incompatible-input case:** Supply an incompatible “Failure-domain inventory” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M11.05-C004-T09 · Valid integration trace:** Run a valid “Failure-domain inventory” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M11.05-C004-T10 · Seam review:** Reconcile the “Failure-domain inventory” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M11.05-C005 · Valid-case test

**Original checklist item:** Run a valid-path fixture for failure-domain inventory; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M11.05-C005-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Failure-domain inventory” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M11.05-C005-T02 · Expected-result oracle:** Specify the “Failure-domain inventory” expected result independently of the implementation output; include the property “Multiple interpreters on one host are not counted as independent host domains” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M11.05-C005-T03 · Fixture material:** Create the concrete “Failure-domain inventory” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M11.05-C005-T04 · Target preparation:** Prepare the “Failure-domain inventory” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M11.05-C005-T05 · Initial-state record:** Record the initial “Failure-domain inventory” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M11.05-C005-T06 · Valid-path execution:** Execute the “Failure-domain inventory” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M11.05-C005-T07 · Outcome comparison:** Compare every declared “Failure-domain inventory” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M11.05-C005-T08 · State and bounds check:** Inspect the “Failure-domain inventory” ownership/state effects and actual use of “Domains, hosts and metadata size”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M11.05-C005-T09 · Repeatability check:** Repeat the same “Failure-domain inventory” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M11.05-C005-T10 · Positive evidence:** Attach the “Failure-domain inventory” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M11.05-C006 · Negative test

**Original checklist item:** Negative case: Four local processes are labeled four independent machines. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M11.05-C006-T01 · Adverse-case definition:** Create a test record for the exact “Failure-domain inventory” source counterexample: “Four local processes are labeled four independent machines”; state which precondition or invariant it challenges.
- [ ] **UC-M11.05-C006-T02 · Safe fixture boundary:** Define the contained test boundary for “Failure-domain inventory”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M11.05-C006-T03 · Valid control:** Construct a valid “Failure-domain inventory” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M11.05-C006-T04 · Minimal adverse input:** Derive the “Failure-domain inventory” adverse fixture from the control with the smallest documented change needed to reproduce “Four local processes are labeled four independent machines”; retain that change as reproducible data.
- [ ] **UC-M11.05-C006-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Failure-domain inventory”; require “Multiple interpreters on one host are not counted as independent host domains” and forbid a false-success verdict.
- [ ] **UC-M11.05-C006-T06 · Adverse execution:** Exercise the “Failure-domain inventory” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M11.05-C006-T07 · Effect inspection:** Inspect “Failure-domain inventory” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M11.05-C006-T08 · Refusal versus failure:** Confirm the “Failure-domain inventory” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M11.05-C006-T09 · Reset and retention:** Restore only the disposable “Failure-domain inventory” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M11.05-C006-T10 · Negative regression:** Register the “Failure-domain inventory” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M11.05-C007 · Change / failure test

**Original checklist item:** Exercise failure-domain inventory when one selected host/domain becomes unreachable through a partial partition; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M11.05-C007-T01 · Scenario record:** Write the “Failure-domain inventory” change/failure scenario exactly as supplied: one selected host/domain becomes unreachable through a partial partition; identify the property that must remain true: “Multiple interpreters on one host are not counted as independent host domains”.
- [ ] **UC-M11.05-C007-T02 · Baseline capture:** Create a known-valid “Failure-domain inventory” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M11.05-C007-T03 · Injection map:** Locate the “Failure-domain inventory” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M11.05-C007-T04 · Disposition oracle:** Define the legal intermediate and final “Failure-domain inventory” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M11.05-C007-T05 · Controlled trigger:** Introduce the controlled “Failure-domain inventory” scenario in the disposable fixture: one selected host/domain becomes unreachable through a partial partition; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M11.05-C007-T06 · Intermediate inspection:** Inspect the “Failure-domain inventory” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M11.05-C007-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Failure-domain inventory”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M11.05-C007-T08 · Stale-evidence cleanup:** Invalidate superseded “Failure-domain inventory” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M11.05-C007-T09 · Repeat and compare:** Repeat the selected “Failure-domain inventory” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M11.05-C007-T10 · Failure evidence:** Publish the “Failure-domain inventory” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M11.05-C008 · Bounds

**Original checklist item:** Choose, document and test limits for domains, hosts and metadata size; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M11.05-C008-T01 · Quantity inventory:** Create a measurement inventory for “Failure-domain inventory”: “Domains, hosts and metadata size”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M11.05-C008-T02 · Measurement method:** Choose how to observe each “Failure-domain inventory” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M11.05-C008-T03 · Budget decision:** Select justified resource and input limits for “Failure-domain inventory”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M11.05-C008-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Failure-domain inventory” cases for “Domains, hosts and metadata size”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M11.05-C008-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Failure-domain inventory” limit; preserve “Multiple interpreters on one host are not counted as independent host domains”.
- [ ] **UC-M11.05-C008-T06 · Normal measurement:** Run or review the normal “Failure-domain inventory” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M11.05-C008-T07 · At-limit measurement:** Exercise the “Failure-domain inventory” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M11.05-C008-T08 · Over-limit measurement:** Exercise the “Failure-domain inventory” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M11.05-C008-T09 · Uncovered-scope report:** List the “Failure-domain inventory” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M11.05-C008-T10 · Limit evidence:** Publish the selected “Failure-domain inventory” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M11.05-C009 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for failure-domain inventory with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M11.05-C009-T01 · Event inventory:** List the “Failure-domain inventory” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M11.05-C009-T02 · Diagnostic schema:** Define nonsecret fields for “Failure-domain inventory” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M11.05-C009-T03 · Failure mapping:** Map each documented “Failure-domain inventory” refusal or error to a diagnostic outcome; include “Four local processes are labeled four independent machines” and prohibit conversion into a success message.
- [ ] **UC-M11.05-C009-T04 · Emission path:** Add the “Failure-domain inventory” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M11.05-C009-T05 · Redaction check:** Test “Failure-domain inventory” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M11.05-C009-T06 · Output budget:** Set and exercise bounded “Failure-domain inventory” message size, rate and retention compatible with “Domains, hosts and metadata size”; define truncation behavior that preserves the final reason.
- [ ] **UC-M11.05-C009-T07 · Success/refusal fixtures:** Capture “Failure-domain inventory” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M11.05-C009-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Failure-domain inventory” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M11.05-C009-T09 · Operator review:** Read the “Failure-domain inventory” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M11.05-C009-T10 · Diagnostic evidence:** Publish redacted “Failure-domain inventory” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M11.05-C010 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for failure-domain inventory; label unexecuted checks as untested.

- [ ] **UC-M11.05-C010-T01 · Evidence inventory:** List the “Failure-domain inventory” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M11.05-C010-T02 · Artifact references:** Record the exact “Failure-domain inventory” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M11.05-C010-T03 · Fixture references:** Attach the “Failure-domain inventory” fixture IDs, input identities and oracle definition; preserve the source counterexample “Four local processes are labeled four independent machines” as a distinct evidence case.
- [ ] **UC-M11.05-C010-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Failure-domain inventory”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M11.05-C010-T05 · Environment record:** Record the actual “Failure-domain inventory” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M11.05-C010-T06 · Expected versus observed:** Pair every “Failure-domain inventory” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M11.05-C010-T07 · Failure and limit records:** Attach “Failure-domain inventory” change/failure and bounds evidence where required; include uncovered “Domains, hosts and metadata size” and unresolved violations of “Multiple interpreters on one host are not counted as independent host domains”.
- [ ] **UC-M11.05-C010-T08 · Evidence hygiene:** Check the “Failure-domain inventory” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M11.05-C010-T09 · Reproduction review:** Have the “Failure-domain inventory” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M11.05-C010-T10 · Acceptance linkage:** Link the “Failure-domain inventory” evidence to its parent and UC-M11.05 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 02. Topology provenance

**Source delivery:** Record the physical or operator-declared relationships behind each domain label.

**Source invariant:** Placement claims identify the evidence supporting independence.

**Source negative case:** Two hosts share one failure source but are counted as unrelated domains.

**Source bounded quantities:** Topology records and review scope.

### UC-M11.05-C011 · Contract

**Original checklist item:** Specify topology provenance inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M11.05-C011-T01 · Scope statement:** Draft the operation boundary for “Topology provenance” within Partition and failure-domain placement; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M11.05-C011-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Topology provenance”; record each producer, representation and missing-value meaning.
- [ ] **UC-M11.05-C011-T03 · Output inventory:** List the outputs of “Topology provenance” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M11.05-C011-T04 · Field dictionary:** Create a field-and-term dictionary for “Topology provenance”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M11.05-C011-T05 · Prerequisite contract:** Map “Topology provenance” to the source component prerequisites (UC-M05.02, UC-M11.04); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M11.05-C011-T06 · Authority map:** Identify who may produce, change and consume “Topology provenance”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M11.05-C011-T07 · Invariant clause:** Add a normative clause for “Topology provenance” that preserves “Placement claims identify the evidence supporting independence”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M11.05-C011-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Topology provenance”; include the source counterexample “Two hosts share one failure source but are counted as unrelated domains” and the intended safe disposition.
- [ ] **UC-M11.05-C011-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Topology records and review scope” in the “Topology provenance” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M11.05-C011-T10 · Contract review:** Review the “Topology provenance” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M11.05-C012 · Delivery

**Original checklist item:** Record the physical or operator-declared relationships behind each domain label.

- [ ] **UC-M11.05-C012-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Topology provenance”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M11.05-C012-T02 · Change plan:** Break the source delivery for “Topology provenance” into concrete edit targets and reviewable outputs; keep the UC-M11.05 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M11.05-C012-T03 · Core artifact:** Create the “Topology provenance” model, schema or inventory that realizes this source instruction: Record the physical or operator-declared relationships behind each domain label.
- [ ] **UC-M11.05-C012-T04 · Concrete realization:** Populate “Topology provenance” with one concrete worked case; map every required entity or field to its source and flag any unmapped entry.
- [ ] **UC-M11.05-C012-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Topology provenance” needed to preserve “Placement claims identify the evidence supporting independence”; record an enforcement gap where only a model exists.
- [ ] **UC-M11.05-C012-T06 · Dependency connection:** Connect the “Topology provenance” implementation to actual failure-domain inventory, resource-aware placement and ownership fencing; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M11.05-C012-T07 · Resource behavior:** Account for “Topology records and review scope” in “Topology provenance”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M11.05-C012-T08 · Delivery check:** Run the smallest real “Topology provenance” path and its adverse fixture “Two hosts share one failure source but are counted as unrelated domains”; retain actual output, state effects and final disposition.
- [ ] **UC-M11.05-C012-T09 · Patch review:** Review the “Topology provenance” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M11.05-C012-T10 · Delivery handoff:** Publish the “Topology provenance” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M11.05-C013 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Placement claims identify the evidence supporting independence. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M11.05-C013-T01 · Named property:** Create a stable property/check name under this parent for “Topology provenance”; copy its required invariant exactly: “Placement claims identify the evidence supporting independence”.
- [ ] **UC-M11.05-C013-T02 · Observable terms:** Define each term in the “Topology provenance” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M11.05-C013-T03 · Precondition set:** List the preconditions under which “Placement claims identify the evidence supporting independence” must hold for “Topology provenance”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M11.05-C013-T04 · Transition coverage:** Map the “Topology provenance” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M11.05-C013-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Topology provenance”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M11.05-C013-T06 · Satisfying fixture:** Create a concrete “Topology provenance” case that satisfies “Placement claims identify the evidence supporting independence”; record its expected observation before running the assertion or review.
- [ ] **UC-M11.05-C013-T07 · Violating fixture:** Create the source counterexample “Two hosts share one failure source but are counted as unrelated domains” for “Topology provenance”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M11.05-C013-T08 · Enforcement evidence:** Exercise the “Topology provenance” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M11.05-C013-T09 · Regression linkage:** Link the “Topology provenance” property to changes in actual failure-domain inventory, resource-aware placement and ownership fencing; record which dependency or contract changes require rerunning it.
- [ ] **UC-M11.05-C013-T10 · Property disposition:** Compare the satisfying and violating “Topology provenance” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M11.05-C014 · Integration

**Original checklist item:** Integrate topology provenance with actual failure-domain inventory, resource-aware placement and ownership fencing; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M11.05-C014-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Topology provenance” across actual failure-domain inventory, resource-aware placement and ownership fencing; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M11.05-C014-T02 · Field mapping:** Map every “Topology provenance” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M11.05-C014-T03 · Prerequisite identities:** Record the actual prerequisites for “Topology provenance” (source dependency list: UC-M05.02, UC-M11.04); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M11.05-C014-T04 · Ownership agreement:** Specify who owns “Topology provenance” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M11.05-C014-T05 · Handoff implementation:** Connect “Topology provenance” through the mapped seam using the real adapter or explicit specification reference; preserve “Placement claims identify the evidence supporting independence” across the handoff.
- [ ] **UC-M11.05-C014-T06 · Absent-input case:** Omit one required “Topology provenance” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M11.05-C014-T07 · Stale-input case:** Supply an outdated “Topology provenance” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M11.05-C014-T08 · Incompatible-input case:** Supply an incompatible “Topology provenance” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M11.05-C014-T09 · Valid integration trace:** Run a valid “Topology provenance” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M11.05-C014-T10 · Seam review:** Reconcile the “Topology provenance” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M11.05-C015 · Valid-case test

**Original checklist item:** Run a valid-path fixture for topology provenance; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M11.05-C015-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Topology provenance” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M11.05-C015-T02 · Expected-result oracle:** Specify the “Topology provenance” expected result independently of the implementation output; include the property “Placement claims identify the evidence supporting independence” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M11.05-C015-T03 · Fixture material:** Create the concrete “Topology provenance” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M11.05-C015-T04 · Target preparation:** Prepare the “Topology provenance” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M11.05-C015-T05 · Initial-state record:** Record the initial “Topology provenance” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M11.05-C015-T06 · Valid-path execution:** Execute the “Topology provenance” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M11.05-C015-T07 · Outcome comparison:** Compare every declared “Topology provenance” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M11.05-C015-T08 · State and bounds check:** Inspect the “Topology provenance” ownership/state effects and actual use of “Topology records and review scope”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M11.05-C015-T09 · Repeatability check:** Repeat the same “Topology provenance” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M11.05-C015-T10 · Positive evidence:** Attach the “Topology provenance” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M11.05-C016 · Negative test

**Original checklist item:** Negative case: Two hosts share one failure source but are counted as unrelated domains. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M11.05-C016-T01 · Adverse-case definition:** Create a test record for the exact “Topology provenance” source counterexample: “Two hosts share one failure source but are counted as unrelated domains”; state which precondition or invariant it challenges.
- [ ] **UC-M11.05-C016-T02 · Safe fixture boundary:** Define the contained test boundary for “Topology provenance”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M11.05-C016-T03 · Valid control:** Construct a valid “Topology provenance” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M11.05-C016-T04 · Minimal adverse input:** Derive the “Topology provenance” adverse fixture from the control with the smallest documented change needed to reproduce “Two hosts share one failure source but are counted as unrelated domains”; retain that change as reproducible data.
- [ ] **UC-M11.05-C016-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Topology provenance”; require “Placement claims identify the evidence supporting independence” and forbid a false-success verdict.
- [ ] **UC-M11.05-C016-T06 · Adverse execution:** Exercise the “Topology provenance” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M11.05-C016-T07 · Effect inspection:** Inspect “Topology provenance” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M11.05-C016-T08 · Refusal versus failure:** Confirm the “Topology provenance” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M11.05-C016-T09 · Reset and retention:** Restore only the disposable “Topology provenance” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M11.05-C016-T10 · Negative regression:** Register the “Topology provenance” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M11.05-C017 · Change / failure test

**Original checklist item:** Exercise topology provenance when one selected host/domain becomes unreachable through a partial partition; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M11.05-C017-T01 · Scenario record:** Write the “Topology provenance” change/failure scenario exactly as supplied: one selected host/domain becomes unreachable through a partial partition; identify the property that must remain true: “Placement claims identify the evidence supporting independence”.
- [ ] **UC-M11.05-C017-T02 · Baseline capture:** Create a known-valid “Topology provenance” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M11.05-C017-T03 · Injection map:** Locate the “Topology provenance” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M11.05-C017-T04 · Disposition oracle:** Define the legal intermediate and final “Topology provenance” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M11.05-C017-T05 · Controlled trigger:** Introduce the controlled “Topology provenance” scenario in the disposable fixture: one selected host/domain becomes unreachable through a partial partition; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M11.05-C017-T06 · Intermediate inspection:** Inspect the “Topology provenance” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M11.05-C017-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Topology provenance”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M11.05-C017-T08 · Stale-evidence cleanup:** Invalidate superseded “Topology provenance” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M11.05-C017-T09 · Repeat and compare:** Repeat the selected “Topology provenance” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M11.05-C017-T10 · Failure evidence:** Publish the “Topology provenance” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M11.05-C018 · Bounds

**Original checklist item:** Choose, document and test limits for topology records and review scope; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M11.05-C018-T01 · Quantity inventory:** Create a measurement inventory for “Topology provenance”: “Topology records and review scope”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M11.05-C018-T02 · Measurement method:** Choose how to observe each “Topology provenance” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M11.05-C018-T03 · Budget decision:** Select justified resource and input limits for “Topology provenance”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M11.05-C018-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Topology provenance” cases for “Topology records and review scope”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M11.05-C018-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Topology provenance” limit; preserve “Placement claims identify the evidence supporting independence”.
- [ ] **UC-M11.05-C018-T06 · Normal measurement:** Run or review the normal “Topology provenance” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M11.05-C018-T07 · At-limit measurement:** Exercise the “Topology provenance” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M11.05-C018-T08 · Over-limit measurement:** Exercise the “Topology provenance” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M11.05-C018-T09 · Uncovered-scope report:** List the “Topology provenance” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M11.05-C018-T10 · Limit evidence:** Publish the selected “Topology provenance” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M11.05-C019 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for topology provenance with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M11.05-C019-T01 · Event inventory:** List the “Topology provenance” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M11.05-C019-T02 · Diagnostic schema:** Define nonsecret fields for “Topology provenance” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M11.05-C019-T03 · Failure mapping:** Map each documented “Topology provenance” refusal or error to a diagnostic outcome; include “Two hosts share one failure source but are counted as unrelated domains” and prohibit conversion into a success message.
- [ ] **UC-M11.05-C019-T04 · Emission path:** Add the “Topology provenance” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M11.05-C019-T05 · Redaction check:** Test “Topology provenance” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M11.05-C019-T06 · Output budget:** Set and exercise bounded “Topology provenance” message size, rate and retention compatible with “Topology records and review scope”; define truncation behavior that preserves the final reason.
- [ ] **UC-M11.05-C019-T07 · Success/refusal fixtures:** Capture “Topology provenance” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M11.05-C019-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Topology provenance” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M11.05-C019-T09 · Operator review:** Read the “Topology provenance” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M11.05-C019-T10 · Diagnostic evidence:** Publish redacted “Topology provenance” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M11.05-C020 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for topology provenance; label unexecuted checks as untested.

- [ ] **UC-M11.05-C020-T01 · Evidence inventory:** List the “Topology provenance” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M11.05-C020-T02 · Artifact references:** Record the exact “Topology provenance” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M11.05-C020-T03 · Fixture references:** Attach the “Topology provenance” fixture IDs, input identities and oracle definition; preserve the source counterexample “Two hosts share one failure source but are counted as unrelated domains” as a distinct evidence case.
- [ ] **UC-M11.05-C020-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Topology provenance”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M11.05-C020-T05 · Environment record:** Record the actual “Topology provenance” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M11.05-C020-T06 · Expected versus observed:** Pair every “Topology provenance” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M11.05-C020-T07 · Failure and limit records:** Attach “Topology provenance” change/failure and bounds evidence where required; include uncovered “Topology records and review scope” and unresolved violations of “Placement claims identify the evidence supporting independence”.
- [ ] **UC-M11.05-C020-T08 · Evidence hygiene:** Check the “Topology provenance” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M11.05-C020-T09 · Reproduction review:** Have the “Topology provenance” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M11.05-C020-T10 · Acceptance linkage:** Link the “Topology provenance” evidence to its parent and UC-M11.05 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 03. Replica placement constraints

**Source delivery:** Express required separation and capacity constraints for selected workloads.

**Source invariant:** Placement cannot claim resilience beyond its enforced domain constraints.

**Source negative case:** All required replicas are placed in one declared failure domain.

**Source bounded quantities:** Replicas and candidate domains.

### UC-M11.05-C021 · Contract

**Original checklist item:** Specify replica placement constraints inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M11.05-C021-T01 · Scope statement:** Draft the operation boundary for “Replica placement constraints” within Partition and failure-domain placement; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M11.05-C021-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Replica placement constraints”; record each producer, representation and missing-value meaning.
- [ ] **UC-M11.05-C021-T03 · Output inventory:** List the outputs of “Replica placement constraints” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M11.05-C021-T04 · Field dictionary:** Create a field-and-term dictionary for “Replica placement constraints”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M11.05-C021-T05 · Prerequisite contract:** Map “Replica placement constraints” to the source component prerequisites (UC-M05.02, UC-M11.04); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M11.05-C021-T06 · Authority map:** Identify who may produce, change and consume “Replica placement constraints”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M11.05-C021-T07 · Invariant clause:** Add a normative clause for “Replica placement constraints” that preserves “Placement cannot claim resilience beyond its enforced domain constraints”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M11.05-C021-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Replica placement constraints”; include the source counterexample “All required replicas are placed in one declared failure domain” and the intended safe disposition.
- [ ] **UC-M11.05-C021-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Replicas and candidate domains” in the “Replica placement constraints” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M11.05-C021-T10 · Contract review:** Review the “Replica placement constraints” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M11.05-C022 · Delivery

**Original checklist item:** Express required separation and capacity constraints for selected workloads.

- [ ] **UC-M11.05-C022-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Replica placement constraints”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M11.05-C022-T02 · Change plan:** Break the source delivery for “Replica placement constraints” into concrete edit targets and reviewable outputs; keep the UC-M11.05 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M11.05-C022-T03 · Core artifact:** Implement the smallest selected-profile change for “Replica placement constraints” that realizes this source instruction: Express required separation and capacity constraints for selected workloads.
- [ ] **UC-M11.05-C022-T04 · Concrete realization:** Trace “Replica placement constraints” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M11.05-C022-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Replica placement constraints” needed to preserve “Placement cannot claim resilience beyond its enforced domain constraints”; record an enforcement gap where only a model exists.
- [ ] **UC-M11.05-C022-T06 · Dependency connection:** Connect the “Replica placement constraints” implementation to actual failure-domain inventory, resource-aware placement and ownership fencing; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M11.05-C022-T07 · Resource behavior:** Account for “Replicas and candidate domains” in “Replica placement constraints”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M11.05-C022-T08 · Delivery check:** Run the smallest real “Replica placement constraints” path and its adverse fixture “All required replicas are placed in one declared failure domain”; retain actual output, state effects and final disposition.
- [ ] **UC-M11.05-C022-T09 · Patch review:** Review the “Replica placement constraints” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M11.05-C022-T10 · Delivery handoff:** Publish the “Replica placement constraints” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M11.05-C023 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Placement cannot claim resilience beyond its enforced domain constraints. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M11.05-C023-T01 · Named property:** Create a stable property/check name under this parent for “Replica placement constraints”; copy its required invariant exactly: “Placement cannot claim resilience beyond its enforced domain constraints”.
- [ ] **UC-M11.05-C023-T02 · Observable terms:** Define each term in the “Replica placement constraints” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M11.05-C023-T03 · Precondition set:** List the preconditions under which “Placement cannot claim resilience beyond its enforced domain constraints” must hold for “Replica placement constraints”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M11.05-C023-T04 · Transition coverage:** Map the “Replica placement constraints” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M11.05-C023-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Replica placement constraints”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M11.05-C023-T06 · Satisfying fixture:** Create a concrete “Replica placement constraints” case that satisfies “Placement cannot claim resilience beyond its enforced domain constraints”; record its expected observation before running the assertion or review.
- [ ] **UC-M11.05-C023-T07 · Violating fixture:** Create the source counterexample “All required replicas are placed in one declared failure domain” for “Replica placement constraints”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M11.05-C023-T08 · Enforcement evidence:** Exercise the “Replica placement constraints” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M11.05-C023-T09 · Regression linkage:** Link the “Replica placement constraints” property to changes in actual failure-domain inventory, resource-aware placement and ownership fencing; record which dependency or contract changes require rerunning it.
- [ ] **UC-M11.05-C023-T10 · Property disposition:** Compare the satisfying and violating “Replica placement constraints” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M11.05-C024 · Integration

**Original checklist item:** Integrate replica placement constraints with actual failure-domain inventory, resource-aware placement and ownership fencing; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M11.05-C024-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Replica placement constraints” across actual failure-domain inventory, resource-aware placement and ownership fencing; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M11.05-C024-T02 · Field mapping:** Map every “Replica placement constraints” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M11.05-C024-T03 · Prerequisite identities:** Record the actual prerequisites for “Replica placement constraints” (source dependency list: UC-M05.02, UC-M11.04); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M11.05-C024-T04 · Ownership agreement:** Specify who owns “Replica placement constraints” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M11.05-C024-T05 · Handoff implementation:** Connect “Replica placement constraints” through the mapped seam using the real adapter or explicit specification reference; preserve “Placement cannot claim resilience beyond its enforced domain constraints” across the handoff.
- [ ] **UC-M11.05-C024-T06 · Absent-input case:** Omit one required “Replica placement constraints” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M11.05-C024-T07 · Stale-input case:** Supply an outdated “Replica placement constraints” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M11.05-C024-T08 · Incompatible-input case:** Supply an incompatible “Replica placement constraints” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M11.05-C024-T09 · Valid integration trace:** Run a valid “Replica placement constraints” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M11.05-C024-T10 · Seam review:** Reconcile the “Replica placement constraints” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M11.05-C025 · Valid-case test

**Original checklist item:** Run a valid-path fixture for replica placement constraints; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M11.05-C025-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Replica placement constraints” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M11.05-C025-T02 · Expected-result oracle:** Specify the “Replica placement constraints” expected result independently of the implementation output; include the property “Placement cannot claim resilience beyond its enforced domain constraints” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M11.05-C025-T03 · Fixture material:** Create the concrete “Replica placement constraints” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M11.05-C025-T04 · Target preparation:** Prepare the “Replica placement constraints” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M11.05-C025-T05 · Initial-state record:** Record the initial “Replica placement constraints” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M11.05-C025-T06 · Valid-path execution:** Execute the “Replica placement constraints” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M11.05-C025-T07 · Outcome comparison:** Compare every declared “Replica placement constraints” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M11.05-C025-T08 · State and bounds check:** Inspect the “Replica placement constraints” ownership/state effects and actual use of “Replicas and candidate domains”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M11.05-C025-T09 · Repeatability check:** Repeat the same “Replica placement constraints” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M11.05-C025-T10 · Positive evidence:** Attach the “Replica placement constraints” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M11.05-C026 · Negative test

**Original checklist item:** Negative case: All required replicas are placed in one declared failure domain. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M11.05-C026-T01 · Adverse-case definition:** Create a test record for the exact “Replica placement constraints” source counterexample: “All required replicas are placed in one declared failure domain”; state which precondition or invariant it challenges.
- [ ] **UC-M11.05-C026-T02 · Safe fixture boundary:** Define the contained test boundary for “Replica placement constraints”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M11.05-C026-T03 · Valid control:** Construct a valid “Replica placement constraints” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M11.05-C026-T04 · Minimal adverse input:** Derive the “Replica placement constraints” adverse fixture from the control with the smallest documented change needed to reproduce “All required replicas are placed in one declared failure domain”; retain that change as reproducible data.
- [ ] **UC-M11.05-C026-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Replica placement constraints”; require “Placement cannot claim resilience beyond its enforced domain constraints” and forbid a false-success verdict.
- [ ] **UC-M11.05-C026-T06 · Adverse execution:** Exercise the “Replica placement constraints” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M11.05-C026-T07 · Effect inspection:** Inspect “Replica placement constraints” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M11.05-C026-T08 · Refusal versus failure:** Confirm the “Replica placement constraints” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M11.05-C026-T09 · Reset and retention:** Restore only the disposable “Replica placement constraints” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M11.05-C026-T10 · Negative regression:** Register the “Replica placement constraints” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M11.05-C027 · Change / failure test

**Original checklist item:** Exercise replica placement constraints when one selected host/domain becomes unreachable through a partial partition; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M11.05-C027-T01 · Scenario record:** Write the “Replica placement constraints” change/failure scenario exactly as supplied: one selected host/domain becomes unreachable through a partial partition; identify the property that must remain true: “Placement cannot claim resilience beyond its enforced domain constraints”.
- [ ] **UC-M11.05-C027-T02 · Baseline capture:** Create a known-valid “Replica placement constraints” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M11.05-C027-T03 · Injection map:** Locate the “Replica placement constraints” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M11.05-C027-T04 · Disposition oracle:** Define the legal intermediate and final “Replica placement constraints” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M11.05-C027-T05 · Controlled trigger:** Introduce the controlled “Replica placement constraints” scenario in the disposable fixture: one selected host/domain becomes unreachable through a partial partition; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M11.05-C027-T06 · Intermediate inspection:** Inspect the “Replica placement constraints” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M11.05-C027-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Replica placement constraints”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M11.05-C027-T08 · Stale-evidence cleanup:** Invalidate superseded “Replica placement constraints” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M11.05-C027-T09 · Repeat and compare:** Repeat the selected “Replica placement constraints” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M11.05-C027-T10 · Failure evidence:** Publish the “Replica placement constraints” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M11.05-C028 · Bounds

**Original checklist item:** Choose, document and test limits for replicas and candidate domains; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M11.05-C028-T01 · Quantity inventory:** Create a measurement inventory for “Replica placement constraints”: “Replicas and candidate domains”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M11.05-C028-T02 · Measurement method:** Choose how to observe each “Replica placement constraints” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M11.05-C028-T03 · Budget decision:** Select justified resource and input limits for “Replica placement constraints”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M11.05-C028-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Replica placement constraints” cases for “Replicas and candidate domains”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M11.05-C028-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Replica placement constraints” limit; preserve “Placement cannot claim resilience beyond its enforced domain constraints”.
- [ ] **UC-M11.05-C028-T06 · Normal measurement:** Run or review the normal “Replica placement constraints” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M11.05-C028-T07 · At-limit measurement:** Exercise the “Replica placement constraints” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M11.05-C028-T08 · Over-limit measurement:** Exercise the “Replica placement constraints” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M11.05-C028-T09 · Uncovered-scope report:** List the “Replica placement constraints” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M11.05-C028-T10 · Limit evidence:** Publish the selected “Replica placement constraints” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M11.05-C029 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for replica placement constraints with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M11.05-C029-T01 · Event inventory:** List the “Replica placement constraints” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M11.05-C029-T02 · Diagnostic schema:** Define nonsecret fields for “Replica placement constraints” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M11.05-C029-T03 · Failure mapping:** Map each documented “Replica placement constraints” refusal or error to a diagnostic outcome; include “All required replicas are placed in one declared failure domain” and prohibit conversion into a success message.
- [ ] **UC-M11.05-C029-T04 · Emission path:** Add the “Replica placement constraints” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M11.05-C029-T05 · Redaction check:** Test “Replica placement constraints” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M11.05-C029-T06 · Output budget:** Set and exercise bounded “Replica placement constraints” message size, rate and retention compatible with “Replicas and candidate domains”; define truncation behavior that preserves the final reason.
- [ ] **UC-M11.05-C029-T07 · Success/refusal fixtures:** Capture “Replica placement constraints” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M11.05-C029-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Replica placement constraints” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M11.05-C029-T09 · Operator review:** Read the “Replica placement constraints” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M11.05-C029-T10 · Diagnostic evidence:** Publish redacted “Replica placement constraints” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M11.05-C030 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for replica placement constraints; label unexecuted checks as untested.

- [ ] **UC-M11.05-C030-T01 · Evidence inventory:** List the “Replica placement constraints” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M11.05-C030-T02 · Artifact references:** Record the exact “Replica placement constraints” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M11.05-C030-T03 · Fixture references:** Attach the “Replica placement constraints” fixture IDs, input identities and oracle definition; preserve the source counterexample “All required replicas are placed in one declared failure domain” as a distinct evidence case.
- [ ] **UC-M11.05-C030-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Replica placement constraints”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M11.05-C030-T05 · Environment record:** Record the actual “Replica placement constraints” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M11.05-C030-T06 · Expected versus observed:** Pair every “Replica placement constraints” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M11.05-C030-T07 · Failure and limit records:** Attach “Replica placement constraints” change/failure and bounds evidence where required; include uncovered “Replicas and candidate domains” and unresolved violations of “Placement cannot claim resilience beyond its enforced domain constraints”.
- [ ] **UC-M11.05-C030-T08 · Evidence hygiene:** Check the “Replica placement constraints” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M11.05-C030-T09 · Reproduction review:** Have the “Replica placement constraints” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M11.05-C030-T10 · Acceptance linkage:** Link the “Replica placement constraints” evidence to its parent and UC-M11.05 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 04. Connectivity model

**Source delivery:** Represent partial links and unreachable peers rather than only host up/down.

**Source invariant:** Partial connectivity has a defined placement and ownership disposition.

**Source negative case:** A host reaches storage but not the controller and is treated as fully healthy.

**Source bounded quantities:** Links and connectivity probes.

### UC-M11.05-C031 · Contract

**Original checklist item:** Specify connectivity model inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M11.05-C031-T01 · Scope statement:** Draft the operation boundary for “Connectivity model” within Partition and failure-domain placement; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M11.05-C031-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Connectivity model”; record each producer, representation and missing-value meaning.
- [ ] **UC-M11.05-C031-T03 · Output inventory:** List the outputs of “Connectivity model” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M11.05-C031-T04 · Field dictionary:** Create a field-and-term dictionary for “Connectivity model”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M11.05-C031-T05 · Prerequisite contract:** Map “Connectivity model” to the source component prerequisites (UC-M05.02, UC-M11.04); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M11.05-C031-T06 · Authority map:** Identify who may produce, change and consume “Connectivity model”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M11.05-C031-T07 · Invariant clause:** Add a normative clause for “Connectivity model” that preserves “Partial connectivity has a defined placement and ownership disposition”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M11.05-C031-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Connectivity model”; include the source counterexample “A host reaches storage but not the controller and is treated as fully healthy” and the intended safe disposition.
- [ ] **UC-M11.05-C031-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Links and connectivity probes” in the “Connectivity model” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M11.05-C031-T10 · Contract review:** Review the “Connectivity model” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M11.05-C032 · Delivery

**Original checklist item:** Represent partial links and unreachable peers rather than only host up/down.

- [ ] **UC-M11.05-C032-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Connectivity model”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M11.05-C032-T02 · Change plan:** Break the source delivery for “Connectivity model” into concrete edit targets and reviewable outputs; keep the UC-M11.05 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M11.05-C032-T03 · Core artifact:** Create the “Connectivity model” model, schema or inventory that realizes this source instruction: Represent partial links and unreachable peers rather than only host up/down.
- [ ] **UC-M11.05-C032-T04 · Concrete realization:** Populate “Connectivity model” with one concrete worked case; map every required entity or field to its source and flag any unmapped entry.
- [ ] **UC-M11.05-C032-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Connectivity model” needed to preserve “Partial connectivity has a defined placement and ownership disposition”; record an enforcement gap where only a model exists.
- [ ] **UC-M11.05-C032-T06 · Dependency connection:** Connect the “Connectivity model” implementation to actual failure-domain inventory, resource-aware placement and ownership fencing; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M11.05-C032-T07 · Resource behavior:** Account for “Links and connectivity probes” in “Connectivity model”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M11.05-C032-T08 · Delivery check:** Run the smallest real “Connectivity model” path and its adverse fixture “A host reaches storage but not the controller and is treated as fully healthy”; retain actual output, state effects and final disposition.
- [ ] **UC-M11.05-C032-T09 · Patch review:** Review the “Connectivity model” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M11.05-C032-T10 · Delivery handoff:** Publish the “Connectivity model” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M11.05-C033 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Partial connectivity has a defined placement and ownership disposition. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M11.05-C033-T01 · Named property:** Create a stable property/check name under this parent for “Connectivity model”; copy its required invariant exactly: “Partial connectivity has a defined placement and ownership disposition”.
- [ ] **UC-M11.05-C033-T02 · Observable terms:** Define each term in the “Connectivity model” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M11.05-C033-T03 · Precondition set:** List the preconditions under which “Partial connectivity has a defined placement and ownership disposition” must hold for “Connectivity model”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M11.05-C033-T04 · Transition coverage:** Map the “Connectivity model” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M11.05-C033-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Connectivity model”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M11.05-C033-T06 · Satisfying fixture:** Create a concrete “Connectivity model” case that satisfies “Partial connectivity has a defined placement and ownership disposition”; record its expected observation before running the assertion or review.
- [ ] **UC-M11.05-C033-T07 · Violating fixture:** Create the source counterexample “A host reaches storage but not the controller and is treated as fully healthy” for “Connectivity model”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M11.05-C033-T08 · Enforcement evidence:** Exercise the “Connectivity model” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M11.05-C033-T09 · Regression linkage:** Link the “Connectivity model” property to changes in actual failure-domain inventory, resource-aware placement and ownership fencing; record which dependency or contract changes require rerunning it.
- [ ] **UC-M11.05-C033-T10 · Property disposition:** Compare the satisfying and violating “Connectivity model” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M11.05-C034 · Integration

**Original checklist item:** Integrate connectivity model with actual failure-domain inventory, resource-aware placement and ownership fencing; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M11.05-C034-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Connectivity model” across actual failure-domain inventory, resource-aware placement and ownership fencing; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M11.05-C034-T02 · Field mapping:** Map every “Connectivity model” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M11.05-C034-T03 · Prerequisite identities:** Record the actual prerequisites for “Connectivity model” (source dependency list: UC-M05.02, UC-M11.04); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M11.05-C034-T04 · Ownership agreement:** Specify who owns “Connectivity model” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M11.05-C034-T05 · Handoff implementation:** Connect “Connectivity model” through the mapped seam using the real adapter or explicit specification reference; preserve “Partial connectivity has a defined placement and ownership disposition” across the handoff.
- [ ] **UC-M11.05-C034-T06 · Absent-input case:** Omit one required “Connectivity model” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M11.05-C034-T07 · Stale-input case:** Supply an outdated “Connectivity model” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M11.05-C034-T08 · Incompatible-input case:** Supply an incompatible “Connectivity model” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M11.05-C034-T09 · Valid integration trace:** Run a valid “Connectivity model” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M11.05-C034-T10 · Seam review:** Reconcile the “Connectivity model” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M11.05-C035 · Valid-case test

**Original checklist item:** Run a valid-path fixture for connectivity model; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M11.05-C035-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Connectivity model” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M11.05-C035-T02 · Expected-result oracle:** Specify the “Connectivity model” expected result independently of the implementation output; include the property “Partial connectivity has a defined placement and ownership disposition” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M11.05-C035-T03 · Fixture material:** Create the concrete “Connectivity model” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M11.05-C035-T04 · Target preparation:** Prepare the “Connectivity model” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M11.05-C035-T05 · Initial-state record:** Record the initial “Connectivity model” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M11.05-C035-T06 · Valid-path execution:** Execute the “Connectivity model” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M11.05-C035-T07 · Outcome comparison:** Compare every declared “Connectivity model” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M11.05-C035-T08 · State and bounds check:** Inspect the “Connectivity model” ownership/state effects and actual use of “Links and connectivity probes”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M11.05-C035-T09 · Repeatability check:** Repeat the same “Connectivity model” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M11.05-C035-T10 · Positive evidence:** Attach the “Connectivity model” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M11.05-C036 · Negative test

**Original checklist item:** Negative case: A host reaches storage but not the controller and is treated as fully healthy. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M11.05-C036-T01 · Adverse-case definition:** Create a test record for the exact “Connectivity model” source counterexample: “A host reaches storage but not the controller and is treated as fully healthy”; state which precondition or invariant it challenges.
- [ ] **UC-M11.05-C036-T02 · Safe fixture boundary:** Define the contained test boundary for “Connectivity model”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M11.05-C036-T03 · Valid control:** Construct a valid “Connectivity model” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M11.05-C036-T04 · Minimal adverse input:** Derive the “Connectivity model” adverse fixture from the control with the smallest documented change needed to reproduce “A host reaches storage but not the controller and is treated as fully healthy”; retain that change as reproducible data.
- [ ] **UC-M11.05-C036-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Connectivity model”; require “Partial connectivity has a defined placement and ownership disposition” and forbid a false-success verdict.
- [ ] **UC-M11.05-C036-T06 · Adverse execution:** Exercise the “Connectivity model” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M11.05-C036-T07 · Effect inspection:** Inspect “Connectivity model” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M11.05-C036-T08 · Refusal versus failure:** Confirm the “Connectivity model” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M11.05-C036-T09 · Reset and retention:** Restore only the disposable “Connectivity model” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M11.05-C036-T10 · Negative regression:** Register the “Connectivity model” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M11.05-C037 · Change / failure test

**Original checklist item:** Exercise connectivity model when one selected host/domain becomes unreachable through a partial partition; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M11.05-C037-T01 · Scenario record:** Write the “Connectivity model” change/failure scenario exactly as supplied: one selected host/domain becomes unreachable through a partial partition; identify the property that must remain true: “Partial connectivity has a defined placement and ownership disposition”.
- [ ] **UC-M11.05-C037-T02 · Baseline capture:** Create a known-valid “Connectivity model” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M11.05-C037-T03 · Injection map:** Locate the “Connectivity model” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M11.05-C037-T04 · Disposition oracle:** Define the legal intermediate and final “Connectivity model” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M11.05-C037-T05 · Controlled trigger:** Introduce the controlled “Connectivity model” scenario in the disposable fixture: one selected host/domain becomes unreachable through a partial partition; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M11.05-C037-T06 · Intermediate inspection:** Inspect the “Connectivity model” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M11.05-C037-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Connectivity model”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M11.05-C037-T08 · Stale-evidence cleanup:** Invalidate superseded “Connectivity model” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M11.05-C037-T09 · Repeat and compare:** Repeat the selected “Connectivity model” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M11.05-C037-T10 · Failure evidence:** Publish the “Connectivity model” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M11.05-C038 · Bounds

**Original checklist item:** Choose, document and test limits for links and connectivity probes; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M11.05-C038-T01 · Quantity inventory:** Create a measurement inventory for “Connectivity model”: “Links and connectivity probes”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M11.05-C038-T02 · Measurement method:** Choose how to observe each “Connectivity model” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M11.05-C038-T03 · Budget decision:** Select justified resource and input limits for “Connectivity model”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M11.05-C038-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Connectivity model” cases for “Links and connectivity probes”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M11.05-C038-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Connectivity model” limit; preserve “Partial connectivity has a defined placement and ownership disposition”.
- [ ] **UC-M11.05-C038-T06 · Normal measurement:** Run or review the normal “Connectivity model” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M11.05-C038-T07 · At-limit measurement:** Exercise the “Connectivity model” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M11.05-C038-T08 · Over-limit measurement:** Exercise the “Connectivity model” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M11.05-C038-T09 · Uncovered-scope report:** List the “Connectivity model” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M11.05-C038-T10 · Limit evidence:** Publish the selected “Connectivity model” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M11.05-C039 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for connectivity model with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M11.05-C039-T01 · Event inventory:** List the “Connectivity model” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M11.05-C039-T02 · Diagnostic schema:** Define nonsecret fields for “Connectivity model” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M11.05-C039-T03 · Failure mapping:** Map each documented “Connectivity model” refusal or error to a diagnostic outcome; include “A host reaches storage but not the controller and is treated as fully healthy” and prohibit conversion into a success message.
- [ ] **UC-M11.05-C039-T04 · Emission path:** Add the “Connectivity model” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M11.05-C039-T05 · Redaction check:** Test “Connectivity model” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M11.05-C039-T06 · Output budget:** Set and exercise bounded “Connectivity model” message size, rate and retention compatible with “Links and connectivity probes”; define truncation behavior that preserves the final reason.
- [ ] **UC-M11.05-C039-T07 · Success/refusal fixtures:** Capture “Connectivity model” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M11.05-C039-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Connectivity model” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M11.05-C039-T09 · Operator review:** Read the “Connectivity model” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M11.05-C039-T10 · Diagnostic evidence:** Publish redacted “Connectivity model” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M11.05-C040 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for connectivity model; label unexecuted checks as untested.

- [ ] **UC-M11.05-C040-T01 · Evidence inventory:** List the “Connectivity model” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M11.05-C040-T02 · Artifact references:** Record the exact “Connectivity model” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M11.05-C040-T03 · Fixture references:** Attach the “Connectivity model” fixture IDs, input identities and oracle definition; preserve the source counterexample “A host reaches storage but not the controller and is treated as fully healthy” as a distinct evidence case.
- [ ] **UC-M11.05-C040-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Connectivity model”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M11.05-C040-T05 · Environment record:** Record the actual “Connectivity model” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M11.05-C040-T06 · Expected versus observed:** Pair every “Connectivity model” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M11.05-C040-T07 · Failure and limit records:** Attach “Connectivity model” change/failure and bounds evidence where required; include uncovered “Links and connectivity probes” and unresolved violations of “Partial connectivity has a defined placement and ownership disposition”.
- [ ] **UC-M11.05-C040-T08 · Evidence hygiene:** Check the “Connectivity model” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M11.05-C040-T09 · Reproduction review:** Have the “Connectivity model” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M11.05-C040-T10 · Acceptance linkage:** Link the “Connectivity model” evidence to its parent and UC-M11.05 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 05. Capacity-aware domain selection

**Source delivery:** Reserve capacity while satisfying required failure-domain diversity.

**Source invariant:** Domain diversity cannot override hard resource or isolation limits.

**Source negative case:** A distant replica is placed on an incapable backend.

**Source bounded quantities:** Candidate hosts and constraint checks.

### UC-M11.05-C041 · Contract

**Original checklist item:** Specify capacity-aware domain selection inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M11.05-C041-T01 · Scope statement:** Draft the operation boundary for “Capacity-aware domain selection” within Partition and failure-domain placement; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M11.05-C041-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Capacity-aware domain selection”; record each producer, representation and missing-value meaning.
- [ ] **UC-M11.05-C041-T03 · Output inventory:** List the outputs of “Capacity-aware domain selection” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M11.05-C041-T04 · Field dictionary:** Create a field-and-term dictionary for “Capacity-aware domain selection”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M11.05-C041-T05 · Prerequisite contract:** Map “Capacity-aware domain selection” to the source component prerequisites (UC-M05.02, UC-M11.04); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M11.05-C041-T06 · Authority map:** Identify who may produce, change and consume “Capacity-aware domain selection”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M11.05-C041-T07 · Invariant clause:** Add a normative clause for “Capacity-aware domain selection” that preserves “Domain diversity cannot override hard resource or isolation limits”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M11.05-C041-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Capacity-aware domain selection”; include the source counterexample “A distant replica is placed on an incapable backend” and the intended safe disposition.
- [ ] **UC-M11.05-C041-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Candidate hosts and constraint checks” in the “Capacity-aware domain selection” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M11.05-C041-T10 · Contract review:** Review the “Capacity-aware domain selection” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M11.05-C042 · Delivery

**Original checklist item:** Reserve capacity while satisfying required failure-domain diversity.

- [ ] **UC-M11.05-C042-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Capacity-aware domain selection”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M11.05-C042-T02 · Change plan:** Break the source delivery for “Capacity-aware domain selection” into concrete edit targets and reviewable outputs; keep the UC-M11.05 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M11.05-C042-T03 · Core artifact:** Implement the smallest selected-profile change for “Capacity-aware domain selection” that realizes this source instruction: Reserve capacity while satisfying required failure-domain diversity.
- [ ] **UC-M11.05-C042-T04 · Concrete realization:** Trace “Capacity-aware domain selection” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M11.05-C042-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Capacity-aware domain selection” needed to preserve “Domain diversity cannot override hard resource or isolation limits”; record an enforcement gap where only a model exists.
- [ ] **UC-M11.05-C042-T06 · Dependency connection:** Connect the “Capacity-aware domain selection” implementation to actual failure-domain inventory, resource-aware placement and ownership fencing; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M11.05-C042-T07 · Resource behavior:** Account for “Candidate hosts and constraint checks” in “Capacity-aware domain selection”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M11.05-C042-T08 · Delivery check:** Run the smallest real “Capacity-aware domain selection” path and its adverse fixture “A distant replica is placed on an incapable backend”; retain actual output, state effects and final disposition.
- [ ] **UC-M11.05-C042-T09 · Patch review:** Review the “Capacity-aware domain selection” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M11.05-C042-T10 · Delivery handoff:** Publish the “Capacity-aware domain selection” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M11.05-C043 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Domain diversity cannot override hard resource or isolation limits. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M11.05-C043-T01 · Named property:** Create a stable property/check name under this parent for “Capacity-aware domain selection”; copy its required invariant exactly: “Domain diversity cannot override hard resource or isolation limits”.
- [ ] **UC-M11.05-C043-T02 · Observable terms:** Define each term in the “Capacity-aware domain selection” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M11.05-C043-T03 · Precondition set:** List the preconditions under which “Domain diversity cannot override hard resource or isolation limits” must hold for “Capacity-aware domain selection”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M11.05-C043-T04 · Transition coverage:** Map the “Capacity-aware domain selection” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M11.05-C043-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Capacity-aware domain selection”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M11.05-C043-T06 · Satisfying fixture:** Create a concrete “Capacity-aware domain selection” case that satisfies “Domain diversity cannot override hard resource or isolation limits”; record its expected observation before running the assertion or review.
- [ ] **UC-M11.05-C043-T07 · Violating fixture:** Create the source counterexample “A distant replica is placed on an incapable backend” for “Capacity-aware domain selection”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M11.05-C043-T08 · Enforcement evidence:** Exercise the “Capacity-aware domain selection” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M11.05-C043-T09 · Regression linkage:** Link the “Capacity-aware domain selection” property to changes in actual failure-domain inventory, resource-aware placement and ownership fencing; record which dependency or contract changes require rerunning it.
- [ ] **UC-M11.05-C043-T10 · Property disposition:** Compare the satisfying and violating “Capacity-aware domain selection” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M11.05-C044 · Integration

**Original checklist item:** Integrate capacity-aware domain selection with actual failure-domain inventory, resource-aware placement and ownership fencing; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M11.05-C044-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Capacity-aware domain selection” across actual failure-domain inventory, resource-aware placement and ownership fencing; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M11.05-C044-T02 · Field mapping:** Map every “Capacity-aware domain selection” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M11.05-C044-T03 · Prerequisite identities:** Record the actual prerequisites for “Capacity-aware domain selection” (source dependency list: UC-M05.02, UC-M11.04); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M11.05-C044-T04 · Ownership agreement:** Specify who owns “Capacity-aware domain selection” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M11.05-C044-T05 · Handoff implementation:** Connect “Capacity-aware domain selection” through the mapped seam using the real adapter or explicit specification reference; preserve “Domain diversity cannot override hard resource or isolation limits” across the handoff.
- [ ] **UC-M11.05-C044-T06 · Absent-input case:** Omit one required “Capacity-aware domain selection” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M11.05-C044-T07 · Stale-input case:** Supply an outdated “Capacity-aware domain selection” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M11.05-C044-T08 · Incompatible-input case:** Supply an incompatible “Capacity-aware domain selection” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M11.05-C044-T09 · Valid integration trace:** Run a valid “Capacity-aware domain selection” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M11.05-C044-T10 · Seam review:** Reconcile the “Capacity-aware domain selection” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M11.05-C045 · Valid-case test

**Original checklist item:** Run a valid-path fixture for capacity-aware domain selection; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M11.05-C045-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Capacity-aware domain selection” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M11.05-C045-T02 · Expected-result oracle:** Specify the “Capacity-aware domain selection” expected result independently of the implementation output; include the property “Domain diversity cannot override hard resource or isolation limits” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M11.05-C045-T03 · Fixture material:** Create the concrete “Capacity-aware domain selection” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M11.05-C045-T04 · Target preparation:** Prepare the “Capacity-aware domain selection” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M11.05-C045-T05 · Initial-state record:** Record the initial “Capacity-aware domain selection” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M11.05-C045-T06 · Valid-path execution:** Execute the “Capacity-aware domain selection” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M11.05-C045-T07 · Outcome comparison:** Compare every declared “Capacity-aware domain selection” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M11.05-C045-T08 · State and bounds check:** Inspect the “Capacity-aware domain selection” ownership/state effects and actual use of “Candidate hosts and constraint checks”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M11.05-C045-T09 · Repeatability check:** Repeat the same “Capacity-aware domain selection” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M11.05-C045-T10 · Positive evidence:** Attach the “Capacity-aware domain selection” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M11.05-C046 · Negative test

**Original checklist item:** Negative case: A distant replica is placed on an incapable backend. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M11.05-C046-T01 · Adverse-case definition:** Create a test record for the exact “Capacity-aware domain selection” source counterexample: “A distant replica is placed on an incapable backend”; state which precondition or invariant it challenges.
- [ ] **UC-M11.05-C046-T02 · Safe fixture boundary:** Define the contained test boundary for “Capacity-aware domain selection”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M11.05-C046-T03 · Valid control:** Construct a valid “Capacity-aware domain selection” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M11.05-C046-T04 · Minimal adverse input:** Derive the “Capacity-aware domain selection” adverse fixture from the control with the smallest documented change needed to reproduce “A distant replica is placed on an incapable backend”; retain that change as reproducible data.
- [ ] **UC-M11.05-C046-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Capacity-aware domain selection”; require “Domain diversity cannot override hard resource or isolation limits” and forbid a false-success verdict.
- [ ] **UC-M11.05-C046-T06 · Adverse execution:** Exercise the “Capacity-aware domain selection” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M11.05-C046-T07 · Effect inspection:** Inspect “Capacity-aware domain selection” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M11.05-C046-T08 · Refusal versus failure:** Confirm the “Capacity-aware domain selection” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M11.05-C046-T09 · Reset and retention:** Restore only the disposable “Capacity-aware domain selection” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M11.05-C046-T10 · Negative regression:** Register the “Capacity-aware domain selection” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M11.05-C047 · Change / failure test

**Original checklist item:** Exercise capacity-aware domain selection when one selected host/domain becomes unreachable through a partial partition; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M11.05-C047-T01 · Scenario record:** Write the “Capacity-aware domain selection” change/failure scenario exactly as supplied: one selected host/domain becomes unreachable through a partial partition; identify the property that must remain true: “Domain diversity cannot override hard resource or isolation limits”.
- [ ] **UC-M11.05-C047-T02 · Baseline capture:** Create a known-valid “Capacity-aware domain selection” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M11.05-C047-T03 · Injection map:** Locate the “Capacity-aware domain selection” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M11.05-C047-T04 · Disposition oracle:** Define the legal intermediate and final “Capacity-aware domain selection” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M11.05-C047-T05 · Controlled trigger:** Introduce the controlled “Capacity-aware domain selection” scenario in the disposable fixture: one selected host/domain becomes unreachable through a partial partition; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M11.05-C047-T06 · Intermediate inspection:** Inspect the “Capacity-aware domain selection” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M11.05-C047-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Capacity-aware domain selection”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M11.05-C047-T08 · Stale-evidence cleanup:** Invalidate superseded “Capacity-aware domain selection” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M11.05-C047-T09 · Repeat and compare:** Repeat the selected “Capacity-aware domain selection” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M11.05-C047-T10 · Failure evidence:** Publish the “Capacity-aware domain selection” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M11.05-C048 · Bounds

**Original checklist item:** Choose, document and test limits for candidate hosts and constraint checks; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M11.05-C048-T01 · Quantity inventory:** Create a measurement inventory for “Capacity-aware domain selection”: “Candidate hosts and constraint checks”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M11.05-C048-T02 · Measurement method:** Choose how to observe each “Capacity-aware domain selection” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M11.05-C048-T03 · Budget decision:** Select justified resource and input limits for “Capacity-aware domain selection”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M11.05-C048-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Capacity-aware domain selection” cases for “Candidate hosts and constraint checks”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M11.05-C048-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Capacity-aware domain selection” limit; preserve “Domain diversity cannot override hard resource or isolation limits”.
- [ ] **UC-M11.05-C048-T06 · Normal measurement:** Run or review the normal “Capacity-aware domain selection” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M11.05-C048-T07 · At-limit measurement:** Exercise the “Capacity-aware domain selection” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M11.05-C048-T08 · Over-limit measurement:** Exercise the “Capacity-aware domain selection” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M11.05-C048-T09 · Uncovered-scope report:** List the “Capacity-aware domain selection” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M11.05-C048-T10 · Limit evidence:** Publish the selected “Capacity-aware domain selection” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M11.05-C049 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for capacity-aware domain selection with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M11.05-C049-T01 · Event inventory:** List the “Capacity-aware domain selection” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M11.05-C049-T02 · Diagnostic schema:** Define nonsecret fields for “Capacity-aware domain selection” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M11.05-C049-T03 · Failure mapping:** Map each documented “Capacity-aware domain selection” refusal or error to a diagnostic outcome; include “A distant replica is placed on an incapable backend” and prohibit conversion into a success message.
- [ ] **UC-M11.05-C049-T04 · Emission path:** Add the “Capacity-aware domain selection” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M11.05-C049-T05 · Redaction check:** Test “Capacity-aware domain selection” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M11.05-C049-T06 · Output budget:** Set and exercise bounded “Capacity-aware domain selection” message size, rate and retention compatible with “Candidate hosts and constraint checks”; define truncation behavior that preserves the final reason.
- [ ] **UC-M11.05-C049-T07 · Success/refusal fixtures:** Capture “Capacity-aware domain selection” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M11.05-C049-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Capacity-aware domain selection” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M11.05-C049-T09 · Operator review:** Read the “Capacity-aware domain selection” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M11.05-C049-T10 · Diagnostic evidence:** Publish redacted “Capacity-aware domain selection” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M11.05-C050 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for capacity-aware domain selection; label unexecuted checks as untested.

- [ ] **UC-M11.05-C050-T01 · Evidence inventory:** List the “Capacity-aware domain selection” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M11.05-C050-T02 · Artifact references:** Record the exact “Capacity-aware domain selection” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M11.05-C050-T03 · Fixture references:** Attach the “Capacity-aware domain selection” fixture IDs, input identities and oracle definition; preserve the source counterexample “A distant replica is placed on an incapable backend” as a distinct evidence case.
- [ ] **UC-M11.05-C050-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Capacity-aware domain selection”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M11.05-C050-T05 · Environment record:** Record the actual “Capacity-aware domain selection” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M11.05-C050-T06 · Expected versus observed:** Pair every “Capacity-aware domain selection” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M11.05-C050-T07 · Failure and limit records:** Attach “Capacity-aware domain selection” change/failure and bounds evidence where required; include uncovered “Candidate hosts and constraint checks” and unresolved violations of “Domain diversity cannot override hard resource or isolation limits”.
- [ ] **UC-M11.05-C050-T08 · Evidence hygiene:** Check the “Capacity-aware domain selection” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M11.05-C050-T09 · Reproduction review:** Have the “Capacity-aware domain selection” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M11.05-C050-T10 · Acceptance linkage:** Link the “Capacity-aware domain selection” evidence to its parent and UC-M11.05 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 06. Failure detection policy

**Source delivery:** Define observed failure signals and uncertainty without immediate unsafe reassignment.

**Source invariant:** Suspected failure does not alone authorize conflicting state writers.

**Source negative case:** A delayed heartbeat causes a second unfenced writer to start.

**Source bounded quantities:** Detection intervals and uncertain workers.

### UC-M11.05-C051 · Contract

**Original checklist item:** Specify failure detection policy inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M11.05-C051-T01 · Scope statement:** Draft the operation boundary for “Failure detection policy” within Partition and failure-domain placement; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M11.05-C051-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Failure detection policy”; record each producer, representation and missing-value meaning.
- [ ] **UC-M11.05-C051-T03 · Output inventory:** List the outputs of “Failure detection policy” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M11.05-C051-T04 · Field dictionary:** Create a field-and-term dictionary for “Failure detection policy”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M11.05-C051-T05 · Prerequisite contract:** Map “Failure detection policy” to the source component prerequisites (UC-M05.02, UC-M11.04); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M11.05-C051-T06 · Authority map:** Identify who may produce, change and consume “Failure detection policy”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M11.05-C051-T07 · Invariant clause:** Add a normative clause for “Failure detection policy” that preserves “Suspected failure does not alone authorize conflicting state writers”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M11.05-C051-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Failure detection policy”; include the source counterexample “A delayed heartbeat causes a second unfenced writer to start” and the intended safe disposition.
- [ ] **UC-M11.05-C051-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Detection intervals and uncertain workers” in the “Failure detection policy” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M11.05-C051-T10 · Contract review:** Review the “Failure detection policy” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M11.05-C052 · Delivery

**Original checklist item:** Define observed failure signals and uncertainty without immediate unsafe reassignment.

- [ ] **UC-M11.05-C052-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Failure detection policy”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M11.05-C052-T02 · Change plan:** Break the source delivery for “Failure detection policy” into concrete edit targets and reviewable outputs; keep the UC-M11.05 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M11.05-C052-T03 · Core artifact:** Create the “Failure detection policy” model, schema or inventory that realizes this source instruction: Define observed failure signals and uncertainty without immediate unsafe reassignment.
- [ ] **UC-M11.05-C052-T04 · Concrete realization:** Populate “Failure detection policy” with one concrete worked case; map every required entity or field to its source and flag any unmapped entry.
- [ ] **UC-M11.05-C052-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Failure detection policy” needed to preserve “Suspected failure does not alone authorize conflicting state writers”; record an enforcement gap where only a model exists.
- [ ] **UC-M11.05-C052-T06 · Dependency connection:** Connect the “Failure detection policy” implementation to actual failure-domain inventory, resource-aware placement and ownership fencing; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M11.05-C052-T07 · Resource behavior:** Account for “Detection intervals and uncertain workers” in “Failure detection policy”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M11.05-C052-T08 · Delivery check:** Run the smallest real “Failure detection policy” path and its adverse fixture “A delayed heartbeat causes a second unfenced writer to start”; retain actual output, state effects and final disposition.
- [ ] **UC-M11.05-C052-T09 · Patch review:** Review the “Failure detection policy” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M11.05-C052-T10 · Delivery handoff:** Publish the “Failure detection policy” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M11.05-C053 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Suspected failure does not alone authorize conflicting state writers. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M11.05-C053-T01 · Named property:** Create a stable property/check name under this parent for “Failure detection policy”; copy its required invariant exactly: “Suspected failure does not alone authorize conflicting state writers”.
- [ ] **UC-M11.05-C053-T02 · Observable terms:** Define each term in the “Failure detection policy” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M11.05-C053-T03 · Precondition set:** List the preconditions under which “Suspected failure does not alone authorize conflicting state writers” must hold for “Failure detection policy”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M11.05-C053-T04 · Transition coverage:** Map the “Failure detection policy” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M11.05-C053-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Failure detection policy”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M11.05-C053-T06 · Satisfying fixture:** Create a concrete “Failure detection policy” case that satisfies “Suspected failure does not alone authorize conflicting state writers”; record its expected observation before running the assertion or review.
- [ ] **UC-M11.05-C053-T07 · Violating fixture:** Create the source counterexample “A delayed heartbeat causes a second unfenced writer to start” for “Failure detection policy”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M11.05-C053-T08 · Enforcement evidence:** Exercise the “Failure detection policy” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M11.05-C053-T09 · Regression linkage:** Link the “Failure detection policy” property to changes in actual failure-domain inventory, resource-aware placement and ownership fencing; record which dependency or contract changes require rerunning it.
- [ ] **UC-M11.05-C053-T10 · Property disposition:** Compare the satisfying and violating “Failure detection policy” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M11.05-C054 · Integration

**Original checklist item:** Integrate failure detection policy with actual failure-domain inventory, resource-aware placement and ownership fencing; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M11.05-C054-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Failure detection policy” across actual failure-domain inventory, resource-aware placement and ownership fencing; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M11.05-C054-T02 · Field mapping:** Map every “Failure detection policy” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M11.05-C054-T03 · Prerequisite identities:** Record the actual prerequisites for “Failure detection policy” (source dependency list: UC-M05.02, UC-M11.04); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M11.05-C054-T04 · Ownership agreement:** Specify who owns “Failure detection policy” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M11.05-C054-T05 · Handoff implementation:** Connect “Failure detection policy” through the mapped seam using the real adapter or explicit specification reference; preserve “Suspected failure does not alone authorize conflicting state writers” across the handoff.
- [ ] **UC-M11.05-C054-T06 · Absent-input case:** Omit one required “Failure detection policy” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M11.05-C054-T07 · Stale-input case:** Supply an outdated “Failure detection policy” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M11.05-C054-T08 · Incompatible-input case:** Supply an incompatible “Failure detection policy” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M11.05-C054-T09 · Valid integration trace:** Run a valid “Failure detection policy” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M11.05-C054-T10 · Seam review:** Reconcile the “Failure detection policy” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M11.05-C055 · Valid-case test

**Original checklist item:** Run a valid-path fixture for failure detection policy; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M11.05-C055-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Failure detection policy” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M11.05-C055-T02 · Expected-result oracle:** Specify the “Failure detection policy” expected result independently of the implementation output; include the property “Suspected failure does not alone authorize conflicting state writers” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M11.05-C055-T03 · Fixture material:** Create the concrete “Failure detection policy” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M11.05-C055-T04 · Target preparation:** Prepare the “Failure detection policy” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M11.05-C055-T05 · Initial-state record:** Record the initial “Failure detection policy” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M11.05-C055-T06 · Valid-path execution:** Execute the “Failure detection policy” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M11.05-C055-T07 · Outcome comparison:** Compare every declared “Failure detection policy” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M11.05-C055-T08 · State and bounds check:** Inspect the “Failure detection policy” ownership/state effects and actual use of “Detection intervals and uncertain workers”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M11.05-C055-T09 · Repeatability check:** Repeat the same “Failure detection policy” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M11.05-C055-T10 · Positive evidence:** Attach the “Failure detection policy” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M11.05-C056 · Negative test

**Original checklist item:** Negative case: A delayed heartbeat causes a second unfenced writer to start. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M11.05-C056-T01 · Adverse-case definition:** Create a test record for the exact “Failure detection policy” source counterexample: “A delayed heartbeat causes a second unfenced writer to start”; state which precondition or invariant it challenges.
- [ ] **UC-M11.05-C056-T02 · Safe fixture boundary:** Define the contained test boundary for “Failure detection policy”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M11.05-C056-T03 · Valid control:** Construct a valid “Failure detection policy” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M11.05-C056-T04 · Minimal adverse input:** Derive the “Failure detection policy” adverse fixture from the control with the smallest documented change needed to reproduce “A delayed heartbeat causes a second unfenced writer to start”; retain that change as reproducible data.
- [ ] **UC-M11.05-C056-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Failure detection policy”; require “Suspected failure does not alone authorize conflicting state writers” and forbid a false-success verdict.
- [ ] **UC-M11.05-C056-T06 · Adverse execution:** Exercise the “Failure detection policy” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M11.05-C056-T07 · Effect inspection:** Inspect “Failure detection policy” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M11.05-C056-T08 · Refusal versus failure:** Confirm the “Failure detection policy” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M11.05-C056-T09 · Reset and retention:** Restore only the disposable “Failure detection policy” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M11.05-C056-T10 · Negative regression:** Register the “Failure detection policy” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M11.05-C057 · Change / failure test

**Original checklist item:** Exercise failure detection policy when one selected host/domain becomes unreachable through a partial partition; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M11.05-C057-T01 · Scenario record:** Write the “Failure detection policy” change/failure scenario exactly as supplied: one selected host/domain becomes unreachable through a partial partition; identify the property that must remain true: “Suspected failure does not alone authorize conflicting state writers”.
- [ ] **UC-M11.05-C057-T02 · Baseline capture:** Create a known-valid “Failure detection policy” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M11.05-C057-T03 · Injection map:** Locate the “Failure detection policy” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M11.05-C057-T04 · Disposition oracle:** Define the legal intermediate and final “Failure detection policy” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M11.05-C057-T05 · Controlled trigger:** Introduce the controlled “Failure detection policy” scenario in the disposable fixture: one selected host/domain becomes unreachable through a partial partition; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M11.05-C057-T06 · Intermediate inspection:** Inspect the “Failure detection policy” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M11.05-C057-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Failure detection policy”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M11.05-C057-T08 · Stale-evidence cleanup:** Invalidate superseded “Failure detection policy” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M11.05-C057-T09 · Repeat and compare:** Repeat the selected “Failure detection policy” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M11.05-C057-T10 · Failure evidence:** Publish the “Failure detection policy” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M11.05-C058 · Bounds

**Original checklist item:** Choose, document and test limits for detection intervals and uncertain workers; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M11.05-C058-T01 · Quantity inventory:** Create a measurement inventory for “Failure detection policy”: “Detection intervals and uncertain workers”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M11.05-C058-T02 · Measurement method:** Choose how to observe each “Failure detection policy” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M11.05-C058-T03 · Budget decision:** Select justified resource and input limits for “Failure detection policy”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M11.05-C058-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Failure detection policy” cases for “Detection intervals and uncertain workers”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M11.05-C058-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Failure detection policy” limit; preserve “Suspected failure does not alone authorize conflicting state writers”.
- [ ] **UC-M11.05-C058-T06 · Normal measurement:** Run or review the normal “Failure detection policy” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M11.05-C058-T07 · At-limit measurement:** Exercise the “Failure detection policy” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M11.05-C058-T08 · Over-limit measurement:** Exercise the “Failure detection policy” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M11.05-C058-T09 · Uncovered-scope report:** List the “Failure detection policy” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M11.05-C058-T10 · Limit evidence:** Publish the selected “Failure detection policy” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M11.05-C059 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for failure detection policy with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M11.05-C059-T01 · Event inventory:** List the “Failure detection policy” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M11.05-C059-T02 · Diagnostic schema:** Define nonsecret fields for “Failure detection policy” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M11.05-C059-T03 · Failure mapping:** Map each documented “Failure detection policy” refusal or error to a diagnostic outcome; include “A delayed heartbeat causes a second unfenced writer to start” and prohibit conversion into a success message.
- [ ] **UC-M11.05-C059-T04 · Emission path:** Add the “Failure detection policy” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M11.05-C059-T05 · Redaction check:** Test “Failure detection policy” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M11.05-C059-T06 · Output budget:** Set and exercise bounded “Failure detection policy” message size, rate and retention compatible with “Detection intervals and uncertain workers”; define truncation behavior that preserves the final reason.
- [ ] **UC-M11.05-C059-T07 · Success/refusal fixtures:** Capture “Failure detection policy” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M11.05-C059-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Failure detection policy” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M11.05-C059-T09 · Operator review:** Read the “Failure detection policy” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M11.05-C059-T10 · Diagnostic evidence:** Publish redacted “Failure detection policy” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M11.05-C060 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for failure detection policy; label unexecuted checks as untested.

- [ ] **UC-M11.05-C060-T01 · Evidence inventory:** List the “Failure detection policy” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M11.05-C060-T02 · Artifact references:** Record the exact “Failure detection policy” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M11.05-C060-T03 · Fixture references:** Attach the “Failure detection policy” fixture IDs, input identities and oracle definition; preserve the source counterexample “A delayed heartbeat causes a second unfenced writer to start” as a distinct evidence case.
- [ ] **UC-M11.05-C060-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Failure detection policy”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M11.05-C060-T05 · Environment record:** Record the actual “Failure detection policy” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M11.05-C060-T06 · Expected versus observed:** Pair every “Failure detection policy” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M11.05-C060-T07 · Failure and limit records:** Attach “Failure detection policy” change/failure and bounds evidence where required; include uncovered “Detection intervals and uncertain workers” and unresolved violations of “Suspected failure does not alone authorize conflicting state writers”.
- [ ] **UC-M11.05-C060-T08 · Evidence hygiene:** Check the “Failure detection policy” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M11.05-C060-T09 · Reproduction review:** Have the “Failure detection policy” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M11.05-C060-T10 · Acceptance linkage:** Link the “Failure detection policy” evidence to its parent and UC-M11.05 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 07. Safe re-placement

**Source delivery:** Use ownership fencing before relocating work after a domain failure.

**Source invariant:** Recovery placement cannot double-commit state with a surviving old owner.

**Source negative case:** A partition is mistaken for permanent host loss.

**Source bounded quantities:** Relocated workloads and fencing delay.

### UC-M11.05-C061 · Contract

**Original checklist item:** Specify safe re-placement inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M11.05-C061-T01 · Scope statement:** Draft the operation boundary for “Safe re-placement” within Partition and failure-domain placement; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M11.05-C061-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Safe re-placement”; record each producer, representation and missing-value meaning.
- [ ] **UC-M11.05-C061-T03 · Output inventory:** List the outputs of “Safe re-placement” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M11.05-C061-T04 · Field dictionary:** Create a field-and-term dictionary for “Safe re-placement”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M11.05-C061-T05 · Prerequisite contract:** Map “Safe re-placement” to the source component prerequisites (UC-M05.02, UC-M11.04); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M11.05-C061-T06 · Authority map:** Identify who may produce, change and consume “Safe re-placement”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M11.05-C061-T07 · Invariant clause:** Add a normative clause for “Safe re-placement” that preserves “Recovery placement cannot double-commit state with a surviving old owner”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M11.05-C061-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Safe re-placement”; include the source counterexample “A partition is mistaken for permanent host loss” and the intended safe disposition.
- [ ] **UC-M11.05-C061-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Relocated workloads and fencing delay” in the “Safe re-placement” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M11.05-C061-T10 · Contract review:** Review the “Safe re-placement” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M11.05-C062 · Delivery

**Original checklist item:** Use ownership fencing before relocating work after a domain failure.

- [ ] **UC-M11.05-C062-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Safe re-placement”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M11.05-C062-T02 · Change plan:** Break the source delivery for “Safe re-placement” into concrete edit targets and reviewable outputs; keep the UC-M11.05 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M11.05-C062-T03 · Core artifact:** Implement the smallest selected-profile change for “Safe re-placement” that realizes this source instruction: Use ownership fencing before relocating work after a domain failure.
- [ ] **UC-M11.05-C062-T04 · Concrete realization:** Trace “Safe re-placement” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M11.05-C062-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Safe re-placement” needed to preserve “Recovery placement cannot double-commit state with a surviving old owner”; record an enforcement gap where only a model exists.
- [ ] **UC-M11.05-C062-T06 · Dependency connection:** Connect the “Safe re-placement” implementation to actual failure-domain inventory, resource-aware placement and ownership fencing; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M11.05-C062-T07 · Resource behavior:** Account for “Relocated workloads and fencing delay” in “Safe re-placement”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M11.05-C062-T08 · Delivery check:** Run the smallest real “Safe re-placement” path and its adverse fixture “A partition is mistaken for permanent host loss”; retain actual output, state effects and final disposition.
- [ ] **UC-M11.05-C062-T09 · Patch review:** Review the “Safe re-placement” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M11.05-C062-T10 · Delivery handoff:** Publish the “Safe re-placement” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M11.05-C063 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Recovery placement cannot double-commit state with a surviving old owner. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M11.05-C063-T01 · Named property:** Create a stable property/check name under this parent for “Safe re-placement”; copy its required invariant exactly: “Recovery placement cannot double-commit state with a surviving old owner”.
- [ ] **UC-M11.05-C063-T02 · Observable terms:** Define each term in the “Safe re-placement” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M11.05-C063-T03 · Precondition set:** List the preconditions under which “Recovery placement cannot double-commit state with a surviving old owner” must hold for “Safe re-placement”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M11.05-C063-T04 · Transition coverage:** Map the “Safe re-placement” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M11.05-C063-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Safe re-placement”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M11.05-C063-T06 · Satisfying fixture:** Create a concrete “Safe re-placement” case that satisfies “Recovery placement cannot double-commit state with a surviving old owner”; record its expected observation before running the assertion or review.
- [ ] **UC-M11.05-C063-T07 · Violating fixture:** Create the source counterexample “A partition is mistaken for permanent host loss” for “Safe re-placement”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M11.05-C063-T08 · Enforcement evidence:** Exercise the “Safe re-placement” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M11.05-C063-T09 · Regression linkage:** Link the “Safe re-placement” property to changes in actual failure-domain inventory, resource-aware placement and ownership fencing; record which dependency or contract changes require rerunning it.
- [ ] **UC-M11.05-C063-T10 · Property disposition:** Compare the satisfying and violating “Safe re-placement” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M11.05-C064 · Integration

**Original checklist item:** Integrate safe re-placement with actual failure-domain inventory, resource-aware placement and ownership fencing; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M11.05-C064-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Safe re-placement” across actual failure-domain inventory, resource-aware placement and ownership fencing; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M11.05-C064-T02 · Field mapping:** Map every “Safe re-placement” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M11.05-C064-T03 · Prerequisite identities:** Record the actual prerequisites for “Safe re-placement” (source dependency list: UC-M05.02, UC-M11.04); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M11.05-C064-T04 · Ownership agreement:** Specify who owns “Safe re-placement” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M11.05-C064-T05 · Handoff implementation:** Connect “Safe re-placement” through the mapped seam using the real adapter or explicit specification reference; preserve “Recovery placement cannot double-commit state with a surviving old owner” across the handoff.
- [ ] **UC-M11.05-C064-T06 · Absent-input case:** Omit one required “Safe re-placement” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M11.05-C064-T07 · Stale-input case:** Supply an outdated “Safe re-placement” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M11.05-C064-T08 · Incompatible-input case:** Supply an incompatible “Safe re-placement” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M11.05-C064-T09 · Valid integration trace:** Run a valid “Safe re-placement” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M11.05-C064-T10 · Seam review:** Reconcile the “Safe re-placement” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M11.05-C065 · Valid-case test

**Original checklist item:** Run a valid-path fixture for safe re-placement; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M11.05-C065-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Safe re-placement” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M11.05-C065-T02 · Expected-result oracle:** Specify the “Safe re-placement” expected result independently of the implementation output; include the property “Recovery placement cannot double-commit state with a surviving old owner” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M11.05-C065-T03 · Fixture material:** Create the concrete “Safe re-placement” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M11.05-C065-T04 · Target preparation:** Prepare the “Safe re-placement” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M11.05-C065-T05 · Initial-state record:** Record the initial “Safe re-placement” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M11.05-C065-T06 · Valid-path execution:** Execute the “Safe re-placement” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M11.05-C065-T07 · Outcome comparison:** Compare every declared “Safe re-placement” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M11.05-C065-T08 · State and bounds check:** Inspect the “Safe re-placement” ownership/state effects and actual use of “Relocated workloads and fencing delay”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M11.05-C065-T09 · Repeatability check:** Repeat the same “Safe re-placement” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M11.05-C065-T10 · Positive evidence:** Attach the “Safe re-placement” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M11.05-C066 · Negative test

**Original checklist item:** Negative case: A partition is mistaken for permanent host loss. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M11.05-C066-T01 · Adverse-case definition:** Create a test record for the exact “Safe re-placement” source counterexample: “A partition is mistaken for permanent host loss”; state which precondition or invariant it challenges.
- [ ] **UC-M11.05-C066-T02 · Safe fixture boundary:** Define the contained test boundary for “Safe re-placement”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M11.05-C066-T03 · Valid control:** Construct a valid “Safe re-placement” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M11.05-C066-T04 · Minimal adverse input:** Derive the “Safe re-placement” adverse fixture from the control with the smallest documented change needed to reproduce “A partition is mistaken for permanent host loss”; retain that change as reproducible data.
- [ ] **UC-M11.05-C066-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Safe re-placement”; require “Recovery placement cannot double-commit state with a surviving old owner” and forbid a false-success verdict.
- [ ] **UC-M11.05-C066-T06 · Adverse execution:** Exercise the “Safe re-placement” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M11.05-C066-T07 · Effect inspection:** Inspect “Safe re-placement” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M11.05-C066-T08 · Refusal versus failure:** Confirm the “Safe re-placement” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M11.05-C066-T09 · Reset and retention:** Restore only the disposable “Safe re-placement” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M11.05-C066-T10 · Negative regression:** Register the “Safe re-placement” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M11.05-C067 · Change / failure test

**Original checklist item:** Exercise safe re-placement when one selected host/domain becomes unreachable through a partial partition; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M11.05-C067-T01 · Scenario record:** Write the “Safe re-placement” change/failure scenario exactly as supplied: one selected host/domain becomes unreachable through a partial partition; identify the property that must remain true: “Recovery placement cannot double-commit state with a surviving old owner”.
- [ ] **UC-M11.05-C067-T02 · Baseline capture:** Create a known-valid “Safe re-placement” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M11.05-C067-T03 · Injection map:** Locate the “Safe re-placement” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M11.05-C067-T04 · Disposition oracle:** Define the legal intermediate and final “Safe re-placement” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M11.05-C067-T05 · Controlled trigger:** Introduce the controlled “Safe re-placement” scenario in the disposable fixture: one selected host/domain becomes unreachable through a partial partition; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M11.05-C067-T06 · Intermediate inspection:** Inspect the “Safe re-placement” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M11.05-C067-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Safe re-placement”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M11.05-C067-T08 · Stale-evidence cleanup:** Invalidate superseded “Safe re-placement” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M11.05-C067-T09 · Repeat and compare:** Repeat the selected “Safe re-placement” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M11.05-C067-T10 · Failure evidence:** Publish the “Safe re-placement” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M11.05-C068 · Bounds

**Original checklist item:** Choose, document and test limits for relocated workloads and fencing delay; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M11.05-C068-T01 · Quantity inventory:** Create a measurement inventory for “Safe re-placement”: “Relocated workloads and fencing delay”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M11.05-C068-T02 · Measurement method:** Choose how to observe each “Safe re-placement” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M11.05-C068-T03 · Budget decision:** Select justified resource and input limits for “Safe re-placement”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M11.05-C068-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Safe re-placement” cases for “Relocated workloads and fencing delay”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M11.05-C068-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Safe re-placement” limit; preserve “Recovery placement cannot double-commit state with a surviving old owner”.
- [ ] **UC-M11.05-C068-T06 · Normal measurement:** Run or review the normal “Safe re-placement” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M11.05-C068-T07 · At-limit measurement:** Exercise the “Safe re-placement” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M11.05-C068-T08 · Over-limit measurement:** Exercise the “Safe re-placement” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M11.05-C068-T09 · Uncovered-scope report:** List the “Safe re-placement” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M11.05-C068-T10 · Limit evidence:** Publish the selected “Safe re-placement” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M11.05-C069 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for safe re-placement with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M11.05-C069-T01 · Event inventory:** List the “Safe re-placement” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M11.05-C069-T02 · Diagnostic schema:** Define nonsecret fields for “Safe re-placement” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M11.05-C069-T03 · Failure mapping:** Map each documented “Safe re-placement” refusal or error to a diagnostic outcome; include “A partition is mistaken for permanent host loss” and prohibit conversion into a success message.
- [ ] **UC-M11.05-C069-T04 · Emission path:** Add the “Safe re-placement” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M11.05-C069-T05 · Redaction check:** Test “Safe re-placement” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M11.05-C069-T06 · Output budget:** Set and exercise bounded “Safe re-placement” message size, rate and retention compatible with “Relocated workloads and fencing delay”; define truncation behavior that preserves the final reason.
- [ ] **UC-M11.05-C069-T07 · Success/refusal fixtures:** Capture “Safe re-placement” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M11.05-C069-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Safe re-placement” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M11.05-C069-T09 · Operator review:** Read the “Safe re-placement” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M11.05-C069-T10 · Diagnostic evidence:** Publish redacted “Safe re-placement” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M11.05-C070 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for safe re-placement; label unexecuted checks as untested.

- [ ] **UC-M11.05-C070-T01 · Evidence inventory:** List the “Safe re-placement” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M11.05-C070-T02 · Artifact references:** Record the exact “Safe re-placement” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M11.05-C070-T03 · Fixture references:** Attach the “Safe re-placement” fixture IDs, input identities and oracle definition; preserve the source counterexample “A partition is mistaken for permanent host loss” as a distinct evidence case.
- [ ] **UC-M11.05-C070-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Safe re-placement”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M11.05-C070-T05 · Environment record:** Record the actual “Safe re-placement” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M11.05-C070-T06 · Expected versus observed:** Pair every “Safe re-placement” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M11.05-C070-T07 · Failure and limit records:** Attach “Safe re-placement” change/failure and bounds evidence where required; include uncovered “Relocated workloads and fencing delay” and unresolved violations of “Recovery placement cannot double-commit state with a surviving old owner”.
- [ ] **UC-M11.05-C070-T08 · Evidence hygiene:** Check the “Safe re-placement” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M11.05-C070-T09 · Reproduction review:** Have the “Safe re-placement” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M11.05-C070-T10 · Acceptance linkage:** Link the “Safe re-placement” evidence to its parent and UC-M11.05 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 08. Replica availability accounting

**Source delivery:** Report which promised replicas remain usable under the tested domain loss.

**Source invariant:** Replica counts distinguish present, ready and independently reachable instances.

**Source negative case:** Unreachable stale replicas are counted as healthy redundancy.

**Source bounded quantities:** Replica states and observation age.

### UC-M11.05-C071 · Contract

**Original checklist item:** Specify replica availability accounting inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M11.05-C071-T01 · Scope statement:** Draft the operation boundary for “Replica availability accounting” within Partition and failure-domain placement; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M11.05-C071-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Replica availability accounting”; record each producer, representation and missing-value meaning.
- [ ] **UC-M11.05-C071-T03 · Output inventory:** List the outputs of “Replica availability accounting” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M11.05-C071-T04 · Field dictionary:** Create a field-and-term dictionary for “Replica availability accounting”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M11.05-C071-T05 · Prerequisite contract:** Map “Replica availability accounting” to the source component prerequisites (UC-M05.02, UC-M11.04); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M11.05-C071-T06 · Authority map:** Identify who may produce, change and consume “Replica availability accounting”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M11.05-C071-T07 · Invariant clause:** Add a normative clause for “Replica availability accounting” that preserves “Replica counts distinguish present, ready and independently reachable instances”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M11.05-C071-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Replica availability accounting”; include the source counterexample “Unreachable stale replicas are counted as healthy redundancy” and the intended safe disposition.
- [ ] **UC-M11.05-C071-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Replica states and observation age” in the “Replica availability accounting” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M11.05-C071-T10 · Contract review:** Review the “Replica availability accounting” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M11.05-C072 · Delivery

**Original checklist item:** Report which promised replicas remain usable under the tested domain loss.

- [ ] **UC-M11.05-C072-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Replica availability accounting”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M11.05-C072-T02 · Change plan:** Break the source delivery for “Replica availability accounting” into concrete edit targets and reviewable outputs; keep the UC-M11.05 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M11.05-C072-T03 · Core artifact:** Create the “Replica availability accounting” output artifact for this source instruction: Report which promised replicas remain usable under the tested domain loss.
- [ ] **UC-M11.05-C072-T04 · Concrete realization:** Populate the “Replica availability accounting” artifact from identified observations; keep unknown, failed and unexecuted results distinct and exclude unapproved sensitive material.
- [ ] **UC-M11.05-C072-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Replica availability accounting” needed to preserve “Replica counts distinguish present, ready and independently reachable instances”; record an enforcement gap where only a model exists.
- [ ] **UC-M11.05-C072-T06 · Dependency connection:** Connect the “Replica availability accounting” implementation to actual failure-domain inventory, resource-aware placement and ownership fencing; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M11.05-C072-T07 · Resource behavior:** Account for “Replica states and observation age” in “Replica availability accounting”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M11.05-C072-T08 · Delivery check:** Run the smallest real “Replica availability accounting” path and its adverse fixture “Unreachable stale replicas are counted as healthy redundancy”; retain actual output, state effects and final disposition.
- [ ] **UC-M11.05-C072-T09 · Patch review:** Review the “Replica availability accounting” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M11.05-C072-T10 · Delivery handoff:** Publish the “Replica availability accounting” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M11.05-C073 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Replica counts distinguish present, ready and independently reachable instances. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M11.05-C073-T01 · Named property:** Create a stable property/check name under this parent for “Replica availability accounting”; copy its required invariant exactly: “Replica counts distinguish present, ready and independently reachable instances”.
- [ ] **UC-M11.05-C073-T02 · Observable terms:** Define each term in the “Replica availability accounting” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M11.05-C073-T03 · Precondition set:** List the preconditions under which “Replica counts distinguish present, ready and independently reachable instances” must hold for “Replica availability accounting”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M11.05-C073-T04 · Transition coverage:** Map the “Replica availability accounting” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M11.05-C073-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Replica availability accounting”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M11.05-C073-T06 · Satisfying fixture:** Create a concrete “Replica availability accounting” case that satisfies “Replica counts distinguish present, ready and independently reachable instances”; record its expected observation before running the assertion or review.
- [ ] **UC-M11.05-C073-T07 · Violating fixture:** Create the source counterexample “Unreachable stale replicas are counted as healthy redundancy” for “Replica availability accounting”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M11.05-C073-T08 · Enforcement evidence:** Exercise the “Replica availability accounting” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M11.05-C073-T09 · Regression linkage:** Link the “Replica availability accounting” property to changes in actual failure-domain inventory, resource-aware placement and ownership fencing; record which dependency or contract changes require rerunning it.
- [ ] **UC-M11.05-C073-T10 · Property disposition:** Compare the satisfying and violating “Replica availability accounting” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M11.05-C074 · Integration

**Original checklist item:** Integrate replica availability accounting with actual failure-domain inventory, resource-aware placement and ownership fencing; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M11.05-C074-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Replica availability accounting” across actual failure-domain inventory, resource-aware placement and ownership fencing; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M11.05-C074-T02 · Field mapping:** Map every “Replica availability accounting” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M11.05-C074-T03 · Prerequisite identities:** Record the actual prerequisites for “Replica availability accounting” (source dependency list: UC-M05.02, UC-M11.04); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M11.05-C074-T04 · Ownership agreement:** Specify who owns “Replica availability accounting” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M11.05-C074-T05 · Handoff implementation:** Connect “Replica availability accounting” through the mapped seam using the real adapter or explicit specification reference; preserve “Replica counts distinguish present, ready and independently reachable instances” across the handoff.
- [ ] **UC-M11.05-C074-T06 · Absent-input case:** Omit one required “Replica availability accounting” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M11.05-C074-T07 · Stale-input case:** Supply an outdated “Replica availability accounting” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M11.05-C074-T08 · Incompatible-input case:** Supply an incompatible “Replica availability accounting” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M11.05-C074-T09 · Valid integration trace:** Run a valid “Replica availability accounting” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M11.05-C074-T10 · Seam review:** Reconcile the “Replica availability accounting” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M11.05-C075 · Valid-case test

**Original checklist item:** Run a valid-path fixture for replica availability accounting; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M11.05-C075-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Replica availability accounting” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M11.05-C075-T02 · Expected-result oracle:** Specify the “Replica availability accounting” expected result independently of the implementation output; include the property “Replica counts distinguish present, ready and independently reachable instances” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M11.05-C075-T03 · Fixture material:** Create the concrete “Replica availability accounting” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M11.05-C075-T04 · Target preparation:** Prepare the “Replica availability accounting” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M11.05-C075-T05 · Initial-state record:** Record the initial “Replica availability accounting” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M11.05-C075-T06 · Valid-path execution:** Execute the “Replica availability accounting” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M11.05-C075-T07 · Outcome comparison:** Compare every declared “Replica availability accounting” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M11.05-C075-T08 · State and bounds check:** Inspect the “Replica availability accounting” ownership/state effects and actual use of “Replica states and observation age”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M11.05-C075-T09 · Repeatability check:** Repeat the same “Replica availability accounting” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M11.05-C075-T10 · Positive evidence:** Attach the “Replica availability accounting” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M11.05-C076 · Negative test

**Original checklist item:** Negative case: Unreachable stale replicas are counted as healthy redundancy. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M11.05-C076-T01 · Adverse-case definition:** Create a test record for the exact “Replica availability accounting” source counterexample: “Unreachable stale replicas are counted as healthy redundancy”; state which precondition or invariant it challenges.
- [ ] **UC-M11.05-C076-T02 · Safe fixture boundary:** Define the contained test boundary for “Replica availability accounting”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M11.05-C076-T03 · Valid control:** Construct a valid “Replica availability accounting” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M11.05-C076-T04 · Minimal adverse input:** Derive the “Replica availability accounting” adverse fixture from the control with the smallest documented change needed to reproduce “Unreachable stale replicas are counted as healthy redundancy”; retain that change as reproducible data.
- [ ] **UC-M11.05-C076-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Replica availability accounting”; require “Replica counts distinguish present, ready and independently reachable instances” and forbid a false-success verdict.
- [ ] **UC-M11.05-C076-T06 · Adverse execution:** Exercise the “Replica availability accounting” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M11.05-C076-T07 · Effect inspection:** Inspect “Replica availability accounting” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M11.05-C076-T08 · Refusal versus failure:** Confirm the “Replica availability accounting” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M11.05-C076-T09 · Reset and retention:** Restore only the disposable “Replica availability accounting” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M11.05-C076-T10 · Negative regression:** Register the “Replica availability accounting” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M11.05-C077 · Change / failure test

**Original checklist item:** Exercise replica availability accounting when one selected host/domain becomes unreachable through a partial partition; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M11.05-C077-T01 · Scenario record:** Write the “Replica availability accounting” change/failure scenario exactly as supplied: one selected host/domain becomes unreachable through a partial partition; identify the property that must remain true: “Replica counts distinguish present, ready and independently reachable instances”.
- [ ] **UC-M11.05-C077-T02 · Baseline capture:** Create a known-valid “Replica availability accounting” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M11.05-C077-T03 · Injection map:** Locate the “Replica availability accounting” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M11.05-C077-T04 · Disposition oracle:** Define the legal intermediate and final “Replica availability accounting” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M11.05-C077-T05 · Controlled trigger:** Introduce the controlled “Replica availability accounting” scenario in the disposable fixture: one selected host/domain becomes unreachable through a partial partition; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M11.05-C077-T06 · Intermediate inspection:** Inspect the “Replica availability accounting” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M11.05-C077-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Replica availability accounting”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M11.05-C077-T08 · Stale-evidence cleanup:** Invalidate superseded “Replica availability accounting” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M11.05-C077-T09 · Repeat and compare:** Repeat the selected “Replica availability accounting” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M11.05-C077-T10 · Failure evidence:** Publish the “Replica availability accounting” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M11.05-C078 · Bounds

**Original checklist item:** Choose, document and test limits for replica states and observation age; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M11.05-C078-T01 · Quantity inventory:** Create a measurement inventory for “Replica availability accounting”: “Replica states and observation age”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M11.05-C078-T02 · Measurement method:** Choose how to observe each “Replica availability accounting” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M11.05-C078-T03 · Budget decision:** Select justified resource and input limits for “Replica availability accounting”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M11.05-C078-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Replica availability accounting” cases for “Replica states and observation age”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M11.05-C078-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Replica availability accounting” limit; preserve “Replica counts distinguish present, ready and independently reachable instances”.
- [ ] **UC-M11.05-C078-T06 · Normal measurement:** Run or review the normal “Replica availability accounting” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M11.05-C078-T07 · At-limit measurement:** Exercise the “Replica availability accounting” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M11.05-C078-T08 · Over-limit measurement:** Exercise the “Replica availability accounting” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M11.05-C078-T09 · Uncovered-scope report:** List the “Replica availability accounting” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M11.05-C078-T10 · Limit evidence:** Publish the selected “Replica availability accounting” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M11.05-C079 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for replica availability accounting with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M11.05-C079-T01 · Event inventory:** List the “Replica availability accounting” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M11.05-C079-T02 · Diagnostic schema:** Define nonsecret fields for “Replica availability accounting” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M11.05-C079-T03 · Failure mapping:** Map each documented “Replica availability accounting” refusal or error to a diagnostic outcome; include “Unreachable stale replicas are counted as healthy redundancy” and prohibit conversion into a success message.
- [ ] **UC-M11.05-C079-T04 · Emission path:** Add the “Replica availability accounting” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M11.05-C079-T05 · Redaction check:** Test “Replica availability accounting” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M11.05-C079-T06 · Output budget:** Set and exercise bounded “Replica availability accounting” message size, rate and retention compatible with “Replica states and observation age”; define truncation behavior that preserves the final reason.
- [ ] **UC-M11.05-C079-T07 · Success/refusal fixtures:** Capture “Replica availability accounting” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M11.05-C079-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Replica availability accounting” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M11.05-C079-T09 · Operator review:** Read the “Replica availability accounting” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M11.05-C079-T10 · Diagnostic evidence:** Publish redacted “Replica availability accounting” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M11.05-C080 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for replica availability accounting; label unexecuted checks as untested.

- [ ] **UC-M11.05-C080-T01 · Evidence inventory:** List the “Replica availability accounting” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M11.05-C080-T02 · Artifact references:** Record the exact “Replica availability accounting” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M11.05-C080-T03 · Fixture references:** Attach the “Replica availability accounting” fixture IDs, input identities and oracle definition; preserve the source counterexample “Unreachable stale replicas are counted as healthy redundancy” as a distinct evidence case.
- [ ] **UC-M11.05-C080-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Replica availability accounting”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M11.05-C080-T05 · Environment record:** Record the actual “Replica availability accounting” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M11.05-C080-T06 · Expected versus observed:** Pair every “Replica availability accounting” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M11.05-C080-T07 · Failure and limit records:** Attach “Replica availability accounting” change/failure and bounds evidence where required; include uncovered “Replica states and observation age” and unresolved violations of “Replica counts distinguish present, ready and independently reachable instances”.
- [ ] **UC-M11.05-C080-T08 · Evidence hygiene:** Check the “Replica availability accounting” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M11.05-C080-T09 · Reproduction review:** Have the “Replica availability accounting” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M11.05-C080-T10 · Acceptance linkage:** Link the “Replica availability accounting” evidence to its parent and UC-M11.05 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 09. Failure-domain drills

**Source delivery:** Remove one selected domain and verify the explicitly promised service behavior.

**Source invariant:** Loss tolerance is supported by observed topology-specific evidence.

**Source negative case:** A same-host process kill is used to claim datacenter-level resilience.

**Source bounded quantities:** Domains tested and drill repetitions.

### UC-M11.05-C081 · Contract

**Original checklist item:** Specify failure-domain drills inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M11.05-C081-T01 · Scope statement:** Draft the operation boundary for “Failure-domain drills” within Partition and failure-domain placement; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M11.05-C081-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Failure-domain drills”; record each producer, representation and missing-value meaning.
- [ ] **UC-M11.05-C081-T03 · Output inventory:** List the outputs of “Failure-domain drills” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M11.05-C081-T04 · Field dictionary:** Create a field-and-term dictionary for “Failure-domain drills”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M11.05-C081-T05 · Prerequisite contract:** Map “Failure-domain drills” to the source component prerequisites (UC-M05.02, UC-M11.04); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M11.05-C081-T06 · Authority map:** Identify who may produce, change and consume “Failure-domain drills”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M11.05-C081-T07 · Invariant clause:** Add a normative clause for “Failure-domain drills” that preserves “Loss tolerance is supported by observed topology-specific evidence”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M11.05-C081-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Failure-domain drills”; include the source counterexample “A same-host process kill is used to claim datacenter-level resilience” and the intended safe disposition.
- [ ] **UC-M11.05-C081-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Domains tested and drill repetitions” in the “Failure-domain drills” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M11.05-C081-T10 · Contract review:** Review the “Failure-domain drills” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M11.05-C082 · Delivery

**Original checklist item:** Remove one selected domain and verify the explicitly promised service behavior.

- [ ] **UC-M11.05-C082-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Failure-domain drills”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M11.05-C082-T02 · Change plan:** Break the source delivery for “Failure-domain drills” into concrete edit targets and reviewable outputs; keep the UC-M11.05 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M11.05-C082-T03 · Core artifact:** Implement the smallest selected-profile change for “Failure-domain drills” that realizes this source instruction: Remove one selected domain and verify the explicitly promised service behavior.
- [ ] **UC-M11.05-C082-T04 · Concrete realization:** Trace “Failure-domain drills” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M11.05-C082-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Failure-domain drills” needed to preserve “Loss tolerance is supported by observed topology-specific evidence”; record an enforcement gap where only a model exists.
- [ ] **UC-M11.05-C082-T06 · Dependency connection:** Connect the “Failure-domain drills” implementation to actual failure-domain inventory, resource-aware placement and ownership fencing; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M11.05-C082-T07 · Resource behavior:** Account for “Domains tested and drill repetitions” in “Failure-domain drills”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M11.05-C082-T08 · Delivery check:** Run the smallest real “Failure-domain drills” path and its adverse fixture “A same-host process kill is used to claim datacenter-level resilience”; retain actual output, state effects and final disposition.
- [ ] **UC-M11.05-C082-T09 · Patch review:** Review the “Failure-domain drills” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M11.05-C082-T10 · Delivery handoff:** Publish the “Failure-domain drills” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M11.05-C083 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Loss tolerance is supported by observed topology-specific evidence. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M11.05-C083-T01 · Named property:** Create a stable property/check name under this parent for “Failure-domain drills”; copy its required invariant exactly: “Loss tolerance is supported by observed topology-specific evidence”.
- [ ] **UC-M11.05-C083-T02 · Observable terms:** Define each term in the “Failure-domain drills” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M11.05-C083-T03 · Precondition set:** List the preconditions under which “Loss tolerance is supported by observed topology-specific evidence” must hold for “Failure-domain drills”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M11.05-C083-T04 · Transition coverage:** Map the “Failure-domain drills” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M11.05-C083-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Failure-domain drills”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M11.05-C083-T06 · Satisfying fixture:** Create a concrete “Failure-domain drills” case that satisfies “Loss tolerance is supported by observed topology-specific evidence”; record its expected observation before running the assertion or review.
- [ ] **UC-M11.05-C083-T07 · Violating fixture:** Create the source counterexample “A same-host process kill is used to claim datacenter-level resilience” for “Failure-domain drills”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M11.05-C083-T08 · Enforcement evidence:** Exercise the “Failure-domain drills” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M11.05-C083-T09 · Regression linkage:** Link the “Failure-domain drills” property to changes in actual failure-domain inventory, resource-aware placement and ownership fencing; record which dependency or contract changes require rerunning it.
- [ ] **UC-M11.05-C083-T10 · Property disposition:** Compare the satisfying and violating “Failure-domain drills” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M11.05-C084 · Integration

**Original checklist item:** Integrate failure-domain drills with actual failure-domain inventory, resource-aware placement and ownership fencing; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M11.05-C084-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Failure-domain drills” across actual failure-domain inventory, resource-aware placement and ownership fencing; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M11.05-C084-T02 · Field mapping:** Map every “Failure-domain drills” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M11.05-C084-T03 · Prerequisite identities:** Record the actual prerequisites for “Failure-domain drills” (source dependency list: UC-M05.02, UC-M11.04); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M11.05-C084-T04 · Ownership agreement:** Specify who owns “Failure-domain drills” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M11.05-C084-T05 · Handoff implementation:** Connect “Failure-domain drills” through the mapped seam using the real adapter or explicit specification reference; preserve “Loss tolerance is supported by observed topology-specific evidence” across the handoff.
- [ ] **UC-M11.05-C084-T06 · Absent-input case:** Omit one required “Failure-domain drills” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M11.05-C084-T07 · Stale-input case:** Supply an outdated “Failure-domain drills” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M11.05-C084-T08 · Incompatible-input case:** Supply an incompatible “Failure-domain drills” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M11.05-C084-T09 · Valid integration trace:** Run a valid “Failure-domain drills” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M11.05-C084-T10 · Seam review:** Reconcile the “Failure-domain drills” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M11.05-C085 · Valid-case test

**Original checklist item:** Run a valid-path fixture for failure-domain drills; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M11.05-C085-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Failure-domain drills” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M11.05-C085-T02 · Expected-result oracle:** Specify the “Failure-domain drills” expected result independently of the implementation output; include the property “Loss tolerance is supported by observed topology-specific evidence” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M11.05-C085-T03 · Fixture material:** Create the concrete “Failure-domain drills” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M11.05-C085-T04 · Target preparation:** Prepare the “Failure-domain drills” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M11.05-C085-T05 · Initial-state record:** Record the initial “Failure-domain drills” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M11.05-C085-T06 · Valid-path execution:** Execute the “Failure-domain drills” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M11.05-C085-T07 · Outcome comparison:** Compare every declared “Failure-domain drills” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M11.05-C085-T08 · State and bounds check:** Inspect the “Failure-domain drills” ownership/state effects and actual use of “Domains tested and drill repetitions”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M11.05-C085-T09 · Repeatability check:** Repeat the same “Failure-domain drills” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M11.05-C085-T10 · Positive evidence:** Attach the “Failure-domain drills” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M11.05-C086 · Negative test

**Original checklist item:** Negative case: A same-host process kill is used to claim datacenter-level resilience. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M11.05-C086-T01 · Adverse-case definition:** Create a test record for the exact “Failure-domain drills” source counterexample: “A same-host process kill is used to claim datacenter-level resilience”; state which precondition or invariant it challenges.
- [ ] **UC-M11.05-C086-T02 · Safe fixture boundary:** Define the contained test boundary for “Failure-domain drills”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M11.05-C086-T03 · Valid control:** Construct a valid “Failure-domain drills” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M11.05-C086-T04 · Minimal adverse input:** Derive the “Failure-domain drills” adverse fixture from the control with the smallest documented change needed to reproduce “A same-host process kill is used to claim datacenter-level resilience”; retain that change as reproducible data.
- [ ] **UC-M11.05-C086-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Failure-domain drills”; require “Loss tolerance is supported by observed topology-specific evidence” and forbid a false-success verdict.
- [ ] **UC-M11.05-C086-T06 · Adverse execution:** Exercise the “Failure-domain drills” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M11.05-C086-T07 · Effect inspection:** Inspect “Failure-domain drills” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M11.05-C086-T08 · Refusal versus failure:** Confirm the “Failure-domain drills” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M11.05-C086-T09 · Reset and retention:** Restore only the disposable “Failure-domain drills” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M11.05-C086-T10 · Negative regression:** Register the “Failure-domain drills” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M11.05-C087 · Change / failure test

**Original checklist item:** Exercise failure-domain drills when one selected host/domain becomes unreachable through a partial partition; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M11.05-C087-T01 · Scenario record:** Write the “Failure-domain drills” change/failure scenario exactly as supplied: one selected host/domain becomes unreachable through a partial partition; identify the property that must remain true: “Loss tolerance is supported by observed topology-specific evidence”.
- [ ] **UC-M11.05-C087-T02 · Baseline capture:** Create a known-valid “Failure-domain drills” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M11.05-C087-T03 · Injection map:** Locate the “Failure-domain drills” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M11.05-C087-T04 · Disposition oracle:** Define the legal intermediate and final “Failure-domain drills” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M11.05-C087-T05 · Controlled trigger:** Introduce the controlled “Failure-domain drills” scenario in the disposable fixture: one selected host/domain becomes unreachable through a partial partition; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M11.05-C087-T06 · Intermediate inspection:** Inspect the “Failure-domain drills” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M11.05-C087-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Failure-domain drills”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M11.05-C087-T08 · Stale-evidence cleanup:** Invalidate superseded “Failure-domain drills” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M11.05-C087-T09 · Repeat and compare:** Repeat the selected “Failure-domain drills” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M11.05-C087-T10 · Failure evidence:** Publish the “Failure-domain drills” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M11.05-C088 · Bounds

**Original checklist item:** Choose, document and test limits for domains tested and drill repetitions; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M11.05-C088-T01 · Quantity inventory:** Create a measurement inventory for “Failure-domain drills”: “Domains tested and drill repetitions”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M11.05-C088-T02 · Measurement method:** Choose how to observe each “Failure-domain drills” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M11.05-C088-T03 · Budget decision:** Select justified resource and input limits for “Failure-domain drills”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M11.05-C088-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Failure-domain drills” cases for “Domains tested and drill repetitions”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M11.05-C088-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Failure-domain drills” limit; preserve “Loss tolerance is supported by observed topology-specific evidence”.
- [ ] **UC-M11.05-C088-T06 · Normal measurement:** Run or review the normal “Failure-domain drills” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M11.05-C088-T07 · At-limit measurement:** Exercise the “Failure-domain drills” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M11.05-C088-T08 · Over-limit measurement:** Exercise the “Failure-domain drills” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M11.05-C088-T09 · Uncovered-scope report:** List the “Failure-domain drills” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M11.05-C088-T10 · Limit evidence:** Publish the selected “Failure-domain drills” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M11.05-C089 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for failure-domain drills with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M11.05-C089-T01 · Event inventory:** List the “Failure-domain drills” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M11.05-C089-T02 · Diagnostic schema:** Define nonsecret fields for “Failure-domain drills” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M11.05-C089-T03 · Failure mapping:** Map each documented “Failure-domain drills” refusal or error to a diagnostic outcome; include “A same-host process kill is used to claim datacenter-level resilience” and prohibit conversion into a success message.
- [ ] **UC-M11.05-C089-T04 · Emission path:** Add the “Failure-domain drills” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M11.05-C089-T05 · Redaction check:** Test “Failure-domain drills” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M11.05-C089-T06 · Output budget:** Set and exercise bounded “Failure-domain drills” message size, rate and retention compatible with “Domains tested and drill repetitions”; define truncation behavior that preserves the final reason.
- [ ] **UC-M11.05-C089-T07 · Success/refusal fixtures:** Capture “Failure-domain drills” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M11.05-C089-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Failure-domain drills” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M11.05-C089-T09 · Operator review:** Read the “Failure-domain drills” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M11.05-C089-T10 · Diagnostic evidence:** Publish redacted “Failure-domain drills” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M11.05-C090 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for failure-domain drills; label unexecuted checks as untested.

- [ ] **UC-M11.05-C090-T01 · Evidence inventory:** List the “Failure-domain drills” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M11.05-C090-T02 · Artifact references:** Record the exact “Failure-domain drills” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M11.05-C090-T03 · Fixture references:** Attach the “Failure-domain drills” fixture IDs, input identities and oracle definition; preserve the source counterexample “A same-host process kill is used to claim datacenter-level resilience” as a distinct evidence case.
- [ ] **UC-M11.05-C090-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Failure-domain drills”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M11.05-C090-T05 · Environment record:** Record the actual “Failure-domain drills” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M11.05-C090-T06 · Expected versus observed:** Pair every “Failure-domain drills” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M11.05-C090-T07 · Failure and limit records:** Attach “Failure-domain drills” change/failure and bounds evidence where required; include uncovered “Domains tested and drill repetitions” and unresolved violations of “Loss tolerance is supported by observed topology-specific evidence”.
- [ ] **UC-M11.05-C090-T08 · Evidence hygiene:** Check the “Failure-domain drills” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M11.05-C090-T09 · Reproduction review:** Have the “Failure-domain drills” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M11.05-C090-T10 · Acceptance linkage:** Link the “Failure-domain drills” evidence to its parent and UC-M11.05 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 10. Placement evidence

**Source delivery:** Publish topology, placement decisions, lost domain and observed commit behavior.

**Source invariant:** The resilience claim is limited to declared replicas and tested assumptions.

**Source negative case:** A drill loses accepted state while still reporting placement success.

**Source bounded quantities:** Evidence bytes and topology versions.

### UC-M11.05-C091 · Contract

**Original checklist item:** Specify placement evidence inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M11.05-C091-T01 · Scope statement:** Draft the operation boundary for “Placement evidence” within Partition and failure-domain placement; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M11.05-C091-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Placement evidence”; record each producer, representation and missing-value meaning.
- [ ] **UC-M11.05-C091-T03 · Output inventory:** List the outputs of “Placement evidence” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M11.05-C091-T04 · Field dictionary:** Create a field-and-term dictionary for “Placement evidence”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M11.05-C091-T05 · Prerequisite contract:** Map “Placement evidence” to the source component prerequisites (UC-M05.02, UC-M11.04); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M11.05-C091-T06 · Authority map:** Identify who may produce, change and consume “Placement evidence”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M11.05-C091-T07 · Invariant clause:** Add a normative clause for “Placement evidence” that preserves “The resilience claim is limited to declared replicas and tested assumptions”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M11.05-C091-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Placement evidence”; include the source counterexample “A drill loses accepted state while still reporting placement success” and the intended safe disposition.
- [ ] **UC-M11.05-C091-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Evidence bytes and topology versions” in the “Placement evidence” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M11.05-C091-T10 · Contract review:** Review the “Placement evidence” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M11.05-C092 · Delivery

**Original checklist item:** Publish topology, placement decisions, lost domain and observed commit behavior.

- [ ] **UC-M11.05-C092-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Placement evidence”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M11.05-C092-T02 · Change plan:** Break the source delivery for “Placement evidence” into concrete edit targets and reviewable outputs; keep the UC-M11.05 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M11.05-C092-T03 · Core artifact:** Create the “Placement evidence” output artifact for this source instruction: Publish topology, placement decisions, lost domain and observed commit behavior.
- [ ] **UC-M11.05-C092-T04 · Concrete realization:** Populate the “Placement evidence” artifact from identified observations; keep unknown, failed and unexecuted results distinct and exclude unapproved sensitive material.
- [ ] **UC-M11.05-C092-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Placement evidence” needed to preserve “The resilience claim is limited to declared replicas and tested assumptions”; record an enforcement gap where only a model exists.
- [ ] **UC-M11.05-C092-T06 · Dependency connection:** Connect the “Placement evidence” implementation to actual failure-domain inventory, resource-aware placement and ownership fencing; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M11.05-C092-T07 · Resource behavior:** Account for “Evidence bytes and topology versions” in “Placement evidence”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M11.05-C092-T08 · Delivery check:** Run the smallest real “Placement evidence” path and its adverse fixture “A drill loses accepted state while still reporting placement success”; retain actual output, state effects and final disposition.
- [ ] **UC-M11.05-C092-T09 · Patch review:** Review the “Placement evidence” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M11.05-C092-T10 · Delivery handoff:** Publish the “Placement evidence” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M11.05-C093 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: The resilience claim is limited to declared replicas and tested assumptions. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M11.05-C093-T01 · Named property:** Create a stable property/check name under this parent for “Placement evidence”; copy its required invariant exactly: “The resilience claim is limited to declared replicas and tested assumptions”.
- [ ] **UC-M11.05-C093-T02 · Observable terms:** Define each term in the “Placement evidence” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M11.05-C093-T03 · Precondition set:** List the preconditions under which “The resilience claim is limited to declared replicas and tested assumptions” must hold for “Placement evidence”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M11.05-C093-T04 · Transition coverage:** Map the “Placement evidence” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M11.05-C093-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Placement evidence”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M11.05-C093-T06 · Satisfying fixture:** Create a concrete “Placement evidence” case that satisfies “The resilience claim is limited to declared replicas and tested assumptions”; record its expected observation before running the assertion or review.
- [ ] **UC-M11.05-C093-T07 · Violating fixture:** Create the source counterexample “A drill loses accepted state while still reporting placement success” for “Placement evidence”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M11.05-C093-T08 · Enforcement evidence:** Exercise the “Placement evidence” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M11.05-C093-T09 · Regression linkage:** Link the “Placement evidence” property to changes in actual failure-domain inventory, resource-aware placement and ownership fencing; record which dependency or contract changes require rerunning it.
- [ ] **UC-M11.05-C093-T10 · Property disposition:** Compare the satisfying and violating “Placement evidence” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M11.05-C094 · Integration

**Original checklist item:** Integrate placement evidence with actual failure-domain inventory, resource-aware placement and ownership fencing; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M11.05-C094-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Placement evidence” across actual failure-domain inventory, resource-aware placement and ownership fencing; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M11.05-C094-T02 · Field mapping:** Map every “Placement evidence” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M11.05-C094-T03 · Prerequisite identities:** Record the actual prerequisites for “Placement evidence” (source dependency list: UC-M05.02, UC-M11.04); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M11.05-C094-T04 · Ownership agreement:** Specify who owns “Placement evidence” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M11.05-C094-T05 · Handoff implementation:** Connect “Placement evidence” through the mapped seam using the real adapter or explicit specification reference; preserve “The resilience claim is limited to declared replicas and tested assumptions” across the handoff.
- [ ] **UC-M11.05-C094-T06 · Absent-input case:** Omit one required “Placement evidence” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M11.05-C094-T07 · Stale-input case:** Supply an outdated “Placement evidence” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M11.05-C094-T08 · Incompatible-input case:** Supply an incompatible “Placement evidence” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M11.05-C094-T09 · Valid integration trace:** Run a valid “Placement evidence” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M11.05-C094-T10 · Seam review:** Reconcile the “Placement evidence” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M11.05-C095 · Valid-case test

**Original checklist item:** Run a valid-path fixture for placement evidence; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M11.05-C095-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Placement evidence” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M11.05-C095-T02 · Expected-result oracle:** Specify the “Placement evidence” expected result independently of the implementation output; include the property “The resilience claim is limited to declared replicas and tested assumptions” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M11.05-C095-T03 · Fixture material:** Create the concrete “Placement evidence” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M11.05-C095-T04 · Target preparation:** Prepare the “Placement evidence” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M11.05-C095-T05 · Initial-state record:** Record the initial “Placement evidence” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M11.05-C095-T06 · Valid-path execution:** Execute the “Placement evidence” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M11.05-C095-T07 · Outcome comparison:** Compare every declared “Placement evidence” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M11.05-C095-T08 · State and bounds check:** Inspect the “Placement evidence” ownership/state effects and actual use of “Evidence bytes and topology versions”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M11.05-C095-T09 · Repeatability check:** Repeat the same “Placement evidence” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M11.05-C095-T10 · Positive evidence:** Attach the “Placement evidence” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M11.05-C096 · Negative test

**Original checklist item:** Negative case: A drill loses accepted state while still reporting placement success. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M11.05-C096-T01 · Adverse-case definition:** Create a test record for the exact “Placement evidence” source counterexample: “A drill loses accepted state while still reporting placement success”; state which precondition or invariant it challenges.
- [ ] **UC-M11.05-C096-T02 · Safe fixture boundary:** Define the contained test boundary for “Placement evidence”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M11.05-C096-T03 · Valid control:** Construct a valid “Placement evidence” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M11.05-C096-T04 · Minimal adverse input:** Derive the “Placement evidence” adverse fixture from the control with the smallest documented change needed to reproduce “A drill loses accepted state while still reporting placement success”; retain that change as reproducible data.
- [ ] **UC-M11.05-C096-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Placement evidence”; require “The resilience claim is limited to declared replicas and tested assumptions” and forbid a false-success verdict.
- [ ] **UC-M11.05-C096-T06 · Adverse execution:** Exercise the “Placement evidence” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M11.05-C096-T07 · Effect inspection:** Inspect “Placement evidence” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M11.05-C096-T08 · Refusal versus failure:** Confirm the “Placement evidence” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M11.05-C096-T09 · Reset and retention:** Restore only the disposable “Placement evidence” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M11.05-C096-T10 · Negative regression:** Register the “Placement evidence” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M11.05-C097 · Change / failure test

**Original checklist item:** Exercise placement evidence when one selected host/domain becomes unreachable through a partial partition; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M11.05-C097-T01 · Scenario record:** Write the “Placement evidence” change/failure scenario exactly as supplied: one selected host/domain becomes unreachable through a partial partition; identify the property that must remain true: “The resilience claim is limited to declared replicas and tested assumptions”.
- [ ] **UC-M11.05-C097-T02 · Baseline capture:** Create a known-valid “Placement evidence” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M11.05-C097-T03 · Injection map:** Locate the “Placement evidence” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M11.05-C097-T04 · Disposition oracle:** Define the legal intermediate and final “Placement evidence” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M11.05-C097-T05 · Controlled trigger:** Introduce the controlled “Placement evidence” scenario in the disposable fixture: one selected host/domain becomes unreachable through a partial partition; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M11.05-C097-T06 · Intermediate inspection:** Inspect the “Placement evidence” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M11.05-C097-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Placement evidence”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M11.05-C097-T08 · Stale-evidence cleanup:** Invalidate superseded “Placement evidence” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M11.05-C097-T09 · Repeat and compare:** Repeat the selected “Placement evidence” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M11.05-C097-T10 · Failure evidence:** Publish the “Placement evidence” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M11.05-C098 · Bounds

**Original checklist item:** Choose, document and test limits for evidence bytes and topology versions; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M11.05-C098-T01 · Quantity inventory:** Create a measurement inventory for “Placement evidence”: “Evidence bytes and topology versions”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M11.05-C098-T02 · Measurement method:** Choose how to observe each “Placement evidence” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M11.05-C098-T03 · Budget decision:** Select justified resource and input limits for “Placement evidence”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M11.05-C098-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Placement evidence” cases for “Evidence bytes and topology versions”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M11.05-C098-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Placement evidence” limit; preserve “The resilience claim is limited to declared replicas and tested assumptions”.
- [ ] **UC-M11.05-C098-T06 · Normal measurement:** Run or review the normal “Placement evidence” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M11.05-C098-T07 · At-limit measurement:** Exercise the “Placement evidence” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M11.05-C098-T08 · Over-limit measurement:** Exercise the “Placement evidence” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M11.05-C098-T09 · Uncovered-scope report:** List the “Placement evidence” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M11.05-C098-T10 · Limit evidence:** Publish the selected “Placement evidence” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M11.05-C099 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for placement evidence with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M11.05-C099-T01 · Event inventory:** List the “Placement evidence” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M11.05-C099-T02 · Diagnostic schema:** Define nonsecret fields for “Placement evidence” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M11.05-C099-T03 · Failure mapping:** Map each documented “Placement evidence” refusal or error to a diagnostic outcome; include “A drill loses accepted state while still reporting placement success” and prohibit conversion into a success message.
- [ ] **UC-M11.05-C099-T04 · Emission path:** Add the “Placement evidence” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M11.05-C099-T05 · Redaction check:** Test “Placement evidence” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M11.05-C099-T06 · Output budget:** Set and exercise bounded “Placement evidence” message size, rate and retention compatible with “Evidence bytes and topology versions”; define truncation behavior that preserves the final reason.
- [ ] **UC-M11.05-C099-T07 · Success/refusal fixtures:** Capture “Placement evidence” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M11.05-C099-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Placement evidence” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M11.05-C099-T09 · Operator review:** Read the “Placement evidence” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M11.05-C099-T10 · Diagnostic evidence:** Publish redacted “Placement evidence” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M11.05-C100 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for placement evidence; label unexecuted checks as untested.

- [ ] **UC-M11.05-C100-T01 · Evidence inventory:** List the “Placement evidence” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M11.05-C100-T02 · Artifact references:** Record the exact “Placement evidence” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M11.05-C100-T03 · Fixture references:** Attach the “Placement evidence” fixture IDs, input identities and oracle definition; preserve the source counterexample “A drill loses accepted state while still reporting placement success” as a distinct evidence case.
- [ ] **UC-M11.05-C100-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Placement evidence”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M11.05-C100-T05 · Environment record:** Record the actual “Placement evidence” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M11.05-C100-T06 · Expected versus observed:** Pair every “Placement evidence” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M11.05-C100-T07 · Failure and limit records:** Attach “Placement evidence” change/failure and bounds evidence where required; include uncovered “Evidence bytes and topology versions” and unresolved violations of “The resilience claim is limited to declared replicas and tested assumptions”.
- [ ] **UC-M11.05-C100-T08 · Evidence hygiene:** Check the “Placement evidence” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M11.05-C100-T09 · Reproduction review:** Have the “Placement evidence” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M11.05-C100-T10 · Acceptance linkage:** Link the “Placement evidence” evidence to its parent and UC-M11.05 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

