# UC-M11.08 — Multi-host disaster-recovery qualification

**To-Do Pack 2.0.0 · Baseline UC-2.2.0 · 100 parent checks × 10 subtasks = 1,000 to-dos**

[Master index](../../INDEX.md) · [Workstream index](../../w/11.md)

| Field | Preserved source value |
|---|---|
| Workstream | 11. Optional multi-host federation |
| Milestone | D |
| Priority | P2 |
| Source assessment | MISSING |
| Scope | optional multi host |
| Dependencies | [UC-M11.04](../11/UC-M11.04.md), [UC-M11.06](../11/UC-M11.06.md), [UC-M11.07](../11/UC-M11.07.md) |
| Source checklist pack | 1.0.0 |
| Original reference labels | [S4], [S6]. |

## Original requirement

Test full controller/worker loss, restored identity and data, split brain and lost update metadata in the declared topology.

**Original acceptance criterion:** A documented drill meets chosen recovery objectives without trusting stale leaders or unsigned replacement artifacts.

**Source trace:** Original checklist `UC100/c/11/UC-M11.08.md` inside [s/checklists.zip](../../s/checklists.zip); exact parent records in [data/parents.jsonl](../../data/parents.jsonl). Original roadmap lines 1076–1087 are preserved in [s/roadmap.md](../../s/roadmap.md).

## How to use these lists

Every parent statement below is preserved verbatim. Its ten child tasks are proposed decomposition, not implemented capabilities or executed tests. Child IDs append `-T01` through `-T10` to the original parent ID. All begin unchecked / `TODO`. Design/review evidence does not establish runtime enforcement; observe the actual selected target where the parent requires it.

The source dependency graph and selected release profile determine applicability. The numbered child sequence is a local working order, not an added hard dependency graph. An unselected optional feature needs a recorded not-applicable rationale; missing prerequisites for selected work remain blockers. Numerical budgets, backends and trust mechanisms remain decisions unless fixed by the source. Test hostile cases only with synthetic inputs in authorized disposable environments.

## 01. Recovery objectives

**Source delivery:** Define explicit data-loss and service-recovery objectives for the selected topology.

**Source invariant:** Recovery promises are chosen requirements rather than invented measured results.

**Source negative case:** A report claims a recovery time that was never observed.

**Source bounded quantities:** Objective fields and affected workload classes.

### UC-M11.08-C001 · Contract

**Original checklist item:** Define the qualification objective for recovery objectives, including the actual target implementation, prerequisites, observable oracle and explicit exclusions.

- [ ] **UC-M11.08-C001-T01 · Scope statement:** Write the qualification question for “Recovery objectives”; identify the actual target, claimed capability and observations that can answer that question.
- [ ] **UC-M11.08-C001-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Recovery objectives”; record each producer, representation and missing-value meaning.
- [ ] **UC-M11.08-C001-T03 · Output inventory:** List the outputs of “Recovery objectives” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M11.08-C001-T04 · Field dictionary:** Create a field-and-term dictionary for “Recovery objectives”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M11.08-C001-T05 · Prerequisite contract:** Map “Recovery objectives” to the source component prerequisites (UC-M11.04, UC-M11.06, UC-M11.07); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M11.08-C001-T06 · Authority map:** Identify who may produce, change and consume “Recovery objectives”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M11.08-C001-T07 · Invariant clause:** Add a normative clause for “Recovery objectives” that preserves “Recovery promises are chosen requirements rather than invented measured results”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M11.08-C001-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Recovery objectives”; include the source counterexample “A report claims a recovery time that was never observed” and the intended safe disposition.
- [ ] **UC-M11.08-C001-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Objective fields and affected workload classes” in the “Recovery objectives” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M11.08-C001-T10 · Contract review:** Review the “Recovery objectives” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M11.08-C002 · Delivery

**Original checklist item:** Define explicit data-loss and service-recovery objectives for the selected topology.

- [ ] **UC-M11.08-C002-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Recovery objectives”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M11.08-C002-T02 · Change plan:** Break the source delivery for “Recovery objectives” into concrete edit targets and reviewable outputs; keep the UC-M11.08 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M11.08-C002-T03 · Core artifact:** Create the “Recovery objectives” model, schema or inventory that realizes this source instruction: Define explicit data-loss and service-recovery objectives for the selected topology.
- [ ] **UC-M11.08-C002-T04 · Concrete realization:** Populate “Recovery objectives” with one concrete worked case; map every required entity or field to its source and flag any unmapped entry.
- [ ] **UC-M11.08-C002-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Recovery objectives” needed to preserve “Recovery promises are chosen requirements rather than invented measured results”; record an enforcement gap where only a model exists.
- [ ] **UC-M11.08-C002-T06 · Dependency connection:** Connect the “Recovery objectives” qualification artifact to verified control/data recovery, restored identities and stale-leader fencing; record the target identity and what the harness actually exercises.
- [ ] **UC-M11.08-C002-T07 · Resource behavior:** Account for “Objective fields and affected workload classes” in “Recovery objectives”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M11.08-C002-T08 · Delivery check:** Run a known-valid control and a deliberately failing control for “Recovery objectives”; confirm the harness distinguishes their observed outcomes.
- [ ] **UC-M11.08-C002-T09 · Patch review:** Review the “Recovery objectives” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M11.08-C002-T10 · Delivery handoff:** Publish the “Recovery objectives” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M11.08-C003 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Recovery promises are chosen requirements rather than invented measured results. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M11.08-C003-T01 · Named property:** Create a stable property/check name under this parent for “Recovery objectives”; copy its required invariant exactly: “Recovery promises are chosen requirements rather than invented measured results”.
- [ ] **UC-M11.08-C003-T02 · Observable terms:** Define each term in the “Recovery objectives” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M11.08-C003-T03 · Precondition set:** List the preconditions under which “Recovery promises are chosen requirements rather than invented measured results” must hold for “Recovery objectives”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M11.08-C003-T04 · Transition coverage:** Map the “Recovery objectives” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M11.08-C003-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Recovery objectives”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M11.08-C003-T06 · Satisfying fixture:** Create a concrete “Recovery objectives” case that satisfies “Recovery promises are chosen requirements rather than invented measured results”; record its expected observation before running the assertion or review.
- [ ] **UC-M11.08-C003-T07 · Violating fixture:** Create the source counterexample “A report claims a recovery time that was never observed” for “Recovery objectives”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M11.08-C003-T08 · Enforcement evidence:** Exercise the “Recovery objectives” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M11.08-C003-T09 · Regression linkage:** Link the “Recovery objectives” property to changes in verified control/data recovery, restored identities and stale-leader fencing; record which dependency or contract changes require rerunning it.
- [ ] **UC-M11.08-C003-T10 · Property disposition:** Compare the satisfying and violating “Recovery objectives” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M11.08-C004 · Integration

**Original checklist item:** Integrate recovery objectives with verified control/data recovery, restored identities and stale-leader fencing; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M11.08-C004-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Recovery objectives” across verified control/data recovery, restored identities and stale-leader fencing; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M11.08-C004-T02 · Field mapping:** Map every “Recovery objectives” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M11.08-C004-T03 · Prerequisite identities:** Record the actual prerequisites for “Recovery objectives” (source dependency list: UC-M11.04, UC-M11.06, UC-M11.07); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M11.08-C004-T04 · Ownership agreement:** Specify who owns “Recovery objectives” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M11.08-C004-T05 · Handoff implementation:** Connect “Recovery objectives” through the mapped seam using the real adapter or explicit specification reference; preserve “Recovery promises are chosen requirements rather than invented measured results” across the handoff.
- [ ] **UC-M11.08-C004-T06 · Absent-input case:** Omit one required “Recovery objectives” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M11.08-C004-T07 · Stale-input case:** Supply an outdated “Recovery objectives” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M11.08-C004-T08 · Incompatible-input case:** Supply an incompatible “Recovery objectives” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M11.08-C004-T09 · Valid integration trace:** Run a valid “Recovery objectives” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M11.08-C004-T10 · Seam review:** Reconcile the “Recovery objectives” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M11.08-C005 · Valid-case test

**Original checklist item:** Run a known-valid control for recovery objectives; verify that the harness reaches its intended target and compare observed measurements or verdicts with predeclared expectations.

- [ ] **UC-M11.08-C005-T01 · Valid fixture choice:** Choose a known-valid control for “Recovery objectives”; document why it should pass and how it proves the harness reaches the intended target.
- [ ] **UC-M11.08-C005-T02 · Expected-result oracle:** Specify the “Recovery objectives” expected result independently of the implementation output; include the property “Recovery promises are chosen requirements rather than invented measured results” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M11.08-C005-T03 · Fixture material:** Create the concrete “Recovery objectives” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M11.08-C005-T04 · Target preparation:** Prepare the “Recovery objectives” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M11.08-C005-T05 · Initial-state record:** Record the initial “Recovery objectives” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M11.08-C005-T06 · Valid-path execution:** Run the “Recovery objectives” known-valid control on the identified target; retain enough observations to prove the correct target was exercised.
- [ ] **UC-M11.08-C005-T07 · Outcome comparison:** Compare every declared “Recovery objectives” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M11.08-C005-T08 · State and bounds check:** Inspect the “Recovery objectives” ownership/state effects and actual use of “Objective fields and affected workload classes”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M11.08-C005-T09 · Repeatability check:** Repeat the same “Recovery objectives” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M11.08-C005-T10 · Positive evidence:** Attach the “Recovery objectives” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M11.08-C006 · Negative test

**Original checklist item:** Negative case: A report claims a recovery time that was never observed. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M11.08-C006-T01 · Adverse-case definition:** Create a test record for the exact “Recovery objectives” source counterexample: “A report claims a recovery time that was never observed”; state which precondition or invariant it challenges.
- [ ] **UC-M11.08-C006-T02 · Safe fixture boundary:** Define the contained test boundary for “Recovery objectives”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M11.08-C006-T03 · Valid control:** Construct a valid “Recovery objectives” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M11.08-C006-T04 · Minimal adverse input:** Derive the “Recovery objectives” adverse fixture from the control with the smallest documented change needed to reproduce “A report claims a recovery time that was never observed”; retain that change as reproducible data.
- [ ] **UC-M11.08-C006-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Recovery objectives”; require “Recovery promises are chosen requirements rather than invented measured results” and forbid a false-success verdict.
- [ ] **UC-M11.08-C006-T06 · Adverse execution:** Exercise the “Recovery objectives” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M11.08-C006-T07 · Effect inspection:** Inspect “Recovery objectives” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M11.08-C006-T08 · Refusal versus failure:** Confirm the “Recovery objectives” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M11.08-C006-T09 · Reset and retention:** Restore only the disposable “Recovery objectives” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M11.08-C006-T10 · Negative regression:** Register the “Recovery objectives” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M11.08-C007 · Change / failure test

**Original checklist item:** Exercise recovery objectives when controllers and selected workers are lost and restored from independently verified material; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M11.08-C007-T01 · Scenario record:** Write the “Recovery objectives” change/failure scenario exactly as supplied: controllers and selected workers are lost and restored from independently verified material; identify the property that must remain true: “Recovery promises are chosen requirements rather than invented measured results”.
- [ ] **UC-M11.08-C007-T02 · Baseline capture:** Create a known-valid “Recovery objectives” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M11.08-C007-T03 · Injection map:** Locate the “Recovery objectives” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M11.08-C007-T04 · Disposition oracle:** Define the legal intermediate and final “Recovery objectives” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M11.08-C007-T05 · Controlled trigger:** Introduce the controlled “Recovery objectives” scenario in the disposable fixture: controllers and selected workers are lost and restored from independently verified material; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M11.08-C007-T06 · Intermediate inspection:** Inspect the “Recovery objectives” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M11.08-C007-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Recovery objectives”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M11.08-C007-T08 · Stale-evidence cleanup:** Invalidate superseded “Recovery objectives” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M11.08-C007-T09 · Repeat and compare:** Repeat the selected “Recovery objectives” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M11.08-C007-T10 · Failure evidence:** Publish the “Recovery objectives” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M11.08-C008 · Bounds

**Original checklist item:** Set a documented campaign budget for objective fields and affected workload classes; record actual consumption, incomplete coverage and the disposition when the budget is exhausted.

- [ ] **UC-M11.08-C008-T01 · Quantity inventory:** Create a measurement inventory for “Recovery objectives”: “Objective fields and affected workload classes”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M11.08-C008-T02 · Measurement method:** Choose how to observe each “Recovery objectives” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M11.08-C008-T03 · Budget decision:** Select justified campaign and target-resource budgets for “Recovery objectives”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M11.08-C008-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Recovery objectives” cases for “Objective fields and affected workload classes”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M11.08-C008-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Recovery objectives” limit; preserve “Recovery promises are chosen requirements rather than invented measured results”.
- [ ] **UC-M11.08-C008-T06 · Normal measurement:** Run or review the normal “Recovery objectives” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M11.08-C008-T07 · At-limit measurement:** Exercise the “Recovery objectives” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M11.08-C008-T08 · Over-limit measurement:** Exercise the “Recovery objectives” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M11.08-C008-T09 · Uncovered-scope report:** List the “Recovery objectives” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M11.08-C008-T10 · Limit evidence:** Publish the selected “Recovery objectives” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M11.08-C009 · Diagnostics / review

**Original checklist item:** Report recovery objectives results with executed, failed, skipped and unavailable cases separated; preserve the underlying observations and do not manufacture missing measurements.

- [ ] **UC-M11.08-C009-T01 · Result inventory:** Enumerate the required “Recovery objectives” qualification cases and intended targets before aggregating results; keep the planned denominator visible.
- [ ] **UC-M11.08-C009-T02 · Verdict schema:** Define separate executed-pass, executed-fail, skipped, unavailable and untested outcomes for “Recovery objectives”; document how incomplete cases block relevant claims.
- [ ] **UC-M11.08-C009-T03 · Identity fields:** Attach the actual target, fixture, configuration and revision identifiers to each “Recovery objectives” result; do not attribute host-only evidence to a guest or another OS.
- [ ] **UC-M11.08-C009-T04 · Observation capture:** Capture bounded raw “Recovery objectives” observations and harness errors; retain enough information to verify the reported oracle comparison.
- [ ] **UC-M11.08-C009-T05 · Aggregation rules:** Implement the “Recovery objectives” count/reduction rule so failures and missing measurements cannot disappear; preserve “Recovery promises are chosen requirements rather than invented measured results”.
- [ ] **UC-M11.08-C009-T06 · Failure visibility:** Feed a failing “Recovery objectives” control through the report path; assert the exact failed case and underlying observation remain visible.
- [ ] **UC-M11.08-C009-T07 · Missing-result visibility:** Withhold a required “Recovery objectives” measurement or target; verify the report uses unavailable/untested rather than a fabricated zero or passing value.
- [ ] **UC-M11.08-C009-T08 · Bounds and redaction:** Check “Recovery objectives” report size and retention against “Objective fields and affected workload classes”; remove secrets while retaining fixture and subject references.
- [ ] **UC-M11.08-C009-T09 · Report reconciliation:** Reconcile the “Recovery objectives” summary with every underlying case record; account for the full planned denominator and all omitted scope.
- [ ] **UC-M11.08-C009-T10 · Qualification handoff:** Publish the “Recovery objectives” report with measured observations, coverage limits and blockers; state which actual targets remain unqualified.

### UC-M11.08-C010 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for recovery objectives; label unexecuted checks as untested.

- [ ] **UC-M11.08-C010-T01 · Evidence inventory:** List the “Recovery objectives” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M11.08-C010-T02 · Artifact references:** Record the exact “Recovery objectives” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M11.08-C010-T03 · Fixture references:** Attach the “Recovery objectives” fixture IDs, input identities and oracle definition; preserve the source counterexample “A report claims a recovery time that was never observed” as a distinct evidence case.
- [ ] **UC-M11.08-C010-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Recovery objectives”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M11.08-C010-T05 · Environment record:** Record the actual “Recovery objectives” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M11.08-C010-T06 · Expected versus observed:** Pair every “Recovery objectives” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M11.08-C010-T07 · Failure and limit records:** Attach “Recovery objectives” change/failure and bounds evidence where required; include uncovered “Objective fields and affected workload classes” and unresolved violations of “Recovery promises are chosen requirements rather than invented measured results”.
- [ ] **UC-M11.08-C010-T08 · Evidence hygiene:** Check the “Recovery objectives” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M11.08-C010-T09 · Reproduction review:** Have the “Recovery objectives” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M11.08-C010-T10 · Acceptance linkage:** Link the “Recovery objectives” evidence to its parent and UC-M11.08 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 02. Disaster scenario matrix

**Source delivery:** Cover controller loss, worker loss, partition, identity loss and update-metadata loss.

**Source invariant:** The drill scope identifies all required selected failure classes.

**Source negative case:** Only a single worker restart is used to claim full disaster recovery.

**Source bounded quantities:** Scenarios and topology variants.

### UC-M11.08-C011 · Contract

**Original checklist item:** Define the qualification objective for disaster scenario matrix, including the actual target implementation, prerequisites, observable oracle and explicit exclusions.

- [ ] **UC-M11.08-C011-T01 · Scope statement:** Write the qualification question for “Disaster scenario matrix”; identify the actual target, claimed capability and observations that can answer that question.
- [ ] **UC-M11.08-C011-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Disaster scenario matrix”; record each producer, representation and missing-value meaning.
- [ ] **UC-M11.08-C011-T03 · Output inventory:** List the outputs of “Disaster scenario matrix” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M11.08-C011-T04 · Field dictionary:** Create a field-and-term dictionary for “Disaster scenario matrix”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M11.08-C011-T05 · Prerequisite contract:** Map “Disaster scenario matrix” to the source component prerequisites (UC-M11.04, UC-M11.06, UC-M11.07); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M11.08-C011-T06 · Authority map:** Identify who may produce, change and consume “Disaster scenario matrix”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M11.08-C011-T07 · Invariant clause:** Add a normative clause for “Disaster scenario matrix” that preserves “The drill scope identifies all required selected failure classes”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M11.08-C011-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Disaster scenario matrix”; include the source counterexample “Only a single worker restart is used to claim full disaster recovery” and the intended safe disposition.
- [ ] **UC-M11.08-C011-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Scenarios and topology variants” in the “Disaster scenario matrix” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M11.08-C011-T10 · Contract review:** Review the “Disaster scenario matrix” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M11.08-C012 · Delivery

**Original checklist item:** Cover controller loss, worker loss, partition, identity loss and update-metadata loss.

- [ ] **UC-M11.08-C012-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Disaster scenario matrix”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M11.08-C012-T02 · Change plan:** Break the source delivery for “Disaster scenario matrix” into concrete edit targets and reviewable outputs; keep the UC-M11.08 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M11.08-C012-T03 · Core artifact:** Implement the smallest selected-profile change for “Disaster scenario matrix” that realizes this source instruction: Cover controller loss, worker loss, partition, identity loss and update-metadata loss.
- [ ] **UC-M11.08-C012-T04 · Concrete realization:** Trace “Disaster scenario matrix” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M11.08-C012-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Disaster scenario matrix” needed to preserve “The drill scope identifies all required selected failure classes”; record an enforcement gap where only a model exists.
- [ ] **UC-M11.08-C012-T06 · Dependency connection:** Connect the “Disaster scenario matrix” qualification artifact to verified control/data recovery, restored identities and stale-leader fencing; record the target identity and what the harness actually exercises.
- [ ] **UC-M11.08-C012-T07 · Resource behavior:** Account for “Scenarios and topology variants” in “Disaster scenario matrix”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M11.08-C012-T08 · Delivery check:** Run a known-valid control and a deliberately failing control for “Disaster scenario matrix”; confirm the harness distinguishes their observed outcomes.
- [ ] **UC-M11.08-C012-T09 · Patch review:** Review the “Disaster scenario matrix” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M11.08-C012-T10 · Delivery handoff:** Publish the “Disaster scenario matrix” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M11.08-C013 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: The drill scope identifies all required selected failure classes. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M11.08-C013-T01 · Named property:** Create a stable property/check name under this parent for “Disaster scenario matrix”; copy its required invariant exactly: “The drill scope identifies all required selected failure classes”.
- [ ] **UC-M11.08-C013-T02 · Observable terms:** Define each term in the “Disaster scenario matrix” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M11.08-C013-T03 · Precondition set:** List the preconditions under which “The drill scope identifies all required selected failure classes” must hold for “Disaster scenario matrix”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M11.08-C013-T04 · Transition coverage:** Map the “Disaster scenario matrix” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M11.08-C013-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Disaster scenario matrix”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M11.08-C013-T06 · Satisfying fixture:** Create a concrete “Disaster scenario matrix” case that satisfies “The drill scope identifies all required selected failure classes”; record its expected observation before running the assertion or review.
- [ ] **UC-M11.08-C013-T07 · Violating fixture:** Create the source counterexample “Only a single worker restart is used to claim full disaster recovery” for “Disaster scenario matrix”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M11.08-C013-T08 · Enforcement evidence:** Exercise the “Disaster scenario matrix” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M11.08-C013-T09 · Regression linkage:** Link the “Disaster scenario matrix” property to changes in verified control/data recovery, restored identities and stale-leader fencing; record which dependency or contract changes require rerunning it.
- [ ] **UC-M11.08-C013-T10 · Property disposition:** Compare the satisfying and violating “Disaster scenario matrix” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M11.08-C014 · Integration

**Original checklist item:** Integrate disaster scenario matrix with verified control/data recovery, restored identities and stale-leader fencing; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M11.08-C014-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Disaster scenario matrix” across verified control/data recovery, restored identities and stale-leader fencing; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M11.08-C014-T02 · Field mapping:** Map every “Disaster scenario matrix” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M11.08-C014-T03 · Prerequisite identities:** Record the actual prerequisites for “Disaster scenario matrix” (source dependency list: UC-M11.04, UC-M11.06, UC-M11.07); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M11.08-C014-T04 · Ownership agreement:** Specify who owns “Disaster scenario matrix” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M11.08-C014-T05 · Handoff implementation:** Connect “Disaster scenario matrix” through the mapped seam using the real adapter or explicit specification reference; preserve “The drill scope identifies all required selected failure classes” across the handoff.
- [ ] **UC-M11.08-C014-T06 · Absent-input case:** Omit one required “Disaster scenario matrix” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M11.08-C014-T07 · Stale-input case:** Supply an outdated “Disaster scenario matrix” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M11.08-C014-T08 · Incompatible-input case:** Supply an incompatible “Disaster scenario matrix” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M11.08-C014-T09 · Valid integration trace:** Run a valid “Disaster scenario matrix” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M11.08-C014-T10 · Seam review:** Reconcile the “Disaster scenario matrix” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M11.08-C015 · Valid-case test

**Original checklist item:** Run a known-valid control for disaster scenario matrix; verify that the harness reaches its intended target and compare observed measurements or verdicts with predeclared expectations.

- [ ] **UC-M11.08-C015-T01 · Valid fixture choice:** Choose a known-valid control for “Disaster scenario matrix”; document why it should pass and how it proves the harness reaches the intended target.
- [ ] **UC-M11.08-C015-T02 · Expected-result oracle:** Specify the “Disaster scenario matrix” expected result independently of the implementation output; include the property “The drill scope identifies all required selected failure classes” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M11.08-C015-T03 · Fixture material:** Create the concrete “Disaster scenario matrix” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M11.08-C015-T04 · Target preparation:** Prepare the “Disaster scenario matrix” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M11.08-C015-T05 · Initial-state record:** Record the initial “Disaster scenario matrix” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M11.08-C015-T06 · Valid-path execution:** Run the “Disaster scenario matrix” known-valid control on the identified target; retain enough observations to prove the correct target was exercised.
- [ ] **UC-M11.08-C015-T07 · Outcome comparison:** Compare every declared “Disaster scenario matrix” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M11.08-C015-T08 · State and bounds check:** Inspect the “Disaster scenario matrix” ownership/state effects and actual use of “Scenarios and topology variants”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M11.08-C015-T09 · Repeatability check:** Repeat the same “Disaster scenario matrix” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M11.08-C015-T10 · Positive evidence:** Attach the “Disaster scenario matrix” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M11.08-C016 · Negative test

**Original checklist item:** Negative case: Only a single worker restart is used to claim full disaster recovery. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M11.08-C016-T01 · Adverse-case definition:** Create a test record for the exact “Disaster scenario matrix” source counterexample: “Only a single worker restart is used to claim full disaster recovery”; state which precondition or invariant it challenges.
- [ ] **UC-M11.08-C016-T02 · Safe fixture boundary:** Define the contained test boundary for “Disaster scenario matrix”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M11.08-C016-T03 · Valid control:** Construct a valid “Disaster scenario matrix” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M11.08-C016-T04 · Minimal adverse input:** Derive the “Disaster scenario matrix” adverse fixture from the control with the smallest documented change needed to reproduce “Only a single worker restart is used to claim full disaster recovery”; retain that change as reproducible data.
- [ ] **UC-M11.08-C016-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Disaster scenario matrix”; require “The drill scope identifies all required selected failure classes” and forbid a false-success verdict.
- [ ] **UC-M11.08-C016-T06 · Adverse execution:** Exercise the “Disaster scenario matrix” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M11.08-C016-T07 · Effect inspection:** Inspect “Disaster scenario matrix” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M11.08-C016-T08 · Refusal versus failure:** Confirm the “Disaster scenario matrix” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M11.08-C016-T09 · Reset and retention:** Restore only the disposable “Disaster scenario matrix” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M11.08-C016-T10 · Negative regression:** Register the “Disaster scenario matrix” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M11.08-C017 · Change / failure test

**Original checklist item:** Exercise disaster scenario matrix when controllers and selected workers are lost and restored from independently verified material; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M11.08-C017-T01 · Scenario record:** Write the “Disaster scenario matrix” change/failure scenario exactly as supplied: controllers and selected workers are lost and restored from independently verified material; identify the property that must remain true: “The drill scope identifies all required selected failure classes”.
- [ ] **UC-M11.08-C017-T02 · Baseline capture:** Create a known-valid “Disaster scenario matrix” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M11.08-C017-T03 · Injection map:** Locate the “Disaster scenario matrix” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M11.08-C017-T04 · Disposition oracle:** Define the legal intermediate and final “Disaster scenario matrix” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M11.08-C017-T05 · Controlled trigger:** Introduce the controlled “Disaster scenario matrix” scenario in the disposable fixture: controllers and selected workers are lost and restored from independently verified material; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M11.08-C017-T06 · Intermediate inspection:** Inspect the “Disaster scenario matrix” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M11.08-C017-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Disaster scenario matrix”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M11.08-C017-T08 · Stale-evidence cleanup:** Invalidate superseded “Disaster scenario matrix” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M11.08-C017-T09 · Repeat and compare:** Repeat the selected “Disaster scenario matrix” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M11.08-C017-T10 · Failure evidence:** Publish the “Disaster scenario matrix” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M11.08-C018 · Bounds

**Original checklist item:** Set a documented campaign budget for scenarios and topology variants; record actual consumption, incomplete coverage and the disposition when the budget is exhausted.

- [ ] **UC-M11.08-C018-T01 · Quantity inventory:** Create a measurement inventory for “Disaster scenario matrix”: “Scenarios and topology variants”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M11.08-C018-T02 · Measurement method:** Choose how to observe each “Disaster scenario matrix” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M11.08-C018-T03 · Budget decision:** Select justified campaign and target-resource budgets for “Disaster scenario matrix”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M11.08-C018-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Disaster scenario matrix” cases for “Scenarios and topology variants”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M11.08-C018-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Disaster scenario matrix” limit; preserve “The drill scope identifies all required selected failure classes”.
- [ ] **UC-M11.08-C018-T06 · Normal measurement:** Run or review the normal “Disaster scenario matrix” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M11.08-C018-T07 · At-limit measurement:** Exercise the “Disaster scenario matrix” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M11.08-C018-T08 · Over-limit measurement:** Exercise the “Disaster scenario matrix” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M11.08-C018-T09 · Uncovered-scope report:** List the “Disaster scenario matrix” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M11.08-C018-T10 · Limit evidence:** Publish the selected “Disaster scenario matrix” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M11.08-C019 · Diagnostics / review

**Original checklist item:** Report disaster scenario matrix results with executed, failed, skipped and unavailable cases separated; preserve the underlying observations and do not manufacture missing measurements.

- [ ] **UC-M11.08-C019-T01 · Result inventory:** Enumerate the required “Disaster scenario matrix” qualification cases and intended targets before aggregating results; keep the planned denominator visible.
- [ ] **UC-M11.08-C019-T02 · Verdict schema:** Define separate executed-pass, executed-fail, skipped, unavailable and untested outcomes for “Disaster scenario matrix”; document how incomplete cases block relevant claims.
- [ ] **UC-M11.08-C019-T03 · Identity fields:** Attach the actual target, fixture, configuration and revision identifiers to each “Disaster scenario matrix” result; do not attribute host-only evidence to a guest or another OS.
- [ ] **UC-M11.08-C019-T04 · Observation capture:** Capture bounded raw “Disaster scenario matrix” observations and harness errors; retain enough information to verify the reported oracle comparison.
- [ ] **UC-M11.08-C019-T05 · Aggregation rules:** Implement the “Disaster scenario matrix” count/reduction rule so failures and missing measurements cannot disappear; preserve “The drill scope identifies all required selected failure classes”.
- [ ] **UC-M11.08-C019-T06 · Failure visibility:** Feed a failing “Disaster scenario matrix” control through the report path; assert the exact failed case and underlying observation remain visible.
- [ ] **UC-M11.08-C019-T07 · Missing-result visibility:** Withhold a required “Disaster scenario matrix” measurement or target; verify the report uses unavailable/untested rather than a fabricated zero or passing value.
- [ ] **UC-M11.08-C019-T08 · Bounds and redaction:** Check “Disaster scenario matrix” report size and retention against “Scenarios and topology variants”; remove secrets while retaining fixture and subject references.
- [ ] **UC-M11.08-C019-T09 · Report reconciliation:** Reconcile the “Disaster scenario matrix” summary with every underlying case record; account for the full planned denominator and all omitted scope.
- [ ] **UC-M11.08-C019-T10 · Qualification handoff:** Publish the “Disaster scenario matrix” report with measured observations, coverage limits and blockers; state which actual targets remain unqualified.

### UC-M11.08-C020 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for disaster scenario matrix; label unexecuted checks as untested.

- [ ] **UC-M11.08-C020-T01 · Evidence inventory:** List the “Disaster scenario matrix” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M11.08-C020-T02 · Artifact references:** Record the exact “Disaster scenario matrix” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M11.08-C020-T03 · Fixture references:** Attach the “Disaster scenario matrix” fixture IDs, input identities and oracle definition; preserve the source counterexample “Only a single worker restart is used to claim full disaster recovery” as a distinct evidence case.
- [ ] **UC-M11.08-C020-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Disaster scenario matrix”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M11.08-C020-T05 · Environment record:** Record the actual “Disaster scenario matrix” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M11.08-C020-T06 · Expected versus observed:** Pair every “Disaster scenario matrix” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M11.08-C020-T07 · Failure and limit records:** Attach “Disaster scenario matrix” change/failure and bounds evidence where required; include uncovered “Scenarios and topology variants” and unresolved violations of “The drill scope identifies all required selected failure classes”.
- [ ] **UC-M11.08-C020-T08 · Evidence hygiene:** Check the “Disaster scenario matrix” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M11.08-C020-T09 · Reproduction review:** Have the “Disaster scenario matrix” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M11.08-C020-T10 · Acceptance linkage:** Link the “Disaster scenario matrix” evidence to its parent and UC-M11.08 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 03. Controller restoration

**Source delivery:** Restore authoritative control state from verified approved recovery material.

**Source invariant:** A restored controller cannot trust stale local leadership automatically.

**Source negative case:** An old controller backup overwrites newer committed desired state.

**Source bounded quantities:** Control-state bytes and replay duration.

### UC-M11.08-C021 · Contract

**Original checklist item:** Define the qualification objective for controller restoration, including the actual target implementation, prerequisites, observable oracle and explicit exclusions.

- [ ] **UC-M11.08-C021-T01 · Scope statement:** Write the qualification question for “Controller restoration”; identify the actual target, claimed capability and observations that can answer that question.
- [ ] **UC-M11.08-C021-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Controller restoration”; record each producer, representation and missing-value meaning.
- [ ] **UC-M11.08-C021-T03 · Output inventory:** List the outputs of “Controller restoration” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M11.08-C021-T04 · Field dictionary:** Create a field-and-term dictionary for “Controller restoration”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M11.08-C021-T05 · Prerequisite contract:** Map “Controller restoration” to the source component prerequisites (UC-M11.04, UC-M11.06, UC-M11.07); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M11.08-C021-T06 · Authority map:** Identify who may produce, change and consume “Controller restoration”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M11.08-C021-T07 · Invariant clause:** Add a normative clause for “Controller restoration” that preserves “A restored controller cannot trust stale local leadership automatically”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M11.08-C021-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Controller restoration”; include the source counterexample “An old controller backup overwrites newer committed desired state” and the intended safe disposition.
- [ ] **UC-M11.08-C021-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Control-state bytes and replay duration” in the “Controller restoration” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M11.08-C021-T10 · Contract review:** Review the “Controller restoration” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M11.08-C022 · Delivery

**Original checklist item:** Restore authoritative control state from verified approved recovery material.

- [ ] **UC-M11.08-C022-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Controller restoration”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M11.08-C022-T02 · Change plan:** Break the source delivery for “Controller restoration” into concrete edit targets and reviewable outputs; keep the UC-M11.08 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M11.08-C022-T03 · Core artifact:** Implement the smallest selected-profile change for “Controller restoration” that realizes this source instruction: Restore authoritative control state from verified approved recovery material.
- [ ] **UC-M11.08-C022-T04 · Concrete realization:** Trace “Controller restoration” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M11.08-C022-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Controller restoration” needed to preserve “A restored controller cannot trust stale local leadership automatically”; record an enforcement gap where only a model exists.
- [ ] **UC-M11.08-C022-T06 · Dependency connection:** Connect the “Controller restoration” qualification artifact to verified control/data recovery, restored identities and stale-leader fencing; record the target identity and what the harness actually exercises.
- [ ] **UC-M11.08-C022-T07 · Resource behavior:** Account for “Control-state bytes and replay duration” in “Controller restoration”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M11.08-C022-T08 · Delivery check:** Run a known-valid control and a deliberately failing control for “Controller restoration”; confirm the harness distinguishes their observed outcomes.
- [ ] **UC-M11.08-C022-T09 · Patch review:** Review the “Controller restoration” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M11.08-C022-T10 · Delivery handoff:** Publish the “Controller restoration” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M11.08-C023 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: A restored controller cannot trust stale local leadership automatically. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M11.08-C023-T01 · Named property:** Create a stable property/check name under this parent for “Controller restoration”; copy its required invariant exactly: “A restored controller cannot trust stale local leadership automatically”.
- [ ] **UC-M11.08-C023-T02 · Observable terms:** Define each term in the “Controller restoration” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M11.08-C023-T03 · Precondition set:** List the preconditions under which “A restored controller cannot trust stale local leadership automatically” must hold for “Controller restoration”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M11.08-C023-T04 · Transition coverage:** Map the “Controller restoration” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M11.08-C023-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Controller restoration”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M11.08-C023-T06 · Satisfying fixture:** Create a concrete “Controller restoration” case that satisfies “A restored controller cannot trust stale local leadership automatically”; record its expected observation before running the assertion or review.
- [ ] **UC-M11.08-C023-T07 · Violating fixture:** Create the source counterexample “An old controller backup overwrites newer committed desired state” for “Controller restoration”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M11.08-C023-T08 · Enforcement evidence:** Exercise the “Controller restoration” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M11.08-C023-T09 · Regression linkage:** Link the “Controller restoration” property to changes in verified control/data recovery, restored identities and stale-leader fencing; record which dependency or contract changes require rerunning it.
- [ ] **UC-M11.08-C023-T10 · Property disposition:** Compare the satisfying and violating “Controller restoration” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M11.08-C024 · Integration

**Original checklist item:** Integrate controller restoration with verified control/data recovery, restored identities and stale-leader fencing; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M11.08-C024-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Controller restoration” across verified control/data recovery, restored identities and stale-leader fencing; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M11.08-C024-T02 · Field mapping:** Map every “Controller restoration” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M11.08-C024-T03 · Prerequisite identities:** Record the actual prerequisites for “Controller restoration” (source dependency list: UC-M11.04, UC-M11.06, UC-M11.07); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M11.08-C024-T04 · Ownership agreement:** Specify who owns “Controller restoration” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M11.08-C024-T05 · Handoff implementation:** Connect “Controller restoration” through the mapped seam using the real adapter or explicit specification reference; preserve “A restored controller cannot trust stale local leadership automatically” across the handoff.
- [ ] **UC-M11.08-C024-T06 · Absent-input case:** Omit one required “Controller restoration” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M11.08-C024-T07 · Stale-input case:** Supply an outdated “Controller restoration” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M11.08-C024-T08 · Incompatible-input case:** Supply an incompatible “Controller restoration” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M11.08-C024-T09 · Valid integration trace:** Run a valid “Controller restoration” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M11.08-C024-T10 · Seam review:** Reconcile the “Controller restoration” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M11.08-C025 · Valid-case test

**Original checklist item:** Run a known-valid control for controller restoration; verify that the harness reaches its intended target and compare observed measurements or verdicts with predeclared expectations.

- [ ] **UC-M11.08-C025-T01 · Valid fixture choice:** Choose a known-valid control for “Controller restoration”; document why it should pass and how it proves the harness reaches the intended target.
- [ ] **UC-M11.08-C025-T02 · Expected-result oracle:** Specify the “Controller restoration” expected result independently of the implementation output; include the property “A restored controller cannot trust stale local leadership automatically” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M11.08-C025-T03 · Fixture material:** Create the concrete “Controller restoration” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M11.08-C025-T04 · Target preparation:** Prepare the “Controller restoration” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M11.08-C025-T05 · Initial-state record:** Record the initial “Controller restoration” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M11.08-C025-T06 · Valid-path execution:** Run the “Controller restoration” known-valid control on the identified target; retain enough observations to prove the correct target was exercised.
- [ ] **UC-M11.08-C025-T07 · Outcome comparison:** Compare every declared “Controller restoration” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M11.08-C025-T08 · State and bounds check:** Inspect the “Controller restoration” ownership/state effects and actual use of “Control-state bytes and replay duration”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M11.08-C025-T09 · Repeatability check:** Repeat the same “Controller restoration” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M11.08-C025-T10 · Positive evidence:** Attach the “Controller restoration” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M11.08-C026 · Negative test

**Original checklist item:** Negative case: An old controller backup overwrites newer committed desired state. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M11.08-C026-T01 · Adverse-case definition:** Create a test record for the exact “Controller restoration” source counterexample: “An old controller backup overwrites newer committed desired state”; state which precondition or invariant it challenges.
- [ ] **UC-M11.08-C026-T02 · Safe fixture boundary:** Define the contained test boundary for “Controller restoration”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M11.08-C026-T03 · Valid control:** Construct a valid “Controller restoration” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M11.08-C026-T04 · Minimal adverse input:** Derive the “Controller restoration” adverse fixture from the control with the smallest documented change needed to reproduce “An old controller backup overwrites newer committed desired state”; retain that change as reproducible data.
- [ ] **UC-M11.08-C026-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Controller restoration”; require “A restored controller cannot trust stale local leadership automatically” and forbid a false-success verdict.
- [ ] **UC-M11.08-C026-T06 · Adverse execution:** Exercise the “Controller restoration” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M11.08-C026-T07 · Effect inspection:** Inspect “Controller restoration” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M11.08-C026-T08 · Refusal versus failure:** Confirm the “Controller restoration” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M11.08-C026-T09 · Reset and retention:** Restore only the disposable “Controller restoration” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M11.08-C026-T10 · Negative regression:** Register the “Controller restoration” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M11.08-C027 · Change / failure test

**Original checklist item:** Exercise controller restoration when controllers and selected workers are lost and restored from independently verified material; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M11.08-C027-T01 · Scenario record:** Write the “Controller restoration” change/failure scenario exactly as supplied: controllers and selected workers are lost and restored from independently verified material; identify the property that must remain true: “A restored controller cannot trust stale local leadership automatically”.
- [ ] **UC-M11.08-C027-T02 · Baseline capture:** Create a known-valid “Controller restoration” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M11.08-C027-T03 · Injection map:** Locate the “Controller restoration” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M11.08-C027-T04 · Disposition oracle:** Define the legal intermediate and final “Controller restoration” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M11.08-C027-T05 · Controlled trigger:** Introduce the controlled “Controller restoration” scenario in the disposable fixture: controllers and selected workers are lost and restored from independently verified material; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M11.08-C027-T06 · Intermediate inspection:** Inspect the “Controller restoration” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M11.08-C027-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Controller restoration”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M11.08-C027-T08 · Stale-evidence cleanup:** Invalidate superseded “Controller restoration” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M11.08-C027-T09 · Repeat and compare:** Repeat the selected “Controller restoration” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M11.08-C027-T10 · Failure evidence:** Publish the “Controller restoration” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M11.08-C028 · Bounds

**Original checklist item:** Set a documented campaign budget for control-state bytes and replay duration; record actual consumption, incomplete coverage and the disposition when the budget is exhausted.

- [ ] **UC-M11.08-C028-T01 · Quantity inventory:** Create a measurement inventory for “Controller restoration”: “Control-state bytes and replay duration”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M11.08-C028-T02 · Measurement method:** Choose how to observe each “Controller restoration” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M11.08-C028-T03 · Budget decision:** Select justified campaign and target-resource budgets for “Controller restoration”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M11.08-C028-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Controller restoration” cases for “Control-state bytes and replay duration”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M11.08-C028-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Controller restoration” limit; preserve “A restored controller cannot trust stale local leadership automatically”.
- [ ] **UC-M11.08-C028-T06 · Normal measurement:** Run or review the normal “Controller restoration” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M11.08-C028-T07 · At-limit measurement:** Exercise the “Controller restoration” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M11.08-C028-T08 · Over-limit measurement:** Exercise the “Controller restoration” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M11.08-C028-T09 · Uncovered-scope report:** List the “Controller restoration” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M11.08-C028-T10 · Limit evidence:** Publish the selected “Controller restoration” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M11.08-C029 · Diagnostics / review

**Original checklist item:** Report controller restoration results with executed, failed, skipped and unavailable cases separated; preserve the underlying observations and do not manufacture missing measurements.

- [ ] **UC-M11.08-C029-T01 · Result inventory:** Enumerate the required “Controller restoration” qualification cases and intended targets before aggregating results; keep the planned denominator visible.
- [ ] **UC-M11.08-C029-T02 · Verdict schema:** Define separate executed-pass, executed-fail, skipped, unavailable and untested outcomes for “Controller restoration”; document how incomplete cases block relevant claims.
- [ ] **UC-M11.08-C029-T03 · Identity fields:** Attach the actual target, fixture, configuration and revision identifiers to each “Controller restoration” result; do not attribute host-only evidence to a guest or another OS.
- [ ] **UC-M11.08-C029-T04 · Observation capture:** Capture bounded raw “Controller restoration” observations and harness errors; retain enough information to verify the reported oracle comparison.
- [ ] **UC-M11.08-C029-T05 · Aggregation rules:** Implement the “Controller restoration” count/reduction rule so failures and missing measurements cannot disappear; preserve “A restored controller cannot trust stale local leadership automatically”.
- [ ] **UC-M11.08-C029-T06 · Failure visibility:** Feed a failing “Controller restoration” control through the report path; assert the exact failed case and underlying observation remain visible.
- [ ] **UC-M11.08-C029-T07 · Missing-result visibility:** Withhold a required “Controller restoration” measurement or target; verify the report uses unavailable/untested rather than a fabricated zero or passing value.
- [ ] **UC-M11.08-C029-T08 · Bounds and redaction:** Check “Controller restoration” report size and retention against “Control-state bytes and replay duration”; remove secrets while retaining fixture and subject references.
- [ ] **UC-M11.08-C029-T09 · Report reconciliation:** Reconcile the “Controller restoration” summary with every underlying case record; account for the full planned denominator and all omitted scope.
- [ ] **UC-M11.08-C029-T10 · Qualification handoff:** Publish the “Controller restoration” report with measured observations, coverage limits and blockers; state which actual targets remain unqualified.

### UC-M11.08-C030 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for controller restoration; label unexecuted checks as untested.

- [ ] **UC-M11.08-C030-T01 · Evidence inventory:** List the “Controller restoration” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M11.08-C030-T02 · Artifact references:** Record the exact “Controller restoration” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M11.08-C030-T03 · Fixture references:** Attach the “Controller restoration” fixture IDs, input identities and oracle definition; preserve the source counterexample “An old controller backup overwrites newer committed desired state” as a distinct evidence case.
- [ ] **UC-M11.08-C030-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Controller restoration”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M11.08-C030-T05 · Environment record:** Record the actual “Controller restoration” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M11.08-C030-T06 · Expected versus observed:** Pair every “Controller restoration” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M11.08-C030-T07 · Failure and limit records:** Attach “Controller restoration” change/failure and bounds evidence where required; include uncovered “Control-state bytes and replay duration” and unresolved violations of “A restored controller cannot trust stale local leadership automatically”.
- [ ] **UC-M11.08-C030-T08 · Evidence hygiene:** Check the “Controller restoration” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M11.08-C030-T09 · Reproduction review:** Have the “Controller restoration” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M11.08-C030-T10 · Acceptance linkage:** Link the “Controller restoration” evidence to its parent and UC-M11.08 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 04. Worker restoration

**Source delivery:** Reprovision and restore workers with current authenticated membership.

**Source invariant:** Replacement workers cannot join through unsigned or assumed identities.

**Source negative case:** A replacement host receives cargo before its identity is approved.

**Source bounded quantities:** Worker count and provisioning steps.

### UC-M11.08-C031 · Contract

**Original checklist item:** Define the qualification objective for worker restoration, including the actual target implementation, prerequisites, observable oracle and explicit exclusions.

- [ ] **UC-M11.08-C031-T01 · Scope statement:** Write the qualification question for “Worker restoration”; identify the actual target, claimed capability and observations that can answer that question.
- [ ] **UC-M11.08-C031-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Worker restoration”; record each producer, representation and missing-value meaning.
- [ ] **UC-M11.08-C031-T03 · Output inventory:** List the outputs of “Worker restoration” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M11.08-C031-T04 · Field dictionary:** Create a field-and-term dictionary for “Worker restoration”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M11.08-C031-T05 · Prerequisite contract:** Map “Worker restoration” to the source component prerequisites (UC-M11.04, UC-M11.06, UC-M11.07); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M11.08-C031-T06 · Authority map:** Identify who may produce, change and consume “Worker restoration”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M11.08-C031-T07 · Invariant clause:** Add a normative clause for “Worker restoration” that preserves “Replacement workers cannot join through unsigned or assumed identities”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M11.08-C031-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Worker restoration”; include the source counterexample “A replacement host receives cargo before its identity is approved” and the intended safe disposition.
- [ ] **UC-M11.08-C031-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Worker count and provisioning steps” in the “Worker restoration” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M11.08-C031-T10 · Contract review:** Review the “Worker restoration” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M11.08-C032 · Delivery

**Original checklist item:** Reprovision and restore workers with current authenticated membership.

- [ ] **UC-M11.08-C032-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Worker restoration”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M11.08-C032-T02 · Change plan:** Break the source delivery for “Worker restoration” into concrete edit targets and reviewable outputs; keep the UC-M11.08 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M11.08-C032-T03 · Core artifact:** Implement the smallest selected-profile change for “Worker restoration” that realizes this source instruction: Reprovision and restore workers with current authenticated membership.
- [ ] **UC-M11.08-C032-T04 · Concrete realization:** Trace “Worker restoration” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M11.08-C032-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Worker restoration” needed to preserve “Replacement workers cannot join through unsigned or assumed identities”; record an enforcement gap where only a model exists.
- [ ] **UC-M11.08-C032-T06 · Dependency connection:** Connect the “Worker restoration” qualification artifact to verified control/data recovery, restored identities and stale-leader fencing; record the target identity and what the harness actually exercises.
- [ ] **UC-M11.08-C032-T07 · Resource behavior:** Account for “Worker count and provisioning steps” in “Worker restoration”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M11.08-C032-T08 · Delivery check:** Run a known-valid control and a deliberately failing control for “Worker restoration”; confirm the harness distinguishes their observed outcomes.
- [ ] **UC-M11.08-C032-T09 · Patch review:** Review the “Worker restoration” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M11.08-C032-T10 · Delivery handoff:** Publish the “Worker restoration” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M11.08-C033 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Replacement workers cannot join through unsigned or assumed identities. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M11.08-C033-T01 · Named property:** Create a stable property/check name under this parent for “Worker restoration”; copy its required invariant exactly: “Replacement workers cannot join through unsigned or assumed identities”.
- [ ] **UC-M11.08-C033-T02 · Observable terms:** Define each term in the “Worker restoration” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M11.08-C033-T03 · Precondition set:** List the preconditions under which “Replacement workers cannot join through unsigned or assumed identities” must hold for “Worker restoration”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M11.08-C033-T04 · Transition coverage:** Map the “Worker restoration” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M11.08-C033-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Worker restoration”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M11.08-C033-T06 · Satisfying fixture:** Create a concrete “Worker restoration” case that satisfies “Replacement workers cannot join through unsigned or assumed identities”; record its expected observation before running the assertion or review.
- [ ] **UC-M11.08-C033-T07 · Violating fixture:** Create the source counterexample “A replacement host receives cargo before its identity is approved” for “Worker restoration”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M11.08-C033-T08 · Enforcement evidence:** Exercise the “Worker restoration” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M11.08-C033-T09 · Regression linkage:** Link the “Worker restoration” property to changes in verified control/data recovery, restored identities and stale-leader fencing; record which dependency or contract changes require rerunning it.
- [ ] **UC-M11.08-C033-T10 · Property disposition:** Compare the satisfying and violating “Worker restoration” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M11.08-C034 · Integration

**Original checklist item:** Integrate worker restoration with verified control/data recovery, restored identities and stale-leader fencing; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M11.08-C034-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Worker restoration” across verified control/data recovery, restored identities and stale-leader fencing; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M11.08-C034-T02 · Field mapping:** Map every “Worker restoration” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M11.08-C034-T03 · Prerequisite identities:** Record the actual prerequisites for “Worker restoration” (source dependency list: UC-M11.04, UC-M11.06, UC-M11.07); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M11.08-C034-T04 · Ownership agreement:** Specify who owns “Worker restoration” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M11.08-C034-T05 · Handoff implementation:** Connect “Worker restoration” through the mapped seam using the real adapter or explicit specification reference; preserve “Replacement workers cannot join through unsigned or assumed identities” across the handoff.
- [ ] **UC-M11.08-C034-T06 · Absent-input case:** Omit one required “Worker restoration” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M11.08-C034-T07 · Stale-input case:** Supply an outdated “Worker restoration” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M11.08-C034-T08 · Incompatible-input case:** Supply an incompatible “Worker restoration” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M11.08-C034-T09 · Valid integration trace:** Run a valid “Worker restoration” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M11.08-C034-T10 · Seam review:** Reconcile the “Worker restoration” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M11.08-C035 · Valid-case test

**Original checklist item:** Run a known-valid control for worker restoration; verify that the harness reaches its intended target and compare observed measurements or verdicts with predeclared expectations.

- [ ] **UC-M11.08-C035-T01 · Valid fixture choice:** Choose a known-valid control for “Worker restoration”; document why it should pass and how it proves the harness reaches the intended target.
- [ ] **UC-M11.08-C035-T02 · Expected-result oracle:** Specify the “Worker restoration” expected result independently of the implementation output; include the property “Replacement workers cannot join through unsigned or assumed identities” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M11.08-C035-T03 · Fixture material:** Create the concrete “Worker restoration” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M11.08-C035-T04 · Target preparation:** Prepare the “Worker restoration” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M11.08-C035-T05 · Initial-state record:** Record the initial “Worker restoration” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M11.08-C035-T06 · Valid-path execution:** Run the “Worker restoration” known-valid control on the identified target; retain enough observations to prove the correct target was exercised.
- [ ] **UC-M11.08-C035-T07 · Outcome comparison:** Compare every declared “Worker restoration” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M11.08-C035-T08 · State and bounds check:** Inspect the “Worker restoration” ownership/state effects and actual use of “Worker count and provisioning steps”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M11.08-C035-T09 · Repeatability check:** Repeat the same “Worker restoration” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M11.08-C035-T10 · Positive evidence:** Attach the “Worker restoration” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M11.08-C036 · Negative test

**Original checklist item:** Negative case: A replacement host receives cargo before its identity is approved. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M11.08-C036-T01 · Adverse-case definition:** Create a test record for the exact “Worker restoration” source counterexample: “A replacement host receives cargo before its identity is approved”; state which precondition or invariant it challenges.
- [ ] **UC-M11.08-C036-T02 · Safe fixture boundary:** Define the contained test boundary for “Worker restoration”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M11.08-C036-T03 · Valid control:** Construct a valid “Worker restoration” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M11.08-C036-T04 · Minimal adverse input:** Derive the “Worker restoration” adverse fixture from the control with the smallest documented change needed to reproduce “A replacement host receives cargo before its identity is approved”; retain that change as reproducible data.
- [ ] **UC-M11.08-C036-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Worker restoration”; require “Replacement workers cannot join through unsigned or assumed identities” and forbid a false-success verdict.
- [ ] **UC-M11.08-C036-T06 · Adverse execution:** Exercise the “Worker restoration” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M11.08-C036-T07 · Effect inspection:** Inspect “Worker restoration” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M11.08-C036-T08 · Refusal versus failure:** Confirm the “Worker restoration” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M11.08-C036-T09 · Reset and retention:** Restore only the disposable “Worker restoration” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M11.08-C036-T10 · Negative regression:** Register the “Worker restoration” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M11.08-C037 · Change / failure test

**Original checklist item:** Exercise worker restoration when controllers and selected workers are lost and restored from independently verified material; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M11.08-C037-T01 · Scenario record:** Write the “Worker restoration” change/failure scenario exactly as supplied: controllers and selected workers are lost and restored from independently verified material; identify the property that must remain true: “Replacement workers cannot join through unsigned or assumed identities”.
- [ ] **UC-M11.08-C037-T02 · Baseline capture:** Create a known-valid “Worker restoration” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M11.08-C037-T03 · Injection map:** Locate the “Worker restoration” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M11.08-C037-T04 · Disposition oracle:** Define the legal intermediate and final “Worker restoration” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M11.08-C037-T05 · Controlled trigger:** Introduce the controlled “Worker restoration” scenario in the disposable fixture: controllers and selected workers are lost and restored from independently verified material; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M11.08-C037-T06 · Intermediate inspection:** Inspect the “Worker restoration” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M11.08-C037-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Worker restoration”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M11.08-C037-T08 · Stale-evidence cleanup:** Invalidate superseded “Worker restoration” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M11.08-C037-T09 · Repeat and compare:** Repeat the selected “Worker restoration” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M11.08-C037-T10 · Failure evidence:** Publish the “Worker restoration” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M11.08-C038 · Bounds

**Original checklist item:** Set a documented campaign budget for worker count and provisioning steps; record actual consumption, incomplete coverage and the disposition when the budget is exhausted.

- [ ] **UC-M11.08-C038-T01 · Quantity inventory:** Create a measurement inventory for “Worker restoration”: “Worker count and provisioning steps”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M11.08-C038-T02 · Measurement method:** Choose how to observe each “Worker restoration” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M11.08-C038-T03 · Budget decision:** Select justified campaign and target-resource budgets for “Worker restoration”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M11.08-C038-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Worker restoration” cases for “Worker count and provisioning steps”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M11.08-C038-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Worker restoration” limit; preserve “Replacement workers cannot join through unsigned or assumed identities”.
- [ ] **UC-M11.08-C038-T06 · Normal measurement:** Run or review the normal “Worker restoration” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M11.08-C038-T07 · At-limit measurement:** Exercise the “Worker restoration” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M11.08-C038-T08 · Over-limit measurement:** Exercise the “Worker restoration” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M11.08-C038-T09 · Uncovered-scope report:** List the “Worker restoration” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M11.08-C038-T10 · Limit evidence:** Publish the selected “Worker restoration” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M11.08-C039 · Diagnostics / review

**Original checklist item:** Report worker restoration results with executed, failed, skipped and unavailable cases separated; preserve the underlying observations and do not manufacture missing measurements.

- [ ] **UC-M11.08-C039-T01 · Result inventory:** Enumerate the required “Worker restoration” qualification cases and intended targets before aggregating results; keep the planned denominator visible.
- [ ] **UC-M11.08-C039-T02 · Verdict schema:** Define separate executed-pass, executed-fail, skipped, unavailable and untested outcomes for “Worker restoration”; document how incomplete cases block relevant claims.
- [ ] **UC-M11.08-C039-T03 · Identity fields:** Attach the actual target, fixture, configuration and revision identifiers to each “Worker restoration” result; do not attribute host-only evidence to a guest or another OS.
- [ ] **UC-M11.08-C039-T04 · Observation capture:** Capture bounded raw “Worker restoration” observations and harness errors; retain enough information to verify the reported oracle comparison.
- [ ] **UC-M11.08-C039-T05 · Aggregation rules:** Implement the “Worker restoration” count/reduction rule so failures and missing measurements cannot disappear; preserve “Replacement workers cannot join through unsigned or assumed identities”.
- [ ] **UC-M11.08-C039-T06 · Failure visibility:** Feed a failing “Worker restoration” control through the report path; assert the exact failed case and underlying observation remain visible.
- [ ] **UC-M11.08-C039-T07 · Missing-result visibility:** Withhold a required “Worker restoration” measurement or target; verify the report uses unavailable/untested rather than a fabricated zero or passing value.
- [ ] **UC-M11.08-C039-T08 · Bounds and redaction:** Check “Worker restoration” report size and retention against “Worker count and provisioning steps”; remove secrets while retaining fixture and subject references.
- [ ] **UC-M11.08-C039-T09 · Report reconciliation:** Reconcile the “Worker restoration” summary with every underlying case record; account for the full planned denominator and all omitted scope.
- [ ] **UC-M11.08-C039-T10 · Qualification handoff:** Publish the “Worker restoration” report with measured observations, coverage limits and blockers; state which actual targets remain unqualified.

### UC-M11.08-C040 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for worker restoration; label unexecuted checks as untested.

- [ ] **UC-M11.08-C040-T01 · Evidence inventory:** List the “Worker restoration” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M11.08-C040-T02 · Artifact references:** Record the exact “Worker restoration” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M11.08-C040-T03 · Fixture references:** Attach the “Worker restoration” fixture IDs, input identities and oracle definition; preserve the source counterexample “A replacement host receives cargo before its identity is approved” as a distinct evidence case.
- [ ] **UC-M11.08-C040-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Worker restoration”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M11.08-C040-T05 · Environment record:** Record the actual “Worker restoration” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M11.08-C040-T06 · Expected versus observed:** Pair every “Worker restoration” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M11.08-C040-T07 · Failure and limit records:** Attach “Worker restoration” change/failure and bounds evidence where required; include uncovered “Worker count and provisioning steps” and unresolved violations of “Replacement workers cannot join through unsigned or assumed identities”.
- [ ] **UC-M11.08-C040-T08 · Evidence hygiene:** Check the “Worker restoration” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M11.08-C040-T09 · Reproduction review:** Have the “Worker restoration” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M11.08-C040-T10 · Acceptance linkage:** Link the “Worker restoration” evidence to its parent and UC-M11.08 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 05. Data restoration

**Source delivery:** Recover verified images and compatible state from independent retained objects.

**Source invariant:** Restored data has correct digest, tenant, image and generation bindings.

**Source negative case:** The only recovered snapshot belongs to an obsolete incompatible image.

**Source bounded quantities:** Restored bytes and dependency closure.

### UC-M11.08-C041 · Contract

**Original checklist item:** Define the qualification objective for data restoration, including the actual target implementation, prerequisites, observable oracle and explicit exclusions.

- [ ] **UC-M11.08-C041-T01 · Scope statement:** Write the qualification question for “Data restoration”; identify the actual target, claimed capability and observations that can answer that question.
- [ ] **UC-M11.08-C041-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Data restoration”; record each producer, representation and missing-value meaning.
- [ ] **UC-M11.08-C041-T03 · Output inventory:** List the outputs of “Data restoration” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M11.08-C041-T04 · Field dictionary:** Create a field-and-term dictionary for “Data restoration”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M11.08-C041-T05 · Prerequisite contract:** Map “Data restoration” to the source component prerequisites (UC-M11.04, UC-M11.06, UC-M11.07); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M11.08-C041-T06 · Authority map:** Identify who may produce, change and consume “Data restoration”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M11.08-C041-T07 · Invariant clause:** Add a normative clause for “Data restoration” that preserves “Restored data has correct digest, tenant, image and generation bindings”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M11.08-C041-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Data restoration”; include the source counterexample “The only recovered snapshot belongs to an obsolete incompatible image” and the intended safe disposition.
- [ ] **UC-M11.08-C041-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Restored bytes and dependency closure” in the “Data restoration” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M11.08-C041-T10 · Contract review:** Review the “Data restoration” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M11.08-C042 · Delivery

**Original checklist item:** Recover verified images and compatible state from independent retained objects.

- [ ] **UC-M11.08-C042-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Data restoration”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M11.08-C042-T02 · Change plan:** Break the source delivery for “Data restoration” into concrete edit targets and reviewable outputs; keep the UC-M11.08 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M11.08-C042-T03 · Core artifact:** Implement the smallest selected-profile change for “Data restoration” that realizes this source instruction: Recover verified images and compatible state from independent retained objects.
- [ ] **UC-M11.08-C042-T04 · Concrete realization:** Trace “Data restoration” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M11.08-C042-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Data restoration” needed to preserve “Restored data has correct digest, tenant, image and generation bindings”; record an enforcement gap where only a model exists.
- [ ] **UC-M11.08-C042-T06 · Dependency connection:** Connect the “Data restoration” qualification artifact to verified control/data recovery, restored identities and stale-leader fencing; record the target identity and what the harness actually exercises.
- [ ] **UC-M11.08-C042-T07 · Resource behavior:** Account for “Restored bytes and dependency closure” in “Data restoration”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M11.08-C042-T08 · Delivery check:** Run a known-valid control and a deliberately failing control for “Data restoration”; confirm the harness distinguishes their observed outcomes.
- [ ] **UC-M11.08-C042-T09 · Patch review:** Review the “Data restoration” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M11.08-C042-T10 · Delivery handoff:** Publish the “Data restoration” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M11.08-C043 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Restored data has correct digest, tenant, image and generation bindings. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M11.08-C043-T01 · Named property:** Create a stable property/check name under this parent for “Data restoration”; copy its required invariant exactly: “Restored data has correct digest, tenant, image and generation bindings”.
- [ ] **UC-M11.08-C043-T02 · Observable terms:** Define each term in the “Data restoration” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M11.08-C043-T03 · Precondition set:** List the preconditions under which “Restored data has correct digest, tenant, image and generation bindings” must hold for “Data restoration”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M11.08-C043-T04 · Transition coverage:** Map the “Data restoration” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M11.08-C043-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Data restoration”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M11.08-C043-T06 · Satisfying fixture:** Create a concrete “Data restoration” case that satisfies “Restored data has correct digest, tenant, image and generation bindings”; record its expected observation before running the assertion or review.
- [ ] **UC-M11.08-C043-T07 · Violating fixture:** Create the source counterexample “The only recovered snapshot belongs to an obsolete incompatible image” for “Data restoration”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M11.08-C043-T08 · Enforcement evidence:** Exercise the “Data restoration” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M11.08-C043-T09 · Regression linkage:** Link the “Data restoration” property to changes in verified control/data recovery, restored identities and stale-leader fencing; record which dependency or contract changes require rerunning it.
- [ ] **UC-M11.08-C043-T10 · Property disposition:** Compare the satisfying and violating “Data restoration” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M11.08-C044 · Integration

**Original checklist item:** Integrate data restoration with verified control/data recovery, restored identities and stale-leader fencing; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M11.08-C044-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Data restoration” across verified control/data recovery, restored identities and stale-leader fencing; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M11.08-C044-T02 · Field mapping:** Map every “Data restoration” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M11.08-C044-T03 · Prerequisite identities:** Record the actual prerequisites for “Data restoration” (source dependency list: UC-M11.04, UC-M11.06, UC-M11.07); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M11.08-C044-T04 · Ownership agreement:** Specify who owns “Data restoration” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M11.08-C044-T05 · Handoff implementation:** Connect “Data restoration” through the mapped seam using the real adapter or explicit specification reference; preserve “Restored data has correct digest, tenant, image and generation bindings” across the handoff.
- [ ] **UC-M11.08-C044-T06 · Absent-input case:** Omit one required “Data restoration” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M11.08-C044-T07 · Stale-input case:** Supply an outdated “Data restoration” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M11.08-C044-T08 · Incompatible-input case:** Supply an incompatible “Data restoration” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M11.08-C044-T09 · Valid integration trace:** Run a valid “Data restoration” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M11.08-C044-T10 · Seam review:** Reconcile the “Data restoration” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M11.08-C045 · Valid-case test

**Original checklist item:** Run a known-valid control for data restoration; verify that the harness reaches its intended target and compare observed measurements or verdicts with predeclared expectations.

- [ ] **UC-M11.08-C045-T01 · Valid fixture choice:** Choose a known-valid control for “Data restoration”; document why it should pass and how it proves the harness reaches the intended target.
- [ ] **UC-M11.08-C045-T02 · Expected-result oracle:** Specify the “Data restoration” expected result independently of the implementation output; include the property “Restored data has correct digest, tenant, image and generation bindings” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M11.08-C045-T03 · Fixture material:** Create the concrete “Data restoration” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M11.08-C045-T04 · Target preparation:** Prepare the “Data restoration” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M11.08-C045-T05 · Initial-state record:** Record the initial “Data restoration” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M11.08-C045-T06 · Valid-path execution:** Run the “Data restoration” known-valid control on the identified target; retain enough observations to prove the correct target was exercised.
- [ ] **UC-M11.08-C045-T07 · Outcome comparison:** Compare every declared “Data restoration” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M11.08-C045-T08 · State and bounds check:** Inspect the “Data restoration” ownership/state effects and actual use of “Restored bytes and dependency closure”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M11.08-C045-T09 · Repeatability check:** Repeat the same “Data restoration” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M11.08-C045-T10 · Positive evidence:** Attach the “Data restoration” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M11.08-C046 · Negative test

**Original checklist item:** Negative case: The only recovered snapshot belongs to an obsolete incompatible image. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M11.08-C046-T01 · Adverse-case definition:** Create a test record for the exact “Data restoration” source counterexample: “The only recovered snapshot belongs to an obsolete incompatible image”; state which precondition or invariant it challenges.
- [ ] **UC-M11.08-C046-T02 · Safe fixture boundary:** Define the contained test boundary for “Data restoration”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M11.08-C046-T03 · Valid control:** Construct a valid “Data restoration” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M11.08-C046-T04 · Minimal adverse input:** Derive the “Data restoration” adverse fixture from the control with the smallest documented change needed to reproduce “The only recovered snapshot belongs to an obsolete incompatible image”; retain that change as reproducible data.
- [ ] **UC-M11.08-C046-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Data restoration”; require “Restored data has correct digest, tenant, image and generation bindings” and forbid a false-success verdict.
- [ ] **UC-M11.08-C046-T06 · Adverse execution:** Exercise the “Data restoration” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M11.08-C046-T07 · Effect inspection:** Inspect “Data restoration” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M11.08-C046-T08 · Refusal versus failure:** Confirm the “Data restoration” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M11.08-C046-T09 · Reset and retention:** Restore only the disposable “Data restoration” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M11.08-C046-T10 · Negative regression:** Register the “Data restoration” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M11.08-C047 · Change / failure test

**Original checklist item:** Exercise data restoration when controllers and selected workers are lost and restored from independently verified material; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M11.08-C047-T01 · Scenario record:** Write the “Data restoration” change/failure scenario exactly as supplied: controllers and selected workers are lost and restored from independently verified material; identify the property that must remain true: “Restored data has correct digest, tenant, image and generation bindings”.
- [ ] **UC-M11.08-C047-T02 · Baseline capture:** Create a known-valid “Data restoration” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M11.08-C047-T03 · Injection map:** Locate the “Data restoration” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M11.08-C047-T04 · Disposition oracle:** Define the legal intermediate and final “Data restoration” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M11.08-C047-T05 · Controlled trigger:** Introduce the controlled “Data restoration” scenario in the disposable fixture: controllers and selected workers are lost and restored from independently verified material; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M11.08-C047-T06 · Intermediate inspection:** Inspect the “Data restoration” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M11.08-C047-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Data restoration”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M11.08-C047-T08 · Stale-evidence cleanup:** Invalidate superseded “Data restoration” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M11.08-C047-T09 · Repeat and compare:** Repeat the selected “Data restoration” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M11.08-C047-T10 · Failure evidence:** Publish the “Data restoration” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M11.08-C048 · Bounds

**Original checklist item:** Set a documented campaign budget for restored bytes and dependency closure; record actual consumption, incomplete coverage and the disposition when the budget is exhausted.

- [ ] **UC-M11.08-C048-T01 · Quantity inventory:** Create a measurement inventory for “Data restoration”: “Restored bytes and dependency closure”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M11.08-C048-T02 · Measurement method:** Choose how to observe each “Data restoration” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M11.08-C048-T03 · Budget decision:** Select justified campaign and target-resource budgets for “Data restoration”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M11.08-C048-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Data restoration” cases for “Restored bytes and dependency closure”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M11.08-C048-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Data restoration” limit; preserve “Restored data has correct digest, tenant, image and generation bindings”.
- [ ] **UC-M11.08-C048-T06 · Normal measurement:** Run or review the normal “Data restoration” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M11.08-C048-T07 · At-limit measurement:** Exercise the “Data restoration” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M11.08-C048-T08 · Over-limit measurement:** Exercise the “Data restoration” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M11.08-C048-T09 · Uncovered-scope report:** List the “Data restoration” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M11.08-C048-T10 · Limit evidence:** Publish the selected “Data restoration” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M11.08-C049 · Diagnostics / review

**Original checklist item:** Report data restoration results with executed, failed, skipped and unavailable cases separated; preserve the underlying observations and do not manufacture missing measurements.

- [ ] **UC-M11.08-C049-T01 · Result inventory:** Enumerate the required “Data restoration” qualification cases and intended targets before aggregating results; keep the planned denominator visible.
- [ ] **UC-M11.08-C049-T02 · Verdict schema:** Define separate executed-pass, executed-fail, skipped, unavailable and untested outcomes for “Data restoration”; document how incomplete cases block relevant claims.
- [ ] **UC-M11.08-C049-T03 · Identity fields:** Attach the actual target, fixture, configuration and revision identifiers to each “Data restoration” result; do not attribute host-only evidence to a guest or another OS.
- [ ] **UC-M11.08-C049-T04 · Observation capture:** Capture bounded raw “Data restoration” observations and harness errors; retain enough information to verify the reported oracle comparison.
- [ ] **UC-M11.08-C049-T05 · Aggregation rules:** Implement the “Data restoration” count/reduction rule so failures and missing measurements cannot disappear; preserve “Restored data has correct digest, tenant, image and generation bindings”.
- [ ] **UC-M11.08-C049-T06 · Failure visibility:** Feed a failing “Data restoration” control through the report path; assert the exact failed case and underlying observation remain visible.
- [ ] **UC-M11.08-C049-T07 · Missing-result visibility:** Withhold a required “Data restoration” measurement or target; verify the report uses unavailable/untested rather than a fabricated zero or passing value.
- [ ] **UC-M11.08-C049-T08 · Bounds and redaction:** Check “Data restoration” report size and retention against “Restored bytes and dependency closure”; remove secrets while retaining fixture and subject references.
- [ ] **UC-M11.08-C049-T09 · Report reconciliation:** Reconcile the “Data restoration” summary with every underlying case record; account for the full planned denominator and all omitted scope.
- [ ] **UC-M11.08-C049-T10 · Qualification handoff:** Publish the “Data restoration” report with measured observations, coverage limits and blockers; state which actual targets remain unqualified.

### UC-M11.08-C050 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for data restoration; label unexecuted checks as untested.

- [ ] **UC-M11.08-C050-T01 · Evidence inventory:** List the “Data restoration” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M11.08-C050-T02 · Artifact references:** Record the exact “Data restoration” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M11.08-C050-T03 · Fixture references:** Attach the “Data restoration” fixture IDs, input identities and oracle definition; preserve the source counterexample “The only recovered snapshot belongs to an obsolete incompatible image” as a distinct evidence case.
- [ ] **UC-M11.08-C050-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Data restoration”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M11.08-C050-T05 · Environment record:** Record the actual “Data restoration” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M11.08-C050-T06 · Expected versus observed:** Pair every “Data restoration” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M11.08-C050-T07 · Failure and limit records:** Attach “Data restoration” change/failure and bounds evidence where required; include uncovered “Restored bytes and dependency closure” and unresolved violations of “Restored data has correct digest, tenant, image and generation bindings”.
- [ ] **UC-M11.08-C050-T08 · Evidence hygiene:** Check the “Data restoration” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M11.08-C050-T09 · Reproduction review:** Have the “Data restoration” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M11.08-C050-T10 · Acceptance linkage:** Link the “Data restoration” evidence to its parent and UC-M11.08 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 06. Split-brain prevention

**Source delivery:** Exercise old and restored controllers or workers attempting concurrent authority.

**Source invariant:** Stale leaders and previous owners cannot commit after recovery authority changes.

**Source negative case:** A recovered old leader continues accepting writes during the drill.

**Source bounded quantities:** Contending authorities and fencing checks.

### UC-M11.08-C051 · Contract

**Original checklist item:** Define the qualification objective for split-brain prevention, including the actual target implementation, prerequisites, observable oracle and explicit exclusions.

- [ ] **UC-M11.08-C051-T01 · Scope statement:** Write the qualification question for “Split-brain prevention”; identify the actual target, claimed capability and observations that can answer that question.
- [ ] **UC-M11.08-C051-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Split-brain prevention”; record each producer, representation and missing-value meaning.
- [ ] **UC-M11.08-C051-T03 · Output inventory:** List the outputs of “Split-brain prevention” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M11.08-C051-T04 · Field dictionary:** Create a field-and-term dictionary for “Split-brain prevention”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M11.08-C051-T05 · Prerequisite contract:** Map “Split-brain prevention” to the source component prerequisites (UC-M11.04, UC-M11.06, UC-M11.07); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M11.08-C051-T06 · Authority map:** Identify who may produce, change and consume “Split-brain prevention”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M11.08-C051-T07 · Invariant clause:** Add a normative clause for “Split-brain prevention” that preserves “Stale leaders and previous owners cannot commit after recovery authority changes”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M11.08-C051-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Split-brain prevention”; include the source counterexample “A recovered old leader continues accepting writes during the drill” and the intended safe disposition.
- [ ] **UC-M11.08-C051-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Contending authorities and fencing checks” in the “Split-brain prevention” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M11.08-C051-T10 · Contract review:** Review the “Split-brain prevention” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M11.08-C052 · Delivery

**Original checklist item:** Exercise old and restored controllers or workers attempting concurrent authority.

- [ ] **UC-M11.08-C052-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Split-brain prevention”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M11.08-C052-T02 · Change plan:** Break the source delivery for “Split-brain prevention” into concrete edit targets and reviewable outputs; keep the UC-M11.08 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M11.08-C052-T03 · Core artifact:** Create the “Split-brain prevention” fixture or harness for this source instruction: Exercise old and restored controllers or workers attempting concurrent authority.
- [ ] **UC-M11.08-C052-T04 · Concrete realization:** Connect the “Split-brain prevention” harness to its actual intended target, set the expected oracle before running it, and distinguish a mock/control run from a target run.
- [ ] **UC-M11.08-C052-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Split-brain prevention” needed to preserve “Stale leaders and previous owners cannot commit after recovery authority changes”; record an enforcement gap where only a model exists.
- [ ] **UC-M11.08-C052-T06 · Dependency connection:** Connect the “Split-brain prevention” qualification artifact to verified control/data recovery, restored identities and stale-leader fencing; record the target identity and what the harness actually exercises.
- [ ] **UC-M11.08-C052-T07 · Resource behavior:** Account for “Contending authorities and fencing checks” in “Split-brain prevention”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M11.08-C052-T08 · Delivery check:** Run a known-valid control and a deliberately failing control for “Split-brain prevention”; confirm the harness distinguishes their observed outcomes.
- [ ] **UC-M11.08-C052-T09 · Patch review:** Review the “Split-brain prevention” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M11.08-C052-T10 · Delivery handoff:** Publish the “Split-brain prevention” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M11.08-C053 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Stale leaders and previous owners cannot commit after recovery authority changes. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M11.08-C053-T01 · Named property:** Create a stable property/check name under this parent for “Split-brain prevention”; copy its required invariant exactly: “Stale leaders and previous owners cannot commit after recovery authority changes”.
- [ ] **UC-M11.08-C053-T02 · Observable terms:** Define each term in the “Split-brain prevention” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M11.08-C053-T03 · Precondition set:** List the preconditions under which “Stale leaders and previous owners cannot commit after recovery authority changes” must hold for “Split-brain prevention”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M11.08-C053-T04 · Transition coverage:** Map the “Split-brain prevention” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M11.08-C053-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Split-brain prevention”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M11.08-C053-T06 · Satisfying fixture:** Create a concrete “Split-brain prevention” case that satisfies “Stale leaders and previous owners cannot commit after recovery authority changes”; record its expected observation before running the assertion or review.
- [ ] **UC-M11.08-C053-T07 · Violating fixture:** Create the source counterexample “A recovered old leader continues accepting writes during the drill” for “Split-brain prevention”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M11.08-C053-T08 · Enforcement evidence:** Exercise the “Split-brain prevention” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M11.08-C053-T09 · Regression linkage:** Link the “Split-brain prevention” property to changes in verified control/data recovery, restored identities and stale-leader fencing; record which dependency or contract changes require rerunning it.
- [ ] **UC-M11.08-C053-T10 · Property disposition:** Compare the satisfying and violating “Split-brain prevention” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M11.08-C054 · Integration

**Original checklist item:** Integrate split-brain prevention with verified control/data recovery, restored identities and stale-leader fencing; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M11.08-C054-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Split-brain prevention” across verified control/data recovery, restored identities and stale-leader fencing; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M11.08-C054-T02 · Field mapping:** Map every “Split-brain prevention” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M11.08-C054-T03 · Prerequisite identities:** Record the actual prerequisites for “Split-brain prevention” (source dependency list: UC-M11.04, UC-M11.06, UC-M11.07); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M11.08-C054-T04 · Ownership agreement:** Specify who owns “Split-brain prevention” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M11.08-C054-T05 · Handoff implementation:** Connect “Split-brain prevention” through the mapped seam using the real adapter or explicit specification reference; preserve “Stale leaders and previous owners cannot commit after recovery authority changes” across the handoff.
- [ ] **UC-M11.08-C054-T06 · Absent-input case:** Omit one required “Split-brain prevention” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M11.08-C054-T07 · Stale-input case:** Supply an outdated “Split-brain prevention” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M11.08-C054-T08 · Incompatible-input case:** Supply an incompatible “Split-brain prevention” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M11.08-C054-T09 · Valid integration trace:** Run a valid “Split-brain prevention” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M11.08-C054-T10 · Seam review:** Reconcile the “Split-brain prevention” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M11.08-C055 · Valid-case test

**Original checklist item:** Run a known-valid control for split-brain prevention; verify that the harness reaches its intended target and compare observed measurements or verdicts with predeclared expectations.

- [ ] **UC-M11.08-C055-T01 · Valid fixture choice:** Choose a known-valid control for “Split-brain prevention”; document why it should pass and how it proves the harness reaches the intended target.
- [ ] **UC-M11.08-C055-T02 · Expected-result oracle:** Specify the “Split-brain prevention” expected result independently of the implementation output; include the property “Stale leaders and previous owners cannot commit after recovery authority changes” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M11.08-C055-T03 · Fixture material:** Create the concrete “Split-brain prevention” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M11.08-C055-T04 · Target preparation:** Prepare the “Split-brain prevention” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M11.08-C055-T05 · Initial-state record:** Record the initial “Split-brain prevention” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M11.08-C055-T06 · Valid-path execution:** Run the “Split-brain prevention” known-valid control on the identified target; retain enough observations to prove the correct target was exercised.
- [ ] **UC-M11.08-C055-T07 · Outcome comparison:** Compare every declared “Split-brain prevention” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M11.08-C055-T08 · State and bounds check:** Inspect the “Split-brain prevention” ownership/state effects and actual use of “Contending authorities and fencing checks”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M11.08-C055-T09 · Repeatability check:** Repeat the same “Split-brain prevention” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M11.08-C055-T10 · Positive evidence:** Attach the “Split-brain prevention” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M11.08-C056 · Negative test

**Original checklist item:** Negative case: A recovered old leader continues accepting writes during the drill. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M11.08-C056-T01 · Adverse-case definition:** Create a test record for the exact “Split-brain prevention” source counterexample: “A recovered old leader continues accepting writes during the drill”; state which precondition or invariant it challenges.
- [ ] **UC-M11.08-C056-T02 · Safe fixture boundary:** Define the contained test boundary for “Split-brain prevention”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M11.08-C056-T03 · Valid control:** Construct a valid “Split-brain prevention” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M11.08-C056-T04 · Minimal adverse input:** Derive the “Split-brain prevention” adverse fixture from the control with the smallest documented change needed to reproduce “A recovered old leader continues accepting writes during the drill”; retain that change as reproducible data.
- [ ] **UC-M11.08-C056-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Split-brain prevention”; require “Stale leaders and previous owners cannot commit after recovery authority changes” and forbid a false-success verdict.
- [ ] **UC-M11.08-C056-T06 · Adverse execution:** Exercise the “Split-brain prevention” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M11.08-C056-T07 · Effect inspection:** Inspect “Split-brain prevention” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M11.08-C056-T08 · Refusal versus failure:** Confirm the “Split-brain prevention” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M11.08-C056-T09 · Reset and retention:** Restore only the disposable “Split-brain prevention” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M11.08-C056-T10 · Negative regression:** Register the “Split-brain prevention” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M11.08-C057 · Change / failure test

**Original checklist item:** Exercise split-brain prevention when controllers and selected workers are lost and restored from independently verified material; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M11.08-C057-T01 · Scenario record:** Write the “Split-brain prevention” change/failure scenario exactly as supplied: controllers and selected workers are lost and restored from independently verified material; identify the property that must remain true: “Stale leaders and previous owners cannot commit after recovery authority changes”.
- [ ] **UC-M11.08-C057-T02 · Baseline capture:** Create a known-valid “Split-brain prevention” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M11.08-C057-T03 · Injection map:** Locate the “Split-brain prevention” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M11.08-C057-T04 · Disposition oracle:** Define the legal intermediate and final “Split-brain prevention” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M11.08-C057-T05 · Controlled trigger:** Introduce the controlled “Split-brain prevention” scenario in the disposable fixture: controllers and selected workers are lost and restored from independently verified material; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M11.08-C057-T06 · Intermediate inspection:** Inspect the “Split-brain prevention” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M11.08-C057-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Split-brain prevention”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M11.08-C057-T08 · Stale-evidence cleanup:** Invalidate superseded “Split-brain prevention” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M11.08-C057-T09 · Repeat and compare:** Repeat the selected “Split-brain prevention” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M11.08-C057-T10 · Failure evidence:** Publish the “Split-brain prevention” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M11.08-C058 · Bounds

**Original checklist item:** Set a documented campaign budget for contending authorities and fencing checks; record actual consumption, incomplete coverage and the disposition when the budget is exhausted.

- [ ] **UC-M11.08-C058-T01 · Quantity inventory:** Create a measurement inventory for “Split-brain prevention”: “Contending authorities and fencing checks”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M11.08-C058-T02 · Measurement method:** Choose how to observe each “Split-brain prevention” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M11.08-C058-T03 · Budget decision:** Select justified campaign and target-resource budgets for “Split-brain prevention”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M11.08-C058-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Split-brain prevention” cases for “Contending authorities and fencing checks”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M11.08-C058-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Split-brain prevention” limit; preserve “Stale leaders and previous owners cannot commit after recovery authority changes”.
- [ ] **UC-M11.08-C058-T06 · Normal measurement:** Run or review the normal “Split-brain prevention” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M11.08-C058-T07 · At-limit measurement:** Exercise the “Split-brain prevention” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M11.08-C058-T08 · Over-limit measurement:** Exercise the “Split-brain prevention” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M11.08-C058-T09 · Uncovered-scope report:** List the “Split-brain prevention” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M11.08-C058-T10 · Limit evidence:** Publish the selected “Split-brain prevention” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M11.08-C059 · Diagnostics / review

**Original checklist item:** Report split-brain prevention results with executed, failed, skipped and unavailable cases separated; preserve the underlying observations and do not manufacture missing measurements.

- [ ] **UC-M11.08-C059-T01 · Result inventory:** Enumerate the required “Split-brain prevention” qualification cases and intended targets before aggregating results; keep the planned denominator visible.
- [ ] **UC-M11.08-C059-T02 · Verdict schema:** Define separate executed-pass, executed-fail, skipped, unavailable and untested outcomes for “Split-brain prevention”; document how incomplete cases block relevant claims.
- [ ] **UC-M11.08-C059-T03 · Identity fields:** Attach the actual target, fixture, configuration and revision identifiers to each “Split-brain prevention” result; do not attribute host-only evidence to a guest or another OS.
- [ ] **UC-M11.08-C059-T04 · Observation capture:** Capture bounded raw “Split-brain prevention” observations and harness errors; retain enough information to verify the reported oracle comparison.
- [ ] **UC-M11.08-C059-T05 · Aggregation rules:** Implement the “Split-brain prevention” count/reduction rule so failures and missing measurements cannot disappear; preserve “Stale leaders and previous owners cannot commit after recovery authority changes”.
- [ ] **UC-M11.08-C059-T06 · Failure visibility:** Feed a failing “Split-brain prevention” control through the report path; assert the exact failed case and underlying observation remain visible.
- [ ] **UC-M11.08-C059-T07 · Missing-result visibility:** Withhold a required “Split-brain prevention” measurement or target; verify the report uses unavailable/untested rather than a fabricated zero or passing value.
- [ ] **UC-M11.08-C059-T08 · Bounds and redaction:** Check “Split-brain prevention” report size and retention against “Contending authorities and fencing checks”; remove secrets while retaining fixture and subject references.
- [ ] **UC-M11.08-C059-T09 · Report reconciliation:** Reconcile the “Split-brain prevention” summary with every underlying case record; account for the full planned denominator and all omitted scope.
- [ ] **UC-M11.08-C059-T10 · Qualification handoff:** Publish the “Split-brain prevention” report with measured observations, coverage limits and blockers; state which actual targets remain unqualified.

### UC-M11.08-C060 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for split-brain prevention; label unexecuted checks as untested.

- [ ] **UC-M11.08-C060-T01 · Evidence inventory:** List the “Split-brain prevention” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M11.08-C060-T02 · Artifact references:** Record the exact “Split-brain prevention” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M11.08-C060-T03 · Fixture references:** Attach the “Split-brain prevention” fixture IDs, input identities and oracle definition; preserve the source counterexample “A recovered old leader continues accepting writes during the drill” as a distinct evidence case.
- [ ] **UC-M11.08-C060-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Split-brain prevention”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M11.08-C060-T05 · Environment record:** Record the actual “Split-brain prevention” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M11.08-C060-T06 · Expected versus observed:** Pair every “Split-brain prevention” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M11.08-C060-T07 · Failure and limit records:** Attach “Split-brain prevention” change/failure and bounds evidence where required; include uncovered “Contending authorities and fencing checks” and unresolved violations of “Stale leaders and previous owners cannot commit after recovery authority changes”.
- [ ] **UC-M11.08-C060-T08 · Evidence hygiene:** Check the “Split-brain prevention” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M11.08-C060-T09 · Reproduction review:** Have the “Split-brain prevention” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M11.08-C060-T10 · Acceptance linkage:** Link the “Split-brain prevention” evidence to its parent and UC-M11.08 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 07. Trust and metadata recovery

**Source delivery:** Restore approved trust anchors and update metadata without implicit enrollment.

**Source invariant:** Lost metadata does not justify unsigned replacement artifacts.

**Source negative case:** An emergency package bypasses signature and anti-rollback checks.

**Source bounded quantities:** Trust records and metadata versions.

### UC-M11.08-C061 · Contract

**Original checklist item:** Define the qualification objective for trust and metadata recovery, including the actual target implementation, prerequisites, observable oracle and explicit exclusions.

- [ ] **UC-M11.08-C061-T01 · Scope statement:** Write the qualification question for “Trust and metadata recovery”; identify the actual target, claimed capability and observations that can answer that question.
- [ ] **UC-M11.08-C061-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Trust and metadata recovery”; record each producer, representation and missing-value meaning.
- [ ] **UC-M11.08-C061-T03 · Output inventory:** List the outputs of “Trust and metadata recovery” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M11.08-C061-T04 · Field dictionary:** Create a field-and-term dictionary for “Trust and metadata recovery”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M11.08-C061-T05 · Prerequisite contract:** Map “Trust and metadata recovery” to the source component prerequisites (UC-M11.04, UC-M11.06, UC-M11.07); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M11.08-C061-T06 · Authority map:** Identify who may produce, change and consume “Trust and metadata recovery”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M11.08-C061-T07 · Invariant clause:** Add a normative clause for “Trust and metadata recovery” that preserves “Lost metadata does not justify unsigned replacement artifacts”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M11.08-C061-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Trust and metadata recovery”; include the source counterexample “An emergency package bypasses signature and anti-rollback checks” and the intended safe disposition.
- [ ] **UC-M11.08-C061-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Trust records and metadata versions” in the “Trust and metadata recovery” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M11.08-C061-T10 · Contract review:** Review the “Trust and metadata recovery” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M11.08-C062 · Delivery

**Original checklist item:** Restore approved trust anchors and update metadata without implicit enrollment.

- [ ] **UC-M11.08-C062-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Trust and metadata recovery”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M11.08-C062-T02 · Change plan:** Break the source delivery for “Trust and metadata recovery” into concrete edit targets and reviewable outputs; keep the UC-M11.08 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M11.08-C062-T03 · Core artifact:** Implement the smallest selected-profile change for “Trust and metadata recovery” that realizes this source instruction: Restore approved trust anchors and update metadata without implicit enrollment.
- [ ] **UC-M11.08-C062-T04 · Concrete realization:** Trace “Trust and metadata recovery” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M11.08-C062-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Trust and metadata recovery” needed to preserve “Lost metadata does not justify unsigned replacement artifacts”; record an enforcement gap where only a model exists.
- [ ] **UC-M11.08-C062-T06 · Dependency connection:** Connect the “Trust and metadata recovery” qualification artifact to verified control/data recovery, restored identities and stale-leader fencing; record the target identity and what the harness actually exercises.
- [ ] **UC-M11.08-C062-T07 · Resource behavior:** Account for “Trust records and metadata versions” in “Trust and metadata recovery”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M11.08-C062-T08 · Delivery check:** Run a known-valid control and a deliberately failing control for “Trust and metadata recovery”; confirm the harness distinguishes their observed outcomes.
- [ ] **UC-M11.08-C062-T09 · Patch review:** Review the “Trust and metadata recovery” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M11.08-C062-T10 · Delivery handoff:** Publish the “Trust and metadata recovery” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M11.08-C063 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Lost metadata does not justify unsigned replacement artifacts. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M11.08-C063-T01 · Named property:** Create a stable property/check name under this parent for “Trust and metadata recovery”; copy its required invariant exactly: “Lost metadata does not justify unsigned replacement artifacts”.
- [ ] **UC-M11.08-C063-T02 · Observable terms:** Define each term in the “Trust and metadata recovery” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M11.08-C063-T03 · Precondition set:** List the preconditions under which “Lost metadata does not justify unsigned replacement artifacts” must hold for “Trust and metadata recovery”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M11.08-C063-T04 · Transition coverage:** Map the “Trust and metadata recovery” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M11.08-C063-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Trust and metadata recovery”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M11.08-C063-T06 · Satisfying fixture:** Create a concrete “Trust and metadata recovery” case that satisfies “Lost metadata does not justify unsigned replacement artifacts”; record its expected observation before running the assertion or review.
- [ ] **UC-M11.08-C063-T07 · Violating fixture:** Create the source counterexample “An emergency package bypasses signature and anti-rollback checks” for “Trust and metadata recovery”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M11.08-C063-T08 · Enforcement evidence:** Exercise the “Trust and metadata recovery” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M11.08-C063-T09 · Regression linkage:** Link the “Trust and metadata recovery” property to changes in verified control/data recovery, restored identities and stale-leader fencing; record which dependency or contract changes require rerunning it.
- [ ] **UC-M11.08-C063-T10 · Property disposition:** Compare the satisfying and violating “Trust and metadata recovery” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M11.08-C064 · Integration

**Original checklist item:** Integrate trust and metadata recovery with verified control/data recovery, restored identities and stale-leader fencing; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M11.08-C064-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Trust and metadata recovery” across verified control/data recovery, restored identities and stale-leader fencing; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M11.08-C064-T02 · Field mapping:** Map every “Trust and metadata recovery” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M11.08-C064-T03 · Prerequisite identities:** Record the actual prerequisites for “Trust and metadata recovery” (source dependency list: UC-M11.04, UC-M11.06, UC-M11.07); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M11.08-C064-T04 · Ownership agreement:** Specify who owns “Trust and metadata recovery” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M11.08-C064-T05 · Handoff implementation:** Connect “Trust and metadata recovery” through the mapped seam using the real adapter or explicit specification reference; preserve “Lost metadata does not justify unsigned replacement artifacts” across the handoff.
- [ ] **UC-M11.08-C064-T06 · Absent-input case:** Omit one required “Trust and metadata recovery” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M11.08-C064-T07 · Stale-input case:** Supply an outdated “Trust and metadata recovery” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M11.08-C064-T08 · Incompatible-input case:** Supply an incompatible “Trust and metadata recovery” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M11.08-C064-T09 · Valid integration trace:** Run a valid “Trust and metadata recovery” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M11.08-C064-T10 · Seam review:** Reconcile the “Trust and metadata recovery” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M11.08-C065 · Valid-case test

**Original checklist item:** Run a known-valid control for trust and metadata recovery; verify that the harness reaches its intended target and compare observed measurements or verdicts with predeclared expectations.

- [ ] **UC-M11.08-C065-T01 · Valid fixture choice:** Choose a known-valid control for “Trust and metadata recovery”; document why it should pass and how it proves the harness reaches the intended target.
- [ ] **UC-M11.08-C065-T02 · Expected-result oracle:** Specify the “Trust and metadata recovery” expected result independently of the implementation output; include the property “Lost metadata does not justify unsigned replacement artifacts” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M11.08-C065-T03 · Fixture material:** Create the concrete “Trust and metadata recovery” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M11.08-C065-T04 · Target preparation:** Prepare the “Trust and metadata recovery” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M11.08-C065-T05 · Initial-state record:** Record the initial “Trust and metadata recovery” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M11.08-C065-T06 · Valid-path execution:** Run the “Trust and metadata recovery” known-valid control on the identified target; retain enough observations to prove the correct target was exercised.
- [ ] **UC-M11.08-C065-T07 · Outcome comparison:** Compare every declared “Trust and metadata recovery” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M11.08-C065-T08 · State and bounds check:** Inspect the “Trust and metadata recovery” ownership/state effects and actual use of “Trust records and metadata versions”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M11.08-C065-T09 · Repeatability check:** Repeat the same “Trust and metadata recovery” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M11.08-C065-T10 · Positive evidence:** Attach the “Trust and metadata recovery” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M11.08-C066 · Negative test

**Original checklist item:** Negative case: An emergency package bypasses signature and anti-rollback checks. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M11.08-C066-T01 · Adverse-case definition:** Create a test record for the exact “Trust and metadata recovery” source counterexample: “An emergency package bypasses signature and anti-rollback checks”; state which precondition or invariant it challenges.
- [ ] **UC-M11.08-C066-T02 · Safe fixture boundary:** Define the contained test boundary for “Trust and metadata recovery”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M11.08-C066-T03 · Valid control:** Construct a valid “Trust and metadata recovery” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M11.08-C066-T04 · Minimal adverse input:** Derive the “Trust and metadata recovery” adverse fixture from the control with the smallest documented change needed to reproduce “An emergency package bypasses signature and anti-rollback checks”; retain that change as reproducible data.
- [ ] **UC-M11.08-C066-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Trust and metadata recovery”; require “Lost metadata does not justify unsigned replacement artifacts” and forbid a false-success verdict.
- [ ] **UC-M11.08-C066-T06 · Adverse execution:** Exercise the “Trust and metadata recovery” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M11.08-C066-T07 · Effect inspection:** Inspect “Trust and metadata recovery” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M11.08-C066-T08 · Refusal versus failure:** Confirm the “Trust and metadata recovery” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M11.08-C066-T09 · Reset and retention:** Restore only the disposable “Trust and metadata recovery” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M11.08-C066-T10 · Negative regression:** Register the “Trust and metadata recovery” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M11.08-C067 · Change / failure test

**Original checklist item:** Exercise trust and metadata recovery when controllers and selected workers are lost and restored from independently verified material; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M11.08-C067-T01 · Scenario record:** Write the “Trust and metadata recovery” change/failure scenario exactly as supplied: controllers and selected workers are lost and restored from independently verified material; identify the property that must remain true: “Lost metadata does not justify unsigned replacement artifacts”.
- [ ] **UC-M11.08-C067-T02 · Baseline capture:** Create a known-valid “Trust and metadata recovery” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M11.08-C067-T03 · Injection map:** Locate the “Trust and metadata recovery” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M11.08-C067-T04 · Disposition oracle:** Define the legal intermediate and final “Trust and metadata recovery” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M11.08-C067-T05 · Controlled trigger:** Introduce the controlled “Trust and metadata recovery” scenario in the disposable fixture: controllers and selected workers are lost and restored from independently verified material; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M11.08-C067-T06 · Intermediate inspection:** Inspect the “Trust and metadata recovery” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M11.08-C067-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Trust and metadata recovery”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M11.08-C067-T08 · Stale-evidence cleanup:** Invalidate superseded “Trust and metadata recovery” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M11.08-C067-T09 · Repeat and compare:** Repeat the selected “Trust and metadata recovery” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M11.08-C067-T10 · Failure evidence:** Publish the “Trust and metadata recovery” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M11.08-C068 · Bounds

**Original checklist item:** Set a documented campaign budget for trust records and metadata versions; record actual consumption, incomplete coverage and the disposition when the budget is exhausted.

- [ ] **UC-M11.08-C068-T01 · Quantity inventory:** Create a measurement inventory for “Trust and metadata recovery”: “Trust records and metadata versions”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M11.08-C068-T02 · Measurement method:** Choose how to observe each “Trust and metadata recovery” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M11.08-C068-T03 · Budget decision:** Select justified campaign and target-resource budgets for “Trust and metadata recovery”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M11.08-C068-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Trust and metadata recovery” cases for “Trust records and metadata versions”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M11.08-C068-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Trust and metadata recovery” limit; preserve “Lost metadata does not justify unsigned replacement artifacts”.
- [ ] **UC-M11.08-C068-T06 · Normal measurement:** Run or review the normal “Trust and metadata recovery” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M11.08-C068-T07 · At-limit measurement:** Exercise the “Trust and metadata recovery” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M11.08-C068-T08 · Over-limit measurement:** Exercise the “Trust and metadata recovery” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M11.08-C068-T09 · Uncovered-scope report:** List the “Trust and metadata recovery” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M11.08-C068-T10 · Limit evidence:** Publish the selected “Trust and metadata recovery” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M11.08-C069 · Diagnostics / review

**Original checklist item:** Report trust and metadata recovery results with executed, failed, skipped and unavailable cases separated; preserve the underlying observations and do not manufacture missing measurements.

- [ ] **UC-M11.08-C069-T01 · Result inventory:** Enumerate the required “Trust and metadata recovery” qualification cases and intended targets before aggregating results; keep the planned denominator visible.
- [ ] **UC-M11.08-C069-T02 · Verdict schema:** Define separate executed-pass, executed-fail, skipped, unavailable and untested outcomes for “Trust and metadata recovery”; document how incomplete cases block relevant claims.
- [ ] **UC-M11.08-C069-T03 · Identity fields:** Attach the actual target, fixture, configuration and revision identifiers to each “Trust and metadata recovery” result; do not attribute host-only evidence to a guest or another OS.
- [ ] **UC-M11.08-C069-T04 · Observation capture:** Capture bounded raw “Trust and metadata recovery” observations and harness errors; retain enough information to verify the reported oracle comparison.
- [ ] **UC-M11.08-C069-T05 · Aggregation rules:** Implement the “Trust and metadata recovery” count/reduction rule so failures and missing measurements cannot disappear; preserve “Lost metadata does not justify unsigned replacement artifacts”.
- [ ] **UC-M11.08-C069-T06 · Failure visibility:** Feed a failing “Trust and metadata recovery” control through the report path; assert the exact failed case and underlying observation remain visible.
- [ ] **UC-M11.08-C069-T07 · Missing-result visibility:** Withhold a required “Trust and metadata recovery” measurement or target; verify the report uses unavailable/untested rather than a fabricated zero or passing value.
- [ ] **UC-M11.08-C069-T08 · Bounds and redaction:** Check “Trust and metadata recovery” report size and retention against “Trust records and metadata versions”; remove secrets while retaining fixture and subject references.
- [ ] **UC-M11.08-C069-T09 · Report reconciliation:** Reconcile the “Trust and metadata recovery” summary with every underlying case record; account for the full planned denominator and all omitted scope.
- [ ] **UC-M11.08-C069-T10 · Qualification handoff:** Publish the “Trust and metadata recovery” report with measured observations, coverage limits and blockers; state which actual targets remain unqualified.

### UC-M11.08-C070 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for trust and metadata recovery; label unexecuted checks as untested.

- [ ] **UC-M11.08-C070-T01 · Evidence inventory:** List the “Trust and metadata recovery” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M11.08-C070-T02 · Artifact references:** Record the exact “Trust and metadata recovery” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M11.08-C070-T03 · Fixture references:** Attach the “Trust and metadata recovery” fixture IDs, input identities and oracle definition; preserve the source counterexample “An emergency package bypasses signature and anti-rollback checks” as a distinct evidence case.
- [ ] **UC-M11.08-C070-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Trust and metadata recovery”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M11.08-C070-T05 · Environment record:** Record the actual “Trust and metadata recovery” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M11.08-C070-T06 · Expected versus observed:** Pair every “Trust and metadata recovery” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M11.08-C070-T07 · Failure and limit records:** Attach “Trust and metadata recovery” change/failure and bounds evidence where required; include uncovered “Trust records and metadata versions” and unresolved violations of “Lost metadata does not justify unsigned replacement artifacts”.
- [ ] **UC-M11.08-C070-T08 · Evidence hygiene:** Check the “Trust and metadata recovery” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M11.08-C070-T09 · Reproduction review:** Have the “Trust and metadata recovery” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M11.08-C070-T10 · Acceptance linkage:** Link the “Trust and metadata recovery” evidence to its parent and UC-M11.08 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 08. Measured drill execution

**Source delivery:** Record actual timeline, failures and recovery outcomes on the declared topology.

**Source invariant:** Measured results include failed attempts and unavailable components.

**Source negative case:** The published duration omits unsuccessful restoration attempts.

**Source bounded quantities:** Observation duration and event count.

### UC-M11.08-C071 · Contract

**Original checklist item:** Define the qualification objective for measured drill execution, including the actual target implementation, prerequisites, observable oracle and explicit exclusions.

- [ ] **UC-M11.08-C071-T01 · Scope statement:** Write the qualification question for “Measured drill execution”; identify the actual target, claimed capability and observations that can answer that question.
- [ ] **UC-M11.08-C071-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Measured drill execution”; record each producer, representation and missing-value meaning.
- [ ] **UC-M11.08-C071-T03 · Output inventory:** List the outputs of “Measured drill execution” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M11.08-C071-T04 · Field dictionary:** Create a field-and-term dictionary for “Measured drill execution”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M11.08-C071-T05 · Prerequisite contract:** Map “Measured drill execution” to the source component prerequisites (UC-M11.04, UC-M11.06, UC-M11.07); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M11.08-C071-T06 · Authority map:** Identify who may produce, change and consume “Measured drill execution”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M11.08-C071-T07 · Invariant clause:** Add a normative clause for “Measured drill execution” that preserves “Measured results include failed attempts and unavailable components”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M11.08-C071-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Measured drill execution”; include the source counterexample “The published duration omits unsuccessful restoration attempts” and the intended safe disposition.
- [ ] **UC-M11.08-C071-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Observation duration and event count” in the “Measured drill execution” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M11.08-C071-T10 · Contract review:** Review the “Measured drill execution” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M11.08-C072 · Delivery

**Original checklist item:** Record actual timeline, failures and recovery outcomes on the declared topology.

- [ ] **UC-M11.08-C072-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Measured drill execution”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M11.08-C072-T02 · Change plan:** Break the source delivery for “Measured drill execution” into concrete edit targets and reviewable outputs; keep the UC-M11.08 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M11.08-C072-T03 · Core artifact:** Create the “Measured drill execution” model, schema or inventory that realizes this source instruction: Record actual timeline, failures and recovery outcomes on the declared topology.
- [ ] **UC-M11.08-C072-T04 · Concrete realization:** Populate “Measured drill execution” with one concrete worked case; map every required entity or field to its source and flag any unmapped entry.
- [ ] **UC-M11.08-C072-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Measured drill execution” needed to preserve “Measured results include failed attempts and unavailable components”; record an enforcement gap where only a model exists.
- [ ] **UC-M11.08-C072-T06 · Dependency connection:** Connect the “Measured drill execution” qualification artifact to verified control/data recovery, restored identities and stale-leader fencing; record the target identity and what the harness actually exercises.
- [ ] **UC-M11.08-C072-T07 · Resource behavior:** Account for “Observation duration and event count” in “Measured drill execution”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M11.08-C072-T08 · Delivery check:** Run a known-valid control and a deliberately failing control for “Measured drill execution”; confirm the harness distinguishes their observed outcomes.
- [ ] **UC-M11.08-C072-T09 · Patch review:** Review the “Measured drill execution” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M11.08-C072-T10 · Delivery handoff:** Publish the “Measured drill execution” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M11.08-C073 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Measured results include failed attempts and unavailable components. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M11.08-C073-T01 · Named property:** Create a stable property/check name under this parent for “Measured drill execution”; copy its required invariant exactly: “Measured results include failed attempts and unavailable components”.
- [ ] **UC-M11.08-C073-T02 · Observable terms:** Define each term in the “Measured drill execution” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M11.08-C073-T03 · Precondition set:** List the preconditions under which “Measured results include failed attempts and unavailable components” must hold for “Measured drill execution”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M11.08-C073-T04 · Transition coverage:** Map the “Measured drill execution” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M11.08-C073-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Measured drill execution”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M11.08-C073-T06 · Satisfying fixture:** Create a concrete “Measured drill execution” case that satisfies “Measured results include failed attempts and unavailable components”; record its expected observation before running the assertion or review.
- [ ] **UC-M11.08-C073-T07 · Violating fixture:** Create the source counterexample “The published duration omits unsuccessful restoration attempts” for “Measured drill execution”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M11.08-C073-T08 · Enforcement evidence:** Exercise the “Measured drill execution” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M11.08-C073-T09 · Regression linkage:** Link the “Measured drill execution” property to changes in verified control/data recovery, restored identities and stale-leader fencing; record which dependency or contract changes require rerunning it.
- [ ] **UC-M11.08-C073-T10 · Property disposition:** Compare the satisfying and violating “Measured drill execution” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M11.08-C074 · Integration

**Original checklist item:** Integrate measured drill execution with verified control/data recovery, restored identities and stale-leader fencing; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M11.08-C074-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Measured drill execution” across verified control/data recovery, restored identities and stale-leader fencing; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M11.08-C074-T02 · Field mapping:** Map every “Measured drill execution” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M11.08-C074-T03 · Prerequisite identities:** Record the actual prerequisites for “Measured drill execution” (source dependency list: UC-M11.04, UC-M11.06, UC-M11.07); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M11.08-C074-T04 · Ownership agreement:** Specify who owns “Measured drill execution” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M11.08-C074-T05 · Handoff implementation:** Connect “Measured drill execution” through the mapped seam using the real adapter or explicit specification reference; preserve “Measured results include failed attempts and unavailable components” across the handoff.
- [ ] **UC-M11.08-C074-T06 · Absent-input case:** Omit one required “Measured drill execution” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M11.08-C074-T07 · Stale-input case:** Supply an outdated “Measured drill execution” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M11.08-C074-T08 · Incompatible-input case:** Supply an incompatible “Measured drill execution” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M11.08-C074-T09 · Valid integration trace:** Run a valid “Measured drill execution” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M11.08-C074-T10 · Seam review:** Reconcile the “Measured drill execution” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M11.08-C075 · Valid-case test

**Original checklist item:** Run a known-valid control for measured drill execution; verify that the harness reaches its intended target and compare observed measurements or verdicts with predeclared expectations.

- [ ] **UC-M11.08-C075-T01 · Valid fixture choice:** Choose a known-valid control for “Measured drill execution”; document why it should pass and how it proves the harness reaches the intended target.
- [ ] **UC-M11.08-C075-T02 · Expected-result oracle:** Specify the “Measured drill execution” expected result independently of the implementation output; include the property “Measured results include failed attempts and unavailable components” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M11.08-C075-T03 · Fixture material:** Create the concrete “Measured drill execution” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M11.08-C075-T04 · Target preparation:** Prepare the “Measured drill execution” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M11.08-C075-T05 · Initial-state record:** Record the initial “Measured drill execution” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M11.08-C075-T06 · Valid-path execution:** Run the “Measured drill execution” known-valid control on the identified target; retain enough observations to prove the correct target was exercised.
- [ ] **UC-M11.08-C075-T07 · Outcome comparison:** Compare every declared “Measured drill execution” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M11.08-C075-T08 · State and bounds check:** Inspect the “Measured drill execution” ownership/state effects and actual use of “Observation duration and event count”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M11.08-C075-T09 · Repeatability check:** Repeat the same “Measured drill execution” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M11.08-C075-T10 · Positive evidence:** Attach the “Measured drill execution” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M11.08-C076 · Negative test

**Original checklist item:** Negative case: The published duration omits unsuccessful restoration attempts. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M11.08-C076-T01 · Adverse-case definition:** Create a test record for the exact “Measured drill execution” source counterexample: “The published duration omits unsuccessful restoration attempts”; state which precondition or invariant it challenges.
- [ ] **UC-M11.08-C076-T02 · Safe fixture boundary:** Define the contained test boundary for “Measured drill execution”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M11.08-C076-T03 · Valid control:** Construct a valid “Measured drill execution” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M11.08-C076-T04 · Minimal adverse input:** Derive the “Measured drill execution” adverse fixture from the control with the smallest documented change needed to reproduce “The published duration omits unsuccessful restoration attempts”; retain that change as reproducible data.
- [ ] **UC-M11.08-C076-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Measured drill execution”; require “Measured results include failed attempts and unavailable components” and forbid a false-success verdict.
- [ ] **UC-M11.08-C076-T06 · Adverse execution:** Exercise the “Measured drill execution” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M11.08-C076-T07 · Effect inspection:** Inspect “Measured drill execution” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M11.08-C076-T08 · Refusal versus failure:** Confirm the “Measured drill execution” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M11.08-C076-T09 · Reset and retention:** Restore only the disposable “Measured drill execution” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M11.08-C076-T10 · Negative regression:** Register the “Measured drill execution” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M11.08-C077 · Change / failure test

**Original checklist item:** Exercise measured drill execution when controllers and selected workers are lost and restored from independently verified material; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M11.08-C077-T01 · Scenario record:** Write the “Measured drill execution” change/failure scenario exactly as supplied: controllers and selected workers are lost and restored from independently verified material; identify the property that must remain true: “Measured results include failed attempts and unavailable components”.
- [ ] **UC-M11.08-C077-T02 · Baseline capture:** Create a known-valid “Measured drill execution” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M11.08-C077-T03 · Injection map:** Locate the “Measured drill execution” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M11.08-C077-T04 · Disposition oracle:** Define the legal intermediate and final “Measured drill execution” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M11.08-C077-T05 · Controlled trigger:** Introduce the controlled “Measured drill execution” scenario in the disposable fixture: controllers and selected workers are lost and restored from independently verified material; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M11.08-C077-T06 · Intermediate inspection:** Inspect the “Measured drill execution” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M11.08-C077-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Measured drill execution”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M11.08-C077-T08 · Stale-evidence cleanup:** Invalidate superseded “Measured drill execution” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M11.08-C077-T09 · Repeat and compare:** Repeat the selected “Measured drill execution” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M11.08-C077-T10 · Failure evidence:** Publish the “Measured drill execution” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M11.08-C078 · Bounds

**Original checklist item:** Set a documented campaign budget for observation duration and event count; record actual consumption, incomplete coverage and the disposition when the budget is exhausted.

- [ ] **UC-M11.08-C078-T01 · Quantity inventory:** Create a measurement inventory for “Measured drill execution”: “Observation duration and event count”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M11.08-C078-T02 · Measurement method:** Choose how to observe each “Measured drill execution” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M11.08-C078-T03 · Budget decision:** Select justified campaign and target-resource budgets for “Measured drill execution”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M11.08-C078-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Measured drill execution” cases for “Observation duration and event count”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M11.08-C078-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Measured drill execution” limit; preserve “Measured results include failed attempts and unavailable components”.
- [ ] **UC-M11.08-C078-T06 · Normal measurement:** Run or review the normal “Measured drill execution” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M11.08-C078-T07 · At-limit measurement:** Exercise the “Measured drill execution” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M11.08-C078-T08 · Over-limit measurement:** Exercise the “Measured drill execution” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M11.08-C078-T09 · Uncovered-scope report:** List the “Measured drill execution” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M11.08-C078-T10 · Limit evidence:** Publish the selected “Measured drill execution” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M11.08-C079 · Diagnostics / review

**Original checklist item:** Report measured drill execution results with executed, failed, skipped and unavailable cases separated; preserve the underlying observations and do not manufacture missing measurements.

- [ ] **UC-M11.08-C079-T01 · Result inventory:** Enumerate the required “Measured drill execution” qualification cases and intended targets before aggregating results; keep the planned denominator visible.
- [ ] **UC-M11.08-C079-T02 · Verdict schema:** Define separate executed-pass, executed-fail, skipped, unavailable and untested outcomes for “Measured drill execution”; document how incomplete cases block relevant claims.
- [ ] **UC-M11.08-C079-T03 · Identity fields:** Attach the actual target, fixture, configuration and revision identifiers to each “Measured drill execution” result; do not attribute host-only evidence to a guest or another OS.
- [ ] **UC-M11.08-C079-T04 · Observation capture:** Capture bounded raw “Measured drill execution” observations and harness errors; retain enough information to verify the reported oracle comparison.
- [ ] **UC-M11.08-C079-T05 · Aggregation rules:** Implement the “Measured drill execution” count/reduction rule so failures and missing measurements cannot disappear; preserve “Measured results include failed attempts and unavailable components”.
- [ ] **UC-M11.08-C079-T06 · Failure visibility:** Feed a failing “Measured drill execution” control through the report path; assert the exact failed case and underlying observation remain visible.
- [ ] **UC-M11.08-C079-T07 · Missing-result visibility:** Withhold a required “Measured drill execution” measurement or target; verify the report uses unavailable/untested rather than a fabricated zero or passing value.
- [ ] **UC-M11.08-C079-T08 · Bounds and redaction:** Check “Measured drill execution” report size and retention against “Observation duration and event count”; remove secrets while retaining fixture and subject references.
- [ ] **UC-M11.08-C079-T09 · Report reconciliation:** Reconcile the “Measured drill execution” summary with every underlying case record; account for the full planned denominator and all omitted scope.
- [ ] **UC-M11.08-C079-T10 · Qualification handoff:** Publish the “Measured drill execution” report with measured observations, coverage limits and blockers; state which actual targets remain unqualified.

### UC-M11.08-C080 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for measured drill execution; label unexecuted checks as untested.

- [ ] **UC-M11.08-C080-T01 · Evidence inventory:** List the “Measured drill execution” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M11.08-C080-T02 · Artifact references:** Record the exact “Measured drill execution” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M11.08-C080-T03 · Fixture references:** Attach the “Measured drill execution” fixture IDs, input identities and oracle definition; preserve the source counterexample “The published duration omits unsuccessful restoration attempts” as a distinct evidence case.
- [ ] **UC-M11.08-C080-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Measured drill execution”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M11.08-C080-T05 · Environment record:** Record the actual “Measured drill execution” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M11.08-C080-T06 · Expected versus observed:** Pair every “Measured drill execution” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M11.08-C080-T07 · Failure and limit records:** Attach “Measured drill execution” change/failure and bounds evidence where required; include uncovered “Observation duration and event count” and unresolved violations of “Measured results include failed attempts and unavailable components”.
- [ ] **UC-M11.08-C080-T08 · Evidence hygiene:** Check the “Measured drill execution” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M11.08-C080-T09 · Reproduction review:** Have the “Measured drill execution” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M11.08-C080-T10 · Acceptance linkage:** Link the “Measured drill execution” evidence to its parent and UC-M11.08 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 09. Objective evaluation

**Source delivery:** Compare observed data and timing outcomes with chosen recovery objectives.

**Source invariant:** A missed objective remains an explicit qualification failure.

**Source negative case:** A drill exceeds the objective but is reported as passed without qualification.

**Source bounded quantities:** Evaluation records and workload scenarios.

### UC-M11.08-C081 · Contract

**Original checklist item:** Define the qualification objective for objective evaluation, including the actual target implementation, prerequisites, observable oracle and explicit exclusions.

- [ ] **UC-M11.08-C081-T01 · Scope statement:** Write the qualification question for “Objective evaluation”; identify the actual target, claimed capability and observations that can answer that question.
- [ ] **UC-M11.08-C081-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Objective evaluation”; record each producer, representation and missing-value meaning.
- [ ] **UC-M11.08-C081-T03 · Output inventory:** List the outputs of “Objective evaluation” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M11.08-C081-T04 · Field dictionary:** Create a field-and-term dictionary for “Objective evaluation”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M11.08-C081-T05 · Prerequisite contract:** Map “Objective evaluation” to the source component prerequisites (UC-M11.04, UC-M11.06, UC-M11.07); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M11.08-C081-T06 · Authority map:** Identify who may produce, change and consume “Objective evaluation”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M11.08-C081-T07 · Invariant clause:** Add a normative clause for “Objective evaluation” that preserves “A missed objective remains an explicit qualification failure”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M11.08-C081-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Objective evaluation”; include the source counterexample “A drill exceeds the objective but is reported as passed without qualification” and the intended safe disposition.
- [ ] **UC-M11.08-C081-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Evaluation records and workload scenarios” in the “Objective evaluation” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M11.08-C081-T10 · Contract review:** Review the “Objective evaluation” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M11.08-C082 · Delivery

**Original checklist item:** Compare observed data and timing outcomes with chosen recovery objectives.

- [ ] **UC-M11.08-C082-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Objective evaluation”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M11.08-C082-T02 · Change plan:** Break the source delivery for “Objective evaluation” into concrete edit targets and reviewable outputs; keep the UC-M11.08 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M11.08-C082-T03 · Core artifact:** Create the “Objective evaluation” fixture or harness for this source instruction: Compare observed data and timing outcomes with chosen recovery objectives.
- [ ] **UC-M11.08-C082-T04 · Concrete realization:** Connect the “Objective evaluation” harness to its actual intended target, set the expected oracle before running it, and distinguish a mock/control run from a target run.
- [ ] **UC-M11.08-C082-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Objective evaluation” needed to preserve “A missed objective remains an explicit qualification failure”; record an enforcement gap where only a model exists.
- [ ] **UC-M11.08-C082-T06 · Dependency connection:** Connect the “Objective evaluation” qualification artifact to verified control/data recovery, restored identities and stale-leader fencing; record the target identity and what the harness actually exercises.
- [ ] **UC-M11.08-C082-T07 · Resource behavior:** Account for “Evaluation records and workload scenarios” in “Objective evaluation”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M11.08-C082-T08 · Delivery check:** Run a known-valid control and a deliberately failing control for “Objective evaluation”; confirm the harness distinguishes their observed outcomes.
- [ ] **UC-M11.08-C082-T09 · Patch review:** Review the “Objective evaluation” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M11.08-C082-T10 · Delivery handoff:** Publish the “Objective evaluation” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M11.08-C083 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: A missed objective remains an explicit qualification failure. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M11.08-C083-T01 · Named property:** Create a stable property/check name under this parent for “Objective evaluation”; copy its required invariant exactly: “A missed objective remains an explicit qualification failure”.
- [ ] **UC-M11.08-C083-T02 · Observable terms:** Define each term in the “Objective evaluation” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M11.08-C083-T03 · Precondition set:** List the preconditions under which “A missed objective remains an explicit qualification failure” must hold for “Objective evaluation”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M11.08-C083-T04 · Transition coverage:** Map the “Objective evaluation” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M11.08-C083-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Objective evaluation”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M11.08-C083-T06 · Satisfying fixture:** Create a concrete “Objective evaluation” case that satisfies “A missed objective remains an explicit qualification failure”; record its expected observation before running the assertion or review.
- [ ] **UC-M11.08-C083-T07 · Violating fixture:** Create the source counterexample “A drill exceeds the objective but is reported as passed without qualification” for “Objective evaluation”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M11.08-C083-T08 · Enforcement evidence:** Exercise the “Objective evaluation” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M11.08-C083-T09 · Regression linkage:** Link the “Objective evaluation” property to changes in verified control/data recovery, restored identities and stale-leader fencing; record which dependency or contract changes require rerunning it.
- [ ] **UC-M11.08-C083-T10 · Property disposition:** Compare the satisfying and violating “Objective evaluation” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M11.08-C084 · Integration

**Original checklist item:** Integrate objective evaluation with verified control/data recovery, restored identities and stale-leader fencing; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M11.08-C084-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Objective evaluation” across verified control/data recovery, restored identities and stale-leader fencing; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M11.08-C084-T02 · Field mapping:** Map every “Objective evaluation” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M11.08-C084-T03 · Prerequisite identities:** Record the actual prerequisites for “Objective evaluation” (source dependency list: UC-M11.04, UC-M11.06, UC-M11.07); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M11.08-C084-T04 · Ownership agreement:** Specify who owns “Objective evaluation” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M11.08-C084-T05 · Handoff implementation:** Connect “Objective evaluation” through the mapped seam using the real adapter or explicit specification reference; preserve “A missed objective remains an explicit qualification failure” across the handoff.
- [ ] **UC-M11.08-C084-T06 · Absent-input case:** Omit one required “Objective evaluation” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M11.08-C084-T07 · Stale-input case:** Supply an outdated “Objective evaluation” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M11.08-C084-T08 · Incompatible-input case:** Supply an incompatible “Objective evaluation” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M11.08-C084-T09 · Valid integration trace:** Run a valid “Objective evaluation” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M11.08-C084-T10 · Seam review:** Reconcile the “Objective evaluation” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M11.08-C085 · Valid-case test

**Original checklist item:** Run a known-valid control for objective evaluation; verify that the harness reaches its intended target and compare observed measurements or verdicts with predeclared expectations.

- [ ] **UC-M11.08-C085-T01 · Valid fixture choice:** Choose a known-valid control for “Objective evaluation”; document why it should pass and how it proves the harness reaches the intended target.
- [ ] **UC-M11.08-C085-T02 · Expected-result oracle:** Specify the “Objective evaluation” expected result independently of the implementation output; include the property “A missed objective remains an explicit qualification failure” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M11.08-C085-T03 · Fixture material:** Create the concrete “Objective evaluation” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M11.08-C085-T04 · Target preparation:** Prepare the “Objective evaluation” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M11.08-C085-T05 · Initial-state record:** Record the initial “Objective evaluation” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M11.08-C085-T06 · Valid-path execution:** Run the “Objective evaluation” known-valid control on the identified target; retain enough observations to prove the correct target was exercised.
- [ ] **UC-M11.08-C085-T07 · Outcome comparison:** Compare every declared “Objective evaluation” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M11.08-C085-T08 · State and bounds check:** Inspect the “Objective evaluation” ownership/state effects and actual use of “Evaluation records and workload scenarios”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M11.08-C085-T09 · Repeatability check:** Repeat the same “Objective evaluation” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M11.08-C085-T10 · Positive evidence:** Attach the “Objective evaluation” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M11.08-C086 · Negative test

**Original checklist item:** Negative case: A drill exceeds the objective but is reported as passed without qualification. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M11.08-C086-T01 · Adverse-case definition:** Create a test record for the exact “Objective evaluation” source counterexample: “A drill exceeds the objective but is reported as passed without qualification”; state which precondition or invariant it challenges.
- [ ] **UC-M11.08-C086-T02 · Safe fixture boundary:** Define the contained test boundary for “Objective evaluation”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M11.08-C086-T03 · Valid control:** Construct a valid “Objective evaluation” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M11.08-C086-T04 · Minimal adverse input:** Derive the “Objective evaluation” adverse fixture from the control with the smallest documented change needed to reproduce “A drill exceeds the objective but is reported as passed without qualification”; retain that change as reproducible data.
- [ ] **UC-M11.08-C086-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Objective evaluation”; require “A missed objective remains an explicit qualification failure” and forbid a false-success verdict.
- [ ] **UC-M11.08-C086-T06 · Adverse execution:** Exercise the “Objective evaluation” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M11.08-C086-T07 · Effect inspection:** Inspect “Objective evaluation” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M11.08-C086-T08 · Refusal versus failure:** Confirm the “Objective evaluation” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M11.08-C086-T09 · Reset and retention:** Restore only the disposable “Objective evaluation” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M11.08-C086-T10 · Negative regression:** Register the “Objective evaluation” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M11.08-C087 · Change / failure test

**Original checklist item:** Exercise objective evaluation when controllers and selected workers are lost and restored from independently verified material; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M11.08-C087-T01 · Scenario record:** Write the “Objective evaluation” change/failure scenario exactly as supplied: controllers and selected workers are lost and restored from independently verified material; identify the property that must remain true: “A missed objective remains an explicit qualification failure”.
- [ ] **UC-M11.08-C087-T02 · Baseline capture:** Create a known-valid “Objective evaluation” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M11.08-C087-T03 · Injection map:** Locate the “Objective evaluation” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M11.08-C087-T04 · Disposition oracle:** Define the legal intermediate and final “Objective evaluation” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M11.08-C087-T05 · Controlled trigger:** Introduce the controlled “Objective evaluation” scenario in the disposable fixture: controllers and selected workers are lost and restored from independently verified material; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M11.08-C087-T06 · Intermediate inspection:** Inspect the “Objective evaluation” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M11.08-C087-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Objective evaluation”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M11.08-C087-T08 · Stale-evidence cleanup:** Invalidate superseded “Objective evaluation” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M11.08-C087-T09 · Repeat and compare:** Repeat the selected “Objective evaluation” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M11.08-C087-T10 · Failure evidence:** Publish the “Objective evaluation” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M11.08-C088 · Bounds

**Original checklist item:** Set a documented campaign budget for evaluation records and workload scenarios; record actual consumption, incomplete coverage and the disposition when the budget is exhausted.

- [ ] **UC-M11.08-C088-T01 · Quantity inventory:** Create a measurement inventory for “Objective evaluation”: “Evaluation records and workload scenarios”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M11.08-C088-T02 · Measurement method:** Choose how to observe each “Objective evaluation” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M11.08-C088-T03 · Budget decision:** Select justified campaign and target-resource budgets for “Objective evaluation”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M11.08-C088-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Objective evaluation” cases for “Evaluation records and workload scenarios”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M11.08-C088-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Objective evaluation” limit; preserve “A missed objective remains an explicit qualification failure”.
- [ ] **UC-M11.08-C088-T06 · Normal measurement:** Run or review the normal “Objective evaluation” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M11.08-C088-T07 · At-limit measurement:** Exercise the “Objective evaluation” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M11.08-C088-T08 · Over-limit measurement:** Exercise the “Objective evaluation” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M11.08-C088-T09 · Uncovered-scope report:** List the “Objective evaluation” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M11.08-C088-T10 · Limit evidence:** Publish the selected “Objective evaluation” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M11.08-C089 · Diagnostics / review

**Original checklist item:** Report objective evaluation results with executed, failed, skipped and unavailable cases separated; preserve the underlying observations and do not manufacture missing measurements.

- [ ] **UC-M11.08-C089-T01 · Result inventory:** Enumerate the required “Objective evaluation” qualification cases and intended targets before aggregating results; keep the planned denominator visible.
- [ ] **UC-M11.08-C089-T02 · Verdict schema:** Define separate executed-pass, executed-fail, skipped, unavailable and untested outcomes for “Objective evaluation”; document how incomplete cases block relevant claims.
- [ ] **UC-M11.08-C089-T03 · Identity fields:** Attach the actual target, fixture, configuration and revision identifiers to each “Objective evaluation” result; do not attribute host-only evidence to a guest or another OS.
- [ ] **UC-M11.08-C089-T04 · Observation capture:** Capture bounded raw “Objective evaluation” observations and harness errors; retain enough information to verify the reported oracle comparison.
- [ ] **UC-M11.08-C089-T05 · Aggregation rules:** Implement the “Objective evaluation” count/reduction rule so failures and missing measurements cannot disappear; preserve “A missed objective remains an explicit qualification failure”.
- [ ] **UC-M11.08-C089-T06 · Failure visibility:** Feed a failing “Objective evaluation” control through the report path; assert the exact failed case and underlying observation remain visible.
- [ ] **UC-M11.08-C089-T07 · Missing-result visibility:** Withhold a required “Objective evaluation” measurement or target; verify the report uses unavailable/untested rather than a fabricated zero or passing value.
- [ ] **UC-M11.08-C089-T08 · Bounds and redaction:** Check “Objective evaluation” report size and retention against “Evaluation records and workload scenarios”; remove secrets while retaining fixture and subject references.
- [ ] **UC-M11.08-C089-T09 · Report reconciliation:** Reconcile the “Objective evaluation” summary with every underlying case record; account for the full planned denominator and all omitted scope.
- [ ] **UC-M11.08-C089-T10 · Qualification handoff:** Publish the “Objective evaluation” report with measured observations, coverage limits and blockers; state which actual targets remain unqualified.

### UC-M11.08-C090 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for objective evaluation; label unexecuted checks as untested.

- [ ] **UC-M11.08-C090-T01 · Evidence inventory:** List the “Objective evaluation” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M11.08-C090-T02 · Artifact references:** Record the exact “Objective evaluation” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M11.08-C090-T03 · Fixture references:** Attach the “Objective evaluation” fixture IDs, input identities and oracle definition; preserve the source counterexample “A drill exceeds the objective but is reported as passed without qualification” as a distinct evidence case.
- [ ] **UC-M11.08-C090-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Objective evaluation”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M11.08-C090-T05 · Environment record:** Record the actual “Objective evaluation” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M11.08-C090-T06 · Expected versus observed:** Pair every “Objective evaluation” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M11.08-C090-T07 · Failure and limit records:** Attach “Objective evaluation” change/failure and bounds evidence where required; include uncovered “Evaluation records and workload scenarios” and unresolved violations of “A missed objective remains an explicit qualification failure”.
- [ ] **UC-M11.08-C090-T08 · Evidence hygiene:** Check the “Objective evaluation” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M11.08-C090-T09 · Reproduction review:** Have the “Objective evaluation” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M11.08-C090-T10 · Acceptance linkage:** Link the “Objective evaluation” evidence to its parent and UC-M11.08 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 10. Disaster recovery runbook

**Source delivery:** Publish reproducible procedures and residual risks grounded in the observed drill.

**Source invariant:** A runbook distinguishes verified actions from untested alternatives.

**Source negative case:** An untested emergency shortcut is presented as the proven recovery path.

**Source bounded quantities:** Runbook steps and evidence links.

### UC-M11.08-C091 · Contract

**Original checklist item:** Define the qualification objective for disaster recovery runbook, including the actual target implementation, prerequisites, observable oracle and explicit exclusions.

- [ ] **UC-M11.08-C091-T01 · Scope statement:** Write the qualification question for “Disaster recovery runbook”; identify the actual target, claimed capability and observations that can answer that question.
- [ ] **UC-M11.08-C091-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Disaster recovery runbook”; record each producer, representation and missing-value meaning.
- [ ] **UC-M11.08-C091-T03 · Output inventory:** List the outputs of “Disaster recovery runbook” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M11.08-C091-T04 · Field dictionary:** Create a field-and-term dictionary for “Disaster recovery runbook”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M11.08-C091-T05 · Prerequisite contract:** Map “Disaster recovery runbook” to the source component prerequisites (UC-M11.04, UC-M11.06, UC-M11.07); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M11.08-C091-T06 · Authority map:** Identify who may produce, change and consume “Disaster recovery runbook”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M11.08-C091-T07 · Invariant clause:** Add a normative clause for “Disaster recovery runbook” that preserves “A runbook distinguishes verified actions from untested alternatives”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M11.08-C091-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Disaster recovery runbook”; include the source counterexample “An untested emergency shortcut is presented as the proven recovery path” and the intended safe disposition.
- [ ] **UC-M11.08-C091-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Runbook steps and evidence links” in the “Disaster recovery runbook” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M11.08-C091-T10 · Contract review:** Review the “Disaster recovery runbook” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M11.08-C092 · Delivery

**Original checklist item:** Publish reproducible procedures and residual risks grounded in the observed drill.

- [ ] **UC-M11.08-C092-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Disaster recovery runbook”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M11.08-C092-T02 · Change plan:** Break the source delivery for “Disaster recovery runbook” into concrete edit targets and reviewable outputs; keep the UC-M11.08 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M11.08-C092-T03 · Core artifact:** Create the “Disaster recovery runbook” output artifact for this source instruction: Publish reproducible procedures and residual risks grounded in the observed drill.
- [ ] **UC-M11.08-C092-T04 · Concrete realization:** Populate the “Disaster recovery runbook” artifact from identified observations; keep unknown, failed and unexecuted results distinct and exclude unapproved sensitive material.
- [ ] **UC-M11.08-C092-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Disaster recovery runbook” needed to preserve “A runbook distinguishes verified actions from untested alternatives”; record an enforcement gap where only a model exists.
- [ ] **UC-M11.08-C092-T06 · Dependency connection:** Connect the “Disaster recovery runbook” qualification artifact to verified control/data recovery, restored identities and stale-leader fencing; record the target identity and what the harness actually exercises.
- [ ] **UC-M11.08-C092-T07 · Resource behavior:** Account for “Runbook steps and evidence links” in “Disaster recovery runbook”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M11.08-C092-T08 · Delivery check:** Run a known-valid control and a deliberately failing control for “Disaster recovery runbook”; confirm the harness distinguishes their observed outcomes.
- [ ] **UC-M11.08-C092-T09 · Patch review:** Review the “Disaster recovery runbook” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M11.08-C092-T10 · Delivery handoff:** Publish the “Disaster recovery runbook” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M11.08-C093 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: A runbook distinguishes verified actions from untested alternatives. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M11.08-C093-T01 · Named property:** Create a stable property/check name under this parent for “Disaster recovery runbook”; copy its required invariant exactly: “A runbook distinguishes verified actions from untested alternatives”.
- [ ] **UC-M11.08-C093-T02 · Observable terms:** Define each term in the “Disaster recovery runbook” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M11.08-C093-T03 · Precondition set:** List the preconditions under which “A runbook distinguishes verified actions from untested alternatives” must hold for “Disaster recovery runbook”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M11.08-C093-T04 · Transition coverage:** Map the “Disaster recovery runbook” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M11.08-C093-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Disaster recovery runbook”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M11.08-C093-T06 · Satisfying fixture:** Create a concrete “Disaster recovery runbook” case that satisfies “A runbook distinguishes verified actions from untested alternatives”; record its expected observation before running the assertion or review.
- [ ] **UC-M11.08-C093-T07 · Violating fixture:** Create the source counterexample “An untested emergency shortcut is presented as the proven recovery path” for “Disaster recovery runbook”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M11.08-C093-T08 · Enforcement evidence:** Exercise the “Disaster recovery runbook” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M11.08-C093-T09 · Regression linkage:** Link the “Disaster recovery runbook” property to changes in verified control/data recovery, restored identities and stale-leader fencing; record which dependency or contract changes require rerunning it.
- [ ] **UC-M11.08-C093-T10 · Property disposition:** Compare the satisfying and violating “Disaster recovery runbook” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M11.08-C094 · Integration

**Original checklist item:** Integrate disaster recovery runbook with verified control/data recovery, restored identities and stale-leader fencing; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M11.08-C094-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Disaster recovery runbook” across verified control/data recovery, restored identities and stale-leader fencing; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M11.08-C094-T02 · Field mapping:** Map every “Disaster recovery runbook” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M11.08-C094-T03 · Prerequisite identities:** Record the actual prerequisites for “Disaster recovery runbook” (source dependency list: UC-M11.04, UC-M11.06, UC-M11.07); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M11.08-C094-T04 · Ownership agreement:** Specify who owns “Disaster recovery runbook” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M11.08-C094-T05 · Handoff implementation:** Connect “Disaster recovery runbook” through the mapped seam using the real adapter or explicit specification reference; preserve “A runbook distinguishes verified actions from untested alternatives” across the handoff.
- [ ] **UC-M11.08-C094-T06 · Absent-input case:** Omit one required “Disaster recovery runbook” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M11.08-C094-T07 · Stale-input case:** Supply an outdated “Disaster recovery runbook” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M11.08-C094-T08 · Incompatible-input case:** Supply an incompatible “Disaster recovery runbook” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M11.08-C094-T09 · Valid integration trace:** Run a valid “Disaster recovery runbook” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M11.08-C094-T10 · Seam review:** Reconcile the “Disaster recovery runbook” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M11.08-C095 · Valid-case test

**Original checklist item:** Run a known-valid control for disaster recovery runbook; verify that the harness reaches its intended target and compare observed measurements or verdicts with predeclared expectations.

- [ ] **UC-M11.08-C095-T01 · Valid fixture choice:** Choose a known-valid control for “Disaster recovery runbook”; document why it should pass and how it proves the harness reaches the intended target.
- [ ] **UC-M11.08-C095-T02 · Expected-result oracle:** Specify the “Disaster recovery runbook” expected result independently of the implementation output; include the property “A runbook distinguishes verified actions from untested alternatives” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M11.08-C095-T03 · Fixture material:** Create the concrete “Disaster recovery runbook” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M11.08-C095-T04 · Target preparation:** Prepare the “Disaster recovery runbook” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M11.08-C095-T05 · Initial-state record:** Record the initial “Disaster recovery runbook” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M11.08-C095-T06 · Valid-path execution:** Run the “Disaster recovery runbook” known-valid control on the identified target; retain enough observations to prove the correct target was exercised.
- [ ] **UC-M11.08-C095-T07 · Outcome comparison:** Compare every declared “Disaster recovery runbook” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M11.08-C095-T08 · State and bounds check:** Inspect the “Disaster recovery runbook” ownership/state effects and actual use of “Runbook steps and evidence links”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M11.08-C095-T09 · Repeatability check:** Repeat the same “Disaster recovery runbook” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M11.08-C095-T10 · Positive evidence:** Attach the “Disaster recovery runbook” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M11.08-C096 · Negative test

**Original checklist item:** Negative case: An untested emergency shortcut is presented as the proven recovery path. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M11.08-C096-T01 · Adverse-case definition:** Create a test record for the exact “Disaster recovery runbook” source counterexample: “An untested emergency shortcut is presented as the proven recovery path”; state which precondition or invariant it challenges.
- [ ] **UC-M11.08-C096-T02 · Safe fixture boundary:** Define the contained test boundary for “Disaster recovery runbook”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M11.08-C096-T03 · Valid control:** Construct a valid “Disaster recovery runbook” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M11.08-C096-T04 · Minimal adverse input:** Derive the “Disaster recovery runbook” adverse fixture from the control with the smallest documented change needed to reproduce “An untested emergency shortcut is presented as the proven recovery path”; retain that change as reproducible data.
- [ ] **UC-M11.08-C096-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Disaster recovery runbook”; require “A runbook distinguishes verified actions from untested alternatives” and forbid a false-success verdict.
- [ ] **UC-M11.08-C096-T06 · Adverse execution:** Exercise the “Disaster recovery runbook” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M11.08-C096-T07 · Effect inspection:** Inspect “Disaster recovery runbook” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M11.08-C096-T08 · Refusal versus failure:** Confirm the “Disaster recovery runbook” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M11.08-C096-T09 · Reset and retention:** Restore only the disposable “Disaster recovery runbook” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M11.08-C096-T10 · Negative regression:** Register the “Disaster recovery runbook” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M11.08-C097 · Change / failure test

**Original checklist item:** Exercise disaster recovery runbook when controllers and selected workers are lost and restored from independently verified material; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M11.08-C097-T01 · Scenario record:** Write the “Disaster recovery runbook” change/failure scenario exactly as supplied: controllers and selected workers are lost and restored from independently verified material; identify the property that must remain true: “A runbook distinguishes verified actions from untested alternatives”.
- [ ] **UC-M11.08-C097-T02 · Baseline capture:** Create a known-valid “Disaster recovery runbook” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M11.08-C097-T03 · Injection map:** Locate the “Disaster recovery runbook” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M11.08-C097-T04 · Disposition oracle:** Define the legal intermediate and final “Disaster recovery runbook” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M11.08-C097-T05 · Controlled trigger:** Introduce the controlled “Disaster recovery runbook” scenario in the disposable fixture: controllers and selected workers are lost and restored from independently verified material; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M11.08-C097-T06 · Intermediate inspection:** Inspect the “Disaster recovery runbook” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M11.08-C097-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Disaster recovery runbook”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M11.08-C097-T08 · Stale-evidence cleanup:** Invalidate superseded “Disaster recovery runbook” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M11.08-C097-T09 · Repeat and compare:** Repeat the selected “Disaster recovery runbook” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M11.08-C097-T10 · Failure evidence:** Publish the “Disaster recovery runbook” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M11.08-C098 · Bounds

**Original checklist item:** Set a documented campaign budget for runbook steps and evidence links; record actual consumption, incomplete coverage and the disposition when the budget is exhausted.

- [ ] **UC-M11.08-C098-T01 · Quantity inventory:** Create a measurement inventory for “Disaster recovery runbook”: “Runbook steps and evidence links”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M11.08-C098-T02 · Measurement method:** Choose how to observe each “Disaster recovery runbook” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M11.08-C098-T03 · Budget decision:** Select justified campaign and target-resource budgets for “Disaster recovery runbook”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M11.08-C098-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Disaster recovery runbook” cases for “Runbook steps and evidence links”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M11.08-C098-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Disaster recovery runbook” limit; preserve “A runbook distinguishes verified actions from untested alternatives”.
- [ ] **UC-M11.08-C098-T06 · Normal measurement:** Run or review the normal “Disaster recovery runbook” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M11.08-C098-T07 · At-limit measurement:** Exercise the “Disaster recovery runbook” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M11.08-C098-T08 · Over-limit measurement:** Exercise the “Disaster recovery runbook” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M11.08-C098-T09 · Uncovered-scope report:** List the “Disaster recovery runbook” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M11.08-C098-T10 · Limit evidence:** Publish the selected “Disaster recovery runbook” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M11.08-C099 · Diagnostics / review

**Original checklist item:** Report disaster recovery runbook results with executed, failed, skipped and unavailable cases separated; preserve the underlying observations and do not manufacture missing measurements.

- [ ] **UC-M11.08-C099-T01 · Result inventory:** Enumerate the required “Disaster recovery runbook” qualification cases and intended targets before aggregating results; keep the planned denominator visible.
- [ ] **UC-M11.08-C099-T02 · Verdict schema:** Define separate executed-pass, executed-fail, skipped, unavailable and untested outcomes for “Disaster recovery runbook”; document how incomplete cases block relevant claims.
- [ ] **UC-M11.08-C099-T03 · Identity fields:** Attach the actual target, fixture, configuration and revision identifiers to each “Disaster recovery runbook” result; do not attribute host-only evidence to a guest or another OS.
- [ ] **UC-M11.08-C099-T04 · Observation capture:** Capture bounded raw “Disaster recovery runbook” observations and harness errors; retain enough information to verify the reported oracle comparison.
- [ ] **UC-M11.08-C099-T05 · Aggregation rules:** Implement the “Disaster recovery runbook” count/reduction rule so failures and missing measurements cannot disappear; preserve “A runbook distinguishes verified actions from untested alternatives”.
- [ ] **UC-M11.08-C099-T06 · Failure visibility:** Feed a failing “Disaster recovery runbook” control through the report path; assert the exact failed case and underlying observation remain visible.
- [ ] **UC-M11.08-C099-T07 · Missing-result visibility:** Withhold a required “Disaster recovery runbook” measurement or target; verify the report uses unavailable/untested rather than a fabricated zero or passing value.
- [ ] **UC-M11.08-C099-T08 · Bounds and redaction:** Check “Disaster recovery runbook” report size and retention against “Runbook steps and evidence links”; remove secrets while retaining fixture and subject references.
- [ ] **UC-M11.08-C099-T09 · Report reconciliation:** Reconcile the “Disaster recovery runbook” summary with every underlying case record; account for the full planned denominator and all omitted scope.
- [ ] **UC-M11.08-C099-T10 · Qualification handoff:** Publish the “Disaster recovery runbook” report with measured observations, coverage limits and blockers; state which actual targets remain unqualified.

### UC-M11.08-C100 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for disaster recovery runbook; label unexecuted checks as untested.

- [ ] **UC-M11.08-C100-T01 · Evidence inventory:** List the “Disaster recovery runbook” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M11.08-C100-T02 · Artifact references:** Record the exact “Disaster recovery runbook” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M11.08-C100-T03 · Fixture references:** Attach the “Disaster recovery runbook” fixture IDs, input identities and oracle definition; preserve the source counterexample “An untested emergency shortcut is presented as the proven recovery path” as a distinct evidence case.
- [ ] **UC-M11.08-C100-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Disaster recovery runbook”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M11.08-C100-T05 · Environment record:** Record the actual “Disaster recovery runbook” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M11.08-C100-T06 · Expected versus observed:** Pair every “Disaster recovery runbook” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M11.08-C100-T07 · Failure and limit records:** Attach “Disaster recovery runbook” change/failure and bounds evidence where required; include uncovered “Runbook steps and evidence links” and unresolved violations of “A runbook distinguishes verified actions from untested alternatives”.
- [ ] **UC-M11.08-C100-T08 · Evidence hygiene:** Check the “Disaster recovery runbook” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M11.08-C100-T09 · Reproduction review:** Have the “Disaster recovery runbook” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M11.08-C100-T10 · Acceptance linkage:** Link the “Disaster recovery runbook” evidence to its parent and UC-M11.08 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

