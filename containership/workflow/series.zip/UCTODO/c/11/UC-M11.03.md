# UC-M11.03 — Durable consensus control store

**To-Do Pack 2.0.0 · Baseline UC-2.2.0 · 100 parent checks × 10 subtasks = 1,000 to-dos**

[Master index](../../INDEX.md) · [Workstream index](../../w/11.md)

| Field | Preserved source value |
|---|---|
| Workstream | 11. Optional multi-host federation |
| Milestone | D |
| Priority | P2 |
| Source assessment | MISSING |
| Scope | optional multi host |
| Dependencies | [UC-M07.01](../07/UC-M07.01.md), [UC-M11.02](../11/UC-M11.02.md) |
| Source checklist pack | 1.0.0 |
| Original reference labels | [S4], [S6]. |

## Original requirement

Choose and specify a real consensus protocol and failure model for desired state; local ALLREDUCE witness agreement is not consensus.

**Original acceptance criterion:** Leader loss and network partition preserve the specified single-writer safety and recovery/liveness assumptions.

**Source trace:** Original checklist `UC100/c/11/UC-M11.03.md` inside [s/checklists.zip](../../s/checklists.zip); exact parent records in [data/parents.jsonl](../../data/parents.jsonl). Original roadmap lines 1021–1031 are preserved in [s/roadmap.md](../../s/roadmap.md).

## How to use these lists

Every parent statement below is preserved verbatim. Its ten child tasks are proposed decomposition, not implemented capabilities or executed tests. Child IDs append `-T01` through `-T10` to the original parent ID. All begin unchecked / `TODO`. Design/review evidence does not establish runtime enforcement; observe the actual selected target where the parent requires it.

The source dependency graph and selected release profile determine applicability. The numbered child sequence is a local working order, not an added hard dependency graph. An unselected optional feature needs a recorded not-applicable rationale; missing prerequisites for selected work remain blockers. Numerical budgets, backends and trust mechanisms remain decisions unless fixed by the source. Test hostile cases only with synthetic inputs in authorized disposable environments.

## 01. Consensus protocol decision

**Source delivery:** Choose an explicit real consensus protocol and supported topology.

**Source invariant:** Local ALLREDUCE witness agreement is not labeled distributed consensus.

**Source negative case:** Several local interpreters are presented as a consensus cluster.

**Source bounded quantities:** Members and supported topology variants.

### UC-M11.03-C001 · Contract

**Original checklist item:** Specify consensus protocol decision inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M11.03-C001-T01 · Scope statement:** Draft the operation boundary for “Consensus protocol decision” within Durable consensus control store; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M11.03-C001-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Consensus protocol decision”; record each producer, representation and missing-value meaning.
- [ ] **UC-M11.03-C001-T03 · Output inventory:** List the outputs of “Consensus protocol decision” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M11.03-C001-T04 · Field dictionary:** Create a field-and-term dictionary for “Consensus protocol decision”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M11.03-C001-T05 · Prerequisite contract:** Map “Consensus protocol decision” to the source component prerequisites (UC-M07.01, UC-M11.02); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M11.03-C001-T06 · Authority map:** Identify who may produce, change and consume “Consensus protocol decision”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M11.03-C001-T07 · Invariant clause:** Add a normative clause for “Consensus protocol decision” that preserves “Local ALLREDUCE witness agreement is not labeled distributed consensus”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M11.03-C001-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Consensus protocol decision”; include the source counterexample “Several local interpreters are presented as a consensus cluster” and the intended safe disposition.
- [ ] **UC-M11.03-C001-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Members and supported topology variants” in the “Consensus protocol decision” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M11.03-C001-T10 · Contract review:** Review the “Consensus protocol decision” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M11.03-C002 · Delivery

**Original checklist item:** Choose an explicit real consensus protocol and supported topology.

- [ ] **UC-M11.03-C002-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Consensus protocol decision”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M11.03-C002-T02 · Change plan:** Break the source delivery for “Consensus protocol decision” into concrete edit targets and reviewable outputs; keep the UC-M11.03 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M11.03-C002-T03 · Core artifact:** Prepare the “Consensus protocol decision” decision record for this source instruction: Choose an explicit real consensus protocol and supported topology.
- [ ] **UC-M11.03-C002-T04 · Concrete realization:** Evaluate the “Consensus protocol decision” choice against its declared constraints; record the exact selected target/configuration and rejected alternatives, leaving unverified compatibility as a blocker.
- [ ] **UC-M11.03-C002-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Consensus protocol decision” needed to preserve “Local ALLREDUCE witness agreement is not labeled distributed consensus”; record an enforcement gap where only a model exists.
- [ ] **UC-M11.03-C002-T06 · Dependency connection:** Connect the “Consensus protocol decision” implementation to replicated desired state, durable protocol state and authoritative commit decisions; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M11.03-C002-T07 · Resource behavior:** Account for “Members and supported topology variants” in “Consensus protocol decision”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M11.03-C002-T08 · Delivery check:** Run the smallest real “Consensus protocol decision” path and its adverse fixture “Several local interpreters are presented as a consensus cluster”; retain actual output, state effects and final disposition.
- [ ] **UC-M11.03-C002-T09 · Patch review:** Review the “Consensus protocol decision” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M11.03-C002-T10 · Delivery handoff:** Publish the “Consensus protocol decision” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M11.03-C003 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Local ALLREDUCE witness agreement is not labeled distributed consensus. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M11.03-C003-T01 · Named property:** Create a stable property/check name under this parent for “Consensus protocol decision”; copy its required invariant exactly: “Local ALLREDUCE witness agreement is not labeled distributed consensus”.
- [ ] **UC-M11.03-C003-T02 · Observable terms:** Define each term in the “Consensus protocol decision” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M11.03-C003-T03 · Precondition set:** List the preconditions under which “Local ALLREDUCE witness agreement is not labeled distributed consensus” must hold for “Consensus protocol decision”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M11.03-C003-T04 · Transition coverage:** Map the “Consensus protocol decision” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M11.03-C003-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Consensus protocol decision”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M11.03-C003-T06 · Satisfying fixture:** Create a concrete “Consensus protocol decision” case that satisfies “Local ALLREDUCE witness agreement is not labeled distributed consensus”; record its expected observation before running the assertion or review.
- [ ] **UC-M11.03-C003-T07 · Violating fixture:** Create the source counterexample “Several local interpreters are presented as a consensus cluster” for “Consensus protocol decision”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M11.03-C003-T08 · Enforcement evidence:** Exercise the “Consensus protocol decision” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M11.03-C003-T09 · Regression linkage:** Link the “Consensus protocol decision” property to changes in replicated desired state, durable protocol state and authoritative commit decisions; record which dependency or contract changes require rerunning it.
- [ ] **UC-M11.03-C003-T10 · Property disposition:** Compare the satisfying and violating “Consensus protocol decision” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M11.03-C004 · Integration

**Original checklist item:** Integrate consensus protocol decision with replicated desired state, durable protocol state and authoritative commit decisions; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M11.03-C004-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Consensus protocol decision” across replicated desired state, durable protocol state and authoritative commit decisions; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M11.03-C004-T02 · Field mapping:** Map every “Consensus protocol decision” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M11.03-C004-T03 · Prerequisite identities:** Record the actual prerequisites for “Consensus protocol decision” (source dependency list: UC-M07.01, UC-M11.02); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M11.03-C004-T04 · Ownership agreement:** Specify who owns “Consensus protocol decision” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M11.03-C004-T05 · Handoff implementation:** Connect “Consensus protocol decision” through the mapped seam using the real adapter or explicit specification reference; preserve “Local ALLREDUCE witness agreement is not labeled distributed consensus” across the handoff.
- [ ] **UC-M11.03-C004-T06 · Absent-input case:** Omit one required “Consensus protocol decision” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M11.03-C004-T07 · Stale-input case:** Supply an outdated “Consensus protocol decision” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M11.03-C004-T08 · Incompatible-input case:** Supply an incompatible “Consensus protocol decision” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M11.03-C004-T09 · Valid integration trace:** Run a valid “Consensus protocol decision” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M11.03-C004-T10 · Seam review:** Reconcile the “Consensus protocol decision” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M11.03-C005 · Valid-case test

**Original checklist item:** Run a valid-path fixture for consensus protocol decision; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M11.03-C005-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Consensus protocol decision” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M11.03-C005-T02 · Expected-result oracle:** Specify the “Consensus protocol decision” expected result independently of the implementation output; include the property “Local ALLREDUCE witness agreement is not labeled distributed consensus” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M11.03-C005-T03 · Fixture material:** Create the concrete “Consensus protocol decision” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M11.03-C005-T04 · Target preparation:** Prepare the “Consensus protocol decision” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M11.03-C005-T05 · Initial-state record:** Record the initial “Consensus protocol decision” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M11.03-C005-T06 · Valid-path execution:** Execute the “Consensus protocol decision” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M11.03-C005-T07 · Outcome comparison:** Compare every declared “Consensus protocol decision” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M11.03-C005-T08 · State and bounds check:** Inspect the “Consensus protocol decision” ownership/state effects and actual use of “Members and supported topology variants”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M11.03-C005-T09 · Repeatability check:** Repeat the same “Consensus protocol decision” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M11.03-C005-T10 · Positive evidence:** Attach the “Consensus protocol decision” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M11.03-C006 · Negative test

**Original checklist item:** Negative case: Several local interpreters are presented as a consensus cluster. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M11.03-C006-T01 · Adverse-case definition:** Create a test record for the exact “Consensus protocol decision” source counterexample: “Several local interpreters are presented as a consensus cluster”; state which precondition or invariant it challenges.
- [ ] **UC-M11.03-C006-T02 · Safe fixture boundary:** Define the contained test boundary for “Consensus protocol decision”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M11.03-C006-T03 · Valid control:** Construct a valid “Consensus protocol decision” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M11.03-C006-T04 · Minimal adverse input:** Derive the “Consensus protocol decision” adverse fixture from the control with the smallest documented change needed to reproduce “Several local interpreters are presented as a consensus cluster”; retain that change as reproducible data.
- [ ] **UC-M11.03-C006-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Consensus protocol decision”; require “Local ALLREDUCE witness agreement is not labeled distributed consensus” and forbid a false-success verdict.
- [ ] **UC-M11.03-C006-T06 · Adverse execution:** Exercise the “Consensus protocol decision” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M11.03-C006-T07 · Effect inspection:** Inspect “Consensus protocol decision” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M11.03-C006-T08 · Refusal versus failure:** Confirm the “Consensus protocol decision” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M11.03-C006-T09 · Reset and retention:** Restore only the disposable “Consensus protocol decision” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M11.03-C006-T10 · Negative regression:** Register the “Consensus protocol decision” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M11.03-C007 · Change / failure test

**Original checklist item:** Exercise consensus protocol decision when leadership changes during a network partition in the declared topology; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M11.03-C007-T01 · Scenario record:** Write the “Consensus protocol decision” change/failure scenario exactly as supplied: leadership changes during a network partition in the declared topology; identify the property that must remain true: “Local ALLREDUCE witness agreement is not labeled distributed consensus”.
- [ ] **UC-M11.03-C007-T02 · Baseline capture:** Create a known-valid “Consensus protocol decision” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M11.03-C007-T03 · Injection map:** Locate the “Consensus protocol decision” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M11.03-C007-T04 · Disposition oracle:** Define the legal intermediate and final “Consensus protocol decision” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M11.03-C007-T05 · Controlled trigger:** Introduce the controlled “Consensus protocol decision” scenario in the disposable fixture: leadership changes during a network partition in the declared topology; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M11.03-C007-T06 · Intermediate inspection:** Inspect the “Consensus protocol decision” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M11.03-C007-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Consensus protocol decision”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M11.03-C007-T08 · Stale-evidence cleanup:** Invalidate superseded “Consensus protocol decision” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M11.03-C007-T09 · Repeat and compare:** Repeat the selected “Consensus protocol decision” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M11.03-C007-T10 · Failure evidence:** Publish the “Consensus protocol decision” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M11.03-C008 · Bounds

**Original checklist item:** Choose, document and test limits for members and supported topology variants; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M11.03-C008-T01 · Quantity inventory:** Create a measurement inventory for “Consensus protocol decision”: “Members and supported topology variants”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M11.03-C008-T02 · Measurement method:** Choose how to observe each “Consensus protocol decision” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M11.03-C008-T03 · Budget decision:** Select justified resource and input limits for “Consensus protocol decision”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M11.03-C008-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Consensus protocol decision” cases for “Members and supported topology variants”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M11.03-C008-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Consensus protocol decision” limit; preserve “Local ALLREDUCE witness agreement is not labeled distributed consensus”.
- [ ] **UC-M11.03-C008-T06 · Normal measurement:** Run or review the normal “Consensus protocol decision” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M11.03-C008-T07 · At-limit measurement:** Exercise the “Consensus protocol decision” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M11.03-C008-T08 · Over-limit measurement:** Exercise the “Consensus protocol decision” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M11.03-C008-T09 · Uncovered-scope report:** List the “Consensus protocol decision” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M11.03-C008-T10 · Limit evidence:** Publish the selected “Consensus protocol decision” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M11.03-C009 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for consensus protocol decision with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M11.03-C009-T01 · Event inventory:** List the “Consensus protocol decision” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M11.03-C009-T02 · Diagnostic schema:** Define nonsecret fields for “Consensus protocol decision” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M11.03-C009-T03 · Failure mapping:** Map each documented “Consensus protocol decision” refusal or error to a diagnostic outcome; include “Several local interpreters are presented as a consensus cluster” and prohibit conversion into a success message.
- [ ] **UC-M11.03-C009-T04 · Emission path:** Add the “Consensus protocol decision” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M11.03-C009-T05 · Redaction check:** Test “Consensus protocol decision” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M11.03-C009-T06 · Output budget:** Set and exercise bounded “Consensus protocol decision” message size, rate and retention compatible with “Members and supported topology variants”; define truncation behavior that preserves the final reason.
- [ ] **UC-M11.03-C009-T07 · Success/refusal fixtures:** Capture “Consensus protocol decision” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M11.03-C009-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Consensus protocol decision” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M11.03-C009-T09 · Operator review:** Read the “Consensus protocol decision” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M11.03-C009-T10 · Diagnostic evidence:** Publish redacted “Consensus protocol decision” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M11.03-C010 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for consensus protocol decision; label unexecuted checks as untested.

- [ ] **UC-M11.03-C010-T01 · Evidence inventory:** List the “Consensus protocol decision” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M11.03-C010-T02 · Artifact references:** Record the exact “Consensus protocol decision” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M11.03-C010-T03 · Fixture references:** Attach the “Consensus protocol decision” fixture IDs, input identities and oracle definition; preserve the source counterexample “Several local interpreters are presented as a consensus cluster” as a distinct evidence case.
- [ ] **UC-M11.03-C010-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Consensus protocol decision”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M11.03-C010-T05 · Environment record:** Record the actual “Consensus protocol decision” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M11.03-C010-T06 · Expected versus observed:** Pair every “Consensus protocol decision” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M11.03-C010-T07 · Failure and limit records:** Attach “Consensus protocol decision” change/failure and bounds evidence where required; include uncovered “Members and supported topology variants” and unresolved violations of “Local ALLREDUCE witness agreement is not labeled distributed consensus”.
- [ ] **UC-M11.03-C010-T08 · Evidence hygiene:** Check the “Consensus protocol decision” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M11.03-C010-T09 · Reproduction review:** Have the “Consensus protocol decision” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M11.03-C010-T10 · Acceptance linkage:** Link the “Consensus protocol decision” evidence to its parent and UC-M11.03 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 02. Failure model

**Source delivery:** Define crash, partition, storage and timing assumptions for the chosen protocol.

**Source invariant:** Safety and liveness claims name their required assumptions.

**Source negative case:** A report promises progress under arbitrary permanent partition.

**Source bounded quantities:** Failure classes and assumption review scope.

### UC-M11.03-C011 · Contract

**Original checklist item:** Specify failure model inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M11.03-C011-T01 · Scope statement:** Draft the operation boundary for “Failure model” within Durable consensus control store; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M11.03-C011-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Failure model”; record each producer, representation and missing-value meaning.
- [ ] **UC-M11.03-C011-T03 · Output inventory:** List the outputs of “Failure model” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M11.03-C011-T04 · Field dictionary:** Create a field-and-term dictionary for “Failure model”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M11.03-C011-T05 · Prerequisite contract:** Map “Failure model” to the source component prerequisites (UC-M07.01, UC-M11.02); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M11.03-C011-T06 · Authority map:** Identify who may produce, change and consume “Failure model”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M11.03-C011-T07 · Invariant clause:** Add a normative clause for “Failure model” that preserves “Safety and liveness claims name their required assumptions”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M11.03-C011-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Failure model”; include the source counterexample “A report promises progress under arbitrary permanent partition” and the intended safe disposition.
- [ ] **UC-M11.03-C011-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Failure classes and assumption review scope” in the “Failure model” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M11.03-C011-T10 · Contract review:** Review the “Failure model” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M11.03-C012 · Delivery

**Original checklist item:** Define crash, partition, storage and timing assumptions for the chosen protocol.

- [ ] **UC-M11.03-C012-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Failure model”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M11.03-C012-T02 · Change plan:** Break the source delivery for “Failure model” into concrete edit targets and reviewable outputs; keep the UC-M11.03 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M11.03-C012-T03 · Core artifact:** Create the “Failure model” model, schema or inventory that realizes this source instruction: Define crash, partition, storage and timing assumptions for the chosen protocol.
- [ ] **UC-M11.03-C012-T04 · Concrete realization:** Populate “Failure model” with one concrete worked case; map every required entity or field to its source and flag any unmapped entry.
- [ ] **UC-M11.03-C012-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Failure model” needed to preserve “Safety and liveness claims name their required assumptions”; record an enforcement gap where only a model exists.
- [ ] **UC-M11.03-C012-T06 · Dependency connection:** Connect the “Failure model” implementation to replicated desired state, durable protocol state and authoritative commit decisions; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M11.03-C012-T07 · Resource behavior:** Account for “Failure classes and assumption review scope” in “Failure model”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M11.03-C012-T08 · Delivery check:** Run the smallest real “Failure model” path and its adverse fixture “A report promises progress under arbitrary permanent partition”; retain actual output, state effects and final disposition.
- [ ] **UC-M11.03-C012-T09 · Patch review:** Review the “Failure model” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M11.03-C012-T10 · Delivery handoff:** Publish the “Failure model” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M11.03-C013 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Safety and liveness claims name their required assumptions. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M11.03-C013-T01 · Named property:** Create a stable property/check name under this parent for “Failure model”; copy its required invariant exactly: “Safety and liveness claims name their required assumptions”.
- [ ] **UC-M11.03-C013-T02 · Observable terms:** Define each term in the “Failure model” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M11.03-C013-T03 · Precondition set:** List the preconditions under which “Safety and liveness claims name their required assumptions” must hold for “Failure model”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M11.03-C013-T04 · Transition coverage:** Map the “Failure model” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M11.03-C013-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Failure model”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M11.03-C013-T06 · Satisfying fixture:** Create a concrete “Failure model” case that satisfies “Safety and liveness claims name their required assumptions”; record its expected observation before running the assertion or review.
- [ ] **UC-M11.03-C013-T07 · Violating fixture:** Create the source counterexample “A report promises progress under arbitrary permanent partition” for “Failure model”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M11.03-C013-T08 · Enforcement evidence:** Exercise the “Failure model” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M11.03-C013-T09 · Regression linkage:** Link the “Failure model” property to changes in replicated desired state, durable protocol state and authoritative commit decisions; record which dependency or contract changes require rerunning it.
- [ ] **UC-M11.03-C013-T10 · Property disposition:** Compare the satisfying and violating “Failure model” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M11.03-C014 · Integration

**Original checklist item:** Integrate failure model with replicated desired state, durable protocol state and authoritative commit decisions; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M11.03-C014-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Failure model” across replicated desired state, durable protocol state and authoritative commit decisions; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M11.03-C014-T02 · Field mapping:** Map every “Failure model” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M11.03-C014-T03 · Prerequisite identities:** Record the actual prerequisites for “Failure model” (source dependency list: UC-M07.01, UC-M11.02); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M11.03-C014-T04 · Ownership agreement:** Specify who owns “Failure model” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M11.03-C014-T05 · Handoff implementation:** Connect “Failure model” through the mapped seam using the real adapter or explicit specification reference; preserve “Safety and liveness claims name their required assumptions” across the handoff.
- [ ] **UC-M11.03-C014-T06 · Absent-input case:** Omit one required “Failure model” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M11.03-C014-T07 · Stale-input case:** Supply an outdated “Failure model” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M11.03-C014-T08 · Incompatible-input case:** Supply an incompatible “Failure model” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M11.03-C014-T09 · Valid integration trace:** Run a valid “Failure model” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M11.03-C014-T10 · Seam review:** Reconcile the “Failure model” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M11.03-C015 · Valid-case test

**Original checklist item:** Run a valid-path fixture for failure model; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M11.03-C015-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Failure model” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M11.03-C015-T02 · Expected-result oracle:** Specify the “Failure model” expected result independently of the implementation output; include the property “Safety and liveness claims name their required assumptions” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M11.03-C015-T03 · Fixture material:** Create the concrete “Failure model” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M11.03-C015-T04 · Target preparation:** Prepare the “Failure model” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M11.03-C015-T05 · Initial-state record:** Record the initial “Failure model” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M11.03-C015-T06 · Valid-path execution:** Execute the “Failure model” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M11.03-C015-T07 · Outcome comparison:** Compare every declared “Failure model” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M11.03-C015-T08 · State and bounds check:** Inspect the “Failure model” ownership/state effects and actual use of “Failure classes and assumption review scope”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M11.03-C015-T09 · Repeatability check:** Repeat the same “Failure model” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M11.03-C015-T10 · Positive evidence:** Attach the “Failure model” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M11.03-C016 · Negative test

**Original checklist item:** Negative case: A report promises progress under arbitrary permanent partition. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M11.03-C016-T01 · Adverse-case definition:** Create a test record for the exact “Failure model” source counterexample: “A report promises progress under arbitrary permanent partition”; state which precondition or invariant it challenges.
- [ ] **UC-M11.03-C016-T02 · Safe fixture boundary:** Define the contained test boundary for “Failure model”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M11.03-C016-T03 · Valid control:** Construct a valid “Failure model” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M11.03-C016-T04 · Minimal adverse input:** Derive the “Failure model” adverse fixture from the control with the smallest documented change needed to reproduce “A report promises progress under arbitrary permanent partition”; retain that change as reproducible data.
- [ ] **UC-M11.03-C016-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Failure model”; require “Safety and liveness claims name their required assumptions” and forbid a false-success verdict.
- [ ] **UC-M11.03-C016-T06 · Adverse execution:** Exercise the “Failure model” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M11.03-C016-T07 · Effect inspection:** Inspect “Failure model” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M11.03-C016-T08 · Refusal versus failure:** Confirm the “Failure model” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M11.03-C016-T09 · Reset and retention:** Restore only the disposable “Failure model” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M11.03-C016-T10 · Negative regression:** Register the “Failure model” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M11.03-C017 · Change / failure test

**Original checklist item:** Exercise failure model when leadership changes during a network partition in the declared topology; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M11.03-C017-T01 · Scenario record:** Write the “Failure model” change/failure scenario exactly as supplied: leadership changes during a network partition in the declared topology; identify the property that must remain true: “Safety and liveness claims name their required assumptions”.
- [ ] **UC-M11.03-C017-T02 · Baseline capture:** Create a known-valid “Failure model” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M11.03-C017-T03 · Injection map:** Locate the “Failure model” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M11.03-C017-T04 · Disposition oracle:** Define the legal intermediate and final “Failure model” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M11.03-C017-T05 · Controlled trigger:** Introduce the controlled “Failure model” scenario in the disposable fixture: leadership changes during a network partition in the declared topology; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M11.03-C017-T06 · Intermediate inspection:** Inspect the “Failure model” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M11.03-C017-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Failure model”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M11.03-C017-T08 · Stale-evidence cleanup:** Invalidate superseded “Failure model” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M11.03-C017-T09 · Repeat and compare:** Repeat the selected “Failure model” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M11.03-C017-T10 · Failure evidence:** Publish the “Failure model” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M11.03-C018 · Bounds

**Original checklist item:** Choose, document and test limits for failure classes and assumption review scope; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M11.03-C018-T01 · Quantity inventory:** Create a measurement inventory for “Failure model”: “Failure classes and assumption review scope”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M11.03-C018-T02 · Measurement method:** Choose how to observe each “Failure model” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M11.03-C018-T03 · Budget decision:** Select justified resource and input limits for “Failure model”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M11.03-C018-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Failure model” cases for “Failure classes and assumption review scope”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M11.03-C018-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Failure model” limit; preserve “Safety and liveness claims name their required assumptions”.
- [ ] **UC-M11.03-C018-T06 · Normal measurement:** Run or review the normal “Failure model” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M11.03-C018-T07 · At-limit measurement:** Exercise the “Failure model” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M11.03-C018-T08 · Over-limit measurement:** Exercise the “Failure model” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M11.03-C018-T09 · Uncovered-scope report:** List the “Failure model” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M11.03-C018-T10 · Limit evidence:** Publish the selected “Failure model” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M11.03-C019 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for failure model with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M11.03-C019-T01 · Event inventory:** List the “Failure model” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M11.03-C019-T02 · Diagnostic schema:** Define nonsecret fields for “Failure model” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M11.03-C019-T03 · Failure mapping:** Map each documented “Failure model” refusal or error to a diagnostic outcome; include “A report promises progress under arbitrary permanent partition” and prohibit conversion into a success message.
- [ ] **UC-M11.03-C019-T04 · Emission path:** Add the “Failure model” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M11.03-C019-T05 · Redaction check:** Test “Failure model” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M11.03-C019-T06 · Output budget:** Set and exercise bounded “Failure model” message size, rate and retention compatible with “Failure classes and assumption review scope”; define truncation behavior that preserves the final reason.
- [ ] **UC-M11.03-C019-T07 · Success/refusal fixtures:** Capture “Failure model” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M11.03-C019-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Failure model” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M11.03-C019-T09 · Operator review:** Read the “Failure model” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M11.03-C019-T10 · Diagnostic evidence:** Publish redacted “Failure model” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M11.03-C020 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for failure model; label unexecuted checks as untested.

- [ ] **UC-M11.03-C020-T01 · Evidence inventory:** List the “Failure model” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M11.03-C020-T02 · Artifact references:** Record the exact “Failure model” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M11.03-C020-T03 · Fixture references:** Attach the “Failure model” fixture IDs, input identities and oracle definition; preserve the source counterexample “A report promises progress under arbitrary permanent partition” as a distinct evidence case.
- [ ] **UC-M11.03-C020-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Failure model”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M11.03-C020-T05 · Environment record:** Record the actual “Failure model” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M11.03-C020-T06 · Expected versus observed:** Pair every “Failure model” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M11.03-C020-T07 · Failure and limit records:** Attach “Failure model” change/failure and bounds evidence where required; include uncovered “Failure classes and assumption review scope” and unresolved violations of “Safety and liveness claims name their required assumptions”.
- [ ] **UC-M11.03-C020-T08 · Evidence hygiene:** Check the “Failure model” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M11.03-C020-T09 · Reproduction review:** Have the “Failure model” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M11.03-C020-T10 · Acceptance linkage:** Link the “Failure model” evidence to its parent and UC-M11.03 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 03. Desired-state data model

**Source delivery:** Represent replicated desired state and versioned operations with stable identities.

**Source invariant:** Replicated state has one defined authoritative interpretation.

**Source negative case:** Two members interpret the same command differently.

**Source bounded quantities:** State bytes and operation schema size.

### UC-M11.03-C021 · Contract

**Original checklist item:** Specify desired-state data model inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M11.03-C021-T01 · Scope statement:** Draft the operation boundary for “Desired-state data model” within Durable consensus control store; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M11.03-C021-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Desired-state data model”; record each producer, representation and missing-value meaning.
- [ ] **UC-M11.03-C021-T03 · Output inventory:** List the outputs of “Desired-state data model” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M11.03-C021-T04 · Field dictionary:** Create a field-and-term dictionary for “Desired-state data model”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M11.03-C021-T05 · Prerequisite contract:** Map “Desired-state data model” to the source component prerequisites (UC-M07.01, UC-M11.02); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M11.03-C021-T06 · Authority map:** Identify who may produce, change and consume “Desired-state data model”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M11.03-C021-T07 · Invariant clause:** Add a normative clause for “Desired-state data model” that preserves “Replicated state has one defined authoritative interpretation”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M11.03-C021-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Desired-state data model”; include the source counterexample “Two members interpret the same command differently” and the intended safe disposition.
- [ ] **UC-M11.03-C021-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “State bytes and operation schema size” in the “Desired-state data model” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M11.03-C021-T10 · Contract review:** Review the “Desired-state data model” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M11.03-C022 · Delivery

**Original checklist item:** Represent replicated desired state and versioned operations with stable identities.

- [ ] **UC-M11.03-C022-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Desired-state data model”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M11.03-C022-T02 · Change plan:** Break the source delivery for “Desired-state data model” into concrete edit targets and reviewable outputs; keep the UC-M11.03 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M11.03-C022-T03 · Core artifact:** Create the “Desired-state data model” model, schema or inventory that realizes this source instruction: Represent replicated desired state and versioned operations with stable identities.
- [ ] **UC-M11.03-C022-T04 · Concrete realization:** Populate “Desired-state data model” with one concrete worked case; map every required entity or field to its source and flag any unmapped entry.
- [ ] **UC-M11.03-C022-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Desired-state data model” needed to preserve “Replicated state has one defined authoritative interpretation”; record an enforcement gap where only a model exists.
- [ ] **UC-M11.03-C022-T06 · Dependency connection:** Connect the “Desired-state data model” implementation to replicated desired state, durable protocol state and authoritative commit decisions; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M11.03-C022-T07 · Resource behavior:** Account for “State bytes and operation schema size” in “Desired-state data model”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M11.03-C022-T08 · Delivery check:** Run the smallest real “Desired-state data model” path and its adverse fixture “Two members interpret the same command differently”; retain actual output, state effects and final disposition.
- [ ] **UC-M11.03-C022-T09 · Patch review:** Review the “Desired-state data model” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M11.03-C022-T10 · Delivery handoff:** Publish the “Desired-state data model” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M11.03-C023 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Replicated state has one defined authoritative interpretation. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M11.03-C023-T01 · Named property:** Create a stable property/check name under this parent for “Desired-state data model”; copy its required invariant exactly: “Replicated state has one defined authoritative interpretation”.
- [ ] **UC-M11.03-C023-T02 · Observable terms:** Define each term in the “Desired-state data model” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M11.03-C023-T03 · Precondition set:** List the preconditions under which “Replicated state has one defined authoritative interpretation” must hold for “Desired-state data model”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M11.03-C023-T04 · Transition coverage:** Map the “Desired-state data model” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M11.03-C023-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Desired-state data model”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M11.03-C023-T06 · Satisfying fixture:** Create a concrete “Desired-state data model” case that satisfies “Replicated state has one defined authoritative interpretation”; record its expected observation before running the assertion or review.
- [ ] **UC-M11.03-C023-T07 · Violating fixture:** Create the source counterexample “Two members interpret the same command differently” for “Desired-state data model”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M11.03-C023-T08 · Enforcement evidence:** Exercise the “Desired-state data model” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M11.03-C023-T09 · Regression linkage:** Link the “Desired-state data model” property to changes in replicated desired state, durable protocol state and authoritative commit decisions; record which dependency or contract changes require rerunning it.
- [ ] **UC-M11.03-C023-T10 · Property disposition:** Compare the satisfying and violating “Desired-state data model” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M11.03-C024 · Integration

**Original checklist item:** Integrate desired-state data model with replicated desired state, durable protocol state and authoritative commit decisions; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M11.03-C024-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Desired-state data model” across replicated desired state, durable protocol state and authoritative commit decisions; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M11.03-C024-T02 · Field mapping:** Map every “Desired-state data model” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M11.03-C024-T03 · Prerequisite identities:** Record the actual prerequisites for “Desired-state data model” (source dependency list: UC-M07.01, UC-M11.02); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M11.03-C024-T04 · Ownership agreement:** Specify who owns “Desired-state data model” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M11.03-C024-T05 · Handoff implementation:** Connect “Desired-state data model” through the mapped seam using the real adapter or explicit specification reference; preserve “Replicated state has one defined authoritative interpretation” across the handoff.
- [ ] **UC-M11.03-C024-T06 · Absent-input case:** Omit one required “Desired-state data model” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M11.03-C024-T07 · Stale-input case:** Supply an outdated “Desired-state data model” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M11.03-C024-T08 · Incompatible-input case:** Supply an incompatible “Desired-state data model” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M11.03-C024-T09 · Valid integration trace:** Run a valid “Desired-state data model” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M11.03-C024-T10 · Seam review:** Reconcile the “Desired-state data model” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M11.03-C025 · Valid-case test

**Original checklist item:** Run a valid-path fixture for desired-state data model; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M11.03-C025-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Desired-state data model” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M11.03-C025-T02 · Expected-result oracle:** Specify the “Desired-state data model” expected result independently of the implementation output; include the property “Replicated state has one defined authoritative interpretation” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M11.03-C025-T03 · Fixture material:** Create the concrete “Desired-state data model” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M11.03-C025-T04 · Target preparation:** Prepare the “Desired-state data model” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M11.03-C025-T05 · Initial-state record:** Record the initial “Desired-state data model” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M11.03-C025-T06 · Valid-path execution:** Execute the “Desired-state data model” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M11.03-C025-T07 · Outcome comparison:** Compare every declared “Desired-state data model” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M11.03-C025-T08 · State and bounds check:** Inspect the “Desired-state data model” ownership/state effects and actual use of “State bytes and operation schema size”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M11.03-C025-T09 · Repeatability check:** Repeat the same “Desired-state data model” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M11.03-C025-T10 · Positive evidence:** Attach the “Desired-state data model” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M11.03-C026 · Negative test

**Original checklist item:** Negative case: Two members interpret the same command differently. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M11.03-C026-T01 · Adverse-case definition:** Create a test record for the exact “Desired-state data model” source counterexample: “Two members interpret the same command differently”; state which precondition or invariant it challenges.
- [ ] **UC-M11.03-C026-T02 · Safe fixture boundary:** Define the contained test boundary for “Desired-state data model”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M11.03-C026-T03 · Valid control:** Construct a valid “Desired-state data model” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M11.03-C026-T04 · Minimal adverse input:** Derive the “Desired-state data model” adverse fixture from the control with the smallest documented change needed to reproduce “Two members interpret the same command differently”; retain that change as reproducible data.
- [ ] **UC-M11.03-C026-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Desired-state data model”; require “Replicated state has one defined authoritative interpretation” and forbid a false-success verdict.
- [ ] **UC-M11.03-C026-T06 · Adverse execution:** Exercise the “Desired-state data model” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M11.03-C026-T07 · Effect inspection:** Inspect “Desired-state data model” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M11.03-C026-T08 · Refusal versus failure:** Confirm the “Desired-state data model” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M11.03-C026-T09 · Reset and retention:** Restore only the disposable “Desired-state data model” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M11.03-C026-T10 · Negative regression:** Register the “Desired-state data model” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M11.03-C027 · Change / failure test

**Original checklist item:** Exercise desired-state data model when leadership changes during a network partition in the declared topology; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M11.03-C027-T01 · Scenario record:** Write the “Desired-state data model” change/failure scenario exactly as supplied: leadership changes during a network partition in the declared topology; identify the property that must remain true: “Replicated state has one defined authoritative interpretation”.
- [ ] **UC-M11.03-C027-T02 · Baseline capture:** Create a known-valid “Desired-state data model” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M11.03-C027-T03 · Injection map:** Locate the “Desired-state data model” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M11.03-C027-T04 · Disposition oracle:** Define the legal intermediate and final “Desired-state data model” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M11.03-C027-T05 · Controlled trigger:** Introduce the controlled “Desired-state data model” scenario in the disposable fixture: leadership changes during a network partition in the declared topology; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M11.03-C027-T06 · Intermediate inspection:** Inspect the “Desired-state data model” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M11.03-C027-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Desired-state data model”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M11.03-C027-T08 · Stale-evidence cleanup:** Invalidate superseded “Desired-state data model” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M11.03-C027-T09 · Repeat and compare:** Repeat the selected “Desired-state data model” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M11.03-C027-T10 · Failure evidence:** Publish the “Desired-state data model” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M11.03-C028 · Bounds

**Original checklist item:** Choose, document and test limits for state bytes and operation schema size; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M11.03-C028-T01 · Quantity inventory:** Create a measurement inventory for “Desired-state data model”: “State bytes and operation schema size”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M11.03-C028-T02 · Measurement method:** Choose how to observe each “Desired-state data model” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M11.03-C028-T03 · Budget decision:** Select justified resource and input limits for “Desired-state data model”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M11.03-C028-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Desired-state data model” cases for “State bytes and operation schema size”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M11.03-C028-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Desired-state data model” limit; preserve “Replicated state has one defined authoritative interpretation”.
- [ ] **UC-M11.03-C028-T06 · Normal measurement:** Run or review the normal “Desired-state data model” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M11.03-C028-T07 · At-limit measurement:** Exercise the “Desired-state data model” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M11.03-C028-T08 · Over-limit measurement:** Exercise the “Desired-state data model” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M11.03-C028-T09 · Uncovered-scope report:** List the “Desired-state data model” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M11.03-C028-T10 · Limit evidence:** Publish the selected “Desired-state data model” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M11.03-C029 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for desired-state data model with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M11.03-C029-T01 · Event inventory:** List the “Desired-state data model” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M11.03-C029-T02 · Diagnostic schema:** Define nonsecret fields for “Desired-state data model” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M11.03-C029-T03 · Failure mapping:** Map each documented “Desired-state data model” refusal or error to a diagnostic outcome; include “Two members interpret the same command differently” and prohibit conversion into a success message.
- [ ] **UC-M11.03-C029-T04 · Emission path:** Add the “Desired-state data model” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M11.03-C029-T05 · Redaction check:** Test “Desired-state data model” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M11.03-C029-T06 · Output budget:** Set and exercise bounded “Desired-state data model” message size, rate and retention compatible with “State bytes and operation schema size”; define truncation behavior that preserves the final reason.
- [ ] **UC-M11.03-C029-T07 · Success/refusal fixtures:** Capture “Desired-state data model” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M11.03-C029-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Desired-state data model” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M11.03-C029-T09 · Operator review:** Read the “Desired-state data model” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M11.03-C029-T10 · Diagnostic evidence:** Publish redacted “Desired-state data model” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M11.03-C030 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for desired-state data model; label unexecuted checks as untested.

- [ ] **UC-M11.03-C030-T01 · Evidence inventory:** List the “Desired-state data model” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M11.03-C030-T02 · Artifact references:** Record the exact “Desired-state data model” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M11.03-C030-T03 · Fixture references:** Attach the “Desired-state data model” fixture IDs, input identities and oracle definition; preserve the source counterexample “Two members interpret the same command differently” as a distinct evidence case.
- [ ] **UC-M11.03-C030-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Desired-state data model”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M11.03-C030-T05 · Environment record:** Record the actual “Desired-state data model” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M11.03-C030-T06 · Expected versus observed:** Pair every “Desired-state data model” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M11.03-C030-T07 · Failure and limit records:** Attach “Desired-state data model” change/failure and bounds evidence where required; include uncovered “State bytes and operation schema size” and unresolved violations of “Replicated state has one defined authoritative interpretation”.
- [ ] **UC-M11.03-C030-T08 · Evidence hygiene:** Check the “Desired-state data model” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M11.03-C030-T09 · Reproduction review:** Have the “Desired-state data model” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M11.03-C030-T10 · Acceptance linkage:** Link the “Desired-state data model” evidence to its parent and UC-M11.03 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 04. Durable log or equivalent

**Source delivery:** Implement the selected protocol's durable ordering and persistence requirements.

**Source invariant:** Acknowledged authoritative state survives the specified member failures.

**Source negative case:** A member acknowledges a state update before required durability.

**Source bounded quantities:** Log entries and persistence latency.

### UC-M11.03-C031 · Contract

**Original checklist item:** Specify durable log or equivalent inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M11.03-C031-T01 · Scope statement:** Draft the operation boundary for “Durable log or equivalent” within Durable consensus control store; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M11.03-C031-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Durable log or equivalent”; record each producer, representation and missing-value meaning.
- [ ] **UC-M11.03-C031-T03 · Output inventory:** List the outputs of “Durable log or equivalent” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M11.03-C031-T04 · Field dictionary:** Create a field-and-term dictionary for “Durable log or equivalent”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M11.03-C031-T05 · Prerequisite contract:** Map “Durable log or equivalent” to the source component prerequisites (UC-M07.01, UC-M11.02); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M11.03-C031-T06 · Authority map:** Identify who may produce, change and consume “Durable log or equivalent”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M11.03-C031-T07 · Invariant clause:** Add a normative clause for “Durable log or equivalent” that preserves “Acknowledged authoritative state survives the specified member failures”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M11.03-C031-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Durable log or equivalent”; include the source counterexample “A member acknowledges a state update before required durability” and the intended safe disposition.
- [ ] **UC-M11.03-C031-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Log entries and persistence latency” in the “Durable log or equivalent” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M11.03-C031-T10 · Contract review:** Review the “Durable log or equivalent” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M11.03-C032 · Delivery

**Original checklist item:** Implement the selected protocol's durable ordering and persistence requirements.

- [ ] **UC-M11.03-C032-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Durable log or equivalent”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M11.03-C032-T02 · Change plan:** Break the source delivery for “Durable log or equivalent” into concrete edit targets and reviewable outputs; keep the UC-M11.03 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M11.03-C032-T03 · Core artifact:** Implement the smallest selected-profile change for “Durable log or equivalent” that realizes this source instruction: Implement the selected protocol's durable ordering and persistence requirements.
- [ ] **UC-M11.03-C032-T04 · Concrete realization:** Trace “Durable log or equivalent” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M11.03-C032-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Durable log or equivalent” needed to preserve “Acknowledged authoritative state survives the specified member failures”; record an enforcement gap where only a model exists.
- [ ] **UC-M11.03-C032-T06 · Dependency connection:** Connect the “Durable log or equivalent” implementation to replicated desired state, durable protocol state and authoritative commit decisions; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M11.03-C032-T07 · Resource behavior:** Account for “Log entries and persistence latency” in “Durable log or equivalent”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M11.03-C032-T08 · Delivery check:** Run the smallest real “Durable log or equivalent” path and its adverse fixture “A member acknowledges a state update before required durability”; retain actual output, state effects and final disposition.
- [ ] **UC-M11.03-C032-T09 · Patch review:** Review the “Durable log or equivalent” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M11.03-C032-T10 · Delivery handoff:** Publish the “Durable log or equivalent” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M11.03-C033 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Acknowledged authoritative state survives the specified member failures. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M11.03-C033-T01 · Named property:** Create a stable property/check name under this parent for “Durable log or equivalent”; copy its required invariant exactly: “Acknowledged authoritative state survives the specified member failures”.
- [ ] **UC-M11.03-C033-T02 · Observable terms:** Define each term in the “Durable log or equivalent” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M11.03-C033-T03 · Precondition set:** List the preconditions under which “Acknowledged authoritative state survives the specified member failures” must hold for “Durable log or equivalent”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M11.03-C033-T04 · Transition coverage:** Map the “Durable log or equivalent” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M11.03-C033-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Durable log or equivalent”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M11.03-C033-T06 · Satisfying fixture:** Create a concrete “Durable log or equivalent” case that satisfies “Acknowledged authoritative state survives the specified member failures”; record its expected observation before running the assertion or review.
- [ ] **UC-M11.03-C033-T07 · Violating fixture:** Create the source counterexample “A member acknowledges a state update before required durability” for “Durable log or equivalent”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M11.03-C033-T08 · Enforcement evidence:** Exercise the “Durable log or equivalent” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M11.03-C033-T09 · Regression linkage:** Link the “Durable log or equivalent” property to changes in replicated desired state, durable protocol state and authoritative commit decisions; record which dependency or contract changes require rerunning it.
- [ ] **UC-M11.03-C033-T10 · Property disposition:** Compare the satisfying and violating “Durable log or equivalent” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M11.03-C034 · Integration

**Original checklist item:** Integrate durable log or equivalent with replicated desired state, durable protocol state and authoritative commit decisions; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M11.03-C034-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Durable log or equivalent” across replicated desired state, durable protocol state and authoritative commit decisions; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M11.03-C034-T02 · Field mapping:** Map every “Durable log or equivalent” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M11.03-C034-T03 · Prerequisite identities:** Record the actual prerequisites for “Durable log or equivalent” (source dependency list: UC-M07.01, UC-M11.02); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M11.03-C034-T04 · Ownership agreement:** Specify who owns “Durable log or equivalent” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M11.03-C034-T05 · Handoff implementation:** Connect “Durable log or equivalent” through the mapped seam using the real adapter or explicit specification reference; preserve “Acknowledged authoritative state survives the specified member failures” across the handoff.
- [ ] **UC-M11.03-C034-T06 · Absent-input case:** Omit one required “Durable log or equivalent” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M11.03-C034-T07 · Stale-input case:** Supply an outdated “Durable log or equivalent” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M11.03-C034-T08 · Incompatible-input case:** Supply an incompatible “Durable log or equivalent” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M11.03-C034-T09 · Valid integration trace:** Run a valid “Durable log or equivalent” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M11.03-C034-T10 · Seam review:** Reconcile the “Durable log or equivalent” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M11.03-C035 · Valid-case test

**Original checklist item:** Run a valid-path fixture for durable log or equivalent; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M11.03-C035-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Durable log or equivalent” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M11.03-C035-T02 · Expected-result oracle:** Specify the “Durable log or equivalent” expected result independently of the implementation output; include the property “Acknowledged authoritative state survives the specified member failures” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M11.03-C035-T03 · Fixture material:** Create the concrete “Durable log or equivalent” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M11.03-C035-T04 · Target preparation:** Prepare the “Durable log or equivalent” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M11.03-C035-T05 · Initial-state record:** Record the initial “Durable log or equivalent” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M11.03-C035-T06 · Valid-path execution:** Execute the “Durable log or equivalent” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M11.03-C035-T07 · Outcome comparison:** Compare every declared “Durable log or equivalent” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M11.03-C035-T08 · State and bounds check:** Inspect the “Durable log or equivalent” ownership/state effects and actual use of “Log entries and persistence latency”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M11.03-C035-T09 · Repeatability check:** Repeat the same “Durable log or equivalent” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M11.03-C035-T10 · Positive evidence:** Attach the “Durable log or equivalent” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M11.03-C036 · Negative test

**Original checklist item:** Negative case: A member acknowledges a state update before required durability. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M11.03-C036-T01 · Adverse-case definition:** Create a test record for the exact “Durable log or equivalent” source counterexample: “A member acknowledges a state update before required durability”; state which precondition or invariant it challenges.
- [ ] **UC-M11.03-C036-T02 · Safe fixture boundary:** Define the contained test boundary for “Durable log or equivalent”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M11.03-C036-T03 · Valid control:** Construct a valid “Durable log or equivalent” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M11.03-C036-T04 · Minimal adverse input:** Derive the “Durable log or equivalent” adverse fixture from the control with the smallest documented change needed to reproduce “A member acknowledges a state update before required durability”; retain that change as reproducible data.
- [ ] **UC-M11.03-C036-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Durable log or equivalent”; require “Acknowledged authoritative state survives the specified member failures” and forbid a false-success verdict.
- [ ] **UC-M11.03-C036-T06 · Adverse execution:** Exercise the “Durable log or equivalent” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M11.03-C036-T07 · Effect inspection:** Inspect “Durable log or equivalent” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M11.03-C036-T08 · Refusal versus failure:** Confirm the “Durable log or equivalent” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M11.03-C036-T09 · Reset and retention:** Restore only the disposable “Durable log or equivalent” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M11.03-C036-T10 · Negative regression:** Register the “Durable log or equivalent” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M11.03-C037 · Change / failure test

**Original checklist item:** Exercise durable log or equivalent when leadership changes during a network partition in the declared topology; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M11.03-C037-T01 · Scenario record:** Write the “Durable log or equivalent” change/failure scenario exactly as supplied: leadership changes during a network partition in the declared topology; identify the property that must remain true: “Acknowledged authoritative state survives the specified member failures”.
- [ ] **UC-M11.03-C037-T02 · Baseline capture:** Create a known-valid “Durable log or equivalent” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M11.03-C037-T03 · Injection map:** Locate the “Durable log or equivalent” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M11.03-C037-T04 · Disposition oracle:** Define the legal intermediate and final “Durable log or equivalent” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M11.03-C037-T05 · Controlled trigger:** Introduce the controlled “Durable log or equivalent” scenario in the disposable fixture: leadership changes during a network partition in the declared topology; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M11.03-C037-T06 · Intermediate inspection:** Inspect the “Durable log or equivalent” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M11.03-C037-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Durable log or equivalent”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M11.03-C037-T08 · Stale-evidence cleanup:** Invalidate superseded “Durable log or equivalent” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M11.03-C037-T09 · Repeat and compare:** Repeat the selected “Durable log or equivalent” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M11.03-C037-T10 · Failure evidence:** Publish the “Durable log or equivalent” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M11.03-C038 · Bounds

**Original checklist item:** Choose, document and test limits for log entries and persistence latency; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M11.03-C038-T01 · Quantity inventory:** Create a measurement inventory for “Durable log or equivalent”: “Log entries and persistence latency”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M11.03-C038-T02 · Measurement method:** Choose how to observe each “Durable log or equivalent” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M11.03-C038-T03 · Budget decision:** Select justified resource and input limits for “Durable log or equivalent”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M11.03-C038-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Durable log or equivalent” cases for “Log entries and persistence latency”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M11.03-C038-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Durable log or equivalent” limit; preserve “Acknowledged authoritative state survives the specified member failures”.
- [ ] **UC-M11.03-C038-T06 · Normal measurement:** Run or review the normal “Durable log or equivalent” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M11.03-C038-T07 · At-limit measurement:** Exercise the “Durable log or equivalent” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M11.03-C038-T08 · Over-limit measurement:** Exercise the “Durable log or equivalent” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M11.03-C038-T09 · Uncovered-scope report:** List the “Durable log or equivalent” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M11.03-C038-T10 · Limit evidence:** Publish the selected “Durable log or equivalent” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M11.03-C039 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for durable log or equivalent with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M11.03-C039-T01 · Event inventory:** List the “Durable log or equivalent” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M11.03-C039-T02 · Diagnostic schema:** Define nonsecret fields for “Durable log or equivalent” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M11.03-C039-T03 · Failure mapping:** Map each documented “Durable log or equivalent” refusal or error to a diagnostic outcome; include “A member acknowledges a state update before required durability” and prohibit conversion into a success message.
- [ ] **UC-M11.03-C039-T04 · Emission path:** Add the “Durable log or equivalent” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M11.03-C039-T05 · Redaction check:** Test “Durable log or equivalent” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M11.03-C039-T06 · Output budget:** Set and exercise bounded “Durable log or equivalent” message size, rate and retention compatible with “Log entries and persistence latency”; define truncation behavior that preserves the final reason.
- [ ] **UC-M11.03-C039-T07 · Success/refusal fixtures:** Capture “Durable log or equivalent” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M11.03-C039-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Durable log or equivalent” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M11.03-C039-T09 · Operator review:** Read the “Durable log or equivalent” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M11.03-C039-T10 · Diagnostic evidence:** Publish redacted “Durable log or equivalent” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M11.03-C040 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for durable log or equivalent; label unexecuted checks as untested.

- [ ] **UC-M11.03-C040-T01 · Evidence inventory:** List the “Durable log or equivalent” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M11.03-C040-T02 · Artifact references:** Record the exact “Durable log or equivalent” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M11.03-C040-T03 · Fixture references:** Attach the “Durable log or equivalent” fixture IDs, input identities and oracle definition; preserve the source counterexample “A member acknowledges a state update before required durability” as a distinct evidence case.
- [ ] **UC-M11.03-C040-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Durable log or equivalent”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M11.03-C040-T05 · Environment record:** Record the actual “Durable log or equivalent” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M11.03-C040-T06 · Expected versus observed:** Pair every “Durable log or equivalent” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M11.03-C040-T07 · Failure and limit records:** Attach “Durable log or equivalent” change/failure and bounds evidence where required; include uncovered “Log entries and persistence latency” and unresolved violations of “Acknowledged authoritative state survives the specified member failures”.
- [ ] **UC-M11.03-C040-T08 · Evidence hygiene:** Check the “Durable log or equivalent” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M11.03-C040-T09 · Reproduction review:** Have the “Durable log or equivalent” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M11.03-C040-T10 · Acceptance linkage:** Link the “Durable log or equivalent” evidence to its parent and UC-M11.03 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 05. Leader and term handling

**Source delivery:** Implement the selected leadership and epoch rules without inventing shortcuts.

**Source invariant:** Stale leadership cannot authorize conflicting committed state.

**Source negative case:** A former leader continues accepting writes after losing authority.

**Source bounded quantities:** Terms, election activity and retained history.

### UC-M11.03-C041 · Contract

**Original checklist item:** Specify leader and term handling inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M11.03-C041-T01 · Scope statement:** Draft the operation boundary for “Leader and term handling” within Durable consensus control store; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M11.03-C041-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Leader and term handling”; record each producer, representation and missing-value meaning.
- [ ] **UC-M11.03-C041-T03 · Output inventory:** List the outputs of “Leader and term handling” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M11.03-C041-T04 · Field dictionary:** Create a field-and-term dictionary for “Leader and term handling”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M11.03-C041-T05 · Prerequisite contract:** Map “Leader and term handling” to the source component prerequisites (UC-M07.01, UC-M11.02); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M11.03-C041-T06 · Authority map:** Identify who may produce, change and consume “Leader and term handling”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M11.03-C041-T07 · Invariant clause:** Add a normative clause for “Leader and term handling” that preserves “Stale leadership cannot authorize conflicting committed state”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M11.03-C041-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Leader and term handling”; include the source counterexample “A former leader continues accepting writes after losing authority” and the intended safe disposition.
- [ ] **UC-M11.03-C041-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Terms, election activity and retained history” in the “Leader and term handling” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M11.03-C041-T10 · Contract review:** Review the “Leader and term handling” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M11.03-C042 · Delivery

**Original checklist item:** Implement the selected leadership and epoch rules without inventing shortcuts.

- [ ] **UC-M11.03-C042-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Leader and term handling”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M11.03-C042-T02 · Change plan:** Break the source delivery for “Leader and term handling” into concrete edit targets and reviewable outputs; keep the UC-M11.03 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M11.03-C042-T03 · Core artifact:** Implement the smallest selected-profile change for “Leader and term handling” that realizes this source instruction: Implement the selected leadership and epoch rules without inventing shortcuts.
- [ ] **UC-M11.03-C042-T04 · Concrete realization:** Trace “Leader and term handling” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M11.03-C042-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Leader and term handling” needed to preserve “Stale leadership cannot authorize conflicting committed state”; record an enforcement gap where only a model exists.
- [ ] **UC-M11.03-C042-T06 · Dependency connection:** Connect the “Leader and term handling” implementation to replicated desired state, durable protocol state and authoritative commit decisions; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M11.03-C042-T07 · Resource behavior:** Account for “Terms, election activity and retained history” in “Leader and term handling”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M11.03-C042-T08 · Delivery check:** Run the smallest real “Leader and term handling” path and its adverse fixture “A former leader continues accepting writes after losing authority”; retain actual output, state effects and final disposition.
- [ ] **UC-M11.03-C042-T09 · Patch review:** Review the “Leader and term handling” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M11.03-C042-T10 · Delivery handoff:** Publish the “Leader and term handling” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M11.03-C043 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Stale leadership cannot authorize conflicting committed state. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M11.03-C043-T01 · Named property:** Create a stable property/check name under this parent for “Leader and term handling”; copy its required invariant exactly: “Stale leadership cannot authorize conflicting committed state”.
- [ ] **UC-M11.03-C043-T02 · Observable terms:** Define each term in the “Leader and term handling” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M11.03-C043-T03 · Precondition set:** List the preconditions under which “Stale leadership cannot authorize conflicting committed state” must hold for “Leader and term handling”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M11.03-C043-T04 · Transition coverage:** Map the “Leader and term handling” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M11.03-C043-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Leader and term handling”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M11.03-C043-T06 · Satisfying fixture:** Create a concrete “Leader and term handling” case that satisfies “Stale leadership cannot authorize conflicting committed state”; record its expected observation before running the assertion or review.
- [ ] **UC-M11.03-C043-T07 · Violating fixture:** Create the source counterexample “A former leader continues accepting writes after losing authority” for “Leader and term handling”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M11.03-C043-T08 · Enforcement evidence:** Exercise the “Leader and term handling” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M11.03-C043-T09 · Regression linkage:** Link the “Leader and term handling” property to changes in replicated desired state, durable protocol state and authoritative commit decisions; record which dependency or contract changes require rerunning it.
- [ ] **UC-M11.03-C043-T10 · Property disposition:** Compare the satisfying and violating “Leader and term handling” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M11.03-C044 · Integration

**Original checklist item:** Integrate leader and term handling with replicated desired state, durable protocol state and authoritative commit decisions; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M11.03-C044-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Leader and term handling” across replicated desired state, durable protocol state and authoritative commit decisions; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M11.03-C044-T02 · Field mapping:** Map every “Leader and term handling” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M11.03-C044-T03 · Prerequisite identities:** Record the actual prerequisites for “Leader and term handling” (source dependency list: UC-M07.01, UC-M11.02); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M11.03-C044-T04 · Ownership agreement:** Specify who owns “Leader and term handling” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M11.03-C044-T05 · Handoff implementation:** Connect “Leader and term handling” through the mapped seam using the real adapter or explicit specification reference; preserve “Stale leadership cannot authorize conflicting committed state” across the handoff.
- [ ] **UC-M11.03-C044-T06 · Absent-input case:** Omit one required “Leader and term handling” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M11.03-C044-T07 · Stale-input case:** Supply an outdated “Leader and term handling” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M11.03-C044-T08 · Incompatible-input case:** Supply an incompatible “Leader and term handling” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M11.03-C044-T09 · Valid integration trace:** Run a valid “Leader and term handling” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M11.03-C044-T10 · Seam review:** Reconcile the “Leader and term handling” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M11.03-C045 · Valid-case test

**Original checklist item:** Run a valid-path fixture for leader and term handling; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M11.03-C045-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Leader and term handling” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M11.03-C045-T02 · Expected-result oracle:** Specify the “Leader and term handling” expected result independently of the implementation output; include the property “Stale leadership cannot authorize conflicting committed state” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M11.03-C045-T03 · Fixture material:** Create the concrete “Leader and term handling” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M11.03-C045-T04 · Target preparation:** Prepare the “Leader and term handling” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M11.03-C045-T05 · Initial-state record:** Record the initial “Leader and term handling” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M11.03-C045-T06 · Valid-path execution:** Execute the “Leader and term handling” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M11.03-C045-T07 · Outcome comparison:** Compare every declared “Leader and term handling” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M11.03-C045-T08 · State and bounds check:** Inspect the “Leader and term handling” ownership/state effects and actual use of “Terms, election activity and retained history”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M11.03-C045-T09 · Repeatability check:** Repeat the same “Leader and term handling” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M11.03-C045-T10 · Positive evidence:** Attach the “Leader and term handling” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M11.03-C046 · Negative test

**Original checklist item:** Negative case: A former leader continues accepting writes after losing authority. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M11.03-C046-T01 · Adverse-case definition:** Create a test record for the exact “Leader and term handling” source counterexample: “A former leader continues accepting writes after losing authority”; state which precondition or invariant it challenges.
- [ ] **UC-M11.03-C046-T02 · Safe fixture boundary:** Define the contained test boundary for “Leader and term handling”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M11.03-C046-T03 · Valid control:** Construct a valid “Leader and term handling” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M11.03-C046-T04 · Minimal adverse input:** Derive the “Leader and term handling” adverse fixture from the control with the smallest documented change needed to reproduce “A former leader continues accepting writes after losing authority”; retain that change as reproducible data.
- [ ] **UC-M11.03-C046-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Leader and term handling”; require “Stale leadership cannot authorize conflicting committed state” and forbid a false-success verdict.
- [ ] **UC-M11.03-C046-T06 · Adverse execution:** Exercise the “Leader and term handling” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M11.03-C046-T07 · Effect inspection:** Inspect “Leader and term handling” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M11.03-C046-T08 · Refusal versus failure:** Confirm the “Leader and term handling” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M11.03-C046-T09 · Reset and retention:** Restore only the disposable “Leader and term handling” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M11.03-C046-T10 · Negative regression:** Register the “Leader and term handling” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M11.03-C047 · Change / failure test

**Original checklist item:** Exercise leader and term handling when leadership changes during a network partition in the declared topology; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M11.03-C047-T01 · Scenario record:** Write the “Leader and term handling” change/failure scenario exactly as supplied: leadership changes during a network partition in the declared topology; identify the property that must remain true: “Stale leadership cannot authorize conflicting committed state”.
- [ ] **UC-M11.03-C047-T02 · Baseline capture:** Create a known-valid “Leader and term handling” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M11.03-C047-T03 · Injection map:** Locate the “Leader and term handling” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M11.03-C047-T04 · Disposition oracle:** Define the legal intermediate and final “Leader and term handling” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M11.03-C047-T05 · Controlled trigger:** Introduce the controlled “Leader and term handling” scenario in the disposable fixture: leadership changes during a network partition in the declared topology; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M11.03-C047-T06 · Intermediate inspection:** Inspect the “Leader and term handling” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M11.03-C047-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Leader and term handling”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M11.03-C047-T08 · Stale-evidence cleanup:** Invalidate superseded “Leader and term handling” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M11.03-C047-T09 · Repeat and compare:** Repeat the selected “Leader and term handling” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M11.03-C047-T10 · Failure evidence:** Publish the “Leader and term handling” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M11.03-C048 · Bounds

**Original checklist item:** Choose, document and test limits for terms, election activity and retained history; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M11.03-C048-T01 · Quantity inventory:** Create a measurement inventory for “Leader and term handling”: “Terms, election activity and retained history”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M11.03-C048-T02 · Measurement method:** Choose how to observe each “Leader and term handling” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M11.03-C048-T03 · Budget decision:** Select justified resource and input limits for “Leader and term handling”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M11.03-C048-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Leader and term handling” cases for “Terms, election activity and retained history”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M11.03-C048-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Leader and term handling” limit; preserve “Stale leadership cannot authorize conflicting committed state”.
- [ ] **UC-M11.03-C048-T06 · Normal measurement:** Run or review the normal “Leader and term handling” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M11.03-C048-T07 · At-limit measurement:** Exercise the “Leader and term handling” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M11.03-C048-T08 · Over-limit measurement:** Exercise the “Leader and term handling” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M11.03-C048-T09 · Uncovered-scope report:** List the “Leader and term handling” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M11.03-C048-T10 · Limit evidence:** Publish the selected “Leader and term handling” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M11.03-C049 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for leader and term handling with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M11.03-C049-T01 · Event inventory:** List the “Leader and term handling” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M11.03-C049-T02 · Diagnostic schema:** Define nonsecret fields for “Leader and term handling” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M11.03-C049-T03 · Failure mapping:** Map each documented “Leader and term handling” refusal or error to a diagnostic outcome; include “A former leader continues accepting writes after losing authority” and prohibit conversion into a success message.
- [ ] **UC-M11.03-C049-T04 · Emission path:** Add the “Leader and term handling” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M11.03-C049-T05 · Redaction check:** Test “Leader and term handling” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M11.03-C049-T06 · Output budget:** Set and exercise bounded “Leader and term handling” message size, rate and retention compatible with “Terms, election activity and retained history”; define truncation behavior that preserves the final reason.
- [ ] **UC-M11.03-C049-T07 · Success/refusal fixtures:** Capture “Leader and term handling” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M11.03-C049-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Leader and term handling” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M11.03-C049-T09 · Operator review:** Read the “Leader and term handling” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M11.03-C049-T10 · Diagnostic evidence:** Publish redacted “Leader and term handling” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M11.03-C050 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for leader and term handling; label unexecuted checks as untested.

- [ ] **UC-M11.03-C050-T01 · Evidence inventory:** List the “Leader and term handling” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M11.03-C050-T02 · Artifact references:** Record the exact “Leader and term handling” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M11.03-C050-T03 · Fixture references:** Attach the “Leader and term handling” fixture IDs, input identities and oracle definition; preserve the source counterexample “A former leader continues accepting writes after losing authority” as a distinct evidence case.
- [ ] **UC-M11.03-C050-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Leader and term handling”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M11.03-C050-T05 · Environment record:** Record the actual “Leader and term handling” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M11.03-C050-T06 · Expected versus observed:** Pair every “Leader and term handling” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M11.03-C050-T07 · Failure and limit records:** Attach “Leader and term handling” change/failure and bounds evidence where required; include uncovered “Terms, election activity and retained history” and unresolved violations of “Stale leadership cannot authorize conflicting committed state”.
- [ ] **UC-M11.03-C050-T08 · Evidence hygiene:** Check the “Leader and term handling” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M11.03-C050-T09 · Reproduction review:** Have the “Leader and term handling” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M11.03-C050-T10 · Acceptance linkage:** Link the “Leader and term handling” evidence to its parent and UC-M11.03 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 06. Commit criteria

**Source delivery:** Apply the chosen protocol's exact commit and acknowledgment conditions.

**Source invariant:** Uncommitted replication is not reported as durable committed state.

**Source negative case:** A single isolated member reports a write committed without required agreement.

**Source bounded quantities:** Acknowledgments and commit deadline assumptions.

### UC-M11.03-C051 · Contract

**Original checklist item:** Specify commit criteria inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M11.03-C051-T01 · Scope statement:** Draft the operation boundary for “Commit criteria” within Durable consensus control store; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M11.03-C051-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Commit criteria”; record each producer, representation and missing-value meaning.
- [ ] **UC-M11.03-C051-T03 · Output inventory:** List the outputs of “Commit criteria” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M11.03-C051-T04 · Field dictionary:** Create a field-and-term dictionary for “Commit criteria”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M11.03-C051-T05 · Prerequisite contract:** Map “Commit criteria” to the source component prerequisites (UC-M07.01, UC-M11.02); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M11.03-C051-T06 · Authority map:** Identify who may produce, change and consume “Commit criteria”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M11.03-C051-T07 · Invariant clause:** Add a normative clause for “Commit criteria” that preserves “Uncommitted replication is not reported as durable committed state”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M11.03-C051-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Commit criteria”; include the source counterexample “A single isolated member reports a write committed without required agreement” and the intended safe disposition.
- [ ] **UC-M11.03-C051-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Acknowledgments and commit deadline assumptions” in the “Commit criteria” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M11.03-C051-T10 · Contract review:** Review the “Commit criteria” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M11.03-C052 · Delivery

**Original checklist item:** Apply the chosen protocol's exact commit and acknowledgment conditions.

- [ ] **UC-M11.03-C052-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Commit criteria”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M11.03-C052-T02 · Change plan:** Break the source delivery for “Commit criteria” into concrete edit targets and reviewable outputs; keep the UC-M11.03 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M11.03-C052-T03 · Core artifact:** Implement the smallest selected-profile change for “Commit criteria” that realizes this source instruction: Apply the chosen protocol's exact commit and acknowledgment conditions.
- [ ] **UC-M11.03-C052-T04 · Concrete realization:** Trace “Commit criteria” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M11.03-C052-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Commit criteria” needed to preserve “Uncommitted replication is not reported as durable committed state”; record an enforcement gap where only a model exists.
- [ ] **UC-M11.03-C052-T06 · Dependency connection:** Connect the “Commit criteria” implementation to replicated desired state, durable protocol state and authoritative commit decisions; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M11.03-C052-T07 · Resource behavior:** Account for “Acknowledgments and commit deadline assumptions” in “Commit criteria”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M11.03-C052-T08 · Delivery check:** Run the smallest real “Commit criteria” path and its adverse fixture “A single isolated member reports a write committed without required agreement”; retain actual output, state effects and final disposition.
- [ ] **UC-M11.03-C052-T09 · Patch review:** Review the “Commit criteria” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M11.03-C052-T10 · Delivery handoff:** Publish the “Commit criteria” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M11.03-C053 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Uncommitted replication is not reported as durable committed state. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M11.03-C053-T01 · Named property:** Create a stable property/check name under this parent for “Commit criteria”; copy its required invariant exactly: “Uncommitted replication is not reported as durable committed state”.
- [ ] **UC-M11.03-C053-T02 · Observable terms:** Define each term in the “Commit criteria” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M11.03-C053-T03 · Precondition set:** List the preconditions under which “Uncommitted replication is not reported as durable committed state” must hold for “Commit criteria”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M11.03-C053-T04 · Transition coverage:** Map the “Commit criteria” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M11.03-C053-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Commit criteria”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M11.03-C053-T06 · Satisfying fixture:** Create a concrete “Commit criteria” case that satisfies “Uncommitted replication is not reported as durable committed state”; record its expected observation before running the assertion or review.
- [ ] **UC-M11.03-C053-T07 · Violating fixture:** Create the source counterexample “A single isolated member reports a write committed without required agreement” for “Commit criteria”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M11.03-C053-T08 · Enforcement evidence:** Exercise the “Commit criteria” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M11.03-C053-T09 · Regression linkage:** Link the “Commit criteria” property to changes in replicated desired state, durable protocol state and authoritative commit decisions; record which dependency or contract changes require rerunning it.
- [ ] **UC-M11.03-C053-T10 · Property disposition:** Compare the satisfying and violating “Commit criteria” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M11.03-C054 · Integration

**Original checklist item:** Integrate commit criteria with replicated desired state, durable protocol state and authoritative commit decisions; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M11.03-C054-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Commit criteria” across replicated desired state, durable protocol state and authoritative commit decisions; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M11.03-C054-T02 · Field mapping:** Map every “Commit criteria” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M11.03-C054-T03 · Prerequisite identities:** Record the actual prerequisites for “Commit criteria” (source dependency list: UC-M07.01, UC-M11.02); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M11.03-C054-T04 · Ownership agreement:** Specify who owns “Commit criteria” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M11.03-C054-T05 · Handoff implementation:** Connect “Commit criteria” through the mapped seam using the real adapter or explicit specification reference; preserve “Uncommitted replication is not reported as durable committed state” across the handoff.
- [ ] **UC-M11.03-C054-T06 · Absent-input case:** Omit one required “Commit criteria” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M11.03-C054-T07 · Stale-input case:** Supply an outdated “Commit criteria” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M11.03-C054-T08 · Incompatible-input case:** Supply an incompatible “Commit criteria” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M11.03-C054-T09 · Valid integration trace:** Run a valid “Commit criteria” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M11.03-C054-T10 · Seam review:** Reconcile the “Commit criteria” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M11.03-C055 · Valid-case test

**Original checklist item:** Run a valid-path fixture for commit criteria; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M11.03-C055-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Commit criteria” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M11.03-C055-T02 · Expected-result oracle:** Specify the “Commit criteria” expected result independently of the implementation output; include the property “Uncommitted replication is not reported as durable committed state” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M11.03-C055-T03 · Fixture material:** Create the concrete “Commit criteria” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M11.03-C055-T04 · Target preparation:** Prepare the “Commit criteria” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M11.03-C055-T05 · Initial-state record:** Record the initial “Commit criteria” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M11.03-C055-T06 · Valid-path execution:** Execute the “Commit criteria” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M11.03-C055-T07 · Outcome comparison:** Compare every declared “Commit criteria” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M11.03-C055-T08 · State and bounds check:** Inspect the “Commit criteria” ownership/state effects and actual use of “Acknowledgments and commit deadline assumptions”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M11.03-C055-T09 · Repeatability check:** Repeat the same “Commit criteria” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M11.03-C055-T10 · Positive evidence:** Attach the “Commit criteria” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M11.03-C056 · Negative test

**Original checklist item:** Negative case: A single isolated member reports a write committed without required agreement. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M11.03-C056-T01 · Adverse-case definition:** Create a test record for the exact “Commit criteria” source counterexample: “A single isolated member reports a write committed without required agreement”; state which precondition or invariant it challenges.
- [ ] **UC-M11.03-C056-T02 · Safe fixture boundary:** Define the contained test boundary for “Commit criteria”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M11.03-C056-T03 · Valid control:** Construct a valid “Commit criteria” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M11.03-C056-T04 · Minimal adverse input:** Derive the “Commit criteria” adverse fixture from the control with the smallest documented change needed to reproduce “A single isolated member reports a write committed without required agreement”; retain that change as reproducible data.
- [ ] **UC-M11.03-C056-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Commit criteria”; require “Uncommitted replication is not reported as durable committed state” and forbid a false-success verdict.
- [ ] **UC-M11.03-C056-T06 · Adverse execution:** Exercise the “Commit criteria” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M11.03-C056-T07 · Effect inspection:** Inspect “Commit criteria” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M11.03-C056-T08 · Refusal versus failure:** Confirm the “Commit criteria” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M11.03-C056-T09 · Reset and retention:** Restore only the disposable “Commit criteria” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M11.03-C056-T10 · Negative regression:** Register the “Commit criteria” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M11.03-C057 · Change / failure test

**Original checklist item:** Exercise commit criteria when leadership changes during a network partition in the declared topology; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M11.03-C057-T01 · Scenario record:** Write the “Commit criteria” change/failure scenario exactly as supplied: leadership changes during a network partition in the declared topology; identify the property that must remain true: “Uncommitted replication is not reported as durable committed state”.
- [ ] **UC-M11.03-C057-T02 · Baseline capture:** Create a known-valid “Commit criteria” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M11.03-C057-T03 · Injection map:** Locate the “Commit criteria” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M11.03-C057-T04 · Disposition oracle:** Define the legal intermediate and final “Commit criteria” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M11.03-C057-T05 · Controlled trigger:** Introduce the controlled “Commit criteria” scenario in the disposable fixture: leadership changes during a network partition in the declared topology; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M11.03-C057-T06 · Intermediate inspection:** Inspect the “Commit criteria” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M11.03-C057-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Commit criteria”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M11.03-C057-T08 · Stale-evidence cleanup:** Invalidate superseded “Commit criteria” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M11.03-C057-T09 · Repeat and compare:** Repeat the selected “Commit criteria” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M11.03-C057-T10 · Failure evidence:** Publish the “Commit criteria” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M11.03-C058 · Bounds

**Original checklist item:** Choose, document and test limits for acknowledgments and commit deadline assumptions; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M11.03-C058-T01 · Quantity inventory:** Create a measurement inventory for “Commit criteria”: “Acknowledgments and commit deadline assumptions”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M11.03-C058-T02 · Measurement method:** Choose how to observe each “Commit criteria” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M11.03-C058-T03 · Budget decision:** Select justified resource and input limits for “Commit criteria”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M11.03-C058-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Commit criteria” cases for “Acknowledgments and commit deadline assumptions”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M11.03-C058-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Commit criteria” limit; preserve “Uncommitted replication is not reported as durable committed state”.
- [ ] **UC-M11.03-C058-T06 · Normal measurement:** Run or review the normal “Commit criteria” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M11.03-C058-T07 · At-limit measurement:** Exercise the “Commit criteria” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M11.03-C058-T08 · Over-limit measurement:** Exercise the “Commit criteria” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M11.03-C058-T09 · Uncovered-scope report:** List the “Commit criteria” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M11.03-C058-T10 · Limit evidence:** Publish the selected “Commit criteria” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M11.03-C059 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for commit criteria with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M11.03-C059-T01 · Event inventory:** List the “Commit criteria” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M11.03-C059-T02 · Diagnostic schema:** Define nonsecret fields for “Commit criteria” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M11.03-C059-T03 · Failure mapping:** Map each documented “Commit criteria” refusal or error to a diagnostic outcome; include “A single isolated member reports a write committed without required agreement” and prohibit conversion into a success message.
- [ ] **UC-M11.03-C059-T04 · Emission path:** Add the “Commit criteria” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M11.03-C059-T05 · Redaction check:** Test “Commit criteria” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M11.03-C059-T06 · Output budget:** Set and exercise bounded “Commit criteria” message size, rate and retention compatible with “Acknowledgments and commit deadline assumptions”; define truncation behavior that preserves the final reason.
- [ ] **UC-M11.03-C059-T07 · Success/refusal fixtures:** Capture “Commit criteria” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M11.03-C059-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Commit criteria” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M11.03-C059-T09 · Operator review:** Read the “Commit criteria” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M11.03-C059-T10 · Diagnostic evidence:** Publish redacted “Commit criteria” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M11.03-C060 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for commit criteria; label unexecuted checks as untested.

- [ ] **UC-M11.03-C060-T01 · Evidence inventory:** List the “Commit criteria” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M11.03-C060-T02 · Artifact references:** Record the exact “Commit criteria” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M11.03-C060-T03 · Fixture references:** Attach the “Commit criteria” fixture IDs, input identities and oracle definition; preserve the source counterexample “A single isolated member reports a write committed without required agreement” as a distinct evidence case.
- [ ] **UC-M11.03-C060-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Commit criteria”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M11.03-C060-T05 · Environment record:** Record the actual “Commit criteria” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M11.03-C060-T06 · Expected versus observed:** Pair every “Commit criteria” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M11.03-C060-T07 · Failure and limit records:** Attach “Commit criteria” change/failure and bounds evidence where required; include uncovered “Acknowledgments and commit deadline assumptions” and unresolved violations of “Uncommitted replication is not reported as durable committed state”.
- [ ] **UC-M11.03-C060-T08 · Evidence hygiene:** Check the “Commit criteria” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M11.03-C060-T09 · Reproduction review:** Have the “Commit criteria” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M11.03-C060-T10 · Acceptance linkage:** Link the “Commit criteria” evidence to its parent and UC-M11.03 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 07. Membership changes

**Source delivery:** Use the selected protocol's supported membership transition procedure.

**Source invariant:** Membership changes preserve the stated single-writer safety model.

**Source negative case:** Members are removed ad hoc until an unsafe quorum appears available.

**Source bounded quantities:** Membership changes and configuration history.

### UC-M11.03-C061 · Contract

**Original checklist item:** Specify membership changes inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M11.03-C061-T01 · Scope statement:** Draft the operation boundary for “Membership changes” within Durable consensus control store; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M11.03-C061-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Membership changes”; record each producer, representation and missing-value meaning.
- [ ] **UC-M11.03-C061-T03 · Output inventory:** List the outputs of “Membership changes” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M11.03-C061-T04 · Field dictionary:** Create a field-and-term dictionary for “Membership changes”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M11.03-C061-T05 · Prerequisite contract:** Map “Membership changes” to the source component prerequisites (UC-M07.01, UC-M11.02); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M11.03-C061-T06 · Authority map:** Identify who may produce, change and consume “Membership changes”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M11.03-C061-T07 · Invariant clause:** Add a normative clause for “Membership changes” that preserves “Membership changes preserve the stated single-writer safety model”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M11.03-C061-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Membership changes”; include the source counterexample “Members are removed ad hoc until an unsafe quorum appears available” and the intended safe disposition.
- [ ] **UC-M11.03-C061-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Membership changes and configuration history” in the “Membership changes” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M11.03-C061-T10 · Contract review:** Review the “Membership changes” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M11.03-C062 · Delivery

**Original checklist item:** Use the selected protocol's supported membership transition procedure.

- [ ] **UC-M11.03-C062-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Membership changes”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M11.03-C062-T02 · Change plan:** Break the source delivery for “Membership changes” into concrete edit targets and reviewable outputs; keep the UC-M11.03 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M11.03-C062-T03 · Core artifact:** Implement the smallest selected-profile change for “Membership changes” that realizes this source instruction: Use the selected protocol's supported membership transition procedure.
- [ ] **UC-M11.03-C062-T04 · Concrete realization:** Trace “Membership changes” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M11.03-C062-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Membership changes” needed to preserve “Membership changes preserve the stated single-writer safety model”; record an enforcement gap where only a model exists.
- [ ] **UC-M11.03-C062-T06 · Dependency connection:** Connect the “Membership changes” implementation to replicated desired state, durable protocol state and authoritative commit decisions; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M11.03-C062-T07 · Resource behavior:** Account for “Membership changes and configuration history” in “Membership changes”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M11.03-C062-T08 · Delivery check:** Run the smallest real “Membership changes” path and its adverse fixture “Members are removed ad hoc until an unsafe quorum appears available”; retain actual output, state effects and final disposition.
- [ ] **UC-M11.03-C062-T09 · Patch review:** Review the “Membership changes” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M11.03-C062-T10 · Delivery handoff:** Publish the “Membership changes” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M11.03-C063 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Membership changes preserve the stated single-writer safety model. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M11.03-C063-T01 · Named property:** Create a stable property/check name under this parent for “Membership changes”; copy its required invariant exactly: “Membership changes preserve the stated single-writer safety model”.
- [ ] **UC-M11.03-C063-T02 · Observable terms:** Define each term in the “Membership changes” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M11.03-C063-T03 · Precondition set:** List the preconditions under which “Membership changes preserve the stated single-writer safety model” must hold for “Membership changes”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M11.03-C063-T04 · Transition coverage:** Map the “Membership changes” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M11.03-C063-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Membership changes”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M11.03-C063-T06 · Satisfying fixture:** Create a concrete “Membership changes” case that satisfies “Membership changes preserve the stated single-writer safety model”; record its expected observation before running the assertion or review.
- [ ] **UC-M11.03-C063-T07 · Violating fixture:** Create the source counterexample “Members are removed ad hoc until an unsafe quorum appears available” for “Membership changes”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M11.03-C063-T08 · Enforcement evidence:** Exercise the “Membership changes” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M11.03-C063-T09 · Regression linkage:** Link the “Membership changes” property to changes in replicated desired state, durable protocol state and authoritative commit decisions; record which dependency or contract changes require rerunning it.
- [ ] **UC-M11.03-C063-T10 · Property disposition:** Compare the satisfying and violating “Membership changes” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M11.03-C064 · Integration

**Original checklist item:** Integrate membership changes with replicated desired state, durable protocol state and authoritative commit decisions; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M11.03-C064-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Membership changes” across replicated desired state, durable protocol state and authoritative commit decisions; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M11.03-C064-T02 · Field mapping:** Map every “Membership changes” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M11.03-C064-T03 · Prerequisite identities:** Record the actual prerequisites for “Membership changes” (source dependency list: UC-M07.01, UC-M11.02); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M11.03-C064-T04 · Ownership agreement:** Specify who owns “Membership changes” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M11.03-C064-T05 · Handoff implementation:** Connect “Membership changes” through the mapped seam using the real adapter or explicit specification reference; preserve “Membership changes preserve the stated single-writer safety model” across the handoff.
- [ ] **UC-M11.03-C064-T06 · Absent-input case:** Omit one required “Membership changes” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M11.03-C064-T07 · Stale-input case:** Supply an outdated “Membership changes” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M11.03-C064-T08 · Incompatible-input case:** Supply an incompatible “Membership changes” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M11.03-C064-T09 · Valid integration trace:** Run a valid “Membership changes” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M11.03-C064-T10 · Seam review:** Reconcile the “Membership changes” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M11.03-C065 · Valid-case test

**Original checklist item:** Run a valid-path fixture for membership changes; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M11.03-C065-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Membership changes” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M11.03-C065-T02 · Expected-result oracle:** Specify the “Membership changes” expected result independently of the implementation output; include the property “Membership changes preserve the stated single-writer safety model” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M11.03-C065-T03 · Fixture material:** Create the concrete “Membership changes” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M11.03-C065-T04 · Target preparation:** Prepare the “Membership changes” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M11.03-C065-T05 · Initial-state record:** Record the initial “Membership changes” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M11.03-C065-T06 · Valid-path execution:** Execute the “Membership changes” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M11.03-C065-T07 · Outcome comparison:** Compare every declared “Membership changes” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M11.03-C065-T08 · State and bounds check:** Inspect the “Membership changes” ownership/state effects and actual use of “Membership changes and configuration history”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M11.03-C065-T09 · Repeatability check:** Repeat the same “Membership changes” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M11.03-C065-T10 · Positive evidence:** Attach the “Membership changes” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M11.03-C066 · Negative test

**Original checklist item:** Negative case: Members are removed ad hoc until an unsafe quorum appears available. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M11.03-C066-T01 · Adverse-case definition:** Create a test record for the exact “Membership changes” source counterexample: “Members are removed ad hoc until an unsafe quorum appears available”; state which precondition or invariant it challenges.
- [ ] **UC-M11.03-C066-T02 · Safe fixture boundary:** Define the contained test boundary for “Membership changes”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M11.03-C066-T03 · Valid control:** Construct a valid “Membership changes” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M11.03-C066-T04 · Minimal adverse input:** Derive the “Membership changes” adverse fixture from the control with the smallest documented change needed to reproduce “Members are removed ad hoc until an unsafe quorum appears available”; retain that change as reproducible data.
- [ ] **UC-M11.03-C066-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Membership changes”; require “Membership changes preserve the stated single-writer safety model” and forbid a false-success verdict.
- [ ] **UC-M11.03-C066-T06 · Adverse execution:** Exercise the “Membership changes” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M11.03-C066-T07 · Effect inspection:** Inspect “Membership changes” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M11.03-C066-T08 · Refusal versus failure:** Confirm the “Membership changes” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M11.03-C066-T09 · Reset and retention:** Restore only the disposable “Membership changes” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M11.03-C066-T10 · Negative regression:** Register the “Membership changes” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M11.03-C067 · Change / failure test

**Original checklist item:** Exercise membership changes when leadership changes during a network partition in the declared topology; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M11.03-C067-T01 · Scenario record:** Write the “Membership changes” change/failure scenario exactly as supplied: leadership changes during a network partition in the declared topology; identify the property that must remain true: “Membership changes preserve the stated single-writer safety model”.
- [ ] **UC-M11.03-C067-T02 · Baseline capture:** Create a known-valid “Membership changes” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M11.03-C067-T03 · Injection map:** Locate the “Membership changes” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M11.03-C067-T04 · Disposition oracle:** Define the legal intermediate and final “Membership changes” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M11.03-C067-T05 · Controlled trigger:** Introduce the controlled “Membership changes” scenario in the disposable fixture: leadership changes during a network partition in the declared topology; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M11.03-C067-T06 · Intermediate inspection:** Inspect the “Membership changes” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M11.03-C067-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Membership changes”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M11.03-C067-T08 · Stale-evidence cleanup:** Invalidate superseded “Membership changes” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M11.03-C067-T09 · Repeat and compare:** Repeat the selected “Membership changes” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M11.03-C067-T10 · Failure evidence:** Publish the “Membership changes” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M11.03-C068 · Bounds

**Original checklist item:** Choose, document and test limits for membership changes and configuration history; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M11.03-C068-T01 · Quantity inventory:** Create a measurement inventory for “Membership changes”: “Membership changes and configuration history”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M11.03-C068-T02 · Measurement method:** Choose how to observe each “Membership changes” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M11.03-C068-T03 · Budget decision:** Select justified resource and input limits for “Membership changes”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M11.03-C068-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Membership changes” cases for “Membership changes and configuration history”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M11.03-C068-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Membership changes” limit; preserve “Membership changes preserve the stated single-writer safety model”.
- [ ] **UC-M11.03-C068-T06 · Normal measurement:** Run or review the normal “Membership changes” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M11.03-C068-T07 · At-limit measurement:** Exercise the “Membership changes” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M11.03-C068-T08 · Over-limit measurement:** Exercise the “Membership changes” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M11.03-C068-T09 · Uncovered-scope report:** List the “Membership changes” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M11.03-C068-T10 · Limit evidence:** Publish the selected “Membership changes” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M11.03-C069 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for membership changes with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M11.03-C069-T01 · Event inventory:** List the “Membership changes” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M11.03-C069-T02 · Diagnostic schema:** Define nonsecret fields for “Membership changes” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M11.03-C069-T03 · Failure mapping:** Map each documented “Membership changes” refusal or error to a diagnostic outcome; include “Members are removed ad hoc until an unsafe quorum appears available” and prohibit conversion into a success message.
- [ ] **UC-M11.03-C069-T04 · Emission path:** Add the “Membership changes” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M11.03-C069-T05 · Redaction check:** Test “Membership changes” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M11.03-C069-T06 · Output budget:** Set and exercise bounded “Membership changes” message size, rate and retention compatible with “Membership changes and configuration history”; define truncation behavior that preserves the final reason.
- [ ] **UC-M11.03-C069-T07 · Success/refusal fixtures:** Capture “Membership changes” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M11.03-C069-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Membership changes” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M11.03-C069-T09 · Operator review:** Read the “Membership changes” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M11.03-C069-T10 · Diagnostic evidence:** Publish redacted “Membership changes” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M11.03-C070 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for membership changes; label unexecuted checks as untested.

- [ ] **UC-M11.03-C070-T01 · Evidence inventory:** List the “Membership changes” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M11.03-C070-T02 · Artifact references:** Record the exact “Membership changes” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M11.03-C070-T03 · Fixture references:** Attach the “Membership changes” fixture IDs, input identities and oracle definition; preserve the source counterexample “Members are removed ad hoc until an unsafe quorum appears available” as a distinct evidence case.
- [ ] **UC-M11.03-C070-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Membership changes”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M11.03-C070-T05 · Environment record:** Record the actual “Membership changes” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M11.03-C070-T06 · Expected versus observed:** Pair every “Membership changes” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M11.03-C070-T07 · Failure and limit records:** Attach “Membership changes” change/failure and bounds evidence where required; include uncovered “Membership changes and configuration history” and unresolved violations of “Membership changes preserve the stated single-writer safety model”.
- [ ] **UC-M11.03-C070-T08 · Evidence hygiene:** Check the “Membership changes” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M11.03-C070-T09 · Reproduction review:** Have the “Membership changes” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M11.03-C070-T10 · Acceptance linkage:** Link the “Membership changes” evidence to its parent and UC-M11.03 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 08. Partition behavior

**Source delivery:** Specify which operations remain available or refuse during partial connectivity.

**Source invariant:** Unavailable quorum cannot be hidden by local success responses.

**Source negative case:** Two partitioned groups both publish conflicting authoritative state.

**Source bounded quantities:** Partition patterns and pending writes.

### UC-M11.03-C071 · Contract

**Original checklist item:** Specify partition behavior inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M11.03-C071-T01 · Scope statement:** Draft the operation boundary for “Partition behavior” within Durable consensus control store; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M11.03-C071-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Partition behavior”; record each producer, representation and missing-value meaning.
- [ ] **UC-M11.03-C071-T03 · Output inventory:** List the outputs of “Partition behavior” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M11.03-C071-T04 · Field dictionary:** Create a field-and-term dictionary for “Partition behavior”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M11.03-C071-T05 · Prerequisite contract:** Map “Partition behavior” to the source component prerequisites (UC-M07.01, UC-M11.02); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M11.03-C071-T06 · Authority map:** Identify who may produce, change and consume “Partition behavior”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M11.03-C071-T07 · Invariant clause:** Add a normative clause for “Partition behavior” that preserves “Unavailable quorum cannot be hidden by local success responses”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M11.03-C071-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Partition behavior”; include the source counterexample “Two partitioned groups both publish conflicting authoritative state” and the intended safe disposition.
- [ ] **UC-M11.03-C071-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Partition patterns and pending writes” in the “Partition behavior” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M11.03-C071-T10 · Contract review:** Review the “Partition behavior” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M11.03-C072 · Delivery

**Original checklist item:** Specify which operations remain available or refuse during partial connectivity.

- [ ] **UC-M11.03-C072-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Partition behavior”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M11.03-C072-T02 · Change plan:** Break the source delivery for “Partition behavior” into concrete edit targets and reviewable outputs; keep the UC-M11.03 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M11.03-C072-T03 · Core artifact:** Create the “Partition behavior” model, schema or inventory that realizes this source instruction: Specify which operations remain available or refuse during partial connectivity.
- [ ] **UC-M11.03-C072-T04 · Concrete realization:** Populate “Partition behavior” with one concrete worked case; map every required entity or field to its source and flag any unmapped entry.
- [ ] **UC-M11.03-C072-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Partition behavior” needed to preserve “Unavailable quorum cannot be hidden by local success responses”; record an enforcement gap where only a model exists.
- [ ] **UC-M11.03-C072-T06 · Dependency connection:** Connect the “Partition behavior” implementation to replicated desired state, durable protocol state and authoritative commit decisions; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M11.03-C072-T07 · Resource behavior:** Account for “Partition patterns and pending writes” in “Partition behavior”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M11.03-C072-T08 · Delivery check:** Run the smallest real “Partition behavior” path and its adverse fixture “Two partitioned groups both publish conflicting authoritative state”; retain actual output, state effects and final disposition.
- [ ] **UC-M11.03-C072-T09 · Patch review:** Review the “Partition behavior” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M11.03-C072-T10 · Delivery handoff:** Publish the “Partition behavior” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M11.03-C073 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Unavailable quorum cannot be hidden by local success responses. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M11.03-C073-T01 · Named property:** Create a stable property/check name under this parent for “Partition behavior”; copy its required invariant exactly: “Unavailable quorum cannot be hidden by local success responses”.
- [ ] **UC-M11.03-C073-T02 · Observable terms:** Define each term in the “Partition behavior” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M11.03-C073-T03 · Precondition set:** List the preconditions under which “Unavailable quorum cannot be hidden by local success responses” must hold for “Partition behavior”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M11.03-C073-T04 · Transition coverage:** Map the “Partition behavior” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M11.03-C073-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Partition behavior”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M11.03-C073-T06 · Satisfying fixture:** Create a concrete “Partition behavior” case that satisfies “Unavailable quorum cannot be hidden by local success responses”; record its expected observation before running the assertion or review.
- [ ] **UC-M11.03-C073-T07 · Violating fixture:** Create the source counterexample “Two partitioned groups both publish conflicting authoritative state” for “Partition behavior”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M11.03-C073-T08 · Enforcement evidence:** Exercise the “Partition behavior” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M11.03-C073-T09 · Regression linkage:** Link the “Partition behavior” property to changes in replicated desired state, durable protocol state and authoritative commit decisions; record which dependency or contract changes require rerunning it.
- [ ] **UC-M11.03-C073-T10 · Property disposition:** Compare the satisfying and violating “Partition behavior” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M11.03-C074 · Integration

**Original checklist item:** Integrate partition behavior with replicated desired state, durable protocol state and authoritative commit decisions; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M11.03-C074-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Partition behavior” across replicated desired state, durable protocol state and authoritative commit decisions; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M11.03-C074-T02 · Field mapping:** Map every “Partition behavior” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M11.03-C074-T03 · Prerequisite identities:** Record the actual prerequisites for “Partition behavior” (source dependency list: UC-M07.01, UC-M11.02); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M11.03-C074-T04 · Ownership agreement:** Specify who owns “Partition behavior” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M11.03-C074-T05 · Handoff implementation:** Connect “Partition behavior” through the mapped seam using the real adapter or explicit specification reference; preserve “Unavailable quorum cannot be hidden by local success responses” across the handoff.
- [ ] **UC-M11.03-C074-T06 · Absent-input case:** Omit one required “Partition behavior” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M11.03-C074-T07 · Stale-input case:** Supply an outdated “Partition behavior” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M11.03-C074-T08 · Incompatible-input case:** Supply an incompatible “Partition behavior” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M11.03-C074-T09 · Valid integration trace:** Run a valid “Partition behavior” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M11.03-C074-T10 · Seam review:** Reconcile the “Partition behavior” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M11.03-C075 · Valid-case test

**Original checklist item:** Run a valid-path fixture for partition behavior; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M11.03-C075-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Partition behavior” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M11.03-C075-T02 · Expected-result oracle:** Specify the “Partition behavior” expected result independently of the implementation output; include the property “Unavailable quorum cannot be hidden by local success responses” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M11.03-C075-T03 · Fixture material:** Create the concrete “Partition behavior” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M11.03-C075-T04 · Target preparation:** Prepare the “Partition behavior” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M11.03-C075-T05 · Initial-state record:** Record the initial “Partition behavior” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M11.03-C075-T06 · Valid-path execution:** Execute the “Partition behavior” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M11.03-C075-T07 · Outcome comparison:** Compare every declared “Partition behavior” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M11.03-C075-T08 · State and bounds check:** Inspect the “Partition behavior” ownership/state effects and actual use of “Partition patterns and pending writes”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M11.03-C075-T09 · Repeatability check:** Repeat the same “Partition behavior” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M11.03-C075-T10 · Positive evidence:** Attach the “Partition behavior” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M11.03-C076 · Negative test

**Original checklist item:** Negative case: Two partitioned groups both publish conflicting authoritative state. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M11.03-C076-T01 · Adverse-case definition:** Create a test record for the exact “Partition behavior” source counterexample: “Two partitioned groups both publish conflicting authoritative state”; state which precondition or invariant it challenges.
- [ ] **UC-M11.03-C076-T02 · Safe fixture boundary:** Define the contained test boundary for “Partition behavior”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M11.03-C076-T03 · Valid control:** Construct a valid “Partition behavior” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M11.03-C076-T04 · Minimal adverse input:** Derive the “Partition behavior” adverse fixture from the control with the smallest documented change needed to reproduce “Two partitioned groups both publish conflicting authoritative state”; retain that change as reproducible data.
- [ ] **UC-M11.03-C076-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Partition behavior”; require “Unavailable quorum cannot be hidden by local success responses” and forbid a false-success verdict.
- [ ] **UC-M11.03-C076-T06 · Adverse execution:** Exercise the “Partition behavior” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M11.03-C076-T07 · Effect inspection:** Inspect “Partition behavior” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M11.03-C076-T08 · Refusal versus failure:** Confirm the “Partition behavior” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M11.03-C076-T09 · Reset and retention:** Restore only the disposable “Partition behavior” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M11.03-C076-T10 · Negative regression:** Register the “Partition behavior” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M11.03-C077 · Change / failure test

**Original checklist item:** Exercise partition behavior when leadership changes during a network partition in the declared topology; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M11.03-C077-T01 · Scenario record:** Write the “Partition behavior” change/failure scenario exactly as supplied: leadership changes during a network partition in the declared topology; identify the property that must remain true: “Unavailable quorum cannot be hidden by local success responses”.
- [ ] **UC-M11.03-C077-T02 · Baseline capture:** Create a known-valid “Partition behavior” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M11.03-C077-T03 · Injection map:** Locate the “Partition behavior” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M11.03-C077-T04 · Disposition oracle:** Define the legal intermediate and final “Partition behavior” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M11.03-C077-T05 · Controlled trigger:** Introduce the controlled “Partition behavior” scenario in the disposable fixture: leadership changes during a network partition in the declared topology; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M11.03-C077-T06 · Intermediate inspection:** Inspect the “Partition behavior” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M11.03-C077-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Partition behavior”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M11.03-C077-T08 · Stale-evidence cleanup:** Invalidate superseded “Partition behavior” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M11.03-C077-T09 · Repeat and compare:** Repeat the selected “Partition behavior” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M11.03-C077-T10 · Failure evidence:** Publish the “Partition behavior” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M11.03-C078 · Bounds

**Original checklist item:** Choose, document and test limits for partition patterns and pending writes; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M11.03-C078-T01 · Quantity inventory:** Create a measurement inventory for “Partition behavior”: “Partition patterns and pending writes”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M11.03-C078-T02 · Measurement method:** Choose how to observe each “Partition behavior” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M11.03-C078-T03 · Budget decision:** Select justified resource and input limits for “Partition behavior”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M11.03-C078-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Partition behavior” cases for “Partition patterns and pending writes”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M11.03-C078-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Partition behavior” limit; preserve “Unavailable quorum cannot be hidden by local success responses”.
- [ ] **UC-M11.03-C078-T06 · Normal measurement:** Run or review the normal “Partition behavior” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M11.03-C078-T07 · At-limit measurement:** Exercise the “Partition behavior” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M11.03-C078-T08 · Over-limit measurement:** Exercise the “Partition behavior” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M11.03-C078-T09 · Uncovered-scope report:** List the “Partition behavior” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M11.03-C078-T10 · Limit evidence:** Publish the selected “Partition behavior” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M11.03-C079 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for partition behavior with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M11.03-C079-T01 · Event inventory:** List the “Partition behavior” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M11.03-C079-T02 · Diagnostic schema:** Define nonsecret fields for “Partition behavior” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M11.03-C079-T03 · Failure mapping:** Map each documented “Partition behavior” refusal or error to a diagnostic outcome; include “Two partitioned groups both publish conflicting authoritative state” and prohibit conversion into a success message.
- [ ] **UC-M11.03-C079-T04 · Emission path:** Add the “Partition behavior” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M11.03-C079-T05 · Redaction check:** Test “Partition behavior” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M11.03-C079-T06 · Output budget:** Set and exercise bounded “Partition behavior” message size, rate and retention compatible with “Partition patterns and pending writes”; define truncation behavior that preserves the final reason.
- [ ] **UC-M11.03-C079-T07 · Success/refusal fixtures:** Capture “Partition behavior” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M11.03-C079-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Partition behavior” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M11.03-C079-T09 · Operator review:** Read the “Partition behavior” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M11.03-C079-T10 · Diagnostic evidence:** Publish redacted “Partition behavior” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M11.03-C080 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for partition behavior; label unexecuted checks as untested.

- [ ] **UC-M11.03-C080-T01 · Evidence inventory:** List the “Partition behavior” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M11.03-C080-T02 · Artifact references:** Record the exact “Partition behavior” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M11.03-C080-T03 · Fixture references:** Attach the “Partition behavior” fixture IDs, input identities and oracle definition; preserve the source counterexample “Two partitioned groups both publish conflicting authoritative state” as a distinct evidence case.
- [ ] **UC-M11.03-C080-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Partition behavior”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M11.03-C080-T05 · Environment record:** Record the actual “Partition behavior” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M11.03-C080-T06 · Expected versus observed:** Pair every “Partition behavior” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M11.03-C080-T07 · Failure and limit records:** Attach “Partition behavior” change/failure and bounds evidence where required; include uncovered “Partition patterns and pending writes” and unresolved violations of “Unavailable quorum cannot be hidden by local success responses”.
- [ ] **UC-M11.03-C080-T08 · Evidence hygiene:** Check the “Partition behavior” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M11.03-C080-T09 · Reproduction review:** Have the “Partition behavior” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M11.03-C080-T10 · Acceptance linkage:** Link the “Partition behavior” evidence to its parent and UC-M11.03 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 09. State recovery

**Source delivery:** Recover durable control state without trusting stale uncommitted leadership.

**Source invariant:** Restart cannot promote an obsolete local state as authoritative.

**Source negative case:** A restored old controller overwrites newer committed desired state.

**Source bounded quantities:** Recovery bytes and replay time.

### UC-M11.03-C081 · Contract

**Original checklist item:** Specify state recovery inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M11.03-C081-T01 · Scope statement:** Draft the operation boundary for “State recovery” within Durable consensus control store; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M11.03-C081-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “State recovery”; record each producer, representation and missing-value meaning.
- [ ] **UC-M11.03-C081-T03 · Output inventory:** List the outputs of “State recovery” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M11.03-C081-T04 · Field dictionary:** Create a field-and-term dictionary for “State recovery”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M11.03-C081-T05 · Prerequisite contract:** Map “State recovery” to the source component prerequisites (UC-M07.01, UC-M11.02); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M11.03-C081-T06 · Authority map:** Identify who may produce, change and consume “State recovery”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M11.03-C081-T07 · Invariant clause:** Add a normative clause for “State recovery” that preserves “Restart cannot promote an obsolete local state as authoritative”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M11.03-C081-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “State recovery”; include the source counterexample “A restored old controller overwrites newer committed desired state” and the intended safe disposition.
- [ ] **UC-M11.03-C081-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Recovery bytes and replay time” in the “State recovery” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M11.03-C081-T10 · Contract review:** Review the “State recovery” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M11.03-C082 · Delivery

**Original checklist item:** Recover durable control state without trusting stale uncommitted leadership.

- [ ] **UC-M11.03-C082-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “State recovery”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M11.03-C082-T02 · Change plan:** Break the source delivery for “State recovery” into concrete edit targets and reviewable outputs; keep the UC-M11.03 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M11.03-C082-T03 · Core artifact:** Implement the smallest selected-profile change for “State recovery” that realizes this source instruction: Recover durable control state without trusting stale uncommitted leadership.
- [ ] **UC-M11.03-C082-T04 · Concrete realization:** Trace “State recovery” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M11.03-C082-T05 · Invariant protection:** Add the actual guard, check or review criterion for “State recovery” needed to preserve “Restart cannot promote an obsolete local state as authoritative”; record an enforcement gap where only a model exists.
- [ ] **UC-M11.03-C082-T06 · Dependency connection:** Connect the “State recovery” implementation to replicated desired state, durable protocol state and authoritative commit decisions; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M11.03-C082-T07 · Resource behavior:** Account for “Recovery bytes and replay time” in “State recovery”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M11.03-C082-T08 · Delivery check:** Run the smallest real “State recovery” path and its adverse fixture “A restored old controller overwrites newer committed desired state”; retain actual output, state effects and final disposition.
- [ ] **UC-M11.03-C082-T09 · Patch review:** Review the “State recovery” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M11.03-C082-T10 · Delivery handoff:** Publish the “State recovery” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M11.03-C083 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Restart cannot promote an obsolete local state as authoritative. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M11.03-C083-T01 · Named property:** Create a stable property/check name under this parent for “State recovery”; copy its required invariant exactly: “Restart cannot promote an obsolete local state as authoritative”.
- [ ] **UC-M11.03-C083-T02 · Observable terms:** Define each term in the “State recovery” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M11.03-C083-T03 · Precondition set:** List the preconditions under which “Restart cannot promote an obsolete local state as authoritative” must hold for “State recovery”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M11.03-C083-T04 · Transition coverage:** Map the “State recovery” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M11.03-C083-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “State recovery”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M11.03-C083-T06 · Satisfying fixture:** Create a concrete “State recovery” case that satisfies “Restart cannot promote an obsolete local state as authoritative”; record its expected observation before running the assertion or review.
- [ ] **UC-M11.03-C083-T07 · Violating fixture:** Create the source counterexample “A restored old controller overwrites newer committed desired state” for “State recovery”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M11.03-C083-T08 · Enforcement evidence:** Exercise the “State recovery” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M11.03-C083-T09 · Regression linkage:** Link the “State recovery” property to changes in replicated desired state, durable protocol state and authoritative commit decisions; record which dependency or contract changes require rerunning it.
- [ ] **UC-M11.03-C083-T10 · Property disposition:** Compare the satisfying and violating “State recovery” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M11.03-C084 · Integration

**Original checklist item:** Integrate state recovery with replicated desired state, durable protocol state and authoritative commit decisions; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M11.03-C084-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “State recovery” across replicated desired state, durable protocol state and authoritative commit decisions; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M11.03-C084-T02 · Field mapping:** Map every “State recovery” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M11.03-C084-T03 · Prerequisite identities:** Record the actual prerequisites for “State recovery” (source dependency list: UC-M07.01, UC-M11.02); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M11.03-C084-T04 · Ownership agreement:** Specify who owns “State recovery” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M11.03-C084-T05 · Handoff implementation:** Connect “State recovery” through the mapped seam using the real adapter or explicit specification reference; preserve “Restart cannot promote an obsolete local state as authoritative” across the handoff.
- [ ] **UC-M11.03-C084-T06 · Absent-input case:** Omit one required “State recovery” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M11.03-C084-T07 · Stale-input case:** Supply an outdated “State recovery” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M11.03-C084-T08 · Incompatible-input case:** Supply an incompatible “State recovery” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M11.03-C084-T09 · Valid integration trace:** Run a valid “State recovery” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M11.03-C084-T10 · Seam review:** Reconcile the “State recovery” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M11.03-C085 · Valid-case test

**Original checklist item:** Run a valid-path fixture for state recovery; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M11.03-C085-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “State recovery” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M11.03-C085-T02 · Expected-result oracle:** Specify the “State recovery” expected result independently of the implementation output; include the property “Restart cannot promote an obsolete local state as authoritative” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M11.03-C085-T03 · Fixture material:** Create the concrete “State recovery” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M11.03-C085-T04 · Target preparation:** Prepare the “State recovery” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M11.03-C085-T05 · Initial-state record:** Record the initial “State recovery” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M11.03-C085-T06 · Valid-path execution:** Execute the “State recovery” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M11.03-C085-T07 · Outcome comparison:** Compare every declared “State recovery” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M11.03-C085-T08 · State and bounds check:** Inspect the “State recovery” ownership/state effects and actual use of “Recovery bytes and replay time”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M11.03-C085-T09 · Repeatability check:** Repeat the same “State recovery” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M11.03-C085-T10 · Positive evidence:** Attach the “State recovery” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M11.03-C086 · Negative test

**Original checklist item:** Negative case: A restored old controller overwrites newer committed desired state. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M11.03-C086-T01 · Adverse-case definition:** Create a test record for the exact “State recovery” source counterexample: “A restored old controller overwrites newer committed desired state”; state which precondition or invariant it challenges.
- [ ] **UC-M11.03-C086-T02 · Safe fixture boundary:** Define the contained test boundary for “State recovery”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M11.03-C086-T03 · Valid control:** Construct a valid “State recovery” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M11.03-C086-T04 · Minimal adverse input:** Derive the “State recovery” adverse fixture from the control with the smallest documented change needed to reproduce “A restored old controller overwrites newer committed desired state”; retain that change as reproducible data.
- [ ] **UC-M11.03-C086-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “State recovery”; require “Restart cannot promote an obsolete local state as authoritative” and forbid a false-success verdict.
- [ ] **UC-M11.03-C086-T06 · Adverse execution:** Exercise the “State recovery” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M11.03-C086-T07 · Effect inspection:** Inspect “State recovery” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M11.03-C086-T08 · Refusal versus failure:** Confirm the “State recovery” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M11.03-C086-T09 · Reset and retention:** Restore only the disposable “State recovery” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M11.03-C086-T10 · Negative regression:** Register the “State recovery” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M11.03-C087 · Change / failure test

**Original checklist item:** Exercise state recovery when leadership changes during a network partition in the declared topology; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M11.03-C087-T01 · Scenario record:** Write the “State recovery” change/failure scenario exactly as supplied: leadership changes during a network partition in the declared topology; identify the property that must remain true: “Restart cannot promote an obsolete local state as authoritative”.
- [ ] **UC-M11.03-C087-T02 · Baseline capture:** Create a known-valid “State recovery” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M11.03-C087-T03 · Injection map:** Locate the “State recovery” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M11.03-C087-T04 · Disposition oracle:** Define the legal intermediate and final “State recovery” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M11.03-C087-T05 · Controlled trigger:** Introduce the controlled “State recovery” scenario in the disposable fixture: leadership changes during a network partition in the declared topology; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M11.03-C087-T06 · Intermediate inspection:** Inspect the “State recovery” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M11.03-C087-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “State recovery”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M11.03-C087-T08 · Stale-evidence cleanup:** Invalidate superseded “State recovery” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M11.03-C087-T09 · Repeat and compare:** Repeat the selected “State recovery” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M11.03-C087-T10 · Failure evidence:** Publish the “State recovery” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M11.03-C088 · Bounds

**Original checklist item:** Choose, document and test limits for recovery bytes and replay time; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M11.03-C088-T01 · Quantity inventory:** Create a measurement inventory for “State recovery”: “Recovery bytes and replay time”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M11.03-C088-T02 · Measurement method:** Choose how to observe each “State recovery” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M11.03-C088-T03 · Budget decision:** Select justified resource and input limits for “State recovery”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M11.03-C088-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “State recovery” cases for “Recovery bytes and replay time”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M11.03-C088-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “State recovery” limit; preserve “Restart cannot promote an obsolete local state as authoritative”.
- [ ] **UC-M11.03-C088-T06 · Normal measurement:** Run or review the normal “State recovery” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M11.03-C088-T07 · At-limit measurement:** Exercise the “State recovery” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M11.03-C088-T08 · Over-limit measurement:** Exercise the “State recovery” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M11.03-C088-T09 · Uncovered-scope report:** List the “State recovery” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M11.03-C088-T10 · Limit evidence:** Publish the selected “State recovery” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M11.03-C089 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for state recovery with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M11.03-C089-T01 · Event inventory:** List the “State recovery” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M11.03-C089-T02 · Diagnostic schema:** Define nonsecret fields for “State recovery” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M11.03-C089-T03 · Failure mapping:** Map each documented “State recovery” refusal or error to a diagnostic outcome; include “A restored old controller overwrites newer committed desired state” and prohibit conversion into a success message.
- [ ] **UC-M11.03-C089-T04 · Emission path:** Add the “State recovery” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M11.03-C089-T05 · Redaction check:** Test “State recovery” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M11.03-C089-T06 · Output budget:** Set and exercise bounded “State recovery” message size, rate and retention compatible with “Recovery bytes and replay time”; define truncation behavior that preserves the final reason.
- [ ] **UC-M11.03-C089-T07 · Success/refusal fixtures:** Capture “State recovery” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M11.03-C089-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “State recovery” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M11.03-C089-T09 · Operator review:** Read the “State recovery” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M11.03-C089-T10 · Diagnostic evidence:** Publish redacted “State recovery” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M11.03-C090 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for state recovery; label unexecuted checks as untested.

- [ ] **UC-M11.03-C090-T01 · Evidence inventory:** List the “State recovery” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M11.03-C090-T02 · Artifact references:** Record the exact “State recovery” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M11.03-C090-T03 · Fixture references:** Attach the “State recovery” fixture IDs, input identities and oracle definition; preserve the source counterexample “A restored old controller overwrites newer committed desired state” as a distinct evidence case.
- [ ] **UC-M11.03-C090-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “State recovery”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M11.03-C090-T05 · Environment record:** Record the actual “State recovery” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M11.03-C090-T06 · Expected versus observed:** Pair every “State recovery” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M11.03-C090-T07 · Failure and limit records:** Attach “State recovery” change/failure and bounds evidence where required; include uncovered “Recovery bytes and replay time” and unresolved violations of “Restart cannot promote an obsolete local state as authoritative”.
- [ ] **UC-M11.03-C090-T08 · Evidence hygiene:** Check the “State recovery” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M11.03-C090-T09 · Reproduction review:** Have the “State recovery” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M11.03-C090-T10 · Acceptance linkage:** Link the “State recovery” evidence to its parent and UC-M11.03 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 10. Consensus qualification

**Source delivery:** Test leader loss and partition with the declared independent hosts and assumptions.

**Source invariant:** Observed tests preserve the specified single-writer safety and recovery rules.

**Source negative case:** A test uses same-host replicas as evidence for independent-host failure safety.

**Source bounded quantities:** Topology size and repeated fault trials.

### UC-M11.03-C091 · Contract

**Original checklist item:** Specify consensus qualification inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M11.03-C091-T01 · Scope statement:** Draft the operation boundary for “Consensus qualification” within Durable consensus control store; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M11.03-C091-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Consensus qualification”; record each producer, representation and missing-value meaning.
- [ ] **UC-M11.03-C091-T03 · Output inventory:** List the outputs of “Consensus qualification” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M11.03-C091-T04 · Field dictionary:** Create a field-and-term dictionary for “Consensus qualification”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M11.03-C091-T05 · Prerequisite contract:** Map “Consensus qualification” to the source component prerequisites (UC-M07.01, UC-M11.02); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M11.03-C091-T06 · Authority map:** Identify who may produce, change and consume “Consensus qualification”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M11.03-C091-T07 · Invariant clause:** Add a normative clause for “Consensus qualification” that preserves “Observed tests preserve the specified single-writer safety and recovery rules”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M11.03-C091-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Consensus qualification”; include the source counterexample “A test uses same-host replicas as evidence for independent-host failure safety” and the intended safe disposition.
- [ ] **UC-M11.03-C091-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Topology size and repeated fault trials” in the “Consensus qualification” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M11.03-C091-T10 · Contract review:** Review the “Consensus qualification” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M11.03-C092 · Delivery

**Original checklist item:** Test leader loss and partition with the declared independent hosts and assumptions.

- [ ] **UC-M11.03-C092-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Consensus qualification”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M11.03-C092-T02 · Change plan:** Break the source delivery for “Consensus qualification” into concrete edit targets and reviewable outputs; keep the UC-M11.03 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M11.03-C092-T03 · Core artifact:** Create the “Consensus qualification” fixture or harness for this source instruction: Test leader loss and partition with the declared independent hosts and assumptions.
- [ ] **UC-M11.03-C092-T04 · Concrete realization:** Connect the “Consensus qualification” harness to its actual intended target, set the expected oracle before running it, and distinguish a mock/control run from a target run.
- [ ] **UC-M11.03-C092-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Consensus qualification” needed to preserve “Observed tests preserve the specified single-writer safety and recovery rules”; record an enforcement gap where only a model exists.
- [ ] **UC-M11.03-C092-T06 · Dependency connection:** Connect the “Consensus qualification” implementation to replicated desired state, durable protocol state and authoritative commit decisions; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M11.03-C092-T07 · Resource behavior:** Account for “Topology size and repeated fault trials” in “Consensus qualification”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M11.03-C092-T08 · Delivery check:** Run the smallest real “Consensus qualification” path and its adverse fixture “A test uses same-host replicas as evidence for independent-host failure safety”; retain actual output, state effects and final disposition.
- [ ] **UC-M11.03-C092-T09 · Patch review:** Review the “Consensus qualification” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M11.03-C092-T10 · Delivery handoff:** Publish the “Consensus qualification” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M11.03-C093 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Observed tests preserve the specified single-writer safety and recovery rules. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M11.03-C093-T01 · Named property:** Create a stable property/check name under this parent for “Consensus qualification”; copy its required invariant exactly: “Observed tests preserve the specified single-writer safety and recovery rules”.
- [ ] **UC-M11.03-C093-T02 · Observable terms:** Define each term in the “Consensus qualification” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M11.03-C093-T03 · Precondition set:** List the preconditions under which “Observed tests preserve the specified single-writer safety and recovery rules” must hold for “Consensus qualification”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M11.03-C093-T04 · Transition coverage:** Map the “Consensus qualification” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M11.03-C093-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Consensus qualification”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M11.03-C093-T06 · Satisfying fixture:** Create a concrete “Consensus qualification” case that satisfies “Observed tests preserve the specified single-writer safety and recovery rules”; record its expected observation before running the assertion or review.
- [ ] **UC-M11.03-C093-T07 · Violating fixture:** Create the source counterexample “A test uses same-host replicas as evidence for independent-host failure safety” for “Consensus qualification”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M11.03-C093-T08 · Enforcement evidence:** Exercise the “Consensus qualification” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M11.03-C093-T09 · Regression linkage:** Link the “Consensus qualification” property to changes in replicated desired state, durable protocol state and authoritative commit decisions; record which dependency or contract changes require rerunning it.
- [ ] **UC-M11.03-C093-T10 · Property disposition:** Compare the satisfying and violating “Consensus qualification” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M11.03-C094 · Integration

**Original checklist item:** Integrate consensus qualification with replicated desired state, durable protocol state and authoritative commit decisions; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M11.03-C094-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Consensus qualification” across replicated desired state, durable protocol state and authoritative commit decisions; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M11.03-C094-T02 · Field mapping:** Map every “Consensus qualification” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M11.03-C094-T03 · Prerequisite identities:** Record the actual prerequisites for “Consensus qualification” (source dependency list: UC-M07.01, UC-M11.02); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M11.03-C094-T04 · Ownership agreement:** Specify who owns “Consensus qualification” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M11.03-C094-T05 · Handoff implementation:** Connect “Consensus qualification” through the mapped seam using the real adapter or explicit specification reference; preserve “Observed tests preserve the specified single-writer safety and recovery rules” across the handoff.
- [ ] **UC-M11.03-C094-T06 · Absent-input case:** Omit one required “Consensus qualification” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M11.03-C094-T07 · Stale-input case:** Supply an outdated “Consensus qualification” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M11.03-C094-T08 · Incompatible-input case:** Supply an incompatible “Consensus qualification” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M11.03-C094-T09 · Valid integration trace:** Run a valid “Consensus qualification” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M11.03-C094-T10 · Seam review:** Reconcile the “Consensus qualification” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M11.03-C095 · Valid-case test

**Original checklist item:** Run a valid-path fixture for consensus qualification; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M11.03-C095-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Consensus qualification” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M11.03-C095-T02 · Expected-result oracle:** Specify the “Consensus qualification” expected result independently of the implementation output; include the property “Observed tests preserve the specified single-writer safety and recovery rules” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M11.03-C095-T03 · Fixture material:** Create the concrete “Consensus qualification” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M11.03-C095-T04 · Target preparation:** Prepare the “Consensus qualification” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M11.03-C095-T05 · Initial-state record:** Record the initial “Consensus qualification” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M11.03-C095-T06 · Valid-path execution:** Execute the “Consensus qualification” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M11.03-C095-T07 · Outcome comparison:** Compare every declared “Consensus qualification” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M11.03-C095-T08 · State and bounds check:** Inspect the “Consensus qualification” ownership/state effects and actual use of “Topology size and repeated fault trials”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M11.03-C095-T09 · Repeatability check:** Repeat the same “Consensus qualification” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M11.03-C095-T10 · Positive evidence:** Attach the “Consensus qualification” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M11.03-C096 · Negative test

**Original checklist item:** Negative case: A test uses same-host replicas as evidence for independent-host failure safety. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M11.03-C096-T01 · Adverse-case definition:** Create a test record for the exact “Consensus qualification” source counterexample: “A test uses same-host replicas as evidence for independent-host failure safety”; state which precondition or invariant it challenges.
- [ ] **UC-M11.03-C096-T02 · Safe fixture boundary:** Define the contained test boundary for “Consensus qualification”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M11.03-C096-T03 · Valid control:** Construct a valid “Consensus qualification” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M11.03-C096-T04 · Minimal adverse input:** Derive the “Consensus qualification” adverse fixture from the control with the smallest documented change needed to reproduce “A test uses same-host replicas as evidence for independent-host failure safety”; retain that change as reproducible data.
- [ ] **UC-M11.03-C096-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Consensus qualification”; require “Observed tests preserve the specified single-writer safety and recovery rules” and forbid a false-success verdict.
- [ ] **UC-M11.03-C096-T06 · Adverse execution:** Exercise the “Consensus qualification” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M11.03-C096-T07 · Effect inspection:** Inspect “Consensus qualification” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M11.03-C096-T08 · Refusal versus failure:** Confirm the “Consensus qualification” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M11.03-C096-T09 · Reset and retention:** Restore only the disposable “Consensus qualification” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M11.03-C096-T10 · Negative regression:** Register the “Consensus qualification” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M11.03-C097 · Change / failure test

**Original checklist item:** Exercise consensus qualification when leadership changes during a network partition in the declared topology; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M11.03-C097-T01 · Scenario record:** Write the “Consensus qualification” change/failure scenario exactly as supplied: leadership changes during a network partition in the declared topology; identify the property that must remain true: “Observed tests preserve the specified single-writer safety and recovery rules”.
- [ ] **UC-M11.03-C097-T02 · Baseline capture:** Create a known-valid “Consensus qualification” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M11.03-C097-T03 · Injection map:** Locate the “Consensus qualification” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M11.03-C097-T04 · Disposition oracle:** Define the legal intermediate and final “Consensus qualification” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M11.03-C097-T05 · Controlled trigger:** Introduce the controlled “Consensus qualification” scenario in the disposable fixture: leadership changes during a network partition in the declared topology; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M11.03-C097-T06 · Intermediate inspection:** Inspect the “Consensus qualification” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M11.03-C097-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Consensus qualification”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M11.03-C097-T08 · Stale-evidence cleanup:** Invalidate superseded “Consensus qualification” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M11.03-C097-T09 · Repeat and compare:** Repeat the selected “Consensus qualification” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M11.03-C097-T10 · Failure evidence:** Publish the “Consensus qualification” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M11.03-C098 · Bounds

**Original checklist item:** Choose, document and test limits for topology size and repeated fault trials; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M11.03-C098-T01 · Quantity inventory:** Create a measurement inventory for “Consensus qualification”: “Topology size and repeated fault trials”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M11.03-C098-T02 · Measurement method:** Choose how to observe each “Consensus qualification” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M11.03-C098-T03 · Budget decision:** Select justified resource and input limits for “Consensus qualification”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M11.03-C098-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Consensus qualification” cases for “Topology size and repeated fault trials”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M11.03-C098-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Consensus qualification” limit; preserve “Observed tests preserve the specified single-writer safety and recovery rules”.
- [ ] **UC-M11.03-C098-T06 · Normal measurement:** Run or review the normal “Consensus qualification” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M11.03-C098-T07 · At-limit measurement:** Exercise the “Consensus qualification” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M11.03-C098-T08 · Over-limit measurement:** Exercise the “Consensus qualification” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M11.03-C098-T09 · Uncovered-scope report:** List the “Consensus qualification” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M11.03-C098-T10 · Limit evidence:** Publish the selected “Consensus qualification” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M11.03-C099 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for consensus qualification with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M11.03-C099-T01 · Event inventory:** List the “Consensus qualification” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M11.03-C099-T02 · Diagnostic schema:** Define nonsecret fields for “Consensus qualification” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M11.03-C099-T03 · Failure mapping:** Map each documented “Consensus qualification” refusal or error to a diagnostic outcome; include “A test uses same-host replicas as evidence for independent-host failure safety” and prohibit conversion into a success message.
- [ ] **UC-M11.03-C099-T04 · Emission path:** Add the “Consensus qualification” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M11.03-C099-T05 · Redaction check:** Test “Consensus qualification” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M11.03-C099-T06 · Output budget:** Set and exercise bounded “Consensus qualification” message size, rate and retention compatible with “Topology size and repeated fault trials”; define truncation behavior that preserves the final reason.
- [ ] **UC-M11.03-C099-T07 · Success/refusal fixtures:** Capture “Consensus qualification” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M11.03-C099-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Consensus qualification” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M11.03-C099-T09 · Operator review:** Read the “Consensus qualification” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M11.03-C099-T10 · Diagnostic evidence:** Publish redacted “Consensus qualification” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M11.03-C100 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for consensus qualification; label unexecuted checks as untested.

- [ ] **UC-M11.03-C100-T01 · Evidence inventory:** List the “Consensus qualification” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M11.03-C100-T02 · Artifact references:** Record the exact “Consensus qualification” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M11.03-C100-T03 · Fixture references:** Attach the “Consensus qualification” fixture IDs, input identities and oracle definition; preserve the source counterexample “A test uses same-host replicas as evidence for independent-host failure safety” as a distinct evidence case.
- [ ] **UC-M11.03-C100-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Consensus qualification”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M11.03-C100-T05 · Environment record:** Record the actual “Consensus qualification” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M11.03-C100-T06 · Expected versus observed:** Pair every “Consensus qualification” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M11.03-C100-T07 · Failure and limit records:** Attach “Consensus qualification” change/failure and bounds evidence where required; include uncovered “Topology size and repeated fault trials” and unresolved violations of “Observed tests preserve the specified single-writer safety and recovery rules”.
- [ ] **UC-M11.03-C100-T08 · Evidence hygiene:** Check the “Consensus qualification” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M11.03-C100-T09 · Reproduction review:** Have the “Consensus qualification” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M11.03-C100-T10 · Acceptance linkage:** Link the “Consensus qualification” evidence to its parent and UC-M11.03 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

