# UC-M11.07 — Rolling upgrades and compatibility negotiation

**To-Do Pack 2.0.0 · Baseline UC-2.2.0 · 100 parent checks × 10 subtasks = 1,000 to-dos**

[Master index](../../INDEX.md) · [Workstream index](../../w/11.md)

| Field | Preserved source value |
|---|---|
| Workstream | 11. Optional multi-host federation |
| Milestone | D |
| Priority | P2 |
| Source assessment | MISSING |
| Scope | optional multi host |
| Dependencies | [UC-M01.02](../01/UC-M01.02.md), [UC-M07.08](../07/UC-M07.08.md), [UC-M11.05](../11/UC-M11.05.md) |
| Source checklist pack | 1.0.0 |
| Original reference labels | [S4], [S6]. |

## Original requirement

Support mixed worker/image/ABI versions during controlled rollouts with admission and rollback gates.

**Original acceptance criterion:** Canary failure stops the rollout; incompatible state or protocol versions never silently interoperate.

**Source trace:** Original checklist `UC100/c/11/UC-M11.07.md` inside [s/checklists.zip](../../s/checklists.zip); exact parent records in [data/parents.jsonl](../../data/parents.jsonl). Original roadmap lines 1065–1075 are preserved in [s/roadmap.md](../../s/roadmap.md).

## How to use these lists

Every parent statement below is preserved verbatim. Its ten child tasks are proposed decomposition, not implemented capabilities or executed tests. Child IDs append `-T01` through `-T10` to the original parent ID. All begin unchecked / `TODO`. Design/review evidence does not establish runtime enforcement; observe the actual selected target where the parent requires it.

The source dependency graph and selected release profile determine applicability. The numbered child sequence is a local working order, not an added hard dependency graph. An unselected optional feature needs a recorded not-applicable rationale; missing prerequisites for selected work remain blockers. Numerical budgets, backends and trust mechanisms remain decisions unless fixed by the source. Test hostile cases only with synthetic inputs in authorized disposable environments.

## 01. Compatibility inventory

**Source delivery:** Record worker, protocol, image, ABI and state-schema versions involved in rollout.

**Source invariant:** Compatibility decisions include all required execution and state contracts.

**Source negative case:** Only ship version is checked while ABI versions differ.

**Source bounded quantities:** Versions and supported combinations.

### UC-M11.07-C001 · Contract

**Original checklist item:** Specify compatibility inventory inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M11.07-C001-T01 · Scope statement:** Draft the operation boundary for “Compatibility inventory” within Rolling upgrades and compatibility negotiation; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M11.07-C001-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Compatibility inventory”; record each producer, representation and missing-value meaning.
- [ ] **UC-M11.07-C001-T03 · Output inventory:** List the outputs of “Compatibility inventory” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M11.07-C001-T04 · Field dictionary:** Create a field-and-term dictionary for “Compatibility inventory”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M11.07-C001-T05 · Prerequisite contract:** Map “Compatibility inventory” to the source component prerequisites (UC-M01.02, UC-M07.08, UC-M11.05); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M11.07-C001-T06 · Authority map:** Identify who may produce, change and consume “Compatibility inventory”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M11.07-C001-T07 · Invariant clause:** Add a normative clause for “Compatibility inventory” that preserves “Compatibility decisions include all required execution and state contracts”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M11.07-C001-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Compatibility inventory”; include the source counterexample “Only ship version is checked while ABI versions differ” and the intended safe disposition.
- [ ] **UC-M11.07-C001-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Versions and supported combinations” in the “Compatibility inventory” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M11.07-C001-T10 · Contract review:** Review the “Compatibility inventory” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M11.07-C002 · Delivery

**Original checklist item:** Record worker, protocol, image, ABI and state-schema versions involved in rollout.

- [ ] **UC-M11.07-C002-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Compatibility inventory”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M11.07-C002-T02 · Change plan:** Break the source delivery for “Compatibility inventory” into concrete edit targets and reviewable outputs; keep the UC-M11.07 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M11.07-C002-T03 · Core artifact:** Create the “Compatibility inventory” model, schema or inventory that realizes this source instruction: Record worker, protocol, image, ABI and state-schema versions involved in rollout.
- [ ] **UC-M11.07-C002-T04 · Concrete realization:** Populate “Compatibility inventory” with one concrete worked case; map every required entity or field to its source and flag any unmapped entry.
- [ ] **UC-M11.07-C002-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Compatibility inventory” needed to preserve “Compatibility decisions include all required execution and state contracts”; record an enforcement gap where only a model exists.
- [ ] **UC-M11.07-C002-T06 · Dependency connection:** Connect the “Compatibility inventory” implementation to mixed-version admission, canary gates and compatible state rollback; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M11.07-C002-T07 · Resource behavior:** Account for “Versions and supported combinations” in “Compatibility inventory”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M11.07-C002-T08 · Delivery check:** Run the smallest real “Compatibility inventory” path and its adverse fixture “Only ship version is checked while ABI versions differ”; retain actual output, state effects and final disposition.
- [ ] **UC-M11.07-C002-T09 · Patch review:** Review the “Compatibility inventory” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M11.07-C002-T10 · Delivery handoff:** Publish the “Compatibility inventory” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M11.07-C003 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Compatibility decisions include all required execution and state contracts. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M11.07-C003-T01 · Named property:** Create a stable property/check name under this parent for “Compatibility inventory”; copy its required invariant exactly: “Compatibility decisions include all required execution and state contracts”.
- [ ] **UC-M11.07-C003-T02 · Observable terms:** Define each term in the “Compatibility inventory” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M11.07-C003-T03 · Precondition set:** List the preconditions under which “Compatibility decisions include all required execution and state contracts” must hold for “Compatibility inventory”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M11.07-C003-T04 · Transition coverage:** Map the “Compatibility inventory” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M11.07-C003-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Compatibility inventory”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M11.07-C003-T06 · Satisfying fixture:** Create a concrete “Compatibility inventory” case that satisfies “Compatibility decisions include all required execution and state contracts”; record its expected observation before running the assertion or review.
- [ ] **UC-M11.07-C003-T07 · Violating fixture:** Create the source counterexample “Only ship version is checked while ABI versions differ” for “Compatibility inventory”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M11.07-C003-T08 · Enforcement evidence:** Exercise the “Compatibility inventory” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M11.07-C003-T09 · Regression linkage:** Link the “Compatibility inventory” property to changes in mixed-version admission, canary gates and compatible state rollback; record which dependency or contract changes require rerunning it.
- [ ] **UC-M11.07-C003-T10 · Property disposition:** Compare the satisfying and violating “Compatibility inventory” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M11.07-C004 · Integration

**Original checklist item:** Integrate compatibility inventory with mixed-version admission, canary gates and compatible state rollback; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M11.07-C004-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Compatibility inventory” across mixed-version admission, canary gates and compatible state rollback; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M11.07-C004-T02 · Field mapping:** Map every “Compatibility inventory” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M11.07-C004-T03 · Prerequisite identities:** Record the actual prerequisites for “Compatibility inventory” (source dependency list: UC-M01.02, UC-M07.08, UC-M11.05); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M11.07-C004-T04 · Ownership agreement:** Specify who owns “Compatibility inventory” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M11.07-C004-T05 · Handoff implementation:** Connect “Compatibility inventory” through the mapped seam using the real adapter or explicit specification reference; preserve “Compatibility decisions include all required execution and state contracts” across the handoff.
- [ ] **UC-M11.07-C004-T06 · Absent-input case:** Omit one required “Compatibility inventory” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M11.07-C004-T07 · Stale-input case:** Supply an outdated “Compatibility inventory” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M11.07-C004-T08 · Incompatible-input case:** Supply an incompatible “Compatibility inventory” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M11.07-C004-T09 · Valid integration trace:** Run a valid “Compatibility inventory” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M11.07-C004-T10 · Seam review:** Reconcile the “Compatibility inventory” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M11.07-C005 · Valid-case test

**Original checklist item:** Run a valid-path fixture for compatibility inventory; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M11.07-C005-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Compatibility inventory” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M11.07-C005-T02 · Expected-result oracle:** Specify the “Compatibility inventory” expected result independently of the implementation output; include the property “Compatibility decisions include all required execution and state contracts” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M11.07-C005-T03 · Fixture material:** Create the concrete “Compatibility inventory” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M11.07-C005-T04 · Target preparation:** Prepare the “Compatibility inventory” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M11.07-C005-T05 · Initial-state record:** Record the initial “Compatibility inventory” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M11.07-C005-T06 · Valid-path execution:** Execute the “Compatibility inventory” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M11.07-C005-T07 · Outcome comparison:** Compare every declared “Compatibility inventory” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M11.07-C005-T08 · State and bounds check:** Inspect the “Compatibility inventory” ownership/state effects and actual use of “Versions and supported combinations”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M11.07-C005-T09 · Repeatability check:** Repeat the same “Compatibility inventory” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M11.07-C005-T10 · Positive evidence:** Attach the “Compatibility inventory” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M11.07-C006 · Negative test

**Original checklist item:** Negative case: Only ship version is checked while ABI versions differ. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M11.07-C006-T01 · Adverse-case definition:** Create a test record for the exact “Compatibility inventory” source counterexample: “Only ship version is checked while ABI versions differ”; state which precondition or invariant it challenges.
- [ ] **UC-M11.07-C006-T02 · Safe fixture boundary:** Define the contained test boundary for “Compatibility inventory”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M11.07-C006-T03 · Valid control:** Construct a valid “Compatibility inventory” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M11.07-C006-T04 · Minimal adverse input:** Derive the “Compatibility inventory” adverse fixture from the control with the smallest documented change needed to reproduce “Only ship version is checked while ABI versions differ”; retain that change as reproducible data.
- [ ] **UC-M11.07-C006-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Compatibility inventory”; require “Compatibility decisions include all required execution and state contracts” and forbid a false-success verdict.
- [ ] **UC-M11.07-C006-T06 · Adverse execution:** Exercise the “Compatibility inventory” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M11.07-C006-T07 · Effect inspection:** Inspect “Compatibility inventory” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M11.07-C006-T08 · Refusal versus failure:** Confirm the “Compatibility inventory” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M11.07-C006-T09 · Reset and retention:** Restore only the disposable “Compatibility inventory” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M11.07-C006-T10 · Negative regression:** Register the “Compatibility inventory” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M11.07-C007 · Change / failure test

**Original checklist item:** Exercise compatibility inventory when a canary fails while other workers are still on the previous approved version; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M11.07-C007-T01 · Scenario record:** Write the “Compatibility inventory” change/failure scenario exactly as supplied: a canary fails while other workers are still on the previous approved version; identify the property that must remain true: “Compatibility decisions include all required execution and state contracts”.
- [ ] **UC-M11.07-C007-T02 · Baseline capture:** Create a known-valid “Compatibility inventory” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M11.07-C007-T03 · Injection map:** Locate the “Compatibility inventory” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M11.07-C007-T04 · Disposition oracle:** Define the legal intermediate and final “Compatibility inventory” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M11.07-C007-T05 · Controlled trigger:** Introduce the controlled “Compatibility inventory” scenario in the disposable fixture: a canary fails while other workers are still on the previous approved version; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M11.07-C007-T06 · Intermediate inspection:** Inspect the “Compatibility inventory” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M11.07-C007-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Compatibility inventory”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M11.07-C007-T08 · Stale-evidence cleanup:** Invalidate superseded “Compatibility inventory” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M11.07-C007-T09 · Repeat and compare:** Repeat the selected “Compatibility inventory” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M11.07-C007-T10 · Failure evidence:** Publish the “Compatibility inventory” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M11.07-C008 · Bounds

**Original checklist item:** Choose, document and test limits for versions and supported combinations; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M11.07-C008-T01 · Quantity inventory:** Create a measurement inventory for “Compatibility inventory”: “Versions and supported combinations”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M11.07-C008-T02 · Measurement method:** Choose how to observe each “Compatibility inventory” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M11.07-C008-T03 · Budget decision:** Select justified resource and input limits for “Compatibility inventory”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M11.07-C008-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Compatibility inventory” cases for “Versions and supported combinations”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M11.07-C008-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Compatibility inventory” limit; preserve “Compatibility decisions include all required execution and state contracts”.
- [ ] **UC-M11.07-C008-T06 · Normal measurement:** Run or review the normal “Compatibility inventory” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M11.07-C008-T07 · At-limit measurement:** Exercise the “Compatibility inventory” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M11.07-C008-T08 · Over-limit measurement:** Exercise the “Compatibility inventory” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M11.07-C008-T09 · Uncovered-scope report:** List the “Compatibility inventory” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M11.07-C008-T10 · Limit evidence:** Publish the selected “Compatibility inventory” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M11.07-C009 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for compatibility inventory with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M11.07-C009-T01 · Event inventory:** List the “Compatibility inventory” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M11.07-C009-T02 · Diagnostic schema:** Define nonsecret fields for “Compatibility inventory” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M11.07-C009-T03 · Failure mapping:** Map each documented “Compatibility inventory” refusal or error to a diagnostic outcome; include “Only ship version is checked while ABI versions differ” and prohibit conversion into a success message.
- [ ] **UC-M11.07-C009-T04 · Emission path:** Add the “Compatibility inventory” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M11.07-C009-T05 · Redaction check:** Test “Compatibility inventory” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M11.07-C009-T06 · Output budget:** Set and exercise bounded “Compatibility inventory” message size, rate and retention compatible with “Versions and supported combinations”; define truncation behavior that preserves the final reason.
- [ ] **UC-M11.07-C009-T07 · Success/refusal fixtures:** Capture “Compatibility inventory” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M11.07-C009-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Compatibility inventory” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M11.07-C009-T09 · Operator review:** Read the “Compatibility inventory” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M11.07-C009-T10 · Diagnostic evidence:** Publish redacted “Compatibility inventory” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M11.07-C010 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for compatibility inventory; label unexecuted checks as untested.

- [ ] **UC-M11.07-C010-T01 · Evidence inventory:** List the “Compatibility inventory” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M11.07-C010-T02 · Artifact references:** Record the exact “Compatibility inventory” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M11.07-C010-T03 · Fixture references:** Attach the “Compatibility inventory” fixture IDs, input identities and oracle definition; preserve the source counterexample “Only ship version is checked while ABI versions differ” as a distinct evidence case.
- [ ] **UC-M11.07-C010-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Compatibility inventory”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M11.07-C010-T05 · Environment record:** Record the actual “Compatibility inventory” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M11.07-C010-T06 · Expected versus observed:** Pair every “Compatibility inventory” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M11.07-C010-T07 · Failure and limit records:** Attach “Compatibility inventory” change/failure and bounds evidence where required; include uncovered “Versions and supported combinations” and unresolved violations of “Compatibility decisions include all required execution and state contracts”.
- [ ] **UC-M11.07-C010-T08 · Evidence hygiene:** Check the “Compatibility inventory” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M11.07-C010-T09 · Reproduction review:** Have the “Compatibility inventory” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M11.07-C010-T10 · Acceptance linkage:** Link the “Compatibility inventory” evidence to its parent and UC-M11.07 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 02. Mixed-version policy

**Source delivery:** Define explicitly supported mixed-version windows and refused combinations.

**Source invariant:** Unknown combinations do not silently interoperate.

**Source negative case:** A future worker protocol is accepted by an older controller.

**Source bounded quantities:** Compatibility matrix and rollout duration.

### UC-M11.07-C011 · Contract

**Original checklist item:** Specify mixed-version policy inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M11.07-C011-T01 · Scope statement:** Draft the operation boundary for “Mixed-version policy” within Rolling upgrades and compatibility negotiation; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M11.07-C011-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Mixed-version policy”; record each producer, representation and missing-value meaning.
- [ ] **UC-M11.07-C011-T03 · Output inventory:** List the outputs of “Mixed-version policy” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M11.07-C011-T04 · Field dictionary:** Create a field-and-term dictionary for “Mixed-version policy”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M11.07-C011-T05 · Prerequisite contract:** Map “Mixed-version policy” to the source component prerequisites (UC-M01.02, UC-M07.08, UC-M11.05); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M11.07-C011-T06 · Authority map:** Identify who may produce, change and consume “Mixed-version policy”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M11.07-C011-T07 · Invariant clause:** Add a normative clause for “Mixed-version policy” that preserves “Unknown combinations do not silently interoperate”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M11.07-C011-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Mixed-version policy”; include the source counterexample “A future worker protocol is accepted by an older controller” and the intended safe disposition.
- [ ] **UC-M11.07-C011-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Compatibility matrix and rollout duration” in the “Mixed-version policy” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M11.07-C011-T10 · Contract review:** Review the “Mixed-version policy” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M11.07-C012 · Delivery

**Original checklist item:** Define explicitly supported mixed-version windows and refused combinations.

- [ ] **UC-M11.07-C012-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Mixed-version policy”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M11.07-C012-T02 · Change plan:** Break the source delivery for “Mixed-version policy” into concrete edit targets and reviewable outputs; keep the UC-M11.07 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M11.07-C012-T03 · Core artifact:** Create the “Mixed-version policy” model, schema or inventory that realizes this source instruction: Define explicitly supported mixed-version windows and refused combinations.
- [ ] **UC-M11.07-C012-T04 · Concrete realization:** Populate “Mixed-version policy” with one concrete worked case; map every required entity or field to its source and flag any unmapped entry.
- [ ] **UC-M11.07-C012-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Mixed-version policy” needed to preserve “Unknown combinations do not silently interoperate”; record an enforcement gap where only a model exists.
- [ ] **UC-M11.07-C012-T06 · Dependency connection:** Connect the “Mixed-version policy” implementation to mixed-version admission, canary gates and compatible state rollback; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M11.07-C012-T07 · Resource behavior:** Account for “Compatibility matrix and rollout duration” in “Mixed-version policy”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M11.07-C012-T08 · Delivery check:** Run the smallest real “Mixed-version policy” path and its adverse fixture “A future worker protocol is accepted by an older controller”; retain actual output, state effects and final disposition.
- [ ] **UC-M11.07-C012-T09 · Patch review:** Review the “Mixed-version policy” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M11.07-C012-T10 · Delivery handoff:** Publish the “Mixed-version policy” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M11.07-C013 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Unknown combinations do not silently interoperate. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M11.07-C013-T01 · Named property:** Create a stable property/check name under this parent for “Mixed-version policy”; copy its required invariant exactly: “Unknown combinations do not silently interoperate”.
- [ ] **UC-M11.07-C013-T02 · Observable terms:** Define each term in the “Mixed-version policy” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M11.07-C013-T03 · Precondition set:** List the preconditions under which “Unknown combinations do not silently interoperate” must hold for “Mixed-version policy”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M11.07-C013-T04 · Transition coverage:** Map the “Mixed-version policy” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M11.07-C013-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Mixed-version policy”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M11.07-C013-T06 · Satisfying fixture:** Create a concrete “Mixed-version policy” case that satisfies “Unknown combinations do not silently interoperate”; record its expected observation before running the assertion or review.
- [ ] **UC-M11.07-C013-T07 · Violating fixture:** Create the source counterexample “A future worker protocol is accepted by an older controller” for “Mixed-version policy”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M11.07-C013-T08 · Enforcement evidence:** Exercise the “Mixed-version policy” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M11.07-C013-T09 · Regression linkage:** Link the “Mixed-version policy” property to changes in mixed-version admission, canary gates and compatible state rollback; record which dependency or contract changes require rerunning it.
- [ ] **UC-M11.07-C013-T10 · Property disposition:** Compare the satisfying and violating “Mixed-version policy” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M11.07-C014 · Integration

**Original checklist item:** Integrate mixed-version policy with mixed-version admission, canary gates and compatible state rollback; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M11.07-C014-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Mixed-version policy” across mixed-version admission, canary gates and compatible state rollback; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M11.07-C014-T02 · Field mapping:** Map every “Mixed-version policy” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M11.07-C014-T03 · Prerequisite identities:** Record the actual prerequisites for “Mixed-version policy” (source dependency list: UC-M01.02, UC-M07.08, UC-M11.05); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M11.07-C014-T04 · Ownership agreement:** Specify who owns “Mixed-version policy” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M11.07-C014-T05 · Handoff implementation:** Connect “Mixed-version policy” through the mapped seam using the real adapter or explicit specification reference; preserve “Unknown combinations do not silently interoperate” across the handoff.
- [ ] **UC-M11.07-C014-T06 · Absent-input case:** Omit one required “Mixed-version policy” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M11.07-C014-T07 · Stale-input case:** Supply an outdated “Mixed-version policy” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M11.07-C014-T08 · Incompatible-input case:** Supply an incompatible “Mixed-version policy” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M11.07-C014-T09 · Valid integration trace:** Run a valid “Mixed-version policy” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M11.07-C014-T10 · Seam review:** Reconcile the “Mixed-version policy” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M11.07-C015 · Valid-case test

**Original checklist item:** Run a valid-path fixture for mixed-version policy; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M11.07-C015-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Mixed-version policy” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M11.07-C015-T02 · Expected-result oracle:** Specify the “Mixed-version policy” expected result independently of the implementation output; include the property “Unknown combinations do not silently interoperate” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M11.07-C015-T03 · Fixture material:** Create the concrete “Mixed-version policy” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M11.07-C015-T04 · Target preparation:** Prepare the “Mixed-version policy” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M11.07-C015-T05 · Initial-state record:** Record the initial “Mixed-version policy” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M11.07-C015-T06 · Valid-path execution:** Execute the “Mixed-version policy” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M11.07-C015-T07 · Outcome comparison:** Compare every declared “Mixed-version policy” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M11.07-C015-T08 · State and bounds check:** Inspect the “Mixed-version policy” ownership/state effects and actual use of “Compatibility matrix and rollout duration”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M11.07-C015-T09 · Repeatability check:** Repeat the same “Mixed-version policy” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M11.07-C015-T10 · Positive evidence:** Attach the “Mixed-version policy” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M11.07-C016 · Negative test

**Original checklist item:** Negative case: A future worker protocol is accepted by an older controller. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M11.07-C016-T01 · Adverse-case definition:** Create a test record for the exact “Mixed-version policy” source counterexample: “A future worker protocol is accepted by an older controller”; state which precondition or invariant it challenges.
- [ ] **UC-M11.07-C016-T02 · Safe fixture boundary:** Define the contained test boundary for “Mixed-version policy”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M11.07-C016-T03 · Valid control:** Construct a valid “Mixed-version policy” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M11.07-C016-T04 · Minimal adverse input:** Derive the “Mixed-version policy” adverse fixture from the control with the smallest documented change needed to reproduce “A future worker protocol is accepted by an older controller”; retain that change as reproducible data.
- [ ] **UC-M11.07-C016-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Mixed-version policy”; require “Unknown combinations do not silently interoperate” and forbid a false-success verdict.
- [ ] **UC-M11.07-C016-T06 · Adverse execution:** Exercise the “Mixed-version policy” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M11.07-C016-T07 · Effect inspection:** Inspect “Mixed-version policy” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M11.07-C016-T08 · Refusal versus failure:** Confirm the “Mixed-version policy” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M11.07-C016-T09 · Reset and retention:** Restore only the disposable “Mixed-version policy” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M11.07-C016-T10 · Negative regression:** Register the “Mixed-version policy” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M11.07-C017 · Change / failure test

**Original checklist item:** Exercise mixed-version policy when a canary fails while other workers are still on the previous approved version; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M11.07-C017-T01 · Scenario record:** Write the “Mixed-version policy” change/failure scenario exactly as supplied: a canary fails while other workers are still on the previous approved version; identify the property that must remain true: “Unknown combinations do not silently interoperate”.
- [ ] **UC-M11.07-C017-T02 · Baseline capture:** Create a known-valid “Mixed-version policy” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M11.07-C017-T03 · Injection map:** Locate the “Mixed-version policy” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M11.07-C017-T04 · Disposition oracle:** Define the legal intermediate and final “Mixed-version policy” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M11.07-C017-T05 · Controlled trigger:** Introduce the controlled “Mixed-version policy” scenario in the disposable fixture: a canary fails while other workers are still on the previous approved version; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M11.07-C017-T06 · Intermediate inspection:** Inspect the “Mixed-version policy” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M11.07-C017-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Mixed-version policy”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M11.07-C017-T08 · Stale-evidence cleanup:** Invalidate superseded “Mixed-version policy” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M11.07-C017-T09 · Repeat and compare:** Repeat the selected “Mixed-version policy” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M11.07-C017-T10 · Failure evidence:** Publish the “Mixed-version policy” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M11.07-C018 · Bounds

**Original checklist item:** Choose, document and test limits for compatibility matrix and rollout duration; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M11.07-C018-T01 · Quantity inventory:** Create a measurement inventory for “Mixed-version policy”: “Compatibility matrix and rollout duration”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M11.07-C018-T02 · Measurement method:** Choose how to observe each “Mixed-version policy” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M11.07-C018-T03 · Budget decision:** Select justified resource and input limits for “Mixed-version policy”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M11.07-C018-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Mixed-version policy” cases for “Compatibility matrix and rollout duration”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M11.07-C018-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Mixed-version policy” limit; preserve “Unknown combinations do not silently interoperate”.
- [ ] **UC-M11.07-C018-T06 · Normal measurement:** Run or review the normal “Mixed-version policy” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M11.07-C018-T07 · At-limit measurement:** Exercise the “Mixed-version policy” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M11.07-C018-T08 · Over-limit measurement:** Exercise the “Mixed-version policy” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M11.07-C018-T09 · Uncovered-scope report:** List the “Mixed-version policy” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M11.07-C018-T10 · Limit evidence:** Publish the selected “Mixed-version policy” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M11.07-C019 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for mixed-version policy with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M11.07-C019-T01 · Event inventory:** List the “Mixed-version policy” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M11.07-C019-T02 · Diagnostic schema:** Define nonsecret fields for “Mixed-version policy” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M11.07-C019-T03 · Failure mapping:** Map each documented “Mixed-version policy” refusal or error to a diagnostic outcome; include “A future worker protocol is accepted by an older controller” and prohibit conversion into a success message.
- [ ] **UC-M11.07-C019-T04 · Emission path:** Add the “Mixed-version policy” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M11.07-C019-T05 · Redaction check:** Test “Mixed-version policy” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M11.07-C019-T06 · Output budget:** Set and exercise bounded “Mixed-version policy” message size, rate and retention compatible with “Compatibility matrix and rollout duration”; define truncation behavior that preserves the final reason.
- [ ] **UC-M11.07-C019-T07 · Success/refusal fixtures:** Capture “Mixed-version policy” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M11.07-C019-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Mixed-version policy” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M11.07-C019-T09 · Operator review:** Read the “Mixed-version policy” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M11.07-C019-T10 · Diagnostic evidence:** Publish redacted “Mixed-version policy” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M11.07-C020 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for mixed-version policy; label unexecuted checks as untested.

- [ ] **UC-M11.07-C020-T01 · Evidence inventory:** List the “Mixed-version policy” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M11.07-C020-T02 · Artifact references:** Record the exact “Mixed-version policy” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M11.07-C020-T03 · Fixture references:** Attach the “Mixed-version policy” fixture IDs, input identities and oracle definition; preserve the source counterexample “A future worker protocol is accepted by an older controller” as a distinct evidence case.
- [ ] **UC-M11.07-C020-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Mixed-version policy”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M11.07-C020-T05 · Environment record:** Record the actual “Mixed-version policy” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M11.07-C020-T06 · Expected versus observed:** Pair every “Mixed-version policy” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M11.07-C020-T07 · Failure and limit records:** Attach “Mixed-version policy” change/failure and bounds evidence where required; include uncovered “Compatibility matrix and rollout duration” and unresolved violations of “Unknown combinations do not silently interoperate”.
- [ ] **UC-M11.07-C020-T08 · Evidence hygiene:** Check the “Mixed-version policy” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M11.07-C020-T09 · Reproduction review:** Have the “Mixed-version policy” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M11.07-C020-T10 · Acceptance linkage:** Link the “Mixed-version policy” evidence to its parent and UC-M11.07 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 03. Canary selection

**Source delivery:** Select an explicit bounded canary set representative of the intended rollout.

**Source invariant:** A canary is identified and observed before broad promotion.

**Source negative case:** Every worker upgrades at once while being labeled a canary.

**Source bounded quantities:** Canary workers and workloads.

### UC-M11.07-C021 · Contract

**Original checklist item:** Specify canary selection inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M11.07-C021-T01 · Scope statement:** Draft the operation boundary for “Canary selection” within Rolling upgrades and compatibility negotiation; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M11.07-C021-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Canary selection”; record each producer, representation and missing-value meaning.
- [ ] **UC-M11.07-C021-T03 · Output inventory:** List the outputs of “Canary selection” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M11.07-C021-T04 · Field dictionary:** Create a field-and-term dictionary for “Canary selection”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M11.07-C021-T05 · Prerequisite contract:** Map “Canary selection” to the source component prerequisites (UC-M01.02, UC-M07.08, UC-M11.05); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M11.07-C021-T06 · Authority map:** Identify who may produce, change and consume “Canary selection”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M11.07-C021-T07 · Invariant clause:** Add a normative clause for “Canary selection” that preserves “A canary is identified and observed before broad promotion”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M11.07-C021-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Canary selection”; include the source counterexample “Every worker upgrades at once while being labeled a canary” and the intended safe disposition.
- [ ] **UC-M11.07-C021-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Canary workers and workloads” in the “Canary selection” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M11.07-C021-T10 · Contract review:** Review the “Canary selection” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M11.07-C022 · Delivery

**Original checklist item:** Select an explicit bounded canary set representative of the intended rollout.

- [ ] **UC-M11.07-C022-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Canary selection”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M11.07-C022-T02 · Change plan:** Break the source delivery for “Canary selection” into concrete edit targets and reviewable outputs; keep the UC-M11.07 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M11.07-C022-T03 · Core artifact:** Prepare the “Canary selection” decision record for this source instruction: Select an explicit bounded canary set representative of the intended rollout.
- [ ] **UC-M11.07-C022-T04 · Concrete realization:** Evaluate the “Canary selection” choice against its declared constraints; record the exact selected target/configuration and rejected alternatives, leaving unverified compatibility as a blocker.
- [ ] **UC-M11.07-C022-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Canary selection” needed to preserve “A canary is identified and observed before broad promotion”; record an enforcement gap where only a model exists.
- [ ] **UC-M11.07-C022-T06 · Dependency connection:** Connect the “Canary selection” implementation to mixed-version admission, canary gates and compatible state rollback; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M11.07-C022-T07 · Resource behavior:** Account for “Canary workers and workloads” in “Canary selection”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M11.07-C022-T08 · Delivery check:** Run the smallest real “Canary selection” path and its adverse fixture “Every worker upgrades at once while being labeled a canary”; retain actual output, state effects and final disposition.
- [ ] **UC-M11.07-C022-T09 · Patch review:** Review the “Canary selection” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M11.07-C022-T10 · Delivery handoff:** Publish the “Canary selection” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M11.07-C023 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: A canary is identified and observed before broad promotion. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M11.07-C023-T01 · Named property:** Create a stable property/check name under this parent for “Canary selection”; copy its required invariant exactly: “A canary is identified and observed before broad promotion”.
- [ ] **UC-M11.07-C023-T02 · Observable terms:** Define each term in the “Canary selection” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M11.07-C023-T03 · Precondition set:** List the preconditions under which “A canary is identified and observed before broad promotion” must hold for “Canary selection”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M11.07-C023-T04 · Transition coverage:** Map the “Canary selection” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M11.07-C023-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Canary selection”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M11.07-C023-T06 · Satisfying fixture:** Create a concrete “Canary selection” case that satisfies “A canary is identified and observed before broad promotion”; record its expected observation before running the assertion or review.
- [ ] **UC-M11.07-C023-T07 · Violating fixture:** Create the source counterexample “Every worker upgrades at once while being labeled a canary” for “Canary selection”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M11.07-C023-T08 · Enforcement evidence:** Exercise the “Canary selection” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M11.07-C023-T09 · Regression linkage:** Link the “Canary selection” property to changes in mixed-version admission, canary gates and compatible state rollback; record which dependency or contract changes require rerunning it.
- [ ] **UC-M11.07-C023-T10 · Property disposition:** Compare the satisfying and violating “Canary selection” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M11.07-C024 · Integration

**Original checklist item:** Integrate canary selection with mixed-version admission, canary gates and compatible state rollback; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M11.07-C024-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Canary selection” across mixed-version admission, canary gates and compatible state rollback; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M11.07-C024-T02 · Field mapping:** Map every “Canary selection” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M11.07-C024-T03 · Prerequisite identities:** Record the actual prerequisites for “Canary selection” (source dependency list: UC-M01.02, UC-M07.08, UC-M11.05); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M11.07-C024-T04 · Ownership agreement:** Specify who owns “Canary selection” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M11.07-C024-T05 · Handoff implementation:** Connect “Canary selection” through the mapped seam using the real adapter or explicit specification reference; preserve “A canary is identified and observed before broad promotion” across the handoff.
- [ ] **UC-M11.07-C024-T06 · Absent-input case:** Omit one required “Canary selection” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M11.07-C024-T07 · Stale-input case:** Supply an outdated “Canary selection” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M11.07-C024-T08 · Incompatible-input case:** Supply an incompatible “Canary selection” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M11.07-C024-T09 · Valid integration trace:** Run a valid “Canary selection” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M11.07-C024-T10 · Seam review:** Reconcile the “Canary selection” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M11.07-C025 · Valid-case test

**Original checklist item:** Run a valid-path fixture for canary selection; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M11.07-C025-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Canary selection” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M11.07-C025-T02 · Expected-result oracle:** Specify the “Canary selection” expected result independently of the implementation output; include the property “A canary is identified and observed before broad promotion” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M11.07-C025-T03 · Fixture material:** Create the concrete “Canary selection” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M11.07-C025-T04 · Target preparation:** Prepare the “Canary selection” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M11.07-C025-T05 · Initial-state record:** Record the initial “Canary selection” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M11.07-C025-T06 · Valid-path execution:** Execute the “Canary selection” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M11.07-C025-T07 · Outcome comparison:** Compare every declared “Canary selection” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M11.07-C025-T08 · State and bounds check:** Inspect the “Canary selection” ownership/state effects and actual use of “Canary workers and workloads”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M11.07-C025-T09 · Repeatability check:** Repeat the same “Canary selection” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M11.07-C025-T10 · Positive evidence:** Attach the “Canary selection” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M11.07-C026 · Negative test

**Original checklist item:** Negative case: Every worker upgrades at once while being labeled a canary. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M11.07-C026-T01 · Adverse-case definition:** Create a test record for the exact “Canary selection” source counterexample: “Every worker upgrades at once while being labeled a canary”; state which precondition or invariant it challenges.
- [ ] **UC-M11.07-C026-T02 · Safe fixture boundary:** Define the contained test boundary for “Canary selection”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M11.07-C026-T03 · Valid control:** Construct a valid “Canary selection” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M11.07-C026-T04 · Minimal adverse input:** Derive the “Canary selection” adverse fixture from the control with the smallest documented change needed to reproduce “Every worker upgrades at once while being labeled a canary”; retain that change as reproducible data.
- [ ] **UC-M11.07-C026-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Canary selection”; require “A canary is identified and observed before broad promotion” and forbid a false-success verdict.
- [ ] **UC-M11.07-C026-T06 · Adverse execution:** Exercise the “Canary selection” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M11.07-C026-T07 · Effect inspection:** Inspect “Canary selection” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M11.07-C026-T08 · Refusal versus failure:** Confirm the “Canary selection” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M11.07-C026-T09 · Reset and retention:** Restore only the disposable “Canary selection” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M11.07-C026-T10 · Negative regression:** Register the “Canary selection” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M11.07-C027 · Change / failure test

**Original checklist item:** Exercise canary selection when a canary fails while other workers are still on the previous approved version; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M11.07-C027-T01 · Scenario record:** Write the “Canary selection” change/failure scenario exactly as supplied: a canary fails while other workers are still on the previous approved version; identify the property that must remain true: “A canary is identified and observed before broad promotion”.
- [ ] **UC-M11.07-C027-T02 · Baseline capture:** Create a known-valid “Canary selection” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M11.07-C027-T03 · Injection map:** Locate the “Canary selection” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M11.07-C027-T04 · Disposition oracle:** Define the legal intermediate and final “Canary selection” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M11.07-C027-T05 · Controlled trigger:** Introduce the controlled “Canary selection” scenario in the disposable fixture: a canary fails while other workers are still on the previous approved version; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M11.07-C027-T06 · Intermediate inspection:** Inspect the “Canary selection” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M11.07-C027-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Canary selection”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M11.07-C027-T08 · Stale-evidence cleanup:** Invalidate superseded “Canary selection” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M11.07-C027-T09 · Repeat and compare:** Repeat the selected “Canary selection” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M11.07-C027-T10 · Failure evidence:** Publish the “Canary selection” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M11.07-C028 · Bounds

**Original checklist item:** Choose, document and test limits for canary workers and workloads; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M11.07-C028-T01 · Quantity inventory:** Create a measurement inventory for “Canary selection”: “Canary workers and workloads”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M11.07-C028-T02 · Measurement method:** Choose how to observe each “Canary selection” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M11.07-C028-T03 · Budget decision:** Select justified resource and input limits for “Canary selection”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M11.07-C028-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Canary selection” cases for “Canary workers and workloads”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M11.07-C028-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Canary selection” limit; preserve “A canary is identified and observed before broad promotion”.
- [ ] **UC-M11.07-C028-T06 · Normal measurement:** Run or review the normal “Canary selection” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M11.07-C028-T07 · At-limit measurement:** Exercise the “Canary selection” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M11.07-C028-T08 · Over-limit measurement:** Exercise the “Canary selection” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M11.07-C028-T09 · Uncovered-scope report:** List the “Canary selection” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M11.07-C028-T10 · Limit evidence:** Publish the selected “Canary selection” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M11.07-C029 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for canary selection with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M11.07-C029-T01 · Event inventory:** List the “Canary selection” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M11.07-C029-T02 · Diagnostic schema:** Define nonsecret fields for “Canary selection” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M11.07-C029-T03 · Failure mapping:** Map each documented “Canary selection” refusal or error to a diagnostic outcome; include “Every worker upgrades at once while being labeled a canary” and prohibit conversion into a success message.
- [ ] **UC-M11.07-C029-T04 · Emission path:** Add the “Canary selection” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M11.07-C029-T05 · Redaction check:** Test “Canary selection” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M11.07-C029-T06 · Output budget:** Set and exercise bounded “Canary selection” message size, rate and retention compatible with “Canary workers and workloads”; define truncation behavior that preserves the final reason.
- [ ] **UC-M11.07-C029-T07 · Success/refusal fixtures:** Capture “Canary selection” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M11.07-C029-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Canary selection” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M11.07-C029-T09 · Operator review:** Read the “Canary selection” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M11.07-C029-T10 · Diagnostic evidence:** Publish redacted “Canary selection” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M11.07-C030 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for canary selection; label unexecuted checks as untested.

- [ ] **UC-M11.07-C030-T01 · Evidence inventory:** List the “Canary selection” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M11.07-C030-T02 · Artifact references:** Record the exact “Canary selection” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M11.07-C030-T03 · Fixture references:** Attach the “Canary selection” fixture IDs, input identities and oracle definition; preserve the source counterexample “Every worker upgrades at once while being labeled a canary” as a distinct evidence case.
- [ ] **UC-M11.07-C030-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Canary selection”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M11.07-C030-T05 · Environment record:** Record the actual “Canary selection” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M11.07-C030-T06 · Expected versus observed:** Pair every “Canary selection” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M11.07-C030-T07 · Failure and limit records:** Attach “Canary selection” change/failure and bounds evidence where required; include uncovered “Canary workers and workloads” and unresolved violations of “A canary is identified and observed before broad promotion”.
- [ ] **UC-M11.07-C030-T08 · Evidence hygiene:** Check the “Canary selection” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M11.07-C030-T09 · Reproduction review:** Have the “Canary selection” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M11.07-C030-T10 · Acceptance linkage:** Link the “Canary selection” evidence to its parent and UC-M11.07 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 04. Admission during rollout

**Source delivery:** Admit work only to workers compatible with its required contracts.

**Source invariant:** Rolling upgrades cannot route work to incompatible state or ABI versions.

**Source negative case:** A new image is dispatched to an old incompatible worker.

**Source bounded quantities:** Pending work and compatibility-check time.

### UC-M11.07-C031 · Contract

**Original checklist item:** Specify admission during rollout inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M11.07-C031-T01 · Scope statement:** Draft the operation boundary for “Admission during rollout” within Rolling upgrades and compatibility negotiation; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M11.07-C031-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Admission during rollout”; record each producer, representation and missing-value meaning.
- [ ] **UC-M11.07-C031-T03 · Output inventory:** List the outputs of “Admission during rollout” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M11.07-C031-T04 · Field dictionary:** Create a field-and-term dictionary for “Admission during rollout”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M11.07-C031-T05 · Prerequisite contract:** Map “Admission during rollout” to the source component prerequisites (UC-M01.02, UC-M07.08, UC-M11.05); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M11.07-C031-T06 · Authority map:** Identify who may produce, change and consume “Admission during rollout”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M11.07-C031-T07 · Invariant clause:** Add a normative clause for “Admission during rollout” that preserves “Rolling upgrades cannot route work to incompatible state or ABI versions”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M11.07-C031-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Admission during rollout”; include the source counterexample “A new image is dispatched to an old incompatible worker” and the intended safe disposition.
- [ ] **UC-M11.07-C031-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Pending work and compatibility-check time” in the “Admission during rollout” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M11.07-C031-T10 · Contract review:** Review the “Admission during rollout” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M11.07-C032 · Delivery

**Original checklist item:** Admit work only to workers compatible with its required contracts.

- [ ] **UC-M11.07-C032-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Admission during rollout”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M11.07-C032-T02 · Change plan:** Break the source delivery for “Admission during rollout” into concrete edit targets and reviewable outputs; keep the UC-M11.07 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M11.07-C032-T03 · Core artifact:** Implement the smallest selected-profile change for “Admission during rollout” that realizes this source instruction: Admit work only to workers compatible with its required contracts.
- [ ] **UC-M11.07-C032-T04 · Concrete realization:** Trace “Admission during rollout” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M11.07-C032-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Admission during rollout” needed to preserve “Rolling upgrades cannot route work to incompatible state or ABI versions”; record an enforcement gap where only a model exists.
- [ ] **UC-M11.07-C032-T06 · Dependency connection:** Connect the “Admission during rollout” implementation to mixed-version admission, canary gates and compatible state rollback; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M11.07-C032-T07 · Resource behavior:** Account for “Pending work and compatibility-check time” in “Admission during rollout”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M11.07-C032-T08 · Delivery check:** Run the smallest real “Admission during rollout” path and its adverse fixture “A new image is dispatched to an old incompatible worker”; retain actual output, state effects and final disposition.
- [ ] **UC-M11.07-C032-T09 · Patch review:** Review the “Admission during rollout” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M11.07-C032-T10 · Delivery handoff:** Publish the “Admission during rollout” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M11.07-C033 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Rolling upgrades cannot route work to incompatible state or ABI versions. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M11.07-C033-T01 · Named property:** Create a stable property/check name under this parent for “Admission during rollout”; copy its required invariant exactly: “Rolling upgrades cannot route work to incompatible state or ABI versions”.
- [ ] **UC-M11.07-C033-T02 · Observable terms:** Define each term in the “Admission during rollout” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M11.07-C033-T03 · Precondition set:** List the preconditions under which “Rolling upgrades cannot route work to incompatible state or ABI versions” must hold for “Admission during rollout”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M11.07-C033-T04 · Transition coverage:** Map the “Admission during rollout” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M11.07-C033-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Admission during rollout”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M11.07-C033-T06 · Satisfying fixture:** Create a concrete “Admission during rollout” case that satisfies “Rolling upgrades cannot route work to incompatible state or ABI versions”; record its expected observation before running the assertion or review.
- [ ] **UC-M11.07-C033-T07 · Violating fixture:** Create the source counterexample “A new image is dispatched to an old incompatible worker” for “Admission during rollout”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M11.07-C033-T08 · Enforcement evidence:** Exercise the “Admission during rollout” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M11.07-C033-T09 · Regression linkage:** Link the “Admission during rollout” property to changes in mixed-version admission, canary gates and compatible state rollback; record which dependency or contract changes require rerunning it.
- [ ] **UC-M11.07-C033-T10 · Property disposition:** Compare the satisfying and violating “Admission during rollout” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M11.07-C034 · Integration

**Original checklist item:** Integrate admission during rollout with mixed-version admission, canary gates and compatible state rollback; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M11.07-C034-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Admission during rollout” across mixed-version admission, canary gates and compatible state rollback; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M11.07-C034-T02 · Field mapping:** Map every “Admission during rollout” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M11.07-C034-T03 · Prerequisite identities:** Record the actual prerequisites for “Admission during rollout” (source dependency list: UC-M01.02, UC-M07.08, UC-M11.05); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M11.07-C034-T04 · Ownership agreement:** Specify who owns “Admission during rollout” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M11.07-C034-T05 · Handoff implementation:** Connect “Admission during rollout” through the mapped seam using the real adapter or explicit specification reference; preserve “Rolling upgrades cannot route work to incompatible state or ABI versions” across the handoff.
- [ ] **UC-M11.07-C034-T06 · Absent-input case:** Omit one required “Admission during rollout” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M11.07-C034-T07 · Stale-input case:** Supply an outdated “Admission during rollout” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M11.07-C034-T08 · Incompatible-input case:** Supply an incompatible “Admission during rollout” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M11.07-C034-T09 · Valid integration trace:** Run a valid “Admission during rollout” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M11.07-C034-T10 · Seam review:** Reconcile the “Admission during rollout” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M11.07-C035 · Valid-case test

**Original checklist item:** Run a valid-path fixture for admission during rollout; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M11.07-C035-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Admission during rollout” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M11.07-C035-T02 · Expected-result oracle:** Specify the “Admission during rollout” expected result independently of the implementation output; include the property “Rolling upgrades cannot route work to incompatible state or ABI versions” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M11.07-C035-T03 · Fixture material:** Create the concrete “Admission during rollout” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M11.07-C035-T04 · Target preparation:** Prepare the “Admission during rollout” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M11.07-C035-T05 · Initial-state record:** Record the initial “Admission during rollout” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M11.07-C035-T06 · Valid-path execution:** Execute the “Admission during rollout” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M11.07-C035-T07 · Outcome comparison:** Compare every declared “Admission during rollout” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M11.07-C035-T08 · State and bounds check:** Inspect the “Admission during rollout” ownership/state effects and actual use of “Pending work and compatibility-check time”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M11.07-C035-T09 · Repeatability check:** Repeat the same “Admission during rollout” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M11.07-C035-T10 · Positive evidence:** Attach the “Admission during rollout” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M11.07-C036 · Negative test

**Original checklist item:** Negative case: A new image is dispatched to an old incompatible worker. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M11.07-C036-T01 · Adverse-case definition:** Create a test record for the exact “Admission during rollout” source counterexample: “A new image is dispatched to an old incompatible worker”; state which precondition or invariant it challenges.
- [ ] **UC-M11.07-C036-T02 · Safe fixture boundary:** Define the contained test boundary for “Admission during rollout”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M11.07-C036-T03 · Valid control:** Construct a valid “Admission during rollout” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M11.07-C036-T04 · Minimal adverse input:** Derive the “Admission during rollout” adverse fixture from the control with the smallest documented change needed to reproduce “A new image is dispatched to an old incompatible worker”; retain that change as reproducible data.
- [ ] **UC-M11.07-C036-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Admission during rollout”; require “Rolling upgrades cannot route work to incompatible state or ABI versions” and forbid a false-success verdict.
- [ ] **UC-M11.07-C036-T06 · Adverse execution:** Exercise the “Admission during rollout” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M11.07-C036-T07 · Effect inspection:** Inspect “Admission during rollout” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M11.07-C036-T08 · Refusal versus failure:** Confirm the “Admission during rollout” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M11.07-C036-T09 · Reset and retention:** Restore only the disposable “Admission during rollout” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M11.07-C036-T10 · Negative regression:** Register the “Admission during rollout” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M11.07-C037 · Change / failure test

**Original checklist item:** Exercise admission during rollout when a canary fails while other workers are still on the previous approved version; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M11.07-C037-T01 · Scenario record:** Write the “Admission during rollout” change/failure scenario exactly as supplied: a canary fails while other workers are still on the previous approved version; identify the property that must remain true: “Rolling upgrades cannot route work to incompatible state or ABI versions”.
- [ ] **UC-M11.07-C037-T02 · Baseline capture:** Create a known-valid “Admission during rollout” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M11.07-C037-T03 · Injection map:** Locate the “Admission during rollout” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M11.07-C037-T04 · Disposition oracle:** Define the legal intermediate and final “Admission during rollout” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M11.07-C037-T05 · Controlled trigger:** Introduce the controlled “Admission during rollout” scenario in the disposable fixture: a canary fails while other workers are still on the previous approved version; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M11.07-C037-T06 · Intermediate inspection:** Inspect the “Admission during rollout” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M11.07-C037-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Admission during rollout”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M11.07-C037-T08 · Stale-evidence cleanup:** Invalidate superseded “Admission during rollout” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M11.07-C037-T09 · Repeat and compare:** Repeat the selected “Admission during rollout” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M11.07-C037-T10 · Failure evidence:** Publish the “Admission during rollout” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M11.07-C038 · Bounds

**Original checklist item:** Choose, document and test limits for pending work and compatibility-check time; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M11.07-C038-T01 · Quantity inventory:** Create a measurement inventory for “Admission during rollout”: “Pending work and compatibility-check time”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M11.07-C038-T02 · Measurement method:** Choose how to observe each “Admission during rollout” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M11.07-C038-T03 · Budget decision:** Select justified resource and input limits for “Admission during rollout”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M11.07-C038-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Admission during rollout” cases for “Pending work and compatibility-check time”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M11.07-C038-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Admission during rollout” limit; preserve “Rolling upgrades cannot route work to incompatible state or ABI versions”.
- [ ] **UC-M11.07-C038-T06 · Normal measurement:** Run or review the normal “Admission during rollout” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M11.07-C038-T07 · At-limit measurement:** Exercise the “Admission during rollout” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M11.07-C038-T08 · Over-limit measurement:** Exercise the “Admission during rollout” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M11.07-C038-T09 · Uncovered-scope report:** List the “Admission during rollout” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M11.07-C038-T10 · Limit evidence:** Publish the selected “Admission during rollout” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M11.07-C039 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for admission during rollout with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M11.07-C039-T01 · Event inventory:** List the “Admission during rollout” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M11.07-C039-T02 · Diagnostic schema:** Define nonsecret fields for “Admission during rollout” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M11.07-C039-T03 · Failure mapping:** Map each documented “Admission during rollout” refusal or error to a diagnostic outcome; include “A new image is dispatched to an old incompatible worker” and prohibit conversion into a success message.
- [ ] **UC-M11.07-C039-T04 · Emission path:** Add the “Admission during rollout” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M11.07-C039-T05 · Redaction check:** Test “Admission during rollout” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M11.07-C039-T06 · Output budget:** Set and exercise bounded “Admission during rollout” message size, rate and retention compatible with “Pending work and compatibility-check time”; define truncation behavior that preserves the final reason.
- [ ] **UC-M11.07-C039-T07 · Success/refusal fixtures:** Capture “Admission during rollout” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M11.07-C039-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Admission during rollout” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M11.07-C039-T09 · Operator review:** Read the “Admission during rollout” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M11.07-C039-T10 · Diagnostic evidence:** Publish redacted “Admission during rollout” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M11.07-C040 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for admission during rollout; label unexecuted checks as untested.

- [ ] **UC-M11.07-C040-T01 · Evidence inventory:** List the “Admission during rollout” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M11.07-C040-T02 · Artifact references:** Record the exact “Admission during rollout” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M11.07-C040-T03 · Fixture references:** Attach the “Admission during rollout” fixture IDs, input identities and oracle definition; preserve the source counterexample “A new image is dispatched to an old incompatible worker” as a distinct evidence case.
- [ ] **UC-M11.07-C040-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Admission during rollout”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M11.07-C040-T05 · Environment record:** Record the actual “Admission during rollout” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M11.07-C040-T06 · Expected versus observed:** Pair every “Admission during rollout” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M11.07-C040-T07 · Failure and limit records:** Attach “Admission during rollout” change/failure and bounds evidence where required; include uncovered “Pending work and compatibility-check time” and unresolved violations of “Rolling upgrades cannot route work to incompatible state or ABI versions”.
- [ ] **UC-M11.07-C040-T08 · Evidence hygiene:** Check the “Admission during rollout” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M11.07-C040-T09 · Reproduction review:** Have the “Admission during rollout” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M11.07-C040-T10 · Acceptance linkage:** Link the “Admission during rollout” evidence to its parent and UC-M11.07 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 05. Drain and upgrade sequencing

**Source delivery:** Drain selected workers before changing their executable or state compatibility.

**Source invariant:** Accepted work receives a documented disposition before replacement.

**Source negative case:** A worker is replaced during an uncommitted invocation.

**Source bounded quantities:** Drain deadline and batch size.

### UC-M11.07-C041 · Contract

**Original checklist item:** Specify drain and upgrade sequencing inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M11.07-C041-T01 · Scope statement:** Draft the operation boundary for “Drain and upgrade sequencing” within Rolling upgrades and compatibility negotiation; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M11.07-C041-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Drain and upgrade sequencing”; record each producer, representation and missing-value meaning.
- [ ] **UC-M11.07-C041-T03 · Output inventory:** List the outputs of “Drain and upgrade sequencing” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M11.07-C041-T04 · Field dictionary:** Create a field-and-term dictionary for “Drain and upgrade sequencing”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M11.07-C041-T05 · Prerequisite contract:** Map “Drain and upgrade sequencing” to the source component prerequisites (UC-M01.02, UC-M07.08, UC-M11.05); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M11.07-C041-T06 · Authority map:** Identify who may produce, change and consume “Drain and upgrade sequencing”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M11.07-C041-T07 · Invariant clause:** Add a normative clause for “Drain and upgrade sequencing” that preserves “Accepted work receives a documented disposition before replacement”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M11.07-C041-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Drain and upgrade sequencing”; include the source counterexample “A worker is replaced during an uncommitted invocation” and the intended safe disposition.
- [ ] **UC-M11.07-C041-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Drain deadline and batch size” in the “Drain and upgrade sequencing” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M11.07-C041-T10 · Contract review:** Review the “Drain and upgrade sequencing” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M11.07-C042 · Delivery

**Original checklist item:** Drain selected workers before changing their executable or state compatibility.

- [ ] **UC-M11.07-C042-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Drain and upgrade sequencing”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M11.07-C042-T02 · Change plan:** Break the source delivery for “Drain and upgrade sequencing” into concrete edit targets and reviewable outputs; keep the UC-M11.07 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M11.07-C042-T03 · Core artifact:** Implement the smallest selected-profile change for “Drain and upgrade sequencing” that realizes this source instruction: Drain selected workers before changing their executable or state compatibility.
- [ ] **UC-M11.07-C042-T04 · Concrete realization:** Trace “Drain and upgrade sequencing” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M11.07-C042-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Drain and upgrade sequencing” needed to preserve “Accepted work receives a documented disposition before replacement”; record an enforcement gap where only a model exists.
- [ ] **UC-M11.07-C042-T06 · Dependency connection:** Connect the “Drain and upgrade sequencing” implementation to mixed-version admission, canary gates and compatible state rollback; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M11.07-C042-T07 · Resource behavior:** Account for “Drain deadline and batch size” in “Drain and upgrade sequencing”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M11.07-C042-T08 · Delivery check:** Run the smallest real “Drain and upgrade sequencing” path and its adverse fixture “A worker is replaced during an uncommitted invocation”; retain actual output, state effects and final disposition.
- [ ] **UC-M11.07-C042-T09 · Patch review:** Review the “Drain and upgrade sequencing” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M11.07-C042-T10 · Delivery handoff:** Publish the “Drain and upgrade sequencing” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M11.07-C043 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Accepted work receives a documented disposition before replacement. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M11.07-C043-T01 · Named property:** Create a stable property/check name under this parent for “Drain and upgrade sequencing”; copy its required invariant exactly: “Accepted work receives a documented disposition before replacement”.
- [ ] **UC-M11.07-C043-T02 · Observable terms:** Define each term in the “Drain and upgrade sequencing” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M11.07-C043-T03 · Precondition set:** List the preconditions under which “Accepted work receives a documented disposition before replacement” must hold for “Drain and upgrade sequencing”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M11.07-C043-T04 · Transition coverage:** Map the “Drain and upgrade sequencing” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M11.07-C043-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Drain and upgrade sequencing”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M11.07-C043-T06 · Satisfying fixture:** Create a concrete “Drain and upgrade sequencing” case that satisfies “Accepted work receives a documented disposition before replacement”; record its expected observation before running the assertion or review.
- [ ] **UC-M11.07-C043-T07 · Violating fixture:** Create the source counterexample “A worker is replaced during an uncommitted invocation” for “Drain and upgrade sequencing”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M11.07-C043-T08 · Enforcement evidence:** Exercise the “Drain and upgrade sequencing” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M11.07-C043-T09 · Regression linkage:** Link the “Drain and upgrade sequencing” property to changes in mixed-version admission, canary gates and compatible state rollback; record which dependency or contract changes require rerunning it.
- [ ] **UC-M11.07-C043-T10 · Property disposition:** Compare the satisfying and violating “Drain and upgrade sequencing” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M11.07-C044 · Integration

**Original checklist item:** Integrate drain and upgrade sequencing with mixed-version admission, canary gates and compatible state rollback; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M11.07-C044-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Drain and upgrade sequencing” across mixed-version admission, canary gates and compatible state rollback; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M11.07-C044-T02 · Field mapping:** Map every “Drain and upgrade sequencing” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M11.07-C044-T03 · Prerequisite identities:** Record the actual prerequisites for “Drain and upgrade sequencing” (source dependency list: UC-M01.02, UC-M07.08, UC-M11.05); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M11.07-C044-T04 · Ownership agreement:** Specify who owns “Drain and upgrade sequencing” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M11.07-C044-T05 · Handoff implementation:** Connect “Drain and upgrade sequencing” through the mapped seam using the real adapter or explicit specification reference; preserve “Accepted work receives a documented disposition before replacement” across the handoff.
- [ ] **UC-M11.07-C044-T06 · Absent-input case:** Omit one required “Drain and upgrade sequencing” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M11.07-C044-T07 · Stale-input case:** Supply an outdated “Drain and upgrade sequencing” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M11.07-C044-T08 · Incompatible-input case:** Supply an incompatible “Drain and upgrade sequencing” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M11.07-C044-T09 · Valid integration trace:** Run a valid “Drain and upgrade sequencing” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M11.07-C044-T10 · Seam review:** Reconcile the “Drain and upgrade sequencing” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M11.07-C045 · Valid-case test

**Original checklist item:** Run a valid-path fixture for drain and upgrade sequencing; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M11.07-C045-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Drain and upgrade sequencing” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M11.07-C045-T02 · Expected-result oracle:** Specify the “Drain and upgrade sequencing” expected result independently of the implementation output; include the property “Accepted work receives a documented disposition before replacement” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M11.07-C045-T03 · Fixture material:** Create the concrete “Drain and upgrade sequencing” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M11.07-C045-T04 · Target preparation:** Prepare the “Drain and upgrade sequencing” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M11.07-C045-T05 · Initial-state record:** Record the initial “Drain and upgrade sequencing” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M11.07-C045-T06 · Valid-path execution:** Execute the “Drain and upgrade sequencing” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M11.07-C045-T07 · Outcome comparison:** Compare every declared “Drain and upgrade sequencing” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M11.07-C045-T08 · State and bounds check:** Inspect the “Drain and upgrade sequencing” ownership/state effects and actual use of “Drain deadline and batch size”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M11.07-C045-T09 · Repeatability check:** Repeat the same “Drain and upgrade sequencing” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M11.07-C045-T10 · Positive evidence:** Attach the “Drain and upgrade sequencing” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M11.07-C046 · Negative test

**Original checklist item:** Negative case: A worker is replaced during an uncommitted invocation. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M11.07-C046-T01 · Adverse-case definition:** Create a test record for the exact “Drain and upgrade sequencing” source counterexample: “A worker is replaced during an uncommitted invocation”; state which precondition or invariant it challenges.
- [ ] **UC-M11.07-C046-T02 · Safe fixture boundary:** Define the contained test boundary for “Drain and upgrade sequencing”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M11.07-C046-T03 · Valid control:** Construct a valid “Drain and upgrade sequencing” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M11.07-C046-T04 · Minimal adverse input:** Derive the “Drain and upgrade sequencing” adverse fixture from the control with the smallest documented change needed to reproduce “A worker is replaced during an uncommitted invocation”; retain that change as reproducible data.
- [ ] **UC-M11.07-C046-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Drain and upgrade sequencing”; require “Accepted work receives a documented disposition before replacement” and forbid a false-success verdict.
- [ ] **UC-M11.07-C046-T06 · Adverse execution:** Exercise the “Drain and upgrade sequencing” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M11.07-C046-T07 · Effect inspection:** Inspect “Drain and upgrade sequencing” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M11.07-C046-T08 · Refusal versus failure:** Confirm the “Drain and upgrade sequencing” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M11.07-C046-T09 · Reset and retention:** Restore only the disposable “Drain and upgrade sequencing” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M11.07-C046-T10 · Negative regression:** Register the “Drain and upgrade sequencing” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M11.07-C047 · Change / failure test

**Original checklist item:** Exercise drain and upgrade sequencing when a canary fails while other workers are still on the previous approved version; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M11.07-C047-T01 · Scenario record:** Write the “Drain and upgrade sequencing” change/failure scenario exactly as supplied: a canary fails while other workers are still on the previous approved version; identify the property that must remain true: “Accepted work receives a documented disposition before replacement”.
- [ ] **UC-M11.07-C047-T02 · Baseline capture:** Create a known-valid “Drain and upgrade sequencing” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M11.07-C047-T03 · Injection map:** Locate the “Drain and upgrade sequencing” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M11.07-C047-T04 · Disposition oracle:** Define the legal intermediate and final “Drain and upgrade sequencing” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M11.07-C047-T05 · Controlled trigger:** Introduce the controlled “Drain and upgrade sequencing” scenario in the disposable fixture: a canary fails while other workers are still on the previous approved version; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M11.07-C047-T06 · Intermediate inspection:** Inspect the “Drain and upgrade sequencing” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M11.07-C047-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Drain and upgrade sequencing”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M11.07-C047-T08 · Stale-evidence cleanup:** Invalidate superseded “Drain and upgrade sequencing” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M11.07-C047-T09 · Repeat and compare:** Repeat the selected “Drain and upgrade sequencing” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M11.07-C047-T10 · Failure evidence:** Publish the “Drain and upgrade sequencing” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M11.07-C048 · Bounds

**Original checklist item:** Choose, document and test limits for drain deadline and batch size; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M11.07-C048-T01 · Quantity inventory:** Create a measurement inventory for “Drain and upgrade sequencing”: “Drain deadline and batch size”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M11.07-C048-T02 · Measurement method:** Choose how to observe each “Drain and upgrade sequencing” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M11.07-C048-T03 · Budget decision:** Select justified resource and input limits for “Drain and upgrade sequencing”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M11.07-C048-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Drain and upgrade sequencing” cases for “Drain deadline and batch size”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M11.07-C048-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Drain and upgrade sequencing” limit; preserve “Accepted work receives a documented disposition before replacement”.
- [ ] **UC-M11.07-C048-T06 · Normal measurement:** Run or review the normal “Drain and upgrade sequencing” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M11.07-C048-T07 · At-limit measurement:** Exercise the “Drain and upgrade sequencing” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M11.07-C048-T08 · Over-limit measurement:** Exercise the “Drain and upgrade sequencing” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M11.07-C048-T09 · Uncovered-scope report:** List the “Drain and upgrade sequencing” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M11.07-C048-T10 · Limit evidence:** Publish the selected “Drain and upgrade sequencing” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M11.07-C049 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for drain and upgrade sequencing with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M11.07-C049-T01 · Event inventory:** List the “Drain and upgrade sequencing” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M11.07-C049-T02 · Diagnostic schema:** Define nonsecret fields for “Drain and upgrade sequencing” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M11.07-C049-T03 · Failure mapping:** Map each documented “Drain and upgrade sequencing” refusal or error to a diagnostic outcome; include “A worker is replaced during an uncommitted invocation” and prohibit conversion into a success message.
- [ ] **UC-M11.07-C049-T04 · Emission path:** Add the “Drain and upgrade sequencing” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M11.07-C049-T05 · Redaction check:** Test “Drain and upgrade sequencing” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M11.07-C049-T06 · Output budget:** Set and exercise bounded “Drain and upgrade sequencing” message size, rate and retention compatible with “Drain deadline and batch size”; define truncation behavior that preserves the final reason.
- [ ] **UC-M11.07-C049-T07 · Success/refusal fixtures:** Capture “Drain and upgrade sequencing” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M11.07-C049-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Drain and upgrade sequencing” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M11.07-C049-T09 · Operator review:** Read the “Drain and upgrade sequencing” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M11.07-C049-T10 · Diagnostic evidence:** Publish redacted “Drain and upgrade sequencing” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M11.07-C050 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for drain and upgrade sequencing; label unexecuted checks as untested.

- [ ] **UC-M11.07-C050-T01 · Evidence inventory:** List the “Drain and upgrade sequencing” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M11.07-C050-T02 · Artifact references:** Record the exact “Drain and upgrade sequencing” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M11.07-C050-T03 · Fixture references:** Attach the “Drain and upgrade sequencing” fixture IDs, input identities and oracle definition; preserve the source counterexample “A worker is replaced during an uncommitted invocation” as a distinct evidence case.
- [ ] **UC-M11.07-C050-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Drain and upgrade sequencing”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M11.07-C050-T05 · Environment record:** Record the actual “Drain and upgrade sequencing” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M11.07-C050-T06 · Expected versus observed:** Pair every “Drain and upgrade sequencing” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M11.07-C050-T07 · Failure and limit records:** Attach “Drain and upgrade sequencing” change/failure and bounds evidence where required; include uncovered “Drain deadline and batch size” and unresolved violations of “Accepted work receives a documented disposition before replacement”.
- [ ] **UC-M11.07-C050-T08 · Evidence hygiene:** Check the “Drain and upgrade sequencing” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M11.07-C050-T09 · Reproduction review:** Have the “Drain and upgrade sequencing” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M11.07-C050-T10 · Acceptance linkage:** Link the “Drain and upgrade sequencing” evidence to its parent and UC-M11.07 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 06. State migration gates

**Source delivery:** Validate any required state migration before activating the new version.

**Source invariant:** Incompatible state is refused rather than guessed convertible.

**Source negative case:** A new worker boots with old state lacking required fields.

**Source bounded quantities:** Migrated bytes and supported paths.

### UC-M11.07-C051 · Contract

**Original checklist item:** Specify state migration gates inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M11.07-C051-T01 · Scope statement:** Draft the operation boundary for “State migration gates” within Rolling upgrades and compatibility negotiation; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M11.07-C051-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “State migration gates”; record each producer, representation and missing-value meaning.
- [ ] **UC-M11.07-C051-T03 · Output inventory:** List the outputs of “State migration gates” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M11.07-C051-T04 · Field dictionary:** Create a field-and-term dictionary for “State migration gates”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M11.07-C051-T05 · Prerequisite contract:** Map “State migration gates” to the source component prerequisites (UC-M01.02, UC-M07.08, UC-M11.05); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M11.07-C051-T06 · Authority map:** Identify who may produce, change and consume “State migration gates”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M11.07-C051-T07 · Invariant clause:** Add a normative clause for “State migration gates” that preserves “Incompatible state is refused rather than guessed convertible”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M11.07-C051-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “State migration gates”; include the source counterexample “A new worker boots with old state lacking required fields” and the intended safe disposition.
- [ ] **UC-M11.07-C051-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Migrated bytes and supported paths” in the “State migration gates” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M11.07-C051-T10 · Contract review:** Review the “State migration gates” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M11.07-C052 · Delivery

**Original checklist item:** Validate any required state migration before activating the new version.

- [ ] **UC-M11.07-C052-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “State migration gates”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M11.07-C052-T02 · Change plan:** Break the source delivery for “State migration gates” into concrete edit targets and reviewable outputs; keep the UC-M11.07 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M11.07-C052-T03 · Core artifact:** Implement the smallest selected-profile change for “State migration gates” that realizes this source instruction: Validate any required state migration before activating the new version.
- [ ] **UC-M11.07-C052-T04 · Concrete realization:** Trace “State migration gates” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M11.07-C052-T05 · Invariant protection:** Add the actual guard, check or review criterion for “State migration gates” needed to preserve “Incompatible state is refused rather than guessed convertible”; record an enforcement gap where only a model exists.
- [ ] **UC-M11.07-C052-T06 · Dependency connection:** Connect the “State migration gates” implementation to mixed-version admission, canary gates and compatible state rollback; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M11.07-C052-T07 · Resource behavior:** Account for “Migrated bytes and supported paths” in “State migration gates”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M11.07-C052-T08 · Delivery check:** Run the smallest real “State migration gates” path and its adverse fixture “A new worker boots with old state lacking required fields”; retain actual output, state effects and final disposition.
- [ ] **UC-M11.07-C052-T09 · Patch review:** Review the “State migration gates” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M11.07-C052-T10 · Delivery handoff:** Publish the “State migration gates” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M11.07-C053 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Incompatible state is refused rather than guessed convertible. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M11.07-C053-T01 · Named property:** Create a stable property/check name under this parent for “State migration gates”; copy its required invariant exactly: “Incompatible state is refused rather than guessed convertible”.
- [ ] **UC-M11.07-C053-T02 · Observable terms:** Define each term in the “State migration gates” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M11.07-C053-T03 · Precondition set:** List the preconditions under which “Incompatible state is refused rather than guessed convertible” must hold for “State migration gates”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M11.07-C053-T04 · Transition coverage:** Map the “State migration gates” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M11.07-C053-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “State migration gates”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M11.07-C053-T06 · Satisfying fixture:** Create a concrete “State migration gates” case that satisfies “Incompatible state is refused rather than guessed convertible”; record its expected observation before running the assertion or review.
- [ ] **UC-M11.07-C053-T07 · Violating fixture:** Create the source counterexample “A new worker boots with old state lacking required fields” for “State migration gates”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M11.07-C053-T08 · Enforcement evidence:** Exercise the “State migration gates” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M11.07-C053-T09 · Regression linkage:** Link the “State migration gates” property to changes in mixed-version admission, canary gates and compatible state rollback; record which dependency or contract changes require rerunning it.
- [ ] **UC-M11.07-C053-T10 · Property disposition:** Compare the satisfying and violating “State migration gates” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M11.07-C054 · Integration

**Original checklist item:** Integrate state migration gates with mixed-version admission, canary gates and compatible state rollback; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M11.07-C054-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “State migration gates” across mixed-version admission, canary gates and compatible state rollback; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M11.07-C054-T02 · Field mapping:** Map every “State migration gates” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M11.07-C054-T03 · Prerequisite identities:** Record the actual prerequisites for “State migration gates” (source dependency list: UC-M01.02, UC-M07.08, UC-M11.05); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M11.07-C054-T04 · Ownership agreement:** Specify who owns “State migration gates” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M11.07-C054-T05 · Handoff implementation:** Connect “State migration gates” through the mapped seam using the real adapter or explicit specification reference; preserve “Incompatible state is refused rather than guessed convertible” across the handoff.
- [ ] **UC-M11.07-C054-T06 · Absent-input case:** Omit one required “State migration gates” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M11.07-C054-T07 · Stale-input case:** Supply an outdated “State migration gates” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M11.07-C054-T08 · Incompatible-input case:** Supply an incompatible “State migration gates” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M11.07-C054-T09 · Valid integration trace:** Run a valid “State migration gates” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M11.07-C054-T10 · Seam review:** Reconcile the “State migration gates” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M11.07-C055 · Valid-case test

**Original checklist item:** Run a valid-path fixture for state migration gates; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M11.07-C055-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “State migration gates” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M11.07-C055-T02 · Expected-result oracle:** Specify the “State migration gates” expected result independently of the implementation output; include the property “Incompatible state is refused rather than guessed convertible” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M11.07-C055-T03 · Fixture material:** Create the concrete “State migration gates” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M11.07-C055-T04 · Target preparation:** Prepare the “State migration gates” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M11.07-C055-T05 · Initial-state record:** Record the initial “State migration gates” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M11.07-C055-T06 · Valid-path execution:** Execute the “State migration gates” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M11.07-C055-T07 · Outcome comparison:** Compare every declared “State migration gates” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M11.07-C055-T08 · State and bounds check:** Inspect the “State migration gates” ownership/state effects and actual use of “Migrated bytes and supported paths”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M11.07-C055-T09 · Repeatability check:** Repeat the same “State migration gates” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M11.07-C055-T10 · Positive evidence:** Attach the “State migration gates” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M11.07-C056 · Negative test

**Original checklist item:** Negative case: A new worker boots with old state lacking required fields. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M11.07-C056-T01 · Adverse-case definition:** Create a test record for the exact “State migration gates” source counterexample: “A new worker boots with old state lacking required fields”; state which precondition or invariant it challenges.
- [ ] **UC-M11.07-C056-T02 · Safe fixture boundary:** Define the contained test boundary for “State migration gates”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M11.07-C056-T03 · Valid control:** Construct a valid “State migration gates” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M11.07-C056-T04 · Minimal adverse input:** Derive the “State migration gates” adverse fixture from the control with the smallest documented change needed to reproduce “A new worker boots with old state lacking required fields”; retain that change as reproducible data.
- [ ] **UC-M11.07-C056-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “State migration gates”; require “Incompatible state is refused rather than guessed convertible” and forbid a false-success verdict.
- [ ] **UC-M11.07-C056-T06 · Adverse execution:** Exercise the “State migration gates” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M11.07-C056-T07 · Effect inspection:** Inspect “State migration gates” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M11.07-C056-T08 · Refusal versus failure:** Confirm the “State migration gates” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M11.07-C056-T09 · Reset and retention:** Restore only the disposable “State migration gates” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M11.07-C056-T10 · Negative regression:** Register the “State migration gates” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M11.07-C057 · Change / failure test

**Original checklist item:** Exercise state migration gates when a canary fails while other workers are still on the previous approved version; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M11.07-C057-T01 · Scenario record:** Write the “State migration gates” change/failure scenario exactly as supplied: a canary fails while other workers are still on the previous approved version; identify the property that must remain true: “Incompatible state is refused rather than guessed convertible”.
- [ ] **UC-M11.07-C057-T02 · Baseline capture:** Create a known-valid “State migration gates” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M11.07-C057-T03 · Injection map:** Locate the “State migration gates” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M11.07-C057-T04 · Disposition oracle:** Define the legal intermediate and final “State migration gates” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M11.07-C057-T05 · Controlled trigger:** Introduce the controlled “State migration gates” scenario in the disposable fixture: a canary fails while other workers are still on the previous approved version; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M11.07-C057-T06 · Intermediate inspection:** Inspect the “State migration gates” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M11.07-C057-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “State migration gates”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M11.07-C057-T08 · Stale-evidence cleanup:** Invalidate superseded “State migration gates” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M11.07-C057-T09 · Repeat and compare:** Repeat the selected “State migration gates” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M11.07-C057-T10 · Failure evidence:** Publish the “State migration gates” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M11.07-C058 · Bounds

**Original checklist item:** Choose, document and test limits for migrated bytes and supported paths; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M11.07-C058-T01 · Quantity inventory:** Create a measurement inventory for “State migration gates”: “Migrated bytes and supported paths”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M11.07-C058-T02 · Measurement method:** Choose how to observe each “State migration gates” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M11.07-C058-T03 · Budget decision:** Select justified resource and input limits for “State migration gates”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M11.07-C058-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “State migration gates” cases for “Migrated bytes and supported paths”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M11.07-C058-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “State migration gates” limit; preserve “Incompatible state is refused rather than guessed convertible”.
- [ ] **UC-M11.07-C058-T06 · Normal measurement:** Run or review the normal “State migration gates” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M11.07-C058-T07 · At-limit measurement:** Exercise the “State migration gates” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M11.07-C058-T08 · Over-limit measurement:** Exercise the “State migration gates” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M11.07-C058-T09 · Uncovered-scope report:** List the “State migration gates” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M11.07-C058-T10 · Limit evidence:** Publish the selected “State migration gates” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M11.07-C059 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for state migration gates with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M11.07-C059-T01 · Event inventory:** List the “State migration gates” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M11.07-C059-T02 · Diagnostic schema:** Define nonsecret fields for “State migration gates” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M11.07-C059-T03 · Failure mapping:** Map each documented “State migration gates” refusal or error to a diagnostic outcome; include “A new worker boots with old state lacking required fields” and prohibit conversion into a success message.
- [ ] **UC-M11.07-C059-T04 · Emission path:** Add the “State migration gates” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M11.07-C059-T05 · Redaction check:** Test “State migration gates” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M11.07-C059-T06 · Output budget:** Set and exercise bounded “State migration gates” message size, rate and retention compatible with “Migrated bytes and supported paths”; define truncation behavior that preserves the final reason.
- [ ] **UC-M11.07-C059-T07 · Success/refusal fixtures:** Capture “State migration gates” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M11.07-C059-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “State migration gates” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M11.07-C059-T09 · Operator review:** Read the “State migration gates” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M11.07-C059-T10 · Diagnostic evidence:** Publish redacted “State migration gates” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M11.07-C060 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for state migration gates; label unexecuted checks as untested.

- [ ] **UC-M11.07-C060-T01 · Evidence inventory:** List the “State migration gates” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M11.07-C060-T02 · Artifact references:** Record the exact “State migration gates” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M11.07-C060-T03 · Fixture references:** Attach the “State migration gates” fixture IDs, input identities and oracle definition; preserve the source counterexample “A new worker boots with old state lacking required fields” as a distinct evidence case.
- [ ] **UC-M11.07-C060-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “State migration gates”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M11.07-C060-T05 · Environment record:** Record the actual “State migration gates” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M11.07-C060-T06 · Expected versus observed:** Pair every “State migration gates” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M11.07-C060-T07 · Failure and limit records:** Attach “State migration gates” change/failure and bounds evidence where required; include uncovered “Migrated bytes and supported paths” and unresolved violations of “Incompatible state is refused rather than guessed convertible”.
- [ ] **UC-M11.07-C060-T08 · Evidence hygiene:** Check the “State migration gates” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M11.07-C060-T09 · Reproduction review:** Have the “State migration gates” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M11.07-C060-T10 · Acceptance linkage:** Link the “State migration gates” evidence to its parent and UC-M11.07 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 07. Canary failure stop

**Source delivery:** Stop further rollout when a required canary gate fails.

**Source invariant:** Canary failure cannot be ignored by a progress counter.

**Source negative case:** A failed canary is skipped and the next batch proceeds.

**Source bounded quantities:** Failure propagation time and queued batches.

### UC-M11.07-C061 · Contract

**Original checklist item:** Specify canary failure stop inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M11.07-C061-T01 · Scope statement:** Draft the operation boundary for “Canary failure stop” within Rolling upgrades and compatibility negotiation; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M11.07-C061-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Canary failure stop”; record each producer, representation and missing-value meaning.
- [ ] **UC-M11.07-C061-T03 · Output inventory:** List the outputs of “Canary failure stop” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M11.07-C061-T04 · Field dictionary:** Create a field-and-term dictionary for “Canary failure stop”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M11.07-C061-T05 · Prerequisite contract:** Map “Canary failure stop” to the source component prerequisites (UC-M01.02, UC-M07.08, UC-M11.05); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M11.07-C061-T06 · Authority map:** Identify who may produce, change and consume “Canary failure stop”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M11.07-C061-T07 · Invariant clause:** Add a normative clause for “Canary failure stop” that preserves “Canary failure cannot be ignored by a progress counter”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M11.07-C061-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Canary failure stop”; include the source counterexample “A failed canary is skipped and the next batch proceeds” and the intended safe disposition.
- [ ] **UC-M11.07-C061-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Failure propagation time and queued batches” in the “Canary failure stop” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M11.07-C061-T10 · Contract review:** Review the “Canary failure stop” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M11.07-C062 · Delivery

**Original checklist item:** Stop further rollout when a required canary gate fails.

- [ ] **UC-M11.07-C062-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Canary failure stop”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M11.07-C062-T02 · Change plan:** Break the source delivery for “Canary failure stop” into concrete edit targets and reviewable outputs; keep the UC-M11.07 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M11.07-C062-T03 · Core artifact:** Implement the smallest selected-profile change for “Canary failure stop” that realizes this source instruction: Stop further rollout when a required canary gate fails.
- [ ] **UC-M11.07-C062-T04 · Concrete realization:** Trace “Canary failure stop” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M11.07-C062-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Canary failure stop” needed to preserve “Canary failure cannot be ignored by a progress counter”; record an enforcement gap where only a model exists.
- [ ] **UC-M11.07-C062-T06 · Dependency connection:** Connect the “Canary failure stop” implementation to mixed-version admission, canary gates and compatible state rollback; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M11.07-C062-T07 · Resource behavior:** Account for “Failure propagation time and queued batches” in “Canary failure stop”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M11.07-C062-T08 · Delivery check:** Run the smallest real “Canary failure stop” path and its adverse fixture “A failed canary is skipped and the next batch proceeds”; retain actual output, state effects and final disposition.
- [ ] **UC-M11.07-C062-T09 · Patch review:** Review the “Canary failure stop” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M11.07-C062-T10 · Delivery handoff:** Publish the “Canary failure stop” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M11.07-C063 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Canary failure cannot be ignored by a progress counter. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M11.07-C063-T01 · Named property:** Create a stable property/check name under this parent for “Canary failure stop”; copy its required invariant exactly: “Canary failure cannot be ignored by a progress counter”.
- [ ] **UC-M11.07-C063-T02 · Observable terms:** Define each term in the “Canary failure stop” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M11.07-C063-T03 · Precondition set:** List the preconditions under which “Canary failure cannot be ignored by a progress counter” must hold for “Canary failure stop”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M11.07-C063-T04 · Transition coverage:** Map the “Canary failure stop” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M11.07-C063-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Canary failure stop”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M11.07-C063-T06 · Satisfying fixture:** Create a concrete “Canary failure stop” case that satisfies “Canary failure cannot be ignored by a progress counter”; record its expected observation before running the assertion or review.
- [ ] **UC-M11.07-C063-T07 · Violating fixture:** Create the source counterexample “A failed canary is skipped and the next batch proceeds” for “Canary failure stop”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M11.07-C063-T08 · Enforcement evidence:** Exercise the “Canary failure stop” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M11.07-C063-T09 · Regression linkage:** Link the “Canary failure stop” property to changes in mixed-version admission, canary gates and compatible state rollback; record which dependency or contract changes require rerunning it.
- [ ] **UC-M11.07-C063-T10 · Property disposition:** Compare the satisfying and violating “Canary failure stop” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M11.07-C064 · Integration

**Original checklist item:** Integrate canary failure stop with mixed-version admission, canary gates and compatible state rollback; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M11.07-C064-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Canary failure stop” across mixed-version admission, canary gates and compatible state rollback; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M11.07-C064-T02 · Field mapping:** Map every “Canary failure stop” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M11.07-C064-T03 · Prerequisite identities:** Record the actual prerequisites for “Canary failure stop” (source dependency list: UC-M01.02, UC-M07.08, UC-M11.05); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M11.07-C064-T04 · Ownership agreement:** Specify who owns “Canary failure stop” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M11.07-C064-T05 · Handoff implementation:** Connect “Canary failure stop” through the mapped seam using the real adapter or explicit specification reference; preserve “Canary failure cannot be ignored by a progress counter” across the handoff.
- [ ] **UC-M11.07-C064-T06 · Absent-input case:** Omit one required “Canary failure stop” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M11.07-C064-T07 · Stale-input case:** Supply an outdated “Canary failure stop” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M11.07-C064-T08 · Incompatible-input case:** Supply an incompatible “Canary failure stop” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M11.07-C064-T09 · Valid integration trace:** Run a valid “Canary failure stop” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M11.07-C064-T10 · Seam review:** Reconcile the “Canary failure stop” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M11.07-C065 · Valid-case test

**Original checklist item:** Run a valid-path fixture for canary failure stop; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M11.07-C065-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Canary failure stop” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M11.07-C065-T02 · Expected-result oracle:** Specify the “Canary failure stop” expected result independently of the implementation output; include the property “Canary failure cannot be ignored by a progress counter” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M11.07-C065-T03 · Fixture material:** Create the concrete “Canary failure stop” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M11.07-C065-T04 · Target preparation:** Prepare the “Canary failure stop” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M11.07-C065-T05 · Initial-state record:** Record the initial “Canary failure stop” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M11.07-C065-T06 · Valid-path execution:** Execute the “Canary failure stop” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M11.07-C065-T07 · Outcome comparison:** Compare every declared “Canary failure stop” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M11.07-C065-T08 · State and bounds check:** Inspect the “Canary failure stop” ownership/state effects and actual use of “Failure propagation time and queued batches”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M11.07-C065-T09 · Repeatability check:** Repeat the same “Canary failure stop” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M11.07-C065-T10 · Positive evidence:** Attach the “Canary failure stop” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M11.07-C066 · Negative test

**Original checklist item:** Negative case: A failed canary is skipped and the next batch proceeds. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M11.07-C066-T01 · Adverse-case definition:** Create a test record for the exact “Canary failure stop” source counterexample: “A failed canary is skipped and the next batch proceeds”; state which precondition or invariant it challenges.
- [ ] **UC-M11.07-C066-T02 · Safe fixture boundary:** Define the contained test boundary for “Canary failure stop”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M11.07-C066-T03 · Valid control:** Construct a valid “Canary failure stop” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M11.07-C066-T04 · Minimal adverse input:** Derive the “Canary failure stop” adverse fixture from the control with the smallest documented change needed to reproduce “A failed canary is skipped and the next batch proceeds”; retain that change as reproducible data.
- [ ] **UC-M11.07-C066-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Canary failure stop”; require “Canary failure cannot be ignored by a progress counter” and forbid a false-success verdict.
- [ ] **UC-M11.07-C066-T06 · Adverse execution:** Exercise the “Canary failure stop” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M11.07-C066-T07 · Effect inspection:** Inspect “Canary failure stop” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M11.07-C066-T08 · Refusal versus failure:** Confirm the “Canary failure stop” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M11.07-C066-T09 · Reset and retention:** Restore only the disposable “Canary failure stop” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M11.07-C066-T10 · Negative regression:** Register the “Canary failure stop” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M11.07-C067 · Change / failure test

**Original checklist item:** Exercise canary failure stop when a canary fails while other workers are still on the previous approved version; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M11.07-C067-T01 · Scenario record:** Write the “Canary failure stop” change/failure scenario exactly as supplied: a canary fails while other workers are still on the previous approved version; identify the property that must remain true: “Canary failure cannot be ignored by a progress counter”.
- [ ] **UC-M11.07-C067-T02 · Baseline capture:** Create a known-valid “Canary failure stop” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M11.07-C067-T03 · Injection map:** Locate the “Canary failure stop” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M11.07-C067-T04 · Disposition oracle:** Define the legal intermediate and final “Canary failure stop” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M11.07-C067-T05 · Controlled trigger:** Introduce the controlled “Canary failure stop” scenario in the disposable fixture: a canary fails while other workers are still on the previous approved version; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M11.07-C067-T06 · Intermediate inspection:** Inspect the “Canary failure stop” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M11.07-C067-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Canary failure stop”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M11.07-C067-T08 · Stale-evidence cleanup:** Invalidate superseded “Canary failure stop” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M11.07-C067-T09 · Repeat and compare:** Repeat the selected “Canary failure stop” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M11.07-C067-T10 · Failure evidence:** Publish the “Canary failure stop” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M11.07-C068 · Bounds

**Original checklist item:** Choose, document and test limits for failure propagation time and queued batches; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M11.07-C068-T01 · Quantity inventory:** Create a measurement inventory for “Canary failure stop”: “Failure propagation time and queued batches”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M11.07-C068-T02 · Measurement method:** Choose how to observe each “Canary failure stop” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M11.07-C068-T03 · Budget decision:** Select justified resource and input limits for “Canary failure stop”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M11.07-C068-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Canary failure stop” cases for “Failure propagation time and queued batches”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M11.07-C068-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Canary failure stop” limit; preserve “Canary failure cannot be ignored by a progress counter”.
- [ ] **UC-M11.07-C068-T06 · Normal measurement:** Run or review the normal “Canary failure stop” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M11.07-C068-T07 · At-limit measurement:** Exercise the “Canary failure stop” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M11.07-C068-T08 · Over-limit measurement:** Exercise the “Canary failure stop” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M11.07-C068-T09 · Uncovered-scope report:** List the “Canary failure stop” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M11.07-C068-T10 · Limit evidence:** Publish the selected “Canary failure stop” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M11.07-C069 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for canary failure stop with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M11.07-C069-T01 · Event inventory:** List the “Canary failure stop” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M11.07-C069-T02 · Diagnostic schema:** Define nonsecret fields for “Canary failure stop” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M11.07-C069-T03 · Failure mapping:** Map each documented “Canary failure stop” refusal or error to a diagnostic outcome; include “A failed canary is skipped and the next batch proceeds” and prohibit conversion into a success message.
- [ ] **UC-M11.07-C069-T04 · Emission path:** Add the “Canary failure stop” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M11.07-C069-T05 · Redaction check:** Test “Canary failure stop” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M11.07-C069-T06 · Output budget:** Set and exercise bounded “Canary failure stop” message size, rate and retention compatible with “Failure propagation time and queued batches”; define truncation behavior that preserves the final reason.
- [ ] **UC-M11.07-C069-T07 · Success/refusal fixtures:** Capture “Canary failure stop” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M11.07-C069-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Canary failure stop” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M11.07-C069-T09 · Operator review:** Read the “Canary failure stop” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M11.07-C069-T10 · Diagnostic evidence:** Publish redacted “Canary failure stop” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M11.07-C070 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for canary failure stop; label unexecuted checks as untested.

- [ ] **UC-M11.07-C070-T01 · Evidence inventory:** List the “Canary failure stop” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M11.07-C070-T02 · Artifact references:** Record the exact “Canary failure stop” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M11.07-C070-T03 · Fixture references:** Attach the “Canary failure stop” fixture IDs, input identities and oracle definition; preserve the source counterexample “A failed canary is skipped and the next batch proceeds” as a distinct evidence case.
- [ ] **UC-M11.07-C070-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Canary failure stop”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M11.07-C070-T05 · Environment record:** Record the actual “Canary failure stop” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M11.07-C070-T06 · Expected versus observed:** Pair every “Canary failure stop” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M11.07-C070-T07 · Failure and limit records:** Attach “Canary failure stop” change/failure and bounds evidence where required; include uncovered “Failure propagation time and queued batches” and unresolved violations of “Canary failure cannot be ignored by a progress counter”.
- [ ] **UC-M11.07-C070-T08 · Evidence hygiene:** Check the “Canary failure stop” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M11.07-C070-T09 · Reproduction review:** Have the “Canary failure stop” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M11.07-C070-T10 · Acceptance linkage:** Link the “Canary failure stop” evidence to its parent and UC-M11.07 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 08. Rollback constraints

**Source delivery:** Restore an approved compatible release without violating trust or state policy.

**Source invariant:** Rollback cannot revive a revoked image or incompatible snapshot.

**Source negative case:** The old release cannot read state already migrated by the new one.

**Source bounded quantities:** Retained releases and rollback prerequisites.

### UC-M11.07-C071 · Contract

**Original checklist item:** Specify rollback constraints inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M11.07-C071-T01 · Scope statement:** Draft the operation boundary for “Rollback constraints” within Rolling upgrades and compatibility negotiation; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M11.07-C071-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Rollback constraints”; record each producer, representation and missing-value meaning.
- [ ] **UC-M11.07-C071-T03 · Output inventory:** List the outputs of “Rollback constraints” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M11.07-C071-T04 · Field dictionary:** Create a field-and-term dictionary for “Rollback constraints”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M11.07-C071-T05 · Prerequisite contract:** Map “Rollback constraints” to the source component prerequisites (UC-M01.02, UC-M07.08, UC-M11.05); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M11.07-C071-T06 · Authority map:** Identify who may produce, change and consume “Rollback constraints”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M11.07-C071-T07 · Invariant clause:** Add a normative clause for “Rollback constraints” that preserves “Rollback cannot revive a revoked image or incompatible snapshot”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M11.07-C071-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Rollback constraints”; include the source counterexample “The old release cannot read state already migrated by the new one” and the intended safe disposition.
- [ ] **UC-M11.07-C071-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Retained releases and rollback prerequisites” in the “Rollback constraints” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M11.07-C071-T10 · Contract review:** Review the “Rollback constraints” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M11.07-C072 · Delivery

**Original checklist item:** Restore an approved compatible release without violating trust or state policy.

- [ ] **UC-M11.07-C072-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Rollback constraints”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M11.07-C072-T02 · Change plan:** Break the source delivery for “Rollback constraints” into concrete edit targets and reviewable outputs; keep the UC-M11.07 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M11.07-C072-T03 · Core artifact:** Implement the smallest selected-profile change for “Rollback constraints” that realizes this source instruction: Restore an approved compatible release without violating trust or state policy.
- [ ] **UC-M11.07-C072-T04 · Concrete realization:** Trace “Rollback constraints” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M11.07-C072-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Rollback constraints” needed to preserve “Rollback cannot revive a revoked image or incompatible snapshot”; record an enforcement gap where only a model exists.
- [ ] **UC-M11.07-C072-T06 · Dependency connection:** Connect the “Rollback constraints” implementation to mixed-version admission, canary gates and compatible state rollback; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M11.07-C072-T07 · Resource behavior:** Account for “Retained releases and rollback prerequisites” in “Rollback constraints”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M11.07-C072-T08 · Delivery check:** Run the smallest real “Rollback constraints” path and its adverse fixture “The old release cannot read state already migrated by the new one”; retain actual output, state effects and final disposition.
- [ ] **UC-M11.07-C072-T09 · Patch review:** Review the “Rollback constraints” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M11.07-C072-T10 · Delivery handoff:** Publish the “Rollback constraints” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M11.07-C073 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Rollback cannot revive a revoked image or incompatible snapshot. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M11.07-C073-T01 · Named property:** Create a stable property/check name under this parent for “Rollback constraints”; copy its required invariant exactly: “Rollback cannot revive a revoked image or incompatible snapshot”.
- [ ] **UC-M11.07-C073-T02 · Observable terms:** Define each term in the “Rollback constraints” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M11.07-C073-T03 · Precondition set:** List the preconditions under which “Rollback cannot revive a revoked image or incompatible snapshot” must hold for “Rollback constraints”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M11.07-C073-T04 · Transition coverage:** Map the “Rollback constraints” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M11.07-C073-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Rollback constraints”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M11.07-C073-T06 · Satisfying fixture:** Create a concrete “Rollback constraints” case that satisfies “Rollback cannot revive a revoked image or incompatible snapshot”; record its expected observation before running the assertion or review.
- [ ] **UC-M11.07-C073-T07 · Violating fixture:** Create the source counterexample “The old release cannot read state already migrated by the new one” for “Rollback constraints”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M11.07-C073-T08 · Enforcement evidence:** Exercise the “Rollback constraints” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M11.07-C073-T09 · Regression linkage:** Link the “Rollback constraints” property to changes in mixed-version admission, canary gates and compatible state rollback; record which dependency or contract changes require rerunning it.
- [ ] **UC-M11.07-C073-T10 · Property disposition:** Compare the satisfying and violating “Rollback constraints” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M11.07-C074 · Integration

**Original checklist item:** Integrate rollback constraints with mixed-version admission, canary gates and compatible state rollback; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M11.07-C074-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Rollback constraints” across mixed-version admission, canary gates and compatible state rollback; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M11.07-C074-T02 · Field mapping:** Map every “Rollback constraints” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M11.07-C074-T03 · Prerequisite identities:** Record the actual prerequisites for “Rollback constraints” (source dependency list: UC-M01.02, UC-M07.08, UC-M11.05); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M11.07-C074-T04 · Ownership agreement:** Specify who owns “Rollback constraints” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M11.07-C074-T05 · Handoff implementation:** Connect “Rollback constraints” through the mapped seam using the real adapter or explicit specification reference; preserve “Rollback cannot revive a revoked image or incompatible snapshot” across the handoff.
- [ ] **UC-M11.07-C074-T06 · Absent-input case:** Omit one required “Rollback constraints” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M11.07-C074-T07 · Stale-input case:** Supply an outdated “Rollback constraints” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M11.07-C074-T08 · Incompatible-input case:** Supply an incompatible “Rollback constraints” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M11.07-C074-T09 · Valid integration trace:** Run a valid “Rollback constraints” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M11.07-C074-T10 · Seam review:** Reconcile the “Rollback constraints” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M11.07-C075 · Valid-case test

**Original checklist item:** Run a valid-path fixture for rollback constraints; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M11.07-C075-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Rollback constraints” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M11.07-C075-T02 · Expected-result oracle:** Specify the “Rollback constraints” expected result independently of the implementation output; include the property “Rollback cannot revive a revoked image or incompatible snapshot” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M11.07-C075-T03 · Fixture material:** Create the concrete “Rollback constraints” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M11.07-C075-T04 · Target preparation:** Prepare the “Rollback constraints” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M11.07-C075-T05 · Initial-state record:** Record the initial “Rollback constraints” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M11.07-C075-T06 · Valid-path execution:** Execute the “Rollback constraints” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M11.07-C075-T07 · Outcome comparison:** Compare every declared “Rollback constraints” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M11.07-C075-T08 · State and bounds check:** Inspect the “Rollback constraints” ownership/state effects and actual use of “Retained releases and rollback prerequisites”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M11.07-C075-T09 · Repeatability check:** Repeat the same “Rollback constraints” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M11.07-C075-T10 · Positive evidence:** Attach the “Rollback constraints” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M11.07-C076 · Negative test

**Original checklist item:** Negative case: The old release cannot read state already migrated by the new one. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M11.07-C076-T01 · Adverse-case definition:** Create a test record for the exact “Rollback constraints” source counterexample: “The old release cannot read state already migrated by the new one”; state which precondition or invariant it challenges.
- [ ] **UC-M11.07-C076-T02 · Safe fixture boundary:** Define the contained test boundary for “Rollback constraints”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M11.07-C076-T03 · Valid control:** Construct a valid “Rollback constraints” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M11.07-C076-T04 · Minimal adverse input:** Derive the “Rollback constraints” adverse fixture from the control with the smallest documented change needed to reproduce “The old release cannot read state already migrated by the new one”; retain that change as reproducible data.
- [ ] **UC-M11.07-C076-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Rollback constraints”; require “Rollback cannot revive a revoked image or incompatible snapshot” and forbid a false-success verdict.
- [ ] **UC-M11.07-C076-T06 · Adverse execution:** Exercise the “Rollback constraints” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M11.07-C076-T07 · Effect inspection:** Inspect “Rollback constraints” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M11.07-C076-T08 · Refusal versus failure:** Confirm the “Rollback constraints” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M11.07-C076-T09 · Reset and retention:** Restore only the disposable “Rollback constraints” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M11.07-C076-T10 · Negative regression:** Register the “Rollback constraints” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M11.07-C077 · Change / failure test

**Original checklist item:** Exercise rollback constraints when a canary fails while other workers are still on the previous approved version; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M11.07-C077-T01 · Scenario record:** Write the “Rollback constraints” change/failure scenario exactly as supplied: a canary fails while other workers are still on the previous approved version; identify the property that must remain true: “Rollback cannot revive a revoked image or incompatible snapshot”.
- [ ] **UC-M11.07-C077-T02 · Baseline capture:** Create a known-valid “Rollback constraints” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M11.07-C077-T03 · Injection map:** Locate the “Rollback constraints” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M11.07-C077-T04 · Disposition oracle:** Define the legal intermediate and final “Rollback constraints” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M11.07-C077-T05 · Controlled trigger:** Introduce the controlled “Rollback constraints” scenario in the disposable fixture: a canary fails while other workers are still on the previous approved version; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M11.07-C077-T06 · Intermediate inspection:** Inspect the “Rollback constraints” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M11.07-C077-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Rollback constraints”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M11.07-C077-T08 · Stale-evidence cleanup:** Invalidate superseded “Rollback constraints” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M11.07-C077-T09 · Repeat and compare:** Repeat the selected “Rollback constraints” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M11.07-C077-T10 · Failure evidence:** Publish the “Rollback constraints” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M11.07-C078 · Bounds

**Original checklist item:** Choose, document and test limits for retained releases and rollback prerequisites; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M11.07-C078-T01 · Quantity inventory:** Create a measurement inventory for “Rollback constraints”: “Retained releases and rollback prerequisites”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M11.07-C078-T02 · Measurement method:** Choose how to observe each “Rollback constraints” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M11.07-C078-T03 · Budget decision:** Select justified resource and input limits for “Rollback constraints”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M11.07-C078-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Rollback constraints” cases for “Retained releases and rollback prerequisites”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M11.07-C078-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Rollback constraints” limit; preserve “Rollback cannot revive a revoked image or incompatible snapshot”.
- [ ] **UC-M11.07-C078-T06 · Normal measurement:** Run or review the normal “Rollback constraints” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M11.07-C078-T07 · At-limit measurement:** Exercise the “Rollback constraints” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M11.07-C078-T08 · Over-limit measurement:** Exercise the “Rollback constraints” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M11.07-C078-T09 · Uncovered-scope report:** List the “Rollback constraints” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M11.07-C078-T10 · Limit evidence:** Publish the selected “Rollback constraints” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M11.07-C079 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for rollback constraints with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M11.07-C079-T01 · Event inventory:** List the “Rollback constraints” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M11.07-C079-T02 · Diagnostic schema:** Define nonsecret fields for “Rollback constraints” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M11.07-C079-T03 · Failure mapping:** Map each documented “Rollback constraints” refusal or error to a diagnostic outcome; include “The old release cannot read state already migrated by the new one” and prohibit conversion into a success message.
- [ ] **UC-M11.07-C079-T04 · Emission path:** Add the “Rollback constraints” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M11.07-C079-T05 · Redaction check:** Test “Rollback constraints” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M11.07-C079-T06 · Output budget:** Set and exercise bounded “Rollback constraints” message size, rate and retention compatible with “Retained releases and rollback prerequisites”; define truncation behavior that preserves the final reason.
- [ ] **UC-M11.07-C079-T07 · Success/refusal fixtures:** Capture “Rollback constraints” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M11.07-C079-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Rollback constraints” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M11.07-C079-T09 · Operator review:** Read the “Rollback constraints” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M11.07-C079-T10 · Diagnostic evidence:** Publish redacted “Rollback constraints” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M11.07-C080 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for rollback constraints; label unexecuted checks as untested.

- [ ] **UC-M11.07-C080-T01 · Evidence inventory:** List the “Rollback constraints” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M11.07-C080-T02 · Artifact references:** Record the exact “Rollback constraints” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M11.07-C080-T03 · Fixture references:** Attach the “Rollback constraints” fixture IDs, input identities and oracle definition; preserve the source counterexample “The old release cannot read state already migrated by the new one” as a distinct evidence case.
- [ ] **UC-M11.07-C080-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Rollback constraints”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M11.07-C080-T05 · Environment record:** Record the actual “Rollback constraints” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M11.07-C080-T06 · Expected versus observed:** Pair every “Rollback constraints” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M11.07-C080-T07 · Failure and limit records:** Attach “Rollback constraints” change/failure and bounds evidence where required; include uncovered “Retained releases and rollback prerequisites” and unresolved violations of “Rollback cannot revive a revoked image or incompatible snapshot”.
- [ ] **UC-M11.07-C080-T08 · Evidence hygiene:** Check the “Rollback constraints” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M11.07-C080-T09 · Reproduction review:** Have the “Rollback constraints” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M11.07-C080-T10 · Acceptance linkage:** Link the “Rollback constraints” evidence to its parent and UC-M11.07 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 09. Rollout observability

**Source delivery:** Track per-worker version, phase, readiness, failures and compatibility blockers.

**Source invariant:** Operators can distinguish attempted upgrades from qualified running versions.

**Source negative case:** The view marks a downloaded image as successfully upgraded.

**Source bounded quantities:** Worker records and update frequency.

### UC-M11.07-C081 · Contract

**Original checklist item:** Specify rollout observability inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M11.07-C081-T01 · Scope statement:** Draft the operation boundary for “Rollout observability” within Rolling upgrades and compatibility negotiation; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M11.07-C081-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Rollout observability”; record each producer, representation and missing-value meaning.
- [ ] **UC-M11.07-C081-T03 · Output inventory:** List the outputs of “Rollout observability” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M11.07-C081-T04 · Field dictionary:** Create a field-and-term dictionary for “Rollout observability”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M11.07-C081-T05 · Prerequisite contract:** Map “Rollout observability” to the source component prerequisites (UC-M01.02, UC-M07.08, UC-M11.05); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M11.07-C081-T06 · Authority map:** Identify who may produce, change and consume “Rollout observability”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M11.07-C081-T07 · Invariant clause:** Add a normative clause for “Rollout observability” that preserves “Operators can distinguish attempted upgrades from qualified running versions”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M11.07-C081-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Rollout observability”; include the source counterexample “The view marks a downloaded image as successfully upgraded” and the intended safe disposition.
- [ ] **UC-M11.07-C081-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Worker records and update frequency” in the “Rollout observability” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M11.07-C081-T10 · Contract review:** Review the “Rollout observability” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M11.07-C082 · Delivery

**Original checklist item:** Track per-worker version, phase, readiness, failures and compatibility blockers.

- [ ] **UC-M11.07-C082-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Rollout observability”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M11.07-C082-T02 · Change plan:** Break the source delivery for “Rollout observability” into concrete edit targets and reviewable outputs; keep the UC-M11.07 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M11.07-C082-T03 · Core artifact:** Implement the smallest selected-profile change for “Rollout observability” that realizes this source instruction: Track per-worker version, phase, readiness, failures and compatibility blockers.
- [ ] **UC-M11.07-C082-T04 · Concrete realization:** Trace “Rollout observability” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M11.07-C082-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Rollout observability” needed to preserve “Operators can distinguish attempted upgrades from qualified running versions”; record an enforcement gap where only a model exists.
- [ ] **UC-M11.07-C082-T06 · Dependency connection:** Connect the “Rollout observability” implementation to mixed-version admission, canary gates and compatible state rollback; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M11.07-C082-T07 · Resource behavior:** Account for “Worker records and update frequency” in “Rollout observability”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M11.07-C082-T08 · Delivery check:** Run the smallest real “Rollout observability” path and its adverse fixture “The view marks a downloaded image as successfully upgraded”; retain actual output, state effects and final disposition.
- [ ] **UC-M11.07-C082-T09 · Patch review:** Review the “Rollout observability” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M11.07-C082-T10 · Delivery handoff:** Publish the “Rollout observability” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M11.07-C083 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Operators can distinguish attempted upgrades from qualified running versions. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M11.07-C083-T01 · Named property:** Create a stable property/check name under this parent for “Rollout observability”; copy its required invariant exactly: “Operators can distinguish attempted upgrades from qualified running versions”.
- [ ] **UC-M11.07-C083-T02 · Observable terms:** Define each term in the “Rollout observability” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M11.07-C083-T03 · Precondition set:** List the preconditions under which “Operators can distinguish attempted upgrades from qualified running versions” must hold for “Rollout observability”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M11.07-C083-T04 · Transition coverage:** Map the “Rollout observability” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M11.07-C083-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Rollout observability”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M11.07-C083-T06 · Satisfying fixture:** Create a concrete “Rollout observability” case that satisfies “Operators can distinguish attempted upgrades from qualified running versions”; record its expected observation before running the assertion or review.
- [ ] **UC-M11.07-C083-T07 · Violating fixture:** Create the source counterexample “The view marks a downloaded image as successfully upgraded” for “Rollout observability”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M11.07-C083-T08 · Enforcement evidence:** Exercise the “Rollout observability” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M11.07-C083-T09 · Regression linkage:** Link the “Rollout observability” property to changes in mixed-version admission, canary gates and compatible state rollback; record which dependency or contract changes require rerunning it.
- [ ] **UC-M11.07-C083-T10 · Property disposition:** Compare the satisfying and violating “Rollout observability” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M11.07-C084 · Integration

**Original checklist item:** Integrate rollout observability with mixed-version admission, canary gates and compatible state rollback; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M11.07-C084-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Rollout observability” across mixed-version admission, canary gates and compatible state rollback; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M11.07-C084-T02 · Field mapping:** Map every “Rollout observability” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M11.07-C084-T03 · Prerequisite identities:** Record the actual prerequisites for “Rollout observability” (source dependency list: UC-M01.02, UC-M07.08, UC-M11.05); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M11.07-C084-T04 · Ownership agreement:** Specify who owns “Rollout observability” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M11.07-C084-T05 · Handoff implementation:** Connect “Rollout observability” through the mapped seam using the real adapter or explicit specification reference; preserve “Operators can distinguish attempted upgrades from qualified running versions” across the handoff.
- [ ] **UC-M11.07-C084-T06 · Absent-input case:** Omit one required “Rollout observability” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M11.07-C084-T07 · Stale-input case:** Supply an outdated “Rollout observability” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M11.07-C084-T08 · Incompatible-input case:** Supply an incompatible “Rollout observability” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M11.07-C084-T09 · Valid integration trace:** Run a valid “Rollout observability” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M11.07-C084-T10 · Seam review:** Reconcile the “Rollout observability” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M11.07-C085 · Valid-case test

**Original checklist item:** Run a valid-path fixture for rollout observability; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M11.07-C085-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Rollout observability” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M11.07-C085-T02 · Expected-result oracle:** Specify the “Rollout observability” expected result independently of the implementation output; include the property “Operators can distinguish attempted upgrades from qualified running versions” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M11.07-C085-T03 · Fixture material:** Create the concrete “Rollout observability” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M11.07-C085-T04 · Target preparation:** Prepare the “Rollout observability” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M11.07-C085-T05 · Initial-state record:** Record the initial “Rollout observability” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M11.07-C085-T06 · Valid-path execution:** Execute the “Rollout observability” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M11.07-C085-T07 · Outcome comparison:** Compare every declared “Rollout observability” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M11.07-C085-T08 · State and bounds check:** Inspect the “Rollout observability” ownership/state effects and actual use of “Worker records and update frequency”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M11.07-C085-T09 · Repeatability check:** Repeat the same “Rollout observability” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M11.07-C085-T10 · Positive evidence:** Attach the “Rollout observability” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M11.07-C086 · Negative test

**Original checklist item:** Negative case: The view marks a downloaded image as successfully upgraded. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M11.07-C086-T01 · Adverse-case definition:** Create a test record for the exact “Rollout observability” source counterexample: “The view marks a downloaded image as successfully upgraded”; state which precondition or invariant it challenges.
- [ ] **UC-M11.07-C086-T02 · Safe fixture boundary:** Define the contained test boundary for “Rollout observability”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M11.07-C086-T03 · Valid control:** Construct a valid “Rollout observability” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M11.07-C086-T04 · Minimal adverse input:** Derive the “Rollout observability” adverse fixture from the control with the smallest documented change needed to reproduce “The view marks a downloaded image as successfully upgraded”; retain that change as reproducible data.
- [ ] **UC-M11.07-C086-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Rollout observability”; require “Operators can distinguish attempted upgrades from qualified running versions” and forbid a false-success verdict.
- [ ] **UC-M11.07-C086-T06 · Adverse execution:** Exercise the “Rollout observability” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M11.07-C086-T07 · Effect inspection:** Inspect “Rollout observability” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M11.07-C086-T08 · Refusal versus failure:** Confirm the “Rollout observability” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M11.07-C086-T09 · Reset and retention:** Restore only the disposable “Rollout observability” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M11.07-C086-T10 · Negative regression:** Register the “Rollout observability” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M11.07-C087 · Change / failure test

**Original checklist item:** Exercise rollout observability when a canary fails while other workers are still on the previous approved version; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M11.07-C087-T01 · Scenario record:** Write the “Rollout observability” change/failure scenario exactly as supplied: a canary fails while other workers are still on the previous approved version; identify the property that must remain true: “Operators can distinguish attempted upgrades from qualified running versions”.
- [ ] **UC-M11.07-C087-T02 · Baseline capture:** Create a known-valid “Rollout observability” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M11.07-C087-T03 · Injection map:** Locate the “Rollout observability” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M11.07-C087-T04 · Disposition oracle:** Define the legal intermediate and final “Rollout observability” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M11.07-C087-T05 · Controlled trigger:** Introduce the controlled “Rollout observability” scenario in the disposable fixture: a canary fails while other workers are still on the previous approved version; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M11.07-C087-T06 · Intermediate inspection:** Inspect the “Rollout observability” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M11.07-C087-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Rollout observability”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M11.07-C087-T08 · Stale-evidence cleanup:** Invalidate superseded “Rollout observability” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M11.07-C087-T09 · Repeat and compare:** Repeat the selected “Rollout observability” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M11.07-C087-T10 · Failure evidence:** Publish the “Rollout observability” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M11.07-C088 · Bounds

**Original checklist item:** Choose, document and test limits for worker records and update frequency; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M11.07-C088-T01 · Quantity inventory:** Create a measurement inventory for “Rollout observability”: “Worker records and update frequency”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M11.07-C088-T02 · Measurement method:** Choose how to observe each “Rollout observability” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M11.07-C088-T03 · Budget decision:** Select justified resource and input limits for “Rollout observability”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M11.07-C088-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Rollout observability” cases for “Worker records and update frequency”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M11.07-C088-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Rollout observability” limit; preserve “Operators can distinguish attempted upgrades from qualified running versions”.
- [ ] **UC-M11.07-C088-T06 · Normal measurement:** Run or review the normal “Rollout observability” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M11.07-C088-T07 · At-limit measurement:** Exercise the “Rollout observability” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M11.07-C088-T08 · Over-limit measurement:** Exercise the “Rollout observability” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M11.07-C088-T09 · Uncovered-scope report:** List the “Rollout observability” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M11.07-C088-T10 · Limit evidence:** Publish the selected “Rollout observability” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M11.07-C089 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for rollout observability with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M11.07-C089-T01 · Event inventory:** List the “Rollout observability” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M11.07-C089-T02 · Diagnostic schema:** Define nonsecret fields for “Rollout observability” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M11.07-C089-T03 · Failure mapping:** Map each documented “Rollout observability” refusal or error to a diagnostic outcome; include “The view marks a downloaded image as successfully upgraded” and prohibit conversion into a success message.
- [ ] **UC-M11.07-C089-T04 · Emission path:** Add the “Rollout observability” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M11.07-C089-T05 · Redaction check:** Test “Rollout observability” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M11.07-C089-T06 · Output budget:** Set and exercise bounded “Rollout observability” message size, rate and retention compatible with “Worker records and update frequency”; define truncation behavior that preserves the final reason.
- [ ] **UC-M11.07-C089-T07 · Success/refusal fixtures:** Capture “Rollout observability” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M11.07-C089-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Rollout observability” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M11.07-C089-T09 · Operator review:** Read the “Rollout observability” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M11.07-C089-T10 · Diagnostic evidence:** Publish redacted “Rollout observability” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M11.07-C090 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for rollout observability; label unexecuted checks as untested.

- [ ] **UC-M11.07-C090-T01 · Evidence inventory:** List the “Rollout observability” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M11.07-C090-T02 · Artifact references:** Record the exact “Rollout observability” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M11.07-C090-T03 · Fixture references:** Attach the “Rollout observability” fixture IDs, input identities and oracle definition; preserve the source counterexample “The view marks a downloaded image as successfully upgraded” as a distinct evidence case.
- [ ] **UC-M11.07-C090-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Rollout observability”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M11.07-C090-T05 · Environment record:** Record the actual “Rollout observability” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M11.07-C090-T06 · Expected versus observed:** Pair every “Rollout observability” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M11.07-C090-T07 · Failure and limit records:** Attach “Rollout observability” change/failure and bounds evidence where required; include uncovered “Worker records and update frequency” and unresolved violations of “Operators can distinguish attempted upgrades from qualified running versions”.
- [ ] **UC-M11.07-C090-T08 · Evidence hygiene:** Check the “Rollout observability” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M11.07-C090-T09 · Reproduction review:** Have the “Rollout observability” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M11.07-C090-T10 · Acceptance linkage:** Link the “Rollout observability” evidence to its parent and UC-M11.07 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 10. Rolling-upgrade qualification

**Source delivery:** Run mixed-version, canary-failure and rollback drills across real selected hosts.

**Source invariant:** Incompatible versions refuse and canary failure stops promotion.

**Source negative case:** A rollout passes while one required worker remains untested.

**Source bounded quantities:** Version combinations and drill repetitions.

### UC-M11.07-C091 · Contract

**Original checklist item:** Specify rolling-upgrade qualification inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M11.07-C091-T01 · Scope statement:** Draft the operation boundary for “Rolling-upgrade qualification” within Rolling upgrades and compatibility negotiation; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M11.07-C091-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Rolling-upgrade qualification”; record each producer, representation and missing-value meaning.
- [ ] **UC-M11.07-C091-T03 · Output inventory:** List the outputs of “Rolling-upgrade qualification” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M11.07-C091-T04 · Field dictionary:** Create a field-and-term dictionary for “Rolling-upgrade qualification”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M11.07-C091-T05 · Prerequisite contract:** Map “Rolling-upgrade qualification” to the source component prerequisites (UC-M01.02, UC-M07.08, UC-M11.05); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M11.07-C091-T06 · Authority map:** Identify who may produce, change and consume “Rolling-upgrade qualification”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M11.07-C091-T07 · Invariant clause:** Add a normative clause for “Rolling-upgrade qualification” that preserves “Incompatible versions refuse and canary failure stops promotion”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M11.07-C091-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Rolling-upgrade qualification”; include the source counterexample “A rollout passes while one required worker remains untested” and the intended safe disposition.
- [ ] **UC-M11.07-C091-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Version combinations and drill repetitions” in the “Rolling-upgrade qualification” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M11.07-C091-T10 · Contract review:** Review the “Rolling-upgrade qualification” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M11.07-C092 · Delivery

**Original checklist item:** Run mixed-version, canary-failure and rollback drills across real selected hosts.

- [ ] **UC-M11.07-C092-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Rolling-upgrade qualification”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M11.07-C092-T02 · Change plan:** Break the source delivery for “Rolling-upgrade qualification” into concrete edit targets and reviewable outputs; keep the UC-M11.07 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M11.07-C092-T03 · Core artifact:** Create the “Rolling-upgrade qualification” fixture or harness for this source instruction: Run mixed-version, canary-failure and rollback drills across real selected hosts.
- [ ] **UC-M11.07-C092-T04 · Concrete realization:** Connect the “Rolling-upgrade qualification” harness to its actual intended target, set the expected oracle before running it, and distinguish a mock/control run from a target run.
- [ ] **UC-M11.07-C092-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Rolling-upgrade qualification” needed to preserve “Incompatible versions refuse and canary failure stops promotion”; record an enforcement gap where only a model exists.
- [ ] **UC-M11.07-C092-T06 · Dependency connection:** Connect the “Rolling-upgrade qualification” implementation to mixed-version admission, canary gates and compatible state rollback; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M11.07-C092-T07 · Resource behavior:** Account for “Version combinations and drill repetitions” in “Rolling-upgrade qualification”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M11.07-C092-T08 · Delivery check:** Run the smallest real “Rolling-upgrade qualification” path and its adverse fixture “A rollout passes while one required worker remains untested”; retain actual output, state effects and final disposition.
- [ ] **UC-M11.07-C092-T09 · Patch review:** Review the “Rolling-upgrade qualification” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M11.07-C092-T10 · Delivery handoff:** Publish the “Rolling-upgrade qualification” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M11.07-C093 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Incompatible versions refuse and canary failure stops promotion. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M11.07-C093-T01 · Named property:** Create a stable property/check name under this parent for “Rolling-upgrade qualification”; copy its required invariant exactly: “Incompatible versions refuse and canary failure stops promotion”.
- [ ] **UC-M11.07-C093-T02 · Observable terms:** Define each term in the “Rolling-upgrade qualification” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M11.07-C093-T03 · Precondition set:** List the preconditions under which “Incompatible versions refuse and canary failure stops promotion” must hold for “Rolling-upgrade qualification”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M11.07-C093-T04 · Transition coverage:** Map the “Rolling-upgrade qualification” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M11.07-C093-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Rolling-upgrade qualification”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M11.07-C093-T06 · Satisfying fixture:** Create a concrete “Rolling-upgrade qualification” case that satisfies “Incompatible versions refuse and canary failure stops promotion”; record its expected observation before running the assertion or review.
- [ ] **UC-M11.07-C093-T07 · Violating fixture:** Create the source counterexample “A rollout passes while one required worker remains untested” for “Rolling-upgrade qualification”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M11.07-C093-T08 · Enforcement evidence:** Exercise the “Rolling-upgrade qualification” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M11.07-C093-T09 · Regression linkage:** Link the “Rolling-upgrade qualification” property to changes in mixed-version admission, canary gates and compatible state rollback; record which dependency or contract changes require rerunning it.
- [ ] **UC-M11.07-C093-T10 · Property disposition:** Compare the satisfying and violating “Rolling-upgrade qualification” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M11.07-C094 · Integration

**Original checklist item:** Integrate rolling-upgrade qualification with mixed-version admission, canary gates and compatible state rollback; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M11.07-C094-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Rolling-upgrade qualification” across mixed-version admission, canary gates and compatible state rollback; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M11.07-C094-T02 · Field mapping:** Map every “Rolling-upgrade qualification” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M11.07-C094-T03 · Prerequisite identities:** Record the actual prerequisites for “Rolling-upgrade qualification” (source dependency list: UC-M01.02, UC-M07.08, UC-M11.05); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M11.07-C094-T04 · Ownership agreement:** Specify who owns “Rolling-upgrade qualification” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M11.07-C094-T05 · Handoff implementation:** Connect “Rolling-upgrade qualification” through the mapped seam using the real adapter or explicit specification reference; preserve “Incompatible versions refuse and canary failure stops promotion” across the handoff.
- [ ] **UC-M11.07-C094-T06 · Absent-input case:** Omit one required “Rolling-upgrade qualification” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M11.07-C094-T07 · Stale-input case:** Supply an outdated “Rolling-upgrade qualification” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M11.07-C094-T08 · Incompatible-input case:** Supply an incompatible “Rolling-upgrade qualification” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M11.07-C094-T09 · Valid integration trace:** Run a valid “Rolling-upgrade qualification” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M11.07-C094-T10 · Seam review:** Reconcile the “Rolling-upgrade qualification” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M11.07-C095 · Valid-case test

**Original checklist item:** Run a valid-path fixture for rolling-upgrade qualification; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M11.07-C095-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Rolling-upgrade qualification” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M11.07-C095-T02 · Expected-result oracle:** Specify the “Rolling-upgrade qualification” expected result independently of the implementation output; include the property “Incompatible versions refuse and canary failure stops promotion” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M11.07-C095-T03 · Fixture material:** Create the concrete “Rolling-upgrade qualification” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M11.07-C095-T04 · Target preparation:** Prepare the “Rolling-upgrade qualification” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M11.07-C095-T05 · Initial-state record:** Record the initial “Rolling-upgrade qualification” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M11.07-C095-T06 · Valid-path execution:** Execute the “Rolling-upgrade qualification” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M11.07-C095-T07 · Outcome comparison:** Compare every declared “Rolling-upgrade qualification” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M11.07-C095-T08 · State and bounds check:** Inspect the “Rolling-upgrade qualification” ownership/state effects and actual use of “Version combinations and drill repetitions”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M11.07-C095-T09 · Repeatability check:** Repeat the same “Rolling-upgrade qualification” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M11.07-C095-T10 · Positive evidence:** Attach the “Rolling-upgrade qualification” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M11.07-C096 · Negative test

**Original checklist item:** Negative case: A rollout passes while one required worker remains untested. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M11.07-C096-T01 · Adverse-case definition:** Create a test record for the exact “Rolling-upgrade qualification” source counterexample: “A rollout passes while one required worker remains untested”; state which precondition or invariant it challenges.
- [ ] **UC-M11.07-C096-T02 · Safe fixture boundary:** Define the contained test boundary for “Rolling-upgrade qualification”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M11.07-C096-T03 · Valid control:** Construct a valid “Rolling-upgrade qualification” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M11.07-C096-T04 · Minimal adverse input:** Derive the “Rolling-upgrade qualification” adverse fixture from the control with the smallest documented change needed to reproduce “A rollout passes while one required worker remains untested”; retain that change as reproducible data.
- [ ] **UC-M11.07-C096-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Rolling-upgrade qualification”; require “Incompatible versions refuse and canary failure stops promotion” and forbid a false-success verdict.
- [ ] **UC-M11.07-C096-T06 · Adverse execution:** Exercise the “Rolling-upgrade qualification” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M11.07-C096-T07 · Effect inspection:** Inspect “Rolling-upgrade qualification” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M11.07-C096-T08 · Refusal versus failure:** Confirm the “Rolling-upgrade qualification” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M11.07-C096-T09 · Reset and retention:** Restore only the disposable “Rolling-upgrade qualification” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M11.07-C096-T10 · Negative regression:** Register the “Rolling-upgrade qualification” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M11.07-C097 · Change / failure test

**Original checklist item:** Exercise rolling-upgrade qualification when a canary fails while other workers are still on the previous approved version; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M11.07-C097-T01 · Scenario record:** Write the “Rolling-upgrade qualification” change/failure scenario exactly as supplied: a canary fails while other workers are still on the previous approved version; identify the property that must remain true: “Incompatible versions refuse and canary failure stops promotion”.
- [ ] **UC-M11.07-C097-T02 · Baseline capture:** Create a known-valid “Rolling-upgrade qualification” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M11.07-C097-T03 · Injection map:** Locate the “Rolling-upgrade qualification” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M11.07-C097-T04 · Disposition oracle:** Define the legal intermediate and final “Rolling-upgrade qualification” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M11.07-C097-T05 · Controlled trigger:** Introduce the controlled “Rolling-upgrade qualification” scenario in the disposable fixture: a canary fails while other workers are still on the previous approved version; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M11.07-C097-T06 · Intermediate inspection:** Inspect the “Rolling-upgrade qualification” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M11.07-C097-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Rolling-upgrade qualification”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M11.07-C097-T08 · Stale-evidence cleanup:** Invalidate superseded “Rolling-upgrade qualification” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M11.07-C097-T09 · Repeat and compare:** Repeat the selected “Rolling-upgrade qualification” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M11.07-C097-T10 · Failure evidence:** Publish the “Rolling-upgrade qualification” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M11.07-C098 · Bounds

**Original checklist item:** Choose, document and test limits for version combinations and drill repetitions; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M11.07-C098-T01 · Quantity inventory:** Create a measurement inventory for “Rolling-upgrade qualification”: “Version combinations and drill repetitions”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M11.07-C098-T02 · Measurement method:** Choose how to observe each “Rolling-upgrade qualification” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M11.07-C098-T03 · Budget decision:** Select justified resource and input limits for “Rolling-upgrade qualification”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M11.07-C098-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Rolling-upgrade qualification” cases for “Version combinations and drill repetitions”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M11.07-C098-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Rolling-upgrade qualification” limit; preserve “Incompatible versions refuse and canary failure stops promotion”.
- [ ] **UC-M11.07-C098-T06 · Normal measurement:** Run or review the normal “Rolling-upgrade qualification” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M11.07-C098-T07 · At-limit measurement:** Exercise the “Rolling-upgrade qualification” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M11.07-C098-T08 · Over-limit measurement:** Exercise the “Rolling-upgrade qualification” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M11.07-C098-T09 · Uncovered-scope report:** List the “Rolling-upgrade qualification” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M11.07-C098-T10 · Limit evidence:** Publish the selected “Rolling-upgrade qualification” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M11.07-C099 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for rolling-upgrade qualification with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M11.07-C099-T01 · Event inventory:** List the “Rolling-upgrade qualification” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M11.07-C099-T02 · Diagnostic schema:** Define nonsecret fields for “Rolling-upgrade qualification” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M11.07-C099-T03 · Failure mapping:** Map each documented “Rolling-upgrade qualification” refusal or error to a diagnostic outcome; include “A rollout passes while one required worker remains untested” and prohibit conversion into a success message.
- [ ] **UC-M11.07-C099-T04 · Emission path:** Add the “Rolling-upgrade qualification” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M11.07-C099-T05 · Redaction check:** Test “Rolling-upgrade qualification” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M11.07-C099-T06 · Output budget:** Set and exercise bounded “Rolling-upgrade qualification” message size, rate and retention compatible with “Version combinations and drill repetitions”; define truncation behavior that preserves the final reason.
- [ ] **UC-M11.07-C099-T07 · Success/refusal fixtures:** Capture “Rolling-upgrade qualification” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M11.07-C099-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Rolling-upgrade qualification” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M11.07-C099-T09 · Operator review:** Read the “Rolling-upgrade qualification” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M11.07-C099-T10 · Diagnostic evidence:** Publish redacted “Rolling-upgrade qualification” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M11.07-C100 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for rolling-upgrade qualification; label unexecuted checks as untested.

- [ ] **UC-M11.07-C100-T01 · Evidence inventory:** List the “Rolling-upgrade qualification” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M11.07-C100-T02 · Artifact references:** Record the exact “Rolling-upgrade qualification” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M11.07-C100-T03 · Fixture references:** Attach the “Rolling-upgrade qualification” fixture IDs, input identities and oracle definition; preserve the source counterexample “A rollout passes while one required worker remains untested” as a distinct evidence case.
- [ ] **UC-M11.07-C100-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Rolling-upgrade qualification”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M11.07-C100-T05 · Environment record:** Record the actual “Rolling-upgrade qualification” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M11.07-C100-T06 · Expected versus observed:** Pair every “Rolling-upgrade qualification” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M11.07-C100-T07 · Failure and limit records:** Attach “Rolling-upgrade qualification” change/failure and bounds evidence where required; include uncovered “Version combinations and drill repetitions” and unresolved violations of “Incompatible versions refuse and canary failure stops promotion”.
- [ ] **UC-M11.07-C100-T08 · Evidence hygiene:** Check the “Rolling-upgrade qualification” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M11.07-C100-T09 · Reproduction review:** Have the “Rolling-upgrade qualification” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M11.07-C100-T10 · Acceptance linkage:** Link the “Rolling-upgrade qualification” evidence to its parent and UC-M11.07 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

