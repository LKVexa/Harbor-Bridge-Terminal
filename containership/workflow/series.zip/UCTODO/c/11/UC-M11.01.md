# UC-M11.01 — Authenticated worker identity

**To-Do Pack 2.0.0 · Baseline UC-2.2.0 · 100 parent checks × 10 subtasks = 1,000 to-dos**

[Master index](../../INDEX.md) · [Workstream index](../../w/11.md)

| Field | Preserved source value |
|---|---|
| Workstream | 11. Optional multi-host federation |
| Milestone | D |
| Priority | P2 |
| Source assessment | MISSING |
| Scope | optional multi host |
| Dependencies | [UC-M06.02](../06/UC-M06.02.md), [UC-M09.01](../09/UC-M09.01.md) |
| Source checklist pack | 1.0.0 |
| Original reference labels | [S4], [S6]. |

## Original requirement

Only for multi-host scope: provision unique worker identities, enrollment policy and revocation independent of display names.

**Original acceptance criterion:** Unknown/revoked workers cannot receive cargo, join scheduling or publish trusted results.

**Source trace:** Original checklist `UC100/c/11/UC-M11.01.md` inside [s/checklists.zip](../../s/checklists.zip); exact parent records in [data/parents.jsonl](../../data/parents.jsonl). Original roadmap lines 999–1009 are preserved in [s/roadmap.md](../../s/roadmap.md).

## How to use these lists

Every parent statement below is preserved verbatim. Its ten child tasks are proposed decomposition, not implemented capabilities or executed tests. Child IDs append `-T01` through `-T10` to the original parent ID. All begin unchecked / `TODO`. Design/review evidence does not establish runtime enforcement; observe the actual selected target where the parent requires it.

The source dependency graph and selected release profile determine applicability. The numbered child sequence is a local working order, not an added hard dependency graph. An unselected optional feature needs a recorded not-applicable rationale; missing prerequisites for selected work remain blockers. Numerical budgets, backends and trust mechanisms remain decisions unless fixed by the source. Test hostile cases only with synthetic inputs in authorized disposable environments.

## 01. Federation opt-in

**Source delivery:** Require an explicit multi-host profile before worker enrollment is available.

**Source invariant:** The offline profile does not depend on or expose worker enrollment.

**Source negative case:** Starting a local ship automatically opens federation registration.

**Source bounded quantities:** Enabled profiles and enrollment endpoints.

### UC-M11.01-C001 · Contract

**Original checklist item:** Specify federation opt-in inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M11.01-C001-T01 · Scope statement:** Draft the operation boundary for “Federation opt-in” within Authenticated worker identity; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M11.01-C001-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Federation opt-in”; record each producer, representation and missing-value meaning.
- [ ] **UC-M11.01-C001-T03 · Output inventory:** List the outputs of “Federation opt-in” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M11.01-C001-T04 · Field dictionary:** Create a field-and-term dictionary for “Federation opt-in”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M11.01-C001-T05 · Prerequisite contract:** Map “Federation opt-in” to the source component prerequisites (UC-M06.02, UC-M09.01); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M11.01-C001-T06 · Authority map:** Identify who may produce, change and consume “Federation opt-in”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M11.01-C001-T07 · Invariant clause:** Add a normative clause for “Federation opt-in” that preserves “The offline profile does not depend on or expose worker enrollment”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M11.01-C001-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Federation opt-in”; include the source counterexample “Starting a local ship automatically opens federation registration” and the intended safe disposition.
- [ ] **UC-M11.01-C001-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Enabled profiles and enrollment endpoints” in the “Federation opt-in” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M11.01-C001-T10 · Contract review:** Review the “Federation opt-in” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M11.01-C002 · Delivery

**Original checklist item:** Require an explicit multi-host profile before worker enrollment is available.

- [ ] **UC-M11.01-C002-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Federation opt-in”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M11.01-C002-T02 · Change plan:** Break the source delivery for “Federation opt-in” into concrete edit targets and reviewable outputs; keep the UC-M11.01 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M11.01-C002-T03 · Core artifact:** Implement the smallest selected-profile change for “Federation opt-in” that realizes this source instruction: Require an explicit multi-host profile before worker enrollment is available.
- [ ] **UC-M11.01-C002-T04 · Concrete realization:** Trace “Federation opt-in” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M11.01-C002-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Federation opt-in” needed to preserve “The offline profile does not depend on or expose worker enrollment”; record an enforcement gap where only a model exists.
- [ ] **UC-M11.01-C002-T06 · Dependency connection:** Connect the “Federation opt-in” implementation to approved worker enrollment, scheduler membership and trusted result acceptance; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M11.01-C002-T07 · Resource behavior:** Account for “Enabled profiles and enrollment endpoints” in “Federation opt-in”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M11.01-C002-T08 · Delivery check:** Run the smallest real “Federation opt-in” path and its adverse fixture “Starting a local ship automatically opens federation registration”; retain actual output, state effects and final disposition.
- [ ] **UC-M11.01-C002-T09 · Patch review:** Review the “Federation opt-in” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M11.01-C002-T10 · Delivery handoff:** Publish the “Federation opt-in” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M11.01-C003 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: The offline profile does not depend on or expose worker enrollment. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M11.01-C003-T01 · Named property:** Create a stable property/check name under this parent for “Federation opt-in”; copy its required invariant exactly: “The offline profile does not depend on or expose worker enrollment”.
- [ ] **UC-M11.01-C003-T02 · Observable terms:** Define each term in the “Federation opt-in” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M11.01-C003-T03 · Precondition set:** List the preconditions under which “The offline profile does not depend on or expose worker enrollment” must hold for “Federation opt-in”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M11.01-C003-T04 · Transition coverage:** Map the “Federation opt-in” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M11.01-C003-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Federation opt-in”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M11.01-C003-T06 · Satisfying fixture:** Create a concrete “Federation opt-in” case that satisfies “The offline profile does not depend on or expose worker enrollment”; record its expected observation before running the assertion or review.
- [ ] **UC-M11.01-C003-T07 · Violating fixture:** Create the source counterexample “Starting a local ship automatically opens federation registration” for “Federation opt-in”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M11.01-C003-T08 · Enforcement evidence:** Exercise the “Federation opt-in” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M11.01-C003-T09 · Regression linkage:** Link the “Federation opt-in” property to changes in approved worker enrollment, scheduler membership and trusted result acceptance; record which dependency or contract changes require rerunning it.
- [ ] **UC-M11.01-C003-T10 · Property disposition:** Compare the satisfying and violating “Federation opt-in” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M11.01-C004 · Integration

**Original checklist item:** Integrate federation opt-in with approved worker enrollment, scheduler membership and trusted result acceptance; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M11.01-C004-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Federation opt-in” across approved worker enrollment, scheduler membership and trusted result acceptance; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M11.01-C004-T02 · Field mapping:** Map every “Federation opt-in” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M11.01-C004-T03 · Prerequisite identities:** Record the actual prerequisites for “Federation opt-in” (source dependency list: UC-M06.02, UC-M09.01); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M11.01-C004-T04 · Ownership agreement:** Specify who owns “Federation opt-in” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M11.01-C004-T05 · Handoff implementation:** Connect “Federation opt-in” through the mapped seam using the real adapter or explicit specification reference; preserve “The offline profile does not depend on or expose worker enrollment” across the handoff.
- [ ] **UC-M11.01-C004-T06 · Absent-input case:** Omit one required “Federation opt-in” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M11.01-C004-T07 · Stale-input case:** Supply an outdated “Federation opt-in” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M11.01-C004-T08 · Incompatible-input case:** Supply an incompatible “Federation opt-in” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M11.01-C004-T09 · Valid integration trace:** Run a valid “Federation opt-in” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M11.01-C004-T10 · Seam review:** Reconcile the “Federation opt-in” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M11.01-C005 · Valid-case test

**Original checklist item:** Run a valid-path fixture for federation opt-in; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M11.01-C005-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Federation opt-in” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M11.01-C005-T02 · Expected-result oracle:** Specify the “Federation opt-in” expected result independently of the implementation output; include the property “The offline profile does not depend on or expose worker enrollment” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M11.01-C005-T03 · Fixture material:** Create the concrete “Federation opt-in” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M11.01-C005-T04 · Target preparation:** Prepare the “Federation opt-in” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M11.01-C005-T05 · Initial-state record:** Record the initial “Federation opt-in” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M11.01-C005-T06 · Valid-path execution:** Execute the “Federation opt-in” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M11.01-C005-T07 · Outcome comparison:** Compare every declared “Federation opt-in” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M11.01-C005-T08 · State and bounds check:** Inspect the “Federation opt-in” ownership/state effects and actual use of “Enabled profiles and enrollment endpoints”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M11.01-C005-T09 · Repeatability check:** Repeat the same “Federation opt-in” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M11.01-C005-T10 · Positive evidence:** Attach the “Federation opt-in” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M11.01-C006 · Negative test

**Original checklist item:** Negative case: Starting a local ship automatically opens federation registration. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M11.01-C006-T01 · Adverse-case definition:** Create a test record for the exact “Federation opt-in” source counterexample: “Starting a local ship automatically opens federation registration”; state which precondition or invariant it challenges.
- [ ] **UC-M11.01-C006-T02 · Safe fixture boundary:** Define the contained test boundary for “Federation opt-in”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M11.01-C006-T03 · Valid control:** Construct a valid “Federation opt-in” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M11.01-C006-T04 · Minimal adverse input:** Derive the “Federation opt-in” adverse fixture from the control with the smallest documented change needed to reproduce “Starting a local ship automatically opens federation registration”; retain that change as reproducible data.
- [ ] **UC-M11.01-C006-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Federation opt-in”; require “The offline profile does not depend on or expose worker enrollment” and forbid a false-success verdict.
- [ ] **UC-M11.01-C006-T06 · Adverse execution:** Exercise the “Federation opt-in” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M11.01-C006-T07 · Effect inspection:** Inspect “Federation opt-in” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M11.01-C006-T08 · Refusal versus failure:** Confirm the “Federation opt-in” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M11.01-C006-T09 · Reset and retention:** Restore only the disposable “Federation opt-in” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M11.01-C006-T10 · Negative regression:** Register the “Federation opt-in” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M11.01-C007 · Change / failure test

**Original checklist item:** Exercise federation opt-in when an enrolled worker is revoked and later reconnects using its old credentials; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M11.01-C007-T01 · Scenario record:** Write the “Federation opt-in” change/failure scenario exactly as supplied: an enrolled worker is revoked and later reconnects using its old credentials; identify the property that must remain true: “The offline profile does not depend on or expose worker enrollment”.
- [ ] **UC-M11.01-C007-T02 · Baseline capture:** Create a known-valid “Federation opt-in” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M11.01-C007-T03 · Injection map:** Locate the “Federation opt-in” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M11.01-C007-T04 · Disposition oracle:** Define the legal intermediate and final “Federation opt-in” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M11.01-C007-T05 · Controlled trigger:** Introduce the controlled “Federation opt-in” scenario in the disposable fixture: an enrolled worker is revoked and later reconnects using its old credentials; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M11.01-C007-T06 · Intermediate inspection:** Inspect the “Federation opt-in” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M11.01-C007-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Federation opt-in”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M11.01-C007-T08 · Stale-evidence cleanup:** Invalidate superseded “Federation opt-in” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M11.01-C007-T09 · Repeat and compare:** Repeat the selected “Federation opt-in” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M11.01-C007-T10 · Failure evidence:** Publish the “Federation opt-in” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M11.01-C008 · Bounds

**Original checklist item:** Choose, document and test limits for enabled profiles and enrollment endpoints; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M11.01-C008-T01 · Quantity inventory:** Create a measurement inventory for “Federation opt-in”: “Enabled profiles and enrollment endpoints”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M11.01-C008-T02 · Measurement method:** Choose how to observe each “Federation opt-in” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M11.01-C008-T03 · Budget decision:** Select justified resource and input limits for “Federation opt-in”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M11.01-C008-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Federation opt-in” cases for “Enabled profiles and enrollment endpoints”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M11.01-C008-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Federation opt-in” limit; preserve “The offline profile does not depend on or expose worker enrollment”.
- [ ] **UC-M11.01-C008-T06 · Normal measurement:** Run or review the normal “Federation opt-in” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M11.01-C008-T07 · At-limit measurement:** Exercise the “Federation opt-in” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M11.01-C008-T08 · Over-limit measurement:** Exercise the “Federation opt-in” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M11.01-C008-T09 · Uncovered-scope report:** List the “Federation opt-in” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M11.01-C008-T10 · Limit evidence:** Publish the selected “Federation opt-in” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M11.01-C009 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for federation opt-in with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M11.01-C009-T01 · Event inventory:** List the “Federation opt-in” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M11.01-C009-T02 · Diagnostic schema:** Define nonsecret fields for “Federation opt-in” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M11.01-C009-T03 · Failure mapping:** Map each documented “Federation opt-in” refusal or error to a diagnostic outcome; include “Starting a local ship automatically opens federation registration” and prohibit conversion into a success message.
- [ ] **UC-M11.01-C009-T04 · Emission path:** Add the “Federation opt-in” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M11.01-C009-T05 · Redaction check:** Test “Federation opt-in” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M11.01-C009-T06 · Output budget:** Set and exercise bounded “Federation opt-in” message size, rate and retention compatible with “Enabled profiles and enrollment endpoints”; define truncation behavior that preserves the final reason.
- [ ] **UC-M11.01-C009-T07 · Success/refusal fixtures:** Capture “Federation opt-in” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M11.01-C009-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Federation opt-in” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M11.01-C009-T09 · Operator review:** Read the “Federation opt-in” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M11.01-C009-T10 · Diagnostic evidence:** Publish redacted “Federation opt-in” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M11.01-C010 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for federation opt-in; label unexecuted checks as untested.

- [ ] **UC-M11.01-C010-T01 · Evidence inventory:** List the “Federation opt-in” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M11.01-C010-T02 · Artifact references:** Record the exact “Federation opt-in” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M11.01-C010-T03 · Fixture references:** Attach the “Federation opt-in” fixture IDs, input identities and oracle definition; preserve the source counterexample “Starting a local ship automatically opens federation registration” as a distinct evidence case.
- [ ] **UC-M11.01-C010-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Federation opt-in”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M11.01-C010-T05 · Environment record:** Record the actual “Federation opt-in” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M11.01-C010-T06 · Expected versus observed:** Pair every “Federation opt-in” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M11.01-C010-T07 · Failure and limit records:** Attach “Federation opt-in” change/failure and bounds evidence where required; include uncovered “Enabled profiles and enrollment endpoints” and unresolved violations of “The offline profile does not depend on or expose worker enrollment”.
- [ ] **UC-M11.01-C010-T08 · Evidence hygiene:** Check the “Federation opt-in” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M11.01-C010-T09 · Reproduction review:** Have the “Federation opt-in” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M11.01-C010-T10 · Acceptance linkage:** Link the “Federation opt-in” evidence to its parent and UC-M11.01 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 02. Worker identity schema

**Source delivery:** Define unique immutable worker IDs distinct from hostnames and display labels.

**Source invariant:** Renaming a host cannot transfer another worker's authority.

**Source negative case:** Two hosts register the same trusted display name.

**Source bounded quantities:** Worker IDs and metadata bytes.

### UC-M11.01-C011 · Contract

**Original checklist item:** Specify worker identity schema inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M11.01-C011-T01 · Scope statement:** Draft the operation boundary for “Worker identity schema” within Authenticated worker identity; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M11.01-C011-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Worker identity schema”; record each producer, representation and missing-value meaning.
- [ ] **UC-M11.01-C011-T03 · Output inventory:** List the outputs of “Worker identity schema” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M11.01-C011-T04 · Field dictionary:** Create a field-and-term dictionary for “Worker identity schema”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M11.01-C011-T05 · Prerequisite contract:** Map “Worker identity schema” to the source component prerequisites (UC-M06.02, UC-M09.01); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M11.01-C011-T06 · Authority map:** Identify who may produce, change and consume “Worker identity schema”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M11.01-C011-T07 · Invariant clause:** Add a normative clause for “Worker identity schema” that preserves “Renaming a host cannot transfer another worker's authority”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M11.01-C011-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Worker identity schema”; include the source counterexample “Two hosts register the same trusted display name” and the intended safe disposition.
- [ ] **UC-M11.01-C011-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Worker IDs and metadata bytes” in the “Worker identity schema” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M11.01-C011-T10 · Contract review:** Review the “Worker identity schema” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M11.01-C012 · Delivery

**Original checklist item:** Define unique immutable worker IDs distinct from hostnames and display labels.

- [ ] **UC-M11.01-C012-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Worker identity schema”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M11.01-C012-T02 · Change plan:** Break the source delivery for “Worker identity schema” into concrete edit targets and reviewable outputs; keep the UC-M11.01 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M11.01-C012-T03 · Core artifact:** Create the “Worker identity schema” model, schema or inventory that realizes this source instruction: Define unique immutable worker IDs distinct from hostnames and display labels.
- [ ] **UC-M11.01-C012-T04 · Concrete realization:** Populate “Worker identity schema” with one concrete worked case; map every required entity or field to its source and flag any unmapped entry.
- [ ] **UC-M11.01-C012-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Worker identity schema” needed to preserve “Renaming a host cannot transfer another worker's authority”; record an enforcement gap where only a model exists.
- [ ] **UC-M11.01-C012-T06 · Dependency connection:** Connect the “Worker identity schema” implementation to approved worker enrollment, scheduler membership and trusted result acceptance; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M11.01-C012-T07 · Resource behavior:** Account for “Worker IDs and metadata bytes” in “Worker identity schema”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M11.01-C012-T08 · Delivery check:** Run the smallest real “Worker identity schema” path and its adverse fixture “Two hosts register the same trusted display name”; retain actual output, state effects and final disposition.
- [ ] **UC-M11.01-C012-T09 · Patch review:** Review the “Worker identity schema” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M11.01-C012-T10 · Delivery handoff:** Publish the “Worker identity schema” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M11.01-C013 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Renaming a host cannot transfer another worker's authority. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M11.01-C013-T01 · Named property:** Create a stable property/check name under this parent for “Worker identity schema”; copy its required invariant exactly: “Renaming a host cannot transfer another worker's authority”.
- [ ] **UC-M11.01-C013-T02 · Observable terms:** Define each term in the “Worker identity schema” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M11.01-C013-T03 · Precondition set:** List the preconditions under which “Renaming a host cannot transfer another worker's authority” must hold for “Worker identity schema”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M11.01-C013-T04 · Transition coverage:** Map the “Worker identity schema” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M11.01-C013-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Worker identity schema”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M11.01-C013-T06 · Satisfying fixture:** Create a concrete “Worker identity schema” case that satisfies “Renaming a host cannot transfer another worker's authority”; record its expected observation before running the assertion or review.
- [ ] **UC-M11.01-C013-T07 · Violating fixture:** Create the source counterexample “Two hosts register the same trusted display name” for “Worker identity schema”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M11.01-C013-T08 · Enforcement evidence:** Exercise the “Worker identity schema” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M11.01-C013-T09 · Regression linkage:** Link the “Worker identity schema” property to changes in approved worker enrollment, scheduler membership and trusted result acceptance; record which dependency or contract changes require rerunning it.
- [ ] **UC-M11.01-C013-T10 · Property disposition:** Compare the satisfying and violating “Worker identity schema” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M11.01-C014 · Integration

**Original checklist item:** Integrate worker identity schema with approved worker enrollment, scheduler membership and trusted result acceptance; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M11.01-C014-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Worker identity schema” across approved worker enrollment, scheduler membership and trusted result acceptance; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M11.01-C014-T02 · Field mapping:** Map every “Worker identity schema” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M11.01-C014-T03 · Prerequisite identities:** Record the actual prerequisites for “Worker identity schema” (source dependency list: UC-M06.02, UC-M09.01); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M11.01-C014-T04 · Ownership agreement:** Specify who owns “Worker identity schema” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M11.01-C014-T05 · Handoff implementation:** Connect “Worker identity schema” through the mapped seam using the real adapter or explicit specification reference; preserve “Renaming a host cannot transfer another worker's authority” across the handoff.
- [ ] **UC-M11.01-C014-T06 · Absent-input case:** Omit one required “Worker identity schema” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M11.01-C014-T07 · Stale-input case:** Supply an outdated “Worker identity schema” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M11.01-C014-T08 · Incompatible-input case:** Supply an incompatible “Worker identity schema” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M11.01-C014-T09 · Valid integration trace:** Run a valid “Worker identity schema” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M11.01-C014-T10 · Seam review:** Reconcile the “Worker identity schema” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M11.01-C015 · Valid-case test

**Original checklist item:** Run a valid-path fixture for worker identity schema; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M11.01-C015-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Worker identity schema” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M11.01-C015-T02 · Expected-result oracle:** Specify the “Worker identity schema” expected result independently of the implementation output; include the property “Renaming a host cannot transfer another worker's authority” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M11.01-C015-T03 · Fixture material:** Create the concrete “Worker identity schema” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M11.01-C015-T04 · Target preparation:** Prepare the “Worker identity schema” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M11.01-C015-T05 · Initial-state record:** Record the initial “Worker identity schema” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M11.01-C015-T06 · Valid-path execution:** Execute the “Worker identity schema” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M11.01-C015-T07 · Outcome comparison:** Compare every declared “Worker identity schema” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M11.01-C015-T08 · State and bounds check:** Inspect the “Worker identity schema” ownership/state effects and actual use of “Worker IDs and metadata bytes”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M11.01-C015-T09 · Repeatability check:** Repeat the same “Worker identity schema” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M11.01-C015-T10 · Positive evidence:** Attach the “Worker identity schema” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M11.01-C016 · Negative test

**Original checklist item:** Negative case: Two hosts register the same trusted display name. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M11.01-C016-T01 · Adverse-case definition:** Create a test record for the exact “Worker identity schema” source counterexample: “Two hosts register the same trusted display name”; state which precondition or invariant it challenges.
- [ ] **UC-M11.01-C016-T02 · Safe fixture boundary:** Define the contained test boundary for “Worker identity schema”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M11.01-C016-T03 · Valid control:** Construct a valid “Worker identity schema” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M11.01-C016-T04 · Minimal adverse input:** Derive the “Worker identity schema” adverse fixture from the control with the smallest documented change needed to reproduce “Two hosts register the same trusted display name”; retain that change as reproducible data.
- [ ] **UC-M11.01-C016-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Worker identity schema”; require “Renaming a host cannot transfer another worker's authority” and forbid a false-success verdict.
- [ ] **UC-M11.01-C016-T06 · Adverse execution:** Exercise the “Worker identity schema” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M11.01-C016-T07 · Effect inspection:** Inspect “Worker identity schema” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M11.01-C016-T08 · Refusal versus failure:** Confirm the “Worker identity schema” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M11.01-C016-T09 · Reset and retention:** Restore only the disposable “Worker identity schema” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M11.01-C016-T10 · Negative regression:** Register the “Worker identity schema” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M11.01-C017 · Change / failure test

**Original checklist item:** Exercise worker identity schema when an enrolled worker is revoked and later reconnects using its old credentials; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M11.01-C017-T01 · Scenario record:** Write the “Worker identity schema” change/failure scenario exactly as supplied: an enrolled worker is revoked and later reconnects using its old credentials; identify the property that must remain true: “Renaming a host cannot transfer another worker's authority”.
- [ ] **UC-M11.01-C017-T02 · Baseline capture:** Create a known-valid “Worker identity schema” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M11.01-C017-T03 · Injection map:** Locate the “Worker identity schema” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M11.01-C017-T04 · Disposition oracle:** Define the legal intermediate and final “Worker identity schema” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M11.01-C017-T05 · Controlled trigger:** Introduce the controlled “Worker identity schema” scenario in the disposable fixture: an enrolled worker is revoked and later reconnects using its old credentials; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M11.01-C017-T06 · Intermediate inspection:** Inspect the “Worker identity schema” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M11.01-C017-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Worker identity schema”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M11.01-C017-T08 · Stale-evidence cleanup:** Invalidate superseded “Worker identity schema” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M11.01-C017-T09 · Repeat and compare:** Repeat the selected “Worker identity schema” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M11.01-C017-T10 · Failure evidence:** Publish the “Worker identity schema” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M11.01-C018 · Bounds

**Original checklist item:** Choose, document and test limits for worker IDs and metadata bytes; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M11.01-C018-T01 · Quantity inventory:** Create a measurement inventory for “Worker identity schema”: “Worker IDs and metadata bytes”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M11.01-C018-T02 · Measurement method:** Choose how to observe each “Worker identity schema” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M11.01-C018-T03 · Budget decision:** Select justified resource and input limits for “Worker identity schema”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M11.01-C018-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Worker identity schema” cases for “Worker IDs and metadata bytes”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M11.01-C018-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Worker identity schema” limit; preserve “Renaming a host cannot transfer another worker's authority”.
- [ ] **UC-M11.01-C018-T06 · Normal measurement:** Run or review the normal “Worker identity schema” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M11.01-C018-T07 · At-limit measurement:** Exercise the “Worker identity schema” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M11.01-C018-T08 · Over-limit measurement:** Exercise the “Worker identity schema” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M11.01-C018-T09 · Uncovered-scope report:** List the “Worker identity schema” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M11.01-C018-T10 · Limit evidence:** Publish the selected “Worker identity schema” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M11.01-C019 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for worker identity schema with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M11.01-C019-T01 · Event inventory:** List the “Worker identity schema” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M11.01-C019-T02 · Diagnostic schema:** Define nonsecret fields for “Worker identity schema” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M11.01-C019-T03 · Failure mapping:** Map each documented “Worker identity schema” refusal or error to a diagnostic outcome; include “Two hosts register the same trusted display name” and prohibit conversion into a success message.
- [ ] **UC-M11.01-C019-T04 · Emission path:** Add the “Worker identity schema” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M11.01-C019-T05 · Redaction check:** Test “Worker identity schema” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M11.01-C019-T06 · Output budget:** Set and exercise bounded “Worker identity schema” message size, rate and retention compatible with “Worker IDs and metadata bytes”; define truncation behavior that preserves the final reason.
- [ ] **UC-M11.01-C019-T07 · Success/refusal fixtures:** Capture “Worker identity schema” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M11.01-C019-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Worker identity schema” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M11.01-C019-T09 · Operator review:** Read the “Worker identity schema” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M11.01-C019-T10 · Diagnostic evidence:** Publish redacted “Worker identity schema” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M11.01-C020 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for worker identity schema; label unexecuted checks as untested.

- [ ] **UC-M11.01-C020-T01 · Evidence inventory:** List the “Worker identity schema” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M11.01-C020-T02 · Artifact references:** Record the exact “Worker identity schema” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M11.01-C020-T03 · Fixture references:** Attach the “Worker identity schema” fixture IDs, input identities and oracle definition; preserve the source counterexample “Two hosts register the same trusted display name” as a distinct evidence case.
- [ ] **UC-M11.01-C020-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Worker identity schema”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M11.01-C020-T05 · Environment record:** Record the actual “Worker identity schema” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M11.01-C020-T06 · Expected versus observed:** Pair every “Worker identity schema” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M11.01-C020-T07 · Failure and limit records:** Attach “Worker identity schema” change/failure and bounds evidence where required; include uncovered “Worker IDs and metadata bytes” and unresolved violations of “Renaming a host cannot transfer another worker's authority”.
- [ ] **UC-M11.01-C020-T08 · Evidence hygiene:** Check the “Worker identity schema” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M11.01-C020-T09 · Reproduction review:** Have the “Worker identity schema” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M11.01-C020-T10 · Acceptance linkage:** Link the “Worker identity schema” evidence to its parent and UC-M11.01 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 03. Identity provisioning

**Source delivery:** Provision worker credentials through operator-approved authentication procedures.

**Source invariant:** Workers cannot mint their own trusted membership solely from cargo.

**Source negative case:** An unknown worker submits a self-created trusted identity.

**Source bounded quantities:** Provisioning records and credential artifacts.

### UC-M11.01-C021 · Contract

**Original checklist item:** Specify identity provisioning inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M11.01-C021-T01 · Scope statement:** Draft the operation boundary for “Identity provisioning” within Authenticated worker identity; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M11.01-C021-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Identity provisioning”; record each producer, representation and missing-value meaning.
- [ ] **UC-M11.01-C021-T03 · Output inventory:** List the outputs of “Identity provisioning” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M11.01-C021-T04 · Field dictionary:** Create a field-and-term dictionary for “Identity provisioning”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M11.01-C021-T05 · Prerequisite contract:** Map “Identity provisioning” to the source component prerequisites (UC-M06.02, UC-M09.01); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M11.01-C021-T06 · Authority map:** Identify who may produce, change and consume “Identity provisioning”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M11.01-C021-T07 · Invariant clause:** Add a normative clause for “Identity provisioning” that preserves “Workers cannot mint their own trusted membership solely from cargo”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M11.01-C021-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Identity provisioning”; include the source counterexample “An unknown worker submits a self-created trusted identity” and the intended safe disposition.
- [ ] **UC-M11.01-C021-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Provisioning records and credential artifacts” in the “Identity provisioning” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M11.01-C021-T10 · Contract review:** Review the “Identity provisioning” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M11.01-C022 · Delivery

**Original checklist item:** Provision worker credentials through operator-approved authentication procedures.

- [ ] **UC-M11.01-C022-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Identity provisioning”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M11.01-C022-T02 · Change plan:** Break the source delivery for “Identity provisioning” into concrete edit targets and reviewable outputs; keep the UC-M11.01 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M11.01-C022-T03 · Core artifact:** Implement the smallest selected-profile change for “Identity provisioning” that realizes this source instruction: Provision worker credentials through operator-approved authentication procedures.
- [ ] **UC-M11.01-C022-T04 · Concrete realization:** Trace “Identity provisioning” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M11.01-C022-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Identity provisioning” needed to preserve “Workers cannot mint their own trusted membership solely from cargo”; record an enforcement gap where only a model exists.
- [ ] **UC-M11.01-C022-T06 · Dependency connection:** Connect the “Identity provisioning” implementation to approved worker enrollment, scheduler membership and trusted result acceptance; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M11.01-C022-T07 · Resource behavior:** Account for “Provisioning records and credential artifacts” in “Identity provisioning”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M11.01-C022-T08 · Delivery check:** Run the smallest real “Identity provisioning” path and its adverse fixture “An unknown worker submits a self-created trusted identity”; retain actual output, state effects and final disposition.
- [ ] **UC-M11.01-C022-T09 · Patch review:** Review the “Identity provisioning” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M11.01-C022-T10 · Delivery handoff:** Publish the “Identity provisioning” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M11.01-C023 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Workers cannot mint their own trusted membership solely from cargo. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M11.01-C023-T01 · Named property:** Create a stable property/check name under this parent for “Identity provisioning”; copy its required invariant exactly: “Workers cannot mint their own trusted membership solely from cargo”.
- [ ] **UC-M11.01-C023-T02 · Observable terms:** Define each term in the “Identity provisioning” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M11.01-C023-T03 · Precondition set:** List the preconditions under which “Workers cannot mint their own trusted membership solely from cargo” must hold for “Identity provisioning”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M11.01-C023-T04 · Transition coverage:** Map the “Identity provisioning” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M11.01-C023-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Identity provisioning”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M11.01-C023-T06 · Satisfying fixture:** Create a concrete “Identity provisioning” case that satisfies “Workers cannot mint their own trusted membership solely from cargo”; record its expected observation before running the assertion or review.
- [ ] **UC-M11.01-C023-T07 · Violating fixture:** Create the source counterexample “An unknown worker submits a self-created trusted identity” for “Identity provisioning”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M11.01-C023-T08 · Enforcement evidence:** Exercise the “Identity provisioning” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M11.01-C023-T09 · Regression linkage:** Link the “Identity provisioning” property to changes in approved worker enrollment, scheduler membership and trusted result acceptance; record which dependency or contract changes require rerunning it.
- [ ] **UC-M11.01-C023-T10 · Property disposition:** Compare the satisfying and violating “Identity provisioning” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M11.01-C024 · Integration

**Original checklist item:** Integrate identity provisioning with approved worker enrollment, scheduler membership and trusted result acceptance; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M11.01-C024-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Identity provisioning” across approved worker enrollment, scheduler membership and trusted result acceptance; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M11.01-C024-T02 · Field mapping:** Map every “Identity provisioning” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M11.01-C024-T03 · Prerequisite identities:** Record the actual prerequisites for “Identity provisioning” (source dependency list: UC-M06.02, UC-M09.01); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M11.01-C024-T04 · Ownership agreement:** Specify who owns “Identity provisioning” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M11.01-C024-T05 · Handoff implementation:** Connect “Identity provisioning” through the mapped seam using the real adapter or explicit specification reference; preserve “Workers cannot mint their own trusted membership solely from cargo” across the handoff.
- [ ] **UC-M11.01-C024-T06 · Absent-input case:** Omit one required “Identity provisioning” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M11.01-C024-T07 · Stale-input case:** Supply an outdated “Identity provisioning” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M11.01-C024-T08 · Incompatible-input case:** Supply an incompatible “Identity provisioning” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M11.01-C024-T09 · Valid integration trace:** Run a valid “Identity provisioning” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M11.01-C024-T10 · Seam review:** Reconcile the “Identity provisioning” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M11.01-C025 · Valid-case test

**Original checklist item:** Run a valid-path fixture for identity provisioning; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M11.01-C025-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Identity provisioning” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M11.01-C025-T02 · Expected-result oracle:** Specify the “Identity provisioning” expected result independently of the implementation output; include the property “Workers cannot mint their own trusted membership solely from cargo” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M11.01-C025-T03 · Fixture material:** Create the concrete “Identity provisioning” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M11.01-C025-T04 · Target preparation:** Prepare the “Identity provisioning” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M11.01-C025-T05 · Initial-state record:** Record the initial “Identity provisioning” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M11.01-C025-T06 · Valid-path execution:** Execute the “Identity provisioning” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M11.01-C025-T07 · Outcome comparison:** Compare every declared “Identity provisioning” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M11.01-C025-T08 · State and bounds check:** Inspect the “Identity provisioning” ownership/state effects and actual use of “Provisioning records and credential artifacts”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M11.01-C025-T09 · Repeatability check:** Repeat the same “Identity provisioning” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M11.01-C025-T10 · Positive evidence:** Attach the “Identity provisioning” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M11.01-C026 · Negative test

**Original checklist item:** Negative case: An unknown worker submits a self-created trusted identity. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M11.01-C026-T01 · Adverse-case definition:** Create a test record for the exact “Identity provisioning” source counterexample: “An unknown worker submits a self-created trusted identity”; state which precondition or invariant it challenges.
- [ ] **UC-M11.01-C026-T02 · Safe fixture boundary:** Define the contained test boundary for “Identity provisioning”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M11.01-C026-T03 · Valid control:** Construct a valid “Identity provisioning” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M11.01-C026-T04 · Minimal adverse input:** Derive the “Identity provisioning” adverse fixture from the control with the smallest documented change needed to reproduce “An unknown worker submits a self-created trusted identity”; retain that change as reproducible data.
- [ ] **UC-M11.01-C026-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Identity provisioning”; require “Workers cannot mint their own trusted membership solely from cargo” and forbid a false-success verdict.
- [ ] **UC-M11.01-C026-T06 · Adverse execution:** Exercise the “Identity provisioning” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M11.01-C026-T07 · Effect inspection:** Inspect “Identity provisioning” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M11.01-C026-T08 · Refusal versus failure:** Confirm the “Identity provisioning” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M11.01-C026-T09 · Reset and retention:** Restore only the disposable “Identity provisioning” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M11.01-C026-T10 · Negative regression:** Register the “Identity provisioning” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M11.01-C027 · Change / failure test

**Original checklist item:** Exercise identity provisioning when an enrolled worker is revoked and later reconnects using its old credentials; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M11.01-C027-T01 · Scenario record:** Write the “Identity provisioning” change/failure scenario exactly as supplied: an enrolled worker is revoked and later reconnects using its old credentials; identify the property that must remain true: “Workers cannot mint their own trusted membership solely from cargo”.
- [ ] **UC-M11.01-C027-T02 · Baseline capture:** Create a known-valid “Identity provisioning” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M11.01-C027-T03 · Injection map:** Locate the “Identity provisioning” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M11.01-C027-T04 · Disposition oracle:** Define the legal intermediate and final “Identity provisioning” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M11.01-C027-T05 · Controlled trigger:** Introduce the controlled “Identity provisioning” scenario in the disposable fixture: an enrolled worker is revoked and later reconnects using its old credentials; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M11.01-C027-T06 · Intermediate inspection:** Inspect the “Identity provisioning” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M11.01-C027-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Identity provisioning”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M11.01-C027-T08 · Stale-evidence cleanup:** Invalidate superseded “Identity provisioning” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M11.01-C027-T09 · Repeat and compare:** Repeat the selected “Identity provisioning” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M11.01-C027-T10 · Failure evidence:** Publish the “Identity provisioning” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M11.01-C028 · Bounds

**Original checklist item:** Choose, document and test limits for provisioning records and credential artifacts; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M11.01-C028-T01 · Quantity inventory:** Create a measurement inventory for “Identity provisioning”: “Provisioning records and credential artifacts”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M11.01-C028-T02 · Measurement method:** Choose how to observe each “Identity provisioning” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M11.01-C028-T03 · Budget decision:** Select justified resource and input limits for “Identity provisioning”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M11.01-C028-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Identity provisioning” cases for “Provisioning records and credential artifacts”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M11.01-C028-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Identity provisioning” limit; preserve “Workers cannot mint their own trusted membership solely from cargo”.
- [ ] **UC-M11.01-C028-T06 · Normal measurement:** Run or review the normal “Identity provisioning” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M11.01-C028-T07 · At-limit measurement:** Exercise the “Identity provisioning” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M11.01-C028-T08 · Over-limit measurement:** Exercise the “Identity provisioning” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M11.01-C028-T09 · Uncovered-scope report:** List the “Identity provisioning” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M11.01-C028-T10 · Limit evidence:** Publish the selected “Identity provisioning” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M11.01-C029 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for identity provisioning with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M11.01-C029-T01 · Event inventory:** List the “Identity provisioning” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M11.01-C029-T02 · Diagnostic schema:** Define nonsecret fields for “Identity provisioning” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M11.01-C029-T03 · Failure mapping:** Map each documented “Identity provisioning” refusal or error to a diagnostic outcome; include “An unknown worker submits a self-created trusted identity” and prohibit conversion into a success message.
- [ ] **UC-M11.01-C029-T04 · Emission path:** Add the “Identity provisioning” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M11.01-C029-T05 · Redaction check:** Test “Identity provisioning” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M11.01-C029-T06 · Output budget:** Set and exercise bounded “Identity provisioning” message size, rate and retention compatible with “Provisioning records and credential artifacts”; define truncation behavior that preserves the final reason.
- [ ] **UC-M11.01-C029-T07 · Success/refusal fixtures:** Capture “Identity provisioning” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M11.01-C029-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Identity provisioning” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M11.01-C029-T09 · Operator review:** Read the “Identity provisioning” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M11.01-C029-T10 · Diagnostic evidence:** Publish redacted “Identity provisioning” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M11.01-C030 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for identity provisioning; label unexecuted checks as untested.

- [ ] **UC-M11.01-C030-T01 · Evidence inventory:** List the “Identity provisioning” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M11.01-C030-T02 · Artifact references:** Record the exact “Identity provisioning” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M11.01-C030-T03 · Fixture references:** Attach the “Identity provisioning” fixture IDs, input identities and oracle definition; preserve the source counterexample “An unknown worker submits a self-created trusted identity” as a distinct evidence case.
- [ ] **UC-M11.01-C030-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Identity provisioning”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M11.01-C030-T05 · Environment record:** Record the actual “Identity provisioning” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M11.01-C030-T06 · Expected versus observed:** Pair every “Identity provisioning” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M11.01-C030-T07 · Failure and limit records:** Attach “Identity provisioning” change/failure and bounds evidence where required; include uncovered “Provisioning records and credential artifacts” and unresolved violations of “Workers cannot mint their own trusted membership solely from cargo”.
- [ ] **UC-M11.01-C030-T08 · Evidence hygiene:** Check the “Identity provisioning” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M11.01-C030-T09 · Reproduction review:** Have the “Identity provisioning” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M11.01-C030-T10 · Acceptance linkage:** Link the “Identity provisioning” evidence to its parent and UC-M11.01 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 04. Enrollment authorization

**Source delivery:** Require explicit permission and policy for adding a worker.

**Source invariant:** A valid network connection is not sufficient for membership.

**Source negative case:** An authenticated ordinary service enrolls a new worker.

**Source bounded quantities:** Enrollment requests and authorization rules.

### UC-M11.01-C031 · Contract

**Original checklist item:** Specify enrollment authorization inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M11.01-C031-T01 · Scope statement:** Draft the operation boundary for “Enrollment authorization” within Authenticated worker identity; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M11.01-C031-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Enrollment authorization”; record each producer, representation and missing-value meaning.
- [ ] **UC-M11.01-C031-T03 · Output inventory:** List the outputs of “Enrollment authorization” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M11.01-C031-T04 · Field dictionary:** Create a field-and-term dictionary for “Enrollment authorization”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M11.01-C031-T05 · Prerequisite contract:** Map “Enrollment authorization” to the source component prerequisites (UC-M06.02, UC-M09.01); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M11.01-C031-T06 · Authority map:** Identify who may produce, change and consume “Enrollment authorization”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M11.01-C031-T07 · Invariant clause:** Add a normative clause for “Enrollment authorization” that preserves “A valid network connection is not sufficient for membership”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M11.01-C031-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Enrollment authorization”; include the source counterexample “An authenticated ordinary service enrolls a new worker” and the intended safe disposition.
- [ ] **UC-M11.01-C031-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Enrollment requests and authorization rules” in the “Enrollment authorization” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M11.01-C031-T10 · Contract review:** Review the “Enrollment authorization” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M11.01-C032 · Delivery

**Original checklist item:** Require explicit permission and policy for adding a worker.

- [ ] **UC-M11.01-C032-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Enrollment authorization”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M11.01-C032-T02 · Change plan:** Break the source delivery for “Enrollment authorization” into concrete edit targets and reviewable outputs; keep the UC-M11.01 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M11.01-C032-T03 · Core artifact:** Implement the smallest selected-profile change for “Enrollment authorization” that realizes this source instruction: Require explicit permission and policy for adding a worker.
- [ ] **UC-M11.01-C032-T04 · Concrete realization:** Trace “Enrollment authorization” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M11.01-C032-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Enrollment authorization” needed to preserve “A valid network connection is not sufficient for membership”; record an enforcement gap where only a model exists.
- [ ] **UC-M11.01-C032-T06 · Dependency connection:** Connect the “Enrollment authorization” implementation to approved worker enrollment, scheduler membership and trusted result acceptance; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M11.01-C032-T07 · Resource behavior:** Account for “Enrollment requests and authorization rules” in “Enrollment authorization”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M11.01-C032-T08 · Delivery check:** Run the smallest real “Enrollment authorization” path and its adverse fixture “An authenticated ordinary service enrolls a new worker”; retain actual output, state effects and final disposition.
- [ ] **UC-M11.01-C032-T09 · Patch review:** Review the “Enrollment authorization” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M11.01-C032-T10 · Delivery handoff:** Publish the “Enrollment authorization” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M11.01-C033 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: A valid network connection is not sufficient for membership. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M11.01-C033-T01 · Named property:** Create a stable property/check name under this parent for “Enrollment authorization”; copy its required invariant exactly: “A valid network connection is not sufficient for membership”.
- [ ] **UC-M11.01-C033-T02 · Observable terms:** Define each term in the “Enrollment authorization” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M11.01-C033-T03 · Precondition set:** List the preconditions under which “A valid network connection is not sufficient for membership” must hold for “Enrollment authorization”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M11.01-C033-T04 · Transition coverage:** Map the “Enrollment authorization” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M11.01-C033-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Enrollment authorization”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M11.01-C033-T06 · Satisfying fixture:** Create a concrete “Enrollment authorization” case that satisfies “A valid network connection is not sufficient for membership”; record its expected observation before running the assertion or review.
- [ ] **UC-M11.01-C033-T07 · Violating fixture:** Create the source counterexample “An authenticated ordinary service enrolls a new worker” for “Enrollment authorization”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M11.01-C033-T08 · Enforcement evidence:** Exercise the “Enrollment authorization” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M11.01-C033-T09 · Regression linkage:** Link the “Enrollment authorization” property to changes in approved worker enrollment, scheduler membership and trusted result acceptance; record which dependency or contract changes require rerunning it.
- [ ] **UC-M11.01-C033-T10 · Property disposition:** Compare the satisfying and violating “Enrollment authorization” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M11.01-C034 · Integration

**Original checklist item:** Integrate enrollment authorization with approved worker enrollment, scheduler membership and trusted result acceptance; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M11.01-C034-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Enrollment authorization” across approved worker enrollment, scheduler membership and trusted result acceptance; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M11.01-C034-T02 · Field mapping:** Map every “Enrollment authorization” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M11.01-C034-T03 · Prerequisite identities:** Record the actual prerequisites for “Enrollment authorization” (source dependency list: UC-M06.02, UC-M09.01); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M11.01-C034-T04 · Ownership agreement:** Specify who owns “Enrollment authorization” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M11.01-C034-T05 · Handoff implementation:** Connect “Enrollment authorization” through the mapped seam using the real adapter or explicit specification reference; preserve “A valid network connection is not sufficient for membership” across the handoff.
- [ ] **UC-M11.01-C034-T06 · Absent-input case:** Omit one required “Enrollment authorization” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M11.01-C034-T07 · Stale-input case:** Supply an outdated “Enrollment authorization” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M11.01-C034-T08 · Incompatible-input case:** Supply an incompatible “Enrollment authorization” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M11.01-C034-T09 · Valid integration trace:** Run a valid “Enrollment authorization” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M11.01-C034-T10 · Seam review:** Reconcile the “Enrollment authorization” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M11.01-C035 · Valid-case test

**Original checklist item:** Run a valid-path fixture for enrollment authorization; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M11.01-C035-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Enrollment authorization” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M11.01-C035-T02 · Expected-result oracle:** Specify the “Enrollment authorization” expected result independently of the implementation output; include the property “A valid network connection is not sufficient for membership” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M11.01-C035-T03 · Fixture material:** Create the concrete “Enrollment authorization” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M11.01-C035-T04 · Target preparation:** Prepare the “Enrollment authorization” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M11.01-C035-T05 · Initial-state record:** Record the initial “Enrollment authorization” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M11.01-C035-T06 · Valid-path execution:** Execute the “Enrollment authorization” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M11.01-C035-T07 · Outcome comparison:** Compare every declared “Enrollment authorization” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M11.01-C035-T08 · State and bounds check:** Inspect the “Enrollment authorization” ownership/state effects and actual use of “Enrollment requests and authorization rules”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M11.01-C035-T09 · Repeatability check:** Repeat the same “Enrollment authorization” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M11.01-C035-T10 · Positive evidence:** Attach the “Enrollment authorization” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M11.01-C036 · Negative test

**Original checklist item:** Negative case: An authenticated ordinary service enrolls a new worker. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M11.01-C036-T01 · Adverse-case definition:** Create a test record for the exact “Enrollment authorization” source counterexample: “An authenticated ordinary service enrolls a new worker”; state which precondition or invariant it challenges.
- [ ] **UC-M11.01-C036-T02 · Safe fixture boundary:** Define the contained test boundary for “Enrollment authorization”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M11.01-C036-T03 · Valid control:** Construct a valid “Enrollment authorization” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M11.01-C036-T04 · Minimal adverse input:** Derive the “Enrollment authorization” adverse fixture from the control with the smallest documented change needed to reproduce “An authenticated ordinary service enrolls a new worker”; retain that change as reproducible data.
- [ ] **UC-M11.01-C036-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Enrollment authorization”; require “A valid network connection is not sufficient for membership” and forbid a false-success verdict.
- [ ] **UC-M11.01-C036-T06 · Adverse execution:** Exercise the “Enrollment authorization” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M11.01-C036-T07 · Effect inspection:** Inspect “Enrollment authorization” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M11.01-C036-T08 · Refusal versus failure:** Confirm the “Enrollment authorization” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M11.01-C036-T09 · Reset and retention:** Restore only the disposable “Enrollment authorization” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M11.01-C036-T10 · Negative regression:** Register the “Enrollment authorization” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M11.01-C037 · Change / failure test

**Original checklist item:** Exercise enrollment authorization when an enrolled worker is revoked and later reconnects using its old credentials; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M11.01-C037-T01 · Scenario record:** Write the “Enrollment authorization” change/failure scenario exactly as supplied: an enrolled worker is revoked and later reconnects using its old credentials; identify the property that must remain true: “A valid network connection is not sufficient for membership”.
- [ ] **UC-M11.01-C037-T02 · Baseline capture:** Create a known-valid “Enrollment authorization” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M11.01-C037-T03 · Injection map:** Locate the “Enrollment authorization” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M11.01-C037-T04 · Disposition oracle:** Define the legal intermediate and final “Enrollment authorization” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M11.01-C037-T05 · Controlled trigger:** Introduce the controlled “Enrollment authorization” scenario in the disposable fixture: an enrolled worker is revoked and later reconnects using its old credentials; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M11.01-C037-T06 · Intermediate inspection:** Inspect the “Enrollment authorization” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M11.01-C037-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Enrollment authorization”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M11.01-C037-T08 · Stale-evidence cleanup:** Invalidate superseded “Enrollment authorization” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M11.01-C037-T09 · Repeat and compare:** Repeat the selected “Enrollment authorization” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M11.01-C037-T10 · Failure evidence:** Publish the “Enrollment authorization” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M11.01-C038 · Bounds

**Original checklist item:** Choose, document and test limits for enrollment requests and authorization rules; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M11.01-C038-T01 · Quantity inventory:** Create a measurement inventory for “Enrollment authorization”: “Enrollment requests and authorization rules”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M11.01-C038-T02 · Measurement method:** Choose how to observe each “Enrollment authorization” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M11.01-C038-T03 · Budget decision:** Select justified resource and input limits for “Enrollment authorization”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M11.01-C038-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Enrollment authorization” cases for “Enrollment requests and authorization rules”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M11.01-C038-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Enrollment authorization” limit; preserve “A valid network connection is not sufficient for membership”.
- [ ] **UC-M11.01-C038-T06 · Normal measurement:** Run or review the normal “Enrollment authorization” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M11.01-C038-T07 · At-limit measurement:** Exercise the “Enrollment authorization” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M11.01-C038-T08 · Over-limit measurement:** Exercise the “Enrollment authorization” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M11.01-C038-T09 · Uncovered-scope report:** List the “Enrollment authorization” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M11.01-C038-T10 · Limit evidence:** Publish the selected “Enrollment authorization” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M11.01-C039 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for enrollment authorization with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M11.01-C039-T01 · Event inventory:** List the “Enrollment authorization” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M11.01-C039-T02 · Diagnostic schema:** Define nonsecret fields for “Enrollment authorization” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M11.01-C039-T03 · Failure mapping:** Map each documented “Enrollment authorization” refusal or error to a diagnostic outcome; include “An authenticated ordinary service enrolls a new worker” and prohibit conversion into a success message.
- [ ] **UC-M11.01-C039-T04 · Emission path:** Add the “Enrollment authorization” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M11.01-C039-T05 · Redaction check:** Test “Enrollment authorization” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M11.01-C039-T06 · Output budget:** Set and exercise bounded “Enrollment authorization” message size, rate and retention compatible with “Enrollment requests and authorization rules”; define truncation behavior that preserves the final reason.
- [ ] **UC-M11.01-C039-T07 · Success/refusal fixtures:** Capture “Enrollment authorization” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M11.01-C039-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Enrollment authorization” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M11.01-C039-T09 · Operator review:** Read the “Enrollment authorization” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M11.01-C039-T10 · Diagnostic evidence:** Publish redacted “Enrollment authorization” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M11.01-C040 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for enrollment authorization; label unexecuted checks as untested.

- [ ] **UC-M11.01-C040-T01 · Evidence inventory:** List the “Enrollment authorization” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M11.01-C040-T02 · Artifact references:** Record the exact “Enrollment authorization” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M11.01-C040-T03 · Fixture references:** Attach the “Enrollment authorization” fixture IDs, input identities and oracle definition; preserve the source counterexample “An authenticated ordinary service enrolls a new worker” as a distinct evidence case.
- [ ] **UC-M11.01-C040-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Enrollment authorization”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M11.01-C040-T05 · Environment record:** Record the actual “Enrollment authorization” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M11.01-C040-T06 · Expected versus observed:** Pair every “Enrollment authorization” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M11.01-C040-T07 · Failure and limit records:** Attach “Enrollment authorization” change/failure and bounds evidence where required; include uncovered “Enrollment requests and authorization rules” and unresolved violations of “A valid network connection is not sufficient for membership”.
- [ ] **UC-M11.01-C040-T08 · Evidence hygiene:** Check the “Enrollment authorization” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M11.01-C040-T09 · Reproduction review:** Have the “Enrollment authorization” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M11.01-C040-T10 · Acceptance linkage:** Link the “Enrollment authorization” evidence to its parent and UC-M11.01 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 05. Worker capability binding

**Source delivery:** Associate claimed capabilities with verified worker identity and evidence.

**Source invariant:** Unverified capability claims do not authorize workload placement.

**Source negative case:** A worker claims an unavailable isolation backend.

**Source bounded quantities:** Capability records and verification cost.

### UC-M11.01-C041 · Contract

**Original checklist item:** Specify worker capability binding inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M11.01-C041-T01 · Scope statement:** Draft the operation boundary for “Worker capability binding” within Authenticated worker identity; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M11.01-C041-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Worker capability binding”; record each producer, representation and missing-value meaning.
- [ ] **UC-M11.01-C041-T03 · Output inventory:** List the outputs of “Worker capability binding” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M11.01-C041-T04 · Field dictionary:** Create a field-and-term dictionary for “Worker capability binding”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M11.01-C041-T05 · Prerequisite contract:** Map “Worker capability binding” to the source component prerequisites (UC-M06.02, UC-M09.01); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M11.01-C041-T06 · Authority map:** Identify who may produce, change and consume “Worker capability binding”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M11.01-C041-T07 · Invariant clause:** Add a normative clause for “Worker capability binding” that preserves “Unverified capability claims do not authorize workload placement”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M11.01-C041-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Worker capability binding”; include the source counterexample “A worker claims an unavailable isolation backend” and the intended safe disposition.
- [ ] **UC-M11.01-C041-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Capability records and verification cost” in the “Worker capability binding” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M11.01-C041-T10 · Contract review:** Review the “Worker capability binding” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M11.01-C042 · Delivery

**Original checklist item:** Associate claimed capabilities with verified worker identity and evidence.

- [ ] **UC-M11.01-C042-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Worker capability binding”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M11.01-C042-T02 · Change plan:** Break the source delivery for “Worker capability binding” into concrete edit targets and reviewable outputs; keep the UC-M11.01 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M11.01-C042-T03 · Core artifact:** Implement the smallest selected-profile change for “Worker capability binding” that realizes this source instruction: Associate claimed capabilities with verified worker identity and evidence.
- [ ] **UC-M11.01-C042-T04 · Concrete realization:** Trace “Worker capability binding” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M11.01-C042-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Worker capability binding” needed to preserve “Unverified capability claims do not authorize workload placement”; record an enforcement gap where only a model exists.
- [ ] **UC-M11.01-C042-T06 · Dependency connection:** Connect the “Worker capability binding” implementation to approved worker enrollment, scheduler membership and trusted result acceptance; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M11.01-C042-T07 · Resource behavior:** Account for “Capability records and verification cost” in “Worker capability binding”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M11.01-C042-T08 · Delivery check:** Run the smallest real “Worker capability binding” path and its adverse fixture “A worker claims an unavailable isolation backend”; retain actual output, state effects and final disposition.
- [ ] **UC-M11.01-C042-T09 · Patch review:** Review the “Worker capability binding” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M11.01-C042-T10 · Delivery handoff:** Publish the “Worker capability binding” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M11.01-C043 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Unverified capability claims do not authorize workload placement. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M11.01-C043-T01 · Named property:** Create a stable property/check name under this parent for “Worker capability binding”; copy its required invariant exactly: “Unverified capability claims do not authorize workload placement”.
- [ ] **UC-M11.01-C043-T02 · Observable terms:** Define each term in the “Worker capability binding” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M11.01-C043-T03 · Precondition set:** List the preconditions under which “Unverified capability claims do not authorize workload placement” must hold for “Worker capability binding”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M11.01-C043-T04 · Transition coverage:** Map the “Worker capability binding” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M11.01-C043-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Worker capability binding”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M11.01-C043-T06 · Satisfying fixture:** Create a concrete “Worker capability binding” case that satisfies “Unverified capability claims do not authorize workload placement”; record its expected observation before running the assertion or review.
- [ ] **UC-M11.01-C043-T07 · Violating fixture:** Create the source counterexample “A worker claims an unavailable isolation backend” for “Worker capability binding”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M11.01-C043-T08 · Enforcement evidence:** Exercise the “Worker capability binding” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M11.01-C043-T09 · Regression linkage:** Link the “Worker capability binding” property to changes in approved worker enrollment, scheduler membership and trusted result acceptance; record which dependency or contract changes require rerunning it.
- [ ] **UC-M11.01-C043-T10 · Property disposition:** Compare the satisfying and violating “Worker capability binding” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M11.01-C044 · Integration

**Original checklist item:** Integrate worker capability binding with approved worker enrollment, scheduler membership and trusted result acceptance; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M11.01-C044-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Worker capability binding” across approved worker enrollment, scheduler membership and trusted result acceptance; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M11.01-C044-T02 · Field mapping:** Map every “Worker capability binding” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M11.01-C044-T03 · Prerequisite identities:** Record the actual prerequisites for “Worker capability binding” (source dependency list: UC-M06.02, UC-M09.01); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M11.01-C044-T04 · Ownership agreement:** Specify who owns “Worker capability binding” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M11.01-C044-T05 · Handoff implementation:** Connect “Worker capability binding” through the mapped seam using the real adapter or explicit specification reference; preserve “Unverified capability claims do not authorize workload placement” across the handoff.
- [ ] **UC-M11.01-C044-T06 · Absent-input case:** Omit one required “Worker capability binding” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M11.01-C044-T07 · Stale-input case:** Supply an outdated “Worker capability binding” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M11.01-C044-T08 · Incompatible-input case:** Supply an incompatible “Worker capability binding” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M11.01-C044-T09 · Valid integration trace:** Run a valid “Worker capability binding” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M11.01-C044-T10 · Seam review:** Reconcile the “Worker capability binding” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M11.01-C045 · Valid-case test

**Original checklist item:** Run a valid-path fixture for worker capability binding; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M11.01-C045-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Worker capability binding” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M11.01-C045-T02 · Expected-result oracle:** Specify the “Worker capability binding” expected result independently of the implementation output; include the property “Unverified capability claims do not authorize workload placement” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M11.01-C045-T03 · Fixture material:** Create the concrete “Worker capability binding” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M11.01-C045-T04 · Target preparation:** Prepare the “Worker capability binding” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M11.01-C045-T05 · Initial-state record:** Record the initial “Worker capability binding” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M11.01-C045-T06 · Valid-path execution:** Execute the “Worker capability binding” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M11.01-C045-T07 · Outcome comparison:** Compare every declared “Worker capability binding” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M11.01-C045-T08 · State and bounds check:** Inspect the “Worker capability binding” ownership/state effects and actual use of “Capability records and verification cost”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M11.01-C045-T09 · Repeatability check:** Repeat the same “Worker capability binding” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M11.01-C045-T10 · Positive evidence:** Attach the “Worker capability binding” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M11.01-C046 · Negative test

**Original checklist item:** Negative case: A worker claims an unavailable isolation backend. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M11.01-C046-T01 · Adverse-case definition:** Create a test record for the exact “Worker capability binding” source counterexample: “A worker claims an unavailable isolation backend”; state which precondition or invariant it challenges.
- [ ] **UC-M11.01-C046-T02 · Safe fixture boundary:** Define the contained test boundary for “Worker capability binding”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M11.01-C046-T03 · Valid control:** Construct a valid “Worker capability binding” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M11.01-C046-T04 · Minimal adverse input:** Derive the “Worker capability binding” adverse fixture from the control with the smallest documented change needed to reproduce “A worker claims an unavailable isolation backend”; retain that change as reproducible data.
- [ ] **UC-M11.01-C046-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Worker capability binding”; require “Unverified capability claims do not authorize workload placement” and forbid a false-success verdict.
- [ ] **UC-M11.01-C046-T06 · Adverse execution:** Exercise the “Worker capability binding” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M11.01-C046-T07 · Effect inspection:** Inspect “Worker capability binding” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M11.01-C046-T08 · Refusal versus failure:** Confirm the “Worker capability binding” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M11.01-C046-T09 · Reset and retention:** Restore only the disposable “Worker capability binding” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M11.01-C046-T10 · Negative regression:** Register the “Worker capability binding” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M11.01-C047 · Change / failure test

**Original checklist item:** Exercise worker capability binding when an enrolled worker is revoked and later reconnects using its old credentials; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M11.01-C047-T01 · Scenario record:** Write the “Worker capability binding” change/failure scenario exactly as supplied: an enrolled worker is revoked and later reconnects using its old credentials; identify the property that must remain true: “Unverified capability claims do not authorize workload placement”.
- [ ] **UC-M11.01-C047-T02 · Baseline capture:** Create a known-valid “Worker capability binding” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M11.01-C047-T03 · Injection map:** Locate the “Worker capability binding” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M11.01-C047-T04 · Disposition oracle:** Define the legal intermediate and final “Worker capability binding” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M11.01-C047-T05 · Controlled trigger:** Introduce the controlled “Worker capability binding” scenario in the disposable fixture: an enrolled worker is revoked and later reconnects using its old credentials; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M11.01-C047-T06 · Intermediate inspection:** Inspect the “Worker capability binding” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M11.01-C047-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Worker capability binding”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M11.01-C047-T08 · Stale-evidence cleanup:** Invalidate superseded “Worker capability binding” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M11.01-C047-T09 · Repeat and compare:** Repeat the selected “Worker capability binding” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M11.01-C047-T10 · Failure evidence:** Publish the “Worker capability binding” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M11.01-C048 · Bounds

**Original checklist item:** Choose, document and test limits for capability records and verification cost; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M11.01-C048-T01 · Quantity inventory:** Create a measurement inventory for “Worker capability binding”: “Capability records and verification cost”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M11.01-C048-T02 · Measurement method:** Choose how to observe each “Worker capability binding” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M11.01-C048-T03 · Budget decision:** Select justified resource and input limits for “Worker capability binding”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M11.01-C048-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Worker capability binding” cases for “Capability records and verification cost”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M11.01-C048-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Worker capability binding” limit; preserve “Unverified capability claims do not authorize workload placement”.
- [ ] **UC-M11.01-C048-T06 · Normal measurement:** Run or review the normal “Worker capability binding” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M11.01-C048-T07 · At-limit measurement:** Exercise the “Worker capability binding” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M11.01-C048-T08 · Over-limit measurement:** Exercise the “Worker capability binding” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M11.01-C048-T09 · Uncovered-scope report:** List the “Worker capability binding” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M11.01-C048-T10 · Limit evidence:** Publish the selected “Worker capability binding” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M11.01-C049 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for worker capability binding with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M11.01-C049-T01 · Event inventory:** List the “Worker capability binding” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M11.01-C049-T02 · Diagnostic schema:** Define nonsecret fields for “Worker capability binding” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M11.01-C049-T03 · Failure mapping:** Map each documented “Worker capability binding” refusal or error to a diagnostic outcome; include “A worker claims an unavailable isolation backend” and prohibit conversion into a success message.
- [ ] **UC-M11.01-C049-T04 · Emission path:** Add the “Worker capability binding” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M11.01-C049-T05 · Redaction check:** Test “Worker capability binding” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M11.01-C049-T06 · Output budget:** Set and exercise bounded “Worker capability binding” message size, rate and retention compatible with “Capability records and verification cost”; define truncation behavior that preserves the final reason.
- [ ] **UC-M11.01-C049-T07 · Success/refusal fixtures:** Capture “Worker capability binding” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M11.01-C049-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Worker capability binding” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M11.01-C049-T09 · Operator review:** Read the “Worker capability binding” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M11.01-C049-T10 · Diagnostic evidence:** Publish redacted “Worker capability binding” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M11.01-C050 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for worker capability binding; label unexecuted checks as untested.

- [ ] **UC-M11.01-C050-T01 · Evidence inventory:** List the “Worker capability binding” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M11.01-C050-T02 · Artifact references:** Record the exact “Worker capability binding” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M11.01-C050-T03 · Fixture references:** Attach the “Worker capability binding” fixture IDs, input identities and oracle definition; preserve the source counterexample “A worker claims an unavailable isolation backend” as a distinct evidence case.
- [ ] **UC-M11.01-C050-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Worker capability binding”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M11.01-C050-T05 · Environment record:** Record the actual “Worker capability binding” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M11.01-C050-T06 · Expected versus observed:** Pair every “Worker capability binding” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M11.01-C050-T07 · Failure and limit records:** Attach “Worker capability binding” change/failure and bounds evidence where required; include uncovered “Capability records and verification cost” and unresolved violations of “Unverified capability claims do not authorize workload placement”.
- [ ] **UC-M11.01-C050-T08 · Evidence hygiene:** Check the “Worker capability binding” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M11.01-C050-T09 · Reproduction review:** Have the “Worker capability binding” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M11.01-C050-T10 · Acceptance linkage:** Link the “Worker capability binding” evidence to its parent and UC-M11.01 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 06. Credential lifetime

**Source delivery:** Define expiry and renewal for enrolled worker identities.

**Source invariant:** Expired identities cannot receive newly trusted work.

**Source negative case:** A worker continues receiving cargo with expired credentials.

**Source bounded quantities:** Credential lifetime and active workers.

### UC-M11.01-C051 · Contract

**Original checklist item:** Specify credential lifetime inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M11.01-C051-T01 · Scope statement:** Draft the operation boundary for “Credential lifetime” within Authenticated worker identity; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M11.01-C051-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Credential lifetime”; record each producer, representation and missing-value meaning.
- [ ] **UC-M11.01-C051-T03 · Output inventory:** List the outputs of “Credential lifetime” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M11.01-C051-T04 · Field dictionary:** Create a field-and-term dictionary for “Credential lifetime”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M11.01-C051-T05 · Prerequisite contract:** Map “Credential lifetime” to the source component prerequisites (UC-M06.02, UC-M09.01); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M11.01-C051-T06 · Authority map:** Identify who may produce, change and consume “Credential lifetime”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M11.01-C051-T07 · Invariant clause:** Add a normative clause for “Credential lifetime” that preserves “Expired identities cannot receive newly trusted work”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M11.01-C051-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Credential lifetime”; include the source counterexample “A worker continues receiving cargo with expired credentials” and the intended safe disposition.
- [ ] **UC-M11.01-C051-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Credential lifetime and active workers” in the “Credential lifetime” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M11.01-C051-T10 · Contract review:** Review the “Credential lifetime” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M11.01-C052 · Delivery

**Original checklist item:** Define expiry and renewal for enrolled worker identities.

- [ ] **UC-M11.01-C052-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Credential lifetime”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M11.01-C052-T02 · Change plan:** Break the source delivery for “Credential lifetime” into concrete edit targets and reviewable outputs; keep the UC-M11.01 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M11.01-C052-T03 · Core artifact:** Create the “Credential lifetime” model, schema or inventory that realizes this source instruction: Define expiry and renewal for enrolled worker identities.
- [ ] **UC-M11.01-C052-T04 · Concrete realization:** Populate “Credential lifetime” with one concrete worked case; map every required entity or field to its source and flag any unmapped entry.
- [ ] **UC-M11.01-C052-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Credential lifetime” needed to preserve “Expired identities cannot receive newly trusted work”; record an enforcement gap where only a model exists.
- [ ] **UC-M11.01-C052-T06 · Dependency connection:** Connect the “Credential lifetime” implementation to approved worker enrollment, scheduler membership and trusted result acceptance; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M11.01-C052-T07 · Resource behavior:** Account for “Credential lifetime and active workers” in “Credential lifetime”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M11.01-C052-T08 · Delivery check:** Run the smallest real “Credential lifetime” path and its adverse fixture “A worker continues receiving cargo with expired credentials”; retain actual output, state effects and final disposition.
- [ ] **UC-M11.01-C052-T09 · Patch review:** Review the “Credential lifetime” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M11.01-C052-T10 · Delivery handoff:** Publish the “Credential lifetime” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M11.01-C053 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Expired identities cannot receive newly trusted work. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M11.01-C053-T01 · Named property:** Create a stable property/check name under this parent for “Credential lifetime”; copy its required invariant exactly: “Expired identities cannot receive newly trusted work”.
- [ ] **UC-M11.01-C053-T02 · Observable terms:** Define each term in the “Credential lifetime” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M11.01-C053-T03 · Precondition set:** List the preconditions under which “Expired identities cannot receive newly trusted work” must hold for “Credential lifetime”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M11.01-C053-T04 · Transition coverage:** Map the “Credential lifetime” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M11.01-C053-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Credential lifetime”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M11.01-C053-T06 · Satisfying fixture:** Create a concrete “Credential lifetime” case that satisfies “Expired identities cannot receive newly trusted work”; record its expected observation before running the assertion or review.
- [ ] **UC-M11.01-C053-T07 · Violating fixture:** Create the source counterexample “A worker continues receiving cargo with expired credentials” for “Credential lifetime”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M11.01-C053-T08 · Enforcement evidence:** Exercise the “Credential lifetime” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M11.01-C053-T09 · Regression linkage:** Link the “Credential lifetime” property to changes in approved worker enrollment, scheduler membership and trusted result acceptance; record which dependency or contract changes require rerunning it.
- [ ] **UC-M11.01-C053-T10 · Property disposition:** Compare the satisfying and violating “Credential lifetime” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M11.01-C054 · Integration

**Original checklist item:** Integrate credential lifetime with approved worker enrollment, scheduler membership and trusted result acceptance; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M11.01-C054-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Credential lifetime” across approved worker enrollment, scheduler membership and trusted result acceptance; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M11.01-C054-T02 · Field mapping:** Map every “Credential lifetime” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M11.01-C054-T03 · Prerequisite identities:** Record the actual prerequisites for “Credential lifetime” (source dependency list: UC-M06.02, UC-M09.01); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M11.01-C054-T04 · Ownership agreement:** Specify who owns “Credential lifetime” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M11.01-C054-T05 · Handoff implementation:** Connect “Credential lifetime” through the mapped seam using the real adapter or explicit specification reference; preserve “Expired identities cannot receive newly trusted work” across the handoff.
- [ ] **UC-M11.01-C054-T06 · Absent-input case:** Omit one required “Credential lifetime” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M11.01-C054-T07 · Stale-input case:** Supply an outdated “Credential lifetime” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M11.01-C054-T08 · Incompatible-input case:** Supply an incompatible “Credential lifetime” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M11.01-C054-T09 · Valid integration trace:** Run a valid “Credential lifetime” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M11.01-C054-T10 · Seam review:** Reconcile the “Credential lifetime” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M11.01-C055 · Valid-case test

**Original checklist item:** Run a valid-path fixture for credential lifetime; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M11.01-C055-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Credential lifetime” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M11.01-C055-T02 · Expected-result oracle:** Specify the “Credential lifetime” expected result independently of the implementation output; include the property “Expired identities cannot receive newly trusted work” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M11.01-C055-T03 · Fixture material:** Create the concrete “Credential lifetime” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M11.01-C055-T04 · Target preparation:** Prepare the “Credential lifetime” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M11.01-C055-T05 · Initial-state record:** Record the initial “Credential lifetime” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M11.01-C055-T06 · Valid-path execution:** Execute the “Credential lifetime” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M11.01-C055-T07 · Outcome comparison:** Compare every declared “Credential lifetime” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M11.01-C055-T08 · State and bounds check:** Inspect the “Credential lifetime” ownership/state effects and actual use of “Credential lifetime and active workers”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M11.01-C055-T09 · Repeatability check:** Repeat the same “Credential lifetime” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M11.01-C055-T10 · Positive evidence:** Attach the “Credential lifetime” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M11.01-C056 · Negative test

**Original checklist item:** Negative case: A worker continues receiving cargo with expired credentials. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M11.01-C056-T01 · Adverse-case definition:** Create a test record for the exact “Credential lifetime” source counterexample: “A worker continues receiving cargo with expired credentials”; state which precondition or invariant it challenges.
- [ ] **UC-M11.01-C056-T02 · Safe fixture boundary:** Define the contained test boundary for “Credential lifetime”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M11.01-C056-T03 · Valid control:** Construct a valid “Credential lifetime” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M11.01-C056-T04 · Minimal adverse input:** Derive the “Credential lifetime” adverse fixture from the control with the smallest documented change needed to reproduce “A worker continues receiving cargo with expired credentials”; retain that change as reproducible data.
- [ ] **UC-M11.01-C056-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Credential lifetime”; require “Expired identities cannot receive newly trusted work” and forbid a false-success verdict.
- [ ] **UC-M11.01-C056-T06 · Adverse execution:** Exercise the “Credential lifetime” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M11.01-C056-T07 · Effect inspection:** Inspect “Credential lifetime” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M11.01-C056-T08 · Refusal versus failure:** Confirm the “Credential lifetime” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M11.01-C056-T09 · Reset and retention:** Restore only the disposable “Credential lifetime” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M11.01-C056-T10 · Negative regression:** Register the “Credential lifetime” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M11.01-C057 · Change / failure test

**Original checklist item:** Exercise credential lifetime when an enrolled worker is revoked and later reconnects using its old credentials; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M11.01-C057-T01 · Scenario record:** Write the “Credential lifetime” change/failure scenario exactly as supplied: an enrolled worker is revoked and later reconnects using its old credentials; identify the property that must remain true: “Expired identities cannot receive newly trusted work”.
- [ ] **UC-M11.01-C057-T02 · Baseline capture:** Create a known-valid “Credential lifetime” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M11.01-C057-T03 · Injection map:** Locate the “Credential lifetime” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M11.01-C057-T04 · Disposition oracle:** Define the legal intermediate and final “Credential lifetime” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M11.01-C057-T05 · Controlled trigger:** Introduce the controlled “Credential lifetime” scenario in the disposable fixture: an enrolled worker is revoked and later reconnects using its old credentials; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M11.01-C057-T06 · Intermediate inspection:** Inspect the “Credential lifetime” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M11.01-C057-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Credential lifetime”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M11.01-C057-T08 · Stale-evidence cleanup:** Invalidate superseded “Credential lifetime” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M11.01-C057-T09 · Repeat and compare:** Repeat the selected “Credential lifetime” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M11.01-C057-T10 · Failure evidence:** Publish the “Credential lifetime” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M11.01-C058 · Bounds

**Original checklist item:** Choose, document and test limits for credential lifetime and active workers; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M11.01-C058-T01 · Quantity inventory:** Create a measurement inventory for “Credential lifetime”: “Credential lifetime and active workers”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M11.01-C058-T02 · Measurement method:** Choose how to observe each “Credential lifetime” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M11.01-C058-T03 · Budget decision:** Select justified resource and input limits for “Credential lifetime”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M11.01-C058-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Credential lifetime” cases for “Credential lifetime and active workers”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M11.01-C058-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Credential lifetime” limit; preserve “Expired identities cannot receive newly trusted work”.
- [ ] **UC-M11.01-C058-T06 · Normal measurement:** Run or review the normal “Credential lifetime” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M11.01-C058-T07 · At-limit measurement:** Exercise the “Credential lifetime” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M11.01-C058-T08 · Over-limit measurement:** Exercise the “Credential lifetime” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M11.01-C058-T09 · Uncovered-scope report:** List the “Credential lifetime” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M11.01-C058-T10 · Limit evidence:** Publish the selected “Credential lifetime” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M11.01-C059 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for credential lifetime with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M11.01-C059-T01 · Event inventory:** List the “Credential lifetime” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M11.01-C059-T02 · Diagnostic schema:** Define nonsecret fields for “Credential lifetime” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M11.01-C059-T03 · Failure mapping:** Map each documented “Credential lifetime” refusal or error to a diagnostic outcome; include “A worker continues receiving cargo with expired credentials” and prohibit conversion into a success message.
- [ ] **UC-M11.01-C059-T04 · Emission path:** Add the “Credential lifetime” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M11.01-C059-T05 · Redaction check:** Test “Credential lifetime” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M11.01-C059-T06 · Output budget:** Set and exercise bounded “Credential lifetime” message size, rate and retention compatible with “Credential lifetime and active workers”; define truncation behavior that preserves the final reason.
- [ ] **UC-M11.01-C059-T07 · Success/refusal fixtures:** Capture “Credential lifetime” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M11.01-C059-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Credential lifetime” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M11.01-C059-T09 · Operator review:** Read the “Credential lifetime” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M11.01-C059-T10 · Diagnostic evidence:** Publish redacted “Credential lifetime” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M11.01-C060 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for credential lifetime; label unexecuted checks as untested.

- [ ] **UC-M11.01-C060-T01 · Evidence inventory:** List the “Credential lifetime” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M11.01-C060-T02 · Artifact references:** Record the exact “Credential lifetime” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M11.01-C060-T03 · Fixture references:** Attach the “Credential lifetime” fixture IDs, input identities and oracle definition; preserve the source counterexample “A worker continues receiving cargo with expired credentials” as a distinct evidence case.
- [ ] **UC-M11.01-C060-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Credential lifetime”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M11.01-C060-T05 · Environment record:** Record the actual “Credential lifetime” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M11.01-C060-T06 · Expected versus observed:** Pair every “Credential lifetime” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M11.01-C060-T07 · Failure and limit records:** Attach “Credential lifetime” change/failure and bounds evidence where required; include uncovered “Credential lifetime and active workers” and unresolved violations of “Expired identities cannot receive newly trusted work”.
- [ ] **UC-M11.01-C060-T08 · Evidence hygiene:** Check the “Credential lifetime” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M11.01-C060-T09 · Reproduction review:** Have the “Credential lifetime” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M11.01-C060-T10 · Acceptance linkage:** Link the “Credential lifetime” evidence to its parent and UC-M11.01 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 07. Revocation propagation

**Source delivery:** Remove revoked workers from scheduling and trusted result publication.

**Source invariant:** A revoked worker cannot keep publishing trusted results.

**Source negative case:** A removed worker reconnects using a cached session.

**Source bounded quantities:** Revocation delay and session cache entries.

### UC-M11.01-C061 · Contract

**Original checklist item:** Specify revocation propagation inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M11.01-C061-T01 · Scope statement:** Draft the operation boundary for “Revocation propagation” within Authenticated worker identity; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M11.01-C061-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Revocation propagation”; record each producer, representation and missing-value meaning.
- [ ] **UC-M11.01-C061-T03 · Output inventory:** List the outputs of “Revocation propagation” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M11.01-C061-T04 · Field dictionary:** Create a field-and-term dictionary for “Revocation propagation”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M11.01-C061-T05 · Prerequisite contract:** Map “Revocation propagation” to the source component prerequisites (UC-M06.02, UC-M09.01); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M11.01-C061-T06 · Authority map:** Identify who may produce, change and consume “Revocation propagation”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M11.01-C061-T07 · Invariant clause:** Add a normative clause for “Revocation propagation” that preserves “A revoked worker cannot keep publishing trusted results”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M11.01-C061-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Revocation propagation”; include the source counterexample “A removed worker reconnects using a cached session” and the intended safe disposition.
- [ ] **UC-M11.01-C061-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Revocation delay and session cache entries” in the “Revocation propagation” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M11.01-C061-T10 · Contract review:** Review the “Revocation propagation” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M11.01-C062 · Delivery

**Original checklist item:** Remove revoked workers from scheduling and trusted result publication.

- [ ] **UC-M11.01-C062-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Revocation propagation”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M11.01-C062-T02 · Change plan:** Break the source delivery for “Revocation propagation” into concrete edit targets and reviewable outputs; keep the UC-M11.01 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M11.01-C062-T03 · Core artifact:** Implement the smallest selected-profile change for “Revocation propagation” that realizes this source instruction: Remove revoked workers from scheduling and trusted result publication.
- [ ] **UC-M11.01-C062-T04 · Concrete realization:** Trace “Revocation propagation” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M11.01-C062-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Revocation propagation” needed to preserve “A revoked worker cannot keep publishing trusted results”; record an enforcement gap where only a model exists.
- [ ] **UC-M11.01-C062-T06 · Dependency connection:** Connect the “Revocation propagation” implementation to approved worker enrollment, scheduler membership and trusted result acceptance; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M11.01-C062-T07 · Resource behavior:** Account for “Revocation delay and session cache entries” in “Revocation propagation”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M11.01-C062-T08 · Delivery check:** Run the smallest real “Revocation propagation” path and its adverse fixture “A removed worker reconnects using a cached session”; retain actual output, state effects and final disposition.
- [ ] **UC-M11.01-C062-T09 · Patch review:** Review the “Revocation propagation” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M11.01-C062-T10 · Delivery handoff:** Publish the “Revocation propagation” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M11.01-C063 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: A revoked worker cannot keep publishing trusted results. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M11.01-C063-T01 · Named property:** Create a stable property/check name under this parent for “Revocation propagation”; copy its required invariant exactly: “A revoked worker cannot keep publishing trusted results”.
- [ ] **UC-M11.01-C063-T02 · Observable terms:** Define each term in the “Revocation propagation” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M11.01-C063-T03 · Precondition set:** List the preconditions under which “A revoked worker cannot keep publishing trusted results” must hold for “Revocation propagation”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M11.01-C063-T04 · Transition coverage:** Map the “Revocation propagation” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M11.01-C063-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Revocation propagation”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M11.01-C063-T06 · Satisfying fixture:** Create a concrete “Revocation propagation” case that satisfies “A revoked worker cannot keep publishing trusted results”; record its expected observation before running the assertion or review.
- [ ] **UC-M11.01-C063-T07 · Violating fixture:** Create the source counterexample “A removed worker reconnects using a cached session” for “Revocation propagation”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M11.01-C063-T08 · Enforcement evidence:** Exercise the “Revocation propagation” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M11.01-C063-T09 · Regression linkage:** Link the “Revocation propagation” property to changes in approved worker enrollment, scheduler membership and trusted result acceptance; record which dependency or contract changes require rerunning it.
- [ ] **UC-M11.01-C063-T10 · Property disposition:** Compare the satisfying and violating “Revocation propagation” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M11.01-C064 · Integration

**Original checklist item:** Integrate revocation propagation with approved worker enrollment, scheduler membership and trusted result acceptance; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M11.01-C064-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Revocation propagation” across approved worker enrollment, scheduler membership and trusted result acceptance; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M11.01-C064-T02 · Field mapping:** Map every “Revocation propagation” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M11.01-C064-T03 · Prerequisite identities:** Record the actual prerequisites for “Revocation propagation” (source dependency list: UC-M06.02, UC-M09.01); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M11.01-C064-T04 · Ownership agreement:** Specify who owns “Revocation propagation” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M11.01-C064-T05 · Handoff implementation:** Connect “Revocation propagation” through the mapped seam using the real adapter or explicit specification reference; preserve “A revoked worker cannot keep publishing trusted results” across the handoff.
- [ ] **UC-M11.01-C064-T06 · Absent-input case:** Omit one required “Revocation propagation” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M11.01-C064-T07 · Stale-input case:** Supply an outdated “Revocation propagation” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M11.01-C064-T08 · Incompatible-input case:** Supply an incompatible “Revocation propagation” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M11.01-C064-T09 · Valid integration trace:** Run a valid “Revocation propagation” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M11.01-C064-T10 · Seam review:** Reconcile the “Revocation propagation” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M11.01-C065 · Valid-case test

**Original checklist item:** Run a valid-path fixture for revocation propagation; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M11.01-C065-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Revocation propagation” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M11.01-C065-T02 · Expected-result oracle:** Specify the “Revocation propagation” expected result independently of the implementation output; include the property “A revoked worker cannot keep publishing trusted results” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M11.01-C065-T03 · Fixture material:** Create the concrete “Revocation propagation” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M11.01-C065-T04 · Target preparation:** Prepare the “Revocation propagation” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M11.01-C065-T05 · Initial-state record:** Record the initial “Revocation propagation” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M11.01-C065-T06 · Valid-path execution:** Execute the “Revocation propagation” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M11.01-C065-T07 · Outcome comparison:** Compare every declared “Revocation propagation” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M11.01-C065-T08 · State and bounds check:** Inspect the “Revocation propagation” ownership/state effects and actual use of “Revocation delay and session cache entries”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M11.01-C065-T09 · Repeatability check:** Repeat the same “Revocation propagation” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M11.01-C065-T10 · Positive evidence:** Attach the “Revocation propagation” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M11.01-C066 · Negative test

**Original checklist item:** Negative case: A removed worker reconnects using a cached session. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M11.01-C066-T01 · Adverse-case definition:** Create a test record for the exact “Revocation propagation” source counterexample: “A removed worker reconnects using a cached session”; state which precondition or invariant it challenges.
- [ ] **UC-M11.01-C066-T02 · Safe fixture boundary:** Define the contained test boundary for “Revocation propagation”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M11.01-C066-T03 · Valid control:** Construct a valid “Revocation propagation” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M11.01-C066-T04 · Minimal adverse input:** Derive the “Revocation propagation” adverse fixture from the control with the smallest documented change needed to reproduce “A removed worker reconnects using a cached session”; retain that change as reproducible data.
- [ ] **UC-M11.01-C066-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Revocation propagation”; require “A revoked worker cannot keep publishing trusted results” and forbid a false-success verdict.
- [ ] **UC-M11.01-C066-T06 · Adverse execution:** Exercise the “Revocation propagation” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M11.01-C066-T07 · Effect inspection:** Inspect “Revocation propagation” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M11.01-C066-T08 · Refusal versus failure:** Confirm the “Revocation propagation” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M11.01-C066-T09 · Reset and retention:** Restore only the disposable “Revocation propagation” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M11.01-C066-T10 · Negative regression:** Register the “Revocation propagation” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M11.01-C067 · Change / failure test

**Original checklist item:** Exercise revocation propagation when an enrolled worker is revoked and later reconnects using its old credentials; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M11.01-C067-T01 · Scenario record:** Write the “Revocation propagation” change/failure scenario exactly as supplied: an enrolled worker is revoked and later reconnects using its old credentials; identify the property that must remain true: “A revoked worker cannot keep publishing trusted results”.
- [ ] **UC-M11.01-C067-T02 · Baseline capture:** Create a known-valid “Revocation propagation” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M11.01-C067-T03 · Injection map:** Locate the “Revocation propagation” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M11.01-C067-T04 · Disposition oracle:** Define the legal intermediate and final “Revocation propagation” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M11.01-C067-T05 · Controlled trigger:** Introduce the controlled “Revocation propagation” scenario in the disposable fixture: an enrolled worker is revoked and later reconnects using its old credentials; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M11.01-C067-T06 · Intermediate inspection:** Inspect the “Revocation propagation” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M11.01-C067-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Revocation propagation”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M11.01-C067-T08 · Stale-evidence cleanup:** Invalidate superseded “Revocation propagation” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M11.01-C067-T09 · Repeat and compare:** Repeat the selected “Revocation propagation” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M11.01-C067-T10 · Failure evidence:** Publish the “Revocation propagation” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M11.01-C068 · Bounds

**Original checklist item:** Choose, document and test limits for revocation delay and session cache entries; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M11.01-C068-T01 · Quantity inventory:** Create a measurement inventory for “Revocation propagation”: “Revocation delay and session cache entries”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M11.01-C068-T02 · Measurement method:** Choose how to observe each “Revocation propagation” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M11.01-C068-T03 · Budget decision:** Select justified resource and input limits for “Revocation propagation”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M11.01-C068-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Revocation propagation” cases for “Revocation delay and session cache entries”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M11.01-C068-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Revocation propagation” limit; preserve “A revoked worker cannot keep publishing trusted results”.
- [ ] **UC-M11.01-C068-T06 · Normal measurement:** Run or review the normal “Revocation propagation” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M11.01-C068-T07 · At-limit measurement:** Exercise the “Revocation propagation” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M11.01-C068-T08 · Over-limit measurement:** Exercise the “Revocation propagation” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M11.01-C068-T09 · Uncovered-scope report:** List the “Revocation propagation” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M11.01-C068-T10 · Limit evidence:** Publish the selected “Revocation propagation” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M11.01-C069 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for revocation propagation with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M11.01-C069-T01 · Event inventory:** List the “Revocation propagation” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M11.01-C069-T02 · Diagnostic schema:** Define nonsecret fields for “Revocation propagation” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M11.01-C069-T03 · Failure mapping:** Map each documented “Revocation propagation” refusal or error to a diagnostic outcome; include “A removed worker reconnects using a cached session” and prohibit conversion into a success message.
- [ ] **UC-M11.01-C069-T04 · Emission path:** Add the “Revocation propagation” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M11.01-C069-T05 · Redaction check:** Test “Revocation propagation” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M11.01-C069-T06 · Output budget:** Set and exercise bounded “Revocation propagation” message size, rate and retention compatible with “Revocation delay and session cache entries”; define truncation behavior that preserves the final reason.
- [ ] **UC-M11.01-C069-T07 · Success/refusal fixtures:** Capture “Revocation propagation” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M11.01-C069-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Revocation propagation” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M11.01-C069-T09 · Operator review:** Read the “Revocation propagation” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M11.01-C069-T10 · Diagnostic evidence:** Publish redacted “Revocation propagation” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M11.01-C070 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for revocation propagation; label unexecuted checks as untested.

- [ ] **UC-M11.01-C070-T01 · Evidence inventory:** List the “Revocation propagation” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M11.01-C070-T02 · Artifact references:** Record the exact “Revocation propagation” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M11.01-C070-T03 · Fixture references:** Attach the “Revocation propagation” fixture IDs, input identities and oracle definition; preserve the source counterexample “A removed worker reconnects using a cached session” as a distinct evidence case.
- [ ] **UC-M11.01-C070-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Revocation propagation”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M11.01-C070-T05 · Environment record:** Record the actual “Revocation propagation” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M11.01-C070-T06 · Expected versus observed:** Pair every “Revocation propagation” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M11.01-C070-T07 · Failure and limit records:** Attach “Revocation propagation” change/failure and bounds evidence where required; include uncovered “Revocation delay and session cache entries” and unresolved violations of “A revoked worker cannot keep publishing trusted results”.
- [ ] **UC-M11.01-C070-T08 · Evidence hygiene:** Check the “Revocation propagation” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M11.01-C070-T09 · Reproduction review:** Have the “Revocation propagation” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M11.01-C070-T10 · Acceptance linkage:** Link the “Revocation propagation” evidence to its parent and UC-M11.01 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 08. Cargo delivery authorization

**Source delivery:** Authorize cargo transmission against current worker identity and membership.

**Source invariant:** Unknown or revoked workers receive no protected cargo.

**Source negative case:** A scheduler sends artifacts before enrollment verification completes.

**Source bounded quantities:** Delivery requests and artifact bytes.

### UC-M11.01-C071 · Contract

**Original checklist item:** Specify cargo delivery authorization inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M11.01-C071-T01 · Scope statement:** Draft the operation boundary for “Cargo delivery authorization” within Authenticated worker identity; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M11.01-C071-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Cargo delivery authorization”; record each producer, representation and missing-value meaning.
- [ ] **UC-M11.01-C071-T03 · Output inventory:** List the outputs of “Cargo delivery authorization” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M11.01-C071-T04 · Field dictionary:** Create a field-and-term dictionary for “Cargo delivery authorization”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M11.01-C071-T05 · Prerequisite contract:** Map “Cargo delivery authorization” to the source component prerequisites (UC-M06.02, UC-M09.01); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M11.01-C071-T06 · Authority map:** Identify who may produce, change and consume “Cargo delivery authorization”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M11.01-C071-T07 · Invariant clause:** Add a normative clause for “Cargo delivery authorization” that preserves “Unknown or revoked workers receive no protected cargo”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M11.01-C071-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Cargo delivery authorization”; include the source counterexample “A scheduler sends artifacts before enrollment verification completes” and the intended safe disposition.
- [ ] **UC-M11.01-C071-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Delivery requests and artifact bytes” in the “Cargo delivery authorization” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M11.01-C071-T10 · Contract review:** Review the “Cargo delivery authorization” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M11.01-C072 · Delivery

**Original checklist item:** Authorize cargo transmission against current worker identity and membership.

- [ ] **UC-M11.01-C072-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Cargo delivery authorization”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M11.01-C072-T02 · Change plan:** Break the source delivery for “Cargo delivery authorization” into concrete edit targets and reviewable outputs; keep the UC-M11.01 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M11.01-C072-T03 · Core artifact:** Implement the smallest selected-profile change for “Cargo delivery authorization” that realizes this source instruction: Authorize cargo transmission against current worker identity and membership.
- [ ] **UC-M11.01-C072-T04 · Concrete realization:** Trace “Cargo delivery authorization” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M11.01-C072-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Cargo delivery authorization” needed to preserve “Unknown or revoked workers receive no protected cargo”; record an enforcement gap where only a model exists.
- [ ] **UC-M11.01-C072-T06 · Dependency connection:** Connect the “Cargo delivery authorization” implementation to approved worker enrollment, scheduler membership and trusted result acceptance; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M11.01-C072-T07 · Resource behavior:** Account for “Delivery requests and artifact bytes” in “Cargo delivery authorization”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M11.01-C072-T08 · Delivery check:** Run the smallest real “Cargo delivery authorization” path and its adverse fixture “A scheduler sends artifacts before enrollment verification completes”; retain actual output, state effects and final disposition.
- [ ] **UC-M11.01-C072-T09 · Patch review:** Review the “Cargo delivery authorization” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M11.01-C072-T10 · Delivery handoff:** Publish the “Cargo delivery authorization” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M11.01-C073 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Unknown or revoked workers receive no protected cargo. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M11.01-C073-T01 · Named property:** Create a stable property/check name under this parent for “Cargo delivery authorization”; copy its required invariant exactly: “Unknown or revoked workers receive no protected cargo”.
- [ ] **UC-M11.01-C073-T02 · Observable terms:** Define each term in the “Cargo delivery authorization” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M11.01-C073-T03 · Precondition set:** List the preconditions under which “Unknown or revoked workers receive no protected cargo” must hold for “Cargo delivery authorization”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M11.01-C073-T04 · Transition coverage:** Map the “Cargo delivery authorization” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M11.01-C073-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Cargo delivery authorization”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M11.01-C073-T06 · Satisfying fixture:** Create a concrete “Cargo delivery authorization” case that satisfies “Unknown or revoked workers receive no protected cargo”; record its expected observation before running the assertion or review.
- [ ] **UC-M11.01-C073-T07 · Violating fixture:** Create the source counterexample “A scheduler sends artifacts before enrollment verification completes” for “Cargo delivery authorization”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M11.01-C073-T08 · Enforcement evidence:** Exercise the “Cargo delivery authorization” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M11.01-C073-T09 · Regression linkage:** Link the “Cargo delivery authorization” property to changes in approved worker enrollment, scheduler membership and trusted result acceptance; record which dependency or contract changes require rerunning it.
- [ ] **UC-M11.01-C073-T10 · Property disposition:** Compare the satisfying and violating “Cargo delivery authorization” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M11.01-C074 · Integration

**Original checklist item:** Integrate cargo delivery authorization with approved worker enrollment, scheduler membership and trusted result acceptance; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M11.01-C074-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Cargo delivery authorization” across approved worker enrollment, scheduler membership and trusted result acceptance; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M11.01-C074-T02 · Field mapping:** Map every “Cargo delivery authorization” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M11.01-C074-T03 · Prerequisite identities:** Record the actual prerequisites for “Cargo delivery authorization” (source dependency list: UC-M06.02, UC-M09.01); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M11.01-C074-T04 · Ownership agreement:** Specify who owns “Cargo delivery authorization” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M11.01-C074-T05 · Handoff implementation:** Connect “Cargo delivery authorization” through the mapped seam using the real adapter or explicit specification reference; preserve “Unknown or revoked workers receive no protected cargo” across the handoff.
- [ ] **UC-M11.01-C074-T06 · Absent-input case:** Omit one required “Cargo delivery authorization” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M11.01-C074-T07 · Stale-input case:** Supply an outdated “Cargo delivery authorization” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M11.01-C074-T08 · Incompatible-input case:** Supply an incompatible “Cargo delivery authorization” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M11.01-C074-T09 · Valid integration trace:** Run a valid “Cargo delivery authorization” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M11.01-C074-T10 · Seam review:** Reconcile the “Cargo delivery authorization” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M11.01-C075 · Valid-case test

**Original checklist item:** Run a valid-path fixture for cargo delivery authorization; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M11.01-C075-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Cargo delivery authorization” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M11.01-C075-T02 · Expected-result oracle:** Specify the “Cargo delivery authorization” expected result independently of the implementation output; include the property “Unknown or revoked workers receive no protected cargo” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M11.01-C075-T03 · Fixture material:** Create the concrete “Cargo delivery authorization” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M11.01-C075-T04 · Target preparation:** Prepare the “Cargo delivery authorization” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M11.01-C075-T05 · Initial-state record:** Record the initial “Cargo delivery authorization” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M11.01-C075-T06 · Valid-path execution:** Execute the “Cargo delivery authorization” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M11.01-C075-T07 · Outcome comparison:** Compare every declared “Cargo delivery authorization” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M11.01-C075-T08 · State and bounds check:** Inspect the “Cargo delivery authorization” ownership/state effects and actual use of “Delivery requests and artifact bytes”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M11.01-C075-T09 · Repeatability check:** Repeat the same “Cargo delivery authorization” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M11.01-C075-T10 · Positive evidence:** Attach the “Cargo delivery authorization” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M11.01-C076 · Negative test

**Original checklist item:** Negative case: A scheduler sends artifacts before enrollment verification completes. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M11.01-C076-T01 · Adverse-case definition:** Create a test record for the exact “Cargo delivery authorization” source counterexample: “A scheduler sends artifacts before enrollment verification completes”; state which precondition or invariant it challenges.
- [ ] **UC-M11.01-C076-T02 · Safe fixture boundary:** Define the contained test boundary for “Cargo delivery authorization”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M11.01-C076-T03 · Valid control:** Construct a valid “Cargo delivery authorization” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M11.01-C076-T04 · Minimal adverse input:** Derive the “Cargo delivery authorization” adverse fixture from the control with the smallest documented change needed to reproduce “A scheduler sends artifacts before enrollment verification completes”; retain that change as reproducible data.
- [ ] **UC-M11.01-C076-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Cargo delivery authorization”; require “Unknown or revoked workers receive no protected cargo” and forbid a false-success verdict.
- [ ] **UC-M11.01-C076-T06 · Adverse execution:** Exercise the “Cargo delivery authorization” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M11.01-C076-T07 · Effect inspection:** Inspect “Cargo delivery authorization” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M11.01-C076-T08 · Refusal versus failure:** Confirm the “Cargo delivery authorization” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M11.01-C076-T09 · Reset and retention:** Restore only the disposable “Cargo delivery authorization” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M11.01-C076-T10 · Negative regression:** Register the “Cargo delivery authorization” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M11.01-C077 · Change / failure test

**Original checklist item:** Exercise cargo delivery authorization when an enrolled worker is revoked and later reconnects using its old credentials; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M11.01-C077-T01 · Scenario record:** Write the “Cargo delivery authorization” change/failure scenario exactly as supplied: an enrolled worker is revoked and later reconnects using its old credentials; identify the property that must remain true: “Unknown or revoked workers receive no protected cargo”.
- [ ] **UC-M11.01-C077-T02 · Baseline capture:** Create a known-valid “Cargo delivery authorization” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M11.01-C077-T03 · Injection map:** Locate the “Cargo delivery authorization” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M11.01-C077-T04 · Disposition oracle:** Define the legal intermediate and final “Cargo delivery authorization” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M11.01-C077-T05 · Controlled trigger:** Introduce the controlled “Cargo delivery authorization” scenario in the disposable fixture: an enrolled worker is revoked and later reconnects using its old credentials; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M11.01-C077-T06 · Intermediate inspection:** Inspect the “Cargo delivery authorization” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M11.01-C077-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Cargo delivery authorization”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M11.01-C077-T08 · Stale-evidence cleanup:** Invalidate superseded “Cargo delivery authorization” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M11.01-C077-T09 · Repeat and compare:** Repeat the selected “Cargo delivery authorization” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M11.01-C077-T10 · Failure evidence:** Publish the “Cargo delivery authorization” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M11.01-C078 · Bounds

**Original checklist item:** Choose, document and test limits for delivery requests and artifact bytes; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M11.01-C078-T01 · Quantity inventory:** Create a measurement inventory for “Cargo delivery authorization”: “Delivery requests and artifact bytes”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M11.01-C078-T02 · Measurement method:** Choose how to observe each “Cargo delivery authorization” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M11.01-C078-T03 · Budget decision:** Select justified resource and input limits for “Cargo delivery authorization”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M11.01-C078-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Cargo delivery authorization” cases for “Delivery requests and artifact bytes”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M11.01-C078-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Cargo delivery authorization” limit; preserve “Unknown or revoked workers receive no protected cargo”.
- [ ] **UC-M11.01-C078-T06 · Normal measurement:** Run or review the normal “Cargo delivery authorization” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M11.01-C078-T07 · At-limit measurement:** Exercise the “Cargo delivery authorization” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M11.01-C078-T08 · Over-limit measurement:** Exercise the “Cargo delivery authorization” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M11.01-C078-T09 · Uncovered-scope report:** List the “Cargo delivery authorization” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M11.01-C078-T10 · Limit evidence:** Publish the selected “Cargo delivery authorization” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M11.01-C079 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for cargo delivery authorization with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M11.01-C079-T01 · Event inventory:** List the “Cargo delivery authorization” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M11.01-C079-T02 · Diagnostic schema:** Define nonsecret fields for “Cargo delivery authorization” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M11.01-C079-T03 · Failure mapping:** Map each documented “Cargo delivery authorization” refusal or error to a diagnostic outcome; include “A scheduler sends artifacts before enrollment verification completes” and prohibit conversion into a success message.
- [ ] **UC-M11.01-C079-T04 · Emission path:** Add the “Cargo delivery authorization” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M11.01-C079-T05 · Redaction check:** Test “Cargo delivery authorization” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M11.01-C079-T06 · Output budget:** Set and exercise bounded “Cargo delivery authorization” message size, rate and retention compatible with “Delivery requests and artifact bytes”; define truncation behavior that preserves the final reason.
- [ ] **UC-M11.01-C079-T07 · Success/refusal fixtures:** Capture “Cargo delivery authorization” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M11.01-C079-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Cargo delivery authorization” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M11.01-C079-T09 · Operator review:** Read the “Cargo delivery authorization” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M11.01-C079-T10 · Diagnostic evidence:** Publish redacted “Cargo delivery authorization” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M11.01-C080 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for cargo delivery authorization; label unexecuted checks as untested.

- [ ] **UC-M11.01-C080-T01 · Evidence inventory:** List the “Cargo delivery authorization” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M11.01-C080-T02 · Artifact references:** Record the exact “Cargo delivery authorization” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M11.01-C080-T03 · Fixture references:** Attach the “Cargo delivery authorization” fixture IDs, input identities and oracle definition; preserve the source counterexample “A scheduler sends artifacts before enrollment verification completes” as a distinct evidence case.
- [ ] **UC-M11.01-C080-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Cargo delivery authorization”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M11.01-C080-T05 · Environment record:** Record the actual “Cargo delivery authorization” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M11.01-C080-T06 · Expected versus observed:** Pair every “Cargo delivery authorization” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M11.01-C080-T07 · Failure and limit records:** Attach “Cargo delivery authorization” change/failure and bounds evidence where required; include uncovered “Delivery requests and artifact bytes” and unresolved violations of “Unknown or revoked workers receive no protected cargo”.
- [ ] **UC-M11.01-C080-T08 · Evidence hygiene:** Check the “Cargo delivery authorization” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M11.01-C080-T09 · Reproduction review:** Have the “Cargo delivery authorization” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M11.01-C080-T10 · Acceptance linkage:** Link the “Cargo delivery authorization” evidence to its parent and UC-M11.01 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 09. Result publisher identity

**Source delivery:** Verify the worker and assigned workload generation on returned results.

**Source invariant:** An enrolled worker cannot impersonate another worker's assigned result.

**Source negative case:** A worker publishes completion for a workload it was never assigned.

**Source bounded quantities:** Result records and authorization lookups.

### UC-M11.01-C081 · Contract

**Original checklist item:** Specify result publisher identity inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M11.01-C081-T01 · Scope statement:** Draft the operation boundary for “Result publisher identity” within Authenticated worker identity; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M11.01-C081-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Result publisher identity”; record each producer, representation and missing-value meaning.
- [ ] **UC-M11.01-C081-T03 · Output inventory:** List the outputs of “Result publisher identity” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M11.01-C081-T04 · Field dictionary:** Create a field-and-term dictionary for “Result publisher identity”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M11.01-C081-T05 · Prerequisite contract:** Map “Result publisher identity” to the source component prerequisites (UC-M06.02, UC-M09.01); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M11.01-C081-T06 · Authority map:** Identify who may produce, change and consume “Result publisher identity”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M11.01-C081-T07 · Invariant clause:** Add a normative clause for “Result publisher identity” that preserves “An enrolled worker cannot impersonate another worker's assigned result”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M11.01-C081-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Result publisher identity”; include the source counterexample “A worker publishes completion for a workload it was never assigned” and the intended safe disposition.
- [ ] **UC-M11.01-C081-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Result records and authorization lookups” in the “Result publisher identity” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M11.01-C081-T10 · Contract review:** Review the “Result publisher identity” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M11.01-C082 · Delivery

**Original checklist item:** Verify the worker and assigned workload generation on returned results.

- [ ] **UC-M11.01-C082-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Result publisher identity”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M11.01-C082-T02 · Change plan:** Break the source delivery for “Result publisher identity” into concrete edit targets and reviewable outputs; keep the UC-M11.01 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M11.01-C082-T03 · Core artifact:** Create the “Result publisher identity” fixture or harness for this source instruction: Verify the worker and assigned workload generation on returned results.
- [ ] **UC-M11.01-C082-T04 · Concrete realization:** Connect the “Result publisher identity” harness to its actual intended target, set the expected oracle before running it, and distinguish a mock/control run from a target run.
- [ ] **UC-M11.01-C082-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Result publisher identity” needed to preserve “An enrolled worker cannot impersonate another worker's assigned result”; record an enforcement gap where only a model exists.
- [ ] **UC-M11.01-C082-T06 · Dependency connection:** Connect the “Result publisher identity” implementation to approved worker enrollment, scheduler membership and trusted result acceptance; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M11.01-C082-T07 · Resource behavior:** Account for “Result records and authorization lookups” in “Result publisher identity”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M11.01-C082-T08 · Delivery check:** Run the smallest real “Result publisher identity” path and its adverse fixture “A worker publishes completion for a workload it was never assigned”; retain actual output, state effects and final disposition.
- [ ] **UC-M11.01-C082-T09 · Patch review:** Review the “Result publisher identity” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M11.01-C082-T10 · Delivery handoff:** Publish the “Result publisher identity” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M11.01-C083 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: An enrolled worker cannot impersonate another worker's assigned result. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M11.01-C083-T01 · Named property:** Create a stable property/check name under this parent for “Result publisher identity”; copy its required invariant exactly: “An enrolled worker cannot impersonate another worker's assigned result”.
- [ ] **UC-M11.01-C083-T02 · Observable terms:** Define each term in the “Result publisher identity” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M11.01-C083-T03 · Precondition set:** List the preconditions under which “An enrolled worker cannot impersonate another worker's assigned result” must hold for “Result publisher identity”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M11.01-C083-T04 · Transition coverage:** Map the “Result publisher identity” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M11.01-C083-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Result publisher identity”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M11.01-C083-T06 · Satisfying fixture:** Create a concrete “Result publisher identity” case that satisfies “An enrolled worker cannot impersonate another worker's assigned result”; record its expected observation before running the assertion or review.
- [ ] **UC-M11.01-C083-T07 · Violating fixture:** Create the source counterexample “A worker publishes completion for a workload it was never assigned” for “Result publisher identity”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M11.01-C083-T08 · Enforcement evidence:** Exercise the “Result publisher identity” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M11.01-C083-T09 · Regression linkage:** Link the “Result publisher identity” property to changes in approved worker enrollment, scheduler membership and trusted result acceptance; record which dependency or contract changes require rerunning it.
- [ ] **UC-M11.01-C083-T10 · Property disposition:** Compare the satisfying and violating “Result publisher identity” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M11.01-C084 · Integration

**Original checklist item:** Integrate result publisher identity with approved worker enrollment, scheduler membership and trusted result acceptance; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M11.01-C084-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Result publisher identity” across approved worker enrollment, scheduler membership and trusted result acceptance; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M11.01-C084-T02 · Field mapping:** Map every “Result publisher identity” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M11.01-C084-T03 · Prerequisite identities:** Record the actual prerequisites for “Result publisher identity” (source dependency list: UC-M06.02, UC-M09.01); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M11.01-C084-T04 · Ownership agreement:** Specify who owns “Result publisher identity” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M11.01-C084-T05 · Handoff implementation:** Connect “Result publisher identity” through the mapped seam using the real adapter or explicit specification reference; preserve “An enrolled worker cannot impersonate another worker's assigned result” across the handoff.
- [ ] **UC-M11.01-C084-T06 · Absent-input case:** Omit one required “Result publisher identity” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M11.01-C084-T07 · Stale-input case:** Supply an outdated “Result publisher identity” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M11.01-C084-T08 · Incompatible-input case:** Supply an incompatible “Result publisher identity” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M11.01-C084-T09 · Valid integration trace:** Run a valid “Result publisher identity” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M11.01-C084-T10 · Seam review:** Reconcile the “Result publisher identity” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M11.01-C085 · Valid-case test

**Original checklist item:** Run a valid-path fixture for result publisher identity; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M11.01-C085-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Result publisher identity” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M11.01-C085-T02 · Expected-result oracle:** Specify the “Result publisher identity” expected result independently of the implementation output; include the property “An enrolled worker cannot impersonate another worker's assigned result” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M11.01-C085-T03 · Fixture material:** Create the concrete “Result publisher identity” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M11.01-C085-T04 · Target preparation:** Prepare the “Result publisher identity” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M11.01-C085-T05 · Initial-state record:** Record the initial “Result publisher identity” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M11.01-C085-T06 · Valid-path execution:** Execute the “Result publisher identity” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M11.01-C085-T07 · Outcome comparison:** Compare every declared “Result publisher identity” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M11.01-C085-T08 · State and bounds check:** Inspect the “Result publisher identity” ownership/state effects and actual use of “Result records and authorization lookups”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M11.01-C085-T09 · Repeatability check:** Repeat the same “Result publisher identity” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M11.01-C085-T10 · Positive evidence:** Attach the “Result publisher identity” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M11.01-C086 · Negative test

**Original checklist item:** Negative case: A worker publishes completion for a workload it was never assigned. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M11.01-C086-T01 · Adverse-case definition:** Create a test record for the exact “Result publisher identity” source counterexample: “A worker publishes completion for a workload it was never assigned”; state which precondition or invariant it challenges.
- [ ] **UC-M11.01-C086-T02 · Safe fixture boundary:** Define the contained test boundary for “Result publisher identity”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M11.01-C086-T03 · Valid control:** Construct a valid “Result publisher identity” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M11.01-C086-T04 · Minimal adverse input:** Derive the “Result publisher identity” adverse fixture from the control with the smallest documented change needed to reproduce “A worker publishes completion for a workload it was never assigned”; retain that change as reproducible data.
- [ ] **UC-M11.01-C086-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Result publisher identity”; require “An enrolled worker cannot impersonate another worker's assigned result” and forbid a false-success verdict.
- [ ] **UC-M11.01-C086-T06 · Adverse execution:** Exercise the “Result publisher identity” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M11.01-C086-T07 · Effect inspection:** Inspect “Result publisher identity” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M11.01-C086-T08 · Refusal versus failure:** Confirm the “Result publisher identity” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M11.01-C086-T09 · Reset and retention:** Restore only the disposable “Result publisher identity” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M11.01-C086-T10 · Negative regression:** Register the “Result publisher identity” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M11.01-C087 · Change / failure test

**Original checklist item:** Exercise result publisher identity when an enrolled worker is revoked and later reconnects using its old credentials; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M11.01-C087-T01 · Scenario record:** Write the “Result publisher identity” change/failure scenario exactly as supplied: an enrolled worker is revoked and later reconnects using its old credentials; identify the property that must remain true: “An enrolled worker cannot impersonate another worker's assigned result”.
- [ ] **UC-M11.01-C087-T02 · Baseline capture:** Create a known-valid “Result publisher identity” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M11.01-C087-T03 · Injection map:** Locate the “Result publisher identity” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M11.01-C087-T04 · Disposition oracle:** Define the legal intermediate and final “Result publisher identity” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M11.01-C087-T05 · Controlled trigger:** Introduce the controlled “Result publisher identity” scenario in the disposable fixture: an enrolled worker is revoked and later reconnects using its old credentials; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M11.01-C087-T06 · Intermediate inspection:** Inspect the “Result publisher identity” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M11.01-C087-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Result publisher identity”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M11.01-C087-T08 · Stale-evidence cleanup:** Invalidate superseded “Result publisher identity” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M11.01-C087-T09 · Repeat and compare:** Repeat the selected “Result publisher identity” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M11.01-C087-T10 · Failure evidence:** Publish the “Result publisher identity” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M11.01-C088 · Bounds

**Original checklist item:** Choose, document and test limits for result records and authorization lookups; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M11.01-C088-T01 · Quantity inventory:** Create a measurement inventory for “Result publisher identity”: “Result records and authorization lookups”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M11.01-C088-T02 · Measurement method:** Choose how to observe each “Result publisher identity” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M11.01-C088-T03 · Budget decision:** Select justified resource and input limits for “Result publisher identity”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M11.01-C088-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Result publisher identity” cases for “Result records and authorization lookups”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M11.01-C088-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Result publisher identity” limit; preserve “An enrolled worker cannot impersonate another worker's assigned result”.
- [ ] **UC-M11.01-C088-T06 · Normal measurement:** Run or review the normal “Result publisher identity” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M11.01-C088-T07 · At-limit measurement:** Exercise the “Result publisher identity” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M11.01-C088-T08 · Over-limit measurement:** Exercise the “Result publisher identity” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M11.01-C088-T09 · Uncovered-scope report:** List the “Result publisher identity” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M11.01-C088-T10 · Limit evidence:** Publish the selected “Result publisher identity” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M11.01-C089 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for result publisher identity with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M11.01-C089-T01 · Event inventory:** List the “Result publisher identity” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M11.01-C089-T02 · Diagnostic schema:** Define nonsecret fields for “Result publisher identity” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M11.01-C089-T03 · Failure mapping:** Map each documented “Result publisher identity” refusal or error to a diagnostic outcome; include “A worker publishes completion for a workload it was never assigned” and prohibit conversion into a success message.
- [ ] **UC-M11.01-C089-T04 · Emission path:** Add the “Result publisher identity” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M11.01-C089-T05 · Redaction check:** Test “Result publisher identity” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M11.01-C089-T06 · Output budget:** Set and exercise bounded “Result publisher identity” message size, rate and retention compatible with “Result records and authorization lookups”; define truncation behavior that preserves the final reason.
- [ ] **UC-M11.01-C089-T07 · Success/refusal fixtures:** Capture “Result publisher identity” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M11.01-C089-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Result publisher identity” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M11.01-C089-T09 · Operator review:** Read the “Result publisher identity” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M11.01-C089-T10 · Diagnostic evidence:** Publish redacted “Result publisher identity” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M11.01-C090 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for result publisher identity; label unexecuted checks as untested.

- [ ] **UC-M11.01-C090-T01 · Evidence inventory:** List the “Result publisher identity” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M11.01-C090-T02 · Artifact references:** Record the exact “Result publisher identity” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M11.01-C090-T03 · Fixture references:** Attach the “Result publisher identity” fixture IDs, input identities and oracle definition; preserve the source counterexample “A worker publishes completion for a workload it was never assigned” as a distinct evidence case.
- [ ] **UC-M11.01-C090-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Result publisher identity”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M11.01-C090-T05 · Environment record:** Record the actual “Result publisher identity” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M11.01-C090-T06 · Expected versus observed:** Pair every “Result publisher identity” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M11.01-C090-T07 · Failure and limit records:** Attach “Result publisher identity” change/failure and bounds evidence where required; include uncovered “Result records and authorization lookups” and unresolved violations of “An enrolled worker cannot impersonate another worker's assigned result”.
- [ ] **UC-M11.01-C090-T08 · Evidence hygiene:** Check the “Result publisher identity” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M11.01-C090-T09 · Reproduction review:** Have the “Result publisher identity” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M11.01-C090-T10 · Acceptance linkage:** Link the “Result publisher identity” evidence to its parent and UC-M11.01 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 10. Worker identity qualification

**Source delivery:** Test unknown, duplicate, expired, revoked and valid worker cases.

**Source invariant:** Only approved current workers participate in scheduling and trusted results.

**Source negative case:** An unknown worker joins through a hostname match.

**Source bounded quantities:** Worker scenarios and federation test duration.

### UC-M11.01-C091 · Contract

**Original checklist item:** Specify worker identity qualification inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M11.01-C091-T01 · Scope statement:** Draft the operation boundary for “Worker identity qualification” within Authenticated worker identity; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M11.01-C091-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Worker identity qualification”; record each producer, representation and missing-value meaning.
- [ ] **UC-M11.01-C091-T03 · Output inventory:** List the outputs of “Worker identity qualification” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M11.01-C091-T04 · Field dictionary:** Create a field-and-term dictionary for “Worker identity qualification”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M11.01-C091-T05 · Prerequisite contract:** Map “Worker identity qualification” to the source component prerequisites (UC-M06.02, UC-M09.01); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M11.01-C091-T06 · Authority map:** Identify who may produce, change and consume “Worker identity qualification”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M11.01-C091-T07 · Invariant clause:** Add a normative clause for “Worker identity qualification” that preserves “Only approved current workers participate in scheduling and trusted results”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M11.01-C091-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Worker identity qualification”; include the source counterexample “An unknown worker joins through a hostname match” and the intended safe disposition.
- [ ] **UC-M11.01-C091-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Worker scenarios and federation test duration” in the “Worker identity qualification” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M11.01-C091-T10 · Contract review:** Review the “Worker identity qualification” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M11.01-C092 · Delivery

**Original checklist item:** Test unknown, duplicate, expired, revoked and valid worker cases.

- [ ] **UC-M11.01-C092-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Worker identity qualification”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M11.01-C092-T02 · Change plan:** Break the source delivery for “Worker identity qualification” into concrete edit targets and reviewable outputs; keep the UC-M11.01 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M11.01-C092-T03 · Core artifact:** Create the “Worker identity qualification” fixture or harness for this source instruction: Test unknown, duplicate, expired, revoked and valid worker cases.
- [ ] **UC-M11.01-C092-T04 · Concrete realization:** Connect the “Worker identity qualification” harness to its actual intended target, set the expected oracle before running it, and distinguish a mock/control run from a target run.
- [ ] **UC-M11.01-C092-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Worker identity qualification” needed to preserve “Only approved current workers participate in scheduling and trusted results”; record an enforcement gap where only a model exists.
- [ ] **UC-M11.01-C092-T06 · Dependency connection:** Connect the “Worker identity qualification” implementation to approved worker enrollment, scheduler membership and trusted result acceptance; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M11.01-C092-T07 · Resource behavior:** Account for “Worker scenarios and federation test duration” in “Worker identity qualification”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M11.01-C092-T08 · Delivery check:** Run the smallest real “Worker identity qualification” path and its adverse fixture “An unknown worker joins through a hostname match”; retain actual output, state effects and final disposition.
- [ ] **UC-M11.01-C092-T09 · Patch review:** Review the “Worker identity qualification” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M11.01-C092-T10 · Delivery handoff:** Publish the “Worker identity qualification” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M11.01-C093 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Only approved current workers participate in scheduling and trusted results. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M11.01-C093-T01 · Named property:** Create a stable property/check name under this parent for “Worker identity qualification”; copy its required invariant exactly: “Only approved current workers participate in scheduling and trusted results”.
- [ ] **UC-M11.01-C093-T02 · Observable terms:** Define each term in the “Worker identity qualification” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M11.01-C093-T03 · Precondition set:** List the preconditions under which “Only approved current workers participate in scheduling and trusted results” must hold for “Worker identity qualification”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M11.01-C093-T04 · Transition coverage:** Map the “Worker identity qualification” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M11.01-C093-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Worker identity qualification”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M11.01-C093-T06 · Satisfying fixture:** Create a concrete “Worker identity qualification” case that satisfies “Only approved current workers participate in scheduling and trusted results”; record its expected observation before running the assertion or review.
- [ ] **UC-M11.01-C093-T07 · Violating fixture:** Create the source counterexample “An unknown worker joins through a hostname match” for “Worker identity qualification”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M11.01-C093-T08 · Enforcement evidence:** Exercise the “Worker identity qualification” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M11.01-C093-T09 · Regression linkage:** Link the “Worker identity qualification” property to changes in approved worker enrollment, scheduler membership and trusted result acceptance; record which dependency or contract changes require rerunning it.
- [ ] **UC-M11.01-C093-T10 · Property disposition:** Compare the satisfying and violating “Worker identity qualification” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M11.01-C094 · Integration

**Original checklist item:** Integrate worker identity qualification with approved worker enrollment, scheduler membership and trusted result acceptance; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M11.01-C094-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Worker identity qualification” across approved worker enrollment, scheduler membership and trusted result acceptance; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M11.01-C094-T02 · Field mapping:** Map every “Worker identity qualification” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M11.01-C094-T03 · Prerequisite identities:** Record the actual prerequisites for “Worker identity qualification” (source dependency list: UC-M06.02, UC-M09.01); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M11.01-C094-T04 · Ownership agreement:** Specify who owns “Worker identity qualification” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M11.01-C094-T05 · Handoff implementation:** Connect “Worker identity qualification” through the mapped seam using the real adapter or explicit specification reference; preserve “Only approved current workers participate in scheduling and trusted results” across the handoff.
- [ ] **UC-M11.01-C094-T06 · Absent-input case:** Omit one required “Worker identity qualification” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M11.01-C094-T07 · Stale-input case:** Supply an outdated “Worker identity qualification” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M11.01-C094-T08 · Incompatible-input case:** Supply an incompatible “Worker identity qualification” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M11.01-C094-T09 · Valid integration trace:** Run a valid “Worker identity qualification” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M11.01-C094-T10 · Seam review:** Reconcile the “Worker identity qualification” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M11.01-C095 · Valid-case test

**Original checklist item:** Run a valid-path fixture for worker identity qualification; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M11.01-C095-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Worker identity qualification” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M11.01-C095-T02 · Expected-result oracle:** Specify the “Worker identity qualification” expected result independently of the implementation output; include the property “Only approved current workers participate in scheduling and trusted results” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M11.01-C095-T03 · Fixture material:** Create the concrete “Worker identity qualification” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M11.01-C095-T04 · Target preparation:** Prepare the “Worker identity qualification” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M11.01-C095-T05 · Initial-state record:** Record the initial “Worker identity qualification” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M11.01-C095-T06 · Valid-path execution:** Execute the “Worker identity qualification” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M11.01-C095-T07 · Outcome comparison:** Compare every declared “Worker identity qualification” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M11.01-C095-T08 · State and bounds check:** Inspect the “Worker identity qualification” ownership/state effects and actual use of “Worker scenarios and federation test duration”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M11.01-C095-T09 · Repeatability check:** Repeat the same “Worker identity qualification” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M11.01-C095-T10 · Positive evidence:** Attach the “Worker identity qualification” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M11.01-C096 · Negative test

**Original checklist item:** Negative case: An unknown worker joins through a hostname match. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M11.01-C096-T01 · Adverse-case definition:** Create a test record for the exact “Worker identity qualification” source counterexample: “An unknown worker joins through a hostname match”; state which precondition or invariant it challenges.
- [ ] **UC-M11.01-C096-T02 · Safe fixture boundary:** Define the contained test boundary for “Worker identity qualification”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M11.01-C096-T03 · Valid control:** Construct a valid “Worker identity qualification” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M11.01-C096-T04 · Minimal adverse input:** Derive the “Worker identity qualification” adverse fixture from the control with the smallest documented change needed to reproduce “An unknown worker joins through a hostname match”; retain that change as reproducible data.
- [ ] **UC-M11.01-C096-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Worker identity qualification”; require “Only approved current workers participate in scheduling and trusted results” and forbid a false-success verdict.
- [ ] **UC-M11.01-C096-T06 · Adverse execution:** Exercise the “Worker identity qualification” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M11.01-C096-T07 · Effect inspection:** Inspect “Worker identity qualification” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M11.01-C096-T08 · Refusal versus failure:** Confirm the “Worker identity qualification” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M11.01-C096-T09 · Reset and retention:** Restore only the disposable “Worker identity qualification” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M11.01-C096-T10 · Negative regression:** Register the “Worker identity qualification” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M11.01-C097 · Change / failure test

**Original checklist item:** Exercise worker identity qualification when an enrolled worker is revoked and later reconnects using its old credentials; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M11.01-C097-T01 · Scenario record:** Write the “Worker identity qualification” change/failure scenario exactly as supplied: an enrolled worker is revoked and later reconnects using its old credentials; identify the property that must remain true: “Only approved current workers participate in scheduling and trusted results”.
- [ ] **UC-M11.01-C097-T02 · Baseline capture:** Create a known-valid “Worker identity qualification” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M11.01-C097-T03 · Injection map:** Locate the “Worker identity qualification” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M11.01-C097-T04 · Disposition oracle:** Define the legal intermediate and final “Worker identity qualification” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M11.01-C097-T05 · Controlled trigger:** Introduce the controlled “Worker identity qualification” scenario in the disposable fixture: an enrolled worker is revoked and later reconnects using its old credentials; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M11.01-C097-T06 · Intermediate inspection:** Inspect the “Worker identity qualification” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M11.01-C097-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Worker identity qualification”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M11.01-C097-T08 · Stale-evidence cleanup:** Invalidate superseded “Worker identity qualification” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M11.01-C097-T09 · Repeat and compare:** Repeat the selected “Worker identity qualification” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M11.01-C097-T10 · Failure evidence:** Publish the “Worker identity qualification” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M11.01-C098 · Bounds

**Original checklist item:** Choose, document and test limits for worker scenarios and federation test duration; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M11.01-C098-T01 · Quantity inventory:** Create a measurement inventory for “Worker identity qualification”: “Worker scenarios and federation test duration”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M11.01-C098-T02 · Measurement method:** Choose how to observe each “Worker identity qualification” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M11.01-C098-T03 · Budget decision:** Select justified resource and input limits for “Worker identity qualification”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M11.01-C098-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Worker identity qualification” cases for “Worker scenarios and federation test duration”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M11.01-C098-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Worker identity qualification” limit; preserve “Only approved current workers participate in scheduling and trusted results”.
- [ ] **UC-M11.01-C098-T06 · Normal measurement:** Run or review the normal “Worker identity qualification” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M11.01-C098-T07 · At-limit measurement:** Exercise the “Worker identity qualification” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M11.01-C098-T08 · Over-limit measurement:** Exercise the “Worker identity qualification” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M11.01-C098-T09 · Uncovered-scope report:** List the “Worker identity qualification” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M11.01-C098-T10 · Limit evidence:** Publish the selected “Worker identity qualification” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M11.01-C099 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for worker identity qualification with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M11.01-C099-T01 · Event inventory:** List the “Worker identity qualification” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M11.01-C099-T02 · Diagnostic schema:** Define nonsecret fields for “Worker identity qualification” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M11.01-C099-T03 · Failure mapping:** Map each documented “Worker identity qualification” refusal or error to a diagnostic outcome; include “An unknown worker joins through a hostname match” and prohibit conversion into a success message.
- [ ] **UC-M11.01-C099-T04 · Emission path:** Add the “Worker identity qualification” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M11.01-C099-T05 · Redaction check:** Test “Worker identity qualification” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M11.01-C099-T06 · Output budget:** Set and exercise bounded “Worker identity qualification” message size, rate and retention compatible with “Worker scenarios and federation test duration”; define truncation behavior that preserves the final reason.
- [ ] **UC-M11.01-C099-T07 · Success/refusal fixtures:** Capture “Worker identity qualification” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M11.01-C099-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Worker identity qualification” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M11.01-C099-T09 · Operator review:** Read the “Worker identity qualification” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M11.01-C099-T10 · Diagnostic evidence:** Publish redacted “Worker identity qualification” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M11.01-C100 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for worker identity qualification; label unexecuted checks as untested.

- [ ] **UC-M11.01-C100-T01 · Evidence inventory:** List the “Worker identity qualification” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M11.01-C100-T02 · Artifact references:** Record the exact “Worker identity qualification” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M11.01-C100-T03 · Fixture references:** Attach the “Worker identity qualification” fixture IDs, input identities and oracle definition; preserve the source counterexample “An unknown worker joins through a hostname match” as a distinct evidence case.
- [ ] **UC-M11.01-C100-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Worker identity qualification”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M11.01-C100-T05 · Environment record:** Record the actual “Worker identity qualification” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M11.01-C100-T06 · Expected versus observed:** Pair every “Worker identity qualification” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M11.01-C100-T07 · Failure and limit records:** Attach “Worker identity qualification” change/failure and bounds evidence where required; include uncovered “Worker scenarios and federation test duration” and unresolved violations of “Only approved current workers participate in scheduling and trusted results”.
- [ ] **UC-M11.01-C100-T08 · Evidence hygiene:** Check the “Worker identity qualification” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M11.01-C100-T09 · Reproduction review:** Have the “Worker identity qualification” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M11.01-C100-T10 · Acceptance linkage:** Link the “Worker identity qualification” evidence to its parent and UC-M11.01 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

