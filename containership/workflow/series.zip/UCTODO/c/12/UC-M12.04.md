# UC-M12.04 — Crash, disk-full and concurrency fault injection

**To-Do Pack 2.0.0 · Baseline UC-2.2.0 · 100 parent checks × 10 subtasks = 1,000 to-dos**

[Master index](../../INDEX.md) · [Workstream index](../../w/12.md)

| Field | Preserved source value |
|---|---|
| Workstream | 12. Qualification, packaging and release |
| Milestone | C |
| Priority | P0 |
| Source assessment | PARTIAL |
| Scope | core or selected profile |
| Dependencies | [UC-M07.01](../07/UC-M07.01.md), [UC-M07.05](../07/UC-M07.05.md), [UC-M07.08](../07/UC-M07.08.md) |
| Source checklist pack | 1.0.0 |
| Original reference labels | [S5], [S6], [S7], [S8]. |

## Original requirement

Inject process termination, partial writes, ENOSPC, permission changes and competing operators at every commit boundary.

**Original acceptance criterion:** Recovery converges to a documented state without data loss or a false successful verdict across repeated trials.

**Source trace:** Original checklist `UC100/c/12/UC-M12.04.md` inside [s/checklists.zip](../../s/checklists.zip); exact parent records in [data/parents.jsonl](../../data/parents.jsonl). Original roadmap lines 1127–1137 are preserved in [s/roadmap.md](../../s/roadmap.md).

## How to use these lists

Every parent statement below is preserved verbatim. Its ten child tasks are proposed decomposition, not implemented capabilities or executed tests. Child IDs append `-T01` through `-T10` to the original parent ID. All begin unchecked / `TODO`. Design/review evidence does not establish runtime enforcement; observe the actual selected target where the parent requires it.

The source dependency graph and selected release profile determine applicability. The numbered child sequence is a local working order, not an added hard dependency graph. An unselected optional feature needs a recorded not-applicable rationale; missing prerequisites for selected work remain blockers. Numerical budgets, backends and trust mechanisms remain decisions unless fixed by the source. Test hostile cases only with synthetic inputs in authorized disposable environments.

## 01. Commit-boundary inventory

**Source delivery:** List every mutation boundary in transaction, tick, checkpoint and recovery paths.

**Source invariant:** Fault coverage refers to concrete mutation sites.

**Source negative case:** A new seal publication step has no injection point.

**Source bounded quantities:** Mutation sites and instrumented targets.

### UC-M12.04-C001 · Contract

**Original checklist item:** Define the qualification objective for commit-boundary inventory, including the actual target implementation, prerequisites, observable oracle and explicit exclusions.

- [ ] **UC-M12.04-C001-T01 · Scope statement:** Write the qualification question for “Commit-boundary inventory”; identify the actual target, claimed capability and observations that can answer that question.
- [ ] **UC-M12.04-C001-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Commit-boundary inventory”; record each producer, representation and missing-value meaning.
- [ ] **UC-M12.04-C001-T03 · Output inventory:** List the outputs of “Commit-boundary inventory” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M12.04-C001-T04 · Field dictionary:** Create a field-and-term dictionary for “Commit-boundary inventory”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M12.04-C001-T05 · Prerequisite contract:** Map “Commit-boundary inventory” to the source component prerequisites (UC-M07.01, UC-M07.05, UC-M07.08); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M12.04-C001-T06 · Authority map:** Identify who may produce, change and consume “Commit-boundary inventory”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M12.04-C001-T07 · Invariant clause:** Add a normative clause for “Commit-boundary inventory” that preserves “Fault coverage refers to concrete mutation sites”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M12.04-C001-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Commit-boundary inventory”; include the source counterexample “A new seal publication step has no injection point” and the intended safe disposition.
- [ ] **UC-M12.04-C001-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Mutation sites and instrumented targets” in the “Commit-boundary inventory” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M12.04-C001-T10 · Contract review:** Review the “Commit-boundary inventory” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M12.04-C002 · Delivery

**Original checklist item:** List every mutation boundary in transaction, tick, checkpoint and recovery paths.

- [ ] **UC-M12.04-C002-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Commit-boundary inventory”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M12.04-C002-T02 · Change plan:** Break the source delivery for “Commit-boundary inventory” into concrete edit targets and reviewable outputs; keep the UC-M12.04 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M12.04-C002-T03 · Core artifact:** Create the “Commit-boundary inventory” model, schema or inventory that realizes this source instruction: List every mutation boundary in transaction, tick, checkpoint and recovery paths.
- [ ] **UC-M12.04-C002-T04 · Concrete realization:** Populate “Commit-boundary inventory” with one concrete worked case; map every required entity or field to its source and flag any unmapped entry.
- [ ] **UC-M12.04-C002-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Commit-boundary inventory” needed to preserve “Fault coverage refers to concrete mutation sites”; record an enforcement gap where only a model exists.
- [ ] **UC-M12.04-C002-T06 · Dependency connection:** Connect the “Commit-boundary inventory” qualification artifact to instrumented mutation boundaries, crash injection and cross-participant recovery oracles; record the target identity and what the harness actually exercises.
- [ ] **UC-M12.04-C002-T07 · Resource behavior:** Account for “Mutation sites and instrumented targets” in “Commit-boundary inventory”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M12.04-C002-T08 · Delivery check:** Run a known-valid control and a deliberately failing control for “Commit-boundary inventory”; confirm the harness distinguishes their observed outcomes.
- [ ] **UC-M12.04-C002-T09 · Patch review:** Review the “Commit-boundary inventory” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M12.04-C002-T10 · Delivery handoff:** Publish the “Commit-boundary inventory” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M12.04-C003 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Fault coverage refers to concrete mutation sites. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M12.04-C003-T01 · Named property:** Create a stable property/check name under this parent for “Commit-boundary inventory”; copy its required invariant exactly: “Fault coverage refers to concrete mutation sites”.
- [ ] **UC-M12.04-C003-T02 · Observable terms:** Define each term in the “Commit-boundary inventory” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M12.04-C003-T03 · Precondition set:** List the preconditions under which “Fault coverage refers to concrete mutation sites” must hold for “Commit-boundary inventory”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M12.04-C003-T04 · Transition coverage:** Map the “Commit-boundary inventory” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M12.04-C003-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Commit-boundary inventory”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M12.04-C003-T06 · Satisfying fixture:** Create a concrete “Commit-boundary inventory” case that satisfies “Fault coverage refers to concrete mutation sites”; record its expected observation before running the assertion or review.
- [ ] **UC-M12.04-C003-T07 · Violating fixture:** Create the source counterexample “A new seal publication step has no injection point” for “Commit-boundary inventory”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M12.04-C003-T08 · Enforcement evidence:** Exercise the “Commit-boundary inventory” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M12.04-C003-T09 · Regression linkage:** Link the “Commit-boundary inventory” property to changes in instrumented mutation boundaries, crash injection and cross-participant recovery oracles; record which dependency or contract changes require rerunning it.
- [ ] **UC-M12.04-C003-T10 · Property disposition:** Compare the satisfying and violating “Commit-boundary inventory” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M12.04-C004 · Integration

**Original checklist item:** Integrate commit-boundary inventory with instrumented mutation boundaries, crash injection and cross-participant recovery oracles; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M12.04-C004-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Commit-boundary inventory” across instrumented mutation boundaries, crash injection and cross-participant recovery oracles; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M12.04-C004-T02 · Field mapping:** Map every “Commit-boundary inventory” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M12.04-C004-T03 · Prerequisite identities:** Record the actual prerequisites for “Commit-boundary inventory” (source dependency list: UC-M07.01, UC-M07.05, UC-M07.08); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M12.04-C004-T04 · Ownership agreement:** Specify who owns “Commit-boundary inventory” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M12.04-C004-T05 · Handoff implementation:** Connect “Commit-boundary inventory” through the mapped seam using the real adapter or explicit specification reference; preserve “Fault coverage refers to concrete mutation sites” across the handoff.
- [ ] **UC-M12.04-C004-T06 · Absent-input case:** Omit one required “Commit-boundary inventory” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M12.04-C004-T07 · Stale-input case:** Supply an outdated “Commit-boundary inventory” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M12.04-C004-T08 · Incompatible-input case:** Supply an incompatible “Commit-boundary inventory” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M12.04-C004-T09 · Valid integration trace:** Run a valid “Commit-boundary inventory” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M12.04-C004-T10 · Seam review:** Reconcile the “Commit-boundary inventory” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M12.04-C005 · Valid-case test

**Original checklist item:** Run a known-valid control for commit-boundary inventory; verify that the harness reaches its intended target and compare observed measurements or verdicts with predeclared expectations.

- [ ] **UC-M12.04-C005-T01 · Valid fixture choice:** Choose a known-valid control for “Commit-boundary inventory”; document why it should pass and how it proves the harness reaches the intended target.
- [ ] **UC-M12.04-C005-T02 · Expected-result oracle:** Specify the “Commit-boundary inventory” expected result independently of the implementation output; include the property “Fault coverage refers to concrete mutation sites” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M12.04-C005-T03 · Fixture material:** Create the concrete “Commit-boundary inventory” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M12.04-C005-T04 · Target preparation:** Prepare the “Commit-boundary inventory” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M12.04-C005-T05 · Initial-state record:** Record the initial “Commit-boundary inventory” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M12.04-C005-T06 · Valid-path execution:** Run the “Commit-boundary inventory” known-valid control on the identified target; retain enough observations to prove the correct target was exercised.
- [ ] **UC-M12.04-C005-T07 · Outcome comparison:** Compare every declared “Commit-boundary inventory” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M12.04-C005-T08 · State and bounds check:** Inspect the “Commit-boundary inventory” ownership/state effects and actual use of “Mutation sites and instrumented targets”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M12.04-C005-T09 · Repeatability check:** Repeat the same “Commit-boundary inventory” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M12.04-C005-T10 · Positive evidence:** Attach the “Commit-boundary inventory” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M12.04-C006 · Negative test

**Original checklist item:** Negative case: A new seal publication step has no injection point. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M12.04-C006-T01 · Adverse-case definition:** Create a test record for the exact “Commit-boundary inventory” source counterexample: “A new seal publication step has no injection point”; state which precondition or invariant it challenges.
- [ ] **UC-M12.04-C006-T02 · Safe fixture boundary:** Define the contained test boundary for “Commit-boundary inventory”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M12.04-C006-T03 · Valid control:** Construct a valid “Commit-boundary inventory” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M12.04-C006-T04 · Minimal adverse input:** Derive the “Commit-boundary inventory” adverse fixture from the control with the smallest documented change needed to reproduce “A new seal publication step has no injection point”; retain that change as reproducible data.
- [ ] **UC-M12.04-C006-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Commit-boundary inventory”; require “Fault coverage refers to concrete mutation sites” and forbid a false-success verdict.
- [ ] **UC-M12.04-C006-T06 · Adverse execution:** Exercise the “Commit-boundary inventory” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M12.04-C006-T07 · Effect inspection:** Inspect “Commit-boundary inventory” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M12.04-C006-T08 · Refusal versus failure:** Confirm the “Commit-boundary inventory” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M12.04-C006-T09 · Reset and retention:** Restore only the disposable “Commit-boundary inventory” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M12.04-C006-T10 · Negative regression:** Register the “Commit-boundary inventory” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M12.04-C007 · Change / failure test

**Original checklist item:** Exercise commit-boundary inventory when the test process restarts after a partial write, ENOSPC or competing mutation; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M12.04-C007-T01 · Scenario record:** Write the “Commit-boundary inventory” change/failure scenario exactly as supplied: the test process restarts after a partial write, ENOSPC or competing mutation; identify the property that must remain true: “Fault coverage refers to concrete mutation sites”.
- [ ] **UC-M12.04-C007-T02 · Baseline capture:** Create a known-valid “Commit-boundary inventory” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M12.04-C007-T03 · Injection map:** Locate the “Commit-boundary inventory” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M12.04-C007-T04 · Disposition oracle:** Define the legal intermediate and final “Commit-boundary inventory” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M12.04-C007-T05 · Controlled trigger:** Introduce the controlled “Commit-boundary inventory” scenario in the disposable fixture: the test process restarts after a partial write, ENOSPC or competing mutation; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M12.04-C007-T06 · Intermediate inspection:** Inspect the “Commit-boundary inventory” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M12.04-C007-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Commit-boundary inventory”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M12.04-C007-T08 · Stale-evidence cleanup:** Invalidate superseded “Commit-boundary inventory” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M12.04-C007-T09 · Repeat and compare:** Repeat the selected “Commit-boundary inventory” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M12.04-C007-T10 · Failure evidence:** Publish the “Commit-boundary inventory” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M12.04-C008 · Bounds

**Original checklist item:** Set a documented campaign budget for mutation sites and instrumented targets; record actual consumption, incomplete coverage and the disposition when the budget is exhausted.

- [ ] **UC-M12.04-C008-T01 · Quantity inventory:** Create a measurement inventory for “Commit-boundary inventory”: “Mutation sites and instrumented targets”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M12.04-C008-T02 · Measurement method:** Choose how to observe each “Commit-boundary inventory” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M12.04-C008-T03 · Budget decision:** Select justified campaign and target-resource budgets for “Commit-boundary inventory”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M12.04-C008-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Commit-boundary inventory” cases for “Mutation sites and instrumented targets”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M12.04-C008-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Commit-boundary inventory” limit; preserve “Fault coverage refers to concrete mutation sites”.
- [ ] **UC-M12.04-C008-T06 · Normal measurement:** Run or review the normal “Commit-boundary inventory” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M12.04-C008-T07 · At-limit measurement:** Exercise the “Commit-boundary inventory” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M12.04-C008-T08 · Over-limit measurement:** Exercise the “Commit-boundary inventory” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M12.04-C008-T09 · Uncovered-scope report:** List the “Commit-boundary inventory” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M12.04-C008-T10 · Limit evidence:** Publish the selected “Commit-boundary inventory” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M12.04-C009 · Diagnostics / review

**Original checklist item:** Report commit-boundary inventory results with executed, failed, skipped and unavailable cases separated; preserve the underlying observations and do not manufacture missing measurements.

- [ ] **UC-M12.04-C009-T01 · Result inventory:** Enumerate the required “Commit-boundary inventory” qualification cases and intended targets before aggregating results; keep the planned denominator visible.
- [ ] **UC-M12.04-C009-T02 · Verdict schema:** Define separate executed-pass, executed-fail, skipped, unavailable and untested outcomes for “Commit-boundary inventory”; document how incomplete cases block relevant claims.
- [ ] **UC-M12.04-C009-T03 · Identity fields:** Attach the actual target, fixture, configuration and revision identifiers to each “Commit-boundary inventory” result; do not attribute host-only evidence to a guest or another OS.
- [ ] **UC-M12.04-C009-T04 · Observation capture:** Capture bounded raw “Commit-boundary inventory” observations and harness errors; retain enough information to verify the reported oracle comparison.
- [ ] **UC-M12.04-C009-T05 · Aggregation rules:** Implement the “Commit-boundary inventory” count/reduction rule so failures and missing measurements cannot disappear; preserve “Fault coverage refers to concrete mutation sites”.
- [ ] **UC-M12.04-C009-T06 · Failure visibility:** Feed a failing “Commit-boundary inventory” control through the report path; assert the exact failed case and underlying observation remain visible.
- [ ] **UC-M12.04-C009-T07 · Missing-result visibility:** Withhold a required “Commit-boundary inventory” measurement or target; verify the report uses unavailable/untested rather than a fabricated zero or passing value.
- [ ] **UC-M12.04-C009-T08 · Bounds and redaction:** Check “Commit-boundary inventory” report size and retention against “Mutation sites and instrumented targets”; remove secrets while retaining fixture and subject references.
- [ ] **UC-M12.04-C009-T09 · Report reconciliation:** Reconcile the “Commit-boundary inventory” summary with every underlying case record; account for the full planned denominator and all omitted scope.
- [ ] **UC-M12.04-C009-T10 · Qualification handoff:** Publish the “Commit-boundary inventory” report with measured observations, coverage limits and blockers; state which actual targets remain unqualified.

### UC-M12.04-C010 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for commit-boundary inventory; label unexecuted checks as untested.

- [ ] **UC-M12.04-C010-T01 · Evidence inventory:** List the “Commit-boundary inventory” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M12.04-C010-T02 · Artifact references:** Record the exact “Commit-boundary inventory” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M12.04-C010-T03 · Fixture references:** Attach the “Commit-boundary inventory” fixture IDs, input identities and oracle definition; preserve the source counterexample “A new seal publication step has no injection point” as a distinct evidence case.
- [ ] **UC-M12.04-C010-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Commit-boundary inventory”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M12.04-C010-T05 · Environment record:** Record the actual “Commit-boundary inventory” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M12.04-C010-T06 · Expected versus observed:** Pair every “Commit-boundary inventory” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M12.04-C010-T07 · Failure and limit records:** Attach “Commit-boundary inventory” change/failure and bounds evidence where required; include uncovered “Mutation sites and instrumented targets” and unresolved violations of “Fault coverage refers to concrete mutation sites”.
- [ ] **UC-M12.04-C010-T08 · Evidence hygiene:** Check the “Commit-boundary inventory” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M12.04-C010-T09 · Reproduction review:** Have the “Commit-boundary inventory” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M12.04-C010-T10 · Acceptance linkage:** Link the “Commit-boundary inventory” evidence to its parent and UC-M12.04 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 02. Process termination injection

**Source delivery:** Terminate responsible processes before and after selected durable steps.

**Source invariant:** Recovery handles abrupt termination rather than only graceful exceptions.

**Source negative case:** A worker is killed after publication but before acknowledgment.

**Source bounded quantities:** Injection sites and repeated trials.

### UC-M12.04-C011 · Contract

**Original checklist item:** Define the qualification objective for process termination injection, including the actual target implementation, prerequisites, observable oracle and explicit exclusions.

- [ ] **UC-M12.04-C011-T01 · Scope statement:** Write the qualification question for “Process termination injection”; identify the actual target, claimed capability and observations that can answer that question.
- [ ] **UC-M12.04-C011-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Process termination injection”; record each producer, representation and missing-value meaning.
- [ ] **UC-M12.04-C011-T03 · Output inventory:** List the outputs of “Process termination injection” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M12.04-C011-T04 · Field dictionary:** Create a field-and-term dictionary for “Process termination injection”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M12.04-C011-T05 · Prerequisite contract:** Map “Process termination injection” to the source component prerequisites (UC-M07.01, UC-M07.05, UC-M07.08); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M12.04-C011-T06 · Authority map:** Identify who may produce, change and consume “Process termination injection”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M12.04-C011-T07 · Invariant clause:** Add a normative clause for “Process termination injection” that preserves “Recovery handles abrupt termination rather than only graceful exceptions”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M12.04-C011-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Process termination injection”; include the source counterexample “A worker is killed after publication but before acknowledgment” and the intended safe disposition.
- [ ] **UC-M12.04-C011-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Injection sites and repeated trials” in the “Process termination injection” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M12.04-C011-T10 · Contract review:** Review the “Process termination injection” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M12.04-C012 · Delivery

**Original checklist item:** Terminate responsible processes before and after selected durable steps.

- [ ] **UC-M12.04-C012-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Process termination injection”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M12.04-C012-T02 · Change plan:** Break the source delivery for “Process termination injection” into concrete edit targets and reviewable outputs; keep the UC-M12.04 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M12.04-C012-T03 · Core artifact:** Implement the smallest selected-profile change for “Process termination injection” that realizes this source instruction: Terminate responsible processes before and after selected durable steps.
- [ ] **UC-M12.04-C012-T04 · Concrete realization:** Trace “Process termination injection” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M12.04-C012-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Process termination injection” needed to preserve “Recovery handles abrupt termination rather than only graceful exceptions”; record an enforcement gap where only a model exists.
- [ ] **UC-M12.04-C012-T06 · Dependency connection:** Connect the “Process termination injection” qualification artifact to instrumented mutation boundaries, crash injection and cross-participant recovery oracles; record the target identity and what the harness actually exercises.
- [ ] **UC-M12.04-C012-T07 · Resource behavior:** Account for “Injection sites and repeated trials” in “Process termination injection”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M12.04-C012-T08 · Delivery check:** Run a known-valid control and a deliberately failing control for “Process termination injection”; confirm the harness distinguishes their observed outcomes.
- [ ] **UC-M12.04-C012-T09 · Patch review:** Review the “Process termination injection” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M12.04-C012-T10 · Delivery handoff:** Publish the “Process termination injection” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M12.04-C013 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Recovery handles abrupt termination rather than only graceful exceptions. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M12.04-C013-T01 · Named property:** Create a stable property/check name under this parent for “Process termination injection”; copy its required invariant exactly: “Recovery handles abrupt termination rather than only graceful exceptions”.
- [ ] **UC-M12.04-C013-T02 · Observable terms:** Define each term in the “Process termination injection” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M12.04-C013-T03 · Precondition set:** List the preconditions under which “Recovery handles abrupt termination rather than only graceful exceptions” must hold for “Process termination injection”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M12.04-C013-T04 · Transition coverage:** Map the “Process termination injection” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M12.04-C013-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Process termination injection”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M12.04-C013-T06 · Satisfying fixture:** Create a concrete “Process termination injection” case that satisfies “Recovery handles abrupt termination rather than only graceful exceptions”; record its expected observation before running the assertion or review.
- [ ] **UC-M12.04-C013-T07 · Violating fixture:** Create the source counterexample “A worker is killed after publication but before acknowledgment” for “Process termination injection”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M12.04-C013-T08 · Enforcement evidence:** Exercise the “Process termination injection” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M12.04-C013-T09 · Regression linkage:** Link the “Process termination injection” property to changes in instrumented mutation boundaries, crash injection and cross-participant recovery oracles; record which dependency or contract changes require rerunning it.
- [ ] **UC-M12.04-C013-T10 · Property disposition:** Compare the satisfying and violating “Process termination injection” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M12.04-C014 · Integration

**Original checklist item:** Integrate process termination injection with instrumented mutation boundaries, crash injection and cross-participant recovery oracles; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M12.04-C014-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Process termination injection” across instrumented mutation boundaries, crash injection and cross-participant recovery oracles; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M12.04-C014-T02 · Field mapping:** Map every “Process termination injection” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M12.04-C014-T03 · Prerequisite identities:** Record the actual prerequisites for “Process termination injection” (source dependency list: UC-M07.01, UC-M07.05, UC-M07.08); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M12.04-C014-T04 · Ownership agreement:** Specify who owns “Process termination injection” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M12.04-C014-T05 · Handoff implementation:** Connect “Process termination injection” through the mapped seam using the real adapter or explicit specification reference; preserve “Recovery handles abrupt termination rather than only graceful exceptions” across the handoff.
- [ ] **UC-M12.04-C014-T06 · Absent-input case:** Omit one required “Process termination injection” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M12.04-C014-T07 · Stale-input case:** Supply an outdated “Process termination injection” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M12.04-C014-T08 · Incompatible-input case:** Supply an incompatible “Process termination injection” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M12.04-C014-T09 · Valid integration trace:** Run a valid “Process termination injection” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M12.04-C014-T10 · Seam review:** Reconcile the “Process termination injection” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M12.04-C015 · Valid-case test

**Original checklist item:** Run a known-valid control for process termination injection; verify that the harness reaches its intended target and compare observed measurements or verdicts with predeclared expectations.

- [ ] **UC-M12.04-C015-T01 · Valid fixture choice:** Choose a known-valid control for “Process termination injection”; document why it should pass and how it proves the harness reaches the intended target.
- [ ] **UC-M12.04-C015-T02 · Expected-result oracle:** Specify the “Process termination injection” expected result independently of the implementation output; include the property “Recovery handles abrupt termination rather than only graceful exceptions” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M12.04-C015-T03 · Fixture material:** Create the concrete “Process termination injection” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M12.04-C015-T04 · Target preparation:** Prepare the “Process termination injection” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M12.04-C015-T05 · Initial-state record:** Record the initial “Process termination injection” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M12.04-C015-T06 · Valid-path execution:** Run the “Process termination injection” known-valid control on the identified target; retain enough observations to prove the correct target was exercised.
- [ ] **UC-M12.04-C015-T07 · Outcome comparison:** Compare every declared “Process termination injection” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M12.04-C015-T08 · State and bounds check:** Inspect the “Process termination injection” ownership/state effects and actual use of “Injection sites and repeated trials”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M12.04-C015-T09 · Repeatability check:** Repeat the same “Process termination injection” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M12.04-C015-T10 · Positive evidence:** Attach the “Process termination injection” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M12.04-C016 · Negative test

**Original checklist item:** Negative case: A worker is killed after publication but before acknowledgment. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M12.04-C016-T01 · Adverse-case definition:** Create a test record for the exact “Process termination injection” source counterexample: “A worker is killed after publication but before acknowledgment”; state which precondition or invariant it challenges.
- [ ] **UC-M12.04-C016-T02 · Safe fixture boundary:** Define the contained test boundary for “Process termination injection”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M12.04-C016-T03 · Valid control:** Construct a valid “Process termination injection” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M12.04-C016-T04 · Minimal adverse input:** Derive the “Process termination injection” adverse fixture from the control with the smallest documented change needed to reproduce “A worker is killed after publication but before acknowledgment”; retain that change as reproducible data.
- [ ] **UC-M12.04-C016-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Process termination injection”; require “Recovery handles abrupt termination rather than only graceful exceptions” and forbid a false-success verdict.
- [ ] **UC-M12.04-C016-T06 · Adverse execution:** Exercise the “Process termination injection” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M12.04-C016-T07 · Effect inspection:** Inspect “Process termination injection” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M12.04-C016-T08 · Refusal versus failure:** Confirm the “Process termination injection” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M12.04-C016-T09 · Reset and retention:** Restore only the disposable “Process termination injection” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M12.04-C016-T10 · Negative regression:** Register the “Process termination injection” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M12.04-C017 · Change / failure test

**Original checklist item:** Exercise process termination injection when the test process restarts after a partial write, ENOSPC or competing mutation; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M12.04-C017-T01 · Scenario record:** Write the “Process termination injection” change/failure scenario exactly as supplied: the test process restarts after a partial write, ENOSPC or competing mutation; identify the property that must remain true: “Recovery handles abrupt termination rather than only graceful exceptions”.
- [ ] **UC-M12.04-C017-T02 · Baseline capture:** Create a known-valid “Process termination injection” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M12.04-C017-T03 · Injection map:** Locate the “Process termination injection” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M12.04-C017-T04 · Disposition oracle:** Define the legal intermediate and final “Process termination injection” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M12.04-C017-T05 · Controlled trigger:** Introduce the controlled “Process termination injection” scenario in the disposable fixture: the test process restarts after a partial write, ENOSPC or competing mutation; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M12.04-C017-T06 · Intermediate inspection:** Inspect the “Process termination injection” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M12.04-C017-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Process termination injection”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M12.04-C017-T08 · Stale-evidence cleanup:** Invalidate superseded “Process termination injection” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M12.04-C017-T09 · Repeat and compare:** Repeat the selected “Process termination injection” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M12.04-C017-T10 · Failure evidence:** Publish the “Process termination injection” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M12.04-C018 · Bounds

**Original checklist item:** Set a documented campaign budget for injection sites and repeated trials; record actual consumption, incomplete coverage and the disposition when the budget is exhausted.

- [ ] **UC-M12.04-C018-T01 · Quantity inventory:** Create a measurement inventory for “Process termination injection”: “Injection sites and repeated trials”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M12.04-C018-T02 · Measurement method:** Choose how to observe each “Process termination injection” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M12.04-C018-T03 · Budget decision:** Select justified campaign and target-resource budgets for “Process termination injection”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M12.04-C018-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Process termination injection” cases for “Injection sites and repeated trials”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M12.04-C018-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Process termination injection” limit; preserve “Recovery handles abrupt termination rather than only graceful exceptions”.
- [ ] **UC-M12.04-C018-T06 · Normal measurement:** Run or review the normal “Process termination injection” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M12.04-C018-T07 · At-limit measurement:** Exercise the “Process termination injection” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M12.04-C018-T08 · Over-limit measurement:** Exercise the “Process termination injection” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M12.04-C018-T09 · Uncovered-scope report:** List the “Process termination injection” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M12.04-C018-T10 · Limit evidence:** Publish the selected “Process termination injection” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M12.04-C019 · Diagnostics / review

**Original checklist item:** Report process termination injection results with executed, failed, skipped and unavailable cases separated; preserve the underlying observations and do not manufacture missing measurements.

- [ ] **UC-M12.04-C019-T01 · Result inventory:** Enumerate the required “Process termination injection” qualification cases and intended targets before aggregating results; keep the planned denominator visible.
- [ ] **UC-M12.04-C019-T02 · Verdict schema:** Define separate executed-pass, executed-fail, skipped, unavailable and untested outcomes for “Process termination injection”; document how incomplete cases block relevant claims.
- [ ] **UC-M12.04-C019-T03 · Identity fields:** Attach the actual target, fixture, configuration and revision identifiers to each “Process termination injection” result; do not attribute host-only evidence to a guest or another OS.
- [ ] **UC-M12.04-C019-T04 · Observation capture:** Capture bounded raw “Process termination injection” observations and harness errors; retain enough information to verify the reported oracle comparison.
- [ ] **UC-M12.04-C019-T05 · Aggregation rules:** Implement the “Process termination injection” count/reduction rule so failures and missing measurements cannot disappear; preserve “Recovery handles abrupt termination rather than only graceful exceptions”.
- [ ] **UC-M12.04-C019-T06 · Failure visibility:** Feed a failing “Process termination injection” control through the report path; assert the exact failed case and underlying observation remain visible.
- [ ] **UC-M12.04-C019-T07 · Missing-result visibility:** Withhold a required “Process termination injection” measurement or target; verify the report uses unavailable/untested rather than a fabricated zero or passing value.
- [ ] **UC-M12.04-C019-T08 · Bounds and redaction:** Check “Process termination injection” report size and retention against “Injection sites and repeated trials”; remove secrets while retaining fixture and subject references.
- [ ] **UC-M12.04-C019-T09 · Report reconciliation:** Reconcile the “Process termination injection” summary with every underlying case record; account for the full planned denominator and all omitted scope.
- [ ] **UC-M12.04-C019-T10 · Qualification handoff:** Publish the “Process termination injection” report with measured observations, coverage limits and blockers; state which actual targets remain unqualified.

### UC-M12.04-C020 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for process termination injection; label unexecuted checks as untested.

- [ ] **UC-M12.04-C020-T01 · Evidence inventory:** List the “Process termination injection” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M12.04-C020-T02 · Artifact references:** Record the exact “Process termination injection” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M12.04-C020-T03 · Fixture references:** Attach the “Process termination injection” fixture IDs, input identities and oracle definition; preserve the source counterexample “A worker is killed after publication but before acknowledgment” as a distinct evidence case.
- [ ] **UC-M12.04-C020-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Process termination injection”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M12.04-C020-T05 · Environment record:** Record the actual “Process termination injection” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M12.04-C020-T06 · Expected versus observed:** Pair every “Process termination injection” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M12.04-C020-T07 · Failure and limit records:** Attach “Process termination injection” change/failure and bounds evidence where required; include uncovered “Injection sites and repeated trials” and unresolved violations of “Recovery handles abrupt termination rather than only graceful exceptions”.
- [ ] **UC-M12.04-C020-T08 · Evidence hygiene:** Check the “Process termination injection” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M12.04-C020-T09 · Reproduction review:** Have the “Process termination injection” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M12.04-C020-T10 · Acceptance linkage:** Link the “Process termination injection” evidence to its parent and UC-M12.04 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 03. Partial-write injection

**Source delivery:** Simulate truncated writes and interrupted publication within controlled fixtures.

**Source invariant:** Partial bytes cannot become accepted complete state.

**Source negative case:** A final-looking manifest contains only its initial portion.

**Source bounded quantities:** Write sizes and interruption offsets.

### UC-M12.04-C021 · Contract

**Original checklist item:** Define the qualification objective for partial-write injection, including the actual target implementation, prerequisites, observable oracle and explicit exclusions.

- [ ] **UC-M12.04-C021-T01 · Scope statement:** Write the qualification question for “Partial-write injection”; identify the actual target, claimed capability and observations that can answer that question.
- [ ] **UC-M12.04-C021-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Partial-write injection”; record each producer, representation and missing-value meaning.
- [ ] **UC-M12.04-C021-T03 · Output inventory:** List the outputs of “Partial-write injection” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M12.04-C021-T04 · Field dictionary:** Create a field-and-term dictionary for “Partial-write injection”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M12.04-C021-T05 · Prerequisite contract:** Map “Partial-write injection” to the source component prerequisites (UC-M07.01, UC-M07.05, UC-M07.08); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M12.04-C021-T06 · Authority map:** Identify who may produce, change and consume “Partial-write injection”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M12.04-C021-T07 · Invariant clause:** Add a normative clause for “Partial-write injection” that preserves “Partial bytes cannot become accepted complete state”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M12.04-C021-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Partial-write injection”; include the source counterexample “A final-looking manifest contains only its initial portion” and the intended safe disposition.
- [ ] **UC-M12.04-C021-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Write sizes and interruption offsets” in the “Partial-write injection” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M12.04-C021-T10 · Contract review:** Review the “Partial-write injection” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M12.04-C022 · Delivery

**Original checklist item:** Simulate truncated writes and interrupted publication within controlled fixtures.

- [ ] **UC-M12.04-C022-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Partial-write injection”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M12.04-C022-T02 · Change plan:** Break the source delivery for “Partial-write injection” into concrete edit targets and reviewable outputs; keep the UC-M12.04 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M12.04-C022-T03 · Core artifact:** Create the “Partial-write injection” fixture or harness for this source instruction: Simulate truncated writes and interrupted publication within controlled fixtures.
- [ ] **UC-M12.04-C022-T04 · Concrete realization:** Connect the “Partial-write injection” harness to its actual intended target, set the expected oracle before running it, and distinguish a mock/control run from a target run.
- [ ] **UC-M12.04-C022-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Partial-write injection” needed to preserve “Partial bytes cannot become accepted complete state”; record an enforcement gap where only a model exists.
- [ ] **UC-M12.04-C022-T06 · Dependency connection:** Connect the “Partial-write injection” qualification artifact to instrumented mutation boundaries, crash injection and cross-participant recovery oracles; record the target identity and what the harness actually exercises.
- [ ] **UC-M12.04-C022-T07 · Resource behavior:** Account for “Write sizes and interruption offsets” in “Partial-write injection”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M12.04-C022-T08 · Delivery check:** Run a known-valid control and a deliberately failing control for “Partial-write injection”; confirm the harness distinguishes their observed outcomes.
- [ ] **UC-M12.04-C022-T09 · Patch review:** Review the “Partial-write injection” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M12.04-C022-T10 · Delivery handoff:** Publish the “Partial-write injection” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M12.04-C023 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Partial bytes cannot become accepted complete state. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M12.04-C023-T01 · Named property:** Create a stable property/check name under this parent for “Partial-write injection”; copy its required invariant exactly: “Partial bytes cannot become accepted complete state”.
- [ ] **UC-M12.04-C023-T02 · Observable terms:** Define each term in the “Partial-write injection” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M12.04-C023-T03 · Precondition set:** List the preconditions under which “Partial bytes cannot become accepted complete state” must hold for “Partial-write injection”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M12.04-C023-T04 · Transition coverage:** Map the “Partial-write injection” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M12.04-C023-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Partial-write injection”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M12.04-C023-T06 · Satisfying fixture:** Create a concrete “Partial-write injection” case that satisfies “Partial bytes cannot become accepted complete state”; record its expected observation before running the assertion or review.
- [ ] **UC-M12.04-C023-T07 · Violating fixture:** Create the source counterexample “A final-looking manifest contains only its initial portion” for “Partial-write injection”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M12.04-C023-T08 · Enforcement evidence:** Exercise the “Partial-write injection” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M12.04-C023-T09 · Regression linkage:** Link the “Partial-write injection” property to changes in instrumented mutation boundaries, crash injection and cross-participant recovery oracles; record which dependency or contract changes require rerunning it.
- [ ] **UC-M12.04-C023-T10 · Property disposition:** Compare the satisfying and violating “Partial-write injection” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M12.04-C024 · Integration

**Original checklist item:** Integrate partial-write injection with instrumented mutation boundaries, crash injection and cross-participant recovery oracles; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M12.04-C024-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Partial-write injection” across instrumented mutation boundaries, crash injection and cross-participant recovery oracles; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M12.04-C024-T02 · Field mapping:** Map every “Partial-write injection” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M12.04-C024-T03 · Prerequisite identities:** Record the actual prerequisites for “Partial-write injection” (source dependency list: UC-M07.01, UC-M07.05, UC-M07.08); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M12.04-C024-T04 · Ownership agreement:** Specify who owns “Partial-write injection” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M12.04-C024-T05 · Handoff implementation:** Connect “Partial-write injection” through the mapped seam using the real adapter or explicit specification reference; preserve “Partial bytes cannot become accepted complete state” across the handoff.
- [ ] **UC-M12.04-C024-T06 · Absent-input case:** Omit one required “Partial-write injection” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M12.04-C024-T07 · Stale-input case:** Supply an outdated “Partial-write injection” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M12.04-C024-T08 · Incompatible-input case:** Supply an incompatible “Partial-write injection” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M12.04-C024-T09 · Valid integration trace:** Run a valid “Partial-write injection” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M12.04-C024-T10 · Seam review:** Reconcile the “Partial-write injection” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M12.04-C025 · Valid-case test

**Original checklist item:** Run a known-valid control for partial-write injection; verify that the harness reaches its intended target and compare observed measurements or verdicts with predeclared expectations.

- [ ] **UC-M12.04-C025-T01 · Valid fixture choice:** Choose a known-valid control for “Partial-write injection”; document why it should pass and how it proves the harness reaches the intended target.
- [ ] **UC-M12.04-C025-T02 · Expected-result oracle:** Specify the “Partial-write injection” expected result independently of the implementation output; include the property “Partial bytes cannot become accepted complete state” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M12.04-C025-T03 · Fixture material:** Create the concrete “Partial-write injection” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M12.04-C025-T04 · Target preparation:** Prepare the “Partial-write injection” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M12.04-C025-T05 · Initial-state record:** Record the initial “Partial-write injection” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M12.04-C025-T06 · Valid-path execution:** Run the “Partial-write injection” known-valid control on the identified target; retain enough observations to prove the correct target was exercised.
- [ ] **UC-M12.04-C025-T07 · Outcome comparison:** Compare every declared “Partial-write injection” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M12.04-C025-T08 · State and bounds check:** Inspect the “Partial-write injection” ownership/state effects and actual use of “Write sizes and interruption offsets”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M12.04-C025-T09 · Repeatability check:** Repeat the same “Partial-write injection” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M12.04-C025-T10 · Positive evidence:** Attach the “Partial-write injection” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M12.04-C026 · Negative test

**Original checklist item:** Negative case: A final-looking manifest contains only its initial portion. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M12.04-C026-T01 · Adverse-case definition:** Create a test record for the exact “Partial-write injection” source counterexample: “A final-looking manifest contains only its initial portion”; state which precondition or invariant it challenges.
- [ ] **UC-M12.04-C026-T02 · Safe fixture boundary:** Define the contained test boundary for “Partial-write injection”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M12.04-C026-T03 · Valid control:** Construct a valid “Partial-write injection” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M12.04-C026-T04 · Minimal adverse input:** Derive the “Partial-write injection” adverse fixture from the control with the smallest documented change needed to reproduce “A final-looking manifest contains only its initial portion”; retain that change as reproducible data.
- [ ] **UC-M12.04-C026-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Partial-write injection”; require “Partial bytes cannot become accepted complete state” and forbid a false-success verdict.
- [ ] **UC-M12.04-C026-T06 · Adverse execution:** Exercise the “Partial-write injection” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M12.04-C026-T07 · Effect inspection:** Inspect “Partial-write injection” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M12.04-C026-T08 · Refusal versus failure:** Confirm the “Partial-write injection” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M12.04-C026-T09 · Reset and retention:** Restore only the disposable “Partial-write injection” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M12.04-C026-T10 · Negative regression:** Register the “Partial-write injection” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M12.04-C027 · Change / failure test

**Original checklist item:** Exercise partial-write injection when the test process restarts after a partial write, ENOSPC or competing mutation; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M12.04-C027-T01 · Scenario record:** Write the “Partial-write injection” change/failure scenario exactly as supplied: the test process restarts after a partial write, ENOSPC or competing mutation; identify the property that must remain true: “Partial bytes cannot become accepted complete state”.
- [ ] **UC-M12.04-C027-T02 · Baseline capture:** Create a known-valid “Partial-write injection” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M12.04-C027-T03 · Injection map:** Locate the “Partial-write injection” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M12.04-C027-T04 · Disposition oracle:** Define the legal intermediate and final “Partial-write injection” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M12.04-C027-T05 · Controlled trigger:** Introduce the controlled “Partial-write injection” scenario in the disposable fixture: the test process restarts after a partial write, ENOSPC or competing mutation; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M12.04-C027-T06 · Intermediate inspection:** Inspect the “Partial-write injection” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M12.04-C027-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Partial-write injection”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M12.04-C027-T08 · Stale-evidence cleanup:** Invalidate superseded “Partial-write injection” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M12.04-C027-T09 · Repeat and compare:** Repeat the selected “Partial-write injection” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M12.04-C027-T10 · Failure evidence:** Publish the “Partial-write injection” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M12.04-C028 · Bounds

**Original checklist item:** Set a documented campaign budget for write sizes and interruption offsets; record actual consumption, incomplete coverage and the disposition when the budget is exhausted.

- [ ] **UC-M12.04-C028-T01 · Quantity inventory:** Create a measurement inventory for “Partial-write injection”: “Write sizes and interruption offsets”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M12.04-C028-T02 · Measurement method:** Choose how to observe each “Partial-write injection” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M12.04-C028-T03 · Budget decision:** Select justified campaign and target-resource budgets for “Partial-write injection”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M12.04-C028-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Partial-write injection” cases for “Write sizes and interruption offsets”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M12.04-C028-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Partial-write injection” limit; preserve “Partial bytes cannot become accepted complete state”.
- [ ] **UC-M12.04-C028-T06 · Normal measurement:** Run or review the normal “Partial-write injection” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M12.04-C028-T07 · At-limit measurement:** Exercise the “Partial-write injection” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M12.04-C028-T08 · Over-limit measurement:** Exercise the “Partial-write injection” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M12.04-C028-T09 · Uncovered-scope report:** List the “Partial-write injection” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M12.04-C028-T10 · Limit evidence:** Publish the selected “Partial-write injection” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M12.04-C029 · Diagnostics / review

**Original checklist item:** Report partial-write injection results with executed, failed, skipped and unavailable cases separated; preserve the underlying observations and do not manufacture missing measurements.

- [ ] **UC-M12.04-C029-T01 · Result inventory:** Enumerate the required “Partial-write injection” qualification cases and intended targets before aggregating results; keep the planned denominator visible.
- [ ] **UC-M12.04-C029-T02 · Verdict schema:** Define separate executed-pass, executed-fail, skipped, unavailable and untested outcomes for “Partial-write injection”; document how incomplete cases block relevant claims.
- [ ] **UC-M12.04-C029-T03 · Identity fields:** Attach the actual target, fixture, configuration and revision identifiers to each “Partial-write injection” result; do not attribute host-only evidence to a guest or another OS.
- [ ] **UC-M12.04-C029-T04 · Observation capture:** Capture bounded raw “Partial-write injection” observations and harness errors; retain enough information to verify the reported oracle comparison.
- [ ] **UC-M12.04-C029-T05 · Aggregation rules:** Implement the “Partial-write injection” count/reduction rule so failures and missing measurements cannot disappear; preserve “Partial bytes cannot become accepted complete state”.
- [ ] **UC-M12.04-C029-T06 · Failure visibility:** Feed a failing “Partial-write injection” control through the report path; assert the exact failed case and underlying observation remain visible.
- [ ] **UC-M12.04-C029-T07 · Missing-result visibility:** Withhold a required “Partial-write injection” measurement or target; verify the report uses unavailable/untested rather than a fabricated zero or passing value.
- [ ] **UC-M12.04-C029-T08 · Bounds and redaction:** Check “Partial-write injection” report size and retention against “Write sizes and interruption offsets”; remove secrets while retaining fixture and subject references.
- [ ] **UC-M12.04-C029-T09 · Report reconciliation:** Reconcile the “Partial-write injection” summary with every underlying case record; account for the full planned denominator and all omitted scope.
- [ ] **UC-M12.04-C029-T10 · Qualification handoff:** Publish the “Partial-write injection” report with measured observations, coverage limits and blockers; state which actual targets remain unqualified.

### UC-M12.04-C030 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for partial-write injection; label unexecuted checks as untested.

- [ ] **UC-M12.04-C030-T01 · Evidence inventory:** List the “Partial-write injection” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M12.04-C030-T02 · Artifact references:** Record the exact “Partial-write injection” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M12.04-C030-T03 · Fixture references:** Attach the “Partial-write injection” fixture IDs, input identities and oracle definition; preserve the source counterexample “A final-looking manifest contains only its initial portion” as a distinct evidence case.
- [ ] **UC-M12.04-C030-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Partial-write injection”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M12.04-C030-T05 · Environment record:** Record the actual “Partial-write injection” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M12.04-C030-T06 · Expected versus observed:** Pair every “Partial-write injection” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M12.04-C030-T07 · Failure and limit records:** Attach “Partial-write injection” change/failure and bounds evidence where required; include uncovered “Write sizes and interruption offsets” and unresolved violations of “Partial bytes cannot become accepted complete state”.
- [ ] **UC-M12.04-C030-T08 · Evidence hygiene:** Check the “Partial-write injection” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M12.04-C030-T09 · Reproduction review:** Have the “Partial-write injection” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M12.04-C030-T10 · Acceptance linkage:** Link the “Partial-write injection” evidence to its parent and UC-M12.04 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 04. Disk-full injection

**Source delivery:** Inject ENOSPC during staging, commit, rollback and evidence writing.

**Source invariant:** Capacity failure preserves a usable documented recovery path.

**Source negative case:** Disk fills while the only backup is being overwritten.

**Source bounded quantities:** Storage budgets and failure locations.

### UC-M12.04-C031 · Contract

**Original checklist item:** Define the qualification objective for disk-full injection, including the actual target implementation, prerequisites, observable oracle and explicit exclusions.

- [ ] **UC-M12.04-C031-T01 · Scope statement:** Write the qualification question for “Disk-full injection”; identify the actual target, claimed capability and observations that can answer that question.
- [ ] **UC-M12.04-C031-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Disk-full injection”; record each producer, representation and missing-value meaning.
- [ ] **UC-M12.04-C031-T03 · Output inventory:** List the outputs of “Disk-full injection” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M12.04-C031-T04 · Field dictionary:** Create a field-and-term dictionary for “Disk-full injection”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M12.04-C031-T05 · Prerequisite contract:** Map “Disk-full injection” to the source component prerequisites (UC-M07.01, UC-M07.05, UC-M07.08); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M12.04-C031-T06 · Authority map:** Identify who may produce, change and consume “Disk-full injection”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M12.04-C031-T07 · Invariant clause:** Add a normative clause for “Disk-full injection” that preserves “Capacity failure preserves a usable documented recovery path”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M12.04-C031-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Disk-full injection”; include the source counterexample “Disk fills while the only backup is being overwritten” and the intended safe disposition.
- [ ] **UC-M12.04-C031-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Storage budgets and failure locations” in the “Disk-full injection” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M12.04-C031-T10 · Contract review:** Review the “Disk-full injection” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M12.04-C032 · Delivery

**Original checklist item:** Inject ENOSPC during staging, commit, rollback and evidence writing.

- [ ] **UC-M12.04-C032-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Disk-full injection”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M12.04-C032-T02 · Change plan:** Break the source delivery for “Disk-full injection” into concrete edit targets and reviewable outputs; keep the UC-M12.04 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M12.04-C032-T03 · Core artifact:** Create the “Disk-full injection” fixture or harness for this source instruction: Inject ENOSPC during staging, commit, rollback and evidence writing.
- [ ] **UC-M12.04-C032-T04 · Concrete realization:** Connect the “Disk-full injection” harness to its actual intended target, set the expected oracle before running it, and distinguish a mock/control run from a target run.
- [ ] **UC-M12.04-C032-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Disk-full injection” needed to preserve “Capacity failure preserves a usable documented recovery path”; record an enforcement gap where only a model exists.
- [ ] **UC-M12.04-C032-T06 · Dependency connection:** Connect the “Disk-full injection” qualification artifact to instrumented mutation boundaries, crash injection and cross-participant recovery oracles; record the target identity and what the harness actually exercises.
- [ ] **UC-M12.04-C032-T07 · Resource behavior:** Account for “Storage budgets and failure locations” in “Disk-full injection”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M12.04-C032-T08 · Delivery check:** Run a known-valid control and a deliberately failing control for “Disk-full injection”; confirm the harness distinguishes their observed outcomes.
- [ ] **UC-M12.04-C032-T09 · Patch review:** Review the “Disk-full injection” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M12.04-C032-T10 · Delivery handoff:** Publish the “Disk-full injection” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M12.04-C033 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Capacity failure preserves a usable documented recovery path. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M12.04-C033-T01 · Named property:** Create a stable property/check name under this parent for “Disk-full injection”; copy its required invariant exactly: “Capacity failure preserves a usable documented recovery path”.
- [ ] **UC-M12.04-C033-T02 · Observable terms:** Define each term in the “Disk-full injection” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M12.04-C033-T03 · Precondition set:** List the preconditions under which “Capacity failure preserves a usable documented recovery path” must hold for “Disk-full injection”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M12.04-C033-T04 · Transition coverage:** Map the “Disk-full injection” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M12.04-C033-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Disk-full injection”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M12.04-C033-T06 · Satisfying fixture:** Create a concrete “Disk-full injection” case that satisfies “Capacity failure preserves a usable documented recovery path”; record its expected observation before running the assertion or review.
- [ ] **UC-M12.04-C033-T07 · Violating fixture:** Create the source counterexample “Disk fills while the only backup is being overwritten” for “Disk-full injection”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M12.04-C033-T08 · Enforcement evidence:** Exercise the “Disk-full injection” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M12.04-C033-T09 · Regression linkage:** Link the “Disk-full injection” property to changes in instrumented mutation boundaries, crash injection and cross-participant recovery oracles; record which dependency or contract changes require rerunning it.
- [ ] **UC-M12.04-C033-T10 · Property disposition:** Compare the satisfying and violating “Disk-full injection” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M12.04-C034 · Integration

**Original checklist item:** Integrate disk-full injection with instrumented mutation boundaries, crash injection and cross-participant recovery oracles; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M12.04-C034-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Disk-full injection” across instrumented mutation boundaries, crash injection and cross-participant recovery oracles; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M12.04-C034-T02 · Field mapping:** Map every “Disk-full injection” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M12.04-C034-T03 · Prerequisite identities:** Record the actual prerequisites for “Disk-full injection” (source dependency list: UC-M07.01, UC-M07.05, UC-M07.08); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M12.04-C034-T04 · Ownership agreement:** Specify who owns “Disk-full injection” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M12.04-C034-T05 · Handoff implementation:** Connect “Disk-full injection” through the mapped seam using the real adapter or explicit specification reference; preserve “Capacity failure preserves a usable documented recovery path” across the handoff.
- [ ] **UC-M12.04-C034-T06 · Absent-input case:** Omit one required “Disk-full injection” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M12.04-C034-T07 · Stale-input case:** Supply an outdated “Disk-full injection” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M12.04-C034-T08 · Incompatible-input case:** Supply an incompatible “Disk-full injection” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M12.04-C034-T09 · Valid integration trace:** Run a valid “Disk-full injection” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M12.04-C034-T10 · Seam review:** Reconcile the “Disk-full injection” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M12.04-C035 · Valid-case test

**Original checklist item:** Run a known-valid control for disk-full injection; verify that the harness reaches its intended target and compare observed measurements or verdicts with predeclared expectations.

- [ ] **UC-M12.04-C035-T01 · Valid fixture choice:** Choose a known-valid control for “Disk-full injection”; document why it should pass and how it proves the harness reaches the intended target.
- [ ] **UC-M12.04-C035-T02 · Expected-result oracle:** Specify the “Disk-full injection” expected result independently of the implementation output; include the property “Capacity failure preserves a usable documented recovery path” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M12.04-C035-T03 · Fixture material:** Create the concrete “Disk-full injection” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M12.04-C035-T04 · Target preparation:** Prepare the “Disk-full injection” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M12.04-C035-T05 · Initial-state record:** Record the initial “Disk-full injection” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M12.04-C035-T06 · Valid-path execution:** Run the “Disk-full injection” known-valid control on the identified target; retain enough observations to prove the correct target was exercised.
- [ ] **UC-M12.04-C035-T07 · Outcome comparison:** Compare every declared “Disk-full injection” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M12.04-C035-T08 · State and bounds check:** Inspect the “Disk-full injection” ownership/state effects and actual use of “Storage budgets and failure locations”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M12.04-C035-T09 · Repeatability check:** Repeat the same “Disk-full injection” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M12.04-C035-T10 · Positive evidence:** Attach the “Disk-full injection” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M12.04-C036 · Negative test

**Original checklist item:** Negative case: Disk fills while the only backup is being overwritten. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M12.04-C036-T01 · Adverse-case definition:** Create a test record for the exact “Disk-full injection” source counterexample: “Disk fills while the only backup is being overwritten”; state which precondition or invariant it challenges.
- [ ] **UC-M12.04-C036-T02 · Safe fixture boundary:** Define the contained test boundary for “Disk-full injection”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M12.04-C036-T03 · Valid control:** Construct a valid “Disk-full injection” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M12.04-C036-T04 · Minimal adverse input:** Derive the “Disk-full injection” adverse fixture from the control with the smallest documented change needed to reproduce “Disk fills while the only backup is being overwritten”; retain that change as reproducible data.
- [ ] **UC-M12.04-C036-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Disk-full injection”; require “Capacity failure preserves a usable documented recovery path” and forbid a false-success verdict.
- [ ] **UC-M12.04-C036-T06 · Adverse execution:** Exercise the “Disk-full injection” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M12.04-C036-T07 · Effect inspection:** Inspect “Disk-full injection” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M12.04-C036-T08 · Refusal versus failure:** Confirm the “Disk-full injection” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M12.04-C036-T09 · Reset and retention:** Restore only the disposable “Disk-full injection” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M12.04-C036-T10 · Negative regression:** Register the “Disk-full injection” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M12.04-C037 · Change / failure test

**Original checklist item:** Exercise disk-full injection when the test process restarts after a partial write, ENOSPC or competing mutation; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M12.04-C037-T01 · Scenario record:** Write the “Disk-full injection” change/failure scenario exactly as supplied: the test process restarts after a partial write, ENOSPC or competing mutation; identify the property that must remain true: “Capacity failure preserves a usable documented recovery path”.
- [ ] **UC-M12.04-C037-T02 · Baseline capture:** Create a known-valid “Disk-full injection” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M12.04-C037-T03 · Injection map:** Locate the “Disk-full injection” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M12.04-C037-T04 · Disposition oracle:** Define the legal intermediate and final “Disk-full injection” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M12.04-C037-T05 · Controlled trigger:** Introduce the controlled “Disk-full injection” scenario in the disposable fixture: the test process restarts after a partial write, ENOSPC or competing mutation; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M12.04-C037-T06 · Intermediate inspection:** Inspect the “Disk-full injection” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M12.04-C037-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Disk-full injection”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M12.04-C037-T08 · Stale-evidence cleanup:** Invalidate superseded “Disk-full injection” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M12.04-C037-T09 · Repeat and compare:** Repeat the selected “Disk-full injection” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M12.04-C037-T10 · Failure evidence:** Publish the “Disk-full injection” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M12.04-C038 · Bounds

**Original checklist item:** Set a documented campaign budget for storage budgets and failure locations; record actual consumption, incomplete coverage and the disposition when the budget is exhausted.

- [ ] **UC-M12.04-C038-T01 · Quantity inventory:** Create a measurement inventory for “Disk-full injection”: “Storage budgets and failure locations”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M12.04-C038-T02 · Measurement method:** Choose how to observe each “Disk-full injection” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M12.04-C038-T03 · Budget decision:** Select justified campaign and target-resource budgets for “Disk-full injection”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M12.04-C038-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Disk-full injection” cases for “Storage budgets and failure locations”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M12.04-C038-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Disk-full injection” limit; preserve “Capacity failure preserves a usable documented recovery path”.
- [ ] **UC-M12.04-C038-T06 · Normal measurement:** Run or review the normal “Disk-full injection” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M12.04-C038-T07 · At-limit measurement:** Exercise the “Disk-full injection” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M12.04-C038-T08 · Over-limit measurement:** Exercise the “Disk-full injection” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M12.04-C038-T09 · Uncovered-scope report:** List the “Disk-full injection” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M12.04-C038-T10 · Limit evidence:** Publish the selected “Disk-full injection” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M12.04-C039 · Diagnostics / review

**Original checklist item:** Report disk-full injection results with executed, failed, skipped and unavailable cases separated; preserve the underlying observations and do not manufacture missing measurements.

- [ ] **UC-M12.04-C039-T01 · Result inventory:** Enumerate the required “Disk-full injection” qualification cases and intended targets before aggregating results; keep the planned denominator visible.
- [ ] **UC-M12.04-C039-T02 · Verdict schema:** Define separate executed-pass, executed-fail, skipped, unavailable and untested outcomes for “Disk-full injection”; document how incomplete cases block relevant claims.
- [ ] **UC-M12.04-C039-T03 · Identity fields:** Attach the actual target, fixture, configuration and revision identifiers to each “Disk-full injection” result; do not attribute host-only evidence to a guest or another OS.
- [ ] **UC-M12.04-C039-T04 · Observation capture:** Capture bounded raw “Disk-full injection” observations and harness errors; retain enough information to verify the reported oracle comparison.
- [ ] **UC-M12.04-C039-T05 · Aggregation rules:** Implement the “Disk-full injection” count/reduction rule so failures and missing measurements cannot disappear; preserve “Capacity failure preserves a usable documented recovery path”.
- [ ] **UC-M12.04-C039-T06 · Failure visibility:** Feed a failing “Disk-full injection” control through the report path; assert the exact failed case and underlying observation remain visible.
- [ ] **UC-M12.04-C039-T07 · Missing-result visibility:** Withhold a required “Disk-full injection” measurement or target; verify the report uses unavailable/untested rather than a fabricated zero or passing value.
- [ ] **UC-M12.04-C039-T08 · Bounds and redaction:** Check “Disk-full injection” report size and retention against “Storage budgets and failure locations”; remove secrets while retaining fixture and subject references.
- [ ] **UC-M12.04-C039-T09 · Report reconciliation:** Reconcile the “Disk-full injection” summary with every underlying case record; account for the full planned denominator and all omitted scope.
- [ ] **UC-M12.04-C039-T10 · Qualification handoff:** Publish the “Disk-full injection” report with measured observations, coverage limits and blockers; state which actual targets remain unqualified.

### UC-M12.04-C040 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for disk-full injection; label unexecuted checks as untested.

- [ ] **UC-M12.04-C040-T01 · Evidence inventory:** List the “Disk-full injection” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M12.04-C040-T02 · Artifact references:** Record the exact “Disk-full injection” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M12.04-C040-T03 · Fixture references:** Attach the “Disk-full injection” fixture IDs, input identities and oracle definition; preserve the source counterexample “Disk fills while the only backup is being overwritten” as a distinct evidence case.
- [ ] **UC-M12.04-C040-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Disk-full injection”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M12.04-C040-T05 · Environment record:** Record the actual “Disk-full injection” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M12.04-C040-T06 · Expected versus observed:** Pair every “Disk-full injection” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M12.04-C040-T07 · Failure and limit records:** Attach “Disk-full injection” change/failure and bounds evidence where required; include uncovered “Storage budgets and failure locations” and unresolved violations of “Capacity failure preserves a usable documented recovery path”.
- [ ] **UC-M12.04-C040-T08 · Evidence hygiene:** Check the “Disk-full injection” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M12.04-C040-T09 · Reproduction review:** Have the “Disk-full injection” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M12.04-C040-T10 · Acceptance linkage:** Link the “Disk-full injection” evidence to its parent and UC-M12.04 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 05. Permission-change injection

**Source delivery:** Change relevant permissions during declared operations in disposable workspaces.

**Source invariant:** Permission failure leaves an explicit recoverable disposition.

**Source negative case:** A directory becomes unwritable between validation and commit.

**Source bounded quantities:** Permission variants and test roots.

### UC-M12.04-C041 · Contract

**Original checklist item:** Define the qualification objective for permission-change injection, including the actual target implementation, prerequisites, observable oracle and explicit exclusions.

- [ ] **UC-M12.04-C041-T01 · Scope statement:** Write the qualification question for “Permission-change injection”; identify the actual target, claimed capability and observations that can answer that question.
- [ ] **UC-M12.04-C041-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Permission-change injection”; record each producer, representation and missing-value meaning.
- [ ] **UC-M12.04-C041-T03 · Output inventory:** List the outputs of “Permission-change injection” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M12.04-C041-T04 · Field dictionary:** Create a field-and-term dictionary for “Permission-change injection”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M12.04-C041-T05 · Prerequisite contract:** Map “Permission-change injection” to the source component prerequisites (UC-M07.01, UC-M07.05, UC-M07.08); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M12.04-C041-T06 · Authority map:** Identify who may produce, change and consume “Permission-change injection”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M12.04-C041-T07 · Invariant clause:** Add a normative clause for “Permission-change injection” that preserves “Permission failure leaves an explicit recoverable disposition”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M12.04-C041-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Permission-change injection”; include the source counterexample “A directory becomes unwritable between validation and commit” and the intended safe disposition.
- [ ] **UC-M12.04-C041-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Permission variants and test roots” in the “Permission-change injection” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M12.04-C041-T10 · Contract review:** Review the “Permission-change injection” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M12.04-C042 · Delivery

**Original checklist item:** Change relevant permissions during declared operations in disposable workspaces.

- [ ] **UC-M12.04-C042-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Permission-change injection”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M12.04-C042-T02 · Change plan:** Break the source delivery for “Permission-change injection” into concrete edit targets and reviewable outputs; keep the UC-M12.04 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M12.04-C042-T03 · Core artifact:** Implement the smallest selected-profile change for “Permission-change injection” that realizes this source instruction: Change relevant permissions during declared operations in disposable workspaces.
- [ ] **UC-M12.04-C042-T04 · Concrete realization:** Trace “Permission-change injection” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M12.04-C042-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Permission-change injection” needed to preserve “Permission failure leaves an explicit recoverable disposition”; record an enforcement gap where only a model exists.
- [ ] **UC-M12.04-C042-T06 · Dependency connection:** Connect the “Permission-change injection” qualification artifact to instrumented mutation boundaries, crash injection and cross-participant recovery oracles; record the target identity and what the harness actually exercises.
- [ ] **UC-M12.04-C042-T07 · Resource behavior:** Account for “Permission variants and test roots” in “Permission-change injection”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M12.04-C042-T08 · Delivery check:** Run a known-valid control and a deliberately failing control for “Permission-change injection”; confirm the harness distinguishes their observed outcomes.
- [ ] **UC-M12.04-C042-T09 · Patch review:** Review the “Permission-change injection” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M12.04-C042-T10 · Delivery handoff:** Publish the “Permission-change injection” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M12.04-C043 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Permission failure leaves an explicit recoverable disposition. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M12.04-C043-T01 · Named property:** Create a stable property/check name under this parent for “Permission-change injection”; copy its required invariant exactly: “Permission failure leaves an explicit recoverable disposition”.
- [ ] **UC-M12.04-C043-T02 · Observable terms:** Define each term in the “Permission-change injection” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M12.04-C043-T03 · Precondition set:** List the preconditions under which “Permission failure leaves an explicit recoverable disposition” must hold for “Permission-change injection”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M12.04-C043-T04 · Transition coverage:** Map the “Permission-change injection” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M12.04-C043-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Permission-change injection”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M12.04-C043-T06 · Satisfying fixture:** Create a concrete “Permission-change injection” case that satisfies “Permission failure leaves an explicit recoverable disposition”; record its expected observation before running the assertion or review.
- [ ] **UC-M12.04-C043-T07 · Violating fixture:** Create the source counterexample “A directory becomes unwritable between validation and commit” for “Permission-change injection”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M12.04-C043-T08 · Enforcement evidence:** Exercise the “Permission-change injection” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M12.04-C043-T09 · Regression linkage:** Link the “Permission-change injection” property to changes in instrumented mutation boundaries, crash injection and cross-participant recovery oracles; record which dependency or contract changes require rerunning it.
- [ ] **UC-M12.04-C043-T10 · Property disposition:** Compare the satisfying and violating “Permission-change injection” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M12.04-C044 · Integration

**Original checklist item:** Integrate permission-change injection with instrumented mutation boundaries, crash injection and cross-participant recovery oracles; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M12.04-C044-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Permission-change injection” across instrumented mutation boundaries, crash injection and cross-participant recovery oracles; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M12.04-C044-T02 · Field mapping:** Map every “Permission-change injection” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M12.04-C044-T03 · Prerequisite identities:** Record the actual prerequisites for “Permission-change injection” (source dependency list: UC-M07.01, UC-M07.05, UC-M07.08); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M12.04-C044-T04 · Ownership agreement:** Specify who owns “Permission-change injection” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M12.04-C044-T05 · Handoff implementation:** Connect “Permission-change injection” through the mapped seam using the real adapter or explicit specification reference; preserve “Permission failure leaves an explicit recoverable disposition” across the handoff.
- [ ] **UC-M12.04-C044-T06 · Absent-input case:** Omit one required “Permission-change injection” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M12.04-C044-T07 · Stale-input case:** Supply an outdated “Permission-change injection” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M12.04-C044-T08 · Incompatible-input case:** Supply an incompatible “Permission-change injection” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M12.04-C044-T09 · Valid integration trace:** Run a valid “Permission-change injection” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M12.04-C044-T10 · Seam review:** Reconcile the “Permission-change injection” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M12.04-C045 · Valid-case test

**Original checklist item:** Run a known-valid control for permission-change injection; verify that the harness reaches its intended target and compare observed measurements or verdicts with predeclared expectations.

- [ ] **UC-M12.04-C045-T01 · Valid fixture choice:** Choose a known-valid control for “Permission-change injection”; document why it should pass and how it proves the harness reaches the intended target.
- [ ] **UC-M12.04-C045-T02 · Expected-result oracle:** Specify the “Permission-change injection” expected result independently of the implementation output; include the property “Permission failure leaves an explicit recoverable disposition” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M12.04-C045-T03 · Fixture material:** Create the concrete “Permission-change injection” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M12.04-C045-T04 · Target preparation:** Prepare the “Permission-change injection” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M12.04-C045-T05 · Initial-state record:** Record the initial “Permission-change injection” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M12.04-C045-T06 · Valid-path execution:** Run the “Permission-change injection” known-valid control on the identified target; retain enough observations to prove the correct target was exercised.
- [ ] **UC-M12.04-C045-T07 · Outcome comparison:** Compare every declared “Permission-change injection” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M12.04-C045-T08 · State and bounds check:** Inspect the “Permission-change injection” ownership/state effects and actual use of “Permission variants and test roots”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M12.04-C045-T09 · Repeatability check:** Repeat the same “Permission-change injection” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M12.04-C045-T10 · Positive evidence:** Attach the “Permission-change injection” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M12.04-C046 · Negative test

**Original checklist item:** Negative case: A directory becomes unwritable between validation and commit. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M12.04-C046-T01 · Adverse-case definition:** Create a test record for the exact “Permission-change injection” source counterexample: “A directory becomes unwritable between validation and commit”; state which precondition or invariant it challenges.
- [ ] **UC-M12.04-C046-T02 · Safe fixture boundary:** Define the contained test boundary for “Permission-change injection”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M12.04-C046-T03 · Valid control:** Construct a valid “Permission-change injection” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M12.04-C046-T04 · Minimal adverse input:** Derive the “Permission-change injection” adverse fixture from the control with the smallest documented change needed to reproduce “A directory becomes unwritable between validation and commit”; retain that change as reproducible data.
- [ ] **UC-M12.04-C046-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Permission-change injection”; require “Permission failure leaves an explicit recoverable disposition” and forbid a false-success verdict.
- [ ] **UC-M12.04-C046-T06 · Adverse execution:** Exercise the “Permission-change injection” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M12.04-C046-T07 · Effect inspection:** Inspect “Permission-change injection” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M12.04-C046-T08 · Refusal versus failure:** Confirm the “Permission-change injection” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M12.04-C046-T09 · Reset and retention:** Restore only the disposable “Permission-change injection” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M12.04-C046-T10 · Negative regression:** Register the “Permission-change injection” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M12.04-C047 · Change / failure test

**Original checklist item:** Exercise permission-change injection when the test process restarts after a partial write, ENOSPC or competing mutation; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M12.04-C047-T01 · Scenario record:** Write the “Permission-change injection” change/failure scenario exactly as supplied: the test process restarts after a partial write, ENOSPC or competing mutation; identify the property that must remain true: “Permission failure leaves an explicit recoverable disposition”.
- [ ] **UC-M12.04-C047-T02 · Baseline capture:** Create a known-valid “Permission-change injection” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M12.04-C047-T03 · Injection map:** Locate the “Permission-change injection” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M12.04-C047-T04 · Disposition oracle:** Define the legal intermediate and final “Permission-change injection” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M12.04-C047-T05 · Controlled trigger:** Introduce the controlled “Permission-change injection” scenario in the disposable fixture: the test process restarts after a partial write, ENOSPC or competing mutation; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M12.04-C047-T06 · Intermediate inspection:** Inspect the “Permission-change injection” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M12.04-C047-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Permission-change injection”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M12.04-C047-T08 · Stale-evidence cleanup:** Invalidate superseded “Permission-change injection” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M12.04-C047-T09 · Repeat and compare:** Repeat the selected “Permission-change injection” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M12.04-C047-T10 · Failure evidence:** Publish the “Permission-change injection” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M12.04-C048 · Bounds

**Original checklist item:** Set a documented campaign budget for permission variants and test roots; record actual consumption, incomplete coverage and the disposition when the budget is exhausted.

- [ ] **UC-M12.04-C048-T01 · Quantity inventory:** Create a measurement inventory for “Permission-change injection”: “Permission variants and test roots”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M12.04-C048-T02 · Measurement method:** Choose how to observe each “Permission-change injection” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M12.04-C048-T03 · Budget decision:** Select justified campaign and target-resource budgets for “Permission-change injection”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M12.04-C048-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Permission-change injection” cases for “Permission variants and test roots”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M12.04-C048-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Permission-change injection” limit; preserve “Permission failure leaves an explicit recoverable disposition”.
- [ ] **UC-M12.04-C048-T06 · Normal measurement:** Run or review the normal “Permission-change injection” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M12.04-C048-T07 · At-limit measurement:** Exercise the “Permission-change injection” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M12.04-C048-T08 · Over-limit measurement:** Exercise the “Permission-change injection” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M12.04-C048-T09 · Uncovered-scope report:** List the “Permission-change injection” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M12.04-C048-T10 · Limit evidence:** Publish the selected “Permission-change injection” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M12.04-C049 · Diagnostics / review

**Original checklist item:** Report permission-change injection results with executed, failed, skipped and unavailable cases separated; preserve the underlying observations and do not manufacture missing measurements.

- [ ] **UC-M12.04-C049-T01 · Result inventory:** Enumerate the required “Permission-change injection” qualification cases and intended targets before aggregating results; keep the planned denominator visible.
- [ ] **UC-M12.04-C049-T02 · Verdict schema:** Define separate executed-pass, executed-fail, skipped, unavailable and untested outcomes for “Permission-change injection”; document how incomplete cases block relevant claims.
- [ ] **UC-M12.04-C049-T03 · Identity fields:** Attach the actual target, fixture, configuration and revision identifiers to each “Permission-change injection” result; do not attribute host-only evidence to a guest or another OS.
- [ ] **UC-M12.04-C049-T04 · Observation capture:** Capture bounded raw “Permission-change injection” observations and harness errors; retain enough information to verify the reported oracle comparison.
- [ ] **UC-M12.04-C049-T05 · Aggregation rules:** Implement the “Permission-change injection” count/reduction rule so failures and missing measurements cannot disappear; preserve “Permission failure leaves an explicit recoverable disposition”.
- [ ] **UC-M12.04-C049-T06 · Failure visibility:** Feed a failing “Permission-change injection” control through the report path; assert the exact failed case and underlying observation remain visible.
- [ ] **UC-M12.04-C049-T07 · Missing-result visibility:** Withhold a required “Permission-change injection” measurement or target; verify the report uses unavailable/untested rather than a fabricated zero or passing value.
- [ ] **UC-M12.04-C049-T08 · Bounds and redaction:** Check “Permission-change injection” report size and retention against “Permission variants and test roots”; remove secrets while retaining fixture and subject references.
- [ ] **UC-M12.04-C049-T09 · Report reconciliation:** Reconcile the “Permission-change injection” summary with every underlying case record; account for the full planned denominator and all omitted scope.
- [ ] **UC-M12.04-C049-T10 · Qualification handoff:** Publish the “Permission-change injection” report with measured observations, coverage limits and blockers; state which actual targets remain unqualified.

### UC-M12.04-C050 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for permission-change injection; label unexecuted checks as untested.

- [ ] **UC-M12.04-C050-T01 · Evidence inventory:** List the “Permission-change injection” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M12.04-C050-T02 · Artifact references:** Record the exact “Permission-change injection” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M12.04-C050-T03 · Fixture references:** Attach the “Permission-change injection” fixture IDs, input identities and oracle definition; preserve the source counterexample “A directory becomes unwritable between validation and commit” as a distinct evidence case.
- [ ] **UC-M12.04-C050-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Permission-change injection”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M12.04-C050-T05 · Environment record:** Record the actual “Permission-change injection” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M12.04-C050-T06 · Expected versus observed:** Pair every “Permission-change injection” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M12.04-C050-T07 · Failure and limit records:** Attach “Permission-change injection” change/failure and bounds evidence where required; include uncovered “Permission variants and test roots” and unresolved violations of “Permission failure leaves an explicit recoverable disposition”.
- [ ] **UC-M12.04-C050-T08 · Evidence hygiene:** Check the “Permission-change injection” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M12.04-C050-T09 · Reproduction review:** Have the “Permission-change injection” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M12.04-C050-T10 · Acceptance linkage:** Link the “Permission-change injection” evidence to its parent and UC-M12.04 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 06. Concurrent operator injection

**Source delivery:** Race supported load, replace, stop, seal and restore requests.

**Source invariant:** Competing operators cannot produce incoherent committed authority.

**Source negative case:** Replace and restore publish different generations concurrently.

**Source bounded quantities:** Concurrent actors and interleavings.

### UC-M12.04-C051 · Contract

**Original checklist item:** Define the qualification objective for concurrent operator injection, including the actual target implementation, prerequisites, observable oracle and explicit exclusions.

- [ ] **UC-M12.04-C051-T01 · Scope statement:** Write the qualification question for “Concurrent operator injection”; identify the actual target, claimed capability and observations that can answer that question.
- [ ] **UC-M12.04-C051-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Concurrent operator injection”; record each producer, representation and missing-value meaning.
- [ ] **UC-M12.04-C051-T03 · Output inventory:** List the outputs of “Concurrent operator injection” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M12.04-C051-T04 · Field dictionary:** Create a field-and-term dictionary for “Concurrent operator injection”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M12.04-C051-T05 · Prerequisite contract:** Map “Concurrent operator injection” to the source component prerequisites (UC-M07.01, UC-M07.05, UC-M07.08); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M12.04-C051-T06 · Authority map:** Identify who may produce, change and consume “Concurrent operator injection”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M12.04-C051-T07 · Invariant clause:** Add a normative clause for “Concurrent operator injection” that preserves “Competing operators cannot produce incoherent committed authority”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M12.04-C051-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Concurrent operator injection”; include the source counterexample “Replace and restore publish different generations concurrently” and the intended safe disposition.
- [ ] **UC-M12.04-C051-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Concurrent actors and interleavings” in the “Concurrent operator injection” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M12.04-C051-T10 · Contract review:** Review the “Concurrent operator injection” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M12.04-C052 · Delivery

**Original checklist item:** Race supported load, replace, stop, seal and restore requests.

- [ ] **UC-M12.04-C052-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Concurrent operator injection”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M12.04-C052-T02 · Change plan:** Break the source delivery for “Concurrent operator injection” into concrete edit targets and reviewable outputs; keep the UC-M12.04 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M12.04-C052-T03 · Core artifact:** Create the “Concurrent operator injection” fixture or harness for this source instruction: Race supported load, replace, stop, seal and restore requests.
- [ ] **UC-M12.04-C052-T04 · Concrete realization:** Connect the “Concurrent operator injection” harness to its actual intended target, set the expected oracle before running it, and distinguish a mock/control run from a target run.
- [ ] **UC-M12.04-C052-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Concurrent operator injection” needed to preserve “Competing operators cannot produce incoherent committed authority”; record an enforcement gap where only a model exists.
- [ ] **UC-M12.04-C052-T06 · Dependency connection:** Connect the “Concurrent operator injection” qualification artifact to instrumented mutation boundaries, crash injection and cross-participant recovery oracles; record the target identity and what the harness actually exercises.
- [ ] **UC-M12.04-C052-T07 · Resource behavior:** Account for “Concurrent actors and interleavings” in “Concurrent operator injection”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M12.04-C052-T08 · Delivery check:** Run a known-valid control and a deliberately failing control for “Concurrent operator injection”; confirm the harness distinguishes their observed outcomes.
- [ ] **UC-M12.04-C052-T09 · Patch review:** Review the “Concurrent operator injection” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M12.04-C052-T10 · Delivery handoff:** Publish the “Concurrent operator injection” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M12.04-C053 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Competing operators cannot produce incoherent committed authority. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M12.04-C053-T01 · Named property:** Create a stable property/check name under this parent for “Concurrent operator injection”; copy its required invariant exactly: “Competing operators cannot produce incoherent committed authority”.
- [ ] **UC-M12.04-C053-T02 · Observable terms:** Define each term in the “Concurrent operator injection” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M12.04-C053-T03 · Precondition set:** List the preconditions under which “Competing operators cannot produce incoherent committed authority” must hold for “Concurrent operator injection”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M12.04-C053-T04 · Transition coverage:** Map the “Concurrent operator injection” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M12.04-C053-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Concurrent operator injection”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M12.04-C053-T06 · Satisfying fixture:** Create a concrete “Concurrent operator injection” case that satisfies “Competing operators cannot produce incoherent committed authority”; record its expected observation before running the assertion or review.
- [ ] **UC-M12.04-C053-T07 · Violating fixture:** Create the source counterexample “Replace and restore publish different generations concurrently” for “Concurrent operator injection”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M12.04-C053-T08 · Enforcement evidence:** Exercise the “Concurrent operator injection” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M12.04-C053-T09 · Regression linkage:** Link the “Concurrent operator injection” property to changes in instrumented mutation boundaries, crash injection and cross-participant recovery oracles; record which dependency or contract changes require rerunning it.
- [ ] **UC-M12.04-C053-T10 · Property disposition:** Compare the satisfying and violating “Concurrent operator injection” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M12.04-C054 · Integration

**Original checklist item:** Integrate concurrent operator injection with instrumented mutation boundaries, crash injection and cross-participant recovery oracles; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M12.04-C054-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Concurrent operator injection” across instrumented mutation boundaries, crash injection and cross-participant recovery oracles; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M12.04-C054-T02 · Field mapping:** Map every “Concurrent operator injection” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M12.04-C054-T03 · Prerequisite identities:** Record the actual prerequisites for “Concurrent operator injection” (source dependency list: UC-M07.01, UC-M07.05, UC-M07.08); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M12.04-C054-T04 · Ownership agreement:** Specify who owns “Concurrent operator injection” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M12.04-C054-T05 · Handoff implementation:** Connect “Concurrent operator injection” through the mapped seam using the real adapter or explicit specification reference; preserve “Competing operators cannot produce incoherent committed authority” across the handoff.
- [ ] **UC-M12.04-C054-T06 · Absent-input case:** Omit one required “Concurrent operator injection” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M12.04-C054-T07 · Stale-input case:** Supply an outdated “Concurrent operator injection” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M12.04-C054-T08 · Incompatible-input case:** Supply an incompatible “Concurrent operator injection” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M12.04-C054-T09 · Valid integration trace:** Run a valid “Concurrent operator injection” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M12.04-C054-T10 · Seam review:** Reconcile the “Concurrent operator injection” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M12.04-C055 · Valid-case test

**Original checklist item:** Run a known-valid control for concurrent operator injection; verify that the harness reaches its intended target and compare observed measurements or verdicts with predeclared expectations.

- [ ] **UC-M12.04-C055-T01 · Valid fixture choice:** Choose a known-valid control for “Concurrent operator injection”; document why it should pass and how it proves the harness reaches the intended target.
- [ ] **UC-M12.04-C055-T02 · Expected-result oracle:** Specify the “Concurrent operator injection” expected result independently of the implementation output; include the property “Competing operators cannot produce incoherent committed authority” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M12.04-C055-T03 · Fixture material:** Create the concrete “Concurrent operator injection” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M12.04-C055-T04 · Target preparation:** Prepare the “Concurrent operator injection” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M12.04-C055-T05 · Initial-state record:** Record the initial “Concurrent operator injection” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M12.04-C055-T06 · Valid-path execution:** Run the “Concurrent operator injection” known-valid control on the identified target; retain enough observations to prove the correct target was exercised.
- [ ] **UC-M12.04-C055-T07 · Outcome comparison:** Compare every declared “Concurrent operator injection” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M12.04-C055-T08 · State and bounds check:** Inspect the “Concurrent operator injection” ownership/state effects and actual use of “Concurrent actors and interleavings”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M12.04-C055-T09 · Repeatability check:** Repeat the same “Concurrent operator injection” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M12.04-C055-T10 · Positive evidence:** Attach the “Concurrent operator injection” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M12.04-C056 · Negative test

**Original checklist item:** Negative case: Replace and restore publish different generations concurrently. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M12.04-C056-T01 · Adverse-case definition:** Create a test record for the exact “Concurrent operator injection” source counterexample: “Replace and restore publish different generations concurrently”; state which precondition or invariant it challenges.
- [ ] **UC-M12.04-C056-T02 · Safe fixture boundary:** Define the contained test boundary for “Concurrent operator injection”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M12.04-C056-T03 · Valid control:** Construct a valid “Concurrent operator injection” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M12.04-C056-T04 · Minimal adverse input:** Derive the “Concurrent operator injection” adverse fixture from the control with the smallest documented change needed to reproduce “Replace and restore publish different generations concurrently”; retain that change as reproducible data.
- [ ] **UC-M12.04-C056-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Concurrent operator injection”; require “Competing operators cannot produce incoherent committed authority” and forbid a false-success verdict.
- [ ] **UC-M12.04-C056-T06 · Adverse execution:** Exercise the “Concurrent operator injection” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M12.04-C056-T07 · Effect inspection:** Inspect “Concurrent operator injection” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M12.04-C056-T08 · Refusal versus failure:** Confirm the “Concurrent operator injection” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M12.04-C056-T09 · Reset and retention:** Restore only the disposable “Concurrent operator injection” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M12.04-C056-T10 · Negative regression:** Register the “Concurrent operator injection” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M12.04-C057 · Change / failure test

**Original checklist item:** Exercise concurrent operator injection when the test process restarts after a partial write, ENOSPC or competing mutation; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M12.04-C057-T01 · Scenario record:** Write the “Concurrent operator injection” change/failure scenario exactly as supplied: the test process restarts after a partial write, ENOSPC or competing mutation; identify the property that must remain true: “Competing operators cannot produce incoherent committed authority”.
- [ ] **UC-M12.04-C057-T02 · Baseline capture:** Create a known-valid “Concurrent operator injection” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M12.04-C057-T03 · Injection map:** Locate the “Concurrent operator injection” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M12.04-C057-T04 · Disposition oracle:** Define the legal intermediate and final “Concurrent operator injection” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M12.04-C057-T05 · Controlled trigger:** Introduce the controlled “Concurrent operator injection” scenario in the disposable fixture: the test process restarts after a partial write, ENOSPC or competing mutation; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M12.04-C057-T06 · Intermediate inspection:** Inspect the “Concurrent operator injection” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M12.04-C057-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Concurrent operator injection”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M12.04-C057-T08 · Stale-evidence cleanup:** Invalidate superseded “Concurrent operator injection” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M12.04-C057-T09 · Repeat and compare:** Repeat the selected “Concurrent operator injection” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M12.04-C057-T10 · Failure evidence:** Publish the “Concurrent operator injection” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M12.04-C058 · Bounds

**Original checklist item:** Set a documented campaign budget for concurrent actors and interleavings; record actual consumption, incomplete coverage and the disposition when the budget is exhausted.

- [ ] **UC-M12.04-C058-T01 · Quantity inventory:** Create a measurement inventory for “Concurrent operator injection”: “Concurrent actors and interleavings”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M12.04-C058-T02 · Measurement method:** Choose how to observe each “Concurrent operator injection” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M12.04-C058-T03 · Budget decision:** Select justified campaign and target-resource budgets for “Concurrent operator injection”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M12.04-C058-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Concurrent operator injection” cases for “Concurrent actors and interleavings”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M12.04-C058-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Concurrent operator injection” limit; preserve “Competing operators cannot produce incoherent committed authority”.
- [ ] **UC-M12.04-C058-T06 · Normal measurement:** Run or review the normal “Concurrent operator injection” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M12.04-C058-T07 · At-limit measurement:** Exercise the “Concurrent operator injection” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M12.04-C058-T08 · Over-limit measurement:** Exercise the “Concurrent operator injection” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M12.04-C058-T09 · Uncovered-scope report:** List the “Concurrent operator injection” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M12.04-C058-T10 · Limit evidence:** Publish the selected “Concurrent operator injection” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M12.04-C059 · Diagnostics / review

**Original checklist item:** Report concurrent operator injection results with executed, failed, skipped and unavailable cases separated; preserve the underlying observations and do not manufacture missing measurements.

- [ ] **UC-M12.04-C059-T01 · Result inventory:** Enumerate the required “Concurrent operator injection” qualification cases and intended targets before aggregating results; keep the planned denominator visible.
- [ ] **UC-M12.04-C059-T02 · Verdict schema:** Define separate executed-pass, executed-fail, skipped, unavailable and untested outcomes for “Concurrent operator injection”; document how incomplete cases block relevant claims.
- [ ] **UC-M12.04-C059-T03 · Identity fields:** Attach the actual target, fixture, configuration and revision identifiers to each “Concurrent operator injection” result; do not attribute host-only evidence to a guest or another OS.
- [ ] **UC-M12.04-C059-T04 · Observation capture:** Capture bounded raw “Concurrent operator injection” observations and harness errors; retain enough information to verify the reported oracle comparison.
- [ ] **UC-M12.04-C059-T05 · Aggregation rules:** Implement the “Concurrent operator injection” count/reduction rule so failures and missing measurements cannot disappear; preserve “Competing operators cannot produce incoherent committed authority”.
- [ ] **UC-M12.04-C059-T06 · Failure visibility:** Feed a failing “Concurrent operator injection” control through the report path; assert the exact failed case and underlying observation remain visible.
- [ ] **UC-M12.04-C059-T07 · Missing-result visibility:** Withhold a required “Concurrent operator injection” measurement or target; verify the report uses unavailable/untested rather than a fabricated zero or passing value.
- [ ] **UC-M12.04-C059-T08 · Bounds and redaction:** Check “Concurrent operator injection” report size and retention against “Concurrent actors and interleavings”; remove secrets while retaining fixture and subject references.
- [ ] **UC-M12.04-C059-T09 · Report reconciliation:** Reconcile the “Concurrent operator injection” summary with every underlying case record; account for the full planned denominator and all omitted scope.
- [ ] **UC-M12.04-C059-T10 · Qualification handoff:** Publish the “Concurrent operator injection” report with measured observations, coverage limits and blockers; state which actual targets remain unqualified.

### UC-M12.04-C060 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for concurrent operator injection; label unexecuted checks as untested.

- [ ] **UC-M12.04-C060-T01 · Evidence inventory:** List the “Concurrent operator injection” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M12.04-C060-T02 · Artifact references:** Record the exact “Concurrent operator injection” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M12.04-C060-T03 · Fixture references:** Attach the “Concurrent operator injection” fixture IDs, input identities and oracle definition; preserve the source counterexample “Replace and restore publish different generations concurrently” as a distinct evidence case.
- [ ] **UC-M12.04-C060-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Concurrent operator injection”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M12.04-C060-T05 · Environment record:** Record the actual “Concurrent operator injection” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M12.04-C060-T06 · Expected versus observed:** Pair every “Concurrent operator injection” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M12.04-C060-T07 · Failure and limit records:** Attach “Concurrent operator injection” change/failure and bounds evidence where required; include uncovered “Concurrent actors and interleavings” and unresolved violations of “Competing operators cannot produce incoherent committed authority”.
- [ ] **UC-M12.04-C060-T08 · Evidence hygiene:** Check the “Concurrent operator injection” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M12.04-C060-T09 · Reproduction review:** Have the “Concurrent operator injection” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M12.04-C060-T10 · Acceptance linkage:** Link the “Concurrent operator injection” evidence to its parent and UC-M12.04 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 07. Backend failure injection

**Source delivery:** Simulate selected backend exits and lost acknowledgments near state changes.

**Source invariant:** Backend uncertainty cannot be converted into fabricated success.

**Source negative case:** The guest commits output and the supervisor loses its acknowledgment.

**Source bounded quantities:** Failure timings and pending operations.

### UC-M12.04-C061 · Contract

**Original checklist item:** Define the qualification objective for backend failure injection, including the actual target implementation, prerequisites, observable oracle and explicit exclusions.

- [ ] **UC-M12.04-C061-T01 · Scope statement:** Write the qualification question for “Backend failure injection”; identify the actual target, claimed capability and observations that can answer that question.
- [ ] **UC-M12.04-C061-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Backend failure injection”; record each producer, representation and missing-value meaning.
- [ ] **UC-M12.04-C061-T03 · Output inventory:** List the outputs of “Backend failure injection” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M12.04-C061-T04 · Field dictionary:** Create a field-and-term dictionary for “Backend failure injection”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M12.04-C061-T05 · Prerequisite contract:** Map “Backend failure injection” to the source component prerequisites (UC-M07.01, UC-M07.05, UC-M07.08); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M12.04-C061-T06 · Authority map:** Identify who may produce, change and consume “Backend failure injection”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M12.04-C061-T07 · Invariant clause:** Add a normative clause for “Backend failure injection” that preserves “Backend uncertainty cannot be converted into fabricated success”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M12.04-C061-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Backend failure injection”; include the source counterexample “The guest commits output and the supervisor loses its acknowledgment” and the intended safe disposition.
- [ ] **UC-M12.04-C061-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Failure timings and pending operations” in the “Backend failure injection” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M12.04-C061-T10 · Contract review:** Review the “Backend failure injection” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M12.04-C062 · Delivery

**Original checklist item:** Simulate selected backend exits and lost acknowledgments near state changes.

- [ ] **UC-M12.04-C062-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Backend failure injection”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M12.04-C062-T02 · Change plan:** Break the source delivery for “Backend failure injection” into concrete edit targets and reviewable outputs; keep the UC-M12.04 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M12.04-C062-T03 · Core artifact:** Create the “Backend failure injection” fixture or harness for this source instruction: Simulate selected backend exits and lost acknowledgments near state changes.
- [ ] **UC-M12.04-C062-T04 · Concrete realization:** Connect the “Backend failure injection” harness to its actual intended target, set the expected oracle before running it, and distinguish a mock/control run from a target run.
- [ ] **UC-M12.04-C062-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Backend failure injection” needed to preserve “Backend uncertainty cannot be converted into fabricated success”; record an enforcement gap where only a model exists.
- [ ] **UC-M12.04-C062-T06 · Dependency connection:** Connect the “Backend failure injection” qualification artifact to instrumented mutation boundaries, crash injection and cross-participant recovery oracles; record the target identity and what the harness actually exercises.
- [ ] **UC-M12.04-C062-T07 · Resource behavior:** Account for “Failure timings and pending operations” in “Backend failure injection”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M12.04-C062-T08 · Delivery check:** Run a known-valid control and a deliberately failing control for “Backend failure injection”; confirm the harness distinguishes their observed outcomes.
- [ ] **UC-M12.04-C062-T09 · Patch review:** Review the “Backend failure injection” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M12.04-C062-T10 · Delivery handoff:** Publish the “Backend failure injection” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M12.04-C063 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Backend uncertainty cannot be converted into fabricated success. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M12.04-C063-T01 · Named property:** Create a stable property/check name under this parent for “Backend failure injection”; copy its required invariant exactly: “Backend uncertainty cannot be converted into fabricated success”.
- [ ] **UC-M12.04-C063-T02 · Observable terms:** Define each term in the “Backend failure injection” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M12.04-C063-T03 · Precondition set:** List the preconditions under which “Backend uncertainty cannot be converted into fabricated success” must hold for “Backend failure injection”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M12.04-C063-T04 · Transition coverage:** Map the “Backend failure injection” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M12.04-C063-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Backend failure injection”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M12.04-C063-T06 · Satisfying fixture:** Create a concrete “Backend failure injection” case that satisfies “Backend uncertainty cannot be converted into fabricated success”; record its expected observation before running the assertion or review.
- [ ] **UC-M12.04-C063-T07 · Violating fixture:** Create the source counterexample “The guest commits output and the supervisor loses its acknowledgment” for “Backend failure injection”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M12.04-C063-T08 · Enforcement evidence:** Exercise the “Backend failure injection” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M12.04-C063-T09 · Regression linkage:** Link the “Backend failure injection” property to changes in instrumented mutation boundaries, crash injection and cross-participant recovery oracles; record which dependency or contract changes require rerunning it.
- [ ] **UC-M12.04-C063-T10 · Property disposition:** Compare the satisfying and violating “Backend failure injection” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M12.04-C064 · Integration

**Original checklist item:** Integrate backend failure injection with instrumented mutation boundaries, crash injection and cross-participant recovery oracles; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M12.04-C064-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Backend failure injection” across instrumented mutation boundaries, crash injection and cross-participant recovery oracles; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M12.04-C064-T02 · Field mapping:** Map every “Backend failure injection” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M12.04-C064-T03 · Prerequisite identities:** Record the actual prerequisites for “Backend failure injection” (source dependency list: UC-M07.01, UC-M07.05, UC-M07.08); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M12.04-C064-T04 · Ownership agreement:** Specify who owns “Backend failure injection” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M12.04-C064-T05 · Handoff implementation:** Connect “Backend failure injection” through the mapped seam using the real adapter or explicit specification reference; preserve “Backend uncertainty cannot be converted into fabricated success” across the handoff.
- [ ] **UC-M12.04-C064-T06 · Absent-input case:** Omit one required “Backend failure injection” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M12.04-C064-T07 · Stale-input case:** Supply an outdated “Backend failure injection” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M12.04-C064-T08 · Incompatible-input case:** Supply an incompatible “Backend failure injection” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M12.04-C064-T09 · Valid integration trace:** Run a valid “Backend failure injection” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M12.04-C064-T10 · Seam review:** Reconcile the “Backend failure injection” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M12.04-C065 · Valid-case test

**Original checklist item:** Run a known-valid control for backend failure injection; verify that the harness reaches its intended target and compare observed measurements or verdicts with predeclared expectations.

- [ ] **UC-M12.04-C065-T01 · Valid fixture choice:** Choose a known-valid control for “Backend failure injection”; document why it should pass and how it proves the harness reaches the intended target.
- [ ] **UC-M12.04-C065-T02 · Expected-result oracle:** Specify the “Backend failure injection” expected result independently of the implementation output; include the property “Backend uncertainty cannot be converted into fabricated success” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M12.04-C065-T03 · Fixture material:** Create the concrete “Backend failure injection” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M12.04-C065-T04 · Target preparation:** Prepare the “Backend failure injection” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M12.04-C065-T05 · Initial-state record:** Record the initial “Backend failure injection” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M12.04-C065-T06 · Valid-path execution:** Run the “Backend failure injection” known-valid control on the identified target; retain enough observations to prove the correct target was exercised.
- [ ] **UC-M12.04-C065-T07 · Outcome comparison:** Compare every declared “Backend failure injection” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M12.04-C065-T08 · State and bounds check:** Inspect the “Backend failure injection” ownership/state effects and actual use of “Failure timings and pending operations”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M12.04-C065-T09 · Repeatability check:** Repeat the same “Backend failure injection” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M12.04-C065-T10 · Positive evidence:** Attach the “Backend failure injection” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M12.04-C066 · Negative test

**Original checklist item:** Negative case: The guest commits output and the supervisor loses its acknowledgment. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M12.04-C066-T01 · Adverse-case definition:** Create a test record for the exact “Backend failure injection” source counterexample: “The guest commits output and the supervisor loses its acknowledgment”; state which precondition or invariant it challenges.
- [ ] **UC-M12.04-C066-T02 · Safe fixture boundary:** Define the contained test boundary for “Backend failure injection”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M12.04-C066-T03 · Valid control:** Construct a valid “Backend failure injection” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M12.04-C066-T04 · Minimal adverse input:** Derive the “Backend failure injection” adverse fixture from the control with the smallest documented change needed to reproduce “The guest commits output and the supervisor loses its acknowledgment”; retain that change as reproducible data.
- [ ] **UC-M12.04-C066-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Backend failure injection”; require “Backend uncertainty cannot be converted into fabricated success” and forbid a false-success verdict.
- [ ] **UC-M12.04-C066-T06 · Adverse execution:** Exercise the “Backend failure injection” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M12.04-C066-T07 · Effect inspection:** Inspect “Backend failure injection” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M12.04-C066-T08 · Refusal versus failure:** Confirm the “Backend failure injection” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M12.04-C066-T09 · Reset and retention:** Restore only the disposable “Backend failure injection” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M12.04-C066-T10 · Negative regression:** Register the “Backend failure injection” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M12.04-C067 · Change / failure test

**Original checklist item:** Exercise backend failure injection when the test process restarts after a partial write, ENOSPC or competing mutation; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M12.04-C067-T01 · Scenario record:** Write the “Backend failure injection” change/failure scenario exactly as supplied: the test process restarts after a partial write, ENOSPC or competing mutation; identify the property that must remain true: “Backend uncertainty cannot be converted into fabricated success”.
- [ ] **UC-M12.04-C067-T02 · Baseline capture:** Create a known-valid “Backend failure injection” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M12.04-C067-T03 · Injection map:** Locate the “Backend failure injection” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M12.04-C067-T04 · Disposition oracle:** Define the legal intermediate and final “Backend failure injection” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M12.04-C067-T05 · Controlled trigger:** Introduce the controlled “Backend failure injection” scenario in the disposable fixture: the test process restarts after a partial write, ENOSPC or competing mutation; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M12.04-C067-T06 · Intermediate inspection:** Inspect the “Backend failure injection” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M12.04-C067-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Backend failure injection”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M12.04-C067-T08 · Stale-evidence cleanup:** Invalidate superseded “Backend failure injection” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M12.04-C067-T09 · Repeat and compare:** Repeat the selected “Backend failure injection” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M12.04-C067-T10 · Failure evidence:** Publish the “Backend failure injection” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M12.04-C068 · Bounds

**Original checklist item:** Set a documented campaign budget for failure timings and pending operations; record actual consumption, incomplete coverage and the disposition when the budget is exhausted.

- [ ] **UC-M12.04-C068-T01 · Quantity inventory:** Create a measurement inventory for “Backend failure injection”: “Failure timings and pending operations”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M12.04-C068-T02 · Measurement method:** Choose how to observe each “Backend failure injection” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M12.04-C068-T03 · Budget decision:** Select justified campaign and target-resource budgets for “Backend failure injection”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M12.04-C068-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Backend failure injection” cases for “Failure timings and pending operations”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M12.04-C068-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Backend failure injection” limit; preserve “Backend uncertainty cannot be converted into fabricated success”.
- [ ] **UC-M12.04-C068-T06 · Normal measurement:** Run or review the normal “Backend failure injection” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M12.04-C068-T07 · At-limit measurement:** Exercise the “Backend failure injection” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M12.04-C068-T08 · Over-limit measurement:** Exercise the “Backend failure injection” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M12.04-C068-T09 · Uncovered-scope report:** List the “Backend failure injection” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M12.04-C068-T10 · Limit evidence:** Publish the selected “Backend failure injection” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M12.04-C069 · Diagnostics / review

**Original checklist item:** Report backend failure injection results with executed, failed, skipped and unavailable cases separated; preserve the underlying observations and do not manufacture missing measurements.

- [ ] **UC-M12.04-C069-T01 · Result inventory:** Enumerate the required “Backend failure injection” qualification cases and intended targets before aggregating results; keep the planned denominator visible.
- [ ] **UC-M12.04-C069-T02 · Verdict schema:** Define separate executed-pass, executed-fail, skipped, unavailable and untested outcomes for “Backend failure injection”; document how incomplete cases block relevant claims.
- [ ] **UC-M12.04-C069-T03 · Identity fields:** Attach the actual target, fixture, configuration and revision identifiers to each “Backend failure injection” result; do not attribute host-only evidence to a guest or another OS.
- [ ] **UC-M12.04-C069-T04 · Observation capture:** Capture bounded raw “Backend failure injection” observations and harness errors; retain enough information to verify the reported oracle comparison.
- [ ] **UC-M12.04-C069-T05 · Aggregation rules:** Implement the “Backend failure injection” count/reduction rule so failures and missing measurements cannot disappear; preserve “Backend uncertainty cannot be converted into fabricated success”.
- [ ] **UC-M12.04-C069-T06 · Failure visibility:** Feed a failing “Backend failure injection” control through the report path; assert the exact failed case and underlying observation remain visible.
- [ ] **UC-M12.04-C069-T07 · Missing-result visibility:** Withhold a required “Backend failure injection” measurement or target; verify the report uses unavailable/untested rather than a fabricated zero or passing value.
- [ ] **UC-M12.04-C069-T08 · Bounds and redaction:** Check “Backend failure injection” report size and retention against “Failure timings and pending operations”; remove secrets while retaining fixture and subject references.
- [ ] **UC-M12.04-C069-T09 · Report reconciliation:** Reconcile the “Backend failure injection” summary with every underlying case record; account for the full planned denominator and all omitted scope.
- [ ] **UC-M12.04-C069-T10 · Qualification handoff:** Publish the “Backend failure injection” report with measured observations, coverage limits and blockers; state which actual targets remain unqualified.

### UC-M12.04-C070 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for backend failure injection; label unexecuted checks as untested.

- [ ] **UC-M12.04-C070-T01 · Evidence inventory:** List the “Backend failure injection” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M12.04-C070-T02 · Artifact references:** Record the exact “Backend failure injection” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M12.04-C070-T03 · Fixture references:** Attach the “Backend failure injection” fixture IDs, input identities and oracle definition; preserve the source counterexample “The guest commits output and the supervisor loses its acknowledgment” as a distinct evidence case.
- [ ] **UC-M12.04-C070-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Backend failure injection”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M12.04-C070-T05 · Environment record:** Record the actual “Backend failure injection” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M12.04-C070-T06 · Expected versus observed:** Pair every “Backend failure injection” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M12.04-C070-T07 · Failure and limit records:** Attach “Backend failure injection” change/failure and bounds evidence where required; include uncovered “Failure timings and pending operations” and unresolved violations of “Backend uncertainty cannot be converted into fabricated success”.
- [ ] **UC-M12.04-C070-T08 · Evidence hygiene:** Check the “Backend failure injection” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M12.04-C070-T09 · Reproduction review:** Have the “Backend failure injection” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M12.04-C070-T10 · Acceptance linkage:** Link the “Backend failure injection” evidence to its parent and UC-M12.04 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 08. Recovery oracle

**Source delivery:** Check all participants against the documented coherent or explicit partial-state model.

**Source invariant:** The oracle inspects more than one directory's existence.

**Source negative case:** A berth looks restored while registry and hull mounts disagree.

**Source bounded quantities:** Participants and verification bytes.

### UC-M12.04-C071 · Contract

**Original checklist item:** Define the qualification objective for recovery oracle, including the actual target implementation, prerequisites, observable oracle and explicit exclusions.

- [ ] **UC-M12.04-C071-T01 · Scope statement:** Write the qualification question for “Recovery oracle”; identify the actual target, claimed capability and observations that can answer that question.
- [ ] **UC-M12.04-C071-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Recovery oracle”; record each producer, representation and missing-value meaning.
- [ ] **UC-M12.04-C071-T03 · Output inventory:** List the outputs of “Recovery oracle” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M12.04-C071-T04 · Field dictionary:** Create a field-and-term dictionary for “Recovery oracle”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M12.04-C071-T05 · Prerequisite contract:** Map “Recovery oracle” to the source component prerequisites (UC-M07.01, UC-M07.05, UC-M07.08); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M12.04-C071-T06 · Authority map:** Identify who may produce, change and consume “Recovery oracle”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M12.04-C071-T07 · Invariant clause:** Add a normative clause for “Recovery oracle” that preserves “The oracle inspects more than one directory's existence”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M12.04-C071-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Recovery oracle”; include the source counterexample “A berth looks restored while registry and hull mounts disagree” and the intended safe disposition.
- [ ] **UC-M12.04-C071-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Participants and verification bytes” in the “Recovery oracle” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M12.04-C071-T10 · Contract review:** Review the “Recovery oracle” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M12.04-C072 · Delivery

**Original checklist item:** Check all participants against the documented coherent or explicit partial-state model.

- [ ] **UC-M12.04-C072-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Recovery oracle”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M12.04-C072-T02 · Change plan:** Break the source delivery for “Recovery oracle” into concrete edit targets and reviewable outputs; keep the UC-M12.04 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M12.04-C072-T03 · Core artifact:** Create the “Recovery oracle” fixture or harness for this source instruction: Check all participants against the documented coherent or explicit partial-state model.
- [ ] **UC-M12.04-C072-T04 · Concrete realization:** Connect the “Recovery oracle” harness to its actual intended target, set the expected oracle before running it, and distinguish a mock/control run from a target run.
- [ ] **UC-M12.04-C072-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Recovery oracle” needed to preserve “The oracle inspects more than one directory's existence”; record an enforcement gap where only a model exists.
- [ ] **UC-M12.04-C072-T06 · Dependency connection:** Connect the “Recovery oracle” qualification artifact to instrumented mutation boundaries, crash injection and cross-participant recovery oracles; record the target identity and what the harness actually exercises.
- [ ] **UC-M12.04-C072-T07 · Resource behavior:** Account for “Participants and verification bytes” in “Recovery oracle”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M12.04-C072-T08 · Delivery check:** Run a known-valid control and a deliberately failing control for “Recovery oracle”; confirm the harness distinguishes their observed outcomes.
- [ ] **UC-M12.04-C072-T09 · Patch review:** Review the “Recovery oracle” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M12.04-C072-T10 · Delivery handoff:** Publish the “Recovery oracle” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M12.04-C073 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: The oracle inspects more than one directory's existence. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M12.04-C073-T01 · Named property:** Create a stable property/check name under this parent for “Recovery oracle”; copy its required invariant exactly: “The oracle inspects more than one directory's existence”.
- [ ] **UC-M12.04-C073-T02 · Observable terms:** Define each term in the “Recovery oracle” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M12.04-C073-T03 · Precondition set:** List the preconditions under which “The oracle inspects more than one directory's existence” must hold for “Recovery oracle”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M12.04-C073-T04 · Transition coverage:** Map the “Recovery oracle” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M12.04-C073-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Recovery oracle”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M12.04-C073-T06 · Satisfying fixture:** Create a concrete “Recovery oracle” case that satisfies “The oracle inspects more than one directory's existence”; record its expected observation before running the assertion or review.
- [ ] **UC-M12.04-C073-T07 · Violating fixture:** Create the source counterexample “A berth looks restored while registry and hull mounts disagree” for “Recovery oracle”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M12.04-C073-T08 · Enforcement evidence:** Exercise the “Recovery oracle” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M12.04-C073-T09 · Regression linkage:** Link the “Recovery oracle” property to changes in instrumented mutation boundaries, crash injection and cross-participant recovery oracles; record which dependency or contract changes require rerunning it.
- [ ] **UC-M12.04-C073-T10 · Property disposition:** Compare the satisfying and violating “Recovery oracle” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M12.04-C074 · Integration

**Original checklist item:** Integrate recovery oracle with instrumented mutation boundaries, crash injection and cross-participant recovery oracles; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M12.04-C074-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Recovery oracle” across instrumented mutation boundaries, crash injection and cross-participant recovery oracles; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M12.04-C074-T02 · Field mapping:** Map every “Recovery oracle” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M12.04-C074-T03 · Prerequisite identities:** Record the actual prerequisites for “Recovery oracle” (source dependency list: UC-M07.01, UC-M07.05, UC-M07.08); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M12.04-C074-T04 · Ownership agreement:** Specify who owns “Recovery oracle” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M12.04-C074-T05 · Handoff implementation:** Connect “Recovery oracle” through the mapped seam using the real adapter or explicit specification reference; preserve “The oracle inspects more than one directory's existence” across the handoff.
- [ ] **UC-M12.04-C074-T06 · Absent-input case:** Omit one required “Recovery oracle” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M12.04-C074-T07 · Stale-input case:** Supply an outdated “Recovery oracle” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M12.04-C074-T08 · Incompatible-input case:** Supply an incompatible “Recovery oracle” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M12.04-C074-T09 · Valid integration trace:** Run a valid “Recovery oracle” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M12.04-C074-T10 · Seam review:** Reconcile the “Recovery oracle” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M12.04-C075 · Valid-case test

**Original checklist item:** Run a known-valid control for recovery oracle; verify that the harness reaches its intended target and compare observed measurements or verdicts with predeclared expectations.

- [ ] **UC-M12.04-C075-T01 · Valid fixture choice:** Choose a known-valid control for “Recovery oracle”; document why it should pass and how it proves the harness reaches the intended target.
- [ ] **UC-M12.04-C075-T02 · Expected-result oracle:** Specify the “Recovery oracle” expected result independently of the implementation output; include the property “The oracle inspects more than one directory's existence” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M12.04-C075-T03 · Fixture material:** Create the concrete “Recovery oracle” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M12.04-C075-T04 · Target preparation:** Prepare the “Recovery oracle” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M12.04-C075-T05 · Initial-state record:** Record the initial “Recovery oracle” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M12.04-C075-T06 · Valid-path execution:** Run the “Recovery oracle” known-valid control on the identified target; retain enough observations to prove the correct target was exercised.
- [ ] **UC-M12.04-C075-T07 · Outcome comparison:** Compare every declared “Recovery oracle” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M12.04-C075-T08 · State and bounds check:** Inspect the “Recovery oracle” ownership/state effects and actual use of “Participants and verification bytes”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M12.04-C075-T09 · Repeatability check:** Repeat the same “Recovery oracle” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M12.04-C075-T10 · Positive evidence:** Attach the “Recovery oracle” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M12.04-C076 · Negative test

**Original checklist item:** Negative case: A berth looks restored while registry and hull mounts disagree. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M12.04-C076-T01 · Adverse-case definition:** Create a test record for the exact “Recovery oracle” source counterexample: “A berth looks restored while registry and hull mounts disagree”; state which precondition or invariant it challenges.
- [ ] **UC-M12.04-C076-T02 · Safe fixture boundary:** Define the contained test boundary for “Recovery oracle”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M12.04-C076-T03 · Valid control:** Construct a valid “Recovery oracle” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M12.04-C076-T04 · Minimal adverse input:** Derive the “Recovery oracle” adverse fixture from the control with the smallest documented change needed to reproduce “A berth looks restored while registry and hull mounts disagree”; retain that change as reproducible data.
- [ ] **UC-M12.04-C076-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Recovery oracle”; require “The oracle inspects more than one directory's existence” and forbid a false-success verdict.
- [ ] **UC-M12.04-C076-T06 · Adverse execution:** Exercise the “Recovery oracle” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M12.04-C076-T07 · Effect inspection:** Inspect “Recovery oracle” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M12.04-C076-T08 · Refusal versus failure:** Confirm the “Recovery oracle” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M12.04-C076-T09 · Reset and retention:** Restore only the disposable “Recovery oracle” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M12.04-C076-T10 · Negative regression:** Register the “Recovery oracle” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M12.04-C077 · Change / failure test

**Original checklist item:** Exercise recovery oracle when the test process restarts after a partial write, ENOSPC or competing mutation; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M12.04-C077-T01 · Scenario record:** Write the “Recovery oracle” change/failure scenario exactly as supplied: the test process restarts after a partial write, ENOSPC or competing mutation; identify the property that must remain true: “The oracle inspects more than one directory's existence”.
- [ ] **UC-M12.04-C077-T02 · Baseline capture:** Create a known-valid “Recovery oracle” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M12.04-C077-T03 · Injection map:** Locate the “Recovery oracle” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M12.04-C077-T04 · Disposition oracle:** Define the legal intermediate and final “Recovery oracle” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M12.04-C077-T05 · Controlled trigger:** Introduce the controlled “Recovery oracle” scenario in the disposable fixture: the test process restarts after a partial write, ENOSPC or competing mutation; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M12.04-C077-T06 · Intermediate inspection:** Inspect the “Recovery oracle” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M12.04-C077-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Recovery oracle”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M12.04-C077-T08 · Stale-evidence cleanup:** Invalidate superseded “Recovery oracle” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M12.04-C077-T09 · Repeat and compare:** Repeat the selected “Recovery oracle” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M12.04-C077-T10 · Failure evidence:** Publish the “Recovery oracle” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M12.04-C078 · Bounds

**Original checklist item:** Set a documented campaign budget for participants and verification bytes; record actual consumption, incomplete coverage and the disposition when the budget is exhausted.

- [ ] **UC-M12.04-C078-T01 · Quantity inventory:** Create a measurement inventory for “Recovery oracle”: “Participants and verification bytes”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M12.04-C078-T02 · Measurement method:** Choose how to observe each “Recovery oracle” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M12.04-C078-T03 · Budget decision:** Select justified campaign and target-resource budgets for “Recovery oracle”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M12.04-C078-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Recovery oracle” cases for “Participants and verification bytes”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M12.04-C078-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Recovery oracle” limit; preserve “The oracle inspects more than one directory's existence”.
- [ ] **UC-M12.04-C078-T06 · Normal measurement:** Run or review the normal “Recovery oracle” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M12.04-C078-T07 · At-limit measurement:** Exercise the “Recovery oracle” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M12.04-C078-T08 · Over-limit measurement:** Exercise the “Recovery oracle” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M12.04-C078-T09 · Uncovered-scope report:** List the “Recovery oracle” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M12.04-C078-T10 · Limit evidence:** Publish the selected “Recovery oracle” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M12.04-C079 · Diagnostics / review

**Original checklist item:** Report recovery oracle results with executed, failed, skipped and unavailable cases separated; preserve the underlying observations and do not manufacture missing measurements.

- [ ] **UC-M12.04-C079-T01 · Result inventory:** Enumerate the required “Recovery oracle” qualification cases and intended targets before aggregating results; keep the planned denominator visible.
- [ ] **UC-M12.04-C079-T02 · Verdict schema:** Define separate executed-pass, executed-fail, skipped, unavailable and untested outcomes for “Recovery oracle”; document how incomplete cases block relevant claims.
- [ ] **UC-M12.04-C079-T03 · Identity fields:** Attach the actual target, fixture, configuration and revision identifiers to each “Recovery oracle” result; do not attribute host-only evidence to a guest or another OS.
- [ ] **UC-M12.04-C079-T04 · Observation capture:** Capture bounded raw “Recovery oracle” observations and harness errors; retain enough information to verify the reported oracle comparison.
- [ ] **UC-M12.04-C079-T05 · Aggregation rules:** Implement the “Recovery oracle” count/reduction rule so failures and missing measurements cannot disappear; preserve “The oracle inspects more than one directory's existence”.
- [ ] **UC-M12.04-C079-T06 · Failure visibility:** Feed a failing “Recovery oracle” control through the report path; assert the exact failed case and underlying observation remain visible.
- [ ] **UC-M12.04-C079-T07 · Missing-result visibility:** Withhold a required “Recovery oracle” measurement or target; verify the report uses unavailable/untested rather than a fabricated zero or passing value.
- [ ] **UC-M12.04-C079-T08 · Bounds and redaction:** Check “Recovery oracle” report size and retention against “Participants and verification bytes”; remove secrets while retaining fixture and subject references.
- [ ] **UC-M12.04-C079-T09 · Report reconciliation:** Reconcile the “Recovery oracle” summary with every underlying case record; account for the full planned denominator and all omitted scope.
- [ ] **UC-M12.04-C079-T10 · Qualification handoff:** Publish the “Recovery oracle” report with measured observations, coverage limits and blockers; state which actual targets remain unqualified.

### UC-M12.04-C080 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for recovery oracle; label unexecuted checks as untested.

- [ ] **UC-M12.04-C080-T01 · Evidence inventory:** List the “Recovery oracle” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M12.04-C080-T02 · Artifact references:** Record the exact “Recovery oracle” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M12.04-C080-T03 · Fixture references:** Attach the “Recovery oracle” fixture IDs, input identities and oracle definition; preserve the source counterexample “A berth looks restored while registry and hull mounts disagree” as a distinct evidence case.
- [ ] **UC-M12.04-C080-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Recovery oracle”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M12.04-C080-T05 · Environment record:** Record the actual “Recovery oracle” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M12.04-C080-T06 · Expected versus observed:** Pair every “Recovery oracle” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M12.04-C080-T07 · Failure and limit records:** Attach “Recovery oracle” change/failure and bounds evidence where required; include uncovered “Participants and verification bytes” and unresolved violations of “The oracle inspects more than one directory's existence”.
- [ ] **UC-M12.04-C080-T08 · Evidence hygiene:** Check the “Recovery oracle” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M12.04-C080-T09 · Reproduction review:** Have the “Recovery oracle” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M12.04-C080-T10 · Acceptance linkage:** Link the “Recovery oracle” evidence to its parent and UC-M12.04 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 09. Repeated trial harness

**Source delivery:** Run deterministic seeds and repeated interleavings with retained evidence.

**Source invariant:** Passing one favorable timing does not hide failures at other required boundaries.

**Source negative case:** Only the first successful trial is retained.

**Source bounded quantities:** Trial count and total test duration.

### UC-M12.04-C081 · Contract

**Original checklist item:** Define the qualification objective for repeated trial harness, including the actual target implementation, prerequisites, observable oracle and explicit exclusions.

- [ ] **UC-M12.04-C081-T01 · Scope statement:** Write the qualification question for “Repeated trial harness”; identify the actual target, claimed capability and observations that can answer that question.
- [ ] **UC-M12.04-C081-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Repeated trial harness”; record each producer, representation and missing-value meaning.
- [ ] **UC-M12.04-C081-T03 · Output inventory:** List the outputs of “Repeated trial harness” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M12.04-C081-T04 · Field dictionary:** Create a field-and-term dictionary for “Repeated trial harness”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M12.04-C081-T05 · Prerequisite contract:** Map “Repeated trial harness” to the source component prerequisites (UC-M07.01, UC-M07.05, UC-M07.08); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M12.04-C081-T06 · Authority map:** Identify who may produce, change and consume “Repeated trial harness”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M12.04-C081-T07 · Invariant clause:** Add a normative clause for “Repeated trial harness” that preserves “Passing one favorable timing does not hide failures at other required boundaries”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M12.04-C081-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Repeated trial harness”; include the source counterexample “Only the first successful trial is retained” and the intended safe disposition.
- [ ] **UC-M12.04-C081-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Trial count and total test duration” in the “Repeated trial harness” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M12.04-C081-T10 · Contract review:** Review the “Repeated trial harness” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M12.04-C082 · Delivery

**Original checklist item:** Run deterministic seeds and repeated interleavings with retained evidence.

- [ ] **UC-M12.04-C082-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Repeated trial harness”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M12.04-C082-T02 · Change plan:** Break the source delivery for “Repeated trial harness” into concrete edit targets and reviewable outputs; keep the UC-M12.04 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M12.04-C082-T03 · Core artifact:** Create the “Repeated trial harness” fixture or harness for this source instruction: Run deterministic seeds and repeated interleavings with retained evidence.
- [ ] **UC-M12.04-C082-T04 · Concrete realization:** Connect the “Repeated trial harness” harness to its actual intended target, set the expected oracle before running it, and distinguish a mock/control run from a target run.
- [ ] **UC-M12.04-C082-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Repeated trial harness” needed to preserve “Passing one favorable timing does not hide failures at other required boundaries”; record an enforcement gap where only a model exists.
- [ ] **UC-M12.04-C082-T06 · Dependency connection:** Connect the “Repeated trial harness” qualification artifact to instrumented mutation boundaries, crash injection and cross-participant recovery oracles; record the target identity and what the harness actually exercises.
- [ ] **UC-M12.04-C082-T07 · Resource behavior:** Account for “Trial count and total test duration” in “Repeated trial harness”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M12.04-C082-T08 · Delivery check:** Run a known-valid control and a deliberately failing control for “Repeated trial harness”; confirm the harness distinguishes their observed outcomes.
- [ ] **UC-M12.04-C082-T09 · Patch review:** Review the “Repeated trial harness” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M12.04-C082-T10 · Delivery handoff:** Publish the “Repeated trial harness” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M12.04-C083 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Passing one favorable timing does not hide failures at other required boundaries. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M12.04-C083-T01 · Named property:** Create a stable property/check name under this parent for “Repeated trial harness”; copy its required invariant exactly: “Passing one favorable timing does not hide failures at other required boundaries”.
- [ ] **UC-M12.04-C083-T02 · Observable terms:** Define each term in the “Repeated trial harness” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M12.04-C083-T03 · Precondition set:** List the preconditions under which “Passing one favorable timing does not hide failures at other required boundaries” must hold for “Repeated trial harness”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M12.04-C083-T04 · Transition coverage:** Map the “Repeated trial harness” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M12.04-C083-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Repeated trial harness”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M12.04-C083-T06 · Satisfying fixture:** Create a concrete “Repeated trial harness” case that satisfies “Passing one favorable timing does not hide failures at other required boundaries”; record its expected observation before running the assertion or review.
- [ ] **UC-M12.04-C083-T07 · Violating fixture:** Create the source counterexample “Only the first successful trial is retained” for “Repeated trial harness”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M12.04-C083-T08 · Enforcement evidence:** Exercise the “Repeated trial harness” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M12.04-C083-T09 · Regression linkage:** Link the “Repeated trial harness” property to changes in instrumented mutation boundaries, crash injection and cross-participant recovery oracles; record which dependency or contract changes require rerunning it.
- [ ] **UC-M12.04-C083-T10 · Property disposition:** Compare the satisfying and violating “Repeated trial harness” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M12.04-C084 · Integration

**Original checklist item:** Integrate repeated trial harness with instrumented mutation boundaries, crash injection and cross-participant recovery oracles; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M12.04-C084-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Repeated trial harness” across instrumented mutation boundaries, crash injection and cross-participant recovery oracles; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M12.04-C084-T02 · Field mapping:** Map every “Repeated trial harness” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M12.04-C084-T03 · Prerequisite identities:** Record the actual prerequisites for “Repeated trial harness” (source dependency list: UC-M07.01, UC-M07.05, UC-M07.08); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M12.04-C084-T04 · Ownership agreement:** Specify who owns “Repeated trial harness” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M12.04-C084-T05 · Handoff implementation:** Connect “Repeated trial harness” through the mapped seam using the real adapter or explicit specification reference; preserve “Passing one favorable timing does not hide failures at other required boundaries” across the handoff.
- [ ] **UC-M12.04-C084-T06 · Absent-input case:** Omit one required “Repeated trial harness” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M12.04-C084-T07 · Stale-input case:** Supply an outdated “Repeated trial harness” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M12.04-C084-T08 · Incompatible-input case:** Supply an incompatible “Repeated trial harness” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M12.04-C084-T09 · Valid integration trace:** Run a valid “Repeated trial harness” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M12.04-C084-T10 · Seam review:** Reconcile the “Repeated trial harness” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M12.04-C085 · Valid-case test

**Original checklist item:** Run a known-valid control for repeated trial harness; verify that the harness reaches its intended target and compare observed measurements or verdicts with predeclared expectations.

- [ ] **UC-M12.04-C085-T01 · Valid fixture choice:** Choose a known-valid control for “Repeated trial harness”; document why it should pass and how it proves the harness reaches the intended target.
- [ ] **UC-M12.04-C085-T02 · Expected-result oracle:** Specify the “Repeated trial harness” expected result independently of the implementation output; include the property “Passing one favorable timing does not hide failures at other required boundaries” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M12.04-C085-T03 · Fixture material:** Create the concrete “Repeated trial harness” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M12.04-C085-T04 · Target preparation:** Prepare the “Repeated trial harness” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M12.04-C085-T05 · Initial-state record:** Record the initial “Repeated trial harness” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M12.04-C085-T06 · Valid-path execution:** Run the “Repeated trial harness” known-valid control on the identified target; retain enough observations to prove the correct target was exercised.
- [ ] **UC-M12.04-C085-T07 · Outcome comparison:** Compare every declared “Repeated trial harness” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M12.04-C085-T08 · State and bounds check:** Inspect the “Repeated trial harness” ownership/state effects and actual use of “Trial count and total test duration”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M12.04-C085-T09 · Repeatability check:** Repeat the same “Repeated trial harness” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M12.04-C085-T10 · Positive evidence:** Attach the “Repeated trial harness” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M12.04-C086 · Negative test

**Original checklist item:** Negative case: Only the first successful trial is retained. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M12.04-C086-T01 · Adverse-case definition:** Create a test record for the exact “Repeated trial harness” source counterexample: “Only the first successful trial is retained”; state which precondition or invariant it challenges.
- [ ] **UC-M12.04-C086-T02 · Safe fixture boundary:** Define the contained test boundary for “Repeated trial harness”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M12.04-C086-T03 · Valid control:** Construct a valid “Repeated trial harness” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M12.04-C086-T04 · Minimal adverse input:** Derive the “Repeated trial harness” adverse fixture from the control with the smallest documented change needed to reproduce “Only the first successful trial is retained”; retain that change as reproducible data.
- [ ] **UC-M12.04-C086-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Repeated trial harness”; require “Passing one favorable timing does not hide failures at other required boundaries” and forbid a false-success verdict.
- [ ] **UC-M12.04-C086-T06 · Adverse execution:** Exercise the “Repeated trial harness” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M12.04-C086-T07 · Effect inspection:** Inspect “Repeated trial harness” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M12.04-C086-T08 · Refusal versus failure:** Confirm the “Repeated trial harness” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M12.04-C086-T09 · Reset and retention:** Restore only the disposable “Repeated trial harness” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M12.04-C086-T10 · Negative regression:** Register the “Repeated trial harness” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M12.04-C087 · Change / failure test

**Original checklist item:** Exercise repeated trial harness when the test process restarts after a partial write, ENOSPC or competing mutation; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M12.04-C087-T01 · Scenario record:** Write the “Repeated trial harness” change/failure scenario exactly as supplied: the test process restarts after a partial write, ENOSPC or competing mutation; identify the property that must remain true: “Passing one favorable timing does not hide failures at other required boundaries”.
- [ ] **UC-M12.04-C087-T02 · Baseline capture:** Create a known-valid “Repeated trial harness” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M12.04-C087-T03 · Injection map:** Locate the “Repeated trial harness” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M12.04-C087-T04 · Disposition oracle:** Define the legal intermediate and final “Repeated trial harness” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M12.04-C087-T05 · Controlled trigger:** Introduce the controlled “Repeated trial harness” scenario in the disposable fixture: the test process restarts after a partial write, ENOSPC or competing mutation; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M12.04-C087-T06 · Intermediate inspection:** Inspect the “Repeated trial harness” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M12.04-C087-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Repeated trial harness”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M12.04-C087-T08 · Stale-evidence cleanup:** Invalidate superseded “Repeated trial harness” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M12.04-C087-T09 · Repeat and compare:** Repeat the selected “Repeated trial harness” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M12.04-C087-T10 · Failure evidence:** Publish the “Repeated trial harness” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M12.04-C088 · Bounds

**Original checklist item:** Set a documented campaign budget for trial count and total test duration; record actual consumption, incomplete coverage and the disposition when the budget is exhausted.

- [ ] **UC-M12.04-C088-T01 · Quantity inventory:** Create a measurement inventory for “Repeated trial harness”: “Trial count and total test duration”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M12.04-C088-T02 · Measurement method:** Choose how to observe each “Repeated trial harness” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M12.04-C088-T03 · Budget decision:** Select justified campaign and target-resource budgets for “Repeated trial harness”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M12.04-C088-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Repeated trial harness” cases for “Trial count and total test duration”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M12.04-C088-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Repeated trial harness” limit; preserve “Passing one favorable timing does not hide failures at other required boundaries”.
- [ ] **UC-M12.04-C088-T06 · Normal measurement:** Run or review the normal “Repeated trial harness” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M12.04-C088-T07 · At-limit measurement:** Exercise the “Repeated trial harness” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M12.04-C088-T08 · Over-limit measurement:** Exercise the “Repeated trial harness” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M12.04-C088-T09 · Uncovered-scope report:** List the “Repeated trial harness” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M12.04-C088-T10 · Limit evidence:** Publish the selected “Repeated trial harness” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M12.04-C089 · Diagnostics / review

**Original checklist item:** Report repeated trial harness results with executed, failed, skipped and unavailable cases separated; preserve the underlying observations and do not manufacture missing measurements.

- [ ] **UC-M12.04-C089-T01 · Result inventory:** Enumerate the required “Repeated trial harness” qualification cases and intended targets before aggregating results; keep the planned denominator visible.
- [ ] **UC-M12.04-C089-T02 · Verdict schema:** Define separate executed-pass, executed-fail, skipped, unavailable and untested outcomes for “Repeated trial harness”; document how incomplete cases block relevant claims.
- [ ] **UC-M12.04-C089-T03 · Identity fields:** Attach the actual target, fixture, configuration and revision identifiers to each “Repeated trial harness” result; do not attribute host-only evidence to a guest or another OS.
- [ ] **UC-M12.04-C089-T04 · Observation capture:** Capture bounded raw “Repeated trial harness” observations and harness errors; retain enough information to verify the reported oracle comparison.
- [ ] **UC-M12.04-C089-T05 · Aggregation rules:** Implement the “Repeated trial harness” count/reduction rule so failures and missing measurements cannot disappear; preserve “Passing one favorable timing does not hide failures at other required boundaries”.
- [ ] **UC-M12.04-C089-T06 · Failure visibility:** Feed a failing “Repeated trial harness” control through the report path; assert the exact failed case and underlying observation remain visible.
- [ ] **UC-M12.04-C089-T07 · Missing-result visibility:** Withhold a required “Repeated trial harness” measurement or target; verify the report uses unavailable/untested rather than a fabricated zero or passing value.
- [ ] **UC-M12.04-C089-T08 · Bounds and redaction:** Check “Repeated trial harness” report size and retention against “Trial count and total test duration”; remove secrets while retaining fixture and subject references.
- [ ] **UC-M12.04-C089-T09 · Report reconciliation:** Reconcile the “Repeated trial harness” summary with every underlying case record; account for the full planned denominator and all omitted scope.
- [ ] **UC-M12.04-C089-T10 · Qualification handoff:** Publish the “Repeated trial harness” report with measured observations, coverage limits and blockers; state which actual targets remain unqualified.

### UC-M12.04-C090 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for repeated trial harness; label unexecuted checks as untested.

- [ ] **UC-M12.04-C090-T01 · Evidence inventory:** List the “Repeated trial harness” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M12.04-C090-T02 · Artifact references:** Record the exact “Repeated trial harness” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M12.04-C090-T03 · Fixture references:** Attach the “Repeated trial harness” fixture IDs, input identities and oracle definition; preserve the source counterexample “Only the first successful trial is retained” as a distinct evidence case.
- [ ] **UC-M12.04-C090-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Repeated trial harness”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M12.04-C090-T05 · Environment record:** Record the actual “Repeated trial harness” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M12.04-C090-T06 · Expected versus observed:** Pair every “Repeated trial harness” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M12.04-C090-T07 · Failure and limit records:** Attach “Repeated trial harness” change/failure and bounds evidence where required; include uncovered “Trial count and total test duration” and unresolved violations of “Passing one favorable timing does not hide failures at other required boundaries”.
- [ ] **UC-M12.04-C090-T08 · Evidence hygiene:** Check the “Repeated trial harness” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M12.04-C090-T09 · Reproduction review:** Have the “Repeated trial harness” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M12.04-C090-T10 · Acceptance linkage:** Link the “Repeated trial harness” evidence to its parent and UC-M12.04 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 10. Fault qualification report

**Source delivery:** Publish injected sites, actual outcomes, recovered cargo and unresolved failures.

**Source invariant:** No data loss or false-success verdict is omitted from the report.

**Source negative case:** A failed recovery trial is excluded from summary counts.

**Source bounded quantities:** Report records and evidence storage.

### UC-M12.04-C091 · Contract

**Original checklist item:** Define the qualification objective for fault qualification report, including the actual target implementation, prerequisites, observable oracle and explicit exclusions.

- [ ] **UC-M12.04-C091-T01 · Scope statement:** Write the qualification question for “Fault qualification report”; identify the actual target, claimed capability and observations that can answer that question.
- [ ] **UC-M12.04-C091-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Fault qualification report”; record each producer, representation and missing-value meaning.
- [ ] **UC-M12.04-C091-T03 · Output inventory:** List the outputs of “Fault qualification report” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M12.04-C091-T04 · Field dictionary:** Create a field-and-term dictionary for “Fault qualification report”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M12.04-C091-T05 · Prerequisite contract:** Map “Fault qualification report” to the source component prerequisites (UC-M07.01, UC-M07.05, UC-M07.08); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M12.04-C091-T06 · Authority map:** Identify who may produce, change and consume “Fault qualification report”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M12.04-C091-T07 · Invariant clause:** Add a normative clause for “Fault qualification report” that preserves “No data loss or false-success verdict is omitted from the report”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M12.04-C091-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Fault qualification report”; include the source counterexample “A failed recovery trial is excluded from summary counts” and the intended safe disposition.
- [ ] **UC-M12.04-C091-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Report records and evidence storage” in the “Fault qualification report” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M12.04-C091-T10 · Contract review:** Review the “Fault qualification report” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M12.04-C092 · Delivery

**Original checklist item:** Publish injected sites, actual outcomes, recovered cargo and unresolved failures.

- [ ] **UC-M12.04-C092-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Fault qualification report”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M12.04-C092-T02 · Change plan:** Break the source delivery for “Fault qualification report” into concrete edit targets and reviewable outputs; keep the UC-M12.04 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M12.04-C092-T03 · Core artifact:** Create the “Fault qualification report” output artifact for this source instruction: Publish injected sites, actual outcomes, recovered cargo and unresolved failures.
- [ ] **UC-M12.04-C092-T04 · Concrete realization:** Populate the “Fault qualification report” artifact from identified observations; keep unknown, failed and unexecuted results distinct and exclude unapproved sensitive material.
- [ ] **UC-M12.04-C092-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Fault qualification report” needed to preserve “No data loss or false-success verdict is omitted from the report”; record an enforcement gap where only a model exists.
- [ ] **UC-M12.04-C092-T06 · Dependency connection:** Connect the “Fault qualification report” qualification artifact to instrumented mutation boundaries, crash injection and cross-participant recovery oracles; record the target identity and what the harness actually exercises.
- [ ] **UC-M12.04-C092-T07 · Resource behavior:** Account for “Report records and evidence storage” in “Fault qualification report”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M12.04-C092-T08 · Delivery check:** Run a known-valid control and a deliberately failing control for “Fault qualification report”; confirm the harness distinguishes their observed outcomes.
- [ ] **UC-M12.04-C092-T09 · Patch review:** Review the “Fault qualification report” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M12.04-C092-T10 · Delivery handoff:** Publish the “Fault qualification report” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M12.04-C093 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: No data loss or false-success verdict is omitted from the report. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M12.04-C093-T01 · Named property:** Create a stable property/check name under this parent for “Fault qualification report”; copy its required invariant exactly: “No data loss or false-success verdict is omitted from the report”.
- [ ] **UC-M12.04-C093-T02 · Observable terms:** Define each term in the “Fault qualification report” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M12.04-C093-T03 · Precondition set:** List the preconditions under which “No data loss or false-success verdict is omitted from the report” must hold for “Fault qualification report”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M12.04-C093-T04 · Transition coverage:** Map the “Fault qualification report” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M12.04-C093-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Fault qualification report”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M12.04-C093-T06 · Satisfying fixture:** Create a concrete “Fault qualification report” case that satisfies “No data loss or false-success verdict is omitted from the report”; record its expected observation before running the assertion or review.
- [ ] **UC-M12.04-C093-T07 · Violating fixture:** Create the source counterexample “A failed recovery trial is excluded from summary counts” for “Fault qualification report”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M12.04-C093-T08 · Enforcement evidence:** Exercise the “Fault qualification report” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M12.04-C093-T09 · Regression linkage:** Link the “Fault qualification report” property to changes in instrumented mutation boundaries, crash injection and cross-participant recovery oracles; record which dependency or contract changes require rerunning it.
- [ ] **UC-M12.04-C093-T10 · Property disposition:** Compare the satisfying and violating “Fault qualification report” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M12.04-C094 · Integration

**Original checklist item:** Integrate fault qualification report with instrumented mutation boundaries, crash injection and cross-participant recovery oracles; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M12.04-C094-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Fault qualification report” across instrumented mutation boundaries, crash injection and cross-participant recovery oracles; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M12.04-C094-T02 · Field mapping:** Map every “Fault qualification report” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M12.04-C094-T03 · Prerequisite identities:** Record the actual prerequisites for “Fault qualification report” (source dependency list: UC-M07.01, UC-M07.05, UC-M07.08); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M12.04-C094-T04 · Ownership agreement:** Specify who owns “Fault qualification report” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M12.04-C094-T05 · Handoff implementation:** Connect “Fault qualification report” through the mapped seam using the real adapter or explicit specification reference; preserve “No data loss or false-success verdict is omitted from the report” across the handoff.
- [ ] **UC-M12.04-C094-T06 · Absent-input case:** Omit one required “Fault qualification report” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M12.04-C094-T07 · Stale-input case:** Supply an outdated “Fault qualification report” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M12.04-C094-T08 · Incompatible-input case:** Supply an incompatible “Fault qualification report” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M12.04-C094-T09 · Valid integration trace:** Run a valid “Fault qualification report” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M12.04-C094-T10 · Seam review:** Reconcile the “Fault qualification report” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M12.04-C095 · Valid-case test

**Original checklist item:** Run a known-valid control for fault qualification report; verify that the harness reaches its intended target and compare observed measurements or verdicts with predeclared expectations.

- [ ] **UC-M12.04-C095-T01 · Valid fixture choice:** Choose a known-valid control for “Fault qualification report”; document why it should pass and how it proves the harness reaches the intended target.
- [ ] **UC-M12.04-C095-T02 · Expected-result oracle:** Specify the “Fault qualification report” expected result independently of the implementation output; include the property “No data loss or false-success verdict is omitted from the report” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M12.04-C095-T03 · Fixture material:** Create the concrete “Fault qualification report” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M12.04-C095-T04 · Target preparation:** Prepare the “Fault qualification report” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M12.04-C095-T05 · Initial-state record:** Record the initial “Fault qualification report” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M12.04-C095-T06 · Valid-path execution:** Run the “Fault qualification report” known-valid control on the identified target; retain enough observations to prove the correct target was exercised.
- [ ] **UC-M12.04-C095-T07 · Outcome comparison:** Compare every declared “Fault qualification report” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M12.04-C095-T08 · State and bounds check:** Inspect the “Fault qualification report” ownership/state effects and actual use of “Report records and evidence storage”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M12.04-C095-T09 · Repeatability check:** Repeat the same “Fault qualification report” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M12.04-C095-T10 · Positive evidence:** Attach the “Fault qualification report” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M12.04-C096 · Negative test

**Original checklist item:** Negative case: A failed recovery trial is excluded from summary counts. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M12.04-C096-T01 · Adverse-case definition:** Create a test record for the exact “Fault qualification report” source counterexample: “A failed recovery trial is excluded from summary counts”; state which precondition or invariant it challenges.
- [ ] **UC-M12.04-C096-T02 · Safe fixture boundary:** Define the contained test boundary for “Fault qualification report”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M12.04-C096-T03 · Valid control:** Construct a valid “Fault qualification report” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M12.04-C096-T04 · Minimal adverse input:** Derive the “Fault qualification report” adverse fixture from the control with the smallest documented change needed to reproduce “A failed recovery trial is excluded from summary counts”; retain that change as reproducible data.
- [ ] **UC-M12.04-C096-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Fault qualification report”; require “No data loss or false-success verdict is omitted from the report” and forbid a false-success verdict.
- [ ] **UC-M12.04-C096-T06 · Adverse execution:** Exercise the “Fault qualification report” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M12.04-C096-T07 · Effect inspection:** Inspect “Fault qualification report” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M12.04-C096-T08 · Refusal versus failure:** Confirm the “Fault qualification report” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M12.04-C096-T09 · Reset and retention:** Restore only the disposable “Fault qualification report” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M12.04-C096-T10 · Negative regression:** Register the “Fault qualification report” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M12.04-C097 · Change / failure test

**Original checklist item:** Exercise fault qualification report when the test process restarts after a partial write, ENOSPC or competing mutation; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M12.04-C097-T01 · Scenario record:** Write the “Fault qualification report” change/failure scenario exactly as supplied: the test process restarts after a partial write, ENOSPC or competing mutation; identify the property that must remain true: “No data loss or false-success verdict is omitted from the report”.
- [ ] **UC-M12.04-C097-T02 · Baseline capture:** Create a known-valid “Fault qualification report” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M12.04-C097-T03 · Injection map:** Locate the “Fault qualification report” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M12.04-C097-T04 · Disposition oracle:** Define the legal intermediate and final “Fault qualification report” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M12.04-C097-T05 · Controlled trigger:** Introduce the controlled “Fault qualification report” scenario in the disposable fixture: the test process restarts after a partial write, ENOSPC or competing mutation; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M12.04-C097-T06 · Intermediate inspection:** Inspect the “Fault qualification report” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M12.04-C097-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Fault qualification report”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M12.04-C097-T08 · Stale-evidence cleanup:** Invalidate superseded “Fault qualification report” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M12.04-C097-T09 · Repeat and compare:** Repeat the selected “Fault qualification report” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M12.04-C097-T10 · Failure evidence:** Publish the “Fault qualification report” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M12.04-C098 · Bounds

**Original checklist item:** Set a documented campaign budget for report records and evidence storage; record actual consumption, incomplete coverage and the disposition when the budget is exhausted.

- [ ] **UC-M12.04-C098-T01 · Quantity inventory:** Create a measurement inventory for “Fault qualification report”: “Report records and evidence storage”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M12.04-C098-T02 · Measurement method:** Choose how to observe each “Fault qualification report” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M12.04-C098-T03 · Budget decision:** Select justified campaign and target-resource budgets for “Fault qualification report”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M12.04-C098-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Fault qualification report” cases for “Report records and evidence storage”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M12.04-C098-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Fault qualification report” limit; preserve “No data loss or false-success verdict is omitted from the report”.
- [ ] **UC-M12.04-C098-T06 · Normal measurement:** Run or review the normal “Fault qualification report” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M12.04-C098-T07 · At-limit measurement:** Exercise the “Fault qualification report” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M12.04-C098-T08 · Over-limit measurement:** Exercise the “Fault qualification report” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M12.04-C098-T09 · Uncovered-scope report:** List the “Fault qualification report” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M12.04-C098-T10 · Limit evidence:** Publish the selected “Fault qualification report” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M12.04-C099 · Diagnostics / review

**Original checklist item:** Report fault qualification report results with executed, failed, skipped and unavailable cases separated; preserve the underlying observations and do not manufacture missing measurements.

- [ ] **UC-M12.04-C099-T01 · Result inventory:** Enumerate the required “Fault qualification report” qualification cases and intended targets before aggregating results; keep the planned denominator visible.
- [ ] **UC-M12.04-C099-T02 · Verdict schema:** Define separate executed-pass, executed-fail, skipped, unavailable and untested outcomes for “Fault qualification report”; document how incomplete cases block relevant claims.
- [ ] **UC-M12.04-C099-T03 · Identity fields:** Attach the actual target, fixture, configuration and revision identifiers to each “Fault qualification report” result; do not attribute host-only evidence to a guest or another OS.
- [ ] **UC-M12.04-C099-T04 · Observation capture:** Capture bounded raw “Fault qualification report” observations and harness errors; retain enough information to verify the reported oracle comparison.
- [ ] **UC-M12.04-C099-T05 · Aggregation rules:** Implement the “Fault qualification report” count/reduction rule so failures and missing measurements cannot disappear; preserve “No data loss or false-success verdict is omitted from the report”.
- [ ] **UC-M12.04-C099-T06 · Failure visibility:** Feed a failing “Fault qualification report” control through the report path; assert the exact failed case and underlying observation remain visible.
- [ ] **UC-M12.04-C099-T07 · Missing-result visibility:** Withhold a required “Fault qualification report” measurement or target; verify the report uses unavailable/untested rather than a fabricated zero or passing value.
- [ ] **UC-M12.04-C099-T08 · Bounds and redaction:** Check “Fault qualification report” report size and retention against “Report records and evidence storage”; remove secrets while retaining fixture and subject references.
- [ ] **UC-M12.04-C099-T09 · Report reconciliation:** Reconcile the “Fault qualification report” summary with every underlying case record; account for the full planned denominator and all omitted scope.
- [ ] **UC-M12.04-C099-T10 · Qualification handoff:** Publish the “Fault qualification report” report with measured observations, coverage limits and blockers; state which actual targets remain unqualified.

### UC-M12.04-C100 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for fault qualification report; label unexecuted checks as untested.

- [ ] **UC-M12.04-C100-T01 · Evidence inventory:** List the “Fault qualification report” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M12.04-C100-T02 · Artifact references:** Record the exact “Fault qualification report” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M12.04-C100-T03 · Fixture references:** Attach the “Fault qualification report” fixture IDs, input identities and oracle definition; preserve the source counterexample “A failed recovery trial is excluded from summary counts” as a distinct evidence case.
- [ ] **UC-M12.04-C100-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Fault qualification report”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M12.04-C100-T05 · Environment record:** Record the actual “Fault qualification report” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M12.04-C100-T06 · Expected versus observed:** Pair every “Fault qualification report” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M12.04-C100-T07 · Failure and limit records:** Attach “Fault qualification report” change/failure and bounds evidence where required; include uncovered “Report records and evidence storage” and unresolved violations of “No data loss or false-success verdict is omitted from the report”.
- [ ] **UC-M12.04-C100-T08 · Evidence hygiene:** Check the “Fault qualification report” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M12.04-C100-T09 · Reproduction review:** Have the “Fault qualification report” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M12.04-C100-T10 · Acceptance linkage:** Link the “Fault qualification report” evidence to its parent and UC-M12.04 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

