# UC-M12.08 — Evidence-based release promotion and runbooks

**To-Do Pack 2.0.0 · Baseline UC-2.2.0 · 100 parent checks × 10 subtasks = 1,000 to-dos**

[Master index](../../INDEX.md) · [Workstream index](../../w/12.md)

| Field | Preserved source value |
|---|---|
| Workstream | 12. Qualification, packaging and release |
| Milestone | C |
| Priority | P0 |
| Source assessment | PARTIAL |
| Scope | core or selected profile |
| Dependencies | [UC-M09.05](../09/UC-M09.05.md), [UC-M09.07](../09/UC-M09.07.md), [UC-M12.01](../12/UC-M12.01.md), [UC-M12.02](../12/UC-M12.02.md), [UC-M12.03](../12/UC-M12.03.md), [UC-M12.04](../12/UC-M12.04.md) |
| Source checklist pack | 1.0.0 |
| Original reference labels | [S5], [S6], [S7], [S8]. |

## Original requirement

Define mandatory, optional and not-applicable gates; publish test scope, failures, residual risks and operator recovery procedures.

**Original acceptance criterion:** No release is labeled operational or isolated while a required gate is skipped, untested or supported only by a declaration.

**Source trace:** Original checklist `UC100/c/12/UC-M12.08.md` inside [s/checklists.zip](../../s/checklists.zip); exact parent records in [data/parents.jsonl](../../data/parents.jsonl). Original roadmap lines 1171–1182 are preserved in [s/roadmap.md](../../s/roadmap.md).

## How to use these lists

Every parent statement below is preserved verbatim. Its ten child tasks are proposed decomposition, not implemented capabilities or executed tests. Child IDs append `-T01` through `-T10` to the original parent ID. All begin unchecked / `TODO`. Design/review evidence does not establish runtime enforcement; observe the actual selected target where the parent requires it.

The source dependency graph and selected release profile determine applicability. The numbered child sequence is a local working order, not an added hard dependency graph. An unselected optional feature needs a recorded not-applicable rationale; missing prerequisites for selected work remain blockers. Numerical budgets, backends and trust mechanisms remain decisions unless fixed by the source. Test hostile cases only with synthetic inputs in authorized disposable environments.

## 01. Promotion profile definition

**Source delivery:** Define the selected offline, isolated, networked or federation release profile.

**Source invariant:** A release is evaluated against explicitly selected scope.

**Source negative case:** Optional federation gates are silently treated as core offline requirements.

**Source bounded quantities:** Profiles and required gate count.

### UC-M12.08-C001 · Contract

**Original checklist item:** Define the qualification objective for promotion profile definition, including the actual target implementation, prerequisites, observable oracle and explicit exclusions.

- [ ] **UC-M12.08-C001-T01 · Scope statement:** Write the qualification question for “Promotion profile definition”; identify the actual target, claimed capability and observations that can answer that question.
- [ ] **UC-M12.08-C001-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Promotion profile definition”; record each producer, representation and missing-value meaning.
- [ ] **UC-M12.08-C001-T03 · Output inventory:** List the outputs of “Promotion profile definition” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M12.08-C001-T04 · Field dictionary:** Create a field-and-term dictionary for “Promotion profile definition”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M12.08-C001-T05 · Prerequisite contract:** Map “Promotion profile definition” to the source component prerequisites (UC-M09.05, UC-M09.07, UC-M12.01, UC-M12.02, UC-M12.03, UC-M12.04); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M12.08-C001-T06 · Authority map:** Identify who may produce, change and consume “Promotion profile definition”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M12.08-C001-T07 · Invariant clause:** Add a normative clause for “Promotion profile definition” that preserves “A release is evaluated against explicitly selected scope”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M12.08-C001-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Promotion profile definition”; include the source counterexample “Optional federation gates are silently treated as core offline requirements” and the intended safe disposition.
- [ ] **UC-M12.08-C001-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Profiles and required gate count” in the “Promotion profile definition” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M12.08-C001-T10 · Contract review:** Review the “Promotion profile definition” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M12.08-C002 · Delivery

**Original checklist item:** Define the selected offline, isolated, networked or federation release profile.

- [ ] **UC-M12.08-C002-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Promotion profile definition”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M12.08-C002-T02 · Change plan:** Break the source delivery for “Promotion profile definition” into concrete edit targets and reviewable outputs; keep the UC-M12.08 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M12.08-C002-T03 · Core artifact:** Create the “Promotion profile definition” model, schema or inventory that realizes this source instruction: Define the selected offline, isolated, networked or federation release profile.
- [ ] **UC-M12.08-C002-T04 · Concrete realization:** Populate “Promotion profile definition” with one concrete worked case; map every required entity or field to its source and flag any unmapped entry.
- [ ] **UC-M12.08-C002-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Promotion profile definition” needed to preserve “A release is evaluated against explicitly selected scope”; record an enforcement gap where only a model exists.
- [ ] **UC-M12.08-C002-T06 · Dependency connection:** Connect the “Promotion profile definition” qualification artifact to selected release profiles, typed assurance evidence and required/optional gate evaluation; record the target identity and what the harness actually exercises.
- [ ] **UC-M12.08-C002-T07 · Resource behavior:** Account for “Profiles and required gate count” in “Promotion profile definition”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M12.08-C002-T08 · Delivery check:** Run a known-valid control and a deliberately failing control for “Promotion profile definition”; confirm the harness distinguishes their observed outcomes.
- [ ] **UC-M12.08-C002-T09 · Patch review:** Review the “Promotion profile definition” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M12.08-C002-T10 · Delivery handoff:** Publish the “Promotion profile definition” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M12.08-C003 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: A release is evaluated against explicitly selected scope. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M12.08-C003-T01 · Named property:** Create a stable property/check name under this parent for “Promotion profile definition”; copy its required invariant exactly: “A release is evaluated against explicitly selected scope”.
- [ ] **UC-M12.08-C003-T02 · Observable terms:** Define each term in the “Promotion profile definition” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M12.08-C003-T03 · Precondition set:** List the preconditions under which “A release is evaluated against explicitly selected scope” must hold for “Promotion profile definition”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M12.08-C003-T04 · Transition coverage:** Map the “Promotion profile definition” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M12.08-C003-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Promotion profile definition”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M12.08-C003-T06 · Satisfying fixture:** Create a concrete “Promotion profile definition” case that satisfies “A release is evaluated against explicitly selected scope”; record its expected observation before running the assertion or review.
- [ ] **UC-M12.08-C003-T07 · Violating fixture:** Create the source counterexample “Optional federation gates are silently treated as core offline requirements” for “Promotion profile definition”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M12.08-C003-T08 · Enforcement evidence:** Exercise the “Promotion profile definition” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M12.08-C003-T09 · Regression linkage:** Link the “Promotion profile definition” property to changes in selected release profiles, typed assurance evidence and required/optional gate evaluation; record which dependency or contract changes require rerunning it.
- [ ] **UC-M12.08-C003-T10 · Property disposition:** Compare the satisfying and violating “Promotion profile definition” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M12.08-C004 · Integration

**Original checklist item:** Integrate promotion profile definition with selected release profiles, typed assurance evidence and required/optional gate evaluation; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M12.08-C004-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Promotion profile definition” across selected release profiles, typed assurance evidence and required/optional gate evaluation; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M12.08-C004-T02 · Field mapping:** Map every “Promotion profile definition” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M12.08-C004-T03 · Prerequisite identities:** Record the actual prerequisites for “Promotion profile definition” (source dependency list: UC-M09.05, UC-M09.07, UC-M12.01, UC-M12.02, UC-M12.03, UC-M12.04); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M12.08-C004-T04 · Ownership agreement:** Specify who owns “Promotion profile definition” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M12.08-C004-T05 · Handoff implementation:** Connect “Promotion profile definition” through the mapped seam using the real adapter or explicit specification reference; preserve “A release is evaluated against explicitly selected scope” across the handoff.
- [ ] **UC-M12.08-C004-T06 · Absent-input case:** Omit one required “Promotion profile definition” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M12.08-C004-T07 · Stale-input case:** Supply an outdated “Promotion profile definition” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M12.08-C004-T08 · Incompatible-input case:** Supply an incompatible “Promotion profile definition” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M12.08-C004-T09 · Valid integration trace:** Run a valid “Promotion profile definition” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M12.08-C004-T10 · Seam review:** Reconcile the “Promotion profile definition” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M12.08-C005 · Valid-case test

**Original checklist item:** Run a known-valid control for promotion profile definition; verify that the harness reaches its intended target and compare observed measurements or verdicts with predeclared expectations.

- [ ] **UC-M12.08-C005-T01 · Valid fixture choice:** Choose a known-valid control for “Promotion profile definition”; document why it should pass and how it proves the harness reaches the intended target.
- [ ] **UC-M12.08-C005-T02 · Expected-result oracle:** Specify the “Promotion profile definition” expected result independently of the implementation output; include the property “A release is evaluated against explicitly selected scope” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M12.08-C005-T03 · Fixture material:** Create the concrete “Promotion profile definition” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M12.08-C005-T04 · Target preparation:** Prepare the “Promotion profile definition” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M12.08-C005-T05 · Initial-state record:** Record the initial “Promotion profile definition” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M12.08-C005-T06 · Valid-path execution:** Run the “Promotion profile definition” known-valid control on the identified target; retain enough observations to prove the correct target was exercised.
- [ ] **UC-M12.08-C005-T07 · Outcome comparison:** Compare every declared “Promotion profile definition” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M12.08-C005-T08 · State and bounds check:** Inspect the “Promotion profile definition” ownership/state effects and actual use of “Profiles and required gate count”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M12.08-C005-T09 · Repeatability check:** Repeat the same “Promotion profile definition” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M12.08-C005-T10 · Positive evidence:** Attach the “Promotion profile definition” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M12.08-C006 · Negative test

**Original checklist item:** Negative case: Optional federation gates are silently treated as core offline requirements. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M12.08-C006-T01 · Adverse-case definition:** Create a test record for the exact “Promotion profile definition” source counterexample: “Optional federation gates are silently treated as core offline requirements”; state which precondition or invariant it challenges.
- [ ] **UC-M12.08-C006-T02 · Safe fixture boundary:** Define the contained test boundary for “Promotion profile definition”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M12.08-C006-T03 · Valid control:** Construct a valid “Promotion profile definition” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M12.08-C006-T04 · Minimal adverse input:** Derive the “Promotion profile definition” adverse fixture from the control with the smallest documented change needed to reproduce “Optional federation gates are silently treated as core offline requirements”; retain that change as reproducible data.
- [ ] **UC-M12.08-C006-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Promotion profile definition”; require “A release is evaluated against explicitly selected scope” and forbid a false-success verdict.
- [ ] **UC-M12.08-C006-T06 · Adverse execution:** Exercise the “Promotion profile definition” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M12.08-C006-T07 · Effect inspection:** Inspect “Promotion profile definition” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M12.08-C006-T08 · Refusal versus failure:** Confirm the “Promotion profile definition” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M12.08-C006-T09 · Reset and retention:** Restore only the disposable “Promotion profile definition” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M12.08-C006-T10 · Negative regression:** Register the “Promotion profile definition” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M12.08-C007 · Change / failure test

**Original checklist item:** Exercise promotion profile definition when a required gate is skipped, stale or supported only by a declaration; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M12.08-C007-T01 · Scenario record:** Write the “Promotion profile definition” change/failure scenario exactly as supplied: a required gate is skipped, stale or supported only by a declaration; identify the property that must remain true: “A release is evaluated against explicitly selected scope”.
- [ ] **UC-M12.08-C007-T02 · Baseline capture:** Create a known-valid “Promotion profile definition” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M12.08-C007-T03 · Injection map:** Locate the “Promotion profile definition” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M12.08-C007-T04 · Disposition oracle:** Define the legal intermediate and final “Promotion profile definition” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M12.08-C007-T05 · Controlled trigger:** Introduce the controlled “Promotion profile definition” scenario in the disposable fixture: a required gate is skipped, stale or supported only by a declaration; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M12.08-C007-T06 · Intermediate inspection:** Inspect the “Promotion profile definition” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M12.08-C007-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Promotion profile definition”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M12.08-C007-T08 · Stale-evidence cleanup:** Invalidate superseded “Promotion profile definition” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M12.08-C007-T09 · Repeat and compare:** Repeat the selected “Promotion profile definition” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M12.08-C007-T10 · Failure evidence:** Publish the “Promotion profile definition” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M12.08-C008 · Bounds

**Original checklist item:** Set a documented campaign budget for profiles and required gate count; record actual consumption, incomplete coverage and the disposition when the budget is exhausted.

- [ ] **UC-M12.08-C008-T01 · Quantity inventory:** Create a measurement inventory for “Promotion profile definition”: “Profiles and required gate count”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M12.08-C008-T02 · Measurement method:** Choose how to observe each “Promotion profile definition” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M12.08-C008-T03 · Budget decision:** Select justified campaign and target-resource budgets for “Promotion profile definition”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M12.08-C008-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Promotion profile definition” cases for “Profiles and required gate count”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M12.08-C008-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Promotion profile definition” limit; preserve “A release is evaluated against explicitly selected scope”.
- [ ] **UC-M12.08-C008-T06 · Normal measurement:** Run or review the normal “Promotion profile definition” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M12.08-C008-T07 · At-limit measurement:** Exercise the “Promotion profile definition” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M12.08-C008-T08 · Over-limit measurement:** Exercise the “Promotion profile definition” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M12.08-C008-T09 · Uncovered-scope report:** List the “Promotion profile definition” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M12.08-C008-T10 · Limit evidence:** Publish the selected “Promotion profile definition” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M12.08-C009 · Diagnostics / review

**Original checklist item:** Report promotion profile definition results with executed, failed, skipped and unavailable cases separated; preserve the underlying observations and do not manufacture missing measurements.

- [ ] **UC-M12.08-C009-T01 · Result inventory:** Enumerate the required “Promotion profile definition” qualification cases and intended targets before aggregating results; keep the planned denominator visible.
- [ ] **UC-M12.08-C009-T02 · Verdict schema:** Define separate executed-pass, executed-fail, skipped, unavailable and untested outcomes for “Promotion profile definition”; document how incomplete cases block relevant claims.
- [ ] **UC-M12.08-C009-T03 · Identity fields:** Attach the actual target, fixture, configuration and revision identifiers to each “Promotion profile definition” result; do not attribute host-only evidence to a guest or another OS.
- [ ] **UC-M12.08-C009-T04 · Observation capture:** Capture bounded raw “Promotion profile definition” observations and harness errors; retain enough information to verify the reported oracle comparison.
- [ ] **UC-M12.08-C009-T05 · Aggregation rules:** Implement the “Promotion profile definition” count/reduction rule so failures and missing measurements cannot disappear; preserve “A release is evaluated against explicitly selected scope”.
- [ ] **UC-M12.08-C009-T06 · Failure visibility:** Feed a failing “Promotion profile definition” control through the report path; assert the exact failed case and underlying observation remain visible.
- [ ] **UC-M12.08-C009-T07 · Missing-result visibility:** Withhold a required “Promotion profile definition” measurement or target; verify the report uses unavailable/untested rather than a fabricated zero or passing value.
- [ ] **UC-M12.08-C009-T08 · Bounds and redaction:** Check “Promotion profile definition” report size and retention against “Profiles and required gate count”; remove secrets while retaining fixture and subject references.
- [ ] **UC-M12.08-C009-T09 · Report reconciliation:** Reconcile the “Promotion profile definition” summary with every underlying case record; account for the full planned denominator and all omitted scope.
- [ ] **UC-M12.08-C009-T10 · Qualification handoff:** Publish the “Promotion profile definition” report with measured observations, coverage limits and blockers; state which actual targets remain unqualified.

### UC-M12.08-C010 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for promotion profile definition; label unexecuted checks as untested.

- [ ] **UC-M12.08-C010-T01 · Evidence inventory:** List the “Promotion profile definition” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M12.08-C010-T02 · Artifact references:** Record the exact “Promotion profile definition” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M12.08-C010-T03 · Fixture references:** Attach the “Promotion profile definition” fixture IDs, input identities and oracle definition; preserve the source counterexample “Optional federation gates are silently treated as core offline requirements” as a distinct evidence case.
- [ ] **UC-M12.08-C010-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Promotion profile definition”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M12.08-C010-T05 · Environment record:** Record the actual “Promotion profile definition” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M12.08-C010-T06 · Expected versus observed:** Pair every “Promotion profile definition” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M12.08-C010-T07 · Failure and limit records:** Attach “Promotion profile definition” change/failure and bounds evidence where required; include uncovered “Profiles and required gate count” and unresolved violations of “A release is evaluated against explicitly selected scope”.
- [ ] **UC-M12.08-C010-T08 · Evidence hygiene:** Check the “Promotion profile definition” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M12.08-C010-T09 · Reproduction review:** Have the “Promotion profile definition” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M12.08-C010-T10 · Acceptance linkage:** Link the “Promotion profile definition” evidence to its parent and UC-M12.08 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 02. Gate classification

**Source delivery:** Classify gates as mandatory, optional or justified not applicable.

**Source invariant:** A required skipped gate cannot count as a pass.

**Source negative case:** An unexecuted native test is labeled not applicable without justification.

**Source bounded quantities:** Gate records and classification reviews.

### UC-M12.08-C011 · Contract

**Original checklist item:** Define the qualification objective for gate classification, including the actual target implementation, prerequisites, observable oracle and explicit exclusions.

- [ ] **UC-M12.08-C011-T01 · Scope statement:** Write the qualification question for “Gate classification”; identify the actual target, claimed capability and observations that can answer that question.
- [ ] **UC-M12.08-C011-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Gate classification”; record each producer, representation and missing-value meaning.
- [ ] **UC-M12.08-C011-T03 · Output inventory:** List the outputs of “Gate classification” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M12.08-C011-T04 · Field dictionary:** Create a field-and-term dictionary for “Gate classification”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M12.08-C011-T05 · Prerequisite contract:** Map “Gate classification” to the source component prerequisites (UC-M09.05, UC-M09.07, UC-M12.01, UC-M12.02, UC-M12.03, UC-M12.04); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M12.08-C011-T06 · Authority map:** Identify who may produce, change and consume “Gate classification”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M12.08-C011-T07 · Invariant clause:** Add a normative clause for “Gate classification” that preserves “A required skipped gate cannot count as a pass”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M12.08-C011-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Gate classification”; include the source counterexample “An unexecuted native test is labeled not applicable without justification” and the intended safe disposition.
- [ ] **UC-M12.08-C011-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Gate records and classification reviews” in the “Gate classification” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M12.08-C011-T10 · Contract review:** Review the “Gate classification” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M12.08-C012 · Delivery

**Original checklist item:** Classify gates as mandatory, optional or justified not applicable.

- [ ] **UC-M12.08-C012-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Gate classification”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M12.08-C012-T02 · Change plan:** Break the source delivery for “Gate classification” into concrete edit targets and reviewable outputs; keep the UC-M12.08 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M12.08-C012-T03 · Core artifact:** Create the “Gate classification” model, schema or inventory that realizes this source instruction: Classify gates as mandatory, optional or justified not applicable.
- [ ] **UC-M12.08-C012-T04 · Concrete realization:** Populate “Gate classification” with one concrete worked case; map every required entity or field to its source and flag any unmapped entry.
- [ ] **UC-M12.08-C012-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Gate classification” needed to preserve “A required skipped gate cannot count as a pass”; record an enforcement gap where only a model exists.
- [ ] **UC-M12.08-C012-T06 · Dependency connection:** Connect the “Gate classification” qualification artifact to selected release profiles, typed assurance evidence and required/optional gate evaluation; record the target identity and what the harness actually exercises.
- [ ] **UC-M12.08-C012-T07 · Resource behavior:** Account for “Gate records and classification reviews” in “Gate classification”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M12.08-C012-T08 · Delivery check:** Run a known-valid control and a deliberately failing control for “Gate classification”; confirm the harness distinguishes their observed outcomes.
- [ ] **UC-M12.08-C012-T09 · Patch review:** Review the “Gate classification” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M12.08-C012-T10 · Delivery handoff:** Publish the “Gate classification” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M12.08-C013 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: A required skipped gate cannot count as a pass. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M12.08-C013-T01 · Named property:** Create a stable property/check name under this parent for “Gate classification”; copy its required invariant exactly: “A required skipped gate cannot count as a pass”.
- [ ] **UC-M12.08-C013-T02 · Observable terms:** Define each term in the “Gate classification” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M12.08-C013-T03 · Precondition set:** List the preconditions under which “A required skipped gate cannot count as a pass” must hold for “Gate classification”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M12.08-C013-T04 · Transition coverage:** Map the “Gate classification” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M12.08-C013-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Gate classification”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M12.08-C013-T06 · Satisfying fixture:** Create a concrete “Gate classification” case that satisfies “A required skipped gate cannot count as a pass”; record its expected observation before running the assertion or review.
- [ ] **UC-M12.08-C013-T07 · Violating fixture:** Create the source counterexample “An unexecuted native test is labeled not applicable without justification” for “Gate classification”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M12.08-C013-T08 · Enforcement evidence:** Exercise the “Gate classification” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M12.08-C013-T09 · Regression linkage:** Link the “Gate classification” property to changes in selected release profiles, typed assurance evidence and required/optional gate evaluation; record which dependency or contract changes require rerunning it.
- [ ] **UC-M12.08-C013-T10 · Property disposition:** Compare the satisfying and violating “Gate classification” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M12.08-C014 · Integration

**Original checklist item:** Integrate gate classification with selected release profiles, typed assurance evidence and required/optional gate evaluation; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M12.08-C014-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Gate classification” across selected release profiles, typed assurance evidence and required/optional gate evaluation; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M12.08-C014-T02 · Field mapping:** Map every “Gate classification” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M12.08-C014-T03 · Prerequisite identities:** Record the actual prerequisites for “Gate classification” (source dependency list: UC-M09.05, UC-M09.07, UC-M12.01, UC-M12.02, UC-M12.03, UC-M12.04); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M12.08-C014-T04 · Ownership agreement:** Specify who owns “Gate classification” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M12.08-C014-T05 · Handoff implementation:** Connect “Gate classification” through the mapped seam using the real adapter or explicit specification reference; preserve “A required skipped gate cannot count as a pass” across the handoff.
- [ ] **UC-M12.08-C014-T06 · Absent-input case:** Omit one required “Gate classification” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M12.08-C014-T07 · Stale-input case:** Supply an outdated “Gate classification” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M12.08-C014-T08 · Incompatible-input case:** Supply an incompatible “Gate classification” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M12.08-C014-T09 · Valid integration trace:** Run a valid “Gate classification” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M12.08-C014-T10 · Seam review:** Reconcile the “Gate classification” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M12.08-C015 · Valid-case test

**Original checklist item:** Run a known-valid control for gate classification; verify that the harness reaches its intended target and compare observed measurements or verdicts with predeclared expectations.

- [ ] **UC-M12.08-C015-T01 · Valid fixture choice:** Choose a known-valid control for “Gate classification”; document why it should pass and how it proves the harness reaches the intended target.
- [ ] **UC-M12.08-C015-T02 · Expected-result oracle:** Specify the “Gate classification” expected result independently of the implementation output; include the property “A required skipped gate cannot count as a pass” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M12.08-C015-T03 · Fixture material:** Create the concrete “Gate classification” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M12.08-C015-T04 · Target preparation:** Prepare the “Gate classification” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M12.08-C015-T05 · Initial-state record:** Record the initial “Gate classification” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M12.08-C015-T06 · Valid-path execution:** Run the “Gate classification” known-valid control on the identified target; retain enough observations to prove the correct target was exercised.
- [ ] **UC-M12.08-C015-T07 · Outcome comparison:** Compare every declared “Gate classification” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M12.08-C015-T08 · State and bounds check:** Inspect the “Gate classification” ownership/state effects and actual use of “Gate records and classification reviews”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M12.08-C015-T09 · Repeatability check:** Repeat the same “Gate classification” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M12.08-C015-T10 · Positive evidence:** Attach the “Gate classification” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M12.08-C016 · Negative test

**Original checklist item:** Negative case: An unexecuted native test is labeled not applicable without justification. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M12.08-C016-T01 · Adverse-case definition:** Create a test record for the exact “Gate classification” source counterexample: “An unexecuted native test is labeled not applicable without justification”; state which precondition or invariant it challenges.
- [ ] **UC-M12.08-C016-T02 · Safe fixture boundary:** Define the contained test boundary for “Gate classification”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M12.08-C016-T03 · Valid control:** Construct a valid “Gate classification” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M12.08-C016-T04 · Minimal adverse input:** Derive the “Gate classification” adverse fixture from the control with the smallest documented change needed to reproduce “An unexecuted native test is labeled not applicable without justification”; retain that change as reproducible data.
- [ ] **UC-M12.08-C016-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Gate classification”; require “A required skipped gate cannot count as a pass” and forbid a false-success verdict.
- [ ] **UC-M12.08-C016-T06 · Adverse execution:** Exercise the “Gate classification” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M12.08-C016-T07 · Effect inspection:** Inspect “Gate classification” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M12.08-C016-T08 · Refusal versus failure:** Confirm the “Gate classification” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M12.08-C016-T09 · Reset and retention:** Restore only the disposable “Gate classification” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M12.08-C016-T10 · Negative regression:** Register the “Gate classification” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M12.08-C017 · Change / failure test

**Original checklist item:** Exercise gate classification when a required gate is skipped, stale or supported only by a declaration; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M12.08-C017-T01 · Scenario record:** Write the “Gate classification” change/failure scenario exactly as supplied: a required gate is skipped, stale or supported only by a declaration; identify the property that must remain true: “A required skipped gate cannot count as a pass”.
- [ ] **UC-M12.08-C017-T02 · Baseline capture:** Create a known-valid “Gate classification” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M12.08-C017-T03 · Injection map:** Locate the “Gate classification” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M12.08-C017-T04 · Disposition oracle:** Define the legal intermediate and final “Gate classification” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M12.08-C017-T05 · Controlled trigger:** Introduce the controlled “Gate classification” scenario in the disposable fixture: a required gate is skipped, stale or supported only by a declaration; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M12.08-C017-T06 · Intermediate inspection:** Inspect the “Gate classification” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M12.08-C017-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Gate classification”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M12.08-C017-T08 · Stale-evidence cleanup:** Invalidate superseded “Gate classification” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M12.08-C017-T09 · Repeat and compare:** Repeat the selected “Gate classification” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M12.08-C017-T10 · Failure evidence:** Publish the “Gate classification” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M12.08-C018 · Bounds

**Original checklist item:** Set a documented campaign budget for gate records and classification reviews; record actual consumption, incomplete coverage and the disposition when the budget is exhausted.

- [ ] **UC-M12.08-C018-T01 · Quantity inventory:** Create a measurement inventory for “Gate classification”: “Gate records and classification reviews”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M12.08-C018-T02 · Measurement method:** Choose how to observe each “Gate classification” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M12.08-C018-T03 · Budget decision:** Select justified campaign and target-resource budgets for “Gate classification”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M12.08-C018-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Gate classification” cases for “Gate records and classification reviews”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M12.08-C018-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Gate classification” limit; preserve “A required skipped gate cannot count as a pass”.
- [ ] **UC-M12.08-C018-T06 · Normal measurement:** Run or review the normal “Gate classification” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M12.08-C018-T07 · At-limit measurement:** Exercise the “Gate classification” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M12.08-C018-T08 · Over-limit measurement:** Exercise the “Gate classification” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M12.08-C018-T09 · Uncovered-scope report:** List the “Gate classification” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M12.08-C018-T10 · Limit evidence:** Publish the selected “Gate classification” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M12.08-C019 · Diagnostics / review

**Original checklist item:** Report gate classification results with executed, failed, skipped and unavailable cases separated; preserve the underlying observations and do not manufacture missing measurements.

- [ ] **UC-M12.08-C019-T01 · Result inventory:** Enumerate the required “Gate classification” qualification cases and intended targets before aggregating results; keep the planned denominator visible.
- [ ] **UC-M12.08-C019-T02 · Verdict schema:** Define separate executed-pass, executed-fail, skipped, unavailable and untested outcomes for “Gate classification”; document how incomplete cases block relevant claims.
- [ ] **UC-M12.08-C019-T03 · Identity fields:** Attach the actual target, fixture, configuration and revision identifiers to each “Gate classification” result; do not attribute host-only evidence to a guest or another OS.
- [ ] **UC-M12.08-C019-T04 · Observation capture:** Capture bounded raw “Gate classification” observations and harness errors; retain enough information to verify the reported oracle comparison.
- [ ] **UC-M12.08-C019-T05 · Aggregation rules:** Implement the “Gate classification” count/reduction rule so failures and missing measurements cannot disappear; preserve “A required skipped gate cannot count as a pass”.
- [ ] **UC-M12.08-C019-T06 · Failure visibility:** Feed a failing “Gate classification” control through the report path; assert the exact failed case and underlying observation remain visible.
- [ ] **UC-M12.08-C019-T07 · Missing-result visibility:** Withhold a required “Gate classification” measurement or target; verify the report uses unavailable/untested rather than a fabricated zero or passing value.
- [ ] **UC-M12.08-C019-T08 · Bounds and redaction:** Check “Gate classification” report size and retention against “Gate records and classification reviews”; remove secrets while retaining fixture and subject references.
- [ ] **UC-M12.08-C019-T09 · Report reconciliation:** Reconcile the “Gate classification” summary with every underlying case record; account for the full planned denominator and all omitted scope.
- [ ] **UC-M12.08-C019-T10 · Qualification handoff:** Publish the “Gate classification” report with measured observations, coverage limits and blockers; state which actual targets remain unqualified.

### UC-M12.08-C020 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for gate classification; label unexecuted checks as untested.

- [ ] **UC-M12.08-C020-T01 · Evidence inventory:** List the “Gate classification” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M12.08-C020-T02 · Artifact references:** Record the exact “Gate classification” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M12.08-C020-T03 · Fixture references:** Attach the “Gate classification” fixture IDs, input identities and oracle definition; preserve the source counterexample “An unexecuted native test is labeled not applicable without justification” as a distinct evidence case.
- [ ] **UC-M12.08-C020-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Gate classification”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M12.08-C020-T05 · Environment record:** Record the actual “Gate classification” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M12.08-C020-T06 · Expected versus observed:** Pair every “Gate classification” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M12.08-C020-T07 · Failure and limit records:** Attach “Gate classification” change/failure and bounds evidence where required; include uncovered “Gate records and classification reviews” and unresolved violations of “A required skipped gate cannot count as a pass”.
- [ ] **UC-M12.08-C020-T08 · Evidence hygiene:** Check the “Gate classification” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M12.08-C020-T09 · Reproduction review:** Have the “Gate classification” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M12.08-C020-T10 · Acceptance linkage:** Link the “Gate classification” evidence to its parent and UC-M12.08 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 03. Evidence requirements

**Source delivery:** Require implementation, executable tests, observed results and negative evidence per completed component.

**Source invariant:** A checked box or source filename alone cannot prove completion.

**Source negative case:** A component is marked done because its planned file exists.

**Source bounded quantities:** Components and evidence references.

### UC-M12.08-C021 · Contract

**Original checklist item:** Define the qualification objective for evidence requirements, including the actual target implementation, prerequisites, observable oracle and explicit exclusions.

- [ ] **UC-M12.08-C021-T01 · Scope statement:** Write the qualification question for “Evidence requirements”; identify the actual target, claimed capability and observations that can answer that question.
- [ ] **UC-M12.08-C021-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Evidence requirements”; record each producer, representation and missing-value meaning.
- [ ] **UC-M12.08-C021-T03 · Output inventory:** List the outputs of “Evidence requirements” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M12.08-C021-T04 · Field dictionary:** Create a field-and-term dictionary for “Evidence requirements”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M12.08-C021-T05 · Prerequisite contract:** Map “Evidence requirements” to the source component prerequisites (UC-M09.05, UC-M09.07, UC-M12.01, UC-M12.02, UC-M12.03, UC-M12.04); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M12.08-C021-T06 · Authority map:** Identify who may produce, change and consume “Evidence requirements”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M12.08-C021-T07 · Invariant clause:** Add a normative clause for “Evidence requirements” that preserves “A checked box or source filename alone cannot prove completion”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M12.08-C021-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Evidence requirements”; include the source counterexample “A component is marked done because its planned file exists” and the intended safe disposition.
- [ ] **UC-M12.08-C021-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Components and evidence references” in the “Evidence requirements” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M12.08-C021-T10 · Contract review:** Review the “Evidence requirements” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M12.08-C022 · Delivery

**Original checklist item:** Require implementation, executable tests, observed results and negative evidence per completed component.

- [ ] **UC-M12.08-C022-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Evidence requirements”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M12.08-C022-T02 · Change plan:** Break the source delivery for “Evidence requirements” into concrete edit targets and reviewable outputs; keep the UC-M12.08 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M12.08-C022-T03 · Core artifact:** Implement the smallest selected-profile change for “Evidence requirements” that realizes this source instruction: Require implementation, executable tests, observed results and negative evidence per completed component.
- [ ] **UC-M12.08-C022-T04 · Concrete realization:** Trace “Evidence requirements” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M12.08-C022-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Evidence requirements” needed to preserve “A checked box or source filename alone cannot prove completion”; record an enforcement gap where only a model exists.
- [ ] **UC-M12.08-C022-T06 · Dependency connection:** Connect the “Evidence requirements” qualification artifact to selected release profiles, typed assurance evidence and required/optional gate evaluation; record the target identity and what the harness actually exercises.
- [ ] **UC-M12.08-C022-T07 · Resource behavior:** Account for “Components and evidence references” in “Evidence requirements”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M12.08-C022-T08 · Delivery check:** Run a known-valid control and a deliberately failing control for “Evidence requirements”; confirm the harness distinguishes their observed outcomes.
- [ ] **UC-M12.08-C022-T09 · Patch review:** Review the “Evidence requirements” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M12.08-C022-T10 · Delivery handoff:** Publish the “Evidence requirements” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M12.08-C023 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: A checked box or source filename alone cannot prove completion. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M12.08-C023-T01 · Named property:** Create a stable property/check name under this parent for “Evidence requirements”; copy its required invariant exactly: “A checked box or source filename alone cannot prove completion”.
- [ ] **UC-M12.08-C023-T02 · Observable terms:** Define each term in the “Evidence requirements” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M12.08-C023-T03 · Precondition set:** List the preconditions under which “A checked box or source filename alone cannot prove completion” must hold for “Evidence requirements”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M12.08-C023-T04 · Transition coverage:** Map the “Evidence requirements” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M12.08-C023-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Evidence requirements”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M12.08-C023-T06 · Satisfying fixture:** Create a concrete “Evidence requirements” case that satisfies “A checked box or source filename alone cannot prove completion”; record its expected observation before running the assertion or review.
- [ ] **UC-M12.08-C023-T07 · Violating fixture:** Create the source counterexample “A component is marked done because its planned file exists” for “Evidence requirements”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M12.08-C023-T08 · Enforcement evidence:** Exercise the “Evidence requirements” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M12.08-C023-T09 · Regression linkage:** Link the “Evidence requirements” property to changes in selected release profiles, typed assurance evidence and required/optional gate evaluation; record which dependency or contract changes require rerunning it.
- [ ] **UC-M12.08-C023-T10 · Property disposition:** Compare the satisfying and violating “Evidence requirements” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M12.08-C024 · Integration

**Original checklist item:** Integrate evidence requirements with selected release profiles, typed assurance evidence and required/optional gate evaluation; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M12.08-C024-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Evidence requirements” across selected release profiles, typed assurance evidence and required/optional gate evaluation; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M12.08-C024-T02 · Field mapping:** Map every “Evidence requirements” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M12.08-C024-T03 · Prerequisite identities:** Record the actual prerequisites for “Evidence requirements” (source dependency list: UC-M09.05, UC-M09.07, UC-M12.01, UC-M12.02, UC-M12.03, UC-M12.04); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M12.08-C024-T04 · Ownership agreement:** Specify who owns “Evidence requirements” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M12.08-C024-T05 · Handoff implementation:** Connect “Evidence requirements” through the mapped seam using the real adapter or explicit specification reference; preserve “A checked box or source filename alone cannot prove completion” across the handoff.
- [ ] **UC-M12.08-C024-T06 · Absent-input case:** Omit one required “Evidence requirements” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M12.08-C024-T07 · Stale-input case:** Supply an outdated “Evidence requirements” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M12.08-C024-T08 · Incompatible-input case:** Supply an incompatible “Evidence requirements” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M12.08-C024-T09 · Valid integration trace:** Run a valid “Evidence requirements” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M12.08-C024-T10 · Seam review:** Reconcile the “Evidence requirements” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M12.08-C025 · Valid-case test

**Original checklist item:** Run a known-valid control for evidence requirements; verify that the harness reaches its intended target and compare observed measurements or verdicts with predeclared expectations.

- [ ] **UC-M12.08-C025-T01 · Valid fixture choice:** Choose a known-valid control for “Evidence requirements”; document why it should pass and how it proves the harness reaches the intended target.
- [ ] **UC-M12.08-C025-T02 · Expected-result oracle:** Specify the “Evidence requirements” expected result independently of the implementation output; include the property “A checked box or source filename alone cannot prove completion” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M12.08-C025-T03 · Fixture material:** Create the concrete “Evidence requirements” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M12.08-C025-T04 · Target preparation:** Prepare the “Evidence requirements” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M12.08-C025-T05 · Initial-state record:** Record the initial “Evidence requirements” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M12.08-C025-T06 · Valid-path execution:** Run the “Evidence requirements” known-valid control on the identified target; retain enough observations to prove the correct target was exercised.
- [ ] **UC-M12.08-C025-T07 · Outcome comparison:** Compare every declared “Evidence requirements” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M12.08-C025-T08 · State and bounds check:** Inspect the “Evidence requirements” ownership/state effects and actual use of “Components and evidence references”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M12.08-C025-T09 · Repeatability check:** Repeat the same “Evidence requirements” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M12.08-C025-T10 · Positive evidence:** Attach the “Evidence requirements” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M12.08-C026 · Negative test

**Original checklist item:** Negative case: A component is marked done because its planned file exists. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M12.08-C026-T01 · Adverse-case definition:** Create a test record for the exact “Evidence requirements” source counterexample: “A component is marked done because its planned file exists”; state which precondition or invariant it challenges.
- [ ] **UC-M12.08-C026-T02 · Safe fixture boundary:** Define the contained test boundary for “Evidence requirements”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M12.08-C026-T03 · Valid control:** Construct a valid “Evidence requirements” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M12.08-C026-T04 · Minimal adverse input:** Derive the “Evidence requirements” adverse fixture from the control with the smallest documented change needed to reproduce “A component is marked done because its planned file exists”; retain that change as reproducible data.
- [ ] **UC-M12.08-C026-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Evidence requirements”; require “A checked box or source filename alone cannot prove completion” and forbid a false-success verdict.
- [ ] **UC-M12.08-C026-T06 · Adverse execution:** Exercise the “Evidence requirements” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M12.08-C026-T07 · Effect inspection:** Inspect “Evidence requirements” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M12.08-C026-T08 · Refusal versus failure:** Confirm the “Evidence requirements” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M12.08-C026-T09 · Reset and retention:** Restore only the disposable “Evidence requirements” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M12.08-C026-T10 · Negative regression:** Register the “Evidence requirements” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M12.08-C027 · Change / failure test

**Original checklist item:** Exercise evidence requirements when a required gate is skipped, stale or supported only by a declaration; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M12.08-C027-T01 · Scenario record:** Write the “Evidence requirements” change/failure scenario exactly as supplied: a required gate is skipped, stale or supported only by a declaration; identify the property that must remain true: “A checked box or source filename alone cannot prove completion”.
- [ ] **UC-M12.08-C027-T02 · Baseline capture:** Create a known-valid “Evidence requirements” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M12.08-C027-T03 · Injection map:** Locate the “Evidence requirements” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M12.08-C027-T04 · Disposition oracle:** Define the legal intermediate and final “Evidence requirements” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M12.08-C027-T05 · Controlled trigger:** Introduce the controlled “Evidence requirements” scenario in the disposable fixture: a required gate is skipped, stale or supported only by a declaration; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M12.08-C027-T06 · Intermediate inspection:** Inspect the “Evidence requirements” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M12.08-C027-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Evidence requirements”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M12.08-C027-T08 · Stale-evidence cleanup:** Invalidate superseded “Evidence requirements” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M12.08-C027-T09 · Repeat and compare:** Repeat the selected “Evidence requirements” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M12.08-C027-T10 · Failure evidence:** Publish the “Evidence requirements” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M12.08-C028 · Bounds

**Original checklist item:** Set a documented campaign budget for components and evidence references; record actual consumption, incomplete coverage and the disposition when the budget is exhausted.

- [ ] **UC-M12.08-C028-T01 · Quantity inventory:** Create a measurement inventory for “Evidence requirements”: “Components and evidence references”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M12.08-C028-T02 · Measurement method:** Choose how to observe each “Evidence requirements” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M12.08-C028-T03 · Budget decision:** Select justified campaign and target-resource budgets for “Evidence requirements”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M12.08-C028-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Evidence requirements” cases for “Components and evidence references”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M12.08-C028-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Evidence requirements” limit; preserve “A checked box or source filename alone cannot prove completion”.
- [ ] **UC-M12.08-C028-T06 · Normal measurement:** Run or review the normal “Evidence requirements” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M12.08-C028-T07 · At-limit measurement:** Exercise the “Evidence requirements” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M12.08-C028-T08 · Over-limit measurement:** Exercise the “Evidence requirements” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M12.08-C028-T09 · Uncovered-scope report:** List the “Evidence requirements” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M12.08-C028-T10 · Limit evidence:** Publish the selected “Evidence requirements” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M12.08-C029 · Diagnostics / review

**Original checklist item:** Report evidence requirements results with executed, failed, skipped and unavailable cases separated; preserve the underlying observations and do not manufacture missing measurements.

- [ ] **UC-M12.08-C029-T01 · Result inventory:** Enumerate the required “Evidence requirements” qualification cases and intended targets before aggregating results; keep the planned denominator visible.
- [ ] **UC-M12.08-C029-T02 · Verdict schema:** Define separate executed-pass, executed-fail, skipped, unavailable and untested outcomes for “Evidence requirements”; document how incomplete cases block relevant claims.
- [ ] **UC-M12.08-C029-T03 · Identity fields:** Attach the actual target, fixture, configuration and revision identifiers to each “Evidence requirements” result; do not attribute host-only evidence to a guest or another OS.
- [ ] **UC-M12.08-C029-T04 · Observation capture:** Capture bounded raw “Evidence requirements” observations and harness errors; retain enough information to verify the reported oracle comparison.
- [ ] **UC-M12.08-C029-T05 · Aggregation rules:** Implement the “Evidence requirements” count/reduction rule so failures and missing measurements cannot disappear; preserve “A checked box or source filename alone cannot prove completion”.
- [ ] **UC-M12.08-C029-T06 · Failure visibility:** Feed a failing “Evidence requirements” control through the report path; assert the exact failed case and underlying observation remain visible.
- [ ] **UC-M12.08-C029-T07 · Missing-result visibility:** Withhold a required “Evidence requirements” measurement or target; verify the report uses unavailable/untested rather than a fabricated zero or passing value.
- [ ] **UC-M12.08-C029-T08 · Bounds and redaction:** Check “Evidence requirements” report size and retention against “Components and evidence references”; remove secrets while retaining fixture and subject references.
- [ ] **UC-M12.08-C029-T09 · Report reconciliation:** Reconcile the “Evidence requirements” summary with every underlying case record; account for the full planned denominator and all omitted scope.
- [ ] **UC-M12.08-C029-T10 · Qualification handoff:** Publish the “Evidence requirements” report with measured observations, coverage limits and blockers; state which actual targets remain unqualified.

### UC-M12.08-C030 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for evidence requirements; label unexecuted checks as untested.

- [ ] **UC-M12.08-C030-T01 · Evidence inventory:** List the “Evidence requirements” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M12.08-C030-T02 · Artifact references:** Record the exact “Evidence requirements” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M12.08-C030-T03 · Fixture references:** Attach the “Evidence requirements” fixture IDs, input identities and oracle definition; preserve the source counterexample “A component is marked done because its planned file exists” as a distinct evidence case.
- [ ] **UC-M12.08-C030-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Evidence requirements”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M12.08-C030-T05 · Environment record:** Record the actual “Evidence requirements” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M12.08-C030-T06 · Expected versus observed:** Pair every “Evidence requirements” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M12.08-C030-T07 · Failure and limit records:** Attach “Evidence requirements” change/failure and bounds evidence where required; include uncovered “Components and evidence references” and unresolved violations of “A checked box or source filename alone cannot prove completion”.
- [ ] **UC-M12.08-C030-T08 · Evidence hygiene:** Check the “Evidence requirements” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M12.08-C030-T09 · Reproduction review:** Have the “Evidence requirements” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M12.08-C030-T10 · Acceptance linkage:** Link the “Evidence requirements” evidence to its parent and UC-M12.08 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 04. Assurance class requirements

**Source delivery:** Map required gates to integrity, authenticity, semantics and isolation evidence.

**Source invariant:** A witness pass cannot substitute for application or isolation qualification.

**Source negative case:** A deterministic hash approves a required isolation gate.

**Source bounded quantities:** Assurance mappings and accepted evidence types.

### UC-M12.08-C031 · Contract

**Original checklist item:** Define the qualification objective for assurance class requirements, including the actual target implementation, prerequisites, observable oracle and explicit exclusions.

- [ ] **UC-M12.08-C031-T01 · Scope statement:** Write the qualification question for “Assurance class requirements”; identify the actual target, claimed capability and observations that can answer that question.
- [ ] **UC-M12.08-C031-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Assurance class requirements”; record each producer, representation and missing-value meaning.
- [ ] **UC-M12.08-C031-T03 · Output inventory:** List the outputs of “Assurance class requirements” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M12.08-C031-T04 · Field dictionary:** Create a field-and-term dictionary for “Assurance class requirements”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M12.08-C031-T05 · Prerequisite contract:** Map “Assurance class requirements” to the source component prerequisites (UC-M09.05, UC-M09.07, UC-M12.01, UC-M12.02, UC-M12.03, UC-M12.04); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M12.08-C031-T06 · Authority map:** Identify who may produce, change and consume “Assurance class requirements”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M12.08-C031-T07 · Invariant clause:** Add a normative clause for “Assurance class requirements” that preserves “A witness pass cannot substitute for application or isolation qualification”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M12.08-C031-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Assurance class requirements”; include the source counterexample “A deterministic hash approves a required isolation gate” and the intended safe disposition.
- [ ] **UC-M12.08-C031-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Assurance mappings and accepted evidence types” in the “Assurance class requirements” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M12.08-C031-T10 · Contract review:** Review the “Assurance class requirements” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M12.08-C032 · Delivery

**Original checklist item:** Map required gates to integrity, authenticity, semantics and isolation evidence.

- [ ] **UC-M12.08-C032-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Assurance class requirements”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M12.08-C032-T02 · Change plan:** Break the source delivery for “Assurance class requirements” into concrete edit targets and reviewable outputs; keep the UC-M12.08 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M12.08-C032-T03 · Core artifact:** Create the “Assurance class requirements” model, schema or inventory that realizes this source instruction: Map required gates to integrity, authenticity, semantics and isolation evidence.
- [ ] **UC-M12.08-C032-T04 · Concrete realization:** Populate “Assurance class requirements” with one concrete worked case; map every required entity or field to its source and flag any unmapped entry.
- [ ] **UC-M12.08-C032-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Assurance class requirements” needed to preserve “A witness pass cannot substitute for application or isolation qualification”; record an enforcement gap where only a model exists.
- [ ] **UC-M12.08-C032-T06 · Dependency connection:** Connect the “Assurance class requirements” qualification artifact to selected release profiles, typed assurance evidence and required/optional gate evaluation; record the target identity and what the harness actually exercises.
- [ ] **UC-M12.08-C032-T07 · Resource behavior:** Account for “Assurance mappings and accepted evidence types” in “Assurance class requirements”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M12.08-C032-T08 · Delivery check:** Run a known-valid control and a deliberately failing control for “Assurance class requirements”; confirm the harness distinguishes their observed outcomes.
- [ ] **UC-M12.08-C032-T09 · Patch review:** Review the “Assurance class requirements” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M12.08-C032-T10 · Delivery handoff:** Publish the “Assurance class requirements” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M12.08-C033 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: A witness pass cannot substitute for application or isolation qualification. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M12.08-C033-T01 · Named property:** Create a stable property/check name under this parent for “Assurance class requirements”; copy its required invariant exactly: “A witness pass cannot substitute for application or isolation qualification”.
- [ ] **UC-M12.08-C033-T02 · Observable terms:** Define each term in the “Assurance class requirements” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M12.08-C033-T03 · Precondition set:** List the preconditions under which “A witness pass cannot substitute for application or isolation qualification” must hold for “Assurance class requirements”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M12.08-C033-T04 · Transition coverage:** Map the “Assurance class requirements” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M12.08-C033-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Assurance class requirements”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M12.08-C033-T06 · Satisfying fixture:** Create a concrete “Assurance class requirements” case that satisfies “A witness pass cannot substitute for application or isolation qualification”; record its expected observation before running the assertion or review.
- [ ] **UC-M12.08-C033-T07 · Violating fixture:** Create the source counterexample “A deterministic hash approves a required isolation gate” for “Assurance class requirements”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M12.08-C033-T08 · Enforcement evidence:** Exercise the “Assurance class requirements” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M12.08-C033-T09 · Regression linkage:** Link the “Assurance class requirements” property to changes in selected release profiles, typed assurance evidence and required/optional gate evaluation; record which dependency or contract changes require rerunning it.
- [ ] **UC-M12.08-C033-T10 · Property disposition:** Compare the satisfying and violating “Assurance class requirements” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M12.08-C034 · Integration

**Original checklist item:** Integrate assurance class requirements with selected release profiles, typed assurance evidence and required/optional gate evaluation; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M12.08-C034-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Assurance class requirements” across selected release profiles, typed assurance evidence and required/optional gate evaluation; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M12.08-C034-T02 · Field mapping:** Map every “Assurance class requirements” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M12.08-C034-T03 · Prerequisite identities:** Record the actual prerequisites for “Assurance class requirements” (source dependency list: UC-M09.05, UC-M09.07, UC-M12.01, UC-M12.02, UC-M12.03, UC-M12.04); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M12.08-C034-T04 · Ownership agreement:** Specify who owns “Assurance class requirements” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M12.08-C034-T05 · Handoff implementation:** Connect “Assurance class requirements” through the mapped seam using the real adapter or explicit specification reference; preserve “A witness pass cannot substitute for application or isolation qualification” across the handoff.
- [ ] **UC-M12.08-C034-T06 · Absent-input case:** Omit one required “Assurance class requirements” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M12.08-C034-T07 · Stale-input case:** Supply an outdated “Assurance class requirements” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M12.08-C034-T08 · Incompatible-input case:** Supply an incompatible “Assurance class requirements” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M12.08-C034-T09 · Valid integration trace:** Run a valid “Assurance class requirements” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M12.08-C034-T10 · Seam review:** Reconcile the “Assurance class requirements” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M12.08-C035 · Valid-case test

**Original checklist item:** Run a known-valid control for assurance class requirements; verify that the harness reaches its intended target and compare observed measurements or verdicts with predeclared expectations.

- [ ] **UC-M12.08-C035-T01 · Valid fixture choice:** Choose a known-valid control for “Assurance class requirements”; document why it should pass and how it proves the harness reaches the intended target.
- [ ] **UC-M12.08-C035-T02 · Expected-result oracle:** Specify the “Assurance class requirements” expected result independently of the implementation output; include the property “A witness pass cannot substitute for application or isolation qualification” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M12.08-C035-T03 · Fixture material:** Create the concrete “Assurance class requirements” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M12.08-C035-T04 · Target preparation:** Prepare the “Assurance class requirements” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M12.08-C035-T05 · Initial-state record:** Record the initial “Assurance class requirements” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M12.08-C035-T06 · Valid-path execution:** Run the “Assurance class requirements” known-valid control on the identified target; retain enough observations to prove the correct target was exercised.
- [ ] **UC-M12.08-C035-T07 · Outcome comparison:** Compare every declared “Assurance class requirements” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M12.08-C035-T08 · State and bounds check:** Inspect the “Assurance class requirements” ownership/state effects and actual use of “Assurance mappings and accepted evidence types”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M12.08-C035-T09 · Repeatability check:** Repeat the same “Assurance class requirements” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M12.08-C035-T10 · Positive evidence:** Attach the “Assurance class requirements” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M12.08-C036 · Negative test

**Original checklist item:** Negative case: A deterministic hash approves a required isolation gate. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M12.08-C036-T01 · Adverse-case definition:** Create a test record for the exact “Assurance class requirements” source counterexample: “A deterministic hash approves a required isolation gate”; state which precondition or invariant it challenges.
- [ ] **UC-M12.08-C036-T02 · Safe fixture boundary:** Define the contained test boundary for “Assurance class requirements”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M12.08-C036-T03 · Valid control:** Construct a valid “Assurance class requirements” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M12.08-C036-T04 · Minimal adverse input:** Derive the “Assurance class requirements” adverse fixture from the control with the smallest documented change needed to reproduce “A deterministic hash approves a required isolation gate”; retain that change as reproducible data.
- [ ] **UC-M12.08-C036-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Assurance class requirements”; require “A witness pass cannot substitute for application or isolation qualification” and forbid a false-success verdict.
- [ ] **UC-M12.08-C036-T06 · Adverse execution:** Exercise the “Assurance class requirements” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M12.08-C036-T07 · Effect inspection:** Inspect “Assurance class requirements” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M12.08-C036-T08 · Refusal versus failure:** Confirm the “Assurance class requirements” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M12.08-C036-T09 · Reset and retention:** Restore only the disposable “Assurance class requirements” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M12.08-C036-T10 · Negative regression:** Register the “Assurance class requirements” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M12.08-C037 · Change / failure test

**Original checklist item:** Exercise assurance class requirements when a required gate is skipped, stale or supported only by a declaration; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M12.08-C037-T01 · Scenario record:** Write the “Assurance class requirements” change/failure scenario exactly as supplied: a required gate is skipped, stale or supported only by a declaration; identify the property that must remain true: “A witness pass cannot substitute for application or isolation qualification”.
- [ ] **UC-M12.08-C037-T02 · Baseline capture:** Create a known-valid “Assurance class requirements” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M12.08-C037-T03 · Injection map:** Locate the “Assurance class requirements” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M12.08-C037-T04 · Disposition oracle:** Define the legal intermediate and final “Assurance class requirements” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M12.08-C037-T05 · Controlled trigger:** Introduce the controlled “Assurance class requirements” scenario in the disposable fixture: a required gate is skipped, stale or supported only by a declaration; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M12.08-C037-T06 · Intermediate inspection:** Inspect the “Assurance class requirements” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M12.08-C037-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Assurance class requirements”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M12.08-C037-T08 · Stale-evidence cleanup:** Invalidate superseded “Assurance class requirements” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M12.08-C037-T09 · Repeat and compare:** Repeat the selected “Assurance class requirements” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M12.08-C037-T10 · Failure evidence:** Publish the “Assurance class requirements” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M12.08-C038 · Bounds

**Original checklist item:** Set a documented campaign budget for assurance mappings and accepted evidence types; record actual consumption, incomplete coverage and the disposition when the budget is exhausted.

- [ ] **UC-M12.08-C038-T01 · Quantity inventory:** Create a measurement inventory for “Assurance class requirements”: “Assurance mappings and accepted evidence types”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M12.08-C038-T02 · Measurement method:** Choose how to observe each “Assurance class requirements” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M12.08-C038-T03 · Budget decision:** Select justified campaign and target-resource budgets for “Assurance class requirements”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M12.08-C038-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Assurance class requirements” cases for “Assurance mappings and accepted evidence types”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M12.08-C038-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Assurance class requirements” limit; preserve “A witness pass cannot substitute for application or isolation qualification”.
- [ ] **UC-M12.08-C038-T06 · Normal measurement:** Run or review the normal “Assurance class requirements” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M12.08-C038-T07 · At-limit measurement:** Exercise the “Assurance class requirements” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M12.08-C038-T08 · Over-limit measurement:** Exercise the “Assurance class requirements” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M12.08-C038-T09 · Uncovered-scope report:** List the “Assurance class requirements” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M12.08-C038-T10 · Limit evidence:** Publish the selected “Assurance class requirements” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M12.08-C039 · Diagnostics / review

**Original checklist item:** Report assurance class requirements results with executed, failed, skipped and unavailable cases separated; preserve the underlying observations and do not manufacture missing measurements.

- [ ] **UC-M12.08-C039-T01 · Result inventory:** Enumerate the required “Assurance class requirements” qualification cases and intended targets before aggregating results; keep the planned denominator visible.
- [ ] **UC-M12.08-C039-T02 · Verdict schema:** Define separate executed-pass, executed-fail, skipped, unavailable and untested outcomes for “Assurance class requirements”; document how incomplete cases block relevant claims.
- [ ] **UC-M12.08-C039-T03 · Identity fields:** Attach the actual target, fixture, configuration and revision identifiers to each “Assurance class requirements” result; do not attribute host-only evidence to a guest or another OS.
- [ ] **UC-M12.08-C039-T04 · Observation capture:** Capture bounded raw “Assurance class requirements” observations and harness errors; retain enough information to verify the reported oracle comparison.
- [ ] **UC-M12.08-C039-T05 · Aggregation rules:** Implement the “Assurance class requirements” count/reduction rule so failures and missing measurements cannot disappear; preserve “A witness pass cannot substitute for application or isolation qualification”.
- [ ] **UC-M12.08-C039-T06 · Failure visibility:** Feed a failing “Assurance class requirements” control through the report path; assert the exact failed case and underlying observation remain visible.
- [ ] **UC-M12.08-C039-T07 · Missing-result visibility:** Withhold a required “Assurance class requirements” measurement or target; verify the report uses unavailable/untested rather than a fabricated zero or passing value.
- [ ] **UC-M12.08-C039-T08 · Bounds and redaction:** Check “Assurance class requirements” report size and retention against “Assurance mappings and accepted evidence types”; remove secrets while retaining fixture and subject references.
- [ ] **UC-M12.08-C039-T09 · Report reconciliation:** Reconcile the “Assurance class requirements” summary with every underlying case record; account for the full planned denominator and all omitted scope.
- [ ] **UC-M12.08-C039-T10 · Qualification handoff:** Publish the “Assurance class requirements” report with measured observations, coverage limits and blockers; state which actual targets remain unqualified.

### UC-M12.08-C040 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for assurance class requirements; label unexecuted checks as untested.

- [ ] **UC-M12.08-C040-T01 · Evidence inventory:** List the “Assurance class requirements” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M12.08-C040-T02 · Artifact references:** Record the exact “Assurance class requirements” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M12.08-C040-T03 · Fixture references:** Attach the “Assurance class requirements” fixture IDs, input identities and oracle definition; preserve the source counterexample “A deterministic hash approves a required isolation gate” as a distinct evidence case.
- [ ] **UC-M12.08-C040-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Assurance class requirements”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M12.08-C040-T05 · Environment record:** Record the actual “Assurance class requirements” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M12.08-C040-T06 · Expected versus observed:** Pair every “Assurance class requirements” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M12.08-C040-T07 · Failure and limit records:** Attach “Assurance class requirements” change/failure and bounds evidence where required; include uncovered “Assurance mappings and accepted evidence types” and unresolved violations of “A witness pass cannot substitute for application or isolation qualification”.
- [ ] **UC-M12.08-C040-T08 · Evidence hygiene:** Check the “Assurance class requirements” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M12.08-C040-T09 · Reproduction review:** Have the “Assurance class requirements” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M12.08-C040-T10 · Acceptance linkage:** Link the “Assurance class requirements” evidence to its parent and UC-M12.08 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 05. Environment scope

**Source delivery:** Publish actual OS, hardware, backend and build environments exercised.

**Source invariant:** Untested platforms are not implicitly covered by another platform's result.

**Source negative case:** A Windows support statement relies solely on Linux testing.

**Source bounded quantities:** Environment matrix and result records.

### UC-M12.08-C041 · Contract

**Original checklist item:** Define the qualification objective for environment scope, including the actual target implementation, prerequisites, observable oracle and explicit exclusions.

- [ ] **UC-M12.08-C041-T01 · Scope statement:** Write the qualification question for “Environment scope”; identify the actual target, claimed capability and observations that can answer that question.
- [ ] **UC-M12.08-C041-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Environment scope”; record each producer, representation and missing-value meaning.
- [ ] **UC-M12.08-C041-T03 · Output inventory:** List the outputs of “Environment scope” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M12.08-C041-T04 · Field dictionary:** Create a field-and-term dictionary for “Environment scope”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M12.08-C041-T05 · Prerequisite contract:** Map “Environment scope” to the source component prerequisites (UC-M09.05, UC-M09.07, UC-M12.01, UC-M12.02, UC-M12.03, UC-M12.04); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M12.08-C041-T06 · Authority map:** Identify who may produce, change and consume “Environment scope”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M12.08-C041-T07 · Invariant clause:** Add a normative clause for “Environment scope” that preserves “Untested platforms are not implicitly covered by another platform's result”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M12.08-C041-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Environment scope”; include the source counterexample “A Windows support statement relies solely on Linux testing” and the intended safe disposition.
- [ ] **UC-M12.08-C041-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Environment matrix and result records” in the “Environment scope” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M12.08-C041-T10 · Contract review:** Review the “Environment scope” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M12.08-C042 · Delivery

**Original checklist item:** Publish actual OS, hardware, backend and build environments exercised.

- [ ] **UC-M12.08-C042-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Environment scope”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M12.08-C042-T02 · Change plan:** Break the source delivery for “Environment scope” into concrete edit targets and reviewable outputs; keep the UC-M12.08 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M12.08-C042-T03 · Core artifact:** Create the “Environment scope” output artifact for this source instruction: Publish actual OS, hardware, backend and build environments exercised.
- [ ] **UC-M12.08-C042-T04 · Concrete realization:** Populate the “Environment scope” artifact from identified observations; keep unknown, failed and unexecuted results distinct and exclude unapproved sensitive material.
- [ ] **UC-M12.08-C042-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Environment scope” needed to preserve “Untested platforms are not implicitly covered by another platform's result”; record an enforcement gap where only a model exists.
- [ ] **UC-M12.08-C042-T06 · Dependency connection:** Connect the “Environment scope” qualification artifact to selected release profiles, typed assurance evidence and required/optional gate evaluation; record the target identity and what the harness actually exercises.
- [ ] **UC-M12.08-C042-T07 · Resource behavior:** Account for “Environment matrix and result records” in “Environment scope”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M12.08-C042-T08 · Delivery check:** Run a known-valid control and a deliberately failing control for “Environment scope”; confirm the harness distinguishes their observed outcomes.
- [ ] **UC-M12.08-C042-T09 · Patch review:** Review the “Environment scope” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M12.08-C042-T10 · Delivery handoff:** Publish the “Environment scope” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M12.08-C043 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Untested platforms are not implicitly covered by another platform's result. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M12.08-C043-T01 · Named property:** Create a stable property/check name under this parent for “Environment scope”; copy its required invariant exactly: “Untested platforms are not implicitly covered by another platform's result”.
- [ ] **UC-M12.08-C043-T02 · Observable terms:** Define each term in the “Environment scope” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M12.08-C043-T03 · Precondition set:** List the preconditions under which “Untested platforms are not implicitly covered by another platform's result” must hold for “Environment scope”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M12.08-C043-T04 · Transition coverage:** Map the “Environment scope” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M12.08-C043-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Environment scope”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M12.08-C043-T06 · Satisfying fixture:** Create a concrete “Environment scope” case that satisfies “Untested platforms are not implicitly covered by another platform's result”; record its expected observation before running the assertion or review.
- [ ] **UC-M12.08-C043-T07 · Violating fixture:** Create the source counterexample “A Windows support statement relies solely on Linux testing” for “Environment scope”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M12.08-C043-T08 · Enforcement evidence:** Exercise the “Environment scope” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M12.08-C043-T09 · Regression linkage:** Link the “Environment scope” property to changes in selected release profiles, typed assurance evidence and required/optional gate evaluation; record which dependency or contract changes require rerunning it.
- [ ] **UC-M12.08-C043-T10 · Property disposition:** Compare the satisfying and violating “Environment scope” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M12.08-C044 · Integration

**Original checklist item:** Integrate environment scope with selected release profiles, typed assurance evidence and required/optional gate evaluation; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M12.08-C044-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Environment scope” across selected release profiles, typed assurance evidence and required/optional gate evaluation; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M12.08-C044-T02 · Field mapping:** Map every “Environment scope” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M12.08-C044-T03 · Prerequisite identities:** Record the actual prerequisites for “Environment scope” (source dependency list: UC-M09.05, UC-M09.07, UC-M12.01, UC-M12.02, UC-M12.03, UC-M12.04); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M12.08-C044-T04 · Ownership agreement:** Specify who owns “Environment scope” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M12.08-C044-T05 · Handoff implementation:** Connect “Environment scope” through the mapped seam using the real adapter or explicit specification reference; preserve “Untested platforms are not implicitly covered by another platform's result” across the handoff.
- [ ] **UC-M12.08-C044-T06 · Absent-input case:** Omit one required “Environment scope” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M12.08-C044-T07 · Stale-input case:** Supply an outdated “Environment scope” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M12.08-C044-T08 · Incompatible-input case:** Supply an incompatible “Environment scope” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M12.08-C044-T09 · Valid integration trace:** Run a valid “Environment scope” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M12.08-C044-T10 · Seam review:** Reconcile the “Environment scope” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M12.08-C045 · Valid-case test

**Original checklist item:** Run a known-valid control for environment scope; verify that the harness reaches its intended target and compare observed measurements or verdicts with predeclared expectations.

- [ ] **UC-M12.08-C045-T01 · Valid fixture choice:** Choose a known-valid control for “Environment scope”; document why it should pass and how it proves the harness reaches the intended target.
- [ ] **UC-M12.08-C045-T02 · Expected-result oracle:** Specify the “Environment scope” expected result independently of the implementation output; include the property “Untested platforms are not implicitly covered by another platform's result” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M12.08-C045-T03 · Fixture material:** Create the concrete “Environment scope” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M12.08-C045-T04 · Target preparation:** Prepare the “Environment scope” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M12.08-C045-T05 · Initial-state record:** Record the initial “Environment scope” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M12.08-C045-T06 · Valid-path execution:** Run the “Environment scope” known-valid control on the identified target; retain enough observations to prove the correct target was exercised.
- [ ] **UC-M12.08-C045-T07 · Outcome comparison:** Compare every declared “Environment scope” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M12.08-C045-T08 · State and bounds check:** Inspect the “Environment scope” ownership/state effects and actual use of “Environment matrix and result records”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M12.08-C045-T09 · Repeatability check:** Repeat the same “Environment scope” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M12.08-C045-T10 · Positive evidence:** Attach the “Environment scope” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M12.08-C046 · Negative test

**Original checklist item:** Negative case: A Windows support statement relies solely on Linux testing. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M12.08-C046-T01 · Adverse-case definition:** Create a test record for the exact “Environment scope” source counterexample: “A Windows support statement relies solely on Linux testing”; state which precondition or invariant it challenges.
- [ ] **UC-M12.08-C046-T02 · Safe fixture boundary:** Define the contained test boundary for “Environment scope”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M12.08-C046-T03 · Valid control:** Construct a valid “Environment scope” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M12.08-C046-T04 · Minimal adverse input:** Derive the “Environment scope” adverse fixture from the control with the smallest documented change needed to reproduce “A Windows support statement relies solely on Linux testing”; retain that change as reproducible data.
- [ ] **UC-M12.08-C046-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Environment scope”; require “Untested platforms are not implicitly covered by another platform's result” and forbid a false-success verdict.
- [ ] **UC-M12.08-C046-T06 · Adverse execution:** Exercise the “Environment scope” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M12.08-C046-T07 · Effect inspection:** Inspect “Environment scope” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M12.08-C046-T08 · Refusal versus failure:** Confirm the “Environment scope” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M12.08-C046-T09 · Reset and retention:** Restore only the disposable “Environment scope” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M12.08-C046-T10 · Negative regression:** Register the “Environment scope” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M12.08-C047 · Change / failure test

**Original checklist item:** Exercise environment scope when a required gate is skipped, stale or supported only by a declaration; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M12.08-C047-T01 · Scenario record:** Write the “Environment scope” change/failure scenario exactly as supplied: a required gate is skipped, stale or supported only by a declaration; identify the property that must remain true: “Untested platforms are not implicitly covered by another platform's result”.
- [ ] **UC-M12.08-C047-T02 · Baseline capture:** Create a known-valid “Environment scope” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M12.08-C047-T03 · Injection map:** Locate the “Environment scope” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M12.08-C047-T04 · Disposition oracle:** Define the legal intermediate and final “Environment scope” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M12.08-C047-T05 · Controlled trigger:** Introduce the controlled “Environment scope” scenario in the disposable fixture: a required gate is skipped, stale or supported only by a declaration; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M12.08-C047-T06 · Intermediate inspection:** Inspect the “Environment scope” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M12.08-C047-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Environment scope”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M12.08-C047-T08 · Stale-evidence cleanup:** Invalidate superseded “Environment scope” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M12.08-C047-T09 · Repeat and compare:** Repeat the selected “Environment scope” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M12.08-C047-T10 · Failure evidence:** Publish the “Environment scope” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M12.08-C048 · Bounds

**Original checklist item:** Set a documented campaign budget for environment matrix and result records; record actual consumption, incomplete coverage and the disposition when the budget is exhausted.

- [ ] **UC-M12.08-C048-T01 · Quantity inventory:** Create a measurement inventory for “Environment scope”: “Environment matrix and result records”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M12.08-C048-T02 · Measurement method:** Choose how to observe each “Environment scope” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M12.08-C048-T03 · Budget decision:** Select justified campaign and target-resource budgets for “Environment scope”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M12.08-C048-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Environment scope” cases for “Environment matrix and result records”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M12.08-C048-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Environment scope” limit; preserve “Untested platforms are not implicitly covered by another platform's result”.
- [ ] **UC-M12.08-C048-T06 · Normal measurement:** Run or review the normal “Environment scope” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M12.08-C048-T07 · At-limit measurement:** Exercise the “Environment scope” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M12.08-C048-T08 · Over-limit measurement:** Exercise the “Environment scope” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M12.08-C048-T09 · Uncovered-scope report:** List the “Environment scope” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M12.08-C048-T10 · Limit evidence:** Publish the selected “Environment scope” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M12.08-C049 · Diagnostics / review

**Original checklist item:** Report environment scope results with executed, failed, skipped and unavailable cases separated; preserve the underlying observations and do not manufacture missing measurements.

- [ ] **UC-M12.08-C049-T01 · Result inventory:** Enumerate the required “Environment scope” qualification cases and intended targets before aggregating results; keep the planned denominator visible.
- [ ] **UC-M12.08-C049-T02 · Verdict schema:** Define separate executed-pass, executed-fail, skipped, unavailable and untested outcomes for “Environment scope”; document how incomplete cases block relevant claims.
- [ ] **UC-M12.08-C049-T03 · Identity fields:** Attach the actual target, fixture, configuration and revision identifiers to each “Environment scope” result; do not attribute host-only evidence to a guest or another OS.
- [ ] **UC-M12.08-C049-T04 · Observation capture:** Capture bounded raw “Environment scope” observations and harness errors; retain enough information to verify the reported oracle comparison.
- [ ] **UC-M12.08-C049-T05 · Aggregation rules:** Implement the “Environment scope” count/reduction rule so failures and missing measurements cannot disappear; preserve “Untested platforms are not implicitly covered by another platform's result”.
- [ ] **UC-M12.08-C049-T06 · Failure visibility:** Feed a failing “Environment scope” control through the report path; assert the exact failed case and underlying observation remain visible.
- [ ] **UC-M12.08-C049-T07 · Missing-result visibility:** Withhold a required “Environment scope” measurement or target; verify the report uses unavailable/untested rather than a fabricated zero or passing value.
- [ ] **UC-M12.08-C049-T08 · Bounds and redaction:** Check “Environment scope” report size and retention against “Environment matrix and result records”; remove secrets while retaining fixture and subject references.
- [ ] **UC-M12.08-C049-T09 · Report reconciliation:** Reconcile the “Environment scope” summary with every underlying case record; account for the full planned denominator and all omitted scope.
- [ ] **UC-M12.08-C049-T10 · Qualification handoff:** Publish the “Environment scope” report with measured observations, coverage limits and blockers; state which actual targets remain unqualified.

### UC-M12.08-C050 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for environment scope; label unexecuted checks as untested.

- [ ] **UC-M12.08-C050-T01 · Evidence inventory:** List the “Environment scope” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M12.08-C050-T02 · Artifact references:** Record the exact “Environment scope” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M12.08-C050-T03 · Fixture references:** Attach the “Environment scope” fixture IDs, input identities and oracle definition; preserve the source counterexample “A Windows support statement relies solely on Linux testing” as a distinct evidence case.
- [ ] **UC-M12.08-C050-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Environment scope”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M12.08-C050-T05 · Environment record:** Record the actual “Environment scope” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M12.08-C050-T06 · Expected versus observed:** Pair every “Environment scope” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M12.08-C050-T07 · Failure and limit records:** Attach “Environment scope” change/failure and bounds evidence where required; include uncovered “Environment matrix and result records” and unresolved violations of “Untested platforms are not implicitly covered by another platform's result”.
- [ ] **UC-M12.08-C050-T08 · Evidence hygiene:** Check the “Environment scope” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M12.08-C050-T09 · Reproduction review:** Have the “Environment scope” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M12.08-C050-T10 · Acceptance linkage:** Link the “Environment scope” evidence to its parent and UC-M12.08 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 06. Failure and skip disclosure

**Source delivery:** Report all required failures, skips and unexplained results visibly.

**Source invariant:** A combined PASS cannot conceal an unmet mandatory gate.

**Source negative case:** A summary drops skipped native guest tests from its totals.

**Source bounded quantities:** Result count and summary reconciliation cost.

### UC-M12.08-C051 · Contract

**Original checklist item:** Define the qualification objective for failure and skip disclosure, including the actual target implementation, prerequisites, observable oracle and explicit exclusions.

- [ ] **UC-M12.08-C051-T01 · Scope statement:** Write the qualification question for “Failure and skip disclosure”; identify the actual target, claimed capability and observations that can answer that question.
- [ ] **UC-M12.08-C051-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Failure and skip disclosure”; record each producer, representation and missing-value meaning.
- [ ] **UC-M12.08-C051-T03 · Output inventory:** List the outputs of “Failure and skip disclosure” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M12.08-C051-T04 · Field dictionary:** Create a field-and-term dictionary for “Failure and skip disclosure”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M12.08-C051-T05 · Prerequisite contract:** Map “Failure and skip disclosure” to the source component prerequisites (UC-M09.05, UC-M09.07, UC-M12.01, UC-M12.02, UC-M12.03, UC-M12.04); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M12.08-C051-T06 · Authority map:** Identify who may produce, change and consume “Failure and skip disclosure”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M12.08-C051-T07 · Invariant clause:** Add a normative clause for “Failure and skip disclosure” that preserves “A combined PASS cannot conceal an unmet mandatory gate”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M12.08-C051-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Failure and skip disclosure”; include the source counterexample “A summary drops skipped native guest tests from its totals” and the intended safe disposition.
- [ ] **UC-M12.08-C051-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Result count and summary reconciliation cost” in the “Failure and skip disclosure” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M12.08-C051-T10 · Contract review:** Review the “Failure and skip disclosure” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M12.08-C052 · Delivery

**Original checklist item:** Report all required failures, skips and unexplained results visibly.

- [ ] **UC-M12.08-C052-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Failure and skip disclosure”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M12.08-C052-T02 · Change plan:** Break the source delivery for “Failure and skip disclosure” into concrete edit targets and reviewable outputs; keep the UC-M12.08 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M12.08-C052-T03 · Core artifact:** Create the “Failure and skip disclosure” output artifact for this source instruction: Report all required failures, skips and unexplained results visibly.
- [ ] **UC-M12.08-C052-T04 · Concrete realization:** Populate the “Failure and skip disclosure” artifact from identified observations; keep unknown, failed and unexecuted results distinct and exclude unapproved sensitive material.
- [ ] **UC-M12.08-C052-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Failure and skip disclosure” needed to preserve “A combined PASS cannot conceal an unmet mandatory gate”; record an enforcement gap where only a model exists.
- [ ] **UC-M12.08-C052-T06 · Dependency connection:** Connect the “Failure and skip disclosure” qualification artifact to selected release profiles, typed assurance evidence and required/optional gate evaluation; record the target identity and what the harness actually exercises.
- [ ] **UC-M12.08-C052-T07 · Resource behavior:** Account for “Result count and summary reconciliation cost” in “Failure and skip disclosure”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M12.08-C052-T08 · Delivery check:** Run a known-valid control and a deliberately failing control for “Failure and skip disclosure”; confirm the harness distinguishes their observed outcomes.
- [ ] **UC-M12.08-C052-T09 · Patch review:** Review the “Failure and skip disclosure” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M12.08-C052-T10 · Delivery handoff:** Publish the “Failure and skip disclosure” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M12.08-C053 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: A combined PASS cannot conceal an unmet mandatory gate. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M12.08-C053-T01 · Named property:** Create a stable property/check name under this parent for “Failure and skip disclosure”; copy its required invariant exactly: “A combined PASS cannot conceal an unmet mandatory gate”.
- [ ] **UC-M12.08-C053-T02 · Observable terms:** Define each term in the “Failure and skip disclosure” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M12.08-C053-T03 · Precondition set:** List the preconditions under which “A combined PASS cannot conceal an unmet mandatory gate” must hold for “Failure and skip disclosure”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M12.08-C053-T04 · Transition coverage:** Map the “Failure and skip disclosure” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M12.08-C053-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Failure and skip disclosure”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M12.08-C053-T06 · Satisfying fixture:** Create a concrete “Failure and skip disclosure” case that satisfies “A combined PASS cannot conceal an unmet mandatory gate”; record its expected observation before running the assertion or review.
- [ ] **UC-M12.08-C053-T07 · Violating fixture:** Create the source counterexample “A summary drops skipped native guest tests from its totals” for “Failure and skip disclosure”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M12.08-C053-T08 · Enforcement evidence:** Exercise the “Failure and skip disclosure” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M12.08-C053-T09 · Regression linkage:** Link the “Failure and skip disclosure” property to changes in selected release profiles, typed assurance evidence and required/optional gate evaluation; record which dependency or contract changes require rerunning it.
- [ ] **UC-M12.08-C053-T10 · Property disposition:** Compare the satisfying and violating “Failure and skip disclosure” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M12.08-C054 · Integration

**Original checklist item:** Integrate failure and skip disclosure with selected release profiles, typed assurance evidence and required/optional gate evaluation; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M12.08-C054-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Failure and skip disclosure” across selected release profiles, typed assurance evidence and required/optional gate evaluation; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M12.08-C054-T02 · Field mapping:** Map every “Failure and skip disclosure” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M12.08-C054-T03 · Prerequisite identities:** Record the actual prerequisites for “Failure and skip disclosure” (source dependency list: UC-M09.05, UC-M09.07, UC-M12.01, UC-M12.02, UC-M12.03, UC-M12.04); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M12.08-C054-T04 · Ownership agreement:** Specify who owns “Failure and skip disclosure” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M12.08-C054-T05 · Handoff implementation:** Connect “Failure and skip disclosure” through the mapped seam using the real adapter or explicit specification reference; preserve “A combined PASS cannot conceal an unmet mandatory gate” across the handoff.
- [ ] **UC-M12.08-C054-T06 · Absent-input case:** Omit one required “Failure and skip disclosure” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M12.08-C054-T07 · Stale-input case:** Supply an outdated “Failure and skip disclosure” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M12.08-C054-T08 · Incompatible-input case:** Supply an incompatible “Failure and skip disclosure” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M12.08-C054-T09 · Valid integration trace:** Run a valid “Failure and skip disclosure” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M12.08-C054-T10 · Seam review:** Reconcile the “Failure and skip disclosure” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M12.08-C055 · Valid-case test

**Original checklist item:** Run a known-valid control for failure and skip disclosure; verify that the harness reaches its intended target and compare observed measurements or verdicts with predeclared expectations.

- [ ] **UC-M12.08-C055-T01 · Valid fixture choice:** Choose a known-valid control for “Failure and skip disclosure”; document why it should pass and how it proves the harness reaches the intended target.
- [ ] **UC-M12.08-C055-T02 · Expected-result oracle:** Specify the “Failure and skip disclosure” expected result independently of the implementation output; include the property “A combined PASS cannot conceal an unmet mandatory gate” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M12.08-C055-T03 · Fixture material:** Create the concrete “Failure and skip disclosure” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M12.08-C055-T04 · Target preparation:** Prepare the “Failure and skip disclosure” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M12.08-C055-T05 · Initial-state record:** Record the initial “Failure and skip disclosure” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M12.08-C055-T06 · Valid-path execution:** Run the “Failure and skip disclosure” known-valid control on the identified target; retain enough observations to prove the correct target was exercised.
- [ ] **UC-M12.08-C055-T07 · Outcome comparison:** Compare every declared “Failure and skip disclosure” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M12.08-C055-T08 · State and bounds check:** Inspect the “Failure and skip disclosure” ownership/state effects and actual use of “Result count and summary reconciliation cost”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M12.08-C055-T09 · Repeatability check:** Repeat the same “Failure and skip disclosure” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M12.08-C055-T10 · Positive evidence:** Attach the “Failure and skip disclosure” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M12.08-C056 · Negative test

**Original checklist item:** Negative case: A summary drops skipped native guest tests from its totals. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M12.08-C056-T01 · Adverse-case definition:** Create a test record for the exact “Failure and skip disclosure” source counterexample: “A summary drops skipped native guest tests from its totals”; state which precondition or invariant it challenges.
- [ ] **UC-M12.08-C056-T02 · Safe fixture boundary:** Define the contained test boundary for “Failure and skip disclosure”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M12.08-C056-T03 · Valid control:** Construct a valid “Failure and skip disclosure” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M12.08-C056-T04 · Minimal adverse input:** Derive the “Failure and skip disclosure” adverse fixture from the control with the smallest documented change needed to reproduce “A summary drops skipped native guest tests from its totals”; retain that change as reproducible data.
- [ ] **UC-M12.08-C056-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Failure and skip disclosure”; require “A combined PASS cannot conceal an unmet mandatory gate” and forbid a false-success verdict.
- [ ] **UC-M12.08-C056-T06 · Adverse execution:** Exercise the “Failure and skip disclosure” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M12.08-C056-T07 · Effect inspection:** Inspect “Failure and skip disclosure” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M12.08-C056-T08 · Refusal versus failure:** Confirm the “Failure and skip disclosure” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M12.08-C056-T09 · Reset and retention:** Restore only the disposable “Failure and skip disclosure” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M12.08-C056-T10 · Negative regression:** Register the “Failure and skip disclosure” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M12.08-C057 · Change / failure test

**Original checklist item:** Exercise failure and skip disclosure when a required gate is skipped, stale or supported only by a declaration; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M12.08-C057-T01 · Scenario record:** Write the “Failure and skip disclosure” change/failure scenario exactly as supplied: a required gate is skipped, stale or supported only by a declaration; identify the property that must remain true: “A combined PASS cannot conceal an unmet mandatory gate”.
- [ ] **UC-M12.08-C057-T02 · Baseline capture:** Create a known-valid “Failure and skip disclosure” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M12.08-C057-T03 · Injection map:** Locate the “Failure and skip disclosure” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M12.08-C057-T04 · Disposition oracle:** Define the legal intermediate and final “Failure and skip disclosure” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M12.08-C057-T05 · Controlled trigger:** Introduce the controlled “Failure and skip disclosure” scenario in the disposable fixture: a required gate is skipped, stale or supported only by a declaration; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M12.08-C057-T06 · Intermediate inspection:** Inspect the “Failure and skip disclosure” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M12.08-C057-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Failure and skip disclosure”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M12.08-C057-T08 · Stale-evidence cleanup:** Invalidate superseded “Failure and skip disclosure” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M12.08-C057-T09 · Repeat and compare:** Repeat the selected “Failure and skip disclosure” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M12.08-C057-T10 · Failure evidence:** Publish the “Failure and skip disclosure” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M12.08-C058 · Bounds

**Original checklist item:** Set a documented campaign budget for result count and summary reconciliation cost; record actual consumption, incomplete coverage and the disposition when the budget is exhausted.

- [ ] **UC-M12.08-C058-T01 · Quantity inventory:** Create a measurement inventory for “Failure and skip disclosure”: “Result count and summary reconciliation cost”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M12.08-C058-T02 · Measurement method:** Choose how to observe each “Failure and skip disclosure” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M12.08-C058-T03 · Budget decision:** Select justified campaign and target-resource budgets for “Failure and skip disclosure”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M12.08-C058-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Failure and skip disclosure” cases for “Result count and summary reconciliation cost”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M12.08-C058-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Failure and skip disclosure” limit; preserve “A combined PASS cannot conceal an unmet mandatory gate”.
- [ ] **UC-M12.08-C058-T06 · Normal measurement:** Run or review the normal “Failure and skip disclosure” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M12.08-C058-T07 · At-limit measurement:** Exercise the “Failure and skip disclosure” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M12.08-C058-T08 · Over-limit measurement:** Exercise the “Failure and skip disclosure” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M12.08-C058-T09 · Uncovered-scope report:** List the “Failure and skip disclosure” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M12.08-C058-T10 · Limit evidence:** Publish the selected “Failure and skip disclosure” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M12.08-C059 · Diagnostics / review

**Original checklist item:** Report failure and skip disclosure results with executed, failed, skipped and unavailable cases separated; preserve the underlying observations and do not manufacture missing measurements.

- [ ] **UC-M12.08-C059-T01 · Result inventory:** Enumerate the required “Failure and skip disclosure” qualification cases and intended targets before aggregating results; keep the planned denominator visible.
- [ ] **UC-M12.08-C059-T02 · Verdict schema:** Define separate executed-pass, executed-fail, skipped, unavailable and untested outcomes for “Failure and skip disclosure”; document how incomplete cases block relevant claims.
- [ ] **UC-M12.08-C059-T03 · Identity fields:** Attach the actual target, fixture, configuration and revision identifiers to each “Failure and skip disclosure” result; do not attribute host-only evidence to a guest or another OS.
- [ ] **UC-M12.08-C059-T04 · Observation capture:** Capture bounded raw “Failure and skip disclosure” observations and harness errors; retain enough information to verify the reported oracle comparison.
- [ ] **UC-M12.08-C059-T05 · Aggregation rules:** Implement the “Failure and skip disclosure” count/reduction rule so failures and missing measurements cannot disappear; preserve “A combined PASS cannot conceal an unmet mandatory gate”.
- [ ] **UC-M12.08-C059-T06 · Failure visibility:** Feed a failing “Failure and skip disclosure” control through the report path; assert the exact failed case and underlying observation remain visible.
- [ ] **UC-M12.08-C059-T07 · Missing-result visibility:** Withhold a required “Failure and skip disclosure” measurement or target; verify the report uses unavailable/untested rather than a fabricated zero or passing value.
- [ ] **UC-M12.08-C059-T08 · Bounds and redaction:** Check “Failure and skip disclosure” report size and retention against “Result count and summary reconciliation cost”; remove secrets while retaining fixture and subject references.
- [ ] **UC-M12.08-C059-T09 · Report reconciliation:** Reconcile the “Failure and skip disclosure” summary with every underlying case record; account for the full planned denominator and all omitted scope.
- [ ] **UC-M12.08-C059-T10 · Qualification handoff:** Publish the “Failure and skip disclosure” report with measured observations, coverage limits and blockers; state which actual targets remain unqualified.

### UC-M12.08-C060 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for failure and skip disclosure; label unexecuted checks as untested.

- [ ] **UC-M12.08-C060-T01 · Evidence inventory:** List the “Failure and skip disclosure” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M12.08-C060-T02 · Artifact references:** Record the exact “Failure and skip disclosure” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M12.08-C060-T03 · Fixture references:** Attach the “Failure and skip disclosure” fixture IDs, input identities and oracle definition; preserve the source counterexample “A summary drops skipped native guest tests from its totals” as a distinct evidence case.
- [ ] **UC-M12.08-C060-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Failure and skip disclosure”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M12.08-C060-T05 · Environment record:** Record the actual “Failure and skip disclosure” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M12.08-C060-T06 · Expected versus observed:** Pair every “Failure and skip disclosure” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M12.08-C060-T07 · Failure and limit records:** Attach “Failure and skip disclosure” change/failure and bounds evidence where required; include uncovered “Result count and summary reconciliation cost” and unresolved violations of “A combined PASS cannot conceal an unmet mandatory gate”.
- [ ] **UC-M12.08-C060-T08 · Evidence hygiene:** Check the “Failure and skip disclosure” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M12.08-C060-T09 · Reproduction review:** Have the “Failure and skip disclosure” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M12.08-C060-T10 · Acceptance linkage:** Link the “Failure and skip disclosure” evidence to its parent and UC-M12.08 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 07. Residual risk register

**Source delivery:** Record unresolved implementation gaps, assumptions and accepted profile limitations.

**Source invariant:** Known required blockers cannot vanish behind general release language.

**Source negative case:** A missing host sandbox is omitted from the isolated-release risks.

**Source bounded quantities:** Open risks and review interval.

### UC-M12.08-C061 · Contract

**Original checklist item:** Define the qualification objective for residual risk register, including the actual target implementation, prerequisites, observable oracle and explicit exclusions.

- [ ] **UC-M12.08-C061-T01 · Scope statement:** Write the qualification question for “Residual risk register”; identify the actual target, claimed capability and observations that can answer that question.
- [ ] **UC-M12.08-C061-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Residual risk register”; record each producer, representation and missing-value meaning.
- [ ] **UC-M12.08-C061-T03 · Output inventory:** List the outputs of “Residual risk register” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M12.08-C061-T04 · Field dictionary:** Create a field-and-term dictionary for “Residual risk register”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M12.08-C061-T05 · Prerequisite contract:** Map “Residual risk register” to the source component prerequisites (UC-M09.05, UC-M09.07, UC-M12.01, UC-M12.02, UC-M12.03, UC-M12.04); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M12.08-C061-T06 · Authority map:** Identify who may produce, change and consume “Residual risk register”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M12.08-C061-T07 · Invariant clause:** Add a normative clause for “Residual risk register” that preserves “Known required blockers cannot vanish behind general release language”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M12.08-C061-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Residual risk register”; include the source counterexample “A missing host sandbox is omitted from the isolated-release risks” and the intended safe disposition.
- [ ] **UC-M12.08-C061-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Open risks and review interval” in the “Residual risk register” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M12.08-C061-T10 · Contract review:** Review the “Residual risk register” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M12.08-C062 · Delivery

**Original checklist item:** Record unresolved implementation gaps, assumptions and accepted profile limitations.

- [ ] **UC-M12.08-C062-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Residual risk register”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M12.08-C062-T02 · Change plan:** Break the source delivery for “Residual risk register” into concrete edit targets and reviewable outputs; keep the UC-M12.08 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M12.08-C062-T03 · Core artifact:** Create the “Residual risk register” model, schema or inventory that realizes this source instruction: Record unresolved implementation gaps, assumptions and accepted profile limitations.
- [ ] **UC-M12.08-C062-T04 · Concrete realization:** Populate “Residual risk register” with one concrete worked case; map every required entity or field to its source and flag any unmapped entry.
- [ ] **UC-M12.08-C062-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Residual risk register” needed to preserve “Known required blockers cannot vanish behind general release language”; record an enforcement gap where only a model exists.
- [ ] **UC-M12.08-C062-T06 · Dependency connection:** Connect the “Residual risk register” qualification artifact to selected release profiles, typed assurance evidence and required/optional gate evaluation; record the target identity and what the harness actually exercises.
- [ ] **UC-M12.08-C062-T07 · Resource behavior:** Account for “Open risks and review interval” in “Residual risk register”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M12.08-C062-T08 · Delivery check:** Run a known-valid control and a deliberately failing control for “Residual risk register”; confirm the harness distinguishes their observed outcomes.
- [ ] **UC-M12.08-C062-T09 · Patch review:** Review the “Residual risk register” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M12.08-C062-T10 · Delivery handoff:** Publish the “Residual risk register” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M12.08-C063 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Known required blockers cannot vanish behind general release language. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M12.08-C063-T01 · Named property:** Create a stable property/check name under this parent for “Residual risk register”; copy its required invariant exactly: “Known required blockers cannot vanish behind general release language”.
- [ ] **UC-M12.08-C063-T02 · Observable terms:** Define each term in the “Residual risk register” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M12.08-C063-T03 · Precondition set:** List the preconditions under which “Known required blockers cannot vanish behind general release language” must hold for “Residual risk register”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M12.08-C063-T04 · Transition coverage:** Map the “Residual risk register” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M12.08-C063-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Residual risk register”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M12.08-C063-T06 · Satisfying fixture:** Create a concrete “Residual risk register” case that satisfies “Known required blockers cannot vanish behind general release language”; record its expected observation before running the assertion or review.
- [ ] **UC-M12.08-C063-T07 · Violating fixture:** Create the source counterexample “A missing host sandbox is omitted from the isolated-release risks” for “Residual risk register”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M12.08-C063-T08 · Enforcement evidence:** Exercise the “Residual risk register” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M12.08-C063-T09 · Regression linkage:** Link the “Residual risk register” property to changes in selected release profiles, typed assurance evidence and required/optional gate evaluation; record which dependency or contract changes require rerunning it.
- [ ] **UC-M12.08-C063-T10 · Property disposition:** Compare the satisfying and violating “Residual risk register” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M12.08-C064 · Integration

**Original checklist item:** Integrate residual risk register with selected release profiles, typed assurance evidence and required/optional gate evaluation; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M12.08-C064-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Residual risk register” across selected release profiles, typed assurance evidence and required/optional gate evaluation; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M12.08-C064-T02 · Field mapping:** Map every “Residual risk register” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M12.08-C064-T03 · Prerequisite identities:** Record the actual prerequisites for “Residual risk register” (source dependency list: UC-M09.05, UC-M09.07, UC-M12.01, UC-M12.02, UC-M12.03, UC-M12.04); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M12.08-C064-T04 · Ownership agreement:** Specify who owns “Residual risk register” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M12.08-C064-T05 · Handoff implementation:** Connect “Residual risk register” through the mapped seam using the real adapter or explicit specification reference; preserve “Known required blockers cannot vanish behind general release language” across the handoff.
- [ ] **UC-M12.08-C064-T06 · Absent-input case:** Omit one required “Residual risk register” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M12.08-C064-T07 · Stale-input case:** Supply an outdated “Residual risk register” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M12.08-C064-T08 · Incompatible-input case:** Supply an incompatible “Residual risk register” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M12.08-C064-T09 · Valid integration trace:** Run a valid “Residual risk register” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M12.08-C064-T10 · Seam review:** Reconcile the “Residual risk register” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M12.08-C065 · Valid-case test

**Original checklist item:** Run a known-valid control for residual risk register; verify that the harness reaches its intended target and compare observed measurements or verdicts with predeclared expectations.

- [ ] **UC-M12.08-C065-T01 · Valid fixture choice:** Choose a known-valid control for “Residual risk register”; document why it should pass and how it proves the harness reaches the intended target.
- [ ] **UC-M12.08-C065-T02 · Expected-result oracle:** Specify the “Residual risk register” expected result independently of the implementation output; include the property “Known required blockers cannot vanish behind general release language” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M12.08-C065-T03 · Fixture material:** Create the concrete “Residual risk register” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M12.08-C065-T04 · Target preparation:** Prepare the “Residual risk register” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M12.08-C065-T05 · Initial-state record:** Record the initial “Residual risk register” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M12.08-C065-T06 · Valid-path execution:** Run the “Residual risk register” known-valid control on the identified target; retain enough observations to prove the correct target was exercised.
- [ ] **UC-M12.08-C065-T07 · Outcome comparison:** Compare every declared “Residual risk register” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M12.08-C065-T08 · State and bounds check:** Inspect the “Residual risk register” ownership/state effects and actual use of “Open risks and review interval”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M12.08-C065-T09 · Repeatability check:** Repeat the same “Residual risk register” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M12.08-C065-T10 · Positive evidence:** Attach the “Residual risk register” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M12.08-C066 · Negative test

**Original checklist item:** Negative case: A missing host sandbox is omitted from the isolated-release risks. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M12.08-C066-T01 · Adverse-case definition:** Create a test record for the exact “Residual risk register” source counterexample: “A missing host sandbox is omitted from the isolated-release risks”; state which precondition or invariant it challenges.
- [ ] **UC-M12.08-C066-T02 · Safe fixture boundary:** Define the contained test boundary for “Residual risk register”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M12.08-C066-T03 · Valid control:** Construct a valid “Residual risk register” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M12.08-C066-T04 · Minimal adverse input:** Derive the “Residual risk register” adverse fixture from the control with the smallest documented change needed to reproduce “A missing host sandbox is omitted from the isolated-release risks”; retain that change as reproducible data.
- [ ] **UC-M12.08-C066-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Residual risk register”; require “Known required blockers cannot vanish behind general release language” and forbid a false-success verdict.
- [ ] **UC-M12.08-C066-T06 · Adverse execution:** Exercise the “Residual risk register” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M12.08-C066-T07 · Effect inspection:** Inspect “Residual risk register” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M12.08-C066-T08 · Refusal versus failure:** Confirm the “Residual risk register” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M12.08-C066-T09 · Reset and retention:** Restore only the disposable “Residual risk register” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M12.08-C066-T10 · Negative regression:** Register the “Residual risk register” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M12.08-C067 · Change / failure test

**Original checklist item:** Exercise residual risk register when a required gate is skipped, stale or supported only by a declaration; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M12.08-C067-T01 · Scenario record:** Write the “Residual risk register” change/failure scenario exactly as supplied: a required gate is skipped, stale or supported only by a declaration; identify the property that must remain true: “Known required blockers cannot vanish behind general release language”.
- [ ] **UC-M12.08-C067-T02 · Baseline capture:** Create a known-valid “Residual risk register” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M12.08-C067-T03 · Injection map:** Locate the “Residual risk register” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M12.08-C067-T04 · Disposition oracle:** Define the legal intermediate and final “Residual risk register” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M12.08-C067-T05 · Controlled trigger:** Introduce the controlled “Residual risk register” scenario in the disposable fixture: a required gate is skipped, stale or supported only by a declaration; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M12.08-C067-T06 · Intermediate inspection:** Inspect the “Residual risk register” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M12.08-C067-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Residual risk register”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M12.08-C067-T08 · Stale-evidence cleanup:** Invalidate superseded “Residual risk register” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M12.08-C067-T09 · Repeat and compare:** Repeat the selected “Residual risk register” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M12.08-C067-T10 · Failure evidence:** Publish the “Residual risk register” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M12.08-C068 · Bounds

**Original checklist item:** Set a documented campaign budget for open risks and review interval; record actual consumption, incomplete coverage and the disposition when the budget is exhausted.

- [ ] **UC-M12.08-C068-T01 · Quantity inventory:** Create a measurement inventory for “Residual risk register”: “Open risks and review interval”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M12.08-C068-T02 · Measurement method:** Choose how to observe each “Residual risk register” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M12.08-C068-T03 · Budget decision:** Select justified campaign and target-resource budgets for “Residual risk register”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M12.08-C068-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Residual risk register” cases for “Open risks and review interval”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M12.08-C068-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Residual risk register” limit; preserve “Known required blockers cannot vanish behind general release language”.
- [ ] **UC-M12.08-C068-T06 · Normal measurement:** Run or review the normal “Residual risk register” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M12.08-C068-T07 · At-limit measurement:** Exercise the “Residual risk register” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M12.08-C068-T08 · Over-limit measurement:** Exercise the “Residual risk register” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M12.08-C068-T09 · Uncovered-scope report:** List the “Residual risk register” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M12.08-C068-T10 · Limit evidence:** Publish the selected “Residual risk register” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M12.08-C069 · Diagnostics / review

**Original checklist item:** Report residual risk register results with executed, failed, skipped and unavailable cases separated; preserve the underlying observations and do not manufacture missing measurements.

- [ ] **UC-M12.08-C069-T01 · Result inventory:** Enumerate the required “Residual risk register” qualification cases and intended targets before aggregating results; keep the planned denominator visible.
- [ ] **UC-M12.08-C069-T02 · Verdict schema:** Define separate executed-pass, executed-fail, skipped, unavailable and untested outcomes for “Residual risk register”; document how incomplete cases block relevant claims.
- [ ] **UC-M12.08-C069-T03 · Identity fields:** Attach the actual target, fixture, configuration and revision identifiers to each “Residual risk register” result; do not attribute host-only evidence to a guest or another OS.
- [ ] **UC-M12.08-C069-T04 · Observation capture:** Capture bounded raw “Residual risk register” observations and harness errors; retain enough information to verify the reported oracle comparison.
- [ ] **UC-M12.08-C069-T05 · Aggregation rules:** Implement the “Residual risk register” count/reduction rule so failures and missing measurements cannot disappear; preserve “Known required blockers cannot vanish behind general release language”.
- [ ] **UC-M12.08-C069-T06 · Failure visibility:** Feed a failing “Residual risk register” control through the report path; assert the exact failed case and underlying observation remain visible.
- [ ] **UC-M12.08-C069-T07 · Missing-result visibility:** Withhold a required “Residual risk register” measurement or target; verify the report uses unavailable/untested rather than a fabricated zero or passing value.
- [ ] **UC-M12.08-C069-T08 · Bounds and redaction:** Check “Residual risk register” report size and retention against “Open risks and review interval”; remove secrets while retaining fixture and subject references.
- [ ] **UC-M12.08-C069-T09 · Report reconciliation:** Reconcile the “Residual risk register” summary with every underlying case record; account for the full planned denominator and all omitted scope.
- [ ] **UC-M12.08-C069-T10 · Qualification handoff:** Publish the “Residual risk register” report with measured observations, coverage limits and blockers; state which actual targets remain unqualified.

### UC-M12.08-C070 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for residual risk register; label unexecuted checks as untested.

- [ ] **UC-M12.08-C070-T01 · Evidence inventory:** List the “Residual risk register” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M12.08-C070-T02 · Artifact references:** Record the exact “Residual risk register” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M12.08-C070-T03 · Fixture references:** Attach the “Residual risk register” fixture IDs, input identities and oracle definition; preserve the source counterexample “A missing host sandbox is omitted from the isolated-release risks” as a distinct evidence case.
- [ ] **UC-M12.08-C070-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Residual risk register”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M12.08-C070-T05 · Environment record:** Record the actual “Residual risk register” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M12.08-C070-T06 · Expected versus observed:** Pair every “Residual risk register” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M12.08-C070-T07 · Failure and limit records:** Attach “Residual risk register” change/failure and bounds evidence where required; include uncovered “Open risks and review interval” and unresolved violations of “Known required blockers cannot vanish behind general release language”.
- [ ] **UC-M12.08-C070-T08 · Evidence hygiene:** Check the “Residual risk register” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M12.08-C070-T09 · Reproduction review:** Have the “Residual risk register” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M12.08-C070-T10 · Acceptance linkage:** Link the “Residual risk register” evidence to its parent and UC-M12.08 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 08. Operator runbooks

**Source delivery:** Provide tested start, inspect, stop, rollback and recovery procedures with evidence links.

**Source invariant:** Runbooks distinguish observed procedures from proposed alternatives.

**Source negative case:** An untested restore command is described as guaranteed recovery.

**Source bounded quantities:** Procedures and drill records.

### UC-M12.08-C071 · Contract

**Original checklist item:** Define the qualification objective for operator runbooks, including the actual target implementation, prerequisites, observable oracle and explicit exclusions.

- [ ] **UC-M12.08-C071-T01 · Scope statement:** Write the qualification question for “Operator runbooks”; identify the actual target, claimed capability and observations that can answer that question.
- [ ] **UC-M12.08-C071-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Operator runbooks”; record each producer, representation and missing-value meaning.
- [ ] **UC-M12.08-C071-T03 · Output inventory:** List the outputs of “Operator runbooks” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M12.08-C071-T04 · Field dictionary:** Create a field-and-term dictionary for “Operator runbooks”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M12.08-C071-T05 · Prerequisite contract:** Map “Operator runbooks” to the source component prerequisites (UC-M09.05, UC-M09.07, UC-M12.01, UC-M12.02, UC-M12.03, UC-M12.04); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M12.08-C071-T06 · Authority map:** Identify who may produce, change and consume “Operator runbooks”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M12.08-C071-T07 · Invariant clause:** Add a normative clause for “Operator runbooks” that preserves “Runbooks distinguish observed procedures from proposed alternatives”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M12.08-C071-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Operator runbooks”; include the source counterexample “An untested restore command is described as guaranteed recovery” and the intended safe disposition.
- [ ] **UC-M12.08-C071-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Procedures and drill records” in the “Operator runbooks” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M12.08-C071-T10 · Contract review:** Review the “Operator runbooks” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M12.08-C072 · Delivery

**Original checklist item:** Provide tested start, inspect, stop, rollback and recovery procedures with evidence links.

- [ ] **UC-M12.08-C072-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Operator runbooks”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M12.08-C072-T02 · Change plan:** Break the source delivery for “Operator runbooks” into concrete edit targets and reviewable outputs; keep the UC-M12.08 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M12.08-C072-T03 · Core artifact:** Implement the smallest selected-profile change for “Operator runbooks” that realizes this source instruction: Provide tested start, inspect, stop, rollback and recovery procedures with evidence links.
- [ ] **UC-M12.08-C072-T04 · Concrete realization:** Trace “Operator runbooks” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M12.08-C072-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Operator runbooks” needed to preserve “Runbooks distinguish observed procedures from proposed alternatives”; record an enforcement gap where only a model exists.
- [ ] **UC-M12.08-C072-T06 · Dependency connection:** Connect the “Operator runbooks” qualification artifact to selected release profiles, typed assurance evidence and required/optional gate evaluation; record the target identity and what the harness actually exercises.
- [ ] **UC-M12.08-C072-T07 · Resource behavior:** Account for “Procedures and drill records” in “Operator runbooks”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M12.08-C072-T08 · Delivery check:** Run a known-valid control and a deliberately failing control for “Operator runbooks”; confirm the harness distinguishes their observed outcomes.
- [ ] **UC-M12.08-C072-T09 · Patch review:** Review the “Operator runbooks” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M12.08-C072-T10 · Delivery handoff:** Publish the “Operator runbooks” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M12.08-C073 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Runbooks distinguish observed procedures from proposed alternatives. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M12.08-C073-T01 · Named property:** Create a stable property/check name under this parent for “Operator runbooks”; copy its required invariant exactly: “Runbooks distinguish observed procedures from proposed alternatives”.
- [ ] **UC-M12.08-C073-T02 · Observable terms:** Define each term in the “Operator runbooks” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M12.08-C073-T03 · Precondition set:** List the preconditions under which “Runbooks distinguish observed procedures from proposed alternatives” must hold for “Operator runbooks”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M12.08-C073-T04 · Transition coverage:** Map the “Operator runbooks” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M12.08-C073-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Operator runbooks”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M12.08-C073-T06 · Satisfying fixture:** Create a concrete “Operator runbooks” case that satisfies “Runbooks distinguish observed procedures from proposed alternatives”; record its expected observation before running the assertion or review.
- [ ] **UC-M12.08-C073-T07 · Violating fixture:** Create the source counterexample “An untested restore command is described as guaranteed recovery” for “Operator runbooks”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M12.08-C073-T08 · Enforcement evidence:** Exercise the “Operator runbooks” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M12.08-C073-T09 · Regression linkage:** Link the “Operator runbooks” property to changes in selected release profiles, typed assurance evidence and required/optional gate evaluation; record which dependency or contract changes require rerunning it.
- [ ] **UC-M12.08-C073-T10 · Property disposition:** Compare the satisfying and violating “Operator runbooks” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M12.08-C074 · Integration

**Original checklist item:** Integrate operator runbooks with selected release profiles, typed assurance evidence and required/optional gate evaluation; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M12.08-C074-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Operator runbooks” across selected release profiles, typed assurance evidence and required/optional gate evaluation; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M12.08-C074-T02 · Field mapping:** Map every “Operator runbooks” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M12.08-C074-T03 · Prerequisite identities:** Record the actual prerequisites for “Operator runbooks” (source dependency list: UC-M09.05, UC-M09.07, UC-M12.01, UC-M12.02, UC-M12.03, UC-M12.04); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M12.08-C074-T04 · Ownership agreement:** Specify who owns “Operator runbooks” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M12.08-C074-T05 · Handoff implementation:** Connect “Operator runbooks” through the mapped seam using the real adapter or explicit specification reference; preserve “Runbooks distinguish observed procedures from proposed alternatives” across the handoff.
- [ ] **UC-M12.08-C074-T06 · Absent-input case:** Omit one required “Operator runbooks” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M12.08-C074-T07 · Stale-input case:** Supply an outdated “Operator runbooks” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M12.08-C074-T08 · Incompatible-input case:** Supply an incompatible “Operator runbooks” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M12.08-C074-T09 · Valid integration trace:** Run a valid “Operator runbooks” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M12.08-C074-T10 · Seam review:** Reconcile the “Operator runbooks” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M12.08-C075 · Valid-case test

**Original checklist item:** Run a known-valid control for operator runbooks; verify that the harness reaches its intended target and compare observed measurements or verdicts with predeclared expectations.

- [ ] **UC-M12.08-C075-T01 · Valid fixture choice:** Choose a known-valid control for “Operator runbooks”; document why it should pass and how it proves the harness reaches the intended target.
- [ ] **UC-M12.08-C075-T02 · Expected-result oracle:** Specify the “Operator runbooks” expected result independently of the implementation output; include the property “Runbooks distinguish observed procedures from proposed alternatives” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M12.08-C075-T03 · Fixture material:** Create the concrete “Operator runbooks” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M12.08-C075-T04 · Target preparation:** Prepare the “Operator runbooks” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M12.08-C075-T05 · Initial-state record:** Record the initial “Operator runbooks” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M12.08-C075-T06 · Valid-path execution:** Run the “Operator runbooks” known-valid control on the identified target; retain enough observations to prove the correct target was exercised.
- [ ] **UC-M12.08-C075-T07 · Outcome comparison:** Compare every declared “Operator runbooks” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M12.08-C075-T08 · State and bounds check:** Inspect the “Operator runbooks” ownership/state effects and actual use of “Procedures and drill records”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M12.08-C075-T09 · Repeatability check:** Repeat the same “Operator runbooks” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M12.08-C075-T10 · Positive evidence:** Attach the “Operator runbooks” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M12.08-C076 · Negative test

**Original checklist item:** Negative case: An untested restore command is described as guaranteed recovery. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M12.08-C076-T01 · Adverse-case definition:** Create a test record for the exact “Operator runbooks” source counterexample: “An untested restore command is described as guaranteed recovery”; state which precondition or invariant it challenges.
- [ ] **UC-M12.08-C076-T02 · Safe fixture boundary:** Define the contained test boundary for “Operator runbooks”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M12.08-C076-T03 · Valid control:** Construct a valid “Operator runbooks” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M12.08-C076-T04 · Minimal adverse input:** Derive the “Operator runbooks” adverse fixture from the control with the smallest documented change needed to reproduce “An untested restore command is described as guaranteed recovery”; retain that change as reproducible data.
- [ ] **UC-M12.08-C076-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Operator runbooks”; require “Runbooks distinguish observed procedures from proposed alternatives” and forbid a false-success verdict.
- [ ] **UC-M12.08-C076-T06 · Adverse execution:** Exercise the “Operator runbooks” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M12.08-C076-T07 · Effect inspection:** Inspect “Operator runbooks” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M12.08-C076-T08 · Refusal versus failure:** Confirm the “Operator runbooks” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M12.08-C076-T09 · Reset and retention:** Restore only the disposable “Operator runbooks” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M12.08-C076-T10 · Negative regression:** Register the “Operator runbooks” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M12.08-C077 · Change / failure test

**Original checklist item:** Exercise operator runbooks when a required gate is skipped, stale or supported only by a declaration; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M12.08-C077-T01 · Scenario record:** Write the “Operator runbooks” change/failure scenario exactly as supplied: a required gate is skipped, stale or supported only by a declaration; identify the property that must remain true: “Runbooks distinguish observed procedures from proposed alternatives”.
- [ ] **UC-M12.08-C077-T02 · Baseline capture:** Create a known-valid “Operator runbooks” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M12.08-C077-T03 · Injection map:** Locate the “Operator runbooks” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M12.08-C077-T04 · Disposition oracle:** Define the legal intermediate and final “Operator runbooks” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M12.08-C077-T05 · Controlled trigger:** Introduce the controlled “Operator runbooks” scenario in the disposable fixture: a required gate is skipped, stale or supported only by a declaration; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M12.08-C077-T06 · Intermediate inspection:** Inspect the “Operator runbooks” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M12.08-C077-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Operator runbooks”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M12.08-C077-T08 · Stale-evidence cleanup:** Invalidate superseded “Operator runbooks” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M12.08-C077-T09 · Repeat and compare:** Repeat the selected “Operator runbooks” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M12.08-C077-T10 · Failure evidence:** Publish the “Operator runbooks” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M12.08-C078 · Bounds

**Original checklist item:** Set a documented campaign budget for procedures and drill records; record actual consumption, incomplete coverage and the disposition when the budget is exhausted.

- [ ] **UC-M12.08-C078-T01 · Quantity inventory:** Create a measurement inventory for “Operator runbooks”: “Procedures and drill records”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M12.08-C078-T02 · Measurement method:** Choose how to observe each “Operator runbooks” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M12.08-C078-T03 · Budget decision:** Select justified campaign and target-resource budgets for “Operator runbooks”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M12.08-C078-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Operator runbooks” cases for “Procedures and drill records”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M12.08-C078-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Operator runbooks” limit; preserve “Runbooks distinguish observed procedures from proposed alternatives”.
- [ ] **UC-M12.08-C078-T06 · Normal measurement:** Run or review the normal “Operator runbooks” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M12.08-C078-T07 · At-limit measurement:** Exercise the “Operator runbooks” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M12.08-C078-T08 · Over-limit measurement:** Exercise the “Operator runbooks” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M12.08-C078-T09 · Uncovered-scope report:** List the “Operator runbooks” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M12.08-C078-T10 · Limit evidence:** Publish the selected “Operator runbooks” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M12.08-C079 · Diagnostics / review

**Original checklist item:** Report operator runbooks results with executed, failed, skipped and unavailable cases separated; preserve the underlying observations and do not manufacture missing measurements.

- [ ] **UC-M12.08-C079-T01 · Result inventory:** Enumerate the required “Operator runbooks” qualification cases and intended targets before aggregating results; keep the planned denominator visible.
- [ ] **UC-M12.08-C079-T02 · Verdict schema:** Define separate executed-pass, executed-fail, skipped, unavailable and untested outcomes for “Operator runbooks”; document how incomplete cases block relevant claims.
- [ ] **UC-M12.08-C079-T03 · Identity fields:** Attach the actual target, fixture, configuration and revision identifiers to each “Operator runbooks” result; do not attribute host-only evidence to a guest or another OS.
- [ ] **UC-M12.08-C079-T04 · Observation capture:** Capture bounded raw “Operator runbooks” observations and harness errors; retain enough information to verify the reported oracle comparison.
- [ ] **UC-M12.08-C079-T05 · Aggregation rules:** Implement the “Operator runbooks” count/reduction rule so failures and missing measurements cannot disappear; preserve “Runbooks distinguish observed procedures from proposed alternatives”.
- [ ] **UC-M12.08-C079-T06 · Failure visibility:** Feed a failing “Operator runbooks” control through the report path; assert the exact failed case and underlying observation remain visible.
- [ ] **UC-M12.08-C079-T07 · Missing-result visibility:** Withhold a required “Operator runbooks” measurement or target; verify the report uses unavailable/untested rather than a fabricated zero or passing value.
- [ ] **UC-M12.08-C079-T08 · Bounds and redaction:** Check “Operator runbooks” report size and retention against “Procedures and drill records”; remove secrets while retaining fixture and subject references.
- [ ] **UC-M12.08-C079-T09 · Report reconciliation:** Reconcile the “Operator runbooks” summary with every underlying case record; account for the full planned denominator and all omitted scope.
- [ ] **UC-M12.08-C079-T10 · Qualification handoff:** Publish the “Operator runbooks” report with measured observations, coverage limits and blockers; state which actual targets remain unqualified.

### UC-M12.08-C080 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for operator runbooks; label unexecuted checks as untested.

- [ ] **UC-M12.08-C080-T01 · Evidence inventory:** List the “Operator runbooks” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M12.08-C080-T02 · Artifact references:** Record the exact “Operator runbooks” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M12.08-C080-T03 · Fixture references:** Attach the “Operator runbooks” fixture IDs, input identities and oracle definition; preserve the source counterexample “An untested restore command is described as guaranteed recovery” as a distinct evidence case.
- [ ] **UC-M12.08-C080-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Operator runbooks”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M12.08-C080-T05 · Environment record:** Record the actual “Operator runbooks” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M12.08-C080-T06 · Expected versus observed:** Pair every “Operator runbooks” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M12.08-C080-T07 · Failure and limit records:** Attach “Operator runbooks” change/failure and bounds evidence where required; include uncovered “Procedures and drill records” and unresolved violations of “Runbooks distinguish observed procedures from proposed alternatives”.
- [ ] **UC-M12.08-C080-T08 · Evidence hygiene:** Check the “Operator runbooks” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M12.08-C080-T09 · Reproduction review:** Have the “Operator runbooks” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M12.08-C080-T10 · Acceptance linkage:** Link the “Operator runbooks” evidence to its parent and UC-M12.08 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 09. Promotion decision artifact

**Source delivery:** Bind the final release decision to exact artifact identities and evaluated gate results.

**Source invariant:** Changing release bytes invalidates the corresponding promotion decision.

**Source negative case:** A promoted archive is repackaged with changed executable content.

**Source bounded quantities:** Artifact subjects and signature/record bytes.

### UC-M12.08-C081 · Contract

**Original checklist item:** Define the qualification objective for promotion decision artifact, including the actual target implementation, prerequisites, observable oracle and explicit exclusions.

- [ ] **UC-M12.08-C081-T01 · Scope statement:** Write the qualification question for “Promotion decision artifact”; identify the actual target, claimed capability and observations that can answer that question.
- [ ] **UC-M12.08-C081-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Promotion decision artifact”; record each producer, representation and missing-value meaning.
- [ ] **UC-M12.08-C081-T03 · Output inventory:** List the outputs of “Promotion decision artifact” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M12.08-C081-T04 · Field dictionary:** Create a field-and-term dictionary for “Promotion decision artifact”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M12.08-C081-T05 · Prerequisite contract:** Map “Promotion decision artifact” to the source component prerequisites (UC-M09.05, UC-M09.07, UC-M12.01, UC-M12.02, UC-M12.03, UC-M12.04); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M12.08-C081-T06 · Authority map:** Identify who may produce, change and consume “Promotion decision artifact”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M12.08-C081-T07 · Invariant clause:** Add a normative clause for “Promotion decision artifact” that preserves “Changing release bytes invalidates the corresponding promotion decision”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M12.08-C081-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Promotion decision artifact”; include the source counterexample “A promoted archive is repackaged with changed executable content” and the intended safe disposition.
- [ ] **UC-M12.08-C081-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Artifact subjects and signature/record bytes” in the “Promotion decision artifact” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M12.08-C081-T10 · Contract review:** Review the “Promotion decision artifact” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M12.08-C082 · Delivery

**Original checklist item:** Bind the final release decision to exact artifact identities and evaluated gate results.

- [ ] **UC-M12.08-C082-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Promotion decision artifact”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M12.08-C082-T02 · Change plan:** Break the source delivery for “Promotion decision artifact” into concrete edit targets and reviewable outputs; keep the UC-M12.08 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M12.08-C082-T03 · Core artifact:** Implement the smallest selected-profile change for “Promotion decision artifact” that realizes this source instruction: Bind the final release decision to exact artifact identities and evaluated gate results.
- [ ] **UC-M12.08-C082-T04 · Concrete realization:** Trace “Promotion decision artifact” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M12.08-C082-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Promotion decision artifact” needed to preserve “Changing release bytes invalidates the corresponding promotion decision”; record an enforcement gap where only a model exists.
- [ ] **UC-M12.08-C082-T06 · Dependency connection:** Connect the “Promotion decision artifact” qualification artifact to selected release profiles, typed assurance evidence and required/optional gate evaluation; record the target identity and what the harness actually exercises.
- [ ] **UC-M12.08-C082-T07 · Resource behavior:** Account for “Artifact subjects and signature/record bytes” in “Promotion decision artifact”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M12.08-C082-T08 · Delivery check:** Run a known-valid control and a deliberately failing control for “Promotion decision artifact”; confirm the harness distinguishes their observed outcomes.
- [ ] **UC-M12.08-C082-T09 · Patch review:** Review the “Promotion decision artifact” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M12.08-C082-T10 · Delivery handoff:** Publish the “Promotion decision artifact” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M12.08-C083 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Changing release bytes invalidates the corresponding promotion decision. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M12.08-C083-T01 · Named property:** Create a stable property/check name under this parent for “Promotion decision artifact”; copy its required invariant exactly: “Changing release bytes invalidates the corresponding promotion decision”.
- [ ] **UC-M12.08-C083-T02 · Observable terms:** Define each term in the “Promotion decision artifact” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M12.08-C083-T03 · Precondition set:** List the preconditions under which “Changing release bytes invalidates the corresponding promotion decision” must hold for “Promotion decision artifact”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M12.08-C083-T04 · Transition coverage:** Map the “Promotion decision artifact” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M12.08-C083-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Promotion decision artifact”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M12.08-C083-T06 · Satisfying fixture:** Create a concrete “Promotion decision artifact” case that satisfies “Changing release bytes invalidates the corresponding promotion decision”; record its expected observation before running the assertion or review.
- [ ] **UC-M12.08-C083-T07 · Violating fixture:** Create the source counterexample “A promoted archive is repackaged with changed executable content” for “Promotion decision artifact”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M12.08-C083-T08 · Enforcement evidence:** Exercise the “Promotion decision artifact” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M12.08-C083-T09 · Regression linkage:** Link the “Promotion decision artifact” property to changes in selected release profiles, typed assurance evidence and required/optional gate evaluation; record which dependency or contract changes require rerunning it.
- [ ] **UC-M12.08-C083-T10 · Property disposition:** Compare the satisfying and violating “Promotion decision artifact” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M12.08-C084 · Integration

**Original checklist item:** Integrate promotion decision artifact with selected release profiles, typed assurance evidence and required/optional gate evaluation; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M12.08-C084-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Promotion decision artifact” across selected release profiles, typed assurance evidence and required/optional gate evaluation; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M12.08-C084-T02 · Field mapping:** Map every “Promotion decision artifact” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M12.08-C084-T03 · Prerequisite identities:** Record the actual prerequisites for “Promotion decision artifact” (source dependency list: UC-M09.05, UC-M09.07, UC-M12.01, UC-M12.02, UC-M12.03, UC-M12.04); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M12.08-C084-T04 · Ownership agreement:** Specify who owns “Promotion decision artifact” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M12.08-C084-T05 · Handoff implementation:** Connect “Promotion decision artifact” through the mapped seam using the real adapter or explicit specification reference; preserve “Changing release bytes invalidates the corresponding promotion decision” across the handoff.
- [ ] **UC-M12.08-C084-T06 · Absent-input case:** Omit one required “Promotion decision artifact” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M12.08-C084-T07 · Stale-input case:** Supply an outdated “Promotion decision artifact” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M12.08-C084-T08 · Incompatible-input case:** Supply an incompatible “Promotion decision artifact” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M12.08-C084-T09 · Valid integration trace:** Run a valid “Promotion decision artifact” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M12.08-C084-T10 · Seam review:** Reconcile the “Promotion decision artifact” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M12.08-C085 · Valid-case test

**Original checklist item:** Run a known-valid control for promotion decision artifact; verify that the harness reaches its intended target and compare observed measurements or verdicts with predeclared expectations.

- [ ] **UC-M12.08-C085-T01 · Valid fixture choice:** Choose a known-valid control for “Promotion decision artifact”; document why it should pass and how it proves the harness reaches the intended target.
- [ ] **UC-M12.08-C085-T02 · Expected-result oracle:** Specify the “Promotion decision artifact” expected result independently of the implementation output; include the property “Changing release bytes invalidates the corresponding promotion decision” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M12.08-C085-T03 · Fixture material:** Create the concrete “Promotion decision artifact” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M12.08-C085-T04 · Target preparation:** Prepare the “Promotion decision artifact” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M12.08-C085-T05 · Initial-state record:** Record the initial “Promotion decision artifact” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M12.08-C085-T06 · Valid-path execution:** Run the “Promotion decision artifact” known-valid control on the identified target; retain enough observations to prove the correct target was exercised.
- [ ] **UC-M12.08-C085-T07 · Outcome comparison:** Compare every declared “Promotion decision artifact” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M12.08-C085-T08 · State and bounds check:** Inspect the “Promotion decision artifact” ownership/state effects and actual use of “Artifact subjects and signature/record bytes”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M12.08-C085-T09 · Repeatability check:** Repeat the same “Promotion decision artifact” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M12.08-C085-T10 · Positive evidence:** Attach the “Promotion decision artifact” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M12.08-C086 · Negative test

**Original checklist item:** Negative case: A promoted archive is repackaged with changed executable content. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M12.08-C086-T01 · Adverse-case definition:** Create a test record for the exact “Promotion decision artifact” source counterexample: “A promoted archive is repackaged with changed executable content”; state which precondition or invariant it challenges.
- [ ] **UC-M12.08-C086-T02 · Safe fixture boundary:** Define the contained test boundary for “Promotion decision artifact”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M12.08-C086-T03 · Valid control:** Construct a valid “Promotion decision artifact” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M12.08-C086-T04 · Minimal adverse input:** Derive the “Promotion decision artifact” adverse fixture from the control with the smallest documented change needed to reproduce “A promoted archive is repackaged with changed executable content”; retain that change as reproducible data.
- [ ] **UC-M12.08-C086-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Promotion decision artifact”; require “Changing release bytes invalidates the corresponding promotion decision” and forbid a false-success verdict.
- [ ] **UC-M12.08-C086-T06 · Adverse execution:** Exercise the “Promotion decision artifact” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M12.08-C086-T07 · Effect inspection:** Inspect “Promotion decision artifact” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M12.08-C086-T08 · Refusal versus failure:** Confirm the “Promotion decision artifact” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M12.08-C086-T09 · Reset and retention:** Restore only the disposable “Promotion decision artifact” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M12.08-C086-T10 · Negative regression:** Register the “Promotion decision artifact” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M12.08-C087 · Change / failure test

**Original checklist item:** Exercise promotion decision artifact when a required gate is skipped, stale or supported only by a declaration; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M12.08-C087-T01 · Scenario record:** Write the “Promotion decision artifact” change/failure scenario exactly as supplied: a required gate is skipped, stale or supported only by a declaration; identify the property that must remain true: “Changing release bytes invalidates the corresponding promotion decision”.
- [ ] **UC-M12.08-C087-T02 · Baseline capture:** Create a known-valid “Promotion decision artifact” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M12.08-C087-T03 · Injection map:** Locate the “Promotion decision artifact” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M12.08-C087-T04 · Disposition oracle:** Define the legal intermediate and final “Promotion decision artifact” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M12.08-C087-T05 · Controlled trigger:** Introduce the controlled “Promotion decision artifact” scenario in the disposable fixture: a required gate is skipped, stale or supported only by a declaration; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M12.08-C087-T06 · Intermediate inspection:** Inspect the “Promotion decision artifact” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M12.08-C087-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Promotion decision artifact”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M12.08-C087-T08 · Stale-evidence cleanup:** Invalidate superseded “Promotion decision artifact” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M12.08-C087-T09 · Repeat and compare:** Repeat the selected “Promotion decision artifact” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M12.08-C087-T10 · Failure evidence:** Publish the “Promotion decision artifact” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M12.08-C088 · Bounds

**Original checklist item:** Set a documented campaign budget for artifact subjects and signature/record bytes; record actual consumption, incomplete coverage and the disposition when the budget is exhausted.

- [ ] **UC-M12.08-C088-T01 · Quantity inventory:** Create a measurement inventory for “Promotion decision artifact”: “Artifact subjects and signature/record bytes”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M12.08-C088-T02 · Measurement method:** Choose how to observe each “Promotion decision artifact” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M12.08-C088-T03 · Budget decision:** Select justified campaign and target-resource budgets for “Promotion decision artifact”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M12.08-C088-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Promotion decision artifact” cases for “Artifact subjects and signature/record bytes”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M12.08-C088-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Promotion decision artifact” limit; preserve “Changing release bytes invalidates the corresponding promotion decision”.
- [ ] **UC-M12.08-C088-T06 · Normal measurement:** Run or review the normal “Promotion decision artifact” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M12.08-C088-T07 · At-limit measurement:** Exercise the “Promotion decision artifact” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M12.08-C088-T08 · Over-limit measurement:** Exercise the “Promotion decision artifact” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M12.08-C088-T09 · Uncovered-scope report:** List the “Promotion decision artifact” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M12.08-C088-T10 · Limit evidence:** Publish the selected “Promotion decision artifact” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M12.08-C089 · Diagnostics / review

**Original checklist item:** Report promotion decision artifact results with executed, failed, skipped and unavailable cases separated; preserve the underlying observations and do not manufacture missing measurements.

- [ ] **UC-M12.08-C089-T01 · Result inventory:** Enumerate the required “Promotion decision artifact” qualification cases and intended targets before aggregating results; keep the planned denominator visible.
- [ ] **UC-M12.08-C089-T02 · Verdict schema:** Define separate executed-pass, executed-fail, skipped, unavailable and untested outcomes for “Promotion decision artifact”; document how incomplete cases block relevant claims.
- [ ] **UC-M12.08-C089-T03 · Identity fields:** Attach the actual target, fixture, configuration and revision identifiers to each “Promotion decision artifact” result; do not attribute host-only evidence to a guest or another OS.
- [ ] **UC-M12.08-C089-T04 · Observation capture:** Capture bounded raw “Promotion decision artifact” observations and harness errors; retain enough information to verify the reported oracle comparison.
- [ ] **UC-M12.08-C089-T05 · Aggregation rules:** Implement the “Promotion decision artifact” count/reduction rule so failures and missing measurements cannot disappear; preserve “Changing release bytes invalidates the corresponding promotion decision”.
- [ ] **UC-M12.08-C089-T06 · Failure visibility:** Feed a failing “Promotion decision artifact” control through the report path; assert the exact failed case and underlying observation remain visible.
- [ ] **UC-M12.08-C089-T07 · Missing-result visibility:** Withhold a required “Promotion decision artifact” measurement or target; verify the report uses unavailable/untested rather than a fabricated zero or passing value.
- [ ] **UC-M12.08-C089-T08 · Bounds and redaction:** Check “Promotion decision artifact” report size and retention against “Artifact subjects and signature/record bytes”; remove secrets while retaining fixture and subject references.
- [ ] **UC-M12.08-C089-T09 · Report reconciliation:** Reconcile the “Promotion decision artifact” summary with every underlying case record; account for the full planned denominator and all omitted scope.
- [ ] **UC-M12.08-C089-T10 · Qualification handoff:** Publish the “Promotion decision artifact” report with measured observations, coverage limits and blockers; state which actual targets remain unqualified.

### UC-M12.08-C090 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for promotion decision artifact; label unexecuted checks as untested.

- [ ] **UC-M12.08-C090-T01 · Evidence inventory:** List the “Promotion decision artifact” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M12.08-C090-T02 · Artifact references:** Record the exact “Promotion decision artifact” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M12.08-C090-T03 · Fixture references:** Attach the “Promotion decision artifact” fixture IDs, input identities and oracle definition; preserve the source counterexample “A promoted archive is repackaged with changed executable content” as a distinct evidence case.
- [ ] **UC-M12.08-C090-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Promotion decision artifact”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M12.08-C090-T05 · Environment record:** Record the actual “Promotion decision artifact” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M12.08-C090-T06 · Expected versus observed:** Pair every “Promotion decision artifact” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M12.08-C090-T07 · Failure and limit records:** Attach “Promotion decision artifact” change/failure and bounds evidence where required; include uncovered “Artifact subjects and signature/record bytes” and unresolved violations of “Changing release bytes invalidates the corresponding promotion decision”.
- [ ] **UC-M12.08-C090-T08 · Evidence hygiene:** Check the “Promotion decision artifact” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M12.08-C090-T09 · Reproduction review:** Have the “Promotion decision artifact” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M12.08-C090-T10 · Acceptance linkage:** Link the “Promotion decision artifact” evidence to its parent and UC-M12.08 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 10. False-promotion regression

**Source delivery:** Test skipped, untested, declaration-only and wrong-assurance evidence combinations.

**Source invariant:** No release is labeled operational or isolated while required gates remain unmet.

**Source negative case:** A required host-boundary gate is satisfied by a manifest declaration.

**Source bounded quantities:** Negative decision fixtures and evaluator runtime.

### UC-M12.08-C091 · Contract

**Original checklist item:** Define the qualification objective for false-promotion regression, including the actual target implementation, prerequisites, observable oracle and explicit exclusions.

- [ ] **UC-M12.08-C091-T01 · Scope statement:** Write the qualification question for “False-promotion regression”; identify the actual target, claimed capability and observations that can answer that question.
- [ ] **UC-M12.08-C091-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “False-promotion regression”; record each producer, representation and missing-value meaning.
- [ ] **UC-M12.08-C091-T03 · Output inventory:** List the outputs of “False-promotion regression” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M12.08-C091-T04 · Field dictionary:** Create a field-and-term dictionary for “False-promotion regression”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M12.08-C091-T05 · Prerequisite contract:** Map “False-promotion regression” to the source component prerequisites (UC-M09.05, UC-M09.07, UC-M12.01, UC-M12.02, UC-M12.03, UC-M12.04); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M12.08-C091-T06 · Authority map:** Identify who may produce, change and consume “False-promotion regression”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M12.08-C091-T07 · Invariant clause:** Add a normative clause for “False-promotion regression” that preserves “No release is labeled operational or isolated while required gates remain unmet”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M12.08-C091-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “False-promotion regression”; include the source counterexample “A required host-boundary gate is satisfied by a manifest declaration” and the intended safe disposition.
- [ ] **UC-M12.08-C091-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Negative decision fixtures and evaluator runtime” in the “False-promotion regression” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M12.08-C091-T10 · Contract review:** Review the “False-promotion regression” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M12.08-C092 · Delivery

**Original checklist item:** Test skipped, untested, declaration-only and wrong-assurance evidence combinations.

- [ ] **UC-M12.08-C092-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “False-promotion regression”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M12.08-C092-T02 · Change plan:** Break the source delivery for “False-promotion regression” into concrete edit targets and reviewable outputs; keep the UC-M12.08 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M12.08-C092-T03 · Core artifact:** Create the “False-promotion regression” fixture or harness for this source instruction: Test skipped, untested, declaration-only and wrong-assurance evidence combinations.
- [ ] **UC-M12.08-C092-T04 · Concrete realization:** Connect the “False-promotion regression” harness to its actual intended target, set the expected oracle before running it, and distinguish a mock/control run from a target run.
- [ ] **UC-M12.08-C092-T05 · Invariant protection:** Add the actual guard, check or review criterion for “False-promotion regression” needed to preserve “No release is labeled operational or isolated while required gates remain unmet”; record an enforcement gap where only a model exists.
- [ ] **UC-M12.08-C092-T06 · Dependency connection:** Connect the “False-promotion regression” qualification artifact to selected release profiles, typed assurance evidence and required/optional gate evaluation; record the target identity and what the harness actually exercises.
- [ ] **UC-M12.08-C092-T07 · Resource behavior:** Account for “Negative decision fixtures and evaluator runtime” in “False-promotion regression”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M12.08-C092-T08 · Delivery check:** Run a known-valid control and a deliberately failing control for “False-promotion regression”; confirm the harness distinguishes their observed outcomes.
- [ ] **UC-M12.08-C092-T09 · Patch review:** Review the “False-promotion regression” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M12.08-C092-T10 · Delivery handoff:** Publish the “False-promotion regression” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M12.08-C093 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: No release is labeled operational or isolated while required gates remain unmet. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M12.08-C093-T01 · Named property:** Create a stable property/check name under this parent for “False-promotion regression”; copy its required invariant exactly: “No release is labeled operational or isolated while required gates remain unmet”.
- [ ] **UC-M12.08-C093-T02 · Observable terms:** Define each term in the “False-promotion regression” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M12.08-C093-T03 · Precondition set:** List the preconditions under which “No release is labeled operational or isolated while required gates remain unmet” must hold for “False-promotion regression”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M12.08-C093-T04 · Transition coverage:** Map the “False-promotion regression” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M12.08-C093-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “False-promotion regression”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M12.08-C093-T06 · Satisfying fixture:** Create a concrete “False-promotion regression” case that satisfies “No release is labeled operational or isolated while required gates remain unmet”; record its expected observation before running the assertion or review.
- [ ] **UC-M12.08-C093-T07 · Violating fixture:** Create the source counterexample “A required host-boundary gate is satisfied by a manifest declaration” for “False-promotion regression”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M12.08-C093-T08 · Enforcement evidence:** Exercise the “False-promotion regression” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M12.08-C093-T09 · Regression linkage:** Link the “False-promotion regression” property to changes in selected release profiles, typed assurance evidence and required/optional gate evaluation; record which dependency or contract changes require rerunning it.
- [ ] **UC-M12.08-C093-T10 · Property disposition:** Compare the satisfying and violating “False-promotion regression” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M12.08-C094 · Integration

**Original checklist item:** Integrate false-promotion regression with selected release profiles, typed assurance evidence and required/optional gate evaluation; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M12.08-C094-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “False-promotion regression” across selected release profiles, typed assurance evidence and required/optional gate evaluation; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M12.08-C094-T02 · Field mapping:** Map every “False-promotion regression” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M12.08-C094-T03 · Prerequisite identities:** Record the actual prerequisites for “False-promotion regression” (source dependency list: UC-M09.05, UC-M09.07, UC-M12.01, UC-M12.02, UC-M12.03, UC-M12.04); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M12.08-C094-T04 · Ownership agreement:** Specify who owns “False-promotion regression” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M12.08-C094-T05 · Handoff implementation:** Connect “False-promotion regression” through the mapped seam using the real adapter or explicit specification reference; preserve “No release is labeled operational or isolated while required gates remain unmet” across the handoff.
- [ ] **UC-M12.08-C094-T06 · Absent-input case:** Omit one required “False-promotion regression” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M12.08-C094-T07 · Stale-input case:** Supply an outdated “False-promotion regression” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M12.08-C094-T08 · Incompatible-input case:** Supply an incompatible “False-promotion regression” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M12.08-C094-T09 · Valid integration trace:** Run a valid “False-promotion regression” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M12.08-C094-T10 · Seam review:** Reconcile the “False-promotion regression” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M12.08-C095 · Valid-case test

**Original checklist item:** Run a known-valid control for false-promotion regression; verify that the harness reaches its intended target and compare observed measurements or verdicts with predeclared expectations.

- [ ] **UC-M12.08-C095-T01 · Valid fixture choice:** Choose a known-valid control for “False-promotion regression”; document why it should pass and how it proves the harness reaches the intended target.
- [ ] **UC-M12.08-C095-T02 · Expected-result oracle:** Specify the “False-promotion regression” expected result independently of the implementation output; include the property “No release is labeled operational or isolated while required gates remain unmet” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M12.08-C095-T03 · Fixture material:** Create the concrete “False-promotion regression” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M12.08-C095-T04 · Target preparation:** Prepare the “False-promotion regression” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M12.08-C095-T05 · Initial-state record:** Record the initial “False-promotion regression” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M12.08-C095-T06 · Valid-path execution:** Run the “False-promotion regression” known-valid control on the identified target; retain enough observations to prove the correct target was exercised.
- [ ] **UC-M12.08-C095-T07 · Outcome comparison:** Compare every declared “False-promotion regression” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M12.08-C095-T08 · State and bounds check:** Inspect the “False-promotion regression” ownership/state effects and actual use of “Negative decision fixtures and evaluator runtime”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M12.08-C095-T09 · Repeatability check:** Repeat the same “False-promotion regression” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M12.08-C095-T10 · Positive evidence:** Attach the “False-promotion regression” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M12.08-C096 · Negative test

**Original checklist item:** Negative case: A required host-boundary gate is satisfied by a manifest declaration. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M12.08-C096-T01 · Adverse-case definition:** Create a test record for the exact “False-promotion regression” source counterexample: “A required host-boundary gate is satisfied by a manifest declaration”; state which precondition or invariant it challenges.
- [ ] **UC-M12.08-C096-T02 · Safe fixture boundary:** Define the contained test boundary for “False-promotion regression”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M12.08-C096-T03 · Valid control:** Construct a valid “False-promotion regression” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M12.08-C096-T04 · Minimal adverse input:** Derive the “False-promotion regression” adverse fixture from the control with the smallest documented change needed to reproduce “A required host-boundary gate is satisfied by a manifest declaration”; retain that change as reproducible data.
- [ ] **UC-M12.08-C096-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “False-promotion regression”; require “No release is labeled operational or isolated while required gates remain unmet” and forbid a false-success verdict.
- [ ] **UC-M12.08-C096-T06 · Adverse execution:** Exercise the “False-promotion regression” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M12.08-C096-T07 · Effect inspection:** Inspect “False-promotion regression” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M12.08-C096-T08 · Refusal versus failure:** Confirm the “False-promotion regression” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M12.08-C096-T09 · Reset and retention:** Restore only the disposable “False-promotion regression” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M12.08-C096-T10 · Negative regression:** Register the “False-promotion regression” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M12.08-C097 · Change / failure test

**Original checklist item:** Exercise false-promotion regression when a required gate is skipped, stale or supported only by a declaration; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M12.08-C097-T01 · Scenario record:** Write the “False-promotion regression” change/failure scenario exactly as supplied: a required gate is skipped, stale or supported only by a declaration; identify the property that must remain true: “No release is labeled operational or isolated while required gates remain unmet”.
- [ ] **UC-M12.08-C097-T02 · Baseline capture:** Create a known-valid “False-promotion regression” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M12.08-C097-T03 · Injection map:** Locate the “False-promotion regression” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M12.08-C097-T04 · Disposition oracle:** Define the legal intermediate and final “False-promotion regression” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M12.08-C097-T05 · Controlled trigger:** Introduce the controlled “False-promotion regression” scenario in the disposable fixture: a required gate is skipped, stale or supported only by a declaration; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M12.08-C097-T06 · Intermediate inspection:** Inspect the “False-promotion regression” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M12.08-C097-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “False-promotion regression”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M12.08-C097-T08 · Stale-evidence cleanup:** Invalidate superseded “False-promotion regression” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M12.08-C097-T09 · Repeat and compare:** Repeat the selected “False-promotion regression” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M12.08-C097-T10 · Failure evidence:** Publish the “False-promotion regression” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M12.08-C098 · Bounds

**Original checklist item:** Set a documented campaign budget for negative decision fixtures and evaluator runtime; record actual consumption, incomplete coverage and the disposition when the budget is exhausted.

- [ ] **UC-M12.08-C098-T01 · Quantity inventory:** Create a measurement inventory for “False-promotion regression”: “Negative decision fixtures and evaluator runtime”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M12.08-C098-T02 · Measurement method:** Choose how to observe each “False-promotion regression” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M12.08-C098-T03 · Budget decision:** Select justified campaign and target-resource budgets for “False-promotion regression”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M12.08-C098-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “False-promotion regression” cases for “Negative decision fixtures and evaluator runtime”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M12.08-C098-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “False-promotion regression” limit; preserve “No release is labeled operational or isolated while required gates remain unmet”.
- [ ] **UC-M12.08-C098-T06 · Normal measurement:** Run or review the normal “False-promotion regression” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M12.08-C098-T07 · At-limit measurement:** Exercise the “False-promotion regression” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M12.08-C098-T08 · Over-limit measurement:** Exercise the “False-promotion regression” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M12.08-C098-T09 · Uncovered-scope report:** List the “False-promotion regression” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M12.08-C098-T10 · Limit evidence:** Publish the selected “False-promotion regression” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M12.08-C099 · Diagnostics / review

**Original checklist item:** Report false-promotion regression results with executed, failed, skipped and unavailable cases separated; preserve the underlying observations and do not manufacture missing measurements.

- [ ] **UC-M12.08-C099-T01 · Result inventory:** Enumerate the required “False-promotion regression” qualification cases and intended targets before aggregating results; keep the planned denominator visible.
- [ ] **UC-M12.08-C099-T02 · Verdict schema:** Define separate executed-pass, executed-fail, skipped, unavailable and untested outcomes for “False-promotion regression”; document how incomplete cases block relevant claims.
- [ ] **UC-M12.08-C099-T03 · Identity fields:** Attach the actual target, fixture, configuration and revision identifiers to each “False-promotion regression” result; do not attribute host-only evidence to a guest or another OS.
- [ ] **UC-M12.08-C099-T04 · Observation capture:** Capture bounded raw “False-promotion regression” observations and harness errors; retain enough information to verify the reported oracle comparison.
- [ ] **UC-M12.08-C099-T05 · Aggregation rules:** Implement the “False-promotion regression” count/reduction rule so failures and missing measurements cannot disappear; preserve “No release is labeled operational or isolated while required gates remain unmet”.
- [ ] **UC-M12.08-C099-T06 · Failure visibility:** Feed a failing “False-promotion regression” control through the report path; assert the exact failed case and underlying observation remain visible.
- [ ] **UC-M12.08-C099-T07 · Missing-result visibility:** Withhold a required “False-promotion regression” measurement or target; verify the report uses unavailable/untested rather than a fabricated zero or passing value.
- [ ] **UC-M12.08-C099-T08 · Bounds and redaction:** Check “False-promotion regression” report size and retention against “Negative decision fixtures and evaluator runtime”; remove secrets while retaining fixture and subject references.
- [ ] **UC-M12.08-C099-T09 · Report reconciliation:** Reconcile the “False-promotion regression” summary with every underlying case record; account for the full planned denominator and all omitted scope.
- [ ] **UC-M12.08-C099-T10 · Qualification handoff:** Publish the “False-promotion regression” report with measured observations, coverage limits and blockers; state which actual targets remain unqualified.

### UC-M12.08-C100 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for false-promotion regression; label unexecuted checks as untested.

- [ ] **UC-M12.08-C100-T01 · Evidence inventory:** List the “False-promotion regression” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M12.08-C100-T02 · Artifact references:** Record the exact “False-promotion regression” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M12.08-C100-T03 · Fixture references:** Attach the “False-promotion regression” fixture IDs, input identities and oracle definition; preserve the source counterexample “A required host-boundary gate is satisfied by a manifest declaration” as a distinct evidence case.
- [ ] **UC-M12.08-C100-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “False-promotion regression”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M12.08-C100-T05 · Environment record:** Record the actual “False-promotion regression” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M12.08-C100-T06 · Expected versus observed:** Pair every “False-promotion regression” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M12.08-C100-T07 · Failure and limit records:** Attach “False-promotion regression” change/failure and bounds evidence where required; include uncovered “Negative decision fixtures and evaluator runtime” and unresolved violations of “No release is labeled operational or isolated while required gates remain unmet”.
- [ ] **UC-M12.08-C100-T08 · Evidence hygiene:** Check the “False-promotion regression” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M12.08-C100-T09 · Reproduction review:** Have the “False-promotion regression” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M12.08-C100-T10 · Acceptance linkage:** Link the “False-promotion regression” evidence to its parent and UC-M12.08 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

