# UC-M12.06 — Optional OCI packaging/runtime conformance

**To-Do Pack 2.0.0 · Baseline UC-2.2.0 · 100 parent checks × 10 subtasks = 1,000 to-dos**

[Master index](../../INDEX.md) · [Workstream index](../../w/12.md)

| Field | Preserved source value |
|---|---|
| Workstream | 12. Qualification, packaging and release |
| Milestone | C |
| Priority | P2 |
| Source assessment | MISSING |
| Scope | optional feature |
| Dependencies | [UC-M03.01](../03/UC-M03.01.md), [UC-M04.05](../04/UC-M04.05.md), [UC-M06.01](../06/UC-M06.01.md) |
| Source checklist pack | 1.0.0 |
| Original reference labels | [S5], [S6], [S7], [S8]. |

## Original requirement

When OCI compatibility is selected, map guest images and lifecycle to specific pinned specification versions rather than merely adopting container names.

**Original acceptance criterion:** OCI descriptors and chosen lifecycle contracts pass their conformance checks; unsupported OCI features are explicitly refused.

**Source trace:** Original checklist `UC100/c/12/UC-M12.06.md` inside [s/checklists.zip](../../s/checklists.zip); exact parent records in [data/parents.jsonl](../../data/parents.jsonl). Original roadmap lines 1149–1159 are preserved in [s/roadmap.md](../../s/roadmap.md).

## How to use these lists

Every parent statement below is preserved verbatim. Its ten child tasks are proposed decomposition, not implemented capabilities or executed tests. Child IDs append `-T01` through `-T10` to the original parent ID. All begin unchecked / `TODO`. Design/review evidence does not establish runtime enforcement; observe the actual selected target where the parent requires it.

The source dependency graph and selected release profile determine applicability. The numbered child sequence is a local working order, not an added hard dependency graph. An unselected optional feature needs a recorded not-applicable rationale; missing prerequisites for selected work remain blockers. Numerical budgets, backends and trust mechanisms remain decisions unless fixed by the source. Test hostile cases only with synthetic inputs in authorized disposable environments.

## 01. OCI opt-in decision

**Source delivery:** Enable OCI work only when interoperability is explicitly selected.

**Source invariant:** Offline first-guest completion does not require optional OCI support.

**Source negative case:** A local guest release is blocked solely by unselected OCI work.

**Source bounded quantities:** Selected profiles and integration points.

### UC-M12.06-C001 · Contract

**Original checklist item:** Define the qualification objective for OCI opt-in decision, including the actual target implementation, prerequisites, observable oracle and explicit exclusions.

- [ ] **UC-M12.06-C001-T01 · Scope statement:** Write the qualification question for “OCI opt-in decision”; identify the actual target, claimed capability and observations that can answer that question.
- [ ] **UC-M12.06-C001-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “OCI opt-in decision”; record each producer, representation and missing-value meaning.
- [ ] **UC-M12.06-C001-T03 · Output inventory:** List the outputs of “OCI opt-in decision” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M12.06-C001-T04 · Field dictionary:** Create a field-and-term dictionary for “OCI opt-in decision”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M12.06-C001-T05 · Prerequisite contract:** Map “OCI opt-in decision” to the source component prerequisites (UC-M03.01, UC-M04.05, UC-M06.01); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M12.06-C001-T06 · Authority map:** Identify who may produce, change and consume “OCI opt-in decision”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M12.06-C001-T07 · Invariant clause:** Add a normative clause for “OCI opt-in decision” that preserves “Offline first-guest completion does not require optional OCI support”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M12.06-C001-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “OCI opt-in decision”; include the source counterexample “A local guest release is blocked solely by unselected OCI work” and the intended safe disposition.
- [ ] **UC-M12.06-C001-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Selected profiles and integration points” in the “OCI opt-in decision” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M12.06-C001-T10 · Contract review:** Review the “OCI opt-in decision” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M12.06-C002 · Delivery

**Original checklist item:** Enable OCI work only when interoperability is explicitly selected.

- [ ] **UC-M12.06-C002-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “OCI opt-in decision”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M12.06-C002-T02 · Change plan:** Break the source delivery for “OCI opt-in decision” into concrete edit targets and reviewable outputs; keep the UC-M12.06 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M12.06-C002-T03 · Core artifact:** Implement the smallest selected-profile change for “OCI opt-in decision” that realizes this source instruction: Enable OCI work only when interoperability is explicitly selected.
- [ ] **UC-M12.06-C002-T04 · Concrete realization:** Trace “OCI opt-in decision” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M12.06-C002-T05 · Invariant protection:** Add the actual guard, check or review criterion for “OCI opt-in decision” needed to preserve “Offline first-guest completion does not require optional OCI support”; record an enforcement gap where only a model exists.
- [ ] **UC-M12.06-C002-T06 · Dependency connection:** Connect the “OCI opt-in decision” qualification artifact to pinned optional OCI contracts, guest artifact mapping and backend lifecycle adapters; record the target identity and what the harness actually exercises.
- [ ] **UC-M12.06-C002-T07 · Resource behavior:** Account for “Selected profiles and integration points” in “OCI opt-in decision”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M12.06-C002-T08 · Delivery check:** Run a known-valid control and a deliberately failing control for “OCI opt-in decision”; confirm the harness distinguishes their observed outcomes.
- [ ] **UC-M12.06-C002-T09 · Patch review:** Review the “OCI opt-in decision” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M12.06-C002-T10 · Delivery handoff:** Publish the “OCI opt-in decision” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M12.06-C003 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Offline first-guest completion does not require optional OCI support. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M12.06-C003-T01 · Named property:** Create a stable property/check name under this parent for “OCI opt-in decision”; copy its required invariant exactly: “Offline first-guest completion does not require optional OCI support”.
- [ ] **UC-M12.06-C003-T02 · Observable terms:** Define each term in the “OCI opt-in decision” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M12.06-C003-T03 · Precondition set:** List the preconditions under which “Offline first-guest completion does not require optional OCI support” must hold for “OCI opt-in decision”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M12.06-C003-T04 · Transition coverage:** Map the “OCI opt-in decision” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M12.06-C003-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “OCI opt-in decision”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M12.06-C003-T06 · Satisfying fixture:** Create a concrete “OCI opt-in decision” case that satisfies “Offline first-guest completion does not require optional OCI support”; record its expected observation before running the assertion or review.
- [ ] **UC-M12.06-C003-T07 · Violating fixture:** Create the source counterexample “A local guest release is blocked solely by unselected OCI work” for “OCI opt-in decision”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M12.06-C003-T08 · Enforcement evidence:** Exercise the “OCI opt-in decision” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M12.06-C003-T09 · Regression linkage:** Link the “OCI opt-in decision” property to changes in pinned optional OCI contracts, guest artifact mapping and backend lifecycle adapters; record which dependency or contract changes require rerunning it.
- [ ] **UC-M12.06-C003-T10 · Property disposition:** Compare the satisfying and violating “OCI opt-in decision” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M12.06-C004 · Integration

**Original checklist item:** Integrate OCI opt-in decision with pinned optional OCI contracts, guest artifact mapping and backend lifecycle adapters; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M12.06-C004-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “OCI opt-in decision” across pinned optional OCI contracts, guest artifact mapping and backend lifecycle adapters; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M12.06-C004-T02 · Field mapping:** Map every “OCI opt-in decision” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M12.06-C004-T03 · Prerequisite identities:** Record the actual prerequisites for “OCI opt-in decision” (source dependency list: UC-M03.01, UC-M04.05, UC-M06.01); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M12.06-C004-T04 · Ownership agreement:** Specify who owns “OCI opt-in decision” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M12.06-C004-T05 · Handoff implementation:** Connect “OCI opt-in decision” through the mapped seam using the real adapter or explicit specification reference; preserve “Offline first-guest completion does not require optional OCI support” across the handoff.
- [ ] **UC-M12.06-C004-T06 · Absent-input case:** Omit one required “OCI opt-in decision” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M12.06-C004-T07 · Stale-input case:** Supply an outdated “OCI opt-in decision” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M12.06-C004-T08 · Incompatible-input case:** Supply an incompatible “OCI opt-in decision” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M12.06-C004-T09 · Valid integration trace:** Run a valid “OCI opt-in decision” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M12.06-C004-T10 · Seam review:** Reconcile the “OCI opt-in decision” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M12.06-C005 · Valid-case test

**Original checklist item:** Run a known-valid control for OCI opt-in decision; verify that the harness reaches its intended target and compare observed measurements or verdicts with predeclared expectations.

- [ ] **UC-M12.06-C005-T01 · Valid fixture choice:** Choose a known-valid control for “OCI opt-in decision”; document why it should pass and how it proves the harness reaches the intended target.
- [ ] **UC-M12.06-C005-T02 · Expected-result oracle:** Specify the “OCI opt-in decision” expected result independently of the implementation output; include the property “Offline first-guest completion does not require optional OCI support” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M12.06-C005-T03 · Fixture material:** Create the concrete “OCI opt-in decision” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M12.06-C005-T04 · Target preparation:** Prepare the “OCI opt-in decision” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M12.06-C005-T05 · Initial-state record:** Record the initial “OCI opt-in decision” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M12.06-C005-T06 · Valid-path execution:** Run the “OCI opt-in decision” known-valid control on the identified target; retain enough observations to prove the correct target was exercised.
- [ ] **UC-M12.06-C005-T07 · Outcome comparison:** Compare every declared “OCI opt-in decision” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M12.06-C005-T08 · State and bounds check:** Inspect the “OCI opt-in decision” ownership/state effects and actual use of “Selected profiles and integration points”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M12.06-C005-T09 · Repeatability check:** Repeat the same “OCI opt-in decision” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M12.06-C005-T10 · Positive evidence:** Attach the “OCI opt-in decision” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M12.06-C006 · Negative test

**Original checklist item:** Negative case: A local guest release is blocked solely by unselected OCI work. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M12.06-C006-T01 · Adverse-case definition:** Create a test record for the exact “OCI opt-in decision” source counterexample: “A local guest release is blocked solely by unselected OCI work”; state which precondition or invariant it challenges.
- [ ] **UC-M12.06-C006-T02 · Safe fixture boundary:** Define the contained test boundary for “OCI opt-in decision”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M12.06-C006-T03 · Valid control:** Construct a valid “OCI opt-in decision” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M12.06-C006-T04 · Minimal adverse input:** Derive the “OCI opt-in decision” adverse fixture from the control with the smallest documented change needed to reproduce “A local guest release is blocked solely by unselected OCI work”; retain that change as reproducible data.
- [ ] **UC-M12.06-C006-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “OCI opt-in decision”; require “Offline first-guest completion does not require optional OCI support” and forbid a false-success verdict.
- [ ] **UC-M12.06-C006-T06 · Adverse execution:** Exercise the “OCI opt-in decision” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M12.06-C006-T07 · Effect inspection:** Inspect “OCI opt-in decision” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M12.06-C006-T08 · Refusal versus failure:** Confirm the “OCI opt-in decision” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M12.06-C006-T09 · Reset and retention:** Restore only the disposable “OCI opt-in decision” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M12.06-C006-T10 · Negative regression:** Register the “OCI opt-in decision” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M12.06-C007 · Change / failure test

**Original checklist item:** Exercise OCI opt-in decision when a consumer requests an unsupported specification feature or incompatible version; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M12.06-C007-T01 · Scenario record:** Write the “OCI opt-in decision” change/failure scenario exactly as supplied: a consumer requests an unsupported specification feature or incompatible version; identify the property that must remain true: “Offline first-guest completion does not require optional OCI support”.
- [ ] **UC-M12.06-C007-T02 · Baseline capture:** Create a known-valid “OCI opt-in decision” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M12.06-C007-T03 · Injection map:** Locate the “OCI opt-in decision” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M12.06-C007-T04 · Disposition oracle:** Define the legal intermediate and final “OCI opt-in decision” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M12.06-C007-T05 · Controlled trigger:** Introduce the controlled “OCI opt-in decision” scenario in the disposable fixture: a consumer requests an unsupported specification feature or incompatible version; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M12.06-C007-T06 · Intermediate inspection:** Inspect the “OCI opt-in decision” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M12.06-C007-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “OCI opt-in decision”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M12.06-C007-T08 · Stale-evidence cleanup:** Invalidate superseded “OCI opt-in decision” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M12.06-C007-T09 · Repeat and compare:** Repeat the selected “OCI opt-in decision” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M12.06-C007-T10 · Failure evidence:** Publish the “OCI opt-in decision” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M12.06-C008 · Bounds

**Original checklist item:** Set a documented campaign budget for selected profiles and integration points; record actual consumption, incomplete coverage and the disposition when the budget is exhausted.

- [ ] **UC-M12.06-C008-T01 · Quantity inventory:** Create a measurement inventory for “OCI opt-in decision”: “Selected profiles and integration points”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M12.06-C008-T02 · Measurement method:** Choose how to observe each “OCI opt-in decision” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M12.06-C008-T03 · Budget decision:** Select justified campaign and target-resource budgets for “OCI opt-in decision”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M12.06-C008-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “OCI opt-in decision” cases for “Selected profiles and integration points”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M12.06-C008-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “OCI opt-in decision” limit; preserve “Offline first-guest completion does not require optional OCI support”.
- [ ] **UC-M12.06-C008-T06 · Normal measurement:** Run or review the normal “OCI opt-in decision” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M12.06-C008-T07 · At-limit measurement:** Exercise the “OCI opt-in decision” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M12.06-C008-T08 · Over-limit measurement:** Exercise the “OCI opt-in decision” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M12.06-C008-T09 · Uncovered-scope report:** List the “OCI opt-in decision” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M12.06-C008-T10 · Limit evidence:** Publish the selected “OCI opt-in decision” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M12.06-C009 · Diagnostics / review

**Original checklist item:** Report OCI opt-in decision results with executed, failed, skipped and unavailable cases separated; preserve the underlying observations and do not manufacture missing measurements.

- [ ] **UC-M12.06-C009-T01 · Result inventory:** Enumerate the required “OCI opt-in decision” qualification cases and intended targets before aggregating results; keep the planned denominator visible.
- [ ] **UC-M12.06-C009-T02 · Verdict schema:** Define separate executed-pass, executed-fail, skipped, unavailable and untested outcomes for “OCI opt-in decision”; document how incomplete cases block relevant claims.
- [ ] **UC-M12.06-C009-T03 · Identity fields:** Attach the actual target, fixture, configuration and revision identifiers to each “OCI opt-in decision” result; do not attribute host-only evidence to a guest or another OS.
- [ ] **UC-M12.06-C009-T04 · Observation capture:** Capture bounded raw “OCI opt-in decision” observations and harness errors; retain enough information to verify the reported oracle comparison.
- [ ] **UC-M12.06-C009-T05 · Aggregation rules:** Implement the “OCI opt-in decision” count/reduction rule so failures and missing measurements cannot disappear; preserve “Offline first-guest completion does not require optional OCI support”.
- [ ] **UC-M12.06-C009-T06 · Failure visibility:** Feed a failing “OCI opt-in decision” control through the report path; assert the exact failed case and underlying observation remain visible.
- [ ] **UC-M12.06-C009-T07 · Missing-result visibility:** Withhold a required “OCI opt-in decision” measurement or target; verify the report uses unavailable/untested rather than a fabricated zero or passing value.
- [ ] **UC-M12.06-C009-T08 · Bounds and redaction:** Check “OCI opt-in decision” report size and retention against “Selected profiles and integration points”; remove secrets while retaining fixture and subject references.
- [ ] **UC-M12.06-C009-T09 · Report reconciliation:** Reconcile the “OCI opt-in decision” summary with every underlying case record; account for the full planned denominator and all omitted scope.
- [ ] **UC-M12.06-C009-T10 · Qualification handoff:** Publish the “OCI opt-in decision” report with measured observations, coverage limits and blockers; state which actual targets remain unqualified.

### UC-M12.06-C010 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for OCI opt-in decision; label unexecuted checks as untested.

- [ ] **UC-M12.06-C010-T01 · Evidence inventory:** List the “OCI opt-in decision” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M12.06-C010-T02 · Artifact references:** Record the exact “OCI opt-in decision” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M12.06-C010-T03 · Fixture references:** Attach the “OCI opt-in decision” fixture IDs, input identities and oracle definition; preserve the source counterexample “A local guest release is blocked solely by unselected OCI work” as a distinct evidence case.
- [ ] **UC-M12.06-C010-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “OCI opt-in decision”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M12.06-C010-T05 · Environment record:** Record the actual “OCI opt-in decision” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M12.06-C010-T06 · Expected versus observed:** Pair every “OCI opt-in decision” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M12.06-C010-T07 · Failure and limit records:** Attach “OCI opt-in decision” change/failure and bounds evidence where required; include uncovered “Selected profiles and integration points” and unresolved violations of “Offline first-guest completion does not require optional OCI support”.
- [ ] **UC-M12.06-C010-T08 · Evidence hygiene:** Check the “OCI opt-in decision” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M12.06-C010-T09 · Reproduction review:** Have the “OCI opt-in decision” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M12.06-C010-T10 · Acceptance linkage:** Link the “OCI opt-in decision” evidence to its parent and UC-M12.06 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 02. Specification version pinning

**Source delivery:** Choose exact image/runtime specification versions and supported subsets.

**Source invariant:** Compatibility claims refer to pinned contracts rather than container terminology.

**Source negative case:** A package claims generic OCI support without version or scope.

**Source bounded quantities:** Versions and supported features.

### UC-M12.06-C011 · Contract

**Original checklist item:** Define the qualification objective for specification version pinning, including the actual target implementation, prerequisites, observable oracle and explicit exclusions.

- [ ] **UC-M12.06-C011-T01 · Scope statement:** Write the qualification question for “Specification version pinning”; identify the actual target, claimed capability and observations that can answer that question.
- [ ] **UC-M12.06-C011-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Specification version pinning”; record each producer, representation and missing-value meaning.
- [ ] **UC-M12.06-C011-T03 · Output inventory:** List the outputs of “Specification version pinning” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M12.06-C011-T04 · Field dictionary:** Create a field-and-term dictionary for “Specification version pinning”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M12.06-C011-T05 · Prerequisite contract:** Map “Specification version pinning” to the source component prerequisites (UC-M03.01, UC-M04.05, UC-M06.01); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M12.06-C011-T06 · Authority map:** Identify who may produce, change and consume “Specification version pinning”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M12.06-C011-T07 · Invariant clause:** Add a normative clause for “Specification version pinning” that preserves “Compatibility claims refer to pinned contracts rather than container terminology”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M12.06-C011-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Specification version pinning”; include the source counterexample “A package claims generic OCI support without version or scope” and the intended safe disposition.
- [ ] **UC-M12.06-C011-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Versions and supported features” in the “Specification version pinning” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M12.06-C011-T10 · Contract review:** Review the “Specification version pinning” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M12.06-C012 · Delivery

**Original checklist item:** Choose exact image/runtime specification versions and supported subsets.

- [ ] **UC-M12.06-C012-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Specification version pinning”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M12.06-C012-T02 · Change plan:** Break the source delivery for “Specification version pinning” into concrete edit targets and reviewable outputs; keep the UC-M12.06 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M12.06-C012-T03 · Core artifact:** Prepare the “Specification version pinning” decision record for this source instruction: Choose exact image/runtime specification versions and supported subsets.
- [ ] **UC-M12.06-C012-T04 · Concrete realization:** Evaluate the “Specification version pinning” choice against its declared constraints; record the exact selected target/configuration and rejected alternatives, leaving unverified compatibility as a blocker.
- [ ] **UC-M12.06-C012-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Specification version pinning” needed to preserve “Compatibility claims refer to pinned contracts rather than container terminology”; record an enforcement gap where only a model exists.
- [ ] **UC-M12.06-C012-T06 · Dependency connection:** Connect the “Specification version pinning” qualification artifact to pinned optional OCI contracts, guest artifact mapping and backend lifecycle adapters; record the target identity and what the harness actually exercises.
- [ ] **UC-M12.06-C012-T07 · Resource behavior:** Account for “Versions and supported features” in “Specification version pinning”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M12.06-C012-T08 · Delivery check:** Run a known-valid control and a deliberately failing control for “Specification version pinning”; confirm the harness distinguishes their observed outcomes.
- [ ] **UC-M12.06-C012-T09 · Patch review:** Review the “Specification version pinning” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M12.06-C012-T10 · Delivery handoff:** Publish the “Specification version pinning” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M12.06-C013 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Compatibility claims refer to pinned contracts rather than container terminology. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M12.06-C013-T01 · Named property:** Create a stable property/check name under this parent for “Specification version pinning”; copy its required invariant exactly: “Compatibility claims refer to pinned contracts rather than container terminology”.
- [ ] **UC-M12.06-C013-T02 · Observable terms:** Define each term in the “Specification version pinning” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M12.06-C013-T03 · Precondition set:** List the preconditions under which “Compatibility claims refer to pinned contracts rather than container terminology” must hold for “Specification version pinning”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M12.06-C013-T04 · Transition coverage:** Map the “Specification version pinning” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M12.06-C013-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Specification version pinning”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M12.06-C013-T06 · Satisfying fixture:** Create a concrete “Specification version pinning” case that satisfies “Compatibility claims refer to pinned contracts rather than container terminology”; record its expected observation before running the assertion or review.
- [ ] **UC-M12.06-C013-T07 · Violating fixture:** Create the source counterexample “A package claims generic OCI support without version or scope” for “Specification version pinning”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M12.06-C013-T08 · Enforcement evidence:** Exercise the “Specification version pinning” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M12.06-C013-T09 · Regression linkage:** Link the “Specification version pinning” property to changes in pinned optional OCI contracts, guest artifact mapping and backend lifecycle adapters; record which dependency or contract changes require rerunning it.
- [ ] **UC-M12.06-C013-T10 · Property disposition:** Compare the satisfying and violating “Specification version pinning” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M12.06-C014 · Integration

**Original checklist item:** Integrate specification version pinning with pinned optional OCI contracts, guest artifact mapping and backend lifecycle adapters; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M12.06-C014-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Specification version pinning” across pinned optional OCI contracts, guest artifact mapping and backend lifecycle adapters; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M12.06-C014-T02 · Field mapping:** Map every “Specification version pinning” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M12.06-C014-T03 · Prerequisite identities:** Record the actual prerequisites for “Specification version pinning” (source dependency list: UC-M03.01, UC-M04.05, UC-M06.01); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M12.06-C014-T04 · Ownership agreement:** Specify who owns “Specification version pinning” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M12.06-C014-T05 · Handoff implementation:** Connect “Specification version pinning” through the mapped seam using the real adapter or explicit specification reference; preserve “Compatibility claims refer to pinned contracts rather than container terminology” across the handoff.
- [ ] **UC-M12.06-C014-T06 · Absent-input case:** Omit one required “Specification version pinning” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M12.06-C014-T07 · Stale-input case:** Supply an outdated “Specification version pinning” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M12.06-C014-T08 · Incompatible-input case:** Supply an incompatible “Specification version pinning” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M12.06-C014-T09 · Valid integration trace:** Run a valid “Specification version pinning” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M12.06-C014-T10 · Seam review:** Reconcile the “Specification version pinning” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M12.06-C015 · Valid-case test

**Original checklist item:** Run a known-valid control for specification version pinning; verify that the harness reaches its intended target and compare observed measurements or verdicts with predeclared expectations.

- [ ] **UC-M12.06-C015-T01 · Valid fixture choice:** Choose a known-valid control for “Specification version pinning”; document why it should pass and how it proves the harness reaches the intended target.
- [ ] **UC-M12.06-C015-T02 · Expected-result oracle:** Specify the “Specification version pinning” expected result independently of the implementation output; include the property “Compatibility claims refer to pinned contracts rather than container terminology” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M12.06-C015-T03 · Fixture material:** Create the concrete “Specification version pinning” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M12.06-C015-T04 · Target preparation:** Prepare the “Specification version pinning” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M12.06-C015-T05 · Initial-state record:** Record the initial “Specification version pinning” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M12.06-C015-T06 · Valid-path execution:** Run the “Specification version pinning” known-valid control on the identified target; retain enough observations to prove the correct target was exercised.
- [ ] **UC-M12.06-C015-T07 · Outcome comparison:** Compare every declared “Specification version pinning” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M12.06-C015-T08 · State and bounds check:** Inspect the “Specification version pinning” ownership/state effects and actual use of “Versions and supported features”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M12.06-C015-T09 · Repeatability check:** Repeat the same “Specification version pinning” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M12.06-C015-T10 · Positive evidence:** Attach the “Specification version pinning” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M12.06-C016 · Negative test

**Original checklist item:** Negative case: A package claims generic OCI support without version or scope. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M12.06-C016-T01 · Adverse-case definition:** Create a test record for the exact “Specification version pinning” source counterexample: “A package claims generic OCI support without version or scope”; state which precondition or invariant it challenges.
- [ ] **UC-M12.06-C016-T02 · Safe fixture boundary:** Define the contained test boundary for “Specification version pinning”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M12.06-C016-T03 · Valid control:** Construct a valid “Specification version pinning” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M12.06-C016-T04 · Minimal adverse input:** Derive the “Specification version pinning” adverse fixture from the control with the smallest documented change needed to reproduce “A package claims generic OCI support without version or scope”; retain that change as reproducible data.
- [ ] **UC-M12.06-C016-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Specification version pinning”; require “Compatibility claims refer to pinned contracts rather than container terminology” and forbid a false-success verdict.
- [ ] **UC-M12.06-C016-T06 · Adverse execution:** Exercise the “Specification version pinning” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M12.06-C016-T07 · Effect inspection:** Inspect “Specification version pinning” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M12.06-C016-T08 · Refusal versus failure:** Confirm the “Specification version pinning” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M12.06-C016-T09 · Reset and retention:** Restore only the disposable “Specification version pinning” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M12.06-C016-T10 · Negative regression:** Register the “Specification version pinning” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M12.06-C017 · Change / failure test

**Original checklist item:** Exercise specification version pinning when a consumer requests an unsupported specification feature or incompatible version; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M12.06-C017-T01 · Scenario record:** Write the “Specification version pinning” change/failure scenario exactly as supplied: a consumer requests an unsupported specification feature or incompatible version; identify the property that must remain true: “Compatibility claims refer to pinned contracts rather than container terminology”.
- [ ] **UC-M12.06-C017-T02 · Baseline capture:** Create a known-valid “Specification version pinning” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M12.06-C017-T03 · Injection map:** Locate the “Specification version pinning” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M12.06-C017-T04 · Disposition oracle:** Define the legal intermediate and final “Specification version pinning” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M12.06-C017-T05 · Controlled trigger:** Introduce the controlled “Specification version pinning” scenario in the disposable fixture: a consumer requests an unsupported specification feature or incompatible version; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M12.06-C017-T06 · Intermediate inspection:** Inspect the “Specification version pinning” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M12.06-C017-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Specification version pinning”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M12.06-C017-T08 · Stale-evidence cleanup:** Invalidate superseded “Specification version pinning” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M12.06-C017-T09 · Repeat and compare:** Repeat the selected “Specification version pinning” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M12.06-C017-T10 · Failure evidence:** Publish the “Specification version pinning” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M12.06-C018 · Bounds

**Original checklist item:** Set a documented campaign budget for versions and supported features; record actual consumption, incomplete coverage and the disposition when the budget is exhausted.

- [ ] **UC-M12.06-C018-T01 · Quantity inventory:** Create a measurement inventory for “Specification version pinning”: “Versions and supported features”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M12.06-C018-T02 · Measurement method:** Choose how to observe each “Specification version pinning” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M12.06-C018-T03 · Budget decision:** Select justified campaign and target-resource budgets for “Specification version pinning”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M12.06-C018-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Specification version pinning” cases for “Versions and supported features”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M12.06-C018-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Specification version pinning” limit; preserve “Compatibility claims refer to pinned contracts rather than container terminology”.
- [ ] **UC-M12.06-C018-T06 · Normal measurement:** Run or review the normal “Specification version pinning” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M12.06-C018-T07 · At-limit measurement:** Exercise the “Specification version pinning” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M12.06-C018-T08 · Over-limit measurement:** Exercise the “Specification version pinning” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M12.06-C018-T09 · Uncovered-scope report:** List the “Specification version pinning” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M12.06-C018-T10 · Limit evidence:** Publish the selected “Specification version pinning” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M12.06-C019 · Diagnostics / review

**Original checklist item:** Report specification version pinning results with executed, failed, skipped and unavailable cases separated; preserve the underlying observations and do not manufacture missing measurements.

- [ ] **UC-M12.06-C019-T01 · Result inventory:** Enumerate the required “Specification version pinning” qualification cases and intended targets before aggregating results; keep the planned denominator visible.
- [ ] **UC-M12.06-C019-T02 · Verdict schema:** Define separate executed-pass, executed-fail, skipped, unavailable and untested outcomes for “Specification version pinning”; document how incomplete cases block relevant claims.
- [ ] **UC-M12.06-C019-T03 · Identity fields:** Attach the actual target, fixture, configuration and revision identifiers to each “Specification version pinning” result; do not attribute host-only evidence to a guest or another OS.
- [ ] **UC-M12.06-C019-T04 · Observation capture:** Capture bounded raw “Specification version pinning” observations and harness errors; retain enough information to verify the reported oracle comparison.
- [ ] **UC-M12.06-C019-T05 · Aggregation rules:** Implement the “Specification version pinning” count/reduction rule so failures and missing measurements cannot disappear; preserve “Compatibility claims refer to pinned contracts rather than container terminology”.
- [ ] **UC-M12.06-C019-T06 · Failure visibility:** Feed a failing “Specification version pinning” control through the report path; assert the exact failed case and underlying observation remain visible.
- [ ] **UC-M12.06-C019-T07 · Missing-result visibility:** Withhold a required “Specification version pinning” measurement or target; verify the report uses unavailable/untested rather than a fabricated zero or passing value.
- [ ] **UC-M12.06-C019-T08 · Bounds and redaction:** Check “Specification version pinning” report size and retention against “Versions and supported features”; remove secrets while retaining fixture and subject references.
- [ ] **UC-M12.06-C019-T09 · Report reconciliation:** Reconcile the “Specification version pinning” summary with every underlying case record; account for the full planned denominator and all omitted scope.
- [ ] **UC-M12.06-C019-T10 · Qualification handoff:** Publish the “Specification version pinning” report with measured observations, coverage limits and blockers; state which actual targets remain unqualified.

### UC-M12.06-C020 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for specification version pinning; label unexecuted checks as untested.

- [ ] **UC-M12.06-C020-T01 · Evidence inventory:** List the “Specification version pinning” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M12.06-C020-T02 · Artifact references:** Record the exact “Specification version pinning” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M12.06-C020-T03 · Fixture references:** Attach the “Specification version pinning” fixture IDs, input identities and oracle definition; preserve the source counterexample “A package claims generic OCI support without version or scope” as a distinct evidence case.
- [ ] **UC-M12.06-C020-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Specification version pinning”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M12.06-C020-T05 · Environment record:** Record the actual “Specification version pinning” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M12.06-C020-T06 · Expected versus observed:** Pair every “Specification version pinning” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M12.06-C020-T07 · Failure and limit records:** Attach “Specification version pinning” change/failure and bounds evidence where required; include uncovered “Versions and supported features” and unresolved violations of “Compatibility claims refer to pinned contracts rather than container terminology”.
- [ ] **UC-M12.06-C020-T08 · Evidence hygiene:** Check the “Specification version pinning” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M12.06-C020-T09 · Reproduction review:** Have the “Specification version pinning” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M12.06-C020-T10 · Acceptance linkage:** Link the “Specification version pinning” evidence to its parent and UC-M12.06 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 03. Guest image mapping

**Source delivery:** Define how the selected guest artifacts map into the chosen image representation.

**Source invariant:** Descriptors identify the actual guest payload and required metadata.

**Source negative case:** A host script is labeled as the guest image payload.

**Source bounded quantities:** Descriptors and artifact bytes.

### UC-M12.06-C021 · Contract

**Original checklist item:** Define the qualification objective for guest image mapping, including the actual target implementation, prerequisites, observable oracle and explicit exclusions.

- [ ] **UC-M12.06-C021-T01 · Scope statement:** Write the qualification question for “Guest image mapping”; identify the actual target, claimed capability and observations that can answer that question.
- [ ] **UC-M12.06-C021-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Guest image mapping”; record each producer, representation and missing-value meaning.
- [ ] **UC-M12.06-C021-T03 · Output inventory:** List the outputs of “Guest image mapping” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M12.06-C021-T04 · Field dictionary:** Create a field-and-term dictionary for “Guest image mapping”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M12.06-C021-T05 · Prerequisite contract:** Map “Guest image mapping” to the source component prerequisites (UC-M03.01, UC-M04.05, UC-M06.01); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M12.06-C021-T06 · Authority map:** Identify who may produce, change and consume “Guest image mapping”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M12.06-C021-T07 · Invariant clause:** Add a normative clause for “Guest image mapping” that preserves “Descriptors identify the actual guest payload and required metadata”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M12.06-C021-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Guest image mapping”; include the source counterexample “A host script is labeled as the guest image payload” and the intended safe disposition.
- [ ] **UC-M12.06-C021-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Descriptors and artifact bytes” in the “Guest image mapping” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M12.06-C021-T10 · Contract review:** Review the “Guest image mapping” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M12.06-C022 · Delivery

**Original checklist item:** Define how the selected guest artifacts map into the chosen image representation.

- [ ] **UC-M12.06-C022-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Guest image mapping”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M12.06-C022-T02 · Change plan:** Break the source delivery for “Guest image mapping” into concrete edit targets and reviewable outputs; keep the UC-M12.06 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M12.06-C022-T03 · Core artifact:** Create the “Guest image mapping” model, schema or inventory that realizes this source instruction: Define how the selected guest artifacts map into the chosen image representation.
- [ ] **UC-M12.06-C022-T04 · Concrete realization:** Populate “Guest image mapping” with one concrete worked case; map every required entity or field to its source and flag any unmapped entry.
- [ ] **UC-M12.06-C022-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Guest image mapping” needed to preserve “Descriptors identify the actual guest payload and required metadata”; record an enforcement gap where only a model exists.
- [ ] **UC-M12.06-C022-T06 · Dependency connection:** Connect the “Guest image mapping” qualification artifact to pinned optional OCI contracts, guest artifact mapping and backend lifecycle adapters; record the target identity and what the harness actually exercises.
- [ ] **UC-M12.06-C022-T07 · Resource behavior:** Account for “Descriptors and artifact bytes” in “Guest image mapping”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M12.06-C022-T08 · Delivery check:** Run a known-valid control and a deliberately failing control for “Guest image mapping”; confirm the harness distinguishes their observed outcomes.
- [ ] **UC-M12.06-C022-T09 · Patch review:** Review the “Guest image mapping” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M12.06-C022-T10 · Delivery handoff:** Publish the “Guest image mapping” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M12.06-C023 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Descriptors identify the actual guest payload and required metadata. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M12.06-C023-T01 · Named property:** Create a stable property/check name under this parent for “Guest image mapping”; copy its required invariant exactly: “Descriptors identify the actual guest payload and required metadata”.
- [ ] **UC-M12.06-C023-T02 · Observable terms:** Define each term in the “Guest image mapping” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M12.06-C023-T03 · Precondition set:** List the preconditions under which “Descriptors identify the actual guest payload and required metadata” must hold for “Guest image mapping”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M12.06-C023-T04 · Transition coverage:** Map the “Guest image mapping” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M12.06-C023-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Guest image mapping”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M12.06-C023-T06 · Satisfying fixture:** Create a concrete “Guest image mapping” case that satisfies “Descriptors identify the actual guest payload and required metadata”; record its expected observation before running the assertion or review.
- [ ] **UC-M12.06-C023-T07 · Violating fixture:** Create the source counterexample “A host script is labeled as the guest image payload” for “Guest image mapping”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M12.06-C023-T08 · Enforcement evidence:** Exercise the “Guest image mapping” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M12.06-C023-T09 · Regression linkage:** Link the “Guest image mapping” property to changes in pinned optional OCI contracts, guest artifact mapping and backend lifecycle adapters; record which dependency or contract changes require rerunning it.
- [ ] **UC-M12.06-C023-T10 · Property disposition:** Compare the satisfying and violating “Guest image mapping” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M12.06-C024 · Integration

**Original checklist item:** Integrate guest image mapping with pinned optional OCI contracts, guest artifact mapping and backend lifecycle adapters; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M12.06-C024-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Guest image mapping” across pinned optional OCI contracts, guest artifact mapping and backend lifecycle adapters; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M12.06-C024-T02 · Field mapping:** Map every “Guest image mapping” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M12.06-C024-T03 · Prerequisite identities:** Record the actual prerequisites for “Guest image mapping” (source dependency list: UC-M03.01, UC-M04.05, UC-M06.01); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M12.06-C024-T04 · Ownership agreement:** Specify who owns “Guest image mapping” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M12.06-C024-T05 · Handoff implementation:** Connect “Guest image mapping” through the mapped seam using the real adapter or explicit specification reference; preserve “Descriptors identify the actual guest payload and required metadata” across the handoff.
- [ ] **UC-M12.06-C024-T06 · Absent-input case:** Omit one required “Guest image mapping” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M12.06-C024-T07 · Stale-input case:** Supply an outdated “Guest image mapping” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M12.06-C024-T08 · Incompatible-input case:** Supply an incompatible “Guest image mapping” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M12.06-C024-T09 · Valid integration trace:** Run a valid “Guest image mapping” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M12.06-C024-T10 · Seam review:** Reconcile the “Guest image mapping” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M12.06-C025 · Valid-case test

**Original checklist item:** Run a known-valid control for guest image mapping; verify that the harness reaches its intended target and compare observed measurements or verdicts with predeclared expectations.

- [ ] **UC-M12.06-C025-T01 · Valid fixture choice:** Choose a known-valid control for “Guest image mapping”; document why it should pass and how it proves the harness reaches the intended target.
- [ ] **UC-M12.06-C025-T02 · Expected-result oracle:** Specify the “Guest image mapping” expected result independently of the implementation output; include the property “Descriptors identify the actual guest payload and required metadata” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M12.06-C025-T03 · Fixture material:** Create the concrete “Guest image mapping” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M12.06-C025-T04 · Target preparation:** Prepare the “Guest image mapping” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M12.06-C025-T05 · Initial-state record:** Record the initial “Guest image mapping” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M12.06-C025-T06 · Valid-path execution:** Run the “Guest image mapping” known-valid control on the identified target; retain enough observations to prove the correct target was exercised.
- [ ] **UC-M12.06-C025-T07 · Outcome comparison:** Compare every declared “Guest image mapping” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M12.06-C025-T08 · State and bounds check:** Inspect the “Guest image mapping” ownership/state effects and actual use of “Descriptors and artifact bytes”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M12.06-C025-T09 · Repeatability check:** Repeat the same “Guest image mapping” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M12.06-C025-T10 · Positive evidence:** Attach the “Guest image mapping” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M12.06-C026 · Negative test

**Original checklist item:** Negative case: A host script is labeled as the guest image payload. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M12.06-C026-T01 · Adverse-case definition:** Create a test record for the exact “Guest image mapping” source counterexample: “A host script is labeled as the guest image payload”; state which precondition or invariant it challenges.
- [ ] **UC-M12.06-C026-T02 · Safe fixture boundary:** Define the contained test boundary for “Guest image mapping”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M12.06-C026-T03 · Valid control:** Construct a valid “Guest image mapping” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M12.06-C026-T04 · Minimal adverse input:** Derive the “Guest image mapping” adverse fixture from the control with the smallest documented change needed to reproduce “A host script is labeled as the guest image payload”; retain that change as reproducible data.
- [ ] **UC-M12.06-C026-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Guest image mapping”; require “Descriptors identify the actual guest payload and required metadata” and forbid a false-success verdict.
- [ ] **UC-M12.06-C026-T06 · Adverse execution:** Exercise the “Guest image mapping” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M12.06-C026-T07 · Effect inspection:** Inspect “Guest image mapping” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M12.06-C026-T08 · Refusal versus failure:** Confirm the “Guest image mapping” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M12.06-C026-T09 · Reset and retention:** Restore only the disposable “Guest image mapping” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M12.06-C026-T10 · Negative regression:** Register the “Guest image mapping” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M12.06-C027 · Change / failure test

**Original checklist item:** Exercise guest image mapping when a consumer requests an unsupported specification feature or incompatible version; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M12.06-C027-T01 · Scenario record:** Write the “Guest image mapping” change/failure scenario exactly as supplied: a consumer requests an unsupported specification feature or incompatible version; identify the property that must remain true: “Descriptors identify the actual guest payload and required metadata”.
- [ ] **UC-M12.06-C027-T02 · Baseline capture:** Create a known-valid “Guest image mapping” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M12.06-C027-T03 · Injection map:** Locate the “Guest image mapping” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M12.06-C027-T04 · Disposition oracle:** Define the legal intermediate and final “Guest image mapping” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M12.06-C027-T05 · Controlled trigger:** Introduce the controlled “Guest image mapping” scenario in the disposable fixture: a consumer requests an unsupported specification feature or incompatible version; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M12.06-C027-T06 · Intermediate inspection:** Inspect the “Guest image mapping” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M12.06-C027-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Guest image mapping”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M12.06-C027-T08 · Stale-evidence cleanup:** Invalidate superseded “Guest image mapping” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M12.06-C027-T09 · Repeat and compare:** Repeat the selected “Guest image mapping” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M12.06-C027-T10 · Failure evidence:** Publish the “Guest image mapping” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M12.06-C028 · Bounds

**Original checklist item:** Set a documented campaign budget for descriptors and artifact bytes; record actual consumption, incomplete coverage and the disposition when the budget is exhausted.

- [ ] **UC-M12.06-C028-T01 · Quantity inventory:** Create a measurement inventory for “Guest image mapping”: “Descriptors and artifact bytes”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M12.06-C028-T02 · Measurement method:** Choose how to observe each “Guest image mapping” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M12.06-C028-T03 · Budget decision:** Select justified campaign and target-resource budgets for “Guest image mapping”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M12.06-C028-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Guest image mapping” cases for “Descriptors and artifact bytes”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M12.06-C028-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Guest image mapping” limit; preserve “Descriptors identify the actual guest payload and required metadata”.
- [ ] **UC-M12.06-C028-T06 · Normal measurement:** Run or review the normal “Guest image mapping” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M12.06-C028-T07 · At-limit measurement:** Exercise the “Guest image mapping” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M12.06-C028-T08 · Over-limit measurement:** Exercise the “Guest image mapping” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M12.06-C028-T09 · Uncovered-scope report:** List the “Guest image mapping” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M12.06-C028-T10 · Limit evidence:** Publish the selected “Guest image mapping” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M12.06-C029 · Diagnostics / review

**Original checklist item:** Report guest image mapping results with executed, failed, skipped and unavailable cases separated; preserve the underlying observations and do not manufacture missing measurements.

- [ ] **UC-M12.06-C029-T01 · Result inventory:** Enumerate the required “Guest image mapping” qualification cases and intended targets before aggregating results; keep the planned denominator visible.
- [ ] **UC-M12.06-C029-T02 · Verdict schema:** Define separate executed-pass, executed-fail, skipped, unavailable and untested outcomes for “Guest image mapping”; document how incomplete cases block relevant claims.
- [ ] **UC-M12.06-C029-T03 · Identity fields:** Attach the actual target, fixture, configuration and revision identifiers to each “Guest image mapping” result; do not attribute host-only evidence to a guest or another OS.
- [ ] **UC-M12.06-C029-T04 · Observation capture:** Capture bounded raw “Guest image mapping” observations and harness errors; retain enough information to verify the reported oracle comparison.
- [ ] **UC-M12.06-C029-T05 · Aggregation rules:** Implement the “Guest image mapping” count/reduction rule so failures and missing measurements cannot disappear; preserve “Descriptors identify the actual guest payload and required metadata”.
- [ ] **UC-M12.06-C029-T06 · Failure visibility:** Feed a failing “Guest image mapping” control through the report path; assert the exact failed case and underlying observation remain visible.
- [ ] **UC-M12.06-C029-T07 · Missing-result visibility:** Withhold a required “Guest image mapping” measurement or target; verify the report uses unavailable/untested rather than a fabricated zero or passing value.
- [ ] **UC-M12.06-C029-T08 · Bounds and redaction:** Check “Guest image mapping” report size and retention against “Descriptors and artifact bytes”; remove secrets while retaining fixture and subject references.
- [ ] **UC-M12.06-C029-T09 · Report reconciliation:** Reconcile the “Guest image mapping” summary with every underlying case record; account for the full planned denominator and all omitted scope.
- [ ] **UC-M12.06-C029-T10 · Qualification handoff:** Publish the “Guest image mapping” report with measured observations, coverage limits and blockers; state which actual targets remain unqualified.

### UC-M12.06-C030 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for guest image mapping; label unexecuted checks as untested.

- [ ] **UC-M12.06-C030-T01 · Evidence inventory:** List the “Guest image mapping” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M12.06-C030-T02 · Artifact references:** Record the exact “Guest image mapping” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M12.06-C030-T03 · Fixture references:** Attach the “Guest image mapping” fixture IDs, input identities and oracle definition; preserve the source counterexample “A host script is labeled as the guest image payload” as a distinct evidence case.
- [ ] **UC-M12.06-C030-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Guest image mapping”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M12.06-C030-T05 · Environment record:** Record the actual “Guest image mapping” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M12.06-C030-T06 · Expected versus observed:** Pair every “Guest image mapping” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M12.06-C030-T07 · Failure and limit records:** Attach “Guest image mapping” change/failure and bounds evidence where required; include uncovered “Descriptors and artifact bytes” and unresolved violations of “Descriptors identify the actual guest payload and required metadata”.
- [ ] **UC-M12.06-C030-T08 · Evidence hygiene:** Check the “Guest image mapping” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M12.06-C030-T09 · Reproduction review:** Have the “Guest image mapping” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M12.06-C030-T10 · Acceptance linkage:** Link the “Guest image mapping” evidence to its parent and UC-M12.06 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 04. Content descriptor validation

**Source delivery:** Validate selected descriptor fields, lengths and digests according to the pinned contract.

**Source invariant:** Referenced content cannot be accepted from names alone.

**Source negative case:** A descriptor's digest does not match its blob.

**Source bounded quantities:** Descriptor count and verification bytes.

### UC-M12.06-C031 · Contract

**Original checklist item:** Define the qualification objective for content descriptor validation, including the actual target implementation, prerequisites, observable oracle and explicit exclusions.

- [ ] **UC-M12.06-C031-T01 · Scope statement:** Write the qualification question for “Content descriptor validation”; identify the actual target, claimed capability and observations that can answer that question.
- [ ] **UC-M12.06-C031-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Content descriptor validation”; record each producer, representation and missing-value meaning.
- [ ] **UC-M12.06-C031-T03 · Output inventory:** List the outputs of “Content descriptor validation” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M12.06-C031-T04 · Field dictionary:** Create a field-and-term dictionary for “Content descriptor validation”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M12.06-C031-T05 · Prerequisite contract:** Map “Content descriptor validation” to the source component prerequisites (UC-M03.01, UC-M04.05, UC-M06.01); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M12.06-C031-T06 · Authority map:** Identify who may produce, change and consume “Content descriptor validation”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M12.06-C031-T07 · Invariant clause:** Add a normative clause for “Content descriptor validation” that preserves “Referenced content cannot be accepted from names alone”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M12.06-C031-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Content descriptor validation”; include the source counterexample “A descriptor's digest does not match its blob” and the intended safe disposition.
- [ ] **UC-M12.06-C031-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Descriptor count and verification bytes” in the “Content descriptor validation” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M12.06-C031-T10 · Contract review:** Review the “Content descriptor validation” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M12.06-C032 · Delivery

**Original checklist item:** Validate selected descriptor fields, lengths and digests according to the pinned contract.

- [ ] **UC-M12.06-C032-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Content descriptor validation”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M12.06-C032-T02 · Change plan:** Break the source delivery for “Content descriptor validation” into concrete edit targets and reviewable outputs; keep the UC-M12.06 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M12.06-C032-T03 · Core artifact:** Implement the smallest selected-profile change for “Content descriptor validation” that realizes this source instruction: Validate selected descriptor fields, lengths and digests according to the pinned contract.
- [ ] **UC-M12.06-C032-T04 · Concrete realization:** Trace “Content descriptor validation” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M12.06-C032-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Content descriptor validation” needed to preserve “Referenced content cannot be accepted from names alone”; record an enforcement gap where only a model exists.
- [ ] **UC-M12.06-C032-T06 · Dependency connection:** Connect the “Content descriptor validation” qualification artifact to pinned optional OCI contracts, guest artifact mapping and backend lifecycle adapters; record the target identity and what the harness actually exercises.
- [ ] **UC-M12.06-C032-T07 · Resource behavior:** Account for “Descriptor count and verification bytes” in “Content descriptor validation”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M12.06-C032-T08 · Delivery check:** Run a known-valid control and a deliberately failing control for “Content descriptor validation”; confirm the harness distinguishes their observed outcomes.
- [ ] **UC-M12.06-C032-T09 · Patch review:** Review the “Content descriptor validation” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M12.06-C032-T10 · Delivery handoff:** Publish the “Content descriptor validation” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M12.06-C033 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Referenced content cannot be accepted from names alone. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M12.06-C033-T01 · Named property:** Create a stable property/check name under this parent for “Content descriptor validation”; copy its required invariant exactly: “Referenced content cannot be accepted from names alone”.
- [ ] **UC-M12.06-C033-T02 · Observable terms:** Define each term in the “Content descriptor validation” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M12.06-C033-T03 · Precondition set:** List the preconditions under which “Referenced content cannot be accepted from names alone” must hold for “Content descriptor validation”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M12.06-C033-T04 · Transition coverage:** Map the “Content descriptor validation” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M12.06-C033-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Content descriptor validation”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M12.06-C033-T06 · Satisfying fixture:** Create a concrete “Content descriptor validation” case that satisfies “Referenced content cannot be accepted from names alone”; record its expected observation before running the assertion or review.
- [ ] **UC-M12.06-C033-T07 · Violating fixture:** Create the source counterexample “A descriptor's digest does not match its blob” for “Content descriptor validation”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M12.06-C033-T08 · Enforcement evidence:** Exercise the “Content descriptor validation” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M12.06-C033-T09 · Regression linkage:** Link the “Content descriptor validation” property to changes in pinned optional OCI contracts, guest artifact mapping and backend lifecycle adapters; record which dependency or contract changes require rerunning it.
- [ ] **UC-M12.06-C033-T10 · Property disposition:** Compare the satisfying and violating “Content descriptor validation” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M12.06-C034 · Integration

**Original checklist item:** Integrate content descriptor validation with pinned optional OCI contracts, guest artifact mapping and backend lifecycle adapters; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M12.06-C034-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Content descriptor validation” across pinned optional OCI contracts, guest artifact mapping and backend lifecycle adapters; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M12.06-C034-T02 · Field mapping:** Map every “Content descriptor validation” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M12.06-C034-T03 · Prerequisite identities:** Record the actual prerequisites for “Content descriptor validation” (source dependency list: UC-M03.01, UC-M04.05, UC-M06.01); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M12.06-C034-T04 · Ownership agreement:** Specify who owns “Content descriptor validation” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M12.06-C034-T05 · Handoff implementation:** Connect “Content descriptor validation” through the mapped seam using the real adapter or explicit specification reference; preserve “Referenced content cannot be accepted from names alone” across the handoff.
- [ ] **UC-M12.06-C034-T06 · Absent-input case:** Omit one required “Content descriptor validation” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M12.06-C034-T07 · Stale-input case:** Supply an outdated “Content descriptor validation” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M12.06-C034-T08 · Incompatible-input case:** Supply an incompatible “Content descriptor validation” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M12.06-C034-T09 · Valid integration trace:** Run a valid “Content descriptor validation” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M12.06-C034-T10 · Seam review:** Reconcile the “Content descriptor validation” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M12.06-C035 · Valid-case test

**Original checklist item:** Run a known-valid control for content descriptor validation; verify that the harness reaches its intended target and compare observed measurements or verdicts with predeclared expectations.

- [ ] **UC-M12.06-C035-T01 · Valid fixture choice:** Choose a known-valid control for “Content descriptor validation”; document why it should pass and how it proves the harness reaches the intended target.
- [ ] **UC-M12.06-C035-T02 · Expected-result oracle:** Specify the “Content descriptor validation” expected result independently of the implementation output; include the property “Referenced content cannot be accepted from names alone” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M12.06-C035-T03 · Fixture material:** Create the concrete “Content descriptor validation” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M12.06-C035-T04 · Target preparation:** Prepare the “Content descriptor validation” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M12.06-C035-T05 · Initial-state record:** Record the initial “Content descriptor validation” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M12.06-C035-T06 · Valid-path execution:** Run the “Content descriptor validation” known-valid control on the identified target; retain enough observations to prove the correct target was exercised.
- [ ] **UC-M12.06-C035-T07 · Outcome comparison:** Compare every declared “Content descriptor validation” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M12.06-C035-T08 · State and bounds check:** Inspect the “Content descriptor validation” ownership/state effects and actual use of “Descriptor count and verification bytes”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M12.06-C035-T09 · Repeatability check:** Repeat the same “Content descriptor validation” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M12.06-C035-T10 · Positive evidence:** Attach the “Content descriptor validation” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M12.06-C036 · Negative test

**Original checklist item:** Negative case: A descriptor's digest does not match its blob. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M12.06-C036-T01 · Adverse-case definition:** Create a test record for the exact “Content descriptor validation” source counterexample: “A descriptor's digest does not match its blob”; state which precondition or invariant it challenges.
- [ ] **UC-M12.06-C036-T02 · Safe fixture boundary:** Define the contained test boundary for “Content descriptor validation”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M12.06-C036-T03 · Valid control:** Construct a valid “Content descriptor validation” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M12.06-C036-T04 · Minimal adverse input:** Derive the “Content descriptor validation” adverse fixture from the control with the smallest documented change needed to reproduce “A descriptor's digest does not match its blob”; retain that change as reproducible data.
- [ ] **UC-M12.06-C036-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Content descriptor validation”; require “Referenced content cannot be accepted from names alone” and forbid a false-success verdict.
- [ ] **UC-M12.06-C036-T06 · Adverse execution:** Exercise the “Content descriptor validation” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M12.06-C036-T07 · Effect inspection:** Inspect “Content descriptor validation” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M12.06-C036-T08 · Refusal versus failure:** Confirm the “Content descriptor validation” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M12.06-C036-T09 · Reset and retention:** Restore only the disposable “Content descriptor validation” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M12.06-C036-T10 · Negative regression:** Register the “Content descriptor validation” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M12.06-C037 · Change / failure test

**Original checklist item:** Exercise content descriptor validation when a consumer requests an unsupported specification feature or incompatible version; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M12.06-C037-T01 · Scenario record:** Write the “Content descriptor validation” change/failure scenario exactly as supplied: a consumer requests an unsupported specification feature or incompatible version; identify the property that must remain true: “Referenced content cannot be accepted from names alone”.
- [ ] **UC-M12.06-C037-T02 · Baseline capture:** Create a known-valid “Content descriptor validation” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M12.06-C037-T03 · Injection map:** Locate the “Content descriptor validation” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M12.06-C037-T04 · Disposition oracle:** Define the legal intermediate and final “Content descriptor validation” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M12.06-C037-T05 · Controlled trigger:** Introduce the controlled “Content descriptor validation” scenario in the disposable fixture: a consumer requests an unsupported specification feature or incompatible version; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M12.06-C037-T06 · Intermediate inspection:** Inspect the “Content descriptor validation” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M12.06-C037-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Content descriptor validation”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M12.06-C037-T08 · Stale-evidence cleanup:** Invalidate superseded “Content descriptor validation” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M12.06-C037-T09 · Repeat and compare:** Repeat the selected “Content descriptor validation” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M12.06-C037-T10 · Failure evidence:** Publish the “Content descriptor validation” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M12.06-C038 · Bounds

**Original checklist item:** Set a documented campaign budget for descriptor count and verification bytes; record actual consumption, incomplete coverage and the disposition when the budget is exhausted.

- [ ] **UC-M12.06-C038-T01 · Quantity inventory:** Create a measurement inventory for “Content descriptor validation”: “Descriptor count and verification bytes”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M12.06-C038-T02 · Measurement method:** Choose how to observe each “Content descriptor validation” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M12.06-C038-T03 · Budget decision:** Select justified campaign and target-resource budgets for “Content descriptor validation”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M12.06-C038-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Content descriptor validation” cases for “Descriptor count and verification bytes”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M12.06-C038-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Content descriptor validation” limit; preserve “Referenced content cannot be accepted from names alone”.
- [ ] **UC-M12.06-C038-T06 · Normal measurement:** Run or review the normal “Content descriptor validation” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M12.06-C038-T07 · At-limit measurement:** Exercise the “Content descriptor validation” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M12.06-C038-T08 · Over-limit measurement:** Exercise the “Content descriptor validation” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M12.06-C038-T09 · Uncovered-scope report:** List the “Content descriptor validation” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M12.06-C038-T10 · Limit evidence:** Publish the selected “Content descriptor validation” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M12.06-C039 · Diagnostics / review

**Original checklist item:** Report content descriptor validation results with executed, failed, skipped and unavailable cases separated; preserve the underlying observations and do not manufacture missing measurements.

- [ ] **UC-M12.06-C039-T01 · Result inventory:** Enumerate the required “Content descriptor validation” qualification cases and intended targets before aggregating results; keep the planned denominator visible.
- [ ] **UC-M12.06-C039-T02 · Verdict schema:** Define separate executed-pass, executed-fail, skipped, unavailable and untested outcomes for “Content descriptor validation”; document how incomplete cases block relevant claims.
- [ ] **UC-M12.06-C039-T03 · Identity fields:** Attach the actual target, fixture, configuration and revision identifiers to each “Content descriptor validation” result; do not attribute host-only evidence to a guest or another OS.
- [ ] **UC-M12.06-C039-T04 · Observation capture:** Capture bounded raw “Content descriptor validation” observations and harness errors; retain enough information to verify the reported oracle comparison.
- [ ] **UC-M12.06-C039-T05 · Aggregation rules:** Implement the “Content descriptor validation” count/reduction rule so failures and missing measurements cannot disappear; preserve “Referenced content cannot be accepted from names alone”.
- [ ] **UC-M12.06-C039-T06 · Failure visibility:** Feed a failing “Content descriptor validation” control through the report path; assert the exact failed case and underlying observation remain visible.
- [ ] **UC-M12.06-C039-T07 · Missing-result visibility:** Withhold a required “Content descriptor validation” measurement or target; verify the report uses unavailable/untested rather than a fabricated zero or passing value.
- [ ] **UC-M12.06-C039-T08 · Bounds and redaction:** Check “Content descriptor validation” report size and retention against “Descriptor count and verification bytes”; remove secrets while retaining fixture and subject references.
- [ ] **UC-M12.06-C039-T09 · Report reconciliation:** Reconcile the “Content descriptor validation” summary with every underlying case record; account for the full planned denominator and all omitted scope.
- [ ] **UC-M12.06-C039-T10 · Qualification handoff:** Publish the “Content descriptor validation” report with measured observations, coverage limits and blockers; state which actual targets remain unqualified.

### UC-M12.06-C040 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for content descriptor validation; label unexecuted checks as untested.

- [ ] **UC-M12.06-C040-T01 · Evidence inventory:** List the “Content descriptor validation” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M12.06-C040-T02 · Artifact references:** Record the exact “Content descriptor validation” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M12.06-C040-T03 · Fixture references:** Attach the “Content descriptor validation” fixture IDs, input identities and oracle definition; preserve the source counterexample “A descriptor's digest does not match its blob” as a distinct evidence case.
- [ ] **UC-M12.06-C040-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Content descriptor validation”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M12.06-C040-T05 · Environment record:** Record the actual “Content descriptor validation” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M12.06-C040-T06 · Expected versus observed:** Pair every “Content descriptor validation” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M12.06-C040-T07 · Failure and limit records:** Attach “Content descriptor validation” change/failure and bounds evidence where required; include uncovered “Descriptor count and verification bytes” and unresolved violations of “Referenced content cannot be accepted from names alone”.
- [ ] **UC-M12.06-C040-T08 · Evidence hygiene:** Check the “Content descriptor validation” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M12.06-C040-T09 · Reproduction review:** Have the “Content descriptor validation” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M12.06-C040-T10 · Acceptance linkage:** Link the “Content descriptor validation” evidence to its parent and UC-M12.06 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 05. Lifecycle mapping

**Source delivery:** Map create, start, inspect, stop and delete semantics to the selected guest backend.

**Source invariant:** Mapped lifecycle operations preserve the actual guest contract.

**Source negative case:** Start returns success without creating the required guest boundary.

**Source bounded quantities:** Operations and lifecycle fixtures.

### UC-M12.06-C041 · Contract

**Original checklist item:** Define the qualification objective for lifecycle mapping, including the actual target implementation, prerequisites, observable oracle and explicit exclusions.

- [ ] **UC-M12.06-C041-T01 · Scope statement:** Write the qualification question for “Lifecycle mapping”; identify the actual target, claimed capability and observations that can answer that question.
- [ ] **UC-M12.06-C041-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Lifecycle mapping”; record each producer, representation and missing-value meaning.
- [ ] **UC-M12.06-C041-T03 · Output inventory:** List the outputs of “Lifecycle mapping” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M12.06-C041-T04 · Field dictionary:** Create a field-and-term dictionary for “Lifecycle mapping”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M12.06-C041-T05 · Prerequisite contract:** Map “Lifecycle mapping” to the source component prerequisites (UC-M03.01, UC-M04.05, UC-M06.01); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M12.06-C041-T06 · Authority map:** Identify who may produce, change and consume “Lifecycle mapping”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M12.06-C041-T07 · Invariant clause:** Add a normative clause for “Lifecycle mapping” that preserves “Mapped lifecycle operations preserve the actual guest contract”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M12.06-C041-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Lifecycle mapping”; include the source counterexample “Start returns success without creating the required guest boundary” and the intended safe disposition.
- [ ] **UC-M12.06-C041-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Operations and lifecycle fixtures” in the “Lifecycle mapping” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M12.06-C041-T10 · Contract review:** Review the “Lifecycle mapping” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M12.06-C042 · Delivery

**Original checklist item:** Map create, start, inspect, stop and delete semantics to the selected guest backend.

- [ ] **UC-M12.06-C042-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Lifecycle mapping”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M12.06-C042-T02 · Change plan:** Break the source delivery for “Lifecycle mapping” into concrete edit targets and reviewable outputs; keep the UC-M12.06 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M12.06-C042-T03 · Core artifact:** Create the “Lifecycle mapping” model, schema or inventory that realizes this source instruction: Map create, start, inspect, stop and delete semantics to the selected guest backend.
- [ ] **UC-M12.06-C042-T04 · Concrete realization:** Populate “Lifecycle mapping” with one concrete worked case; map every required entity or field to its source and flag any unmapped entry.
- [ ] **UC-M12.06-C042-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Lifecycle mapping” needed to preserve “Mapped lifecycle operations preserve the actual guest contract”; record an enforcement gap where only a model exists.
- [ ] **UC-M12.06-C042-T06 · Dependency connection:** Connect the “Lifecycle mapping” qualification artifact to pinned optional OCI contracts, guest artifact mapping and backend lifecycle adapters; record the target identity and what the harness actually exercises.
- [ ] **UC-M12.06-C042-T07 · Resource behavior:** Account for “Operations and lifecycle fixtures” in “Lifecycle mapping”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M12.06-C042-T08 · Delivery check:** Run a known-valid control and a deliberately failing control for “Lifecycle mapping”; confirm the harness distinguishes their observed outcomes.
- [ ] **UC-M12.06-C042-T09 · Patch review:** Review the “Lifecycle mapping” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M12.06-C042-T10 · Delivery handoff:** Publish the “Lifecycle mapping” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M12.06-C043 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Mapped lifecycle operations preserve the actual guest contract. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M12.06-C043-T01 · Named property:** Create a stable property/check name under this parent for “Lifecycle mapping”; copy its required invariant exactly: “Mapped lifecycle operations preserve the actual guest contract”.
- [ ] **UC-M12.06-C043-T02 · Observable terms:** Define each term in the “Lifecycle mapping” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M12.06-C043-T03 · Precondition set:** List the preconditions under which “Mapped lifecycle operations preserve the actual guest contract” must hold for “Lifecycle mapping”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M12.06-C043-T04 · Transition coverage:** Map the “Lifecycle mapping” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M12.06-C043-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Lifecycle mapping”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M12.06-C043-T06 · Satisfying fixture:** Create a concrete “Lifecycle mapping” case that satisfies “Mapped lifecycle operations preserve the actual guest contract”; record its expected observation before running the assertion or review.
- [ ] **UC-M12.06-C043-T07 · Violating fixture:** Create the source counterexample “Start returns success without creating the required guest boundary” for “Lifecycle mapping”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M12.06-C043-T08 · Enforcement evidence:** Exercise the “Lifecycle mapping” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M12.06-C043-T09 · Regression linkage:** Link the “Lifecycle mapping” property to changes in pinned optional OCI contracts, guest artifact mapping and backend lifecycle adapters; record which dependency or contract changes require rerunning it.
- [ ] **UC-M12.06-C043-T10 · Property disposition:** Compare the satisfying and violating “Lifecycle mapping” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M12.06-C044 · Integration

**Original checklist item:** Integrate lifecycle mapping with pinned optional OCI contracts, guest artifact mapping and backend lifecycle adapters; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M12.06-C044-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Lifecycle mapping” across pinned optional OCI contracts, guest artifact mapping and backend lifecycle adapters; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M12.06-C044-T02 · Field mapping:** Map every “Lifecycle mapping” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M12.06-C044-T03 · Prerequisite identities:** Record the actual prerequisites for “Lifecycle mapping” (source dependency list: UC-M03.01, UC-M04.05, UC-M06.01); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M12.06-C044-T04 · Ownership agreement:** Specify who owns “Lifecycle mapping” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M12.06-C044-T05 · Handoff implementation:** Connect “Lifecycle mapping” through the mapped seam using the real adapter or explicit specification reference; preserve “Mapped lifecycle operations preserve the actual guest contract” across the handoff.
- [ ] **UC-M12.06-C044-T06 · Absent-input case:** Omit one required “Lifecycle mapping” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M12.06-C044-T07 · Stale-input case:** Supply an outdated “Lifecycle mapping” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M12.06-C044-T08 · Incompatible-input case:** Supply an incompatible “Lifecycle mapping” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M12.06-C044-T09 · Valid integration trace:** Run a valid “Lifecycle mapping” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M12.06-C044-T10 · Seam review:** Reconcile the “Lifecycle mapping” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M12.06-C045 · Valid-case test

**Original checklist item:** Run a known-valid control for lifecycle mapping; verify that the harness reaches its intended target and compare observed measurements or verdicts with predeclared expectations.

- [ ] **UC-M12.06-C045-T01 · Valid fixture choice:** Choose a known-valid control for “Lifecycle mapping”; document why it should pass and how it proves the harness reaches the intended target.
- [ ] **UC-M12.06-C045-T02 · Expected-result oracle:** Specify the “Lifecycle mapping” expected result independently of the implementation output; include the property “Mapped lifecycle operations preserve the actual guest contract” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M12.06-C045-T03 · Fixture material:** Create the concrete “Lifecycle mapping” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M12.06-C045-T04 · Target preparation:** Prepare the “Lifecycle mapping” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M12.06-C045-T05 · Initial-state record:** Record the initial “Lifecycle mapping” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M12.06-C045-T06 · Valid-path execution:** Run the “Lifecycle mapping” known-valid control on the identified target; retain enough observations to prove the correct target was exercised.
- [ ] **UC-M12.06-C045-T07 · Outcome comparison:** Compare every declared “Lifecycle mapping” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M12.06-C045-T08 · State and bounds check:** Inspect the “Lifecycle mapping” ownership/state effects and actual use of “Operations and lifecycle fixtures”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M12.06-C045-T09 · Repeatability check:** Repeat the same “Lifecycle mapping” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M12.06-C045-T10 · Positive evidence:** Attach the “Lifecycle mapping” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M12.06-C046 · Negative test

**Original checklist item:** Negative case: Start returns success without creating the required guest boundary. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M12.06-C046-T01 · Adverse-case definition:** Create a test record for the exact “Lifecycle mapping” source counterexample: “Start returns success without creating the required guest boundary”; state which precondition or invariant it challenges.
- [ ] **UC-M12.06-C046-T02 · Safe fixture boundary:** Define the contained test boundary for “Lifecycle mapping”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M12.06-C046-T03 · Valid control:** Construct a valid “Lifecycle mapping” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M12.06-C046-T04 · Minimal adverse input:** Derive the “Lifecycle mapping” adverse fixture from the control with the smallest documented change needed to reproduce “Start returns success without creating the required guest boundary”; retain that change as reproducible data.
- [ ] **UC-M12.06-C046-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Lifecycle mapping”; require “Mapped lifecycle operations preserve the actual guest contract” and forbid a false-success verdict.
- [ ] **UC-M12.06-C046-T06 · Adverse execution:** Exercise the “Lifecycle mapping” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M12.06-C046-T07 · Effect inspection:** Inspect “Lifecycle mapping” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M12.06-C046-T08 · Refusal versus failure:** Confirm the “Lifecycle mapping” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M12.06-C046-T09 · Reset and retention:** Restore only the disposable “Lifecycle mapping” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M12.06-C046-T10 · Negative regression:** Register the “Lifecycle mapping” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M12.06-C047 · Change / failure test

**Original checklist item:** Exercise lifecycle mapping when a consumer requests an unsupported specification feature or incompatible version; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M12.06-C047-T01 · Scenario record:** Write the “Lifecycle mapping” change/failure scenario exactly as supplied: a consumer requests an unsupported specification feature or incompatible version; identify the property that must remain true: “Mapped lifecycle operations preserve the actual guest contract”.
- [ ] **UC-M12.06-C047-T02 · Baseline capture:** Create a known-valid “Lifecycle mapping” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M12.06-C047-T03 · Injection map:** Locate the “Lifecycle mapping” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M12.06-C047-T04 · Disposition oracle:** Define the legal intermediate and final “Lifecycle mapping” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M12.06-C047-T05 · Controlled trigger:** Introduce the controlled “Lifecycle mapping” scenario in the disposable fixture: a consumer requests an unsupported specification feature or incompatible version; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M12.06-C047-T06 · Intermediate inspection:** Inspect the “Lifecycle mapping” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M12.06-C047-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Lifecycle mapping”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M12.06-C047-T08 · Stale-evidence cleanup:** Invalidate superseded “Lifecycle mapping” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M12.06-C047-T09 · Repeat and compare:** Repeat the selected “Lifecycle mapping” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M12.06-C047-T10 · Failure evidence:** Publish the “Lifecycle mapping” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M12.06-C048 · Bounds

**Original checklist item:** Set a documented campaign budget for operations and lifecycle fixtures; record actual consumption, incomplete coverage and the disposition when the budget is exhausted.

- [ ] **UC-M12.06-C048-T01 · Quantity inventory:** Create a measurement inventory for “Lifecycle mapping”: “Operations and lifecycle fixtures”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M12.06-C048-T02 · Measurement method:** Choose how to observe each “Lifecycle mapping” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M12.06-C048-T03 · Budget decision:** Select justified campaign and target-resource budgets for “Lifecycle mapping”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M12.06-C048-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Lifecycle mapping” cases for “Operations and lifecycle fixtures”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M12.06-C048-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Lifecycle mapping” limit; preserve “Mapped lifecycle operations preserve the actual guest contract”.
- [ ] **UC-M12.06-C048-T06 · Normal measurement:** Run or review the normal “Lifecycle mapping” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M12.06-C048-T07 · At-limit measurement:** Exercise the “Lifecycle mapping” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M12.06-C048-T08 · Over-limit measurement:** Exercise the “Lifecycle mapping” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M12.06-C048-T09 · Uncovered-scope report:** List the “Lifecycle mapping” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M12.06-C048-T10 · Limit evidence:** Publish the selected “Lifecycle mapping” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M12.06-C049 · Diagnostics / review

**Original checklist item:** Report lifecycle mapping results with executed, failed, skipped and unavailable cases separated; preserve the underlying observations and do not manufacture missing measurements.

- [ ] **UC-M12.06-C049-T01 · Result inventory:** Enumerate the required “Lifecycle mapping” qualification cases and intended targets before aggregating results; keep the planned denominator visible.
- [ ] **UC-M12.06-C049-T02 · Verdict schema:** Define separate executed-pass, executed-fail, skipped, unavailable and untested outcomes for “Lifecycle mapping”; document how incomplete cases block relevant claims.
- [ ] **UC-M12.06-C049-T03 · Identity fields:** Attach the actual target, fixture, configuration and revision identifiers to each “Lifecycle mapping” result; do not attribute host-only evidence to a guest or another OS.
- [ ] **UC-M12.06-C049-T04 · Observation capture:** Capture bounded raw “Lifecycle mapping” observations and harness errors; retain enough information to verify the reported oracle comparison.
- [ ] **UC-M12.06-C049-T05 · Aggregation rules:** Implement the “Lifecycle mapping” count/reduction rule so failures and missing measurements cannot disappear; preserve “Mapped lifecycle operations preserve the actual guest contract”.
- [ ] **UC-M12.06-C049-T06 · Failure visibility:** Feed a failing “Lifecycle mapping” control through the report path; assert the exact failed case and underlying observation remain visible.
- [ ] **UC-M12.06-C049-T07 · Missing-result visibility:** Withhold a required “Lifecycle mapping” measurement or target; verify the report uses unavailable/untested rather than a fabricated zero or passing value.
- [ ] **UC-M12.06-C049-T08 · Bounds and redaction:** Check “Lifecycle mapping” report size and retention against “Operations and lifecycle fixtures”; remove secrets while retaining fixture and subject references.
- [ ] **UC-M12.06-C049-T09 · Report reconciliation:** Reconcile the “Lifecycle mapping” summary with every underlying case record; account for the full planned denominator and all omitted scope.
- [ ] **UC-M12.06-C049-T10 · Qualification handoff:** Publish the “Lifecycle mapping” report with measured observations, coverage limits and blockers; state which actual targets remain unqualified.

### UC-M12.06-C050 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for lifecycle mapping; label unexecuted checks as untested.

- [ ] **UC-M12.06-C050-T01 · Evidence inventory:** List the “Lifecycle mapping” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M12.06-C050-T02 · Artifact references:** Record the exact “Lifecycle mapping” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M12.06-C050-T03 · Fixture references:** Attach the “Lifecycle mapping” fixture IDs, input identities and oracle definition; preserve the source counterexample “Start returns success without creating the required guest boundary” as a distinct evidence case.
- [ ] **UC-M12.06-C050-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Lifecycle mapping”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M12.06-C050-T05 · Environment record:** Record the actual “Lifecycle mapping” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M12.06-C050-T06 · Expected versus observed:** Pair every “Lifecycle mapping” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M12.06-C050-T07 · Failure and limit records:** Attach “Lifecycle mapping” change/failure and bounds evidence where required; include uncovered “Operations and lifecycle fixtures” and unresolved violations of “Mapped lifecycle operations preserve the actual guest contract”.
- [ ] **UC-M12.06-C050-T08 · Evidence hygiene:** Check the “Lifecycle mapping” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M12.06-C050-T09 · Reproduction review:** Have the “Lifecycle mapping” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M12.06-C050-T10 · Acceptance linkage:** Link the “Lifecycle mapping” evidence to its parent and UC-M12.06 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 06. Configuration translation

**Source delivery:** Translate only supported OCI configuration fields into explicit backend settings.

**Source invariant:** Unsupported fields cannot silently weaken isolation or resource policy.

**Source negative case:** An unimplemented network setting is ignored as successful configuration.

**Source bounded quantities:** Fields and translation rules.

### UC-M12.06-C051 · Contract

**Original checklist item:** Define the qualification objective for configuration translation, including the actual target implementation, prerequisites, observable oracle and explicit exclusions.

- [ ] **UC-M12.06-C051-T01 · Scope statement:** Write the qualification question for “Configuration translation”; identify the actual target, claimed capability and observations that can answer that question.
- [ ] **UC-M12.06-C051-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Configuration translation”; record each producer, representation and missing-value meaning.
- [ ] **UC-M12.06-C051-T03 · Output inventory:** List the outputs of “Configuration translation” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M12.06-C051-T04 · Field dictionary:** Create a field-and-term dictionary for “Configuration translation”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M12.06-C051-T05 · Prerequisite contract:** Map “Configuration translation” to the source component prerequisites (UC-M03.01, UC-M04.05, UC-M06.01); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M12.06-C051-T06 · Authority map:** Identify who may produce, change and consume “Configuration translation”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M12.06-C051-T07 · Invariant clause:** Add a normative clause for “Configuration translation” that preserves “Unsupported fields cannot silently weaken isolation or resource policy”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M12.06-C051-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Configuration translation”; include the source counterexample “An unimplemented network setting is ignored as successful configuration” and the intended safe disposition.
- [ ] **UC-M12.06-C051-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Fields and translation rules” in the “Configuration translation” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M12.06-C051-T10 · Contract review:** Review the “Configuration translation” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M12.06-C052 · Delivery

**Original checklist item:** Translate only supported OCI configuration fields into explicit backend settings.

- [ ] **UC-M12.06-C052-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Configuration translation”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M12.06-C052-T02 · Change plan:** Break the source delivery for “Configuration translation” into concrete edit targets and reviewable outputs; keep the UC-M12.06 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M12.06-C052-T03 · Core artifact:** Implement the smallest selected-profile change for “Configuration translation” that realizes this source instruction: Translate only supported OCI configuration fields into explicit backend settings.
- [ ] **UC-M12.06-C052-T04 · Concrete realization:** Trace “Configuration translation” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M12.06-C052-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Configuration translation” needed to preserve “Unsupported fields cannot silently weaken isolation or resource policy”; record an enforcement gap where only a model exists.
- [ ] **UC-M12.06-C052-T06 · Dependency connection:** Connect the “Configuration translation” qualification artifact to pinned optional OCI contracts, guest artifact mapping and backend lifecycle adapters; record the target identity and what the harness actually exercises.
- [ ] **UC-M12.06-C052-T07 · Resource behavior:** Account for “Fields and translation rules” in “Configuration translation”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M12.06-C052-T08 · Delivery check:** Run a known-valid control and a deliberately failing control for “Configuration translation”; confirm the harness distinguishes their observed outcomes.
- [ ] **UC-M12.06-C052-T09 · Patch review:** Review the “Configuration translation” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M12.06-C052-T10 · Delivery handoff:** Publish the “Configuration translation” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M12.06-C053 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Unsupported fields cannot silently weaken isolation or resource policy. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M12.06-C053-T01 · Named property:** Create a stable property/check name under this parent for “Configuration translation”; copy its required invariant exactly: “Unsupported fields cannot silently weaken isolation or resource policy”.
- [ ] **UC-M12.06-C053-T02 · Observable terms:** Define each term in the “Configuration translation” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M12.06-C053-T03 · Precondition set:** List the preconditions under which “Unsupported fields cannot silently weaken isolation or resource policy” must hold for “Configuration translation”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M12.06-C053-T04 · Transition coverage:** Map the “Configuration translation” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M12.06-C053-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Configuration translation”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M12.06-C053-T06 · Satisfying fixture:** Create a concrete “Configuration translation” case that satisfies “Unsupported fields cannot silently weaken isolation or resource policy”; record its expected observation before running the assertion or review.
- [ ] **UC-M12.06-C053-T07 · Violating fixture:** Create the source counterexample “An unimplemented network setting is ignored as successful configuration” for “Configuration translation”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M12.06-C053-T08 · Enforcement evidence:** Exercise the “Configuration translation” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M12.06-C053-T09 · Regression linkage:** Link the “Configuration translation” property to changes in pinned optional OCI contracts, guest artifact mapping and backend lifecycle adapters; record which dependency or contract changes require rerunning it.
- [ ] **UC-M12.06-C053-T10 · Property disposition:** Compare the satisfying and violating “Configuration translation” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M12.06-C054 · Integration

**Original checklist item:** Integrate configuration translation with pinned optional OCI contracts, guest artifact mapping and backend lifecycle adapters; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M12.06-C054-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Configuration translation” across pinned optional OCI contracts, guest artifact mapping and backend lifecycle adapters; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M12.06-C054-T02 · Field mapping:** Map every “Configuration translation” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M12.06-C054-T03 · Prerequisite identities:** Record the actual prerequisites for “Configuration translation” (source dependency list: UC-M03.01, UC-M04.05, UC-M06.01); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M12.06-C054-T04 · Ownership agreement:** Specify who owns “Configuration translation” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M12.06-C054-T05 · Handoff implementation:** Connect “Configuration translation” through the mapped seam using the real adapter or explicit specification reference; preserve “Unsupported fields cannot silently weaken isolation or resource policy” across the handoff.
- [ ] **UC-M12.06-C054-T06 · Absent-input case:** Omit one required “Configuration translation” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M12.06-C054-T07 · Stale-input case:** Supply an outdated “Configuration translation” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M12.06-C054-T08 · Incompatible-input case:** Supply an incompatible “Configuration translation” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M12.06-C054-T09 · Valid integration trace:** Run a valid “Configuration translation” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M12.06-C054-T10 · Seam review:** Reconcile the “Configuration translation” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M12.06-C055 · Valid-case test

**Original checklist item:** Run a known-valid control for configuration translation; verify that the harness reaches its intended target and compare observed measurements or verdicts with predeclared expectations.

- [ ] **UC-M12.06-C055-T01 · Valid fixture choice:** Choose a known-valid control for “Configuration translation”; document why it should pass and how it proves the harness reaches the intended target.
- [ ] **UC-M12.06-C055-T02 · Expected-result oracle:** Specify the “Configuration translation” expected result independently of the implementation output; include the property “Unsupported fields cannot silently weaken isolation or resource policy” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M12.06-C055-T03 · Fixture material:** Create the concrete “Configuration translation” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M12.06-C055-T04 · Target preparation:** Prepare the “Configuration translation” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M12.06-C055-T05 · Initial-state record:** Record the initial “Configuration translation” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M12.06-C055-T06 · Valid-path execution:** Run the “Configuration translation” known-valid control on the identified target; retain enough observations to prove the correct target was exercised.
- [ ] **UC-M12.06-C055-T07 · Outcome comparison:** Compare every declared “Configuration translation” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M12.06-C055-T08 · State and bounds check:** Inspect the “Configuration translation” ownership/state effects and actual use of “Fields and translation rules”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M12.06-C055-T09 · Repeatability check:** Repeat the same “Configuration translation” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M12.06-C055-T10 · Positive evidence:** Attach the “Configuration translation” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M12.06-C056 · Negative test

**Original checklist item:** Negative case: An unimplemented network setting is ignored as successful configuration. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M12.06-C056-T01 · Adverse-case definition:** Create a test record for the exact “Configuration translation” source counterexample: “An unimplemented network setting is ignored as successful configuration”; state which precondition or invariant it challenges.
- [ ] **UC-M12.06-C056-T02 · Safe fixture boundary:** Define the contained test boundary for “Configuration translation”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M12.06-C056-T03 · Valid control:** Construct a valid “Configuration translation” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M12.06-C056-T04 · Minimal adverse input:** Derive the “Configuration translation” adverse fixture from the control with the smallest documented change needed to reproduce “An unimplemented network setting is ignored as successful configuration”; retain that change as reproducible data.
- [ ] **UC-M12.06-C056-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Configuration translation”; require “Unsupported fields cannot silently weaken isolation or resource policy” and forbid a false-success verdict.
- [ ] **UC-M12.06-C056-T06 · Adverse execution:** Exercise the “Configuration translation” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M12.06-C056-T07 · Effect inspection:** Inspect “Configuration translation” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M12.06-C056-T08 · Refusal versus failure:** Confirm the “Configuration translation” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M12.06-C056-T09 · Reset and retention:** Restore only the disposable “Configuration translation” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M12.06-C056-T10 · Negative regression:** Register the “Configuration translation” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M12.06-C057 · Change / failure test

**Original checklist item:** Exercise configuration translation when a consumer requests an unsupported specification feature or incompatible version; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M12.06-C057-T01 · Scenario record:** Write the “Configuration translation” change/failure scenario exactly as supplied: a consumer requests an unsupported specification feature or incompatible version; identify the property that must remain true: “Unsupported fields cannot silently weaken isolation or resource policy”.
- [ ] **UC-M12.06-C057-T02 · Baseline capture:** Create a known-valid “Configuration translation” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M12.06-C057-T03 · Injection map:** Locate the “Configuration translation” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M12.06-C057-T04 · Disposition oracle:** Define the legal intermediate and final “Configuration translation” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M12.06-C057-T05 · Controlled trigger:** Introduce the controlled “Configuration translation” scenario in the disposable fixture: a consumer requests an unsupported specification feature or incompatible version; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M12.06-C057-T06 · Intermediate inspection:** Inspect the “Configuration translation” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M12.06-C057-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Configuration translation”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M12.06-C057-T08 · Stale-evidence cleanup:** Invalidate superseded “Configuration translation” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M12.06-C057-T09 · Repeat and compare:** Repeat the selected “Configuration translation” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M12.06-C057-T10 · Failure evidence:** Publish the “Configuration translation” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M12.06-C058 · Bounds

**Original checklist item:** Set a documented campaign budget for fields and translation rules; record actual consumption, incomplete coverage and the disposition when the budget is exhausted.

- [ ] **UC-M12.06-C058-T01 · Quantity inventory:** Create a measurement inventory for “Configuration translation”: “Fields and translation rules”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M12.06-C058-T02 · Measurement method:** Choose how to observe each “Configuration translation” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M12.06-C058-T03 · Budget decision:** Select justified campaign and target-resource budgets for “Configuration translation”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M12.06-C058-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Configuration translation” cases for “Fields and translation rules”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M12.06-C058-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Configuration translation” limit; preserve “Unsupported fields cannot silently weaken isolation or resource policy”.
- [ ] **UC-M12.06-C058-T06 · Normal measurement:** Run or review the normal “Configuration translation” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M12.06-C058-T07 · At-limit measurement:** Exercise the “Configuration translation” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M12.06-C058-T08 · Over-limit measurement:** Exercise the “Configuration translation” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M12.06-C058-T09 · Uncovered-scope report:** List the “Configuration translation” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M12.06-C058-T10 · Limit evidence:** Publish the selected “Configuration translation” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M12.06-C059 · Diagnostics / review

**Original checklist item:** Report configuration translation results with executed, failed, skipped and unavailable cases separated; preserve the underlying observations and do not manufacture missing measurements.

- [ ] **UC-M12.06-C059-T01 · Result inventory:** Enumerate the required “Configuration translation” qualification cases and intended targets before aggregating results; keep the planned denominator visible.
- [ ] **UC-M12.06-C059-T02 · Verdict schema:** Define separate executed-pass, executed-fail, skipped, unavailable and untested outcomes for “Configuration translation”; document how incomplete cases block relevant claims.
- [ ] **UC-M12.06-C059-T03 · Identity fields:** Attach the actual target, fixture, configuration and revision identifiers to each “Configuration translation” result; do not attribute host-only evidence to a guest or another OS.
- [ ] **UC-M12.06-C059-T04 · Observation capture:** Capture bounded raw “Configuration translation” observations and harness errors; retain enough information to verify the reported oracle comparison.
- [ ] **UC-M12.06-C059-T05 · Aggregation rules:** Implement the “Configuration translation” count/reduction rule so failures and missing measurements cannot disappear; preserve “Unsupported fields cannot silently weaken isolation or resource policy”.
- [ ] **UC-M12.06-C059-T06 · Failure visibility:** Feed a failing “Configuration translation” control through the report path; assert the exact failed case and underlying observation remain visible.
- [ ] **UC-M12.06-C059-T07 · Missing-result visibility:** Withhold a required “Configuration translation” measurement or target; verify the report uses unavailable/untested rather than a fabricated zero or passing value.
- [ ] **UC-M12.06-C059-T08 · Bounds and redaction:** Check “Configuration translation” report size and retention against “Fields and translation rules”; remove secrets while retaining fixture and subject references.
- [ ] **UC-M12.06-C059-T09 · Report reconciliation:** Reconcile the “Configuration translation” summary with every underlying case record; account for the full planned denominator and all omitted scope.
- [ ] **UC-M12.06-C059-T10 · Qualification handoff:** Publish the “Configuration translation” report with measured observations, coverage limits and blockers; state which actual targets remain unqualified.

### UC-M12.06-C060 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for configuration translation; label unexecuted checks as untested.

- [ ] **UC-M12.06-C060-T01 · Evidence inventory:** List the “Configuration translation” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M12.06-C060-T02 · Artifact references:** Record the exact “Configuration translation” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M12.06-C060-T03 · Fixture references:** Attach the “Configuration translation” fixture IDs, input identities and oracle definition; preserve the source counterexample “An unimplemented network setting is ignored as successful configuration” as a distinct evidence case.
- [ ] **UC-M12.06-C060-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Configuration translation”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M12.06-C060-T05 · Environment record:** Record the actual “Configuration translation” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M12.06-C060-T06 · Expected versus observed:** Pair every “Configuration translation” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M12.06-C060-T07 · Failure and limit records:** Attach “Configuration translation” change/failure and bounds evidence where required; include uncovered “Fields and translation rules” and unresolved violations of “Unsupported fields cannot silently weaken isolation or resource policy”.
- [ ] **UC-M12.06-C060-T08 · Evidence hygiene:** Check the “Configuration translation” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M12.06-C060-T09 · Reproduction review:** Have the “Configuration translation” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M12.06-C060-T10 · Acceptance linkage:** Link the “Configuration translation” evidence to its parent and UC-M12.06 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 07. Unsupported feature refusal

**Source delivery:** List and reject unsupported selected-spec features explicitly.

**Source invariant:** Partial compatibility is not presented as complete runtime support.

**Source negative case:** A caller requests an unsupported lifecycle feature and receives success.

**Source bounded quantities:** Unsupported features and refusal fixtures.

### UC-M12.06-C061 · Contract

**Original checklist item:** Define the qualification objective for unsupported feature refusal, including the actual target implementation, prerequisites, observable oracle and explicit exclusions.

- [ ] **UC-M12.06-C061-T01 · Scope statement:** Write the qualification question for “Unsupported feature refusal”; identify the actual target, claimed capability and observations that can answer that question.
- [ ] **UC-M12.06-C061-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Unsupported feature refusal”; record each producer, representation and missing-value meaning.
- [ ] **UC-M12.06-C061-T03 · Output inventory:** List the outputs of “Unsupported feature refusal” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M12.06-C061-T04 · Field dictionary:** Create a field-and-term dictionary for “Unsupported feature refusal”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M12.06-C061-T05 · Prerequisite contract:** Map “Unsupported feature refusal” to the source component prerequisites (UC-M03.01, UC-M04.05, UC-M06.01); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M12.06-C061-T06 · Authority map:** Identify who may produce, change and consume “Unsupported feature refusal”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M12.06-C061-T07 · Invariant clause:** Add a normative clause for “Unsupported feature refusal” that preserves “Partial compatibility is not presented as complete runtime support”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M12.06-C061-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Unsupported feature refusal”; include the source counterexample “A caller requests an unsupported lifecycle feature and receives success” and the intended safe disposition.
- [ ] **UC-M12.06-C061-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Unsupported features and refusal fixtures” in the “Unsupported feature refusal” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M12.06-C061-T10 · Contract review:** Review the “Unsupported feature refusal” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M12.06-C062 · Delivery

**Original checklist item:** List and reject unsupported selected-spec features explicitly.

- [ ] **UC-M12.06-C062-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Unsupported feature refusal”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M12.06-C062-T02 · Change plan:** Break the source delivery for “Unsupported feature refusal” into concrete edit targets and reviewable outputs; keep the UC-M12.06 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M12.06-C062-T03 · Core artifact:** Create the “Unsupported feature refusal” model, schema or inventory that realizes this source instruction: List and reject unsupported selected-spec features explicitly.
- [ ] **UC-M12.06-C062-T04 · Concrete realization:** Populate “Unsupported feature refusal” with one concrete worked case; map every required entity or field to its source and flag any unmapped entry.
- [ ] **UC-M12.06-C062-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Unsupported feature refusal” needed to preserve “Partial compatibility is not presented as complete runtime support”; record an enforcement gap where only a model exists.
- [ ] **UC-M12.06-C062-T06 · Dependency connection:** Connect the “Unsupported feature refusal” qualification artifact to pinned optional OCI contracts, guest artifact mapping and backend lifecycle adapters; record the target identity and what the harness actually exercises.
- [ ] **UC-M12.06-C062-T07 · Resource behavior:** Account for “Unsupported features and refusal fixtures” in “Unsupported feature refusal”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M12.06-C062-T08 · Delivery check:** Run a known-valid control and a deliberately failing control for “Unsupported feature refusal”; confirm the harness distinguishes their observed outcomes.
- [ ] **UC-M12.06-C062-T09 · Patch review:** Review the “Unsupported feature refusal” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M12.06-C062-T10 · Delivery handoff:** Publish the “Unsupported feature refusal” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M12.06-C063 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Partial compatibility is not presented as complete runtime support. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M12.06-C063-T01 · Named property:** Create a stable property/check name under this parent for “Unsupported feature refusal”; copy its required invariant exactly: “Partial compatibility is not presented as complete runtime support”.
- [ ] **UC-M12.06-C063-T02 · Observable terms:** Define each term in the “Unsupported feature refusal” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M12.06-C063-T03 · Precondition set:** List the preconditions under which “Partial compatibility is not presented as complete runtime support” must hold for “Unsupported feature refusal”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M12.06-C063-T04 · Transition coverage:** Map the “Unsupported feature refusal” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M12.06-C063-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Unsupported feature refusal”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M12.06-C063-T06 · Satisfying fixture:** Create a concrete “Unsupported feature refusal” case that satisfies “Partial compatibility is not presented as complete runtime support”; record its expected observation before running the assertion or review.
- [ ] **UC-M12.06-C063-T07 · Violating fixture:** Create the source counterexample “A caller requests an unsupported lifecycle feature and receives success” for “Unsupported feature refusal”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M12.06-C063-T08 · Enforcement evidence:** Exercise the “Unsupported feature refusal” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M12.06-C063-T09 · Regression linkage:** Link the “Unsupported feature refusal” property to changes in pinned optional OCI contracts, guest artifact mapping and backend lifecycle adapters; record which dependency or contract changes require rerunning it.
- [ ] **UC-M12.06-C063-T10 · Property disposition:** Compare the satisfying and violating “Unsupported feature refusal” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M12.06-C064 · Integration

**Original checklist item:** Integrate unsupported feature refusal with pinned optional OCI contracts, guest artifact mapping and backend lifecycle adapters; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M12.06-C064-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Unsupported feature refusal” across pinned optional OCI contracts, guest artifact mapping and backend lifecycle adapters; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M12.06-C064-T02 · Field mapping:** Map every “Unsupported feature refusal” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M12.06-C064-T03 · Prerequisite identities:** Record the actual prerequisites for “Unsupported feature refusal” (source dependency list: UC-M03.01, UC-M04.05, UC-M06.01); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M12.06-C064-T04 · Ownership agreement:** Specify who owns “Unsupported feature refusal” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M12.06-C064-T05 · Handoff implementation:** Connect “Unsupported feature refusal” through the mapped seam using the real adapter or explicit specification reference; preserve “Partial compatibility is not presented as complete runtime support” across the handoff.
- [ ] **UC-M12.06-C064-T06 · Absent-input case:** Omit one required “Unsupported feature refusal” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M12.06-C064-T07 · Stale-input case:** Supply an outdated “Unsupported feature refusal” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M12.06-C064-T08 · Incompatible-input case:** Supply an incompatible “Unsupported feature refusal” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M12.06-C064-T09 · Valid integration trace:** Run a valid “Unsupported feature refusal” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M12.06-C064-T10 · Seam review:** Reconcile the “Unsupported feature refusal” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M12.06-C065 · Valid-case test

**Original checklist item:** Run a known-valid control for unsupported feature refusal; verify that the harness reaches its intended target and compare observed measurements or verdicts with predeclared expectations.

- [ ] **UC-M12.06-C065-T01 · Valid fixture choice:** Choose a known-valid control for “Unsupported feature refusal”; document why it should pass and how it proves the harness reaches the intended target.
- [ ] **UC-M12.06-C065-T02 · Expected-result oracle:** Specify the “Unsupported feature refusal” expected result independently of the implementation output; include the property “Partial compatibility is not presented as complete runtime support” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M12.06-C065-T03 · Fixture material:** Create the concrete “Unsupported feature refusal” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M12.06-C065-T04 · Target preparation:** Prepare the “Unsupported feature refusal” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M12.06-C065-T05 · Initial-state record:** Record the initial “Unsupported feature refusal” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M12.06-C065-T06 · Valid-path execution:** Run the “Unsupported feature refusal” known-valid control on the identified target; retain enough observations to prove the correct target was exercised.
- [ ] **UC-M12.06-C065-T07 · Outcome comparison:** Compare every declared “Unsupported feature refusal” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M12.06-C065-T08 · State and bounds check:** Inspect the “Unsupported feature refusal” ownership/state effects and actual use of “Unsupported features and refusal fixtures”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M12.06-C065-T09 · Repeatability check:** Repeat the same “Unsupported feature refusal” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M12.06-C065-T10 · Positive evidence:** Attach the “Unsupported feature refusal” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M12.06-C066 · Negative test

**Original checklist item:** Negative case: A caller requests an unsupported lifecycle feature and receives success. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M12.06-C066-T01 · Adverse-case definition:** Create a test record for the exact “Unsupported feature refusal” source counterexample: “A caller requests an unsupported lifecycle feature and receives success”; state which precondition or invariant it challenges.
- [ ] **UC-M12.06-C066-T02 · Safe fixture boundary:** Define the contained test boundary for “Unsupported feature refusal”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M12.06-C066-T03 · Valid control:** Construct a valid “Unsupported feature refusal” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M12.06-C066-T04 · Minimal adverse input:** Derive the “Unsupported feature refusal” adverse fixture from the control with the smallest documented change needed to reproduce “A caller requests an unsupported lifecycle feature and receives success”; retain that change as reproducible data.
- [ ] **UC-M12.06-C066-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Unsupported feature refusal”; require “Partial compatibility is not presented as complete runtime support” and forbid a false-success verdict.
- [ ] **UC-M12.06-C066-T06 · Adverse execution:** Exercise the “Unsupported feature refusal” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M12.06-C066-T07 · Effect inspection:** Inspect “Unsupported feature refusal” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M12.06-C066-T08 · Refusal versus failure:** Confirm the “Unsupported feature refusal” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M12.06-C066-T09 · Reset and retention:** Restore only the disposable “Unsupported feature refusal” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M12.06-C066-T10 · Negative regression:** Register the “Unsupported feature refusal” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M12.06-C067 · Change / failure test

**Original checklist item:** Exercise unsupported feature refusal when a consumer requests an unsupported specification feature or incompatible version; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M12.06-C067-T01 · Scenario record:** Write the “Unsupported feature refusal” change/failure scenario exactly as supplied: a consumer requests an unsupported specification feature or incompatible version; identify the property that must remain true: “Partial compatibility is not presented as complete runtime support”.
- [ ] **UC-M12.06-C067-T02 · Baseline capture:** Create a known-valid “Unsupported feature refusal” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M12.06-C067-T03 · Injection map:** Locate the “Unsupported feature refusal” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M12.06-C067-T04 · Disposition oracle:** Define the legal intermediate and final “Unsupported feature refusal” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M12.06-C067-T05 · Controlled trigger:** Introduce the controlled “Unsupported feature refusal” scenario in the disposable fixture: a consumer requests an unsupported specification feature or incompatible version; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M12.06-C067-T06 · Intermediate inspection:** Inspect the “Unsupported feature refusal” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M12.06-C067-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Unsupported feature refusal”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M12.06-C067-T08 · Stale-evidence cleanup:** Invalidate superseded “Unsupported feature refusal” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M12.06-C067-T09 · Repeat and compare:** Repeat the selected “Unsupported feature refusal” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M12.06-C067-T10 · Failure evidence:** Publish the “Unsupported feature refusal” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M12.06-C068 · Bounds

**Original checklist item:** Set a documented campaign budget for unsupported features and refusal fixtures; record actual consumption, incomplete coverage and the disposition when the budget is exhausted.

- [ ] **UC-M12.06-C068-T01 · Quantity inventory:** Create a measurement inventory for “Unsupported feature refusal”: “Unsupported features and refusal fixtures”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M12.06-C068-T02 · Measurement method:** Choose how to observe each “Unsupported feature refusal” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M12.06-C068-T03 · Budget decision:** Select justified campaign and target-resource budgets for “Unsupported feature refusal”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M12.06-C068-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Unsupported feature refusal” cases for “Unsupported features and refusal fixtures”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M12.06-C068-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Unsupported feature refusal” limit; preserve “Partial compatibility is not presented as complete runtime support”.
- [ ] **UC-M12.06-C068-T06 · Normal measurement:** Run or review the normal “Unsupported feature refusal” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M12.06-C068-T07 · At-limit measurement:** Exercise the “Unsupported feature refusal” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M12.06-C068-T08 · Over-limit measurement:** Exercise the “Unsupported feature refusal” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M12.06-C068-T09 · Uncovered-scope report:** List the “Unsupported feature refusal” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M12.06-C068-T10 · Limit evidence:** Publish the selected “Unsupported feature refusal” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M12.06-C069 · Diagnostics / review

**Original checklist item:** Report unsupported feature refusal results with executed, failed, skipped and unavailable cases separated; preserve the underlying observations and do not manufacture missing measurements.

- [ ] **UC-M12.06-C069-T01 · Result inventory:** Enumerate the required “Unsupported feature refusal” qualification cases and intended targets before aggregating results; keep the planned denominator visible.
- [ ] **UC-M12.06-C069-T02 · Verdict schema:** Define separate executed-pass, executed-fail, skipped, unavailable and untested outcomes for “Unsupported feature refusal”; document how incomplete cases block relevant claims.
- [ ] **UC-M12.06-C069-T03 · Identity fields:** Attach the actual target, fixture, configuration and revision identifiers to each “Unsupported feature refusal” result; do not attribute host-only evidence to a guest or another OS.
- [ ] **UC-M12.06-C069-T04 · Observation capture:** Capture bounded raw “Unsupported feature refusal” observations and harness errors; retain enough information to verify the reported oracle comparison.
- [ ] **UC-M12.06-C069-T05 · Aggregation rules:** Implement the “Unsupported feature refusal” count/reduction rule so failures and missing measurements cannot disappear; preserve “Partial compatibility is not presented as complete runtime support”.
- [ ] **UC-M12.06-C069-T06 · Failure visibility:** Feed a failing “Unsupported feature refusal” control through the report path; assert the exact failed case and underlying observation remain visible.
- [ ] **UC-M12.06-C069-T07 · Missing-result visibility:** Withhold a required “Unsupported feature refusal” measurement or target; verify the report uses unavailable/untested rather than a fabricated zero or passing value.
- [ ] **UC-M12.06-C069-T08 · Bounds and redaction:** Check “Unsupported feature refusal” report size and retention against “Unsupported features and refusal fixtures”; remove secrets while retaining fixture and subject references.
- [ ] **UC-M12.06-C069-T09 · Report reconciliation:** Reconcile the “Unsupported feature refusal” summary with every underlying case record; account for the full planned denominator and all omitted scope.
- [ ] **UC-M12.06-C069-T10 · Qualification handoff:** Publish the “Unsupported feature refusal” report with measured observations, coverage limits and blockers; state which actual targets remain unqualified.

### UC-M12.06-C070 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for unsupported feature refusal; label unexecuted checks as untested.

- [ ] **UC-M12.06-C070-T01 · Evidence inventory:** List the “Unsupported feature refusal” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M12.06-C070-T02 · Artifact references:** Record the exact “Unsupported feature refusal” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M12.06-C070-T03 · Fixture references:** Attach the “Unsupported feature refusal” fixture IDs, input identities and oracle definition; preserve the source counterexample “A caller requests an unsupported lifecycle feature and receives success” as a distinct evidence case.
- [ ] **UC-M12.06-C070-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Unsupported feature refusal”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M12.06-C070-T05 · Environment record:** Record the actual “Unsupported feature refusal” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M12.06-C070-T06 · Expected versus observed:** Pair every “Unsupported feature refusal” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M12.06-C070-T07 · Failure and limit records:** Attach “Unsupported feature refusal” change/failure and bounds evidence where required; include uncovered “Unsupported features and refusal fixtures” and unresolved violations of “Partial compatibility is not presented as complete runtime support”.
- [ ] **UC-M12.06-C070-T08 · Evidence hygiene:** Check the “Unsupported feature refusal” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M12.06-C070-T09 · Reproduction review:** Have the “Unsupported feature refusal” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M12.06-C070-T10 · Acceptance linkage:** Link the “Unsupported feature refusal” evidence to its parent and UC-M12.06 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 08. Conformance harness

**Source delivery:** Run checks appropriate to the chosen pinned specification subset.

**Source invariant:** A package naming convention alone is not conformance evidence.

**Source negative case:** Only archive creation is tested while runtime conformance is claimed.

**Source bounded quantities:** Conformance cases and runtime budget.

### UC-M12.06-C071 · Contract

**Original checklist item:** Define the qualification objective for conformance harness, including the actual target implementation, prerequisites, observable oracle and explicit exclusions.

- [ ] **UC-M12.06-C071-T01 · Scope statement:** Write the qualification question for “Conformance harness”; identify the actual target, claimed capability and observations that can answer that question.
- [ ] **UC-M12.06-C071-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Conformance harness”; record each producer, representation and missing-value meaning.
- [ ] **UC-M12.06-C071-T03 · Output inventory:** List the outputs of “Conformance harness” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M12.06-C071-T04 · Field dictionary:** Create a field-and-term dictionary for “Conformance harness”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M12.06-C071-T05 · Prerequisite contract:** Map “Conformance harness” to the source component prerequisites (UC-M03.01, UC-M04.05, UC-M06.01); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M12.06-C071-T06 · Authority map:** Identify who may produce, change and consume “Conformance harness”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M12.06-C071-T07 · Invariant clause:** Add a normative clause for “Conformance harness” that preserves “A package naming convention alone is not conformance evidence”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M12.06-C071-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Conformance harness”; include the source counterexample “Only archive creation is tested while runtime conformance is claimed” and the intended safe disposition.
- [ ] **UC-M12.06-C071-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Conformance cases and runtime budget” in the “Conformance harness” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M12.06-C071-T10 · Contract review:** Review the “Conformance harness” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M12.06-C072 · Delivery

**Original checklist item:** Run checks appropriate to the chosen pinned specification subset.

- [ ] **UC-M12.06-C072-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Conformance harness”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M12.06-C072-T02 · Change plan:** Break the source delivery for “Conformance harness” into concrete edit targets and reviewable outputs; keep the UC-M12.06 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M12.06-C072-T03 · Core artifact:** Create the “Conformance harness” fixture or harness for this source instruction: Run checks appropriate to the chosen pinned specification subset.
- [ ] **UC-M12.06-C072-T04 · Concrete realization:** Connect the “Conformance harness” harness to its actual intended target, set the expected oracle before running it, and distinguish a mock/control run from a target run.
- [ ] **UC-M12.06-C072-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Conformance harness” needed to preserve “A package naming convention alone is not conformance evidence”; record an enforcement gap where only a model exists.
- [ ] **UC-M12.06-C072-T06 · Dependency connection:** Connect the “Conformance harness” qualification artifact to pinned optional OCI contracts, guest artifact mapping and backend lifecycle adapters; record the target identity and what the harness actually exercises.
- [ ] **UC-M12.06-C072-T07 · Resource behavior:** Account for “Conformance cases and runtime budget” in “Conformance harness”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M12.06-C072-T08 · Delivery check:** Run a known-valid control and a deliberately failing control for “Conformance harness”; confirm the harness distinguishes their observed outcomes.
- [ ] **UC-M12.06-C072-T09 · Patch review:** Review the “Conformance harness” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M12.06-C072-T10 · Delivery handoff:** Publish the “Conformance harness” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M12.06-C073 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: A package naming convention alone is not conformance evidence. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M12.06-C073-T01 · Named property:** Create a stable property/check name under this parent for “Conformance harness”; copy its required invariant exactly: “A package naming convention alone is not conformance evidence”.
- [ ] **UC-M12.06-C073-T02 · Observable terms:** Define each term in the “Conformance harness” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M12.06-C073-T03 · Precondition set:** List the preconditions under which “A package naming convention alone is not conformance evidence” must hold for “Conformance harness”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M12.06-C073-T04 · Transition coverage:** Map the “Conformance harness” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M12.06-C073-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Conformance harness”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M12.06-C073-T06 · Satisfying fixture:** Create a concrete “Conformance harness” case that satisfies “A package naming convention alone is not conformance evidence”; record its expected observation before running the assertion or review.
- [ ] **UC-M12.06-C073-T07 · Violating fixture:** Create the source counterexample “Only archive creation is tested while runtime conformance is claimed” for “Conformance harness”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M12.06-C073-T08 · Enforcement evidence:** Exercise the “Conformance harness” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M12.06-C073-T09 · Regression linkage:** Link the “Conformance harness” property to changes in pinned optional OCI contracts, guest artifact mapping and backend lifecycle adapters; record which dependency or contract changes require rerunning it.
- [ ] **UC-M12.06-C073-T10 · Property disposition:** Compare the satisfying and violating “Conformance harness” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M12.06-C074 · Integration

**Original checklist item:** Integrate conformance harness with pinned optional OCI contracts, guest artifact mapping and backend lifecycle adapters; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M12.06-C074-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Conformance harness” across pinned optional OCI contracts, guest artifact mapping and backend lifecycle adapters; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M12.06-C074-T02 · Field mapping:** Map every “Conformance harness” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M12.06-C074-T03 · Prerequisite identities:** Record the actual prerequisites for “Conformance harness” (source dependency list: UC-M03.01, UC-M04.05, UC-M06.01); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M12.06-C074-T04 · Ownership agreement:** Specify who owns “Conformance harness” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M12.06-C074-T05 · Handoff implementation:** Connect “Conformance harness” through the mapped seam using the real adapter or explicit specification reference; preserve “A package naming convention alone is not conformance evidence” across the handoff.
- [ ] **UC-M12.06-C074-T06 · Absent-input case:** Omit one required “Conformance harness” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M12.06-C074-T07 · Stale-input case:** Supply an outdated “Conformance harness” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M12.06-C074-T08 · Incompatible-input case:** Supply an incompatible “Conformance harness” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M12.06-C074-T09 · Valid integration trace:** Run a valid “Conformance harness” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M12.06-C074-T10 · Seam review:** Reconcile the “Conformance harness” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M12.06-C075 · Valid-case test

**Original checklist item:** Run a known-valid control for conformance harness; verify that the harness reaches its intended target and compare observed measurements or verdicts with predeclared expectations.

- [ ] **UC-M12.06-C075-T01 · Valid fixture choice:** Choose a known-valid control for “Conformance harness”; document why it should pass and how it proves the harness reaches the intended target.
- [ ] **UC-M12.06-C075-T02 · Expected-result oracle:** Specify the “Conformance harness” expected result independently of the implementation output; include the property “A package naming convention alone is not conformance evidence” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M12.06-C075-T03 · Fixture material:** Create the concrete “Conformance harness” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M12.06-C075-T04 · Target preparation:** Prepare the “Conformance harness” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M12.06-C075-T05 · Initial-state record:** Record the initial “Conformance harness” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M12.06-C075-T06 · Valid-path execution:** Run the “Conformance harness” known-valid control on the identified target; retain enough observations to prove the correct target was exercised.
- [ ] **UC-M12.06-C075-T07 · Outcome comparison:** Compare every declared “Conformance harness” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M12.06-C075-T08 · State and bounds check:** Inspect the “Conformance harness” ownership/state effects and actual use of “Conformance cases and runtime budget”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M12.06-C075-T09 · Repeatability check:** Repeat the same “Conformance harness” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M12.06-C075-T10 · Positive evidence:** Attach the “Conformance harness” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M12.06-C076 · Negative test

**Original checklist item:** Negative case: Only archive creation is tested while runtime conformance is claimed. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M12.06-C076-T01 · Adverse-case definition:** Create a test record for the exact “Conformance harness” source counterexample: “Only archive creation is tested while runtime conformance is claimed”; state which precondition or invariant it challenges.
- [ ] **UC-M12.06-C076-T02 · Safe fixture boundary:** Define the contained test boundary for “Conformance harness”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M12.06-C076-T03 · Valid control:** Construct a valid “Conformance harness” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M12.06-C076-T04 · Minimal adverse input:** Derive the “Conformance harness” adverse fixture from the control with the smallest documented change needed to reproduce “Only archive creation is tested while runtime conformance is claimed”; retain that change as reproducible data.
- [ ] **UC-M12.06-C076-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Conformance harness”; require “A package naming convention alone is not conformance evidence” and forbid a false-success verdict.
- [ ] **UC-M12.06-C076-T06 · Adverse execution:** Exercise the “Conformance harness” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M12.06-C076-T07 · Effect inspection:** Inspect “Conformance harness” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M12.06-C076-T08 · Refusal versus failure:** Confirm the “Conformance harness” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M12.06-C076-T09 · Reset and retention:** Restore only the disposable “Conformance harness” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M12.06-C076-T10 · Negative regression:** Register the “Conformance harness” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M12.06-C077 · Change / failure test

**Original checklist item:** Exercise conformance harness when a consumer requests an unsupported specification feature or incompatible version; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M12.06-C077-T01 · Scenario record:** Write the “Conformance harness” change/failure scenario exactly as supplied: a consumer requests an unsupported specification feature or incompatible version; identify the property that must remain true: “A package naming convention alone is not conformance evidence”.
- [ ] **UC-M12.06-C077-T02 · Baseline capture:** Create a known-valid “Conformance harness” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M12.06-C077-T03 · Injection map:** Locate the “Conformance harness” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M12.06-C077-T04 · Disposition oracle:** Define the legal intermediate and final “Conformance harness” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M12.06-C077-T05 · Controlled trigger:** Introduce the controlled “Conformance harness” scenario in the disposable fixture: a consumer requests an unsupported specification feature or incompatible version; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M12.06-C077-T06 · Intermediate inspection:** Inspect the “Conformance harness” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M12.06-C077-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Conformance harness”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M12.06-C077-T08 · Stale-evidence cleanup:** Invalidate superseded “Conformance harness” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M12.06-C077-T09 · Repeat and compare:** Repeat the selected “Conformance harness” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M12.06-C077-T10 · Failure evidence:** Publish the “Conformance harness” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M12.06-C078 · Bounds

**Original checklist item:** Set a documented campaign budget for conformance cases and runtime budget; record actual consumption, incomplete coverage and the disposition when the budget is exhausted.

- [ ] **UC-M12.06-C078-T01 · Quantity inventory:** Create a measurement inventory for “Conformance harness”: “Conformance cases and runtime budget”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M12.06-C078-T02 · Measurement method:** Choose how to observe each “Conformance harness” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M12.06-C078-T03 · Budget decision:** Select justified campaign and target-resource budgets for “Conformance harness”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M12.06-C078-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Conformance harness” cases for “Conformance cases and runtime budget”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M12.06-C078-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Conformance harness” limit; preserve “A package naming convention alone is not conformance evidence”.
- [ ] **UC-M12.06-C078-T06 · Normal measurement:** Run or review the normal “Conformance harness” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M12.06-C078-T07 · At-limit measurement:** Exercise the “Conformance harness” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M12.06-C078-T08 · Over-limit measurement:** Exercise the “Conformance harness” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M12.06-C078-T09 · Uncovered-scope report:** List the “Conformance harness” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M12.06-C078-T10 · Limit evidence:** Publish the selected “Conformance harness” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M12.06-C079 · Diagnostics / review

**Original checklist item:** Report conformance harness results with executed, failed, skipped and unavailable cases separated; preserve the underlying observations and do not manufacture missing measurements.

- [ ] **UC-M12.06-C079-T01 · Result inventory:** Enumerate the required “Conformance harness” qualification cases and intended targets before aggregating results; keep the planned denominator visible.
- [ ] **UC-M12.06-C079-T02 · Verdict schema:** Define separate executed-pass, executed-fail, skipped, unavailable and untested outcomes for “Conformance harness”; document how incomplete cases block relevant claims.
- [ ] **UC-M12.06-C079-T03 · Identity fields:** Attach the actual target, fixture, configuration and revision identifiers to each “Conformance harness” result; do not attribute host-only evidence to a guest or another OS.
- [ ] **UC-M12.06-C079-T04 · Observation capture:** Capture bounded raw “Conformance harness” observations and harness errors; retain enough information to verify the reported oracle comparison.
- [ ] **UC-M12.06-C079-T05 · Aggregation rules:** Implement the “Conformance harness” count/reduction rule so failures and missing measurements cannot disappear; preserve “A package naming convention alone is not conformance evidence”.
- [ ] **UC-M12.06-C079-T06 · Failure visibility:** Feed a failing “Conformance harness” control through the report path; assert the exact failed case and underlying observation remain visible.
- [ ] **UC-M12.06-C079-T07 · Missing-result visibility:** Withhold a required “Conformance harness” measurement or target; verify the report uses unavailable/untested rather than a fabricated zero or passing value.
- [ ] **UC-M12.06-C079-T08 · Bounds and redaction:** Check “Conformance harness” report size and retention against “Conformance cases and runtime budget”; remove secrets while retaining fixture and subject references.
- [ ] **UC-M12.06-C079-T09 · Report reconciliation:** Reconcile the “Conformance harness” summary with every underlying case record; account for the full planned denominator and all omitted scope.
- [ ] **UC-M12.06-C079-T10 · Qualification handoff:** Publish the “Conformance harness” report with measured observations, coverage limits and blockers; state which actual targets remain unqualified.

### UC-M12.06-C080 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for conformance harness; label unexecuted checks as untested.

- [ ] **UC-M12.06-C080-T01 · Evidence inventory:** List the “Conformance harness” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M12.06-C080-T02 · Artifact references:** Record the exact “Conformance harness” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M12.06-C080-T03 · Fixture references:** Attach the “Conformance harness” fixture IDs, input identities and oracle definition; preserve the source counterexample “Only archive creation is tested while runtime conformance is claimed” as a distinct evidence case.
- [ ] **UC-M12.06-C080-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Conformance harness”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M12.06-C080-T05 · Environment record:** Record the actual “Conformance harness” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M12.06-C080-T06 · Expected versus observed:** Pair every “Conformance harness” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M12.06-C080-T07 · Failure and limit records:** Attach “Conformance harness” change/failure and bounds evidence where required; include uncovered “Conformance cases and runtime budget” and unresolved violations of “A package naming convention alone is not conformance evidence”.
- [ ] **UC-M12.06-C080-T08 · Evidence hygiene:** Check the “Conformance harness” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M12.06-C080-T09 · Reproduction review:** Have the “Conformance harness” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M12.06-C080-T10 · Acceptance linkage:** Link the “Conformance harness” evidence to its parent and UC-M12.06 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 09. Round-trip interoperability

**Source delivery:** Test selected package creation, consumption and lifecycle paths with qualified tooling.

**Source invariant:** Interoperability evidence covers the actual produced artifacts.

**Source negative case:** Only a hand-crafted sample passes the external consumer.

**Source bounded quantities:** Tool versions and artifact variants.

### UC-M12.06-C081 · Contract

**Original checklist item:** Define the qualification objective for round-trip interoperability, including the actual target implementation, prerequisites, observable oracle and explicit exclusions.

- [ ] **UC-M12.06-C081-T01 · Scope statement:** Write the qualification question for “Round-trip interoperability”; identify the actual target, claimed capability and observations that can answer that question.
- [ ] **UC-M12.06-C081-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Round-trip interoperability”; record each producer, representation and missing-value meaning.
- [ ] **UC-M12.06-C081-T03 · Output inventory:** List the outputs of “Round-trip interoperability” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M12.06-C081-T04 · Field dictionary:** Create a field-and-term dictionary for “Round-trip interoperability”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M12.06-C081-T05 · Prerequisite contract:** Map “Round-trip interoperability” to the source component prerequisites (UC-M03.01, UC-M04.05, UC-M06.01); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M12.06-C081-T06 · Authority map:** Identify who may produce, change and consume “Round-trip interoperability”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M12.06-C081-T07 · Invariant clause:** Add a normative clause for “Round-trip interoperability” that preserves “Interoperability evidence covers the actual produced artifacts”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M12.06-C081-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Round-trip interoperability”; include the source counterexample “Only a hand-crafted sample passes the external consumer” and the intended safe disposition.
- [ ] **UC-M12.06-C081-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Tool versions and artifact variants” in the “Round-trip interoperability” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M12.06-C081-T10 · Contract review:** Review the “Round-trip interoperability” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M12.06-C082 · Delivery

**Original checklist item:** Test selected package creation, consumption and lifecycle paths with qualified tooling.

- [ ] **UC-M12.06-C082-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Round-trip interoperability”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M12.06-C082-T02 · Change plan:** Break the source delivery for “Round-trip interoperability” into concrete edit targets and reviewable outputs; keep the UC-M12.06 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M12.06-C082-T03 · Core artifact:** Create the “Round-trip interoperability” fixture or harness for this source instruction: Test selected package creation, consumption and lifecycle paths with qualified tooling.
- [ ] **UC-M12.06-C082-T04 · Concrete realization:** Connect the “Round-trip interoperability” harness to its actual intended target, set the expected oracle before running it, and distinguish a mock/control run from a target run.
- [ ] **UC-M12.06-C082-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Round-trip interoperability” needed to preserve “Interoperability evidence covers the actual produced artifacts”; record an enforcement gap where only a model exists.
- [ ] **UC-M12.06-C082-T06 · Dependency connection:** Connect the “Round-trip interoperability” qualification artifact to pinned optional OCI contracts, guest artifact mapping and backend lifecycle adapters; record the target identity and what the harness actually exercises.
- [ ] **UC-M12.06-C082-T07 · Resource behavior:** Account for “Tool versions and artifact variants” in “Round-trip interoperability”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M12.06-C082-T08 · Delivery check:** Run a known-valid control and a deliberately failing control for “Round-trip interoperability”; confirm the harness distinguishes their observed outcomes.
- [ ] **UC-M12.06-C082-T09 · Patch review:** Review the “Round-trip interoperability” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M12.06-C082-T10 · Delivery handoff:** Publish the “Round-trip interoperability” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M12.06-C083 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Interoperability evidence covers the actual produced artifacts. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M12.06-C083-T01 · Named property:** Create a stable property/check name under this parent for “Round-trip interoperability”; copy its required invariant exactly: “Interoperability evidence covers the actual produced artifacts”.
- [ ] **UC-M12.06-C083-T02 · Observable terms:** Define each term in the “Round-trip interoperability” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M12.06-C083-T03 · Precondition set:** List the preconditions under which “Interoperability evidence covers the actual produced artifacts” must hold for “Round-trip interoperability”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M12.06-C083-T04 · Transition coverage:** Map the “Round-trip interoperability” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M12.06-C083-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Round-trip interoperability”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M12.06-C083-T06 · Satisfying fixture:** Create a concrete “Round-trip interoperability” case that satisfies “Interoperability evidence covers the actual produced artifacts”; record its expected observation before running the assertion or review.
- [ ] **UC-M12.06-C083-T07 · Violating fixture:** Create the source counterexample “Only a hand-crafted sample passes the external consumer” for “Round-trip interoperability”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M12.06-C083-T08 · Enforcement evidence:** Exercise the “Round-trip interoperability” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M12.06-C083-T09 · Regression linkage:** Link the “Round-trip interoperability” property to changes in pinned optional OCI contracts, guest artifact mapping and backend lifecycle adapters; record which dependency or contract changes require rerunning it.
- [ ] **UC-M12.06-C083-T10 · Property disposition:** Compare the satisfying and violating “Round-trip interoperability” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M12.06-C084 · Integration

**Original checklist item:** Integrate round-trip interoperability with pinned optional OCI contracts, guest artifact mapping and backend lifecycle adapters; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M12.06-C084-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Round-trip interoperability” across pinned optional OCI contracts, guest artifact mapping and backend lifecycle adapters; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M12.06-C084-T02 · Field mapping:** Map every “Round-trip interoperability” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M12.06-C084-T03 · Prerequisite identities:** Record the actual prerequisites for “Round-trip interoperability” (source dependency list: UC-M03.01, UC-M04.05, UC-M06.01); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M12.06-C084-T04 · Ownership agreement:** Specify who owns “Round-trip interoperability” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M12.06-C084-T05 · Handoff implementation:** Connect “Round-trip interoperability” through the mapped seam using the real adapter or explicit specification reference; preserve “Interoperability evidence covers the actual produced artifacts” across the handoff.
- [ ] **UC-M12.06-C084-T06 · Absent-input case:** Omit one required “Round-trip interoperability” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M12.06-C084-T07 · Stale-input case:** Supply an outdated “Round-trip interoperability” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M12.06-C084-T08 · Incompatible-input case:** Supply an incompatible “Round-trip interoperability” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M12.06-C084-T09 · Valid integration trace:** Run a valid “Round-trip interoperability” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M12.06-C084-T10 · Seam review:** Reconcile the “Round-trip interoperability” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M12.06-C085 · Valid-case test

**Original checklist item:** Run a known-valid control for round-trip interoperability; verify that the harness reaches its intended target and compare observed measurements or verdicts with predeclared expectations.

- [ ] **UC-M12.06-C085-T01 · Valid fixture choice:** Choose a known-valid control for “Round-trip interoperability”; document why it should pass and how it proves the harness reaches the intended target.
- [ ] **UC-M12.06-C085-T02 · Expected-result oracle:** Specify the “Round-trip interoperability” expected result independently of the implementation output; include the property “Interoperability evidence covers the actual produced artifacts” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M12.06-C085-T03 · Fixture material:** Create the concrete “Round-trip interoperability” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M12.06-C085-T04 · Target preparation:** Prepare the “Round-trip interoperability” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M12.06-C085-T05 · Initial-state record:** Record the initial “Round-trip interoperability” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M12.06-C085-T06 · Valid-path execution:** Run the “Round-trip interoperability” known-valid control on the identified target; retain enough observations to prove the correct target was exercised.
- [ ] **UC-M12.06-C085-T07 · Outcome comparison:** Compare every declared “Round-trip interoperability” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M12.06-C085-T08 · State and bounds check:** Inspect the “Round-trip interoperability” ownership/state effects and actual use of “Tool versions and artifact variants”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M12.06-C085-T09 · Repeatability check:** Repeat the same “Round-trip interoperability” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M12.06-C085-T10 · Positive evidence:** Attach the “Round-trip interoperability” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M12.06-C086 · Negative test

**Original checklist item:** Negative case: Only a hand-crafted sample passes the external consumer. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M12.06-C086-T01 · Adverse-case definition:** Create a test record for the exact “Round-trip interoperability” source counterexample: “Only a hand-crafted sample passes the external consumer”; state which precondition or invariant it challenges.
- [ ] **UC-M12.06-C086-T02 · Safe fixture boundary:** Define the contained test boundary for “Round-trip interoperability”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M12.06-C086-T03 · Valid control:** Construct a valid “Round-trip interoperability” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M12.06-C086-T04 · Minimal adverse input:** Derive the “Round-trip interoperability” adverse fixture from the control with the smallest documented change needed to reproduce “Only a hand-crafted sample passes the external consumer”; retain that change as reproducible data.
- [ ] **UC-M12.06-C086-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Round-trip interoperability”; require “Interoperability evidence covers the actual produced artifacts” and forbid a false-success verdict.
- [ ] **UC-M12.06-C086-T06 · Adverse execution:** Exercise the “Round-trip interoperability” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M12.06-C086-T07 · Effect inspection:** Inspect “Round-trip interoperability” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M12.06-C086-T08 · Refusal versus failure:** Confirm the “Round-trip interoperability” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M12.06-C086-T09 · Reset and retention:** Restore only the disposable “Round-trip interoperability” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M12.06-C086-T10 · Negative regression:** Register the “Round-trip interoperability” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M12.06-C087 · Change / failure test

**Original checklist item:** Exercise round-trip interoperability when a consumer requests an unsupported specification feature or incompatible version; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M12.06-C087-T01 · Scenario record:** Write the “Round-trip interoperability” change/failure scenario exactly as supplied: a consumer requests an unsupported specification feature or incompatible version; identify the property that must remain true: “Interoperability evidence covers the actual produced artifacts”.
- [ ] **UC-M12.06-C087-T02 · Baseline capture:** Create a known-valid “Round-trip interoperability” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M12.06-C087-T03 · Injection map:** Locate the “Round-trip interoperability” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M12.06-C087-T04 · Disposition oracle:** Define the legal intermediate and final “Round-trip interoperability” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M12.06-C087-T05 · Controlled trigger:** Introduce the controlled “Round-trip interoperability” scenario in the disposable fixture: a consumer requests an unsupported specification feature or incompatible version; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M12.06-C087-T06 · Intermediate inspection:** Inspect the “Round-trip interoperability” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M12.06-C087-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Round-trip interoperability”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M12.06-C087-T08 · Stale-evidence cleanup:** Invalidate superseded “Round-trip interoperability” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M12.06-C087-T09 · Repeat and compare:** Repeat the selected “Round-trip interoperability” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M12.06-C087-T10 · Failure evidence:** Publish the “Round-trip interoperability” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M12.06-C088 · Bounds

**Original checklist item:** Set a documented campaign budget for tool versions and artifact variants; record actual consumption, incomplete coverage and the disposition when the budget is exhausted.

- [ ] **UC-M12.06-C088-T01 · Quantity inventory:** Create a measurement inventory for “Round-trip interoperability”: “Tool versions and artifact variants”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M12.06-C088-T02 · Measurement method:** Choose how to observe each “Round-trip interoperability” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M12.06-C088-T03 · Budget decision:** Select justified campaign and target-resource budgets for “Round-trip interoperability”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M12.06-C088-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Round-trip interoperability” cases for “Tool versions and artifact variants”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M12.06-C088-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Round-trip interoperability” limit; preserve “Interoperability evidence covers the actual produced artifacts”.
- [ ] **UC-M12.06-C088-T06 · Normal measurement:** Run or review the normal “Round-trip interoperability” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M12.06-C088-T07 · At-limit measurement:** Exercise the “Round-trip interoperability” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M12.06-C088-T08 · Over-limit measurement:** Exercise the “Round-trip interoperability” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M12.06-C088-T09 · Uncovered-scope report:** List the “Round-trip interoperability” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M12.06-C088-T10 · Limit evidence:** Publish the selected “Round-trip interoperability” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M12.06-C089 · Diagnostics / review

**Original checklist item:** Report round-trip interoperability results with executed, failed, skipped and unavailable cases separated; preserve the underlying observations and do not manufacture missing measurements.

- [ ] **UC-M12.06-C089-T01 · Result inventory:** Enumerate the required “Round-trip interoperability” qualification cases and intended targets before aggregating results; keep the planned denominator visible.
- [ ] **UC-M12.06-C089-T02 · Verdict schema:** Define separate executed-pass, executed-fail, skipped, unavailable and untested outcomes for “Round-trip interoperability”; document how incomplete cases block relevant claims.
- [ ] **UC-M12.06-C089-T03 · Identity fields:** Attach the actual target, fixture, configuration and revision identifiers to each “Round-trip interoperability” result; do not attribute host-only evidence to a guest or another OS.
- [ ] **UC-M12.06-C089-T04 · Observation capture:** Capture bounded raw “Round-trip interoperability” observations and harness errors; retain enough information to verify the reported oracle comparison.
- [ ] **UC-M12.06-C089-T05 · Aggregation rules:** Implement the “Round-trip interoperability” count/reduction rule so failures and missing measurements cannot disappear; preserve “Interoperability evidence covers the actual produced artifacts”.
- [ ] **UC-M12.06-C089-T06 · Failure visibility:** Feed a failing “Round-trip interoperability” control through the report path; assert the exact failed case and underlying observation remain visible.
- [ ] **UC-M12.06-C089-T07 · Missing-result visibility:** Withhold a required “Round-trip interoperability” measurement or target; verify the report uses unavailable/untested rather than a fabricated zero or passing value.
- [ ] **UC-M12.06-C089-T08 · Bounds and redaction:** Check “Round-trip interoperability” report size and retention against “Tool versions and artifact variants”; remove secrets while retaining fixture and subject references.
- [ ] **UC-M12.06-C089-T09 · Report reconciliation:** Reconcile the “Round-trip interoperability” summary with every underlying case record; account for the full planned denominator and all omitted scope.
- [ ] **UC-M12.06-C089-T10 · Qualification handoff:** Publish the “Round-trip interoperability” report with measured observations, coverage limits and blockers; state which actual targets remain unqualified.

### UC-M12.06-C090 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for round-trip interoperability; label unexecuted checks as untested.

- [ ] **UC-M12.06-C090-T01 · Evidence inventory:** List the “Round-trip interoperability” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M12.06-C090-T02 · Artifact references:** Record the exact “Round-trip interoperability” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M12.06-C090-T03 · Fixture references:** Attach the “Round-trip interoperability” fixture IDs, input identities and oracle definition; preserve the source counterexample “Only a hand-crafted sample passes the external consumer” as a distinct evidence case.
- [ ] **UC-M12.06-C090-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Round-trip interoperability”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M12.06-C090-T05 · Environment record:** Record the actual “Round-trip interoperability” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M12.06-C090-T06 · Expected versus observed:** Pair every “Round-trip interoperability” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M12.06-C090-T07 · Failure and limit records:** Attach “Round-trip interoperability” change/failure and bounds evidence where required; include uncovered “Tool versions and artifact variants” and unresolved violations of “Interoperability evidence covers the actual produced artifacts”.
- [ ] **UC-M12.06-C090-T08 · Evidence hygiene:** Check the “Round-trip interoperability” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M12.06-C090-T09 · Reproduction review:** Have the “Round-trip interoperability” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M12.06-C090-T10 · Acceptance linkage:** Link the “Round-trip interoperability” evidence to its parent and UC-M12.06 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 10. OCI claim review

**Source delivery:** Publish supported versions, tested features, refused features and residual gaps.

**Source invariant:** Unassessed conformance remains explicitly unclaimed.

**Source negative case:** A release badge implies full conformance despite required skipped tests.

**Source bounded quantities:** Claim fields and evidence freshness.

### UC-M12.06-C091 · Contract

**Original checklist item:** Define the qualification objective for OCI claim review, including the actual target implementation, prerequisites, observable oracle and explicit exclusions.

- [ ] **UC-M12.06-C091-T01 · Scope statement:** Write the qualification question for “OCI claim review”; identify the actual target, claimed capability and observations that can answer that question.
- [ ] **UC-M12.06-C091-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “OCI claim review”; record each producer, representation and missing-value meaning.
- [ ] **UC-M12.06-C091-T03 · Output inventory:** List the outputs of “OCI claim review” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M12.06-C091-T04 · Field dictionary:** Create a field-and-term dictionary for “OCI claim review”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M12.06-C091-T05 · Prerequisite contract:** Map “OCI claim review” to the source component prerequisites (UC-M03.01, UC-M04.05, UC-M06.01); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M12.06-C091-T06 · Authority map:** Identify who may produce, change and consume “OCI claim review”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M12.06-C091-T07 · Invariant clause:** Add a normative clause for “OCI claim review” that preserves “Unassessed conformance remains explicitly unclaimed”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M12.06-C091-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “OCI claim review”; include the source counterexample “A release badge implies full conformance despite required skipped tests” and the intended safe disposition.
- [ ] **UC-M12.06-C091-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Claim fields and evidence freshness” in the “OCI claim review” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M12.06-C091-T10 · Contract review:** Review the “OCI claim review” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M12.06-C092 · Delivery

**Original checklist item:** Publish supported versions, tested features, refused features and residual gaps.

- [ ] **UC-M12.06-C092-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “OCI claim review”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M12.06-C092-T02 · Change plan:** Break the source delivery for “OCI claim review” into concrete edit targets and reviewable outputs; keep the UC-M12.06 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M12.06-C092-T03 · Core artifact:** Create the “OCI claim review” output artifact for this source instruction: Publish supported versions, tested features, refused features and residual gaps.
- [ ] **UC-M12.06-C092-T04 · Concrete realization:** Populate the “OCI claim review” artifact from identified observations; keep unknown, failed and unexecuted results distinct and exclude unapproved sensitive material.
- [ ] **UC-M12.06-C092-T05 · Invariant protection:** Add the actual guard, check or review criterion for “OCI claim review” needed to preserve “Unassessed conformance remains explicitly unclaimed”; record an enforcement gap where only a model exists.
- [ ] **UC-M12.06-C092-T06 · Dependency connection:** Connect the “OCI claim review” qualification artifact to pinned optional OCI contracts, guest artifact mapping and backend lifecycle adapters; record the target identity and what the harness actually exercises.
- [ ] **UC-M12.06-C092-T07 · Resource behavior:** Account for “Claim fields and evidence freshness” in “OCI claim review”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M12.06-C092-T08 · Delivery check:** Run a known-valid control and a deliberately failing control for “OCI claim review”; confirm the harness distinguishes their observed outcomes.
- [ ] **UC-M12.06-C092-T09 · Patch review:** Review the “OCI claim review” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M12.06-C092-T10 · Delivery handoff:** Publish the “OCI claim review” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M12.06-C093 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Unassessed conformance remains explicitly unclaimed. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M12.06-C093-T01 · Named property:** Create a stable property/check name under this parent for “OCI claim review”; copy its required invariant exactly: “Unassessed conformance remains explicitly unclaimed”.
- [ ] **UC-M12.06-C093-T02 · Observable terms:** Define each term in the “OCI claim review” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M12.06-C093-T03 · Precondition set:** List the preconditions under which “Unassessed conformance remains explicitly unclaimed” must hold for “OCI claim review”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M12.06-C093-T04 · Transition coverage:** Map the “OCI claim review” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M12.06-C093-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “OCI claim review”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M12.06-C093-T06 · Satisfying fixture:** Create a concrete “OCI claim review” case that satisfies “Unassessed conformance remains explicitly unclaimed”; record its expected observation before running the assertion or review.
- [ ] **UC-M12.06-C093-T07 · Violating fixture:** Create the source counterexample “A release badge implies full conformance despite required skipped tests” for “OCI claim review”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M12.06-C093-T08 · Enforcement evidence:** Exercise the “OCI claim review” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M12.06-C093-T09 · Regression linkage:** Link the “OCI claim review” property to changes in pinned optional OCI contracts, guest artifact mapping and backend lifecycle adapters; record which dependency or contract changes require rerunning it.
- [ ] **UC-M12.06-C093-T10 · Property disposition:** Compare the satisfying and violating “OCI claim review” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M12.06-C094 · Integration

**Original checklist item:** Integrate OCI claim review with pinned optional OCI contracts, guest artifact mapping and backend lifecycle adapters; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M12.06-C094-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “OCI claim review” across pinned optional OCI contracts, guest artifact mapping and backend lifecycle adapters; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M12.06-C094-T02 · Field mapping:** Map every “OCI claim review” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M12.06-C094-T03 · Prerequisite identities:** Record the actual prerequisites for “OCI claim review” (source dependency list: UC-M03.01, UC-M04.05, UC-M06.01); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M12.06-C094-T04 · Ownership agreement:** Specify who owns “OCI claim review” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M12.06-C094-T05 · Handoff implementation:** Connect “OCI claim review” through the mapped seam using the real adapter or explicit specification reference; preserve “Unassessed conformance remains explicitly unclaimed” across the handoff.
- [ ] **UC-M12.06-C094-T06 · Absent-input case:** Omit one required “OCI claim review” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M12.06-C094-T07 · Stale-input case:** Supply an outdated “OCI claim review” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M12.06-C094-T08 · Incompatible-input case:** Supply an incompatible “OCI claim review” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M12.06-C094-T09 · Valid integration trace:** Run a valid “OCI claim review” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M12.06-C094-T10 · Seam review:** Reconcile the “OCI claim review” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M12.06-C095 · Valid-case test

**Original checklist item:** Run a known-valid control for OCI claim review; verify that the harness reaches its intended target and compare observed measurements or verdicts with predeclared expectations.

- [ ] **UC-M12.06-C095-T01 · Valid fixture choice:** Choose a known-valid control for “OCI claim review”; document why it should pass and how it proves the harness reaches the intended target.
- [ ] **UC-M12.06-C095-T02 · Expected-result oracle:** Specify the “OCI claim review” expected result independently of the implementation output; include the property “Unassessed conformance remains explicitly unclaimed” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M12.06-C095-T03 · Fixture material:** Create the concrete “OCI claim review” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M12.06-C095-T04 · Target preparation:** Prepare the “OCI claim review” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M12.06-C095-T05 · Initial-state record:** Record the initial “OCI claim review” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M12.06-C095-T06 · Valid-path execution:** Run the “OCI claim review” known-valid control on the identified target; retain enough observations to prove the correct target was exercised.
- [ ] **UC-M12.06-C095-T07 · Outcome comparison:** Compare every declared “OCI claim review” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M12.06-C095-T08 · State and bounds check:** Inspect the “OCI claim review” ownership/state effects and actual use of “Claim fields and evidence freshness”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M12.06-C095-T09 · Repeatability check:** Repeat the same “OCI claim review” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M12.06-C095-T10 · Positive evidence:** Attach the “OCI claim review” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M12.06-C096 · Negative test

**Original checklist item:** Negative case: A release badge implies full conformance despite required skipped tests. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M12.06-C096-T01 · Adverse-case definition:** Create a test record for the exact “OCI claim review” source counterexample: “A release badge implies full conformance despite required skipped tests”; state which precondition or invariant it challenges.
- [ ] **UC-M12.06-C096-T02 · Safe fixture boundary:** Define the contained test boundary for “OCI claim review”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M12.06-C096-T03 · Valid control:** Construct a valid “OCI claim review” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M12.06-C096-T04 · Minimal adverse input:** Derive the “OCI claim review” adverse fixture from the control with the smallest documented change needed to reproduce “A release badge implies full conformance despite required skipped tests”; retain that change as reproducible data.
- [ ] **UC-M12.06-C096-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “OCI claim review”; require “Unassessed conformance remains explicitly unclaimed” and forbid a false-success verdict.
- [ ] **UC-M12.06-C096-T06 · Adverse execution:** Exercise the “OCI claim review” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M12.06-C096-T07 · Effect inspection:** Inspect “OCI claim review” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M12.06-C096-T08 · Refusal versus failure:** Confirm the “OCI claim review” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M12.06-C096-T09 · Reset and retention:** Restore only the disposable “OCI claim review” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M12.06-C096-T10 · Negative regression:** Register the “OCI claim review” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M12.06-C097 · Change / failure test

**Original checklist item:** Exercise OCI claim review when a consumer requests an unsupported specification feature or incompatible version; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M12.06-C097-T01 · Scenario record:** Write the “OCI claim review” change/failure scenario exactly as supplied: a consumer requests an unsupported specification feature or incompatible version; identify the property that must remain true: “Unassessed conformance remains explicitly unclaimed”.
- [ ] **UC-M12.06-C097-T02 · Baseline capture:** Create a known-valid “OCI claim review” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M12.06-C097-T03 · Injection map:** Locate the “OCI claim review” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M12.06-C097-T04 · Disposition oracle:** Define the legal intermediate and final “OCI claim review” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M12.06-C097-T05 · Controlled trigger:** Introduce the controlled “OCI claim review” scenario in the disposable fixture: a consumer requests an unsupported specification feature or incompatible version; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M12.06-C097-T06 · Intermediate inspection:** Inspect the “OCI claim review” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M12.06-C097-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “OCI claim review”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M12.06-C097-T08 · Stale-evidence cleanup:** Invalidate superseded “OCI claim review” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M12.06-C097-T09 · Repeat and compare:** Repeat the selected “OCI claim review” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M12.06-C097-T10 · Failure evidence:** Publish the “OCI claim review” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M12.06-C098 · Bounds

**Original checklist item:** Set a documented campaign budget for claim fields and evidence freshness; record actual consumption, incomplete coverage and the disposition when the budget is exhausted.

- [ ] **UC-M12.06-C098-T01 · Quantity inventory:** Create a measurement inventory for “OCI claim review”: “Claim fields and evidence freshness”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M12.06-C098-T02 · Measurement method:** Choose how to observe each “OCI claim review” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M12.06-C098-T03 · Budget decision:** Select justified campaign and target-resource budgets for “OCI claim review”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M12.06-C098-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “OCI claim review” cases for “Claim fields and evidence freshness”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M12.06-C098-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “OCI claim review” limit; preserve “Unassessed conformance remains explicitly unclaimed”.
- [ ] **UC-M12.06-C098-T06 · Normal measurement:** Run or review the normal “OCI claim review” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M12.06-C098-T07 · At-limit measurement:** Exercise the “OCI claim review” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M12.06-C098-T08 · Over-limit measurement:** Exercise the “OCI claim review” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M12.06-C098-T09 · Uncovered-scope report:** List the “OCI claim review” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M12.06-C098-T10 · Limit evidence:** Publish the selected “OCI claim review” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M12.06-C099 · Diagnostics / review

**Original checklist item:** Report OCI claim review results with executed, failed, skipped and unavailable cases separated; preserve the underlying observations and do not manufacture missing measurements.

- [ ] **UC-M12.06-C099-T01 · Result inventory:** Enumerate the required “OCI claim review” qualification cases and intended targets before aggregating results; keep the planned denominator visible.
- [ ] **UC-M12.06-C099-T02 · Verdict schema:** Define separate executed-pass, executed-fail, skipped, unavailable and untested outcomes for “OCI claim review”; document how incomplete cases block relevant claims.
- [ ] **UC-M12.06-C099-T03 · Identity fields:** Attach the actual target, fixture, configuration and revision identifiers to each “OCI claim review” result; do not attribute host-only evidence to a guest or another OS.
- [ ] **UC-M12.06-C099-T04 · Observation capture:** Capture bounded raw “OCI claim review” observations and harness errors; retain enough information to verify the reported oracle comparison.
- [ ] **UC-M12.06-C099-T05 · Aggregation rules:** Implement the “OCI claim review” count/reduction rule so failures and missing measurements cannot disappear; preserve “Unassessed conformance remains explicitly unclaimed”.
- [ ] **UC-M12.06-C099-T06 · Failure visibility:** Feed a failing “OCI claim review” control through the report path; assert the exact failed case and underlying observation remain visible.
- [ ] **UC-M12.06-C099-T07 · Missing-result visibility:** Withhold a required “OCI claim review” measurement or target; verify the report uses unavailable/untested rather than a fabricated zero or passing value.
- [ ] **UC-M12.06-C099-T08 · Bounds and redaction:** Check “OCI claim review” report size and retention against “Claim fields and evidence freshness”; remove secrets while retaining fixture and subject references.
- [ ] **UC-M12.06-C099-T09 · Report reconciliation:** Reconcile the “OCI claim review” summary with every underlying case record; account for the full planned denominator and all omitted scope.
- [ ] **UC-M12.06-C099-T10 · Qualification handoff:** Publish the “OCI claim review” report with measured observations, coverage limits and blockers; state which actual targets remain unqualified.

### UC-M12.06-C100 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for OCI claim review; label unexecuted checks as untested.

- [ ] **UC-M12.06-C100-T01 · Evidence inventory:** List the “OCI claim review” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M12.06-C100-T02 · Artifact references:** Record the exact “OCI claim review” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M12.06-C100-T03 · Fixture references:** Attach the “OCI claim review” fixture IDs, input identities and oracle definition; preserve the source counterexample “A release badge implies full conformance despite required skipped tests” as a distinct evidence case.
- [ ] **UC-M12.06-C100-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “OCI claim review”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M12.06-C100-T05 · Environment record:** Record the actual “OCI claim review” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M12.06-C100-T06 · Expected versus observed:** Pair every “OCI claim review” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M12.06-C100-T07 · Failure and limit records:** Attach “OCI claim review” change/failure and bounds evidence where required; include uncovered “Claim fields and evidence freshness” and unresolved violations of “Unassessed conformance remains explicitly unclaimed”.
- [ ] **UC-M12.06-C100-T08 · Evidence hygiene:** Check the “OCI claim review” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M12.06-C100-T09 · Reproduction review:** Have the “OCI claim review” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M12.06-C100-T10 · Acceptance linkage:** Link the “OCI claim review” evidence to its parent and UC-M12.06 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

