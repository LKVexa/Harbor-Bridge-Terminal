# UC-M12.07 — Authenticated portable installer and updater

**To-Do Pack 2.0.0 · Baseline UC-2.2.0 · 100 parent checks × 10 subtasks = 1,000 to-dos**

[Master index](../../INDEX.md) · [Workstream index](../../w/12.md)

| Field | Preserved source value |
|---|---|
| Workstream | 12. Qualification, packaging and release |
| Milestone | C |
| Priority | P1 |
| Source assessment | PARTIAL |
| Scope | core or selected profile |
| Dependencies | [UC-M07.08](../07/UC-M07.08.md), [UC-M09.02](../09/UC-M09.02.md), [UC-M12.01](../12/UC-M12.01.md) |
| Source checklist pack | 1.0.0 |
| Original reference labels | [S5], [S6], [S7], [S8]. |

## Original requirement

Package short-path launchers, dependency checks, rollback and signed update metadata without silently overwriting user state.

**Original acceptance criterion:** A clean install and interrupted upgrade on each supported OS preserve user cargo and restore an approved release.

**Source trace:** Original checklist `UC100/c/12/UC-M12.07.md` inside [s/checklists.zip](../../s/checklists.zip); exact parent records in [data/parents.jsonl](../../data/parents.jsonl). Original roadmap lines 1160–1170 are preserved in [s/roadmap.md](../../s/roadmap.md).

## How to use these lists

Every parent statement below is preserved verbatim. Its ten child tasks are proposed decomposition, not implemented capabilities or executed tests. Child IDs append `-T01` through `-T10` to the original parent ID. All begin unchecked / `TODO`. Design/review evidence does not establish runtime enforcement; observe the actual selected target where the parent requires it.

The source dependency graph and selected release profile determine applicability. The numbered child sequence is a local working order, not an added hard dependency graph. An unselected optional feature needs a recorded not-applicable rationale; missing prerequisites for selected work remain blockers. Numerical budgets, backends and trust mechanisms remain decisions unless fixed by the source. Test hostile cases only with synthetic inputs in authorized disposable environments.

## 01. Short-path package layout

**Source delivery:** Package launchers and payloads under a bounded Windows-friendly root layout.

**Source invariant:** Packaging does not recreate avoidable long nested paths.

**Source negative case:** Extraction exceeds the supported path budget before first launch.

**Source bounded quantities:** Relative path length and member count.

### UC-M12.07-C001 · Contract

**Original checklist item:** Define the qualification objective for short-path package layout, including the actual target implementation, prerequisites, observable oracle and explicit exclusions.

- [ ] **UC-M12.07-C001-T01 · Scope statement:** Write the qualification question for “Short-path package layout”; identify the actual target, claimed capability and observations that can answer that question.
- [ ] **UC-M12.07-C001-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Short-path package layout”; record each producer, representation and missing-value meaning.
- [ ] **UC-M12.07-C001-T03 · Output inventory:** List the outputs of “Short-path package layout” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M12.07-C001-T04 · Field dictionary:** Create a field-and-term dictionary for “Short-path package layout”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M12.07-C001-T05 · Prerequisite contract:** Map “Short-path package layout” to the source component prerequisites (UC-M07.08, UC-M09.02, UC-M12.01); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M12.07-C001-T06 · Authority map:** Identify who may produce, change and consume “Short-path package layout”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M12.07-C001-T07 · Invariant clause:** Add a normative clause for “Short-path package layout” that preserves “Packaging does not recreate avoidable long nested paths”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M12.07-C001-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Short-path package layout”; include the source counterexample “Extraction exceeds the supported path budget before first launch” and the intended safe disposition.
- [ ] **UC-M12.07-C001-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Relative path length and member count” in the “Short-path package layout” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M12.07-C001-T10 · Contract review:** Review the “Short-path package layout” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M12.07-C002 · Delivery

**Original checklist item:** Package launchers and payloads under a bounded Windows-friendly root layout.

- [ ] **UC-M12.07-C002-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Short-path package layout”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M12.07-C002-T02 · Change plan:** Break the source delivery for “Short-path package layout” into concrete edit targets and reviewable outputs; keep the UC-M12.07 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M12.07-C002-T03 · Core artifact:** Create the “Short-path package layout” output artifact for this source instruction: Package launchers and payloads under a bounded Windows-friendly root layout.
- [ ] **UC-M12.07-C002-T04 · Concrete realization:** Populate the “Short-path package layout” artifact from identified observations; keep unknown, failed and unexecuted results distinct and exclude unapproved sensitive material.
- [ ] **UC-M12.07-C002-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Short-path package layout” needed to preserve “Packaging does not recreate avoidable long nested paths”; record an enforcement gap where only a model exists.
- [ ] **UC-M12.07-C002-T06 · Dependency connection:** Connect the “Short-path package layout” qualification artifact to authenticated packages, short-path launchers and user-state-preserving upgrade transactions; record the target identity and what the harness actually exercises.
- [ ] **UC-M12.07-C002-T07 · Resource behavior:** Account for “Relative path length and member count” in “Short-path package layout”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M12.07-C002-T08 · Delivery check:** Run a known-valid control and a deliberately failing control for “Short-path package layout”; confirm the harness distinguishes their observed outcomes.
- [ ] **UC-M12.07-C002-T09 · Patch review:** Review the “Short-path package layout” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M12.07-C002-T10 · Delivery handoff:** Publish the “Short-path package layout” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M12.07-C003 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Packaging does not recreate avoidable long nested paths. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M12.07-C003-T01 · Named property:** Create a stable property/check name under this parent for “Short-path package layout”; copy its required invariant exactly: “Packaging does not recreate avoidable long nested paths”.
- [ ] **UC-M12.07-C003-T02 · Observable terms:** Define each term in the “Short-path package layout” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M12.07-C003-T03 · Precondition set:** List the preconditions under which “Packaging does not recreate avoidable long nested paths” must hold for “Short-path package layout”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M12.07-C003-T04 · Transition coverage:** Map the “Short-path package layout” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M12.07-C003-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Short-path package layout”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M12.07-C003-T06 · Satisfying fixture:** Create a concrete “Short-path package layout” case that satisfies “Packaging does not recreate avoidable long nested paths”; record its expected observation before running the assertion or review.
- [ ] **UC-M12.07-C003-T07 · Violating fixture:** Create the source counterexample “Extraction exceeds the supported path budget before first launch” for “Short-path package layout”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M12.07-C003-T08 · Enforcement evidence:** Exercise the “Short-path package layout” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M12.07-C003-T09 · Regression linkage:** Link the “Short-path package layout” property to changes in authenticated packages, short-path launchers and user-state-preserving upgrade transactions; record which dependency or contract changes require rerunning it.
- [ ] **UC-M12.07-C003-T10 · Property disposition:** Compare the satisfying and violating “Short-path package layout” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M12.07-C004 · Integration

**Original checklist item:** Integrate short-path package layout with authenticated packages, short-path launchers and user-state-preserving upgrade transactions; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M12.07-C004-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Short-path package layout” across authenticated packages, short-path launchers and user-state-preserving upgrade transactions; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M12.07-C004-T02 · Field mapping:** Map every “Short-path package layout” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M12.07-C004-T03 · Prerequisite identities:** Record the actual prerequisites for “Short-path package layout” (source dependency list: UC-M07.08, UC-M09.02, UC-M12.01); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M12.07-C004-T04 · Ownership agreement:** Specify who owns “Short-path package layout” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M12.07-C004-T05 · Handoff implementation:** Connect “Short-path package layout” through the mapped seam using the real adapter or explicit specification reference; preserve “Packaging does not recreate avoidable long nested paths” across the handoff.
- [ ] **UC-M12.07-C004-T06 · Absent-input case:** Omit one required “Short-path package layout” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M12.07-C004-T07 · Stale-input case:** Supply an outdated “Short-path package layout” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M12.07-C004-T08 · Incompatible-input case:** Supply an incompatible “Short-path package layout” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M12.07-C004-T09 · Valid integration trace:** Run a valid “Short-path package layout” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M12.07-C004-T10 · Seam review:** Reconcile the “Short-path package layout” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M12.07-C005 · Valid-case test

**Original checklist item:** Run a known-valid control for short-path package layout; verify that the harness reaches its intended target and compare observed measurements or verdicts with predeclared expectations.

- [ ] **UC-M12.07-C005-T01 · Valid fixture choice:** Choose a known-valid control for “Short-path package layout”; document why it should pass and how it proves the harness reaches the intended target.
- [ ] **UC-M12.07-C005-T02 · Expected-result oracle:** Specify the “Short-path package layout” expected result independently of the implementation output; include the property “Packaging does not recreate avoidable long nested paths” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M12.07-C005-T03 · Fixture material:** Create the concrete “Short-path package layout” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M12.07-C005-T04 · Target preparation:** Prepare the “Short-path package layout” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M12.07-C005-T05 · Initial-state record:** Record the initial “Short-path package layout” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M12.07-C005-T06 · Valid-path execution:** Run the “Short-path package layout” known-valid control on the identified target; retain enough observations to prove the correct target was exercised.
- [ ] **UC-M12.07-C005-T07 · Outcome comparison:** Compare every declared “Short-path package layout” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M12.07-C005-T08 · State and bounds check:** Inspect the “Short-path package layout” ownership/state effects and actual use of “Relative path length and member count”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M12.07-C005-T09 · Repeatability check:** Repeat the same “Short-path package layout” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M12.07-C005-T10 · Positive evidence:** Attach the “Short-path package layout” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M12.07-C006 · Negative test

**Original checklist item:** Negative case: Extraction exceeds the supported path budget before first launch. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M12.07-C006-T01 · Adverse-case definition:** Create a test record for the exact “Short-path package layout” source counterexample: “Extraction exceeds the supported path budget before first launch”; state which precondition or invariant it challenges.
- [ ] **UC-M12.07-C006-T02 · Safe fixture boundary:** Define the contained test boundary for “Short-path package layout”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M12.07-C006-T03 · Valid control:** Construct a valid “Short-path package layout” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M12.07-C006-T04 · Minimal adverse input:** Derive the “Short-path package layout” adverse fixture from the control with the smallest documented change needed to reproduce “Extraction exceeds the supported path budget before first launch”; retain that change as reproducible data.
- [ ] **UC-M12.07-C006-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Short-path package layout”; require “Packaging does not recreate avoidable long nested paths” and forbid a false-success verdict.
- [ ] **UC-M12.07-C006-T06 · Adverse execution:** Exercise the “Short-path package layout” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M12.07-C006-T07 · Effect inspection:** Inspect “Short-path package layout” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M12.07-C006-T08 · Refusal versus failure:** Confirm the “Short-path package layout” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M12.07-C006-T09 · Reset and retention:** Restore only the disposable “Short-path package layout” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M12.07-C006-T10 · Negative regression:** Register the “Short-path package layout” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M12.07-C007 · Change / failure test

**Original checklist item:** Exercise short-path package layout when installation or upgrade is interrupted on a claimed native platform; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M12.07-C007-T01 · Scenario record:** Write the “Short-path package layout” change/failure scenario exactly as supplied: installation or upgrade is interrupted on a claimed native platform; identify the property that must remain true: “Packaging does not recreate avoidable long nested paths”.
- [ ] **UC-M12.07-C007-T02 · Baseline capture:** Create a known-valid “Short-path package layout” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M12.07-C007-T03 · Injection map:** Locate the “Short-path package layout” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M12.07-C007-T04 · Disposition oracle:** Define the legal intermediate and final “Short-path package layout” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M12.07-C007-T05 · Controlled trigger:** Introduce the controlled “Short-path package layout” scenario in the disposable fixture: installation or upgrade is interrupted on a claimed native platform; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M12.07-C007-T06 · Intermediate inspection:** Inspect the “Short-path package layout” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M12.07-C007-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Short-path package layout”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M12.07-C007-T08 · Stale-evidence cleanup:** Invalidate superseded “Short-path package layout” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M12.07-C007-T09 · Repeat and compare:** Repeat the selected “Short-path package layout” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M12.07-C007-T10 · Failure evidence:** Publish the “Short-path package layout” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M12.07-C008 · Bounds

**Original checklist item:** Set a documented campaign budget for relative path length and member count; record actual consumption, incomplete coverage and the disposition when the budget is exhausted.

- [ ] **UC-M12.07-C008-T01 · Quantity inventory:** Create a measurement inventory for “Short-path package layout”: “Relative path length and member count”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M12.07-C008-T02 · Measurement method:** Choose how to observe each “Short-path package layout” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M12.07-C008-T03 · Budget decision:** Select justified campaign and target-resource budgets for “Short-path package layout”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M12.07-C008-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Short-path package layout” cases for “Relative path length and member count”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M12.07-C008-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Short-path package layout” limit; preserve “Packaging does not recreate avoidable long nested paths”.
- [ ] **UC-M12.07-C008-T06 · Normal measurement:** Run or review the normal “Short-path package layout” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M12.07-C008-T07 · At-limit measurement:** Exercise the “Short-path package layout” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M12.07-C008-T08 · Over-limit measurement:** Exercise the “Short-path package layout” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M12.07-C008-T09 · Uncovered-scope report:** List the “Short-path package layout” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M12.07-C008-T10 · Limit evidence:** Publish the selected “Short-path package layout” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M12.07-C009 · Diagnostics / review

**Original checklist item:** Report short-path package layout results with executed, failed, skipped and unavailable cases separated; preserve the underlying observations and do not manufacture missing measurements.

- [ ] **UC-M12.07-C009-T01 · Result inventory:** Enumerate the required “Short-path package layout” qualification cases and intended targets before aggregating results; keep the planned denominator visible.
- [ ] **UC-M12.07-C009-T02 · Verdict schema:** Define separate executed-pass, executed-fail, skipped, unavailable and untested outcomes for “Short-path package layout”; document how incomplete cases block relevant claims.
- [ ] **UC-M12.07-C009-T03 · Identity fields:** Attach the actual target, fixture, configuration and revision identifiers to each “Short-path package layout” result; do not attribute host-only evidence to a guest or another OS.
- [ ] **UC-M12.07-C009-T04 · Observation capture:** Capture bounded raw “Short-path package layout” observations and harness errors; retain enough information to verify the reported oracle comparison.
- [ ] **UC-M12.07-C009-T05 · Aggregation rules:** Implement the “Short-path package layout” count/reduction rule so failures and missing measurements cannot disappear; preserve “Packaging does not recreate avoidable long nested paths”.
- [ ] **UC-M12.07-C009-T06 · Failure visibility:** Feed a failing “Short-path package layout” control through the report path; assert the exact failed case and underlying observation remain visible.
- [ ] **UC-M12.07-C009-T07 · Missing-result visibility:** Withhold a required “Short-path package layout” measurement or target; verify the report uses unavailable/untested rather than a fabricated zero or passing value.
- [ ] **UC-M12.07-C009-T08 · Bounds and redaction:** Check “Short-path package layout” report size and retention against “Relative path length and member count”; remove secrets while retaining fixture and subject references.
- [ ] **UC-M12.07-C009-T09 · Report reconciliation:** Reconcile the “Short-path package layout” summary with every underlying case record; account for the full planned denominator and all omitted scope.
- [ ] **UC-M12.07-C009-T10 · Qualification handoff:** Publish the “Short-path package layout” report with measured observations, coverage limits and blockers; state which actual targets remain unqualified.

### UC-M12.07-C010 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for short-path package layout; label unexecuted checks as untested.

- [ ] **UC-M12.07-C010-T01 · Evidence inventory:** List the “Short-path package layout” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M12.07-C010-T02 · Artifact references:** Record the exact “Short-path package layout” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M12.07-C010-T03 · Fixture references:** Attach the “Short-path package layout” fixture IDs, input identities and oracle definition; preserve the source counterexample “Extraction exceeds the supported path budget before first launch” as a distinct evidence case.
- [ ] **UC-M12.07-C010-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Short-path package layout”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M12.07-C010-T05 · Environment record:** Record the actual “Short-path package layout” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M12.07-C010-T06 · Expected versus observed:** Pair every “Short-path package layout” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M12.07-C010-T07 · Failure and limit records:** Attach “Short-path package layout” change/failure and bounds evidence where required; include uncovered “Relative path length and member count” and unresolved violations of “Packaging does not recreate avoidable long nested paths”.
- [ ] **UC-M12.07-C010-T08 · Evidence hygiene:** Check the “Short-path package layout” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M12.07-C010-T09 · Reproduction review:** Have the “Short-path package layout” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M12.07-C010-T10 · Acceptance linkage:** Link the “Short-path package layout” evidence to its parent and UC-M12.07 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 02. Launcher argument handling

**Source delivery:** Quote paths and preserve arguments and exit results on supported hosts.

**Source invariant:** Paths with spaces do not change the intended command.

**Source negative case:** A launcher splits the installation root at a space.

**Source bounded quantities:** Argument bytes and launch variants.

### UC-M12.07-C011 · Contract

**Original checklist item:** Define the qualification objective for launcher argument handling, including the actual target implementation, prerequisites, observable oracle and explicit exclusions.

- [ ] **UC-M12.07-C011-T01 · Scope statement:** Write the qualification question for “Launcher argument handling”; identify the actual target, claimed capability and observations that can answer that question.
- [ ] **UC-M12.07-C011-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Launcher argument handling”; record each producer, representation and missing-value meaning.
- [ ] **UC-M12.07-C011-T03 · Output inventory:** List the outputs of “Launcher argument handling” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M12.07-C011-T04 · Field dictionary:** Create a field-and-term dictionary for “Launcher argument handling”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M12.07-C011-T05 · Prerequisite contract:** Map “Launcher argument handling” to the source component prerequisites (UC-M07.08, UC-M09.02, UC-M12.01); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M12.07-C011-T06 · Authority map:** Identify who may produce, change and consume “Launcher argument handling”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M12.07-C011-T07 · Invariant clause:** Add a normative clause for “Launcher argument handling” that preserves “Paths with spaces do not change the intended command”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M12.07-C011-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Launcher argument handling”; include the source counterexample “A launcher splits the installation root at a space” and the intended safe disposition.
- [ ] **UC-M12.07-C011-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Argument bytes and launch variants” in the “Launcher argument handling” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M12.07-C011-T10 · Contract review:** Review the “Launcher argument handling” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M12.07-C012 · Delivery

**Original checklist item:** Quote paths and preserve arguments and exit results on supported hosts.

- [ ] **UC-M12.07-C012-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Launcher argument handling”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M12.07-C012-T02 · Change plan:** Break the source delivery for “Launcher argument handling” into concrete edit targets and reviewable outputs; keep the UC-M12.07 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M12.07-C012-T03 · Core artifact:** Create the “Launcher argument handling” output artifact for this source instruction: Quote paths and preserve arguments and exit results on supported hosts.
- [ ] **UC-M12.07-C012-T04 · Concrete realization:** Populate the “Launcher argument handling” artifact from identified observations; keep unknown, failed and unexecuted results distinct and exclude unapproved sensitive material.
- [ ] **UC-M12.07-C012-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Launcher argument handling” needed to preserve “Paths with spaces do not change the intended command”; record an enforcement gap where only a model exists.
- [ ] **UC-M12.07-C012-T06 · Dependency connection:** Connect the “Launcher argument handling” qualification artifact to authenticated packages, short-path launchers and user-state-preserving upgrade transactions; record the target identity and what the harness actually exercises.
- [ ] **UC-M12.07-C012-T07 · Resource behavior:** Account for “Argument bytes and launch variants” in “Launcher argument handling”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M12.07-C012-T08 · Delivery check:** Run a known-valid control and a deliberately failing control for “Launcher argument handling”; confirm the harness distinguishes their observed outcomes.
- [ ] **UC-M12.07-C012-T09 · Patch review:** Review the “Launcher argument handling” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M12.07-C012-T10 · Delivery handoff:** Publish the “Launcher argument handling” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M12.07-C013 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Paths with spaces do not change the intended command. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M12.07-C013-T01 · Named property:** Create a stable property/check name under this parent for “Launcher argument handling”; copy its required invariant exactly: “Paths with spaces do not change the intended command”.
- [ ] **UC-M12.07-C013-T02 · Observable terms:** Define each term in the “Launcher argument handling” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M12.07-C013-T03 · Precondition set:** List the preconditions under which “Paths with spaces do not change the intended command” must hold for “Launcher argument handling”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M12.07-C013-T04 · Transition coverage:** Map the “Launcher argument handling” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M12.07-C013-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Launcher argument handling”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M12.07-C013-T06 · Satisfying fixture:** Create a concrete “Launcher argument handling” case that satisfies “Paths with spaces do not change the intended command”; record its expected observation before running the assertion or review.
- [ ] **UC-M12.07-C013-T07 · Violating fixture:** Create the source counterexample “A launcher splits the installation root at a space” for “Launcher argument handling”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M12.07-C013-T08 · Enforcement evidence:** Exercise the “Launcher argument handling” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M12.07-C013-T09 · Regression linkage:** Link the “Launcher argument handling” property to changes in authenticated packages, short-path launchers and user-state-preserving upgrade transactions; record which dependency or contract changes require rerunning it.
- [ ] **UC-M12.07-C013-T10 · Property disposition:** Compare the satisfying and violating “Launcher argument handling” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M12.07-C014 · Integration

**Original checklist item:** Integrate launcher argument handling with authenticated packages, short-path launchers and user-state-preserving upgrade transactions; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M12.07-C014-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Launcher argument handling” across authenticated packages, short-path launchers and user-state-preserving upgrade transactions; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M12.07-C014-T02 · Field mapping:** Map every “Launcher argument handling” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M12.07-C014-T03 · Prerequisite identities:** Record the actual prerequisites for “Launcher argument handling” (source dependency list: UC-M07.08, UC-M09.02, UC-M12.01); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M12.07-C014-T04 · Ownership agreement:** Specify who owns “Launcher argument handling” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M12.07-C014-T05 · Handoff implementation:** Connect “Launcher argument handling” through the mapped seam using the real adapter or explicit specification reference; preserve “Paths with spaces do not change the intended command” across the handoff.
- [ ] **UC-M12.07-C014-T06 · Absent-input case:** Omit one required “Launcher argument handling” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M12.07-C014-T07 · Stale-input case:** Supply an outdated “Launcher argument handling” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M12.07-C014-T08 · Incompatible-input case:** Supply an incompatible “Launcher argument handling” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M12.07-C014-T09 · Valid integration trace:** Run a valid “Launcher argument handling” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M12.07-C014-T10 · Seam review:** Reconcile the “Launcher argument handling” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M12.07-C015 · Valid-case test

**Original checklist item:** Run a known-valid control for launcher argument handling; verify that the harness reaches its intended target and compare observed measurements or verdicts with predeclared expectations.

- [ ] **UC-M12.07-C015-T01 · Valid fixture choice:** Choose a known-valid control for “Launcher argument handling”; document why it should pass and how it proves the harness reaches the intended target.
- [ ] **UC-M12.07-C015-T02 · Expected-result oracle:** Specify the “Launcher argument handling” expected result independently of the implementation output; include the property “Paths with spaces do not change the intended command” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M12.07-C015-T03 · Fixture material:** Create the concrete “Launcher argument handling” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M12.07-C015-T04 · Target preparation:** Prepare the “Launcher argument handling” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M12.07-C015-T05 · Initial-state record:** Record the initial “Launcher argument handling” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M12.07-C015-T06 · Valid-path execution:** Run the “Launcher argument handling” known-valid control on the identified target; retain enough observations to prove the correct target was exercised.
- [ ] **UC-M12.07-C015-T07 · Outcome comparison:** Compare every declared “Launcher argument handling” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M12.07-C015-T08 · State and bounds check:** Inspect the “Launcher argument handling” ownership/state effects and actual use of “Argument bytes and launch variants”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M12.07-C015-T09 · Repeatability check:** Repeat the same “Launcher argument handling” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M12.07-C015-T10 · Positive evidence:** Attach the “Launcher argument handling” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M12.07-C016 · Negative test

**Original checklist item:** Negative case: A launcher splits the installation root at a space. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M12.07-C016-T01 · Adverse-case definition:** Create a test record for the exact “Launcher argument handling” source counterexample: “A launcher splits the installation root at a space”; state which precondition or invariant it challenges.
- [ ] **UC-M12.07-C016-T02 · Safe fixture boundary:** Define the contained test boundary for “Launcher argument handling”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M12.07-C016-T03 · Valid control:** Construct a valid “Launcher argument handling” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M12.07-C016-T04 · Minimal adverse input:** Derive the “Launcher argument handling” adverse fixture from the control with the smallest documented change needed to reproduce “A launcher splits the installation root at a space”; retain that change as reproducible data.
- [ ] **UC-M12.07-C016-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Launcher argument handling”; require “Paths with spaces do not change the intended command” and forbid a false-success verdict.
- [ ] **UC-M12.07-C016-T06 · Adverse execution:** Exercise the “Launcher argument handling” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M12.07-C016-T07 · Effect inspection:** Inspect “Launcher argument handling” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M12.07-C016-T08 · Refusal versus failure:** Confirm the “Launcher argument handling” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M12.07-C016-T09 · Reset and retention:** Restore only the disposable “Launcher argument handling” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M12.07-C016-T10 · Negative regression:** Register the “Launcher argument handling” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M12.07-C017 · Change / failure test

**Original checklist item:** Exercise launcher argument handling when installation or upgrade is interrupted on a claimed native platform; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M12.07-C017-T01 · Scenario record:** Write the “Launcher argument handling” change/failure scenario exactly as supplied: installation or upgrade is interrupted on a claimed native platform; identify the property that must remain true: “Paths with spaces do not change the intended command”.
- [ ] **UC-M12.07-C017-T02 · Baseline capture:** Create a known-valid “Launcher argument handling” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M12.07-C017-T03 · Injection map:** Locate the “Launcher argument handling” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M12.07-C017-T04 · Disposition oracle:** Define the legal intermediate and final “Launcher argument handling” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M12.07-C017-T05 · Controlled trigger:** Introduce the controlled “Launcher argument handling” scenario in the disposable fixture: installation or upgrade is interrupted on a claimed native platform; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M12.07-C017-T06 · Intermediate inspection:** Inspect the “Launcher argument handling” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M12.07-C017-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Launcher argument handling”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M12.07-C017-T08 · Stale-evidence cleanup:** Invalidate superseded “Launcher argument handling” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M12.07-C017-T09 · Repeat and compare:** Repeat the selected “Launcher argument handling” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M12.07-C017-T10 · Failure evidence:** Publish the “Launcher argument handling” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M12.07-C018 · Bounds

**Original checklist item:** Set a documented campaign budget for argument bytes and launch variants; record actual consumption, incomplete coverage and the disposition when the budget is exhausted.

- [ ] **UC-M12.07-C018-T01 · Quantity inventory:** Create a measurement inventory for “Launcher argument handling”: “Argument bytes and launch variants”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M12.07-C018-T02 · Measurement method:** Choose how to observe each “Launcher argument handling” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M12.07-C018-T03 · Budget decision:** Select justified campaign and target-resource budgets for “Launcher argument handling”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M12.07-C018-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Launcher argument handling” cases for “Argument bytes and launch variants”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M12.07-C018-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Launcher argument handling” limit; preserve “Paths with spaces do not change the intended command”.
- [ ] **UC-M12.07-C018-T06 · Normal measurement:** Run or review the normal “Launcher argument handling” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M12.07-C018-T07 · At-limit measurement:** Exercise the “Launcher argument handling” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M12.07-C018-T08 · Over-limit measurement:** Exercise the “Launcher argument handling” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M12.07-C018-T09 · Uncovered-scope report:** List the “Launcher argument handling” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M12.07-C018-T10 · Limit evidence:** Publish the selected “Launcher argument handling” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M12.07-C019 · Diagnostics / review

**Original checklist item:** Report launcher argument handling results with executed, failed, skipped and unavailable cases separated; preserve the underlying observations and do not manufacture missing measurements.

- [ ] **UC-M12.07-C019-T01 · Result inventory:** Enumerate the required “Launcher argument handling” qualification cases and intended targets before aggregating results; keep the planned denominator visible.
- [ ] **UC-M12.07-C019-T02 · Verdict schema:** Define separate executed-pass, executed-fail, skipped, unavailable and untested outcomes for “Launcher argument handling”; document how incomplete cases block relevant claims.
- [ ] **UC-M12.07-C019-T03 · Identity fields:** Attach the actual target, fixture, configuration and revision identifiers to each “Launcher argument handling” result; do not attribute host-only evidence to a guest or another OS.
- [ ] **UC-M12.07-C019-T04 · Observation capture:** Capture bounded raw “Launcher argument handling” observations and harness errors; retain enough information to verify the reported oracle comparison.
- [ ] **UC-M12.07-C019-T05 · Aggregation rules:** Implement the “Launcher argument handling” count/reduction rule so failures and missing measurements cannot disappear; preserve “Paths with spaces do not change the intended command”.
- [ ] **UC-M12.07-C019-T06 · Failure visibility:** Feed a failing “Launcher argument handling” control through the report path; assert the exact failed case and underlying observation remain visible.
- [ ] **UC-M12.07-C019-T07 · Missing-result visibility:** Withhold a required “Launcher argument handling” measurement or target; verify the report uses unavailable/untested rather than a fabricated zero or passing value.
- [ ] **UC-M12.07-C019-T08 · Bounds and redaction:** Check “Launcher argument handling” report size and retention against “Argument bytes and launch variants”; remove secrets while retaining fixture and subject references.
- [ ] **UC-M12.07-C019-T09 · Report reconciliation:** Reconcile the “Launcher argument handling” summary with every underlying case record; account for the full planned denominator and all omitted scope.
- [ ] **UC-M12.07-C019-T10 · Qualification handoff:** Publish the “Launcher argument handling” report with measured observations, coverage limits and blockers; state which actual targets remain unqualified.

### UC-M12.07-C020 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for launcher argument handling; label unexecuted checks as untested.

- [ ] **UC-M12.07-C020-T01 · Evidence inventory:** List the “Launcher argument handling” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M12.07-C020-T02 · Artifact references:** Record the exact “Launcher argument handling” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M12.07-C020-T03 · Fixture references:** Attach the “Launcher argument handling” fixture IDs, input identities and oracle definition; preserve the source counterexample “A launcher splits the installation root at a space” as a distinct evidence case.
- [ ] **UC-M12.07-C020-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Launcher argument handling”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M12.07-C020-T05 · Environment record:** Record the actual “Launcher argument handling” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M12.07-C020-T06 · Expected versus observed:** Pair every “Launcher argument handling” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M12.07-C020-T07 · Failure and limit records:** Attach “Launcher argument handling” change/failure and bounds evidence where required; include uncovered “Argument bytes and launch variants” and unresolved violations of “Paths with spaces do not change the intended command”.
- [ ] **UC-M12.07-C020-T08 · Evidence hygiene:** Check the “Launcher argument handling” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M12.07-C020-T09 · Reproduction review:** Have the “Launcher argument handling” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M12.07-C020-T10 · Acceptance linkage:** Link the “Launcher argument handling” evidence to its parent and UC-M12.07 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 03. Dependency preflight

**Source delivery:** Check required interpreter, libraries, tools and backend capabilities before mutation.

**Source invariant:** Missing prerequisites produce a clear safe stop.

**Source negative case:** The installer partially updates files before detecting a missing runtime.

**Source bounded quantities:** Checks and preflight duration.

### UC-M12.07-C021 · Contract

**Original checklist item:** Define the qualification objective for dependency preflight, including the actual target implementation, prerequisites, observable oracle and explicit exclusions.

- [ ] **UC-M12.07-C021-T01 · Scope statement:** Write the qualification question for “Dependency preflight”; identify the actual target, claimed capability and observations that can answer that question.
- [ ] **UC-M12.07-C021-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Dependency preflight”; record each producer, representation and missing-value meaning.
- [ ] **UC-M12.07-C021-T03 · Output inventory:** List the outputs of “Dependency preflight” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M12.07-C021-T04 · Field dictionary:** Create a field-and-term dictionary for “Dependency preflight”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M12.07-C021-T05 · Prerequisite contract:** Map “Dependency preflight” to the source component prerequisites (UC-M07.08, UC-M09.02, UC-M12.01); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M12.07-C021-T06 · Authority map:** Identify who may produce, change and consume “Dependency preflight”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M12.07-C021-T07 · Invariant clause:** Add a normative clause for “Dependency preflight” that preserves “Missing prerequisites produce a clear safe stop”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M12.07-C021-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Dependency preflight”; include the source counterexample “The installer partially updates files before detecting a missing runtime” and the intended safe disposition.
- [ ] **UC-M12.07-C021-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Checks and preflight duration” in the “Dependency preflight” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M12.07-C021-T10 · Contract review:** Review the “Dependency preflight” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M12.07-C022 · Delivery

**Original checklist item:** Check required interpreter, libraries, tools and backend capabilities before mutation.

- [ ] **UC-M12.07-C022-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Dependency preflight”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M12.07-C022-T02 · Change plan:** Break the source delivery for “Dependency preflight” into concrete edit targets and reviewable outputs; keep the UC-M12.07 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M12.07-C022-T03 · Core artifact:** Create the “Dependency preflight” fixture or harness for this source instruction: Check required interpreter, libraries, tools and backend capabilities before mutation.
- [ ] **UC-M12.07-C022-T04 · Concrete realization:** Connect the “Dependency preflight” harness to its actual intended target, set the expected oracle before running it, and distinguish a mock/control run from a target run.
- [ ] **UC-M12.07-C022-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Dependency preflight” needed to preserve “Missing prerequisites produce a clear safe stop”; record an enforcement gap where only a model exists.
- [ ] **UC-M12.07-C022-T06 · Dependency connection:** Connect the “Dependency preflight” qualification artifact to authenticated packages, short-path launchers and user-state-preserving upgrade transactions; record the target identity and what the harness actually exercises.
- [ ] **UC-M12.07-C022-T07 · Resource behavior:** Account for “Checks and preflight duration” in “Dependency preflight”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M12.07-C022-T08 · Delivery check:** Run a known-valid control and a deliberately failing control for “Dependency preflight”; confirm the harness distinguishes their observed outcomes.
- [ ] **UC-M12.07-C022-T09 · Patch review:** Review the “Dependency preflight” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M12.07-C022-T10 · Delivery handoff:** Publish the “Dependency preflight” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M12.07-C023 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Missing prerequisites produce a clear safe stop. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M12.07-C023-T01 · Named property:** Create a stable property/check name under this parent for “Dependency preflight”; copy its required invariant exactly: “Missing prerequisites produce a clear safe stop”.
- [ ] **UC-M12.07-C023-T02 · Observable terms:** Define each term in the “Dependency preflight” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M12.07-C023-T03 · Precondition set:** List the preconditions under which “Missing prerequisites produce a clear safe stop” must hold for “Dependency preflight”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M12.07-C023-T04 · Transition coverage:** Map the “Dependency preflight” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M12.07-C023-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Dependency preflight”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M12.07-C023-T06 · Satisfying fixture:** Create a concrete “Dependency preflight” case that satisfies “Missing prerequisites produce a clear safe stop”; record its expected observation before running the assertion or review.
- [ ] **UC-M12.07-C023-T07 · Violating fixture:** Create the source counterexample “The installer partially updates files before detecting a missing runtime” for “Dependency preflight”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M12.07-C023-T08 · Enforcement evidence:** Exercise the “Dependency preflight” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M12.07-C023-T09 · Regression linkage:** Link the “Dependency preflight” property to changes in authenticated packages, short-path launchers and user-state-preserving upgrade transactions; record which dependency or contract changes require rerunning it.
- [ ] **UC-M12.07-C023-T10 · Property disposition:** Compare the satisfying and violating “Dependency preflight” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M12.07-C024 · Integration

**Original checklist item:** Integrate dependency preflight with authenticated packages, short-path launchers and user-state-preserving upgrade transactions; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M12.07-C024-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Dependency preflight” across authenticated packages, short-path launchers and user-state-preserving upgrade transactions; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M12.07-C024-T02 · Field mapping:** Map every “Dependency preflight” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M12.07-C024-T03 · Prerequisite identities:** Record the actual prerequisites for “Dependency preflight” (source dependency list: UC-M07.08, UC-M09.02, UC-M12.01); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M12.07-C024-T04 · Ownership agreement:** Specify who owns “Dependency preflight” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M12.07-C024-T05 · Handoff implementation:** Connect “Dependency preflight” through the mapped seam using the real adapter or explicit specification reference; preserve “Missing prerequisites produce a clear safe stop” across the handoff.
- [ ] **UC-M12.07-C024-T06 · Absent-input case:** Omit one required “Dependency preflight” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M12.07-C024-T07 · Stale-input case:** Supply an outdated “Dependency preflight” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M12.07-C024-T08 · Incompatible-input case:** Supply an incompatible “Dependency preflight” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M12.07-C024-T09 · Valid integration trace:** Run a valid “Dependency preflight” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M12.07-C024-T10 · Seam review:** Reconcile the “Dependency preflight” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M12.07-C025 · Valid-case test

**Original checklist item:** Run a known-valid control for dependency preflight; verify that the harness reaches its intended target and compare observed measurements or verdicts with predeclared expectations.

- [ ] **UC-M12.07-C025-T01 · Valid fixture choice:** Choose a known-valid control for “Dependency preflight”; document why it should pass and how it proves the harness reaches the intended target.
- [ ] **UC-M12.07-C025-T02 · Expected-result oracle:** Specify the “Dependency preflight” expected result independently of the implementation output; include the property “Missing prerequisites produce a clear safe stop” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M12.07-C025-T03 · Fixture material:** Create the concrete “Dependency preflight” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M12.07-C025-T04 · Target preparation:** Prepare the “Dependency preflight” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M12.07-C025-T05 · Initial-state record:** Record the initial “Dependency preflight” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M12.07-C025-T06 · Valid-path execution:** Run the “Dependency preflight” known-valid control on the identified target; retain enough observations to prove the correct target was exercised.
- [ ] **UC-M12.07-C025-T07 · Outcome comparison:** Compare every declared “Dependency preflight” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M12.07-C025-T08 · State and bounds check:** Inspect the “Dependency preflight” ownership/state effects and actual use of “Checks and preflight duration”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M12.07-C025-T09 · Repeatability check:** Repeat the same “Dependency preflight” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M12.07-C025-T10 · Positive evidence:** Attach the “Dependency preflight” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M12.07-C026 · Negative test

**Original checklist item:** Negative case: The installer partially updates files before detecting a missing runtime. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M12.07-C026-T01 · Adverse-case definition:** Create a test record for the exact “Dependency preflight” source counterexample: “The installer partially updates files before detecting a missing runtime”; state which precondition or invariant it challenges.
- [ ] **UC-M12.07-C026-T02 · Safe fixture boundary:** Define the contained test boundary for “Dependency preflight”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M12.07-C026-T03 · Valid control:** Construct a valid “Dependency preflight” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M12.07-C026-T04 · Minimal adverse input:** Derive the “Dependency preflight” adverse fixture from the control with the smallest documented change needed to reproduce “The installer partially updates files before detecting a missing runtime”; retain that change as reproducible data.
- [ ] **UC-M12.07-C026-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Dependency preflight”; require “Missing prerequisites produce a clear safe stop” and forbid a false-success verdict.
- [ ] **UC-M12.07-C026-T06 · Adverse execution:** Exercise the “Dependency preflight” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M12.07-C026-T07 · Effect inspection:** Inspect “Dependency preflight” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M12.07-C026-T08 · Refusal versus failure:** Confirm the “Dependency preflight” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M12.07-C026-T09 · Reset and retention:** Restore only the disposable “Dependency preflight” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M12.07-C026-T10 · Negative regression:** Register the “Dependency preflight” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M12.07-C027 · Change / failure test

**Original checklist item:** Exercise dependency preflight when installation or upgrade is interrupted on a claimed native platform; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M12.07-C027-T01 · Scenario record:** Write the “Dependency preflight” change/failure scenario exactly as supplied: installation or upgrade is interrupted on a claimed native platform; identify the property that must remain true: “Missing prerequisites produce a clear safe stop”.
- [ ] **UC-M12.07-C027-T02 · Baseline capture:** Create a known-valid “Dependency preflight” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M12.07-C027-T03 · Injection map:** Locate the “Dependency preflight” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M12.07-C027-T04 · Disposition oracle:** Define the legal intermediate and final “Dependency preflight” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M12.07-C027-T05 · Controlled trigger:** Introduce the controlled “Dependency preflight” scenario in the disposable fixture: installation or upgrade is interrupted on a claimed native platform; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M12.07-C027-T06 · Intermediate inspection:** Inspect the “Dependency preflight” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M12.07-C027-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Dependency preflight”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M12.07-C027-T08 · Stale-evidence cleanup:** Invalidate superseded “Dependency preflight” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M12.07-C027-T09 · Repeat and compare:** Repeat the selected “Dependency preflight” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M12.07-C027-T10 · Failure evidence:** Publish the “Dependency preflight” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M12.07-C028 · Bounds

**Original checklist item:** Set a documented campaign budget for checks and preflight duration; record actual consumption, incomplete coverage and the disposition when the budget is exhausted.

- [ ] **UC-M12.07-C028-T01 · Quantity inventory:** Create a measurement inventory for “Dependency preflight”: “Checks and preflight duration”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M12.07-C028-T02 · Measurement method:** Choose how to observe each “Dependency preflight” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M12.07-C028-T03 · Budget decision:** Select justified campaign and target-resource budgets for “Dependency preflight”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M12.07-C028-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Dependency preflight” cases for “Checks and preflight duration”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M12.07-C028-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Dependency preflight” limit; preserve “Missing prerequisites produce a clear safe stop”.
- [ ] **UC-M12.07-C028-T06 · Normal measurement:** Run or review the normal “Dependency preflight” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M12.07-C028-T07 · At-limit measurement:** Exercise the “Dependency preflight” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M12.07-C028-T08 · Over-limit measurement:** Exercise the “Dependency preflight” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M12.07-C028-T09 · Uncovered-scope report:** List the “Dependency preflight” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M12.07-C028-T10 · Limit evidence:** Publish the selected “Dependency preflight” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M12.07-C029 · Diagnostics / review

**Original checklist item:** Report dependency preflight results with executed, failed, skipped and unavailable cases separated; preserve the underlying observations and do not manufacture missing measurements.

- [ ] **UC-M12.07-C029-T01 · Result inventory:** Enumerate the required “Dependency preflight” qualification cases and intended targets before aggregating results; keep the planned denominator visible.
- [ ] **UC-M12.07-C029-T02 · Verdict schema:** Define separate executed-pass, executed-fail, skipped, unavailable and untested outcomes for “Dependency preflight”; document how incomplete cases block relevant claims.
- [ ] **UC-M12.07-C029-T03 · Identity fields:** Attach the actual target, fixture, configuration and revision identifiers to each “Dependency preflight” result; do not attribute host-only evidence to a guest or another OS.
- [ ] **UC-M12.07-C029-T04 · Observation capture:** Capture bounded raw “Dependency preflight” observations and harness errors; retain enough information to verify the reported oracle comparison.
- [ ] **UC-M12.07-C029-T05 · Aggregation rules:** Implement the “Dependency preflight” count/reduction rule so failures and missing measurements cannot disappear; preserve “Missing prerequisites produce a clear safe stop”.
- [ ] **UC-M12.07-C029-T06 · Failure visibility:** Feed a failing “Dependency preflight” control through the report path; assert the exact failed case and underlying observation remain visible.
- [ ] **UC-M12.07-C029-T07 · Missing-result visibility:** Withhold a required “Dependency preflight” measurement or target; verify the report uses unavailable/untested rather than a fabricated zero or passing value.
- [ ] **UC-M12.07-C029-T08 · Bounds and redaction:** Check “Dependency preflight” report size and retention against “Checks and preflight duration”; remove secrets while retaining fixture and subject references.
- [ ] **UC-M12.07-C029-T09 · Report reconciliation:** Reconcile the “Dependency preflight” summary with every underlying case record; account for the full planned denominator and all omitted scope.
- [ ] **UC-M12.07-C029-T10 · Qualification handoff:** Publish the “Dependency preflight” report with measured observations, coverage limits and blockers; state which actual targets remain unqualified.

### UC-M12.07-C030 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for dependency preflight; label unexecuted checks as untested.

- [ ] **UC-M12.07-C030-T01 · Evidence inventory:** List the “Dependency preflight” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M12.07-C030-T02 · Artifact references:** Record the exact “Dependency preflight” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M12.07-C030-T03 · Fixture references:** Attach the “Dependency preflight” fixture IDs, input identities and oracle definition; preserve the source counterexample “The installer partially updates files before detecting a missing runtime” as a distinct evidence case.
- [ ] **UC-M12.07-C030-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Dependency preflight”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M12.07-C030-T05 · Environment record:** Record the actual “Dependency preflight” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M12.07-C030-T06 · Expected versus observed:** Pair every “Dependency preflight” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M12.07-C030-T07 · Failure and limit records:** Attach “Dependency preflight” change/failure and bounds evidence where required; include uncovered “Checks and preflight duration” and unresolved violations of “Missing prerequisites produce a clear safe stop”.
- [ ] **UC-M12.07-C030-T08 · Evidence hygiene:** Check the “Dependency preflight” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M12.07-C030-T09 · Reproduction review:** Have the “Dependency preflight” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M12.07-C030-T10 · Acceptance linkage:** Link the “Dependency preflight” evidence to its parent and UC-M12.07 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 04. Authenticated package verification

**Source delivery:** Verify approved signatures and update metadata before executing installer payloads.

**Source invariant:** A checksum-only package cannot bypass required release authority.

**Source negative case:** A self-signed installer is accepted from its embedded key.

**Source bounded quantities:** Package bytes and verification records.

### UC-M12.07-C031 · Contract

**Original checklist item:** Define the qualification objective for authenticated package verification, including the actual target implementation, prerequisites, observable oracle and explicit exclusions.

- [ ] **UC-M12.07-C031-T01 · Scope statement:** Write the qualification question for “Authenticated package verification”; identify the actual target, claimed capability and observations that can answer that question.
- [ ] **UC-M12.07-C031-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Authenticated package verification”; record each producer, representation and missing-value meaning.
- [ ] **UC-M12.07-C031-T03 · Output inventory:** List the outputs of “Authenticated package verification” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M12.07-C031-T04 · Field dictionary:** Create a field-and-term dictionary for “Authenticated package verification”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M12.07-C031-T05 · Prerequisite contract:** Map “Authenticated package verification” to the source component prerequisites (UC-M07.08, UC-M09.02, UC-M12.01); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M12.07-C031-T06 · Authority map:** Identify who may produce, change and consume “Authenticated package verification”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M12.07-C031-T07 · Invariant clause:** Add a normative clause for “Authenticated package verification” that preserves “A checksum-only package cannot bypass required release authority”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M12.07-C031-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Authenticated package verification”; include the source counterexample “A self-signed installer is accepted from its embedded key” and the intended safe disposition.
- [ ] **UC-M12.07-C031-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Package bytes and verification records” in the “Authenticated package verification” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M12.07-C031-T10 · Contract review:** Review the “Authenticated package verification” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M12.07-C032 · Delivery

**Original checklist item:** Verify approved signatures and update metadata before executing installer payloads.

- [ ] **UC-M12.07-C032-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Authenticated package verification”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M12.07-C032-T02 · Change plan:** Break the source delivery for “Authenticated package verification” into concrete edit targets and reviewable outputs; keep the UC-M12.07 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M12.07-C032-T03 · Core artifact:** Create the “Authenticated package verification” fixture or harness for this source instruction: Verify approved signatures and update metadata before executing installer payloads.
- [ ] **UC-M12.07-C032-T04 · Concrete realization:** Connect the “Authenticated package verification” harness to its actual intended target, set the expected oracle before running it, and distinguish a mock/control run from a target run.
- [ ] **UC-M12.07-C032-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Authenticated package verification” needed to preserve “A checksum-only package cannot bypass required release authority”; record an enforcement gap where only a model exists.
- [ ] **UC-M12.07-C032-T06 · Dependency connection:** Connect the “Authenticated package verification” qualification artifact to authenticated packages, short-path launchers and user-state-preserving upgrade transactions; record the target identity and what the harness actually exercises.
- [ ] **UC-M12.07-C032-T07 · Resource behavior:** Account for “Package bytes and verification records” in “Authenticated package verification”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M12.07-C032-T08 · Delivery check:** Run a known-valid control and a deliberately failing control for “Authenticated package verification”; confirm the harness distinguishes their observed outcomes.
- [ ] **UC-M12.07-C032-T09 · Patch review:** Review the “Authenticated package verification” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M12.07-C032-T10 · Delivery handoff:** Publish the “Authenticated package verification” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M12.07-C033 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: A checksum-only package cannot bypass required release authority. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M12.07-C033-T01 · Named property:** Create a stable property/check name under this parent for “Authenticated package verification”; copy its required invariant exactly: “A checksum-only package cannot bypass required release authority”.
- [ ] **UC-M12.07-C033-T02 · Observable terms:** Define each term in the “Authenticated package verification” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M12.07-C033-T03 · Precondition set:** List the preconditions under which “A checksum-only package cannot bypass required release authority” must hold for “Authenticated package verification”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M12.07-C033-T04 · Transition coverage:** Map the “Authenticated package verification” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M12.07-C033-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Authenticated package verification”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M12.07-C033-T06 · Satisfying fixture:** Create a concrete “Authenticated package verification” case that satisfies “A checksum-only package cannot bypass required release authority”; record its expected observation before running the assertion or review.
- [ ] **UC-M12.07-C033-T07 · Violating fixture:** Create the source counterexample “A self-signed installer is accepted from its embedded key” for “Authenticated package verification”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M12.07-C033-T08 · Enforcement evidence:** Exercise the “Authenticated package verification” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M12.07-C033-T09 · Regression linkage:** Link the “Authenticated package verification” property to changes in authenticated packages, short-path launchers and user-state-preserving upgrade transactions; record which dependency or contract changes require rerunning it.
- [ ] **UC-M12.07-C033-T10 · Property disposition:** Compare the satisfying and violating “Authenticated package verification” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M12.07-C034 · Integration

**Original checklist item:** Integrate authenticated package verification with authenticated packages, short-path launchers and user-state-preserving upgrade transactions; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M12.07-C034-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Authenticated package verification” across authenticated packages, short-path launchers and user-state-preserving upgrade transactions; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M12.07-C034-T02 · Field mapping:** Map every “Authenticated package verification” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M12.07-C034-T03 · Prerequisite identities:** Record the actual prerequisites for “Authenticated package verification” (source dependency list: UC-M07.08, UC-M09.02, UC-M12.01); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M12.07-C034-T04 · Ownership agreement:** Specify who owns “Authenticated package verification” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M12.07-C034-T05 · Handoff implementation:** Connect “Authenticated package verification” through the mapped seam using the real adapter or explicit specification reference; preserve “A checksum-only package cannot bypass required release authority” across the handoff.
- [ ] **UC-M12.07-C034-T06 · Absent-input case:** Omit one required “Authenticated package verification” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M12.07-C034-T07 · Stale-input case:** Supply an outdated “Authenticated package verification” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M12.07-C034-T08 · Incompatible-input case:** Supply an incompatible “Authenticated package verification” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M12.07-C034-T09 · Valid integration trace:** Run a valid “Authenticated package verification” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M12.07-C034-T10 · Seam review:** Reconcile the “Authenticated package verification” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M12.07-C035 · Valid-case test

**Original checklist item:** Run a known-valid control for authenticated package verification; verify that the harness reaches its intended target and compare observed measurements or verdicts with predeclared expectations.

- [ ] **UC-M12.07-C035-T01 · Valid fixture choice:** Choose a known-valid control for “Authenticated package verification”; document why it should pass and how it proves the harness reaches the intended target.
- [ ] **UC-M12.07-C035-T02 · Expected-result oracle:** Specify the “Authenticated package verification” expected result independently of the implementation output; include the property “A checksum-only package cannot bypass required release authority” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M12.07-C035-T03 · Fixture material:** Create the concrete “Authenticated package verification” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M12.07-C035-T04 · Target preparation:** Prepare the “Authenticated package verification” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M12.07-C035-T05 · Initial-state record:** Record the initial “Authenticated package verification” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M12.07-C035-T06 · Valid-path execution:** Run the “Authenticated package verification” known-valid control on the identified target; retain enough observations to prove the correct target was exercised.
- [ ] **UC-M12.07-C035-T07 · Outcome comparison:** Compare every declared “Authenticated package verification” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M12.07-C035-T08 · State and bounds check:** Inspect the “Authenticated package verification” ownership/state effects and actual use of “Package bytes and verification records”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M12.07-C035-T09 · Repeatability check:** Repeat the same “Authenticated package verification” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M12.07-C035-T10 · Positive evidence:** Attach the “Authenticated package verification” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M12.07-C036 · Negative test

**Original checklist item:** Negative case: A self-signed installer is accepted from its embedded key. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M12.07-C036-T01 · Adverse-case definition:** Create a test record for the exact “Authenticated package verification” source counterexample: “A self-signed installer is accepted from its embedded key”; state which precondition or invariant it challenges.
- [ ] **UC-M12.07-C036-T02 · Safe fixture boundary:** Define the contained test boundary for “Authenticated package verification”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M12.07-C036-T03 · Valid control:** Construct a valid “Authenticated package verification” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M12.07-C036-T04 · Minimal adverse input:** Derive the “Authenticated package verification” adverse fixture from the control with the smallest documented change needed to reproduce “A self-signed installer is accepted from its embedded key”; retain that change as reproducible data.
- [ ] **UC-M12.07-C036-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Authenticated package verification”; require “A checksum-only package cannot bypass required release authority” and forbid a false-success verdict.
- [ ] **UC-M12.07-C036-T06 · Adverse execution:** Exercise the “Authenticated package verification” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M12.07-C036-T07 · Effect inspection:** Inspect “Authenticated package verification” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M12.07-C036-T08 · Refusal versus failure:** Confirm the “Authenticated package verification” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M12.07-C036-T09 · Reset and retention:** Restore only the disposable “Authenticated package verification” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M12.07-C036-T10 · Negative regression:** Register the “Authenticated package verification” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M12.07-C037 · Change / failure test

**Original checklist item:** Exercise authenticated package verification when installation or upgrade is interrupted on a claimed native platform; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M12.07-C037-T01 · Scenario record:** Write the “Authenticated package verification” change/failure scenario exactly as supplied: installation or upgrade is interrupted on a claimed native platform; identify the property that must remain true: “A checksum-only package cannot bypass required release authority”.
- [ ] **UC-M12.07-C037-T02 · Baseline capture:** Create a known-valid “Authenticated package verification” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M12.07-C037-T03 · Injection map:** Locate the “Authenticated package verification” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M12.07-C037-T04 · Disposition oracle:** Define the legal intermediate and final “Authenticated package verification” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M12.07-C037-T05 · Controlled trigger:** Introduce the controlled “Authenticated package verification” scenario in the disposable fixture: installation or upgrade is interrupted on a claimed native platform; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M12.07-C037-T06 · Intermediate inspection:** Inspect the “Authenticated package verification” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M12.07-C037-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Authenticated package verification”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M12.07-C037-T08 · Stale-evidence cleanup:** Invalidate superseded “Authenticated package verification” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M12.07-C037-T09 · Repeat and compare:** Repeat the selected “Authenticated package verification” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M12.07-C037-T10 · Failure evidence:** Publish the “Authenticated package verification” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M12.07-C038 · Bounds

**Original checklist item:** Set a documented campaign budget for package bytes and verification records; record actual consumption, incomplete coverage and the disposition when the budget is exhausted.

- [ ] **UC-M12.07-C038-T01 · Quantity inventory:** Create a measurement inventory for “Authenticated package verification”: “Package bytes and verification records”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M12.07-C038-T02 · Measurement method:** Choose how to observe each “Authenticated package verification” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M12.07-C038-T03 · Budget decision:** Select justified campaign and target-resource budgets for “Authenticated package verification”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M12.07-C038-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Authenticated package verification” cases for “Package bytes and verification records”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M12.07-C038-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Authenticated package verification” limit; preserve “A checksum-only package cannot bypass required release authority”.
- [ ] **UC-M12.07-C038-T06 · Normal measurement:** Run or review the normal “Authenticated package verification” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M12.07-C038-T07 · At-limit measurement:** Exercise the “Authenticated package verification” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M12.07-C038-T08 · Over-limit measurement:** Exercise the “Authenticated package verification” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M12.07-C038-T09 · Uncovered-scope report:** List the “Authenticated package verification” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M12.07-C038-T10 · Limit evidence:** Publish the selected “Authenticated package verification” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M12.07-C039 · Diagnostics / review

**Original checklist item:** Report authenticated package verification results with executed, failed, skipped and unavailable cases separated; preserve the underlying observations and do not manufacture missing measurements.

- [ ] **UC-M12.07-C039-T01 · Result inventory:** Enumerate the required “Authenticated package verification” qualification cases and intended targets before aggregating results; keep the planned denominator visible.
- [ ] **UC-M12.07-C039-T02 · Verdict schema:** Define separate executed-pass, executed-fail, skipped, unavailable and untested outcomes for “Authenticated package verification”; document how incomplete cases block relevant claims.
- [ ] **UC-M12.07-C039-T03 · Identity fields:** Attach the actual target, fixture, configuration and revision identifiers to each “Authenticated package verification” result; do not attribute host-only evidence to a guest or another OS.
- [ ] **UC-M12.07-C039-T04 · Observation capture:** Capture bounded raw “Authenticated package verification” observations and harness errors; retain enough information to verify the reported oracle comparison.
- [ ] **UC-M12.07-C039-T05 · Aggregation rules:** Implement the “Authenticated package verification” count/reduction rule so failures and missing measurements cannot disappear; preserve “A checksum-only package cannot bypass required release authority”.
- [ ] **UC-M12.07-C039-T06 · Failure visibility:** Feed a failing “Authenticated package verification” control through the report path; assert the exact failed case and underlying observation remain visible.
- [ ] **UC-M12.07-C039-T07 · Missing-result visibility:** Withhold a required “Authenticated package verification” measurement or target; verify the report uses unavailable/untested rather than a fabricated zero or passing value.
- [ ] **UC-M12.07-C039-T08 · Bounds and redaction:** Check “Authenticated package verification” report size and retention against “Package bytes and verification records”; remove secrets while retaining fixture and subject references.
- [ ] **UC-M12.07-C039-T09 · Report reconciliation:** Reconcile the “Authenticated package verification” summary with every underlying case record; account for the full planned denominator and all omitted scope.
- [ ] **UC-M12.07-C039-T10 · Qualification handoff:** Publish the “Authenticated package verification” report with measured observations, coverage limits and blockers; state which actual targets remain unqualified.

### UC-M12.07-C040 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for authenticated package verification; label unexecuted checks as untested.

- [ ] **UC-M12.07-C040-T01 · Evidence inventory:** List the “Authenticated package verification” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M12.07-C040-T02 · Artifact references:** Record the exact “Authenticated package verification” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M12.07-C040-T03 · Fixture references:** Attach the “Authenticated package verification” fixture IDs, input identities and oracle definition; preserve the source counterexample “A self-signed installer is accepted from its embedded key” as a distinct evidence case.
- [ ] **UC-M12.07-C040-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Authenticated package verification”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M12.07-C040-T05 · Environment record:** Record the actual “Authenticated package verification” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M12.07-C040-T06 · Expected versus observed:** Pair every “Authenticated package verification” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M12.07-C040-T07 · Failure and limit records:** Attach “Authenticated package verification” change/failure and bounds evidence where required; include uncovered “Package bytes and verification records” and unresolved violations of “A checksum-only package cannot bypass required release authority”.
- [ ] **UC-M12.07-C040-T08 · Evidence hygiene:** Check the “Authenticated package verification” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M12.07-C040-T09 · Reproduction review:** Have the “Authenticated package verification” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M12.07-C040-T10 · Acceptance linkage:** Link the “Authenticated package verification” evidence to its parent and UC-M12.07 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 05. User-state preservation

**Source delivery:** Separate application-owned replacement files from user cargo and mutable state.

**Source invariant:** Upgrade cannot silently overwrite user edits or live data.

**Source negative case:** An update replaces a user-modified workspace with bundled defaults.

**Source bounded quantities:** User files and migration inventory size.

### UC-M12.07-C041 · Contract

**Original checklist item:** Define the qualification objective for user-state preservation, including the actual target implementation, prerequisites, observable oracle and explicit exclusions.

- [ ] **UC-M12.07-C041-T01 · Scope statement:** Write the qualification question for “User-state preservation”; identify the actual target, claimed capability and observations that can answer that question.
- [ ] **UC-M12.07-C041-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “User-state preservation”; record each producer, representation and missing-value meaning.
- [ ] **UC-M12.07-C041-T03 · Output inventory:** List the outputs of “User-state preservation” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M12.07-C041-T04 · Field dictionary:** Create a field-and-term dictionary for “User-state preservation”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M12.07-C041-T05 · Prerequisite contract:** Map “User-state preservation” to the source component prerequisites (UC-M07.08, UC-M09.02, UC-M12.01); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M12.07-C041-T06 · Authority map:** Identify who may produce, change and consume “User-state preservation”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M12.07-C041-T07 · Invariant clause:** Add a normative clause for “User-state preservation” that preserves “Upgrade cannot silently overwrite user edits or live data”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M12.07-C041-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “User-state preservation”; include the source counterexample “An update replaces a user-modified workspace with bundled defaults” and the intended safe disposition.
- [ ] **UC-M12.07-C041-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “User files and migration inventory size” in the “User-state preservation” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M12.07-C041-T10 · Contract review:** Review the “User-state preservation” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M12.07-C042 · Delivery

**Original checklist item:** Separate application-owned replacement files from user cargo and mutable state.

- [ ] **UC-M12.07-C042-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “User-state preservation”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M12.07-C042-T02 · Change plan:** Break the source delivery for “User-state preservation” into concrete edit targets and reviewable outputs; keep the UC-M12.07 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M12.07-C042-T03 · Core artifact:** Implement the smallest selected-profile change for “User-state preservation” that realizes this source instruction: Separate application-owned replacement files from user cargo and mutable state.
- [ ] **UC-M12.07-C042-T04 · Concrete realization:** Trace “User-state preservation” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M12.07-C042-T05 · Invariant protection:** Add the actual guard, check or review criterion for “User-state preservation” needed to preserve “Upgrade cannot silently overwrite user edits or live data”; record an enforcement gap where only a model exists.
- [ ] **UC-M12.07-C042-T06 · Dependency connection:** Connect the “User-state preservation” qualification artifact to authenticated packages, short-path launchers and user-state-preserving upgrade transactions; record the target identity and what the harness actually exercises.
- [ ] **UC-M12.07-C042-T07 · Resource behavior:** Account for “User files and migration inventory size” in “User-state preservation”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M12.07-C042-T08 · Delivery check:** Run a known-valid control and a deliberately failing control for “User-state preservation”; confirm the harness distinguishes their observed outcomes.
- [ ] **UC-M12.07-C042-T09 · Patch review:** Review the “User-state preservation” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M12.07-C042-T10 · Delivery handoff:** Publish the “User-state preservation” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M12.07-C043 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Upgrade cannot silently overwrite user edits or live data. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M12.07-C043-T01 · Named property:** Create a stable property/check name under this parent for “User-state preservation”; copy its required invariant exactly: “Upgrade cannot silently overwrite user edits or live data”.
- [ ] **UC-M12.07-C043-T02 · Observable terms:** Define each term in the “User-state preservation” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M12.07-C043-T03 · Precondition set:** List the preconditions under which “Upgrade cannot silently overwrite user edits or live data” must hold for “User-state preservation”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M12.07-C043-T04 · Transition coverage:** Map the “User-state preservation” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M12.07-C043-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “User-state preservation”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M12.07-C043-T06 · Satisfying fixture:** Create a concrete “User-state preservation” case that satisfies “Upgrade cannot silently overwrite user edits or live data”; record its expected observation before running the assertion or review.
- [ ] **UC-M12.07-C043-T07 · Violating fixture:** Create the source counterexample “An update replaces a user-modified workspace with bundled defaults” for “User-state preservation”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M12.07-C043-T08 · Enforcement evidence:** Exercise the “User-state preservation” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M12.07-C043-T09 · Regression linkage:** Link the “User-state preservation” property to changes in authenticated packages, short-path launchers and user-state-preserving upgrade transactions; record which dependency or contract changes require rerunning it.
- [ ] **UC-M12.07-C043-T10 · Property disposition:** Compare the satisfying and violating “User-state preservation” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M12.07-C044 · Integration

**Original checklist item:** Integrate user-state preservation with authenticated packages, short-path launchers and user-state-preserving upgrade transactions; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M12.07-C044-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “User-state preservation” across authenticated packages, short-path launchers and user-state-preserving upgrade transactions; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M12.07-C044-T02 · Field mapping:** Map every “User-state preservation” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M12.07-C044-T03 · Prerequisite identities:** Record the actual prerequisites for “User-state preservation” (source dependency list: UC-M07.08, UC-M09.02, UC-M12.01); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M12.07-C044-T04 · Ownership agreement:** Specify who owns “User-state preservation” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M12.07-C044-T05 · Handoff implementation:** Connect “User-state preservation” through the mapped seam using the real adapter or explicit specification reference; preserve “Upgrade cannot silently overwrite user edits or live data” across the handoff.
- [ ] **UC-M12.07-C044-T06 · Absent-input case:** Omit one required “User-state preservation” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M12.07-C044-T07 · Stale-input case:** Supply an outdated “User-state preservation” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M12.07-C044-T08 · Incompatible-input case:** Supply an incompatible “User-state preservation” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M12.07-C044-T09 · Valid integration trace:** Run a valid “User-state preservation” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M12.07-C044-T10 · Seam review:** Reconcile the “User-state preservation” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M12.07-C045 · Valid-case test

**Original checklist item:** Run a known-valid control for user-state preservation; verify that the harness reaches its intended target and compare observed measurements or verdicts with predeclared expectations.

- [ ] **UC-M12.07-C045-T01 · Valid fixture choice:** Choose a known-valid control for “User-state preservation”; document why it should pass and how it proves the harness reaches the intended target.
- [ ] **UC-M12.07-C045-T02 · Expected-result oracle:** Specify the “User-state preservation” expected result independently of the implementation output; include the property “Upgrade cannot silently overwrite user edits or live data” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M12.07-C045-T03 · Fixture material:** Create the concrete “User-state preservation” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M12.07-C045-T04 · Target preparation:** Prepare the “User-state preservation” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M12.07-C045-T05 · Initial-state record:** Record the initial “User-state preservation” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M12.07-C045-T06 · Valid-path execution:** Run the “User-state preservation” known-valid control on the identified target; retain enough observations to prove the correct target was exercised.
- [ ] **UC-M12.07-C045-T07 · Outcome comparison:** Compare every declared “User-state preservation” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M12.07-C045-T08 · State and bounds check:** Inspect the “User-state preservation” ownership/state effects and actual use of “User files and migration inventory size”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M12.07-C045-T09 · Repeatability check:** Repeat the same “User-state preservation” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M12.07-C045-T10 · Positive evidence:** Attach the “User-state preservation” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M12.07-C046 · Negative test

**Original checklist item:** Negative case: An update replaces a user-modified workspace with bundled defaults. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M12.07-C046-T01 · Adverse-case definition:** Create a test record for the exact “User-state preservation” source counterexample: “An update replaces a user-modified workspace with bundled defaults”; state which precondition or invariant it challenges.
- [ ] **UC-M12.07-C046-T02 · Safe fixture boundary:** Define the contained test boundary for “User-state preservation”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M12.07-C046-T03 · Valid control:** Construct a valid “User-state preservation” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M12.07-C046-T04 · Minimal adverse input:** Derive the “User-state preservation” adverse fixture from the control with the smallest documented change needed to reproduce “An update replaces a user-modified workspace with bundled defaults”; retain that change as reproducible data.
- [ ] **UC-M12.07-C046-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “User-state preservation”; require “Upgrade cannot silently overwrite user edits or live data” and forbid a false-success verdict.
- [ ] **UC-M12.07-C046-T06 · Adverse execution:** Exercise the “User-state preservation” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M12.07-C046-T07 · Effect inspection:** Inspect “User-state preservation” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M12.07-C046-T08 · Refusal versus failure:** Confirm the “User-state preservation” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M12.07-C046-T09 · Reset and retention:** Restore only the disposable “User-state preservation” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M12.07-C046-T10 · Negative regression:** Register the “User-state preservation” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M12.07-C047 · Change / failure test

**Original checklist item:** Exercise user-state preservation when installation or upgrade is interrupted on a claimed native platform; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M12.07-C047-T01 · Scenario record:** Write the “User-state preservation” change/failure scenario exactly as supplied: installation or upgrade is interrupted on a claimed native platform; identify the property that must remain true: “Upgrade cannot silently overwrite user edits or live data”.
- [ ] **UC-M12.07-C047-T02 · Baseline capture:** Create a known-valid “User-state preservation” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M12.07-C047-T03 · Injection map:** Locate the “User-state preservation” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M12.07-C047-T04 · Disposition oracle:** Define the legal intermediate and final “User-state preservation” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M12.07-C047-T05 · Controlled trigger:** Introduce the controlled “User-state preservation” scenario in the disposable fixture: installation or upgrade is interrupted on a claimed native platform; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M12.07-C047-T06 · Intermediate inspection:** Inspect the “User-state preservation” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M12.07-C047-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “User-state preservation”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M12.07-C047-T08 · Stale-evidence cleanup:** Invalidate superseded “User-state preservation” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M12.07-C047-T09 · Repeat and compare:** Repeat the selected “User-state preservation” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M12.07-C047-T10 · Failure evidence:** Publish the “User-state preservation” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M12.07-C048 · Bounds

**Original checklist item:** Set a documented campaign budget for user files and migration inventory size; record actual consumption, incomplete coverage and the disposition when the budget is exhausted.

- [ ] **UC-M12.07-C048-T01 · Quantity inventory:** Create a measurement inventory for “User-state preservation”: “User files and migration inventory size”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M12.07-C048-T02 · Measurement method:** Choose how to observe each “User-state preservation” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M12.07-C048-T03 · Budget decision:** Select justified campaign and target-resource budgets for “User-state preservation”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M12.07-C048-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “User-state preservation” cases for “User files and migration inventory size”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M12.07-C048-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “User-state preservation” limit; preserve “Upgrade cannot silently overwrite user edits or live data”.
- [ ] **UC-M12.07-C048-T06 · Normal measurement:** Run or review the normal “User-state preservation” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M12.07-C048-T07 · At-limit measurement:** Exercise the “User-state preservation” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M12.07-C048-T08 · Over-limit measurement:** Exercise the “User-state preservation” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M12.07-C048-T09 · Uncovered-scope report:** List the “User-state preservation” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M12.07-C048-T10 · Limit evidence:** Publish the selected “User-state preservation” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M12.07-C049 · Diagnostics / review

**Original checklist item:** Report user-state preservation results with executed, failed, skipped and unavailable cases separated; preserve the underlying observations and do not manufacture missing measurements.

- [ ] **UC-M12.07-C049-T01 · Result inventory:** Enumerate the required “User-state preservation” qualification cases and intended targets before aggregating results; keep the planned denominator visible.
- [ ] **UC-M12.07-C049-T02 · Verdict schema:** Define separate executed-pass, executed-fail, skipped, unavailable and untested outcomes for “User-state preservation”; document how incomplete cases block relevant claims.
- [ ] **UC-M12.07-C049-T03 · Identity fields:** Attach the actual target, fixture, configuration and revision identifiers to each “User-state preservation” result; do not attribute host-only evidence to a guest or another OS.
- [ ] **UC-M12.07-C049-T04 · Observation capture:** Capture bounded raw “User-state preservation” observations and harness errors; retain enough information to verify the reported oracle comparison.
- [ ] **UC-M12.07-C049-T05 · Aggregation rules:** Implement the “User-state preservation” count/reduction rule so failures and missing measurements cannot disappear; preserve “Upgrade cannot silently overwrite user edits or live data”.
- [ ] **UC-M12.07-C049-T06 · Failure visibility:** Feed a failing “User-state preservation” control through the report path; assert the exact failed case and underlying observation remain visible.
- [ ] **UC-M12.07-C049-T07 · Missing-result visibility:** Withhold a required “User-state preservation” measurement or target; verify the report uses unavailable/untested rather than a fabricated zero or passing value.
- [ ] **UC-M12.07-C049-T08 · Bounds and redaction:** Check “User-state preservation” report size and retention against “User files and migration inventory size”; remove secrets while retaining fixture and subject references.
- [ ] **UC-M12.07-C049-T09 · Report reconciliation:** Reconcile the “User-state preservation” summary with every underlying case record; account for the full planned denominator and all omitted scope.
- [ ] **UC-M12.07-C049-T10 · Qualification handoff:** Publish the “User-state preservation” report with measured observations, coverage limits and blockers; state which actual targets remain unqualified.

### UC-M12.07-C050 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for user-state preservation; label unexecuted checks as untested.

- [ ] **UC-M12.07-C050-T01 · Evidence inventory:** List the “User-state preservation” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M12.07-C050-T02 · Artifact references:** Record the exact “User-state preservation” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M12.07-C050-T03 · Fixture references:** Attach the “User-state preservation” fixture IDs, input identities and oracle definition; preserve the source counterexample “An update replaces a user-modified workspace with bundled defaults” as a distinct evidence case.
- [ ] **UC-M12.07-C050-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “User-state preservation”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M12.07-C050-T05 · Environment record:** Record the actual “User-state preservation” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M12.07-C050-T06 · Expected versus observed:** Pair every “User-state preservation” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M12.07-C050-T07 · Failure and limit records:** Attach “User-state preservation” change/failure and bounds evidence where required; include uncovered “User files and migration inventory size” and unresolved violations of “Upgrade cannot silently overwrite user edits or live data”.
- [ ] **UC-M12.07-C050-T08 · Evidence hygiene:** Check the “User-state preservation” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M12.07-C050-T09 · Reproduction review:** Have the “User-state preservation” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M12.07-C050-T10 · Acceptance linkage:** Link the “User-state preservation” evidence to its parent and UC-M12.07 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 06. Staged upgrade

**Source delivery:** Prepare and validate the complete new release before switching current authority.

**Source invariant:** Interrupted staging leaves the existing approved release usable.

**Source negative case:** The installer deletes the old runtime before validating the new payload.

**Source bounded quantities:** Staging bytes and upgrade duration.

### UC-M12.07-C051 · Contract

**Original checklist item:** Define the qualification objective for staged upgrade, including the actual target implementation, prerequisites, observable oracle and explicit exclusions.

- [ ] **UC-M12.07-C051-T01 · Scope statement:** Write the qualification question for “Staged upgrade”; identify the actual target, claimed capability and observations that can answer that question.
- [ ] **UC-M12.07-C051-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Staged upgrade”; record each producer, representation and missing-value meaning.
- [ ] **UC-M12.07-C051-T03 · Output inventory:** List the outputs of “Staged upgrade” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M12.07-C051-T04 · Field dictionary:** Create a field-and-term dictionary for “Staged upgrade”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M12.07-C051-T05 · Prerequisite contract:** Map “Staged upgrade” to the source component prerequisites (UC-M07.08, UC-M09.02, UC-M12.01); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M12.07-C051-T06 · Authority map:** Identify who may produce, change and consume “Staged upgrade”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M12.07-C051-T07 · Invariant clause:** Add a normative clause for “Staged upgrade” that preserves “Interrupted staging leaves the existing approved release usable”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M12.07-C051-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Staged upgrade”; include the source counterexample “The installer deletes the old runtime before validating the new payload” and the intended safe disposition.
- [ ] **UC-M12.07-C051-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Staging bytes and upgrade duration” in the “Staged upgrade” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M12.07-C051-T10 · Contract review:** Review the “Staged upgrade” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M12.07-C052 · Delivery

**Original checklist item:** Prepare and validate the complete new release before switching current authority.

- [ ] **UC-M12.07-C052-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Staged upgrade”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M12.07-C052-T02 · Change plan:** Break the source delivery for “Staged upgrade” into concrete edit targets and reviewable outputs; keep the UC-M12.07 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M12.07-C052-T03 · Core artifact:** Implement the smallest selected-profile change for “Staged upgrade” that realizes this source instruction: Prepare and validate the complete new release before switching current authority.
- [ ] **UC-M12.07-C052-T04 · Concrete realization:** Trace “Staged upgrade” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M12.07-C052-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Staged upgrade” needed to preserve “Interrupted staging leaves the existing approved release usable”; record an enforcement gap where only a model exists.
- [ ] **UC-M12.07-C052-T06 · Dependency connection:** Connect the “Staged upgrade” qualification artifact to authenticated packages, short-path launchers and user-state-preserving upgrade transactions; record the target identity and what the harness actually exercises.
- [ ] **UC-M12.07-C052-T07 · Resource behavior:** Account for “Staging bytes and upgrade duration” in “Staged upgrade”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M12.07-C052-T08 · Delivery check:** Run a known-valid control and a deliberately failing control for “Staged upgrade”; confirm the harness distinguishes their observed outcomes.
- [ ] **UC-M12.07-C052-T09 · Patch review:** Review the “Staged upgrade” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M12.07-C052-T10 · Delivery handoff:** Publish the “Staged upgrade” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M12.07-C053 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Interrupted staging leaves the existing approved release usable. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M12.07-C053-T01 · Named property:** Create a stable property/check name under this parent for “Staged upgrade”; copy its required invariant exactly: “Interrupted staging leaves the existing approved release usable”.
- [ ] **UC-M12.07-C053-T02 · Observable terms:** Define each term in the “Staged upgrade” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M12.07-C053-T03 · Precondition set:** List the preconditions under which “Interrupted staging leaves the existing approved release usable” must hold for “Staged upgrade”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M12.07-C053-T04 · Transition coverage:** Map the “Staged upgrade” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M12.07-C053-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Staged upgrade”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M12.07-C053-T06 · Satisfying fixture:** Create a concrete “Staged upgrade” case that satisfies “Interrupted staging leaves the existing approved release usable”; record its expected observation before running the assertion or review.
- [ ] **UC-M12.07-C053-T07 · Violating fixture:** Create the source counterexample “The installer deletes the old runtime before validating the new payload” for “Staged upgrade”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M12.07-C053-T08 · Enforcement evidence:** Exercise the “Staged upgrade” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M12.07-C053-T09 · Regression linkage:** Link the “Staged upgrade” property to changes in authenticated packages, short-path launchers and user-state-preserving upgrade transactions; record which dependency or contract changes require rerunning it.
- [ ] **UC-M12.07-C053-T10 · Property disposition:** Compare the satisfying and violating “Staged upgrade” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M12.07-C054 · Integration

**Original checklist item:** Integrate staged upgrade with authenticated packages, short-path launchers and user-state-preserving upgrade transactions; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M12.07-C054-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Staged upgrade” across authenticated packages, short-path launchers and user-state-preserving upgrade transactions; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M12.07-C054-T02 · Field mapping:** Map every “Staged upgrade” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M12.07-C054-T03 · Prerequisite identities:** Record the actual prerequisites for “Staged upgrade” (source dependency list: UC-M07.08, UC-M09.02, UC-M12.01); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M12.07-C054-T04 · Ownership agreement:** Specify who owns “Staged upgrade” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M12.07-C054-T05 · Handoff implementation:** Connect “Staged upgrade” through the mapped seam using the real adapter or explicit specification reference; preserve “Interrupted staging leaves the existing approved release usable” across the handoff.
- [ ] **UC-M12.07-C054-T06 · Absent-input case:** Omit one required “Staged upgrade” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M12.07-C054-T07 · Stale-input case:** Supply an outdated “Staged upgrade” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M12.07-C054-T08 · Incompatible-input case:** Supply an incompatible “Staged upgrade” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M12.07-C054-T09 · Valid integration trace:** Run a valid “Staged upgrade” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M12.07-C054-T10 · Seam review:** Reconcile the “Staged upgrade” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M12.07-C055 · Valid-case test

**Original checklist item:** Run a known-valid control for staged upgrade; verify that the harness reaches its intended target and compare observed measurements or verdicts with predeclared expectations.

- [ ] **UC-M12.07-C055-T01 · Valid fixture choice:** Choose a known-valid control for “Staged upgrade”; document why it should pass and how it proves the harness reaches the intended target.
- [ ] **UC-M12.07-C055-T02 · Expected-result oracle:** Specify the “Staged upgrade” expected result independently of the implementation output; include the property “Interrupted staging leaves the existing approved release usable” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M12.07-C055-T03 · Fixture material:** Create the concrete “Staged upgrade” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M12.07-C055-T04 · Target preparation:** Prepare the “Staged upgrade” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M12.07-C055-T05 · Initial-state record:** Record the initial “Staged upgrade” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M12.07-C055-T06 · Valid-path execution:** Run the “Staged upgrade” known-valid control on the identified target; retain enough observations to prove the correct target was exercised.
- [ ] **UC-M12.07-C055-T07 · Outcome comparison:** Compare every declared “Staged upgrade” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M12.07-C055-T08 · State and bounds check:** Inspect the “Staged upgrade” ownership/state effects and actual use of “Staging bytes and upgrade duration”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M12.07-C055-T09 · Repeatability check:** Repeat the same “Staged upgrade” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M12.07-C055-T10 · Positive evidence:** Attach the “Staged upgrade” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M12.07-C056 · Negative test

**Original checklist item:** Negative case: The installer deletes the old runtime before validating the new payload. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M12.07-C056-T01 · Adverse-case definition:** Create a test record for the exact “Staged upgrade” source counterexample: “The installer deletes the old runtime before validating the new payload”; state which precondition or invariant it challenges.
- [ ] **UC-M12.07-C056-T02 · Safe fixture boundary:** Define the contained test boundary for “Staged upgrade”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M12.07-C056-T03 · Valid control:** Construct a valid “Staged upgrade” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M12.07-C056-T04 · Minimal adverse input:** Derive the “Staged upgrade” adverse fixture from the control with the smallest documented change needed to reproduce “The installer deletes the old runtime before validating the new payload”; retain that change as reproducible data.
- [ ] **UC-M12.07-C056-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Staged upgrade”; require “Interrupted staging leaves the existing approved release usable” and forbid a false-success verdict.
- [ ] **UC-M12.07-C056-T06 · Adverse execution:** Exercise the “Staged upgrade” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M12.07-C056-T07 · Effect inspection:** Inspect “Staged upgrade” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M12.07-C056-T08 · Refusal versus failure:** Confirm the “Staged upgrade” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M12.07-C056-T09 · Reset and retention:** Restore only the disposable “Staged upgrade” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M12.07-C056-T10 · Negative regression:** Register the “Staged upgrade” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M12.07-C057 · Change / failure test

**Original checklist item:** Exercise staged upgrade when installation or upgrade is interrupted on a claimed native platform; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M12.07-C057-T01 · Scenario record:** Write the “Staged upgrade” change/failure scenario exactly as supplied: installation or upgrade is interrupted on a claimed native platform; identify the property that must remain true: “Interrupted staging leaves the existing approved release usable”.
- [ ] **UC-M12.07-C057-T02 · Baseline capture:** Create a known-valid “Staged upgrade” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M12.07-C057-T03 · Injection map:** Locate the “Staged upgrade” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M12.07-C057-T04 · Disposition oracle:** Define the legal intermediate and final “Staged upgrade” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M12.07-C057-T05 · Controlled trigger:** Introduce the controlled “Staged upgrade” scenario in the disposable fixture: installation or upgrade is interrupted on a claimed native platform; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M12.07-C057-T06 · Intermediate inspection:** Inspect the “Staged upgrade” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M12.07-C057-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Staged upgrade”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M12.07-C057-T08 · Stale-evidence cleanup:** Invalidate superseded “Staged upgrade” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M12.07-C057-T09 · Repeat and compare:** Repeat the selected “Staged upgrade” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M12.07-C057-T10 · Failure evidence:** Publish the “Staged upgrade” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M12.07-C058 · Bounds

**Original checklist item:** Set a documented campaign budget for staging bytes and upgrade duration; record actual consumption, incomplete coverage and the disposition when the budget is exhausted.

- [ ] **UC-M12.07-C058-T01 · Quantity inventory:** Create a measurement inventory for “Staged upgrade”: “Staging bytes and upgrade duration”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M12.07-C058-T02 · Measurement method:** Choose how to observe each “Staged upgrade” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M12.07-C058-T03 · Budget decision:** Select justified campaign and target-resource budgets for “Staged upgrade”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M12.07-C058-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Staged upgrade” cases for “Staging bytes and upgrade duration”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M12.07-C058-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Staged upgrade” limit; preserve “Interrupted staging leaves the existing approved release usable”.
- [ ] **UC-M12.07-C058-T06 · Normal measurement:** Run or review the normal “Staged upgrade” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M12.07-C058-T07 · At-limit measurement:** Exercise the “Staged upgrade” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M12.07-C058-T08 · Over-limit measurement:** Exercise the “Staged upgrade” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M12.07-C058-T09 · Uncovered-scope report:** List the “Staged upgrade” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M12.07-C058-T10 · Limit evidence:** Publish the selected “Staged upgrade” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M12.07-C059 · Diagnostics / review

**Original checklist item:** Report staged upgrade results with executed, failed, skipped and unavailable cases separated; preserve the underlying observations and do not manufacture missing measurements.

- [ ] **UC-M12.07-C059-T01 · Result inventory:** Enumerate the required “Staged upgrade” qualification cases and intended targets before aggregating results; keep the planned denominator visible.
- [ ] **UC-M12.07-C059-T02 · Verdict schema:** Define separate executed-pass, executed-fail, skipped, unavailable and untested outcomes for “Staged upgrade”; document how incomplete cases block relevant claims.
- [ ] **UC-M12.07-C059-T03 · Identity fields:** Attach the actual target, fixture, configuration and revision identifiers to each “Staged upgrade” result; do not attribute host-only evidence to a guest or another OS.
- [ ] **UC-M12.07-C059-T04 · Observation capture:** Capture bounded raw “Staged upgrade” observations and harness errors; retain enough information to verify the reported oracle comparison.
- [ ] **UC-M12.07-C059-T05 · Aggregation rules:** Implement the “Staged upgrade” count/reduction rule so failures and missing measurements cannot disappear; preserve “Interrupted staging leaves the existing approved release usable”.
- [ ] **UC-M12.07-C059-T06 · Failure visibility:** Feed a failing “Staged upgrade” control through the report path; assert the exact failed case and underlying observation remain visible.
- [ ] **UC-M12.07-C059-T07 · Missing-result visibility:** Withhold a required “Staged upgrade” measurement or target; verify the report uses unavailable/untested rather than a fabricated zero or passing value.
- [ ] **UC-M12.07-C059-T08 · Bounds and redaction:** Check “Staged upgrade” report size and retention against “Staging bytes and upgrade duration”; remove secrets while retaining fixture and subject references.
- [ ] **UC-M12.07-C059-T09 · Report reconciliation:** Reconcile the “Staged upgrade” summary with every underlying case record; account for the full planned denominator and all omitted scope.
- [ ] **UC-M12.07-C059-T10 · Qualification handoff:** Publish the “Staged upgrade” report with measured observations, coverage limits and blockers; state which actual targets remain unqualified.

### UC-M12.07-C060 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for staged upgrade; label unexecuted checks as untested.

- [ ] **UC-M12.07-C060-T01 · Evidence inventory:** List the “Staged upgrade” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M12.07-C060-T02 · Artifact references:** Record the exact “Staged upgrade” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M12.07-C060-T03 · Fixture references:** Attach the “Staged upgrade” fixture IDs, input identities and oracle definition; preserve the source counterexample “The installer deletes the old runtime before validating the new payload” as a distinct evidence case.
- [ ] **UC-M12.07-C060-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Staged upgrade”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M12.07-C060-T05 · Environment record:** Record the actual “Staged upgrade” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M12.07-C060-T06 · Expected versus observed:** Pair every “Staged upgrade” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M12.07-C060-T07 · Failure and limit records:** Attach “Staged upgrade” change/failure and bounds evidence where required; include uncovered “Staging bytes and upgrade duration” and unresolved violations of “Interrupted staging leaves the existing approved release usable”.
- [ ] **UC-M12.07-C060-T08 · Evidence hygiene:** Check the “Staged upgrade” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M12.07-C060-T09 · Reproduction review:** Have the “Staged upgrade” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M12.07-C060-T10 · Acceptance linkage:** Link the “Staged upgrade” evidence to its parent and UC-M12.07 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 07. Rollback plan

**Source delivery:** Retain an approved compatible recovery release and state relationship.

**Source invariant:** Rollback preserves trust policy and required state compatibility.

**Source negative case:** A failed update restores a revoked or incompatible old release.

**Source bounded quantities:** Retained releases and recovery bytes.

### UC-M12.07-C061 · Contract

**Original checklist item:** Define the qualification objective for rollback plan, including the actual target implementation, prerequisites, observable oracle and explicit exclusions.

- [ ] **UC-M12.07-C061-T01 · Scope statement:** Write the qualification question for “Rollback plan”; identify the actual target, claimed capability and observations that can answer that question.
- [ ] **UC-M12.07-C061-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Rollback plan”; record each producer, representation and missing-value meaning.
- [ ] **UC-M12.07-C061-T03 · Output inventory:** List the outputs of “Rollback plan” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M12.07-C061-T04 · Field dictionary:** Create a field-and-term dictionary for “Rollback plan”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M12.07-C061-T05 · Prerequisite contract:** Map “Rollback plan” to the source component prerequisites (UC-M07.08, UC-M09.02, UC-M12.01); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M12.07-C061-T06 · Authority map:** Identify who may produce, change and consume “Rollback plan”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M12.07-C061-T07 · Invariant clause:** Add a normative clause for “Rollback plan” that preserves “Rollback preserves trust policy and required state compatibility”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M12.07-C061-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Rollback plan”; include the source counterexample “A failed update restores a revoked or incompatible old release” and the intended safe disposition.
- [ ] **UC-M12.07-C061-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Retained releases and recovery bytes” in the “Rollback plan” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M12.07-C061-T10 · Contract review:** Review the “Rollback plan” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M12.07-C062 · Delivery

**Original checklist item:** Retain an approved compatible recovery release and state relationship.

- [ ] **UC-M12.07-C062-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Rollback plan”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M12.07-C062-T02 · Change plan:** Break the source delivery for “Rollback plan” into concrete edit targets and reviewable outputs; keep the UC-M12.07 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M12.07-C062-T03 · Core artifact:** Implement the smallest selected-profile change for “Rollback plan” that realizes this source instruction: Retain an approved compatible recovery release and state relationship.
- [ ] **UC-M12.07-C062-T04 · Concrete realization:** Trace “Rollback plan” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M12.07-C062-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Rollback plan” needed to preserve “Rollback preserves trust policy and required state compatibility”; record an enforcement gap where only a model exists.
- [ ] **UC-M12.07-C062-T06 · Dependency connection:** Connect the “Rollback plan” qualification artifact to authenticated packages, short-path launchers and user-state-preserving upgrade transactions; record the target identity and what the harness actually exercises.
- [ ] **UC-M12.07-C062-T07 · Resource behavior:** Account for “Retained releases and recovery bytes” in “Rollback plan”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M12.07-C062-T08 · Delivery check:** Run a known-valid control and a deliberately failing control for “Rollback plan”; confirm the harness distinguishes their observed outcomes.
- [ ] **UC-M12.07-C062-T09 · Patch review:** Review the “Rollback plan” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M12.07-C062-T10 · Delivery handoff:** Publish the “Rollback plan” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M12.07-C063 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Rollback preserves trust policy and required state compatibility. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M12.07-C063-T01 · Named property:** Create a stable property/check name under this parent for “Rollback plan”; copy its required invariant exactly: “Rollback preserves trust policy and required state compatibility”.
- [ ] **UC-M12.07-C063-T02 · Observable terms:** Define each term in the “Rollback plan” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M12.07-C063-T03 · Precondition set:** List the preconditions under which “Rollback preserves trust policy and required state compatibility” must hold for “Rollback plan”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M12.07-C063-T04 · Transition coverage:** Map the “Rollback plan” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M12.07-C063-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Rollback plan”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M12.07-C063-T06 · Satisfying fixture:** Create a concrete “Rollback plan” case that satisfies “Rollback preserves trust policy and required state compatibility”; record its expected observation before running the assertion or review.
- [ ] **UC-M12.07-C063-T07 · Violating fixture:** Create the source counterexample “A failed update restores a revoked or incompatible old release” for “Rollback plan”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M12.07-C063-T08 · Enforcement evidence:** Exercise the “Rollback plan” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M12.07-C063-T09 · Regression linkage:** Link the “Rollback plan” property to changes in authenticated packages, short-path launchers and user-state-preserving upgrade transactions; record which dependency or contract changes require rerunning it.
- [ ] **UC-M12.07-C063-T10 · Property disposition:** Compare the satisfying and violating “Rollback plan” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M12.07-C064 · Integration

**Original checklist item:** Integrate rollback plan with authenticated packages, short-path launchers and user-state-preserving upgrade transactions; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M12.07-C064-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Rollback plan” across authenticated packages, short-path launchers and user-state-preserving upgrade transactions; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M12.07-C064-T02 · Field mapping:** Map every “Rollback plan” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M12.07-C064-T03 · Prerequisite identities:** Record the actual prerequisites for “Rollback plan” (source dependency list: UC-M07.08, UC-M09.02, UC-M12.01); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M12.07-C064-T04 · Ownership agreement:** Specify who owns “Rollback plan” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M12.07-C064-T05 · Handoff implementation:** Connect “Rollback plan” through the mapped seam using the real adapter or explicit specification reference; preserve “Rollback preserves trust policy and required state compatibility” across the handoff.
- [ ] **UC-M12.07-C064-T06 · Absent-input case:** Omit one required “Rollback plan” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M12.07-C064-T07 · Stale-input case:** Supply an outdated “Rollback plan” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M12.07-C064-T08 · Incompatible-input case:** Supply an incompatible “Rollback plan” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M12.07-C064-T09 · Valid integration trace:** Run a valid “Rollback plan” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M12.07-C064-T10 · Seam review:** Reconcile the “Rollback plan” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M12.07-C065 · Valid-case test

**Original checklist item:** Run a known-valid control for rollback plan; verify that the harness reaches its intended target and compare observed measurements or verdicts with predeclared expectations.

- [ ] **UC-M12.07-C065-T01 · Valid fixture choice:** Choose a known-valid control for “Rollback plan”; document why it should pass and how it proves the harness reaches the intended target.
- [ ] **UC-M12.07-C065-T02 · Expected-result oracle:** Specify the “Rollback plan” expected result independently of the implementation output; include the property “Rollback preserves trust policy and required state compatibility” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M12.07-C065-T03 · Fixture material:** Create the concrete “Rollback plan” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M12.07-C065-T04 · Target preparation:** Prepare the “Rollback plan” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M12.07-C065-T05 · Initial-state record:** Record the initial “Rollback plan” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M12.07-C065-T06 · Valid-path execution:** Run the “Rollback plan” known-valid control on the identified target; retain enough observations to prove the correct target was exercised.
- [ ] **UC-M12.07-C065-T07 · Outcome comparison:** Compare every declared “Rollback plan” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M12.07-C065-T08 · State and bounds check:** Inspect the “Rollback plan” ownership/state effects and actual use of “Retained releases and recovery bytes”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M12.07-C065-T09 · Repeatability check:** Repeat the same “Rollback plan” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M12.07-C065-T10 · Positive evidence:** Attach the “Rollback plan” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M12.07-C066 · Negative test

**Original checklist item:** Negative case: A failed update restores a revoked or incompatible old release. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M12.07-C066-T01 · Adverse-case definition:** Create a test record for the exact “Rollback plan” source counterexample: “A failed update restores a revoked or incompatible old release”; state which precondition or invariant it challenges.
- [ ] **UC-M12.07-C066-T02 · Safe fixture boundary:** Define the contained test boundary for “Rollback plan”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M12.07-C066-T03 · Valid control:** Construct a valid “Rollback plan” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M12.07-C066-T04 · Minimal adverse input:** Derive the “Rollback plan” adverse fixture from the control with the smallest documented change needed to reproduce “A failed update restores a revoked or incompatible old release”; retain that change as reproducible data.
- [ ] **UC-M12.07-C066-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Rollback plan”; require “Rollback preserves trust policy and required state compatibility” and forbid a false-success verdict.
- [ ] **UC-M12.07-C066-T06 · Adverse execution:** Exercise the “Rollback plan” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M12.07-C066-T07 · Effect inspection:** Inspect “Rollback plan” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M12.07-C066-T08 · Refusal versus failure:** Confirm the “Rollback plan” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M12.07-C066-T09 · Reset and retention:** Restore only the disposable “Rollback plan” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M12.07-C066-T10 · Negative regression:** Register the “Rollback plan” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M12.07-C067 · Change / failure test

**Original checklist item:** Exercise rollback plan when installation or upgrade is interrupted on a claimed native platform; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M12.07-C067-T01 · Scenario record:** Write the “Rollback plan” change/failure scenario exactly as supplied: installation or upgrade is interrupted on a claimed native platform; identify the property that must remain true: “Rollback preserves trust policy and required state compatibility”.
- [ ] **UC-M12.07-C067-T02 · Baseline capture:** Create a known-valid “Rollback plan” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M12.07-C067-T03 · Injection map:** Locate the “Rollback plan” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M12.07-C067-T04 · Disposition oracle:** Define the legal intermediate and final “Rollback plan” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M12.07-C067-T05 · Controlled trigger:** Introduce the controlled “Rollback plan” scenario in the disposable fixture: installation or upgrade is interrupted on a claimed native platform; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M12.07-C067-T06 · Intermediate inspection:** Inspect the “Rollback plan” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M12.07-C067-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Rollback plan”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M12.07-C067-T08 · Stale-evidence cleanup:** Invalidate superseded “Rollback plan” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M12.07-C067-T09 · Repeat and compare:** Repeat the selected “Rollback plan” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M12.07-C067-T10 · Failure evidence:** Publish the “Rollback plan” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M12.07-C068 · Bounds

**Original checklist item:** Set a documented campaign budget for retained releases and recovery bytes; record actual consumption, incomplete coverage and the disposition when the budget is exhausted.

- [ ] **UC-M12.07-C068-T01 · Quantity inventory:** Create a measurement inventory for “Rollback plan”: “Retained releases and recovery bytes”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M12.07-C068-T02 · Measurement method:** Choose how to observe each “Rollback plan” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M12.07-C068-T03 · Budget decision:** Select justified campaign and target-resource budgets for “Rollback plan”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M12.07-C068-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Rollback plan” cases for “Retained releases and recovery bytes”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M12.07-C068-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Rollback plan” limit; preserve “Rollback preserves trust policy and required state compatibility”.
- [ ] **UC-M12.07-C068-T06 · Normal measurement:** Run or review the normal “Rollback plan” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M12.07-C068-T07 · At-limit measurement:** Exercise the “Rollback plan” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M12.07-C068-T08 · Over-limit measurement:** Exercise the “Rollback plan” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M12.07-C068-T09 · Uncovered-scope report:** List the “Rollback plan” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M12.07-C068-T10 · Limit evidence:** Publish the selected “Rollback plan” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M12.07-C069 · Diagnostics / review

**Original checklist item:** Report rollback plan results with executed, failed, skipped and unavailable cases separated; preserve the underlying observations and do not manufacture missing measurements.

- [ ] **UC-M12.07-C069-T01 · Result inventory:** Enumerate the required “Rollback plan” qualification cases and intended targets before aggregating results; keep the planned denominator visible.
- [ ] **UC-M12.07-C069-T02 · Verdict schema:** Define separate executed-pass, executed-fail, skipped, unavailable and untested outcomes for “Rollback plan”; document how incomplete cases block relevant claims.
- [ ] **UC-M12.07-C069-T03 · Identity fields:** Attach the actual target, fixture, configuration and revision identifiers to each “Rollback plan” result; do not attribute host-only evidence to a guest or another OS.
- [ ] **UC-M12.07-C069-T04 · Observation capture:** Capture bounded raw “Rollback plan” observations and harness errors; retain enough information to verify the reported oracle comparison.
- [ ] **UC-M12.07-C069-T05 · Aggregation rules:** Implement the “Rollback plan” count/reduction rule so failures and missing measurements cannot disappear; preserve “Rollback preserves trust policy and required state compatibility”.
- [ ] **UC-M12.07-C069-T06 · Failure visibility:** Feed a failing “Rollback plan” control through the report path; assert the exact failed case and underlying observation remain visible.
- [ ] **UC-M12.07-C069-T07 · Missing-result visibility:** Withhold a required “Rollback plan” measurement or target; verify the report uses unavailable/untested rather than a fabricated zero or passing value.
- [ ] **UC-M12.07-C069-T08 · Bounds and redaction:** Check “Rollback plan” report size and retention against “Retained releases and recovery bytes”; remove secrets while retaining fixture and subject references.
- [ ] **UC-M12.07-C069-T09 · Report reconciliation:** Reconcile the “Rollback plan” summary with every underlying case record; account for the full planned denominator and all omitted scope.
- [ ] **UC-M12.07-C069-T10 · Qualification handoff:** Publish the “Rollback plan” report with measured observations, coverage limits and blockers; state which actual targets remain unqualified.

### UC-M12.07-C070 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for rollback plan; label unexecuted checks as untested.

- [ ] **UC-M12.07-C070-T01 · Evidence inventory:** List the “Rollback plan” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M12.07-C070-T02 · Artifact references:** Record the exact “Rollback plan” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M12.07-C070-T03 · Fixture references:** Attach the “Rollback plan” fixture IDs, input identities and oracle definition; preserve the source counterexample “A failed update restores a revoked or incompatible old release” as a distinct evidence case.
- [ ] **UC-M12.07-C070-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Rollback plan”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M12.07-C070-T05 · Environment record:** Record the actual “Rollback plan” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M12.07-C070-T06 · Expected versus observed:** Pair every “Rollback plan” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M12.07-C070-T07 · Failure and limit records:** Attach “Rollback plan” change/failure and bounds evidence where required; include uncovered “Retained releases and recovery bytes” and unresolved violations of “Rollback preserves trust policy and required state compatibility”.
- [ ] **UC-M12.07-C070-T08 · Evidence hygiene:** Check the “Rollback plan” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M12.07-C070-T09 · Reproduction review:** Have the “Rollback plan” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M12.07-C070-T10 · Acceptance linkage:** Link the “Rollback plan” evidence to its parent and UC-M12.07 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 08. Interrupted-install recovery

**Source delivery:** Recover power loss or process termination at each installer commit boundary.

**Source invariant:** A partial installation cannot appear as a completed qualified release.

**Source negative case:** A version file updates while executable files remain mixed.

**Source bounded quantities:** Commit points and recovery time.

### UC-M12.07-C071 · Contract

**Original checklist item:** Define the qualification objective for interrupted-install recovery, including the actual target implementation, prerequisites, observable oracle and explicit exclusions.

- [ ] **UC-M12.07-C071-T01 · Scope statement:** Write the qualification question for “Interrupted-install recovery”; identify the actual target, claimed capability and observations that can answer that question.
- [ ] **UC-M12.07-C071-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Interrupted-install recovery”; record each producer, representation and missing-value meaning.
- [ ] **UC-M12.07-C071-T03 · Output inventory:** List the outputs of “Interrupted-install recovery” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M12.07-C071-T04 · Field dictionary:** Create a field-and-term dictionary for “Interrupted-install recovery”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M12.07-C071-T05 · Prerequisite contract:** Map “Interrupted-install recovery” to the source component prerequisites (UC-M07.08, UC-M09.02, UC-M12.01); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M12.07-C071-T06 · Authority map:** Identify who may produce, change and consume “Interrupted-install recovery”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M12.07-C071-T07 · Invariant clause:** Add a normative clause for “Interrupted-install recovery” that preserves “A partial installation cannot appear as a completed qualified release”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M12.07-C071-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Interrupted-install recovery”; include the source counterexample “A version file updates while executable files remain mixed” and the intended safe disposition.
- [ ] **UC-M12.07-C071-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Commit points and recovery time” in the “Interrupted-install recovery” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M12.07-C071-T10 · Contract review:** Review the “Interrupted-install recovery” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M12.07-C072 · Delivery

**Original checklist item:** Recover power loss or process termination at each installer commit boundary.

- [ ] **UC-M12.07-C072-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Interrupted-install recovery”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M12.07-C072-T02 · Change plan:** Break the source delivery for “Interrupted-install recovery” into concrete edit targets and reviewable outputs; keep the UC-M12.07 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M12.07-C072-T03 · Core artifact:** Implement the smallest selected-profile change for “Interrupted-install recovery” that realizes this source instruction: Recover power loss or process termination at each installer commit boundary.
- [ ] **UC-M12.07-C072-T04 · Concrete realization:** Trace “Interrupted-install recovery” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M12.07-C072-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Interrupted-install recovery” needed to preserve “A partial installation cannot appear as a completed qualified release”; record an enforcement gap where only a model exists.
- [ ] **UC-M12.07-C072-T06 · Dependency connection:** Connect the “Interrupted-install recovery” qualification artifact to authenticated packages, short-path launchers and user-state-preserving upgrade transactions; record the target identity and what the harness actually exercises.
- [ ] **UC-M12.07-C072-T07 · Resource behavior:** Account for “Commit points and recovery time” in “Interrupted-install recovery”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M12.07-C072-T08 · Delivery check:** Run a known-valid control and a deliberately failing control for “Interrupted-install recovery”; confirm the harness distinguishes their observed outcomes.
- [ ] **UC-M12.07-C072-T09 · Patch review:** Review the “Interrupted-install recovery” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M12.07-C072-T10 · Delivery handoff:** Publish the “Interrupted-install recovery” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M12.07-C073 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: A partial installation cannot appear as a completed qualified release. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M12.07-C073-T01 · Named property:** Create a stable property/check name under this parent for “Interrupted-install recovery”; copy its required invariant exactly: “A partial installation cannot appear as a completed qualified release”.
- [ ] **UC-M12.07-C073-T02 · Observable terms:** Define each term in the “Interrupted-install recovery” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M12.07-C073-T03 · Precondition set:** List the preconditions under which “A partial installation cannot appear as a completed qualified release” must hold for “Interrupted-install recovery”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M12.07-C073-T04 · Transition coverage:** Map the “Interrupted-install recovery” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M12.07-C073-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Interrupted-install recovery”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M12.07-C073-T06 · Satisfying fixture:** Create a concrete “Interrupted-install recovery” case that satisfies “A partial installation cannot appear as a completed qualified release”; record its expected observation before running the assertion or review.
- [ ] **UC-M12.07-C073-T07 · Violating fixture:** Create the source counterexample “A version file updates while executable files remain mixed” for “Interrupted-install recovery”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M12.07-C073-T08 · Enforcement evidence:** Exercise the “Interrupted-install recovery” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M12.07-C073-T09 · Regression linkage:** Link the “Interrupted-install recovery” property to changes in authenticated packages, short-path launchers and user-state-preserving upgrade transactions; record which dependency or contract changes require rerunning it.
- [ ] **UC-M12.07-C073-T10 · Property disposition:** Compare the satisfying and violating “Interrupted-install recovery” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M12.07-C074 · Integration

**Original checklist item:** Integrate interrupted-install recovery with authenticated packages, short-path launchers and user-state-preserving upgrade transactions; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M12.07-C074-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Interrupted-install recovery” across authenticated packages, short-path launchers and user-state-preserving upgrade transactions; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M12.07-C074-T02 · Field mapping:** Map every “Interrupted-install recovery” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M12.07-C074-T03 · Prerequisite identities:** Record the actual prerequisites for “Interrupted-install recovery” (source dependency list: UC-M07.08, UC-M09.02, UC-M12.01); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M12.07-C074-T04 · Ownership agreement:** Specify who owns “Interrupted-install recovery” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M12.07-C074-T05 · Handoff implementation:** Connect “Interrupted-install recovery” through the mapped seam using the real adapter or explicit specification reference; preserve “A partial installation cannot appear as a completed qualified release” across the handoff.
- [ ] **UC-M12.07-C074-T06 · Absent-input case:** Omit one required “Interrupted-install recovery” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M12.07-C074-T07 · Stale-input case:** Supply an outdated “Interrupted-install recovery” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M12.07-C074-T08 · Incompatible-input case:** Supply an incompatible “Interrupted-install recovery” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M12.07-C074-T09 · Valid integration trace:** Run a valid “Interrupted-install recovery” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M12.07-C074-T10 · Seam review:** Reconcile the “Interrupted-install recovery” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M12.07-C075 · Valid-case test

**Original checklist item:** Run a known-valid control for interrupted-install recovery; verify that the harness reaches its intended target and compare observed measurements or verdicts with predeclared expectations.

- [ ] **UC-M12.07-C075-T01 · Valid fixture choice:** Choose a known-valid control for “Interrupted-install recovery”; document why it should pass and how it proves the harness reaches the intended target.
- [ ] **UC-M12.07-C075-T02 · Expected-result oracle:** Specify the “Interrupted-install recovery” expected result independently of the implementation output; include the property “A partial installation cannot appear as a completed qualified release” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M12.07-C075-T03 · Fixture material:** Create the concrete “Interrupted-install recovery” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M12.07-C075-T04 · Target preparation:** Prepare the “Interrupted-install recovery” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M12.07-C075-T05 · Initial-state record:** Record the initial “Interrupted-install recovery” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M12.07-C075-T06 · Valid-path execution:** Run the “Interrupted-install recovery” known-valid control on the identified target; retain enough observations to prove the correct target was exercised.
- [ ] **UC-M12.07-C075-T07 · Outcome comparison:** Compare every declared “Interrupted-install recovery” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M12.07-C075-T08 · State and bounds check:** Inspect the “Interrupted-install recovery” ownership/state effects and actual use of “Commit points and recovery time”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M12.07-C075-T09 · Repeatability check:** Repeat the same “Interrupted-install recovery” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M12.07-C075-T10 · Positive evidence:** Attach the “Interrupted-install recovery” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M12.07-C076 · Negative test

**Original checklist item:** Negative case: A version file updates while executable files remain mixed. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M12.07-C076-T01 · Adverse-case definition:** Create a test record for the exact “Interrupted-install recovery” source counterexample: “A version file updates while executable files remain mixed”; state which precondition or invariant it challenges.
- [ ] **UC-M12.07-C076-T02 · Safe fixture boundary:** Define the contained test boundary for “Interrupted-install recovery”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M12.07-C076-T03 · Valid control:** Construct a valid “Interrupted-install recovery” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M12.07-C076-T04 · Minimal adverse input:** Derive the “Interrupted-install recovery” adverse fixture from the control with the smallest documented change needed to reproduce “A version file updates while executable files remain mixed”; retain that change as reproducible data.
- [ ] **UC-M12.07-C076-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Interrupted-install recovery”; require “A partial installation cannot appear as a completed qualified release” and forbid a false-success verdict.
- [ ] **UC-M12.07-C076-T06 · Adverse execution:** Exercise the “Interrupted-install recovery” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M12.07-C076-T07 · Effect inspection:** Inspect “Interrupted-install recovery” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M12.07-C076-T08 · Refusal versus failure:** Confirm the “Interrupted-install recovery” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M12.07-C076-T09 · Reset and retention:** Restore only the disposable “Interrupted-install recovery” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M12.07-C076-T10 · Negative regression:** Register the “Interrupted-install recovery” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M12.07-C077 · Change / failure test

**Original checklist item:** Exercise interrupted-install recovery when installation or upgrade is interrupted on a claimed native platform; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M12.07-C077-T01 · Scenario record:** Write the “Interrupted-install recovery” change/failure scenario exactly as supplied: installation or upgrade is interrupted on a claimed native platform; identify the property that must remain true: “A partial installation cannot appear as a completed qualified release”.
- [ ] **UC-M12.07-C077-T02 · Baseline capture:** Create a known-valid “Interrupted-install recovery” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M12.07-C077-T03 · Injection map:** Locate the “Interrupted-install recovery” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M12.07-C077-T04 · Disposition oracle:** Define the legal intermediate and final “Interrupted-install recovery” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M12.07-C077-T05 · Controlled trigger:** Introduce the controlled “Interrupted-install recovery” scenario in the disposable fixture: installation or upgrade is interrupted on a claimed native platform; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M12.07-C077-T06 · Intermediate inspection:** Inspect the “Interrupted-install recovery” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M12.07-C077-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Interrupted-install recovery”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M12.07-C077-T08 · Stale-evidence cleanup:** Invalidate superseded “Interrupted-install recovery” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M12.07-C077-T09 · Repeat and compare:** Repeat the selected “Interrupted-install recovery” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M12.07-C077-T10 · Failure evidence:** Publish the “Interrupted-install recovery” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M12.07-C078 · Bounds

**Original checklist item:** Set a documented campaign budget for commit points and recovery time; record actual consumption, incomplete coverage and the disposition when the budget is exhausted.

- [ ] **UC-M12.07-C078-T01 · Quantity inventory:** Create a measurement inventory for “Interrupted-install recovery”: “Commit points and recovery time”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M12.07-C078-T02 · Measurement method:** Choose how to observe each “Interrupted-install recovery” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M12.07-C078-T03 · Budget decision:** Select justified campaign and target-resource budgets for “Interrupted-install recovery”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M12.07-C078-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Interrupted-install recovery” cases for “Commit points and recovery time”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M12.07-C078-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Interrupted-install recovery” limit; preserve “A partial installation cannot appear as a completed qualified release”.
- [ ] **UC-M12.07-C078-T06 · Normal measurement:** Run or review the normal “Interrupted-install recovery” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M12.07-C078-T07 · At-limit measurement:** Exercise the “Interrupted-install recovery” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M12.07-C078-T08 · Over-limit measurement:** Exercise the “Interrupted-install recovery” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M12.07-C078-T09 · Uncovered-scope report:** List the “Interrupted-install recovery” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M12.07-C078-T10 · Limit evidence:** Publish the selected “Interrupted-install recovery” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M12.07-C079 · Diagnostics / review

**Original checklist item:** Report interrupted-install recovery results with executed, failed, skipped and unavailable cases separated; preserve the underlying observations and do not manufacture missing measurements.

- [ ] **UC-M12.07-C079-T01 · Result inventory:** Enumerate the required “Interrupted-install recovery” qualification cases and intended targets before aggregating results; keep the planned denominator visible.
- [ ] **UC-M12.07-C079-T02 · Verdict schema:** Define separate executed-pass, executed-fail, skipped, unavailable and untested outcomes for “Interrupted-install recovery”; document how incomplete cases block relevant claims.
- [ ] **UC-M12.07-C079-T03 · Identity fields:** Attach the actual target, fixture, configuration and revision identifiers to each “Interrupted-install recovery” result; do not attribute host-only evidence to a guest or another OS.
- [ ] **UC-M12.07-C079-T04 · Observation capture:** Capture bounded raw “Interrupted-install recovery” observations and harness errors; retain enough information to verify the reported oracle comparison.
- [ ] **UC-M12.07-C079-T05 · Aggregation rules:** Implement the “Interrupted-install recovery” count/reduction rule so failures and missing measurements cannot disappear; preserve “A partial installation cannot appear as a completed qualified release”.
- [ ] **UC-M12.07-C079-T06 · Failure visibility:** Feed a failing “Interrupted-install recovery” control through the report path; assert the exact failed case and underlying observation remain visible.
- [ ] **UC-M12.07-C079-T07 · Missing-result visibility:** Withhold a required “Interrupted-install recovery” measurement or target; verify the report uses unavailable/untested rather than a fabricated zero or passing value.
- [ ] **UC-M12.07-C079-T08 · Bounds and redaction:** Check “Interrupted-install recovery” report size and retention against “Commit points and recovery time”; remove secrets while retaining fixture and subject references.
- [ ] **UC-M12.07-C079-T09 · Report reconciliation:** Reconcile the “Interrupted-install recovery” summary with every underlying case record; account for the full planned denominator and all omitted scope.
- [ ] **UC-M12.07-C079-T10 · Qualification handoff:** Publish the “Interrupted-install recovery” report with measured observations, coverage limits and blockers; state which actual targets remain unqualified.

### UC-M12.07-C080 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for interrupted-install recovery; label unexecuted checks as untested.

- [ ] **UC-M12.07-C080-T01 · Evidence inventory:** List the “Interrupted-install recovery” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M12.07-C080-T02 · Artifact references:** Record the exact “Interrupted-install recovery” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M12.07-C080-T03 · Fixture references:** Attach the “Interrupted-install recovery” fixture IDs, input identities and oracle definition; preserve the source counterexample “A version file updates while executable files remain mixed” as a distinct evidence case.
- [ ] **UC-M12.07-C080-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Interrupted-install recovery”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M12.07-C080-T05 · Environment record:** Record the actual “Interrupted-install recovery” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M12.07-C080-T06 · Expected versus observed:** Pair every “Interrupted-install recovery” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M12.07-C080-T07 · Failure and limit records:** Attach “Interrupted-install recovery” change/failure and bounds evidence where required; include uncovered “Commit points and recovery time” and unresolved violations of “A partial installation cannot appear as a completed qualified release”.
- [ ] **UC-M12.07-C080-T08 · Evidence hygiene:** Check the “Interrupted-install recovery” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M12.07-C080-T09 · Reproduction review:** Have the “Interrupted-install recovery” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M12.07-C080-T10 · Acceptance linkage:** Link the “Interrupted-install recovery” evidence to its parent and UC-M12.07 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 09. Native platform trials

**Source delivery:** Run clean install and interrupted upgrade on each claimed native OS.

**Source invariant:** Static launcher review does not count as native installer execution.

**Source negative case:** Only a Linux extraction test is used to claim Windows installation support.

**Source bounded quantities:** Platform profiles and test repetitions.

### UC-M12.07-C081 · Contract

**Original checklist item:** Define the qualification objective for native platform trials, including the actual target implementation, prerequisites, observable oracle and explicit exclusions.

- [ ] **UC-M12.07-C081-T01 · Scope statement:** Write the qualification question for “Native platform trials”; identify the actual target, claimed capability and observations that can answer that question.
- [ ] **UC-M12.07-C081-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Native platform trials”; record each producer, representation and missing-value meaning.
- [ ] **UC-M12.07-C081-T03 · Output inventory:** List the outputs of “Native platform trials” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M12.07-C081-T04 · Field dictionary:** Create a field-and-term dictionary for “Native platform trials”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M12.07-C081-T05 · Prerequisite contract:** Map “Native platform trials” to the source component prerequisites (UC-M07.08, UC-M09.02, UC-M12.01); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M12.07-C081-T06 · Authority map:** Identify who may produce, change and consume “Native platform trials”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M12.07-C081-T07 · Invariant clause:** Add a normative clause for “Native platform trials” that preserves “Static launcher review does not count as native installer execution”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M12.07-C081-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Native platform trials”; include the source counterexample “Only a Linux extraction test is used to claim Windows installation support” and the intended safe disposition.
- [ ] **UC-M12.07-C081-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Platform profiles and test repetitions” in the “Native platform trials” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M12.07-C081-T10 · Contract review:** Review the “Native platform trials” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M12.07-C082 · Delivery

**Original checklist item:** Run clean install and interrupted upgrade on each claimed native OS.

- [ ] **UC-M12.07-C082-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Native platform trials”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M12.07-C082-T02 · Change plan:** Break the source delivery for “Native platform trials” into concrete edit targets and reviewable outputs; keep the UC-M12.07 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M12.07-C082-T03 · Core artifact:** Create the “Native platform trials” fixture or harness for this source instruction: Run clean install and interrupted upgrade on each claimed native OS.
- [ ] **UC-M12.07-C082-T04 · Concrete realization:** Connect the “Native platform trials” harness to its actual intended target, set the expected oracle before running it, and distinguish a mock/control run from a target run.
- [ ] **UC-M12.07-C082-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Native platform trials” needed to preserve “Static launcher review does not count as native installer execution”; record an enforcement gap where only a model exists.
- [ ] **UC-M12.07-C082-T06 · Dependency connection:** Connect the “Native platform trials” qualification artifact to authenticated packages, short-path launchers and user-state-preserving upgrade transactions; record the target identity and what the harness actually exercises.
- [ ] **UC-M12.07-C082-T07 · Resource behavior:** Account for “Platform profiles and test repetitions” in “Native platform trials”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M12.07-C082-T08 · Delivery check:** Run a known-valid control and a deliberately failing control for “Native platform trials”; confirm the harness distinguishes their observed outcomes.
- [ ] **UC-M12.07-C082-T09 · Patch review:** Review the “Native platform trials” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M12.07-C082-T10 · Delivery handoff:** Publish the “Native platform trials” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M12.07-C083 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Static launcher review does not count as native installer execution. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M12.07-C083-T01 · Named property:** Create a stable property/check name under this parent for “Native platform trials”; copy its required invariant exactly: “Static launcher review does not count as native installer execution”.
- [ ] **UC-M12.07-C083-T02 · Observable terms:** Define each term in the “Native platform trials” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M12.07-C083-T03 · Precondition set:** List the preconditions under which “Static launcher review does not count as native installer execution” must hold for “Native platform trials”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M12.07-C083-T04 · Transition coverage:** Map the “Native platform trials” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M12.07-C083-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Native platform trials”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M12.07-C083-T06 · Satisfying fixture:** Create a concrete “Native platform trials” case that satisfies “Static launcher review does not count as native installer execution”; record its expected observation before running the assertion or review.
- [ ] **UC-M12.07-C083-T07 · Violating fixture:** Create the source counterexample “Only a Linux extraction test is used to claim Windows installation support” for “Native platform trials”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M12.07-C083-T08 · Enforcement evidence:** Exercise the “Native platform trials” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M12.07-C083-T09 · Regression linkage:** Link the “Native platform trials” property to changes in authenticated packages, short-path launchers and user-state-preserving upgrade transactions; record which dependency or contract changes require rerunning it.
- [ ] **UC-M12.07-C083-T10 · Property disposition:** Compare the satisfying and violating “Native platform trials” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M12.07-C084 · Integration

**Original checklist item:** Integrate native platform trials with authenticated packages, short-path launchers and user-state-preserving upgrade transactions; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M12.07-C084-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Native platform trials” across authenticated packages, short-path launchers and user-state-preserving upgrade transactions; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M12.07-C084-T02 · Field mapping:** Map every “Native platform trials” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M12.07-C084-T03 · Prerequisite identities:** Record the actual prerequisites for “Native platform trials” (source dependency list: UC-M07.08, UC-M09.02, UC-M12.01); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M12.07-C084-T04 · Ownership agreement:** Specify who owns “Native platform trials” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M12.07-C084-T05 · Handoff implementation:** Connect “Native platform trials” through the mapped seam using the real adapter or explicit specification reference; preserve “Static launcher review does not count as native installer execution” across the handoff.
- [ ] **UC-M12.07-C084-T06 · Absent-input case:** Omit one required “Native platform trials” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M12.07-C084-T07 · Stale-input case:** Supply an outdated “Native platform trials” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M12.07-C084-T08 · Incompatible-input case:** Supply an incompatible “Native platform trials” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M12.07-C084-T09 · Valid integration trace:** Run a valid “Native platform trials” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M12.07-C084-T10 · Seam review:** Reconcile the “Native platform trials” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M12.07-C085 · Valid-case test

**Original checklist item:** Run a known-valid control for native platform trials; verify that the harness reaches its intended target and compare observed measurements or verdicts with predeclared expectations.

- [ ] **UC-M12.07-C085-T01 · Valid fixture choice:** Choose a known-valid control for “Native platform trials”; document why it should pass and how it proves the harness reaches the intended target.
- [ ] **UC-M12.07-C085-T02 · Expected-result oracle:** Specify the “Native platform trials” expected result independently of the implementation output; include the property “Static launcher review does not count as native installer execution” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M12.07-C085-T03 · Fixture material:** Create the concrete “Native platform trials” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M12.07-C085-T04 · Target preparation:** Prepare the “Native platform trials” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M12.07-C085-T05 · Initial-state record:** Record the initial “Native platform trials” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M12.07-C085-T06 · Valid-path execution:** Run the “Native platform trials” known-valid control on the identified target; retain enough observations to prove the correct target was exercised.
- [ ] **UC-M12.07-C085-T07 · Outcome comparison:** Compare every declared “Native platform trials” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M12.07-C085-T08 · State and bounds check:** Inspect the “Native platform trials” ownership/state effects and actual use of “Platform profiles and test repetitions”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M12.07-C085-T09 · Repeatability check:** Repeat the same “Native platform trials” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M12.07-C085-T10 · Positive evidence:** Attach the “Native platform trials” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M12.07-C086 · Negative test

**Original checklist item:** Negative case: Only a Linux extraction test is used to claim Windows installation support. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M12.07-C086-T01 · Adverse-case definition:** Create a test record for the exact “Native platform trials” source counterexample: “Only a Linux extraction test is used to claim Windows installation support”; state which precondition or invariant it challenges.
- [ ] **UC-M12.07-C086-T02 · Safe fixture boundary:** Define the contained test boundary for “Native platform trials”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M12.07-C086-T03 · Valid control:** Construct a valid “Native platform trials” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M12.07-C086-T04 · Minimal adverse input:** Derive the “Native platform trials” adverse fixture from the control with the smallest documented change needed to reproduce “Only a Linux extraction test is used to claim Windows installation support”; retain that change as reproducible data.
- [ ] **UC-M12.07-C086-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Native platform trials”; require “Static launcher review does not count as native installer execution” and forbid a false-success verdict.
- [ ] **UC-M12.07-C086-T06 · Adverse execution:** Exercise the “Native platform trials” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M12.07-C086-T07 · Effect inspection:** Inspect “Native platform trials” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M12.07-C086-T08 · Refusal versus failure:** Confirm the “Native platform trials” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M12.07-C086-T09 · Reset and retention:** Restore only the disposable “Native platform trials” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M12.07-C086-T10 · Negative regression:** Register the “Native platform trials” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M12.07-C087 · Change / failure test

**Original checklist item:** Exercise native platform trials when installation or upgrade is interrupted on a claimed native platform; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M12.07-C087-T01 · Scenario record:** Write the “Native platform trials” change/failure scenario exactly as supplied: installation or upgrade is interrupted on a claimed native platform; identify the property that must remain true: “Static launcher review does not count as native installer execution”.
- [ ] **UC-M12.07-C087-T02 · Baseline capture:** Create a known-valid “Native platform trials” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M12.07-C087-T03 · Injection map:** Locate the “Native platform trials” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M12.07-C087-T04 · Disposition oracle:** Define the legal intermediate and final “Native platform trials” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M12.07-C087-T05 · Controlled trigger:** Introduce the controlled “Native platform trials” scenario in the disposable fixture: installation or upgrade is interrupted on a claimed native platform; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M12.07-C087-T06 · Intermediate inspection:** Inspect the “Native platform trials” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M12.07-C087-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Native platform trials”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M12.07-C087-T08 · Stale-evidence cleanup:** Invalidate superseded “Native platform trials” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M12.07-C087-T09 · Repeat and compare:** Repeat the selected “Native platform trials” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M12.07-C087-T10 · Failure evidence:** Publish the “Native platform trials” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M12.07-C088 · Bounds

**Original checklist item:** Set a documented campaign budget for platform profiles and test repetitions; record actual consumption, incomplete coverage and the disposition when the budget is exhausted.

- [ ] **UC-M12.07-C088-T01 · Quantity inventory:** Create a measurement inventory for “Native platform trials”: “Platform profiles and test repetitions”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M12.07-C088-T02 · Measurement method:** Choose how to observe each “Native platform trials” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M12.07-C088-T03 · Budget decision:** Select justified campaign and target-resource budgets for “Native platform trials”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M12.07-C088-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Native platform trials” cases for “Platform profiles and test repetitions”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M12.07-C088-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Native platform trials” limit; preserve “Static launcher review does not count as native installer execution”.
- [ ] **UC-M12.07-C088-T06 · Normal measurement:** Run or review the normal “Native platform trials” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M12.07-C088-T07 · At-limit measurement:** Exercise the “Native platform trials” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M12.07-C088-T08 · Over-limit measurement:** Exercise the “Native platform trials” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M12.07-C088-T09 · Uncovered-scope report:** List the “Native platform trials” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M12.07-C088-T10 · Limit evidence:** Publish the selected “Native platform trials” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M12.07-C089 · Diagnostics / review

**Original checklist item:** Report native platform trials results with executed, failed, skipped and unavailable cases separated; preserve the underlying observations and do not manufacture missing measurements.

- [ ] **UC-M12.07-C089-T01 · Result inventory:** Enumerate the required “Native platform trials” qualification cases and intended targets before aggregating results; keep the planned denominator visible.
- [ ] **UC-M12.07-C089-T02 · Verdict schema:** Define separate executed-pass, executed-fail, skipped, unavailable and untested outcomes for “Native platform trials”; document how incomplete cases block relevant claims.
- [ ] **UC-M12.07-C089-T03 · Identity fields:** Attach the actual target, fixture, configuration and revision identifiers to each “Native platform trials” result; do not attribute host-only evidence to a guest or another OS.
- [ ] **UC-M12.07-C089-T04 · Observation capture:** Capture bounded raw “Native platform trials” observations and harness errors; retain enough information to verify the reported oracle comparison.
- [ ] **UC-M12.07-C089-T05 · Aggregation rules:** Implement the “Native platform trials” count/reduction rule so failures and missing measurements cannot disappear; preserve “Static launcher review does not count as native installer execution”.
- [ ] **UC-M12.07-C089-T06 · Failure visibility:** Feed a failing “Native platform trials” control through the report path; assert the exact failed case and underlying observation remain visible.
- [ ] **UC-M12.07-C089-T07 · Missing-result visibility:** Withhold a required “Native platform trials” measurement or target; verify the report uses unavailable/untested rather than a fabricated zero or passing value.
- [ ] **UC-M12.07-C089-T08 · Bounds and redaction:** Check “Native platform trials” report size and retention against “Platform profiles and test repetitions”; remove secrets while retaining fixture and subject references.
- [ ] **UC-M12.07-C089-T09 · Report reconciliation:** Reconcile the “Native platform trials” summary with every underlying case record; account for the full planned denominator and all omitted scope.
- [ ] **UC-M12.07-C089-T10 · Qualification handoff:** Publish the “Native platform trials” report with measured observations, coverage limits and blockers; state which actual targets remain unqualified.

### UC-M12.07-C090 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for native platform trials; label unexecuted checks as untested.

- [ ] **UC-M12.07-C090-T01 · Evidence inventory:** List the “Native platform trials” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M12.07-C090-T02 · Artifact references:** Record the exact “Native platform trials” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M12.07-C090-T03 · Fixture references:** Attach the “Native platform trials” fixture IDs, input identities and oracle definition; preserve the source counterexample “Only a Linux extraction test is used to claim Windows installation support” as a distinct evidence case.
- [ ] **UC-M12.07-C090-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Native platform trials”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M12.07-C090-T05 · Environment record:** Record the actual “Native platform trials” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M12.07-C090-T06 · Expected versus observed:** Pair every “Native platform trials” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M12.07-C090-T07 · Failure and limit records:** Attach “Native platform trials” change/failure and bounds evidence where required; include uncovered “Platform profiles and test repetitions” and unresolved violations of “Static launcher review does not count as native installer execution”.
- [ ] **UC-M12.07-C090-T08 · Evidence hygiene:** Check the “Native platform trials” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M12.07-C090-T09 · Reproduction review:** Have the “Native platform trials” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M12.07-C090-T10 · Acceptance linkage:** Link the “Native platform trials” evidence to its parent and UC-M12.07 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 10. Installer release evidence

**Source delivery:** Publish observed results, prerequisite limits and user-state preservation checks.

**Source invariant:** Installer success is backed by actual install/upgrade outcomes.

**Source negative case:** A packaged updater is described as tested without running it.

**Source bounded quantities:** Evidence bytes and required acceptance cases.

### UC-M12.07-C091 · Contract

**Original checklist item:** Define the qualification objective for installer release evidence, including the actual target implementation, prerequisites, observable oracle and explicit exclusions.

- [ ] **UC-M12.07-C091-T01 · Scope statement:** Write the qualification question for “Installer release evidence”; identify the actual target, claimed capability and observations that can answer that question.
- [ ] **UC-M12.07-C091-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Installer release evidence”; record each producer, representation and missing-value meaning.
- [ ] **UC-M12.07-C091-T03 · Output inventory:** List the outputs of “Installer release evidence” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M12.07-C091-T04 · Field dictionary:** Create a field-and-term dictionary for “Installer release evidence”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M12.07-C091-T05 · Prerequisite contract:** Map “Installer release evidence” to the source component prerequisites (UC-M07.08, UC-M09.02, UC-M12.01); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M12.07-C091-T06 · Authority map:** Identify who may produce, change and consume “Installer release evidence”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M12.07-C091-T07 · Invariant clause:** Add a normative clause for “Installer release evidence” that preserves “Installer success is backed by actual install/upgrade outcomes”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M12.07-C091-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Installer release evidence”; include the source counterexample “A packaged updater is described as tested without running it” and the intended safe disposition.
- [ ] **UC-M12.07-C091-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Evidence bytes and required acceptance cases” in the “Installer release evidence” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M12.07-C091-T10 · Contract review:** Review the “Installer release evidence” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M12.07-C092 · Delivery

**Original checklist item:** Publish observed results, prerequisite limits and user-state preservation checks.

- [ ] **UC-M12.07-C092-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Installer release evidence”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M12.07-C092-T02 · Change plan:** Break the source delivery for “Installer release evidence” into concrete edit targets and reviewable outputs; keep the UC-M12.07 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M12.07-C092-T03 · Core artifact:** Create the “Installer release evidence” output artifact for this source instruction: Publish observed results, prerequisite limits and user-state preservation checks.
- [ ] **UC-M12.07-C092-T04 · Concrete realization:** Populate the “Installer release evidence” artifact from identified observations; keep unknown, failed and unexecuted results distinct and exclude unapproved sensitive material.
- [ ] **UC-M12.07-C092-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Installer release evidence” needed to preserve “Installer success is backed by actual install/upgrade outcomes”; record an enforcement gap where only a model exists.
- [ ] **UC-M12.07-C092-T06 · Dependency connection:** Connect the “Installer release evidence” qualification artifact to authenticated packages, short-path launchers and user-state-preserving upgrade transactions; record the target identity and what the harness actually exercises.
- [ ] **UC-M12.07-C092-T07 · Resource behavior:** Account for “Evidence bytes and required acceptance cases” in “Installer release evidence”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M12.07-C092-T08 · Delivery check:** Run a known-valid control and a deliberately failing control for “Installer release evidence”; confirm the harness distinguishes their observed outcomes.
- [ ] **UC-M12.07-C092-T09 · Patch review:** Review the “Installer release evidence” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M12.07-C092-T10 · Delivery handoff:** Publish the “Installer release evidence” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M12.07-C093 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Installer success is backed by actual install/upgrade outcomes. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M12.07-C093-T01 · Named property:** Create a stable property/check name under this parent for “Installer release evidence”; copy its required invariant exactly: “Installer success is backed by actual install/upgrade outcomes”.
- [ ] **UC-M12.07-C093-T02 · Observable terms:** Define each term in the “Installer release evidence” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M12.07-C093-T03 · Precondition set:** List the preconditions under which “Installer success is backed by actual install/upgrade outcomes” must hold for “Installer release evidence”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M12.07-C093-T04 · Transition coverage:** Map the “Installer release evidence” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M12.07-C093-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Installer release evidence”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M12.07-C093-T06 · Satisfying fixture:** Create a concrete “Installer release evidence” case that satisfies “Installer success is backed by actual install/upgrade outcomes”; record its expected observation before running the assertion or review.
- [ ] **UC-M12.07-C093-T07 · Violating fixture:** Create the source counterexample “A packaged updater is described as tested without running it” for “Installer release evidence”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M12.07-C093-T08 · Enforcement evidence:** Exercise the “Installer release evidence” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M12.07-C093-T09 · Regression linkage:** Link the “Installer release evidence” property to changes in authenticated packages, short-path launchers and user-state-preserving upgrade transactions; record which dependency or contract changes require rerunning it.
- [ ] **UC-M12.07-C093-T10 · Property disposition:** Compare the satisfying and violating “Installer release evidence” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M12.07-C094 · Integration

**Original checklist item:** Integrate installer release evidence with authenticated packages, short-path launchers and user-state-preserving upgrade transactions; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M12.07-C094-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Installer release evidence” across authenticated packages, short-path launchers and user-state-preserving upgrade transactions; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M12.07-C094-T02 · Field mapping:** Map every “Installer release evidence” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M12.07-C094-T03 · Prerequisite identities:** Record the actual prerequisites for “Installer release evidence” (source dependency list: UC-M07.08, UC-M09.02, UC-M12.01); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M12.07-C094-T04 · Ownership agreement:** Specify who owns “Installer release evidence” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M12.07-C094-T05 · Handoff implementation:** Connect “Installer release evidence” through the mapped seam using the real adapter or explicit specification reference; preserve “Installer success is backed by actual install/upgrade outcomes” across the handoff.
- [ ] **UC-M12.07-C094-T06 · Absent-input case:** Omit one required “Installer release evidence” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M12.07-C094-T07 · Stale-input case:** Supply an outdated “Installer release evidence” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M12.07-C094-T08 · Incompatible-input case:** Supply an incompatible “Installer release evidence” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M12.07-C094-T09 · Valid integration trace:** Run a valid “Installer release evidence” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M12.07-C094-T10 · Seam review:** Reconcile the “Installer release evidence” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M12.07-C095 · Valid-case test

**Original checklist item:** Run a known-valid control for installer release evidence; verify that the harness reaches its intended target and compare observed measurements or verdicts with predeclared expectations.

- [ ] **UC-M12.07-C095-T01 · Valid fixture choice:** Choose a known-valid control for “Installer release evidence”; document why it should pass and how it proves the harness reaches the intended target.
- [ ] **UC-M12.07-C095-T02 · Expected-result oracle:** Specify the “Installer release evidence” expected result independently of the implementation output; include the property “Installer success is backed by actual install/upgrade outcomes” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M12.07-C095-T03 · Fixture material:** Create the concrete “Installer release evidence” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M12.07-C095-T04 · Target preparation:** Prepare the “Installer release evidence” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M12.07-C095-T05 · Initial-state record:** Record the initial “Installer release evidence” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M12.07-C095-T06 · Valid-path execution:** Run the “Installer release evidence” known-valid control on the identified target; retain enough observations to prove the correct target was exercised.
- [ ] **UC-M12.07-C095-T07 · Outcome comparison:** Compare every declared “Installer release evidence” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M12.07-C095-T08 · State and bounds check:** Inspect the “Installer release evidence” ownership/state effects and actual use of “Evidence bytes and required acceptance cases”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M12.07-C095-T09 · Repeatability check:** Repeat the same “Installer release evidence” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M12.07-C095-T10 · Positive evidence:** Attach the “Installer release evidence” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M12.07-C096 · Negative test

**Original checklist item:** Negative case: A packaged updater is described as tested without running it. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M12.07-C096-T01 · Adverse-case definition:** Create a test record for the exact “Installer release evidence” source counterexample: “A packaged updater is described as tested without running it”; state which precondition or invariant it challenges.
- [ ] **UC-M12.07-C096-T02 · Safe fixture boundary:** Define the contained test boundary for “Installer release evidence”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M12.07-C096-T03 · Valid control:** Construct a valid “Installer release evidence” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M12.07-C096-T04 · Minimal adverse input:** Derive the “Installer release evidence” adverse fixture from the control with the smallest documented change needed to reproduce “A packaged updater is described as tested without running it”; retain that change as reproducible data.
- [ ] **UC-M12.07-C096-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Installer release evidence”; require “Installer success is backed by actual install/upgrade outcomes” and forbid a false-success verdict.
- [ ] **UC-M12.07-C096-T06 · Adverse execution:** Exercise the “Installer release evidence” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M12.07-C096-T07 · Effect inspection:** Inspect “Installer release evidence” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M12.07-C096-T08 · Refusal versus failure:** Confirm the “Installer release evidence” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M12.07-C096-T09 · Reset and retention:** Restore only the disposable “Installer release evidence” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M12.07-C096-T10 · Negative regression:** Register the “Installer release evidence” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M12.07-C097 · Change / failure test

**Original checklist item:** Exercise installer release evidence when installation or upgrade is interrupted on a claimed native platform; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M12.07-C097-T01 · Scenario record:** Write the “Installer release evidence” change/failure scenario exactly as supplied: installation or upgrade is interrupted on a claimed native platform; identify the property that must remain true: “Installer success is backed by actual install/upgrade outcomes”.
- [ ] **UC-M12.07-C097-T02 · Baseline capture:** Create a known-valid “Installer release evidence” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M12.07-C097-T03 · Injection map:** Locate the “Installer release evidence” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M12.07-C097-T04 · Disposition oracle:** Define the legal intermediate and final “Installer release evidence” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M12.07-C097-T05 · Controlled trigger:** Introduce the controlled “Installer release evidence” scenario in the disposable fixture: installation or upgrade is interrupted on a claimed native platform; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M12.07-C097-T06 · Intermediate inspection:** Inspect the “Installer release evidence” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M12.07-C097-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Installer release evidence”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M12.07-C097-T08 · Stale-evidence cleanup:** Invalidate superseded “Installer release evidence” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M12.07-C097-T09 · Repeat and compare:** Repeat the selected “Installer release evidence” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M12.07-C097-T10 · Failure evidence:** Publish the “Installer release evidence” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M12.07-C098 · Bounds

**Original checklist item:** Set a documented campaign budget for evidence bytes and required acceptance cases; record actual consumption, incomplete coverage and the disposition when the budget is exhausted.

- [ ] **UC-M12.07-C098-T01 · Quantity inventory:** Create a measurement inventory for “Installer release evidence”: “Evidence bytes and required acceptance cases”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M12.07-C098-T02 · Measurement method:** Choose how to observe each “Installer release evidence” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M12.07-C098-T03 · Budget decision:** Select justified campaign and target-resource budgets for “Installer release evidence”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M12.07-C098-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Installer release evidence” cases for “Evidence bytes and required acceptance cases”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M12.07-C098-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Installer release evidence” limit; preserve “Installer success is backed by actual install/upgrade outcomes”.
- [ ] **UC-M12.07-C098-T06 · Normal measurement:** Run or review the normal “Installer release evidence” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M12.07-C098-T07 · At-limit measurement:** Exercise the “Installer release evidence” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M12.07-C098-T08 · Over-limit measurement:** Exercise the “Installer release evidence” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M12.07-C098-T09 · Uncovered-scope report:** List the “Installer release evidence” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M12.07-C098-T10 · Limit evidence:** Publish the selected “Installer release evidence” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M12.07-C099 · Diagnostics / review

**Original checklist item:** Report installer release evidence results with executed, failed, skipped and unavailable cases separated; preserve the underlying observations and do not manufacture missing measurements.

- [ ] **UC-M12.07-C099-T01 · Result inventory:** Enumerate the required “Installer release evidence” qualification cases and intended targets before aggregating results; keep the planned denominator visible.
- [ ] **UC-M12.07-C099-T02 · Verdict schema:** Define separate executed-pass, executed-fail, skipped, unavailable and untested outcomes for “Installer release evidence”; document how incomplete cases block relevant claims.
- [ ] **UC-M12.07-C099-T03 · Identity fields:** Attach the actual target, fixture, configuration and revision identifiers to each “Installer release evidence” result; do not attribute host-only evidence to a guest or another OS.
- [ ] **UC-M12.07-C099-T04 · Observation capture:** Capture bounded raw “Installer release evidence” observations and harness errors; retain enough information to verify the reported oracle comparison.
- [ ] **UC-M12.07-C099-T05 · Aggregation rules:** Implement the “Installer release evidence” count/reduction rule so failures and missing measurements cannot disappear; preserve “Installer success is backed by actual install/upgrade outcomes”.
- [ ] **UC-M12.07-C099-T06 · Failure visibility:** Feed a failing “Installer release evidence” control through the report path; assert the exact failed case and underlying observation remain visible.
- [ ] **UC-M12.07-C099-T07 · Missing-result visibility:** Withhold a required “Installer release evidence” measurement or target; verify the report uses unavailable/untested rather than a fabricated zero or passing value.
- [ ] **UC-M12.07-C099-T08 · Bounds and redaction:** Check “Installer release evidence” report size and retention against “Evidence bytes and required acceptance cases”; remove secrets while retaining fixture and subject references.
- [ ] **UC-M12.07-C099-T09 · Report reconciliation:** Reconcile the “Installer release evidence” summary with every underlying case record; account for the full planned denominator and all omitted scope.
- [ ] **UC-M12.07-C099-T10 · Qualification handoff:** Publish the “Installer release evidence” report with measured observations, coverage limits and blockers; state which actual targets remain unqualified.

### UC-M12.07-C100 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for installer release evidence; label unexecuted checks as untested.

- [ ] **UC-M12.07-C100-T01 · Evidence inventory:** List the “Installer release evidence” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M12.07-C100-T02 · Artifact references:** Record the exact “Installer release evidence” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M12.07-C100-T03 · Fixture references:** Attach the “Installer release evidence” fixture IDs, input identities and oracle definition; preserve the source counterexample “A packaged updater is described as tested without running it” as a distinct evidence case.
- [ ] **UC-M12.07-C100-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Installer release evidence”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M12.07-C100-T05 · Environment record:** Record the actual “Installer release evidence” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M12.07-C100-T06 · Expected versus observed:** Pair every “Installer release evidence” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M12.07-C100-T07 · Failure and limit records:** Attach “Installer release evidence” change/failure and bounds evidence where required; include uncovered “Evidence bytes and required acceptance cases” and unresolved violations of “Installer success is backed by actual install/upgrade outcomes”.
- [ ] **UC-M12.07-C100-T08 · Evidence hygiene:** Check the “Installer release evidence” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M12.07-C100-T09 · Reproduction review:** Have the “Installer release evidence” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M12.07-C100-T10 · Acceptance linkage:** Link the “Installer release evidence” evidence to its parent and UC-M12.07 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

