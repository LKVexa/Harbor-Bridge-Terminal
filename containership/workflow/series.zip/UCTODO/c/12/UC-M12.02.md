# UC-M12.02 — Parser fuzzing campaign

**To-Do Pack 2.0.0 · Baseline UC-2.2.0 · 100 parent checks × 10 subtasks = 1,000 to-dos**

[Master index](../../INDEX.md) · [Workstream index](../../w/12.md)

| Field | Preserved source value |
|---|---|
| Workstream | 12. Qualification, packaging and release |
| Milestone | C |
| Priority | P0 |
| Source assessment | PARTIAL |
| Scope | core or selected profile |
| Dependencies | [UC-M07.04](../07/UC-M07.04.md), [UC-M08.02](../08/UC-M08.02.md), [UC-M09.06](../09/UC-M09.06.md) |
| Source checklist pack | 1.0.0 |
| Original reference labels | [S5], [S6], [S7], [S8]. |

## Original requirement

Fuzz archive, manifest, image, TIFF, bytecode and IPC parsers inside resource-limited workers with a retained corpus.

**Original acceptance criterion:** A budgeted campaign has reproducible seeds and no unexplained crashes, hangs, overreads or unbounded allocations.

**Source trace:** Original checklist `UC100/c/12/UC-M12.02.md` inside [s/checklists.zip](../../s/checklists.zip); exact parent records in [data/parents.jsonl](../../data/parents.jsonl). Original roadmap lines 1105–1115 are preserved in [s/roadmap.md](../../s/roadmap.md).

## How to use these lists

Every parent statement below is preserved verbatim. Its ten child tasks are proposed decomposition, not implemented capabilities or executed tests. Child IDs append `-T01` through `-T10` to the original parent ID. All begin unchecked / `TODO`. Design/review evidence does not establish runtime enforcement; observe the actual selected target where the parent requires it.

The source dependency graph and selected release profile determine applicability. The numbered child sequence is a local working order, not an added hard dependency graph. An unselected optional feature needs a recorded not-applicable rationale; missing prerequisites for selected work remain blockers. Numerical budgets, backends and trust mechanisms remain decisions unless fixed by the source. Test hostile cases only with synthetic inputs in authorized disposable environments.

## 01. Parser target inventory

**Source delivery:** Enumerate archive, manifest, image, TIFF, bytecode and IPC parser entry points.

**Source invariant:** Every claimed parser family is tied to an actual target implementation.

**Source negative case:** A wrapper is fuzzed while its native decoder is omitted.

**Source bounded quantities:** Targets and input formats.

### UC-M12.02-C001 · Contract

**Original checklist item:** Define the qualification objective for parser target inventory, including the actual target implementation, prerequisites, observable oracle and explicit exclusions.

- [ ] **UC-M12.02-C001-T01 · Scope statement:** Write the qualification question for “Parser target inventory”; identify the actual target, claimed capability and observations that can answer that question.
- [ ] **UC-M12.02-C001-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Parser target inventory”; record each producer, representation and missing-value meaning.
- [ ] **UC-M12.02-C001-T03 · Output inventory:** List the outputs of “Parser target inventory” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M12.02-C001-T04 · Field dictionary:** Create a field-and-term dictionary for “Parser target inventory”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M12.02-C001-T05 · Prerequisite contract:** Map “Parser target inventory” to the source component prerequisites (UC-M07.04, UC-M08.02, UC-M09.06); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M12.02-C001-T06 · Authority map:** Identify who may produce, change and consume “Parser target inventory”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M12.02-C001-T07 · Invariant clause:** Add a normative clause for “Parser target inventory” that preserves “Every claimed parser family is tied to an actual target implementation”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M12.02-C001-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Parser target inventory”; include the source counterexample “A wrapper is fuzzed while its native decoder is omitted” and the intended safe disposition.
- [ ] **UC-M12.02-C001-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Targets and input formats” in the “Parser target inventory” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M12.02-C001-T10 · Contract review:** Review the “Parser target inventory” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M12.02-C002 · Delivery

**Original checklist item:** Enumerate archive, manifest, image, TIFF, bytecode and IPC parser entry points.

- [ ] **UC-M12.02-C002-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Parser target inventory”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M12.02-C002-T02 · Change plan:** Break the source delivery for “Parser target inventory” into concrete edit targets and reviewable outputs; keep the UC-M12.02 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M12.02-C002-T03 · Core artifact:** Create the “Parser target inventory” model, schema or inventory that realizes this source instruction: Enumerate archive, manifest, image, TIFF, bytecode and IPC parser entry points.
- [ ] **UC-M12.02-C002-T04 · Concrete realization:** Populate “Parser target inventory” with one concrete worked case; map every required entity or field to its source and flag any unmapped entry.
- [ ] **UC-M12.02-C002-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Parser target inventory” needed to preserve “Every claimed parser family is tied to an actual target implementation”; record an enforcement gap where only a model exists.
- [ ] **UC-M12.02-C002-T06 · Dependency connection:** Connect the “Parser target inventory” qualification artifact to production parser harnesses, resource-limited workers and retained seed corpora; record the target identity and what the harness actually exercises.
- [ ] **UC-M12.02-C002-T07 · Resource behavior:** Account for “Targets and input formats” in “Parser target inventory”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M12.02-C002-T08 · Delivery check:** Run a known-valid control and a deliberately failing control for “Parser target inventory”; confirm the harness distinguishes their observed outcomes.
- [ ] **UC-M12.02-C002-T09 · Patch review:** Review the “Parser target inventory” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M12.02-C002-T10 · Delivery handoff:** Publish the “Parser target inventory” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M12.02-C003 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Every claimed parser family is tied to an actual target implementation. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M12.02-C003-T01 · Named property:** Create a stable property/check name under this parent for “Parser target inventory”; copy its required invariant exactly: “Every claimed parser family is tied to an actual target implementation”.
- [ ] **UC-M12.02-C003-T02 · Observable terms:** Define each term in the “Parser target inventory” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M12.02-C003-T03 · Precondition set:** List the preconditions under which “Every claimed parser family is tied to an actual target implementation” must hold for “Parser target inventory”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M12.02-C003-T04 · Transition coverage:** Map the “Parser target inventory” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M12.02-C003-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Parser target inventory”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M12.02-C003-T06 · Satisfying fixture:** Create a concrete “Parser target inventory” case that satisfies “Every claimed parser family is tied to an actual target implementation”; record its expected observation before running the assertion or review.
- [ ] **UC-M12.02-C003-T07 · Violating fixture:** Create the source counterexample “A wrapper is fuzzed while its native decoder is omitted” for “Parser target inventory”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M12.02-C003-T08 · Enforcement evidence:** Exercise the “Parser target inventory” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M12.02-C003-T09 · Regression linkage:** Link the “Parser target inventory” property to changes in production parser harnesses, resource-limited workers and retained seed corpora; record which dependency or contract changes require rerunning it.
- [ ] **UC-M12.02-C003-T10 · Property disposition:** Compare the satisfying and violating “Parser target inventory” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M12.02-C004 · Integration

**Original checklist item:** Integrate parser target inventory with production parser harnesses, resource-limited workers and retained seed corpora; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M12.02-C004-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Parser target inventory” across production parser harnesses, resource-limited workers and retained seed corpora; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M12.02-C004-T02 · Field mapping:** Map every “Parser target inventory” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M12.02-C004-T03 · Prerequisite identities:** Record the actual prerequisites for “Parser target inventory” (source dependency list: UC-M07.04, UC-M08.02, UC-M09.06); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M12.02-C004-T04 · Ownership agreement:** Specify who owns “Parser target inventory” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M12.02-C004-T05 · Handoff implementation:** Connect “Parser target inventory” through the mapped seam using the real adapter or explicit specification reference; preserve “Every claimed parser family is tied to an actual target implementation” across the handoff.
- [ ] **UC-M12.02-C004-T06 · Absent-input case:** Omit one required “Parser target inventory” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M12.02-C004-T07 · Stale-input case:** Supply an outdated “Parser target inventory” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M12.02-C004-T08 · Incompatible-input case:** Supply an incompatible “Parser target inventory” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M12.02-C004-T09 · Valid integration trace:** Run a valid “Parser target inventory” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M12.02-C004-T10 · Seam review:** Reconcile the “Parser target inventory” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M12.02-C005 · Valid-case test

**Original checklist item:** Run a known-valid control for parser target inventory; verify that the harness reaches its intended target and compare observed measurements or verdicts with predeclared expectations.

- [ ] **UC-M12.02-C005-T01 · Valid fixture choice:** Choose a known-valid control for “Parser target inventory”; document why it should pass and how it proves the harness reaches the intended target.
- [ ] **UC-M12.02-C005-T02 · Expected-result oracle:** Specify the “Parser target inventory” expected result independently of the implementation output; include the property “Every claimed parser family is tied to an actual target implementation” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M12.02-C005-T03 · Fixture material:** Create the concrete “Parser target inventory” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M12.02-C005-T04 · Target preparation:** Prepare the “Parser target inventory” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M12.02-C005-T05 · Initial-state record:** Record the initial “Parser target inventory” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M12.02-C005-T06 · Valid-path execution:** Run the “Parser target inventory” known-valid control on the identified target; retain enough observations to prove the correct target was exercised.
- [ ] **UC-M12.02-C005-T07 · Outcome comparison:** Compare every declared “Parser target inventory” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M12.02-C005-T08 · State and bounds check:** Inspect the “Parser target inventory” ownership/state effects and actual use of “Targets and input formats”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M12.02-C005-T09 · Repeatability check:** Repeat the same “Parser target inventory” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M12.02-C005-T10 · Positive evidence:** Attach the “Parser target inventory” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M12.02-C006 · Negative test

**Original checklist item:** Negative case: A wrapper is fuzzed while its native decoder is omitted. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M12.02-C006-T01 · Adverse-case definition:** Create a test record for the exact “Parser target inventory” source counterexample: “A wrapper is fuzzed while its native decoder is omitted”; state which precondition or invariant it challenges.
- [ ] **UC-M12.02-C006-T02 · Safe fixture boundary:** Define the contained test boundary for “Parser target inventory”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M12.02-C006-T03 · Valid control:** Construct a valid “Parser target inventory” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M12.02-C006-T04 · Minimal adverse input:** Derive the “Parser target inventory” adverse fixture from the control with the smallest documented change needed to reproduce “A wrapper is fuzzed while its native decoder is omitted”; retain that change as reproducible data.
- [ ] **UC-M12.02-C006-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Parser target inventory”; require “Every claimed parser family is tied to an actual target implementation” and forbid a false-success verdict.
- [ ] **UC-M12.02-C006-T06 · Adverse execution:** Exercise the “Parser target inventory” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M12.02-C006-T07 · Effect inspection:** Inspect “Parser target inventory” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M12.02-C006-T08 · Refusal versus failure:** Confirm the “Parser target inventory” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M12.02-C006-T09 · Reset and retention:** Restore only the disposable “Parser target inventory” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M12.02-C006-T10 · Negative regression:** Register the “Parser target inventory” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M12.02-C007 · Change / failure test

**Original checklist item:** Exercise parser target inventory when a campaign worker crashes or hangs on a reproducible generated input; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M12.02-C007-T01 · Scenario record:** Write the “Parser target inventory” change/failure scenario exactly as supplied: a campaign worker crashes or hangs on a reproducible generated input; identify the property that must remain true: “Every claimed parser family is tied to an actual target implementation”.
- [ ] **UC-M12.02-C007-T02 · Baseline capture:** Create a known-valid “Parser target inventory” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M12.02-C007-T03 · Injection map:** Locate the “Parser target inventory” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M12.02-C007-T04 · Disposition oracle:** Define the legal intermediate and final “Parser target inventory” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M12.02-C007-T05 · Controlled trigger:** Introduce the controlled “Parser target inventory” scenario in the disposable fixture: a campaign worker crashes or hangs on a reproducible generated input; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M12.02-C007-T06 · Intermediate inspection:** Inspect the “Parser target inventory” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M12.02-C007-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Parser target inventory”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M12.02-C007-T08 · Stale-evidence cleanup:** Invalidate superseded “Parser target inventory” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M12.02-C007-T09 · Repeat and compare:** Repeat the selected “Parser target inventory” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M12.02-C007-T10 · Failure evidence:** Publish the “Parser target inventory” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M12.02-C008 · Bounds

**Original checklist item:** Set a documented campaign budget for targets and input formats; record actual consumption, incomplete coverage and the disposition when the budget is exhausted.

- [ ] **UC-M12.02-C008-T01 · Quantity inventory:** Create a measurement inventory for “Parser target inventory”: “Targets and input formats”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M12.02-C008-T02 · Measurement method:** Choose how to observe each “Parser target inventory” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M12.02-C008-T03 · Budget decision:** Select justified campaign and target-resource budgets for “Parser target inventory”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M12.02-C008-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Parser target inventory” cases for “Targets and input formats”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M12.02-C008-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Parser target inventory” limit; preserve “Every claimed parser family is tied to an actual target implementation”.
- [ ] **UC-M12.02-C008-T06 · Normal measurement:** Run or review the normal “Parser target inventory” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M12.02-C008-T07 · At-limit measurement:** Exercise the “Parser target inventory” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M12.02-C008-T08 · Over-limit measurement:** Exercise the “Parser target inventory” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M12.02-C008-T09 · Uncovered-scope report:** List the “Parser target inventory” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M12.02-C008-T10 · Limit evidence:** Publish the selected “Parser target inventory” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M12.02-C009 · Diagnostics / review

**Original checklist item:** Report parser target inventory results with executed, failed, skipped and unavailable cases separated; preserve the underlying observations and do not manufacture missing measurements.

- [ ] **UC-M12.02-C009-T01 · Result inventory:** Enumerate the required “Parser target inventory” qualification cases and intended targets before aggregating results; keep the planned denominator visible.
- [ ] **UC-M12.02-C009-T02 · Verdict schema:** Define separate executed-pass, executed-fail, skipped, unavailable and untested outcomes for “Parser target inventory”; document how incomplete cases block relevant claims.
- [ ] **UC-M12.02-C009-T03 · Identity fields:** Attach the actual target, fixture, configuration and revision identifiers to each “Parser target inventory” result; do not attribute host-only evidence to a guest or another OS.
- [ ] **UC-M12.02-C009-T04 · Observation capture:** Capture bounded raw “Parser target inventory” observations and harness errors; retain enough information to verify the reported oracle comparison.
- [ ] **UC-M12.02-C009-T05 · Aggregation rules:** Implement the “Parser target inventory” count/reduction rule so failures and missing measurements cannot disappear; preserve “Every claimed parser family is tied to an actual target implementation”.
- [ ] **UC-M12.02-C009-T06 · Failure visibility:** Feed a failing “Parser target inventory” control through the report path; assert the exact failed case and underlying observation remain visible.
- [ ] **UC-M12.02-C009-T07 · Missing-result visibility:** Withhold a required “Parser target inventory” measurement or target; verify the report uses unavailable/untested rather than a fabricated zero or passing value.
- [ ] **UC-M12.02-C009-T08 · Bounds and redaction:** Check “Parser target inventory” report size and retention against “Targets and input formats”; remove secrets while retaining fixture and subject references.
- [ ] **UC-M12.02-C009-T09 · Report reconciliation:** Reconcile the “Parser target inventory” summary with every underlying case record; account for the full planned denominator and all omitted scope.
- [ ] **UC-M12.02-C009-T10 · Qualification handoff:** Publish the “Parser target inventory” report with measured observations, coverage limits and blockers; state which actual targets remain unqualified.

### UC-M12.02-C010 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for parser target inventory; label unexecuted checks as untested.

- [ ] **UC-M12.02-C010-T01 · Evidence inventory:** List the “Parser target inventory” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M12.02-C010-T02 · Artifact references:** Record the exact “Parser target inventory” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M12.02-C010-T03 · Fixture references:** Attach the “Parser target inventory” fixture IDs, input identities and oracle definition; preserve the source counterexample “A wrapper is fuzzed while its native decoder is omitted” as a distinct evidence case.
- [ ] **UC-M12.02-C010-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Parser target inventory”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M12.02-C010-T05 · Environment record:** Record the actual “Parser target inventory” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M12.02-C010-T06 · Expected versus observed:** Pair every “Parser target inventory” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M12.02-C010-T07 · Failure and limit records:** Attach “Parser target inventory” change/failure and bounds evidence where required; include uncovered “Targets and input formats” and unresolved violations of “Every claimed parser family is tied to an actual target implementation”.
- [ ] **UC-M12.02-C010-T08 · Evidence hygiene:** Check the “Parser target inventory” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M12.02-C010-T09 · Reproduction review:** Have the “Parser target inventory” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M12.02-C010-T10 · Acceptance linkage:** Link the “Parser target inventory” evidence to its parent and UC-M12.02 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 02. Harness correctness

**Source delivery:** Create harnesses that call production parsing logic and validate outcomes.

**Source invariant:** A harness cannot pass by never reaching the parser.

**Source negative case:** Malformed input is rejected by a stub before real parsing runs.

**Source bounded quantities:** Harness count and setup time.

### UC-M12.02-C011 · Contract

**Original checklist item:** Define the qualification objective for harness correctness, including the actual target implementation, prerequisites, observable oracle and explicit exclusions.

- [ ] **UC-M12.02-C011-T01 · Scope statement:** Write the qualification question for “Harness correctness”; identify the actual target, claimed capability and observations that can answer that question.
- [ ] **UC-M12.02-C011-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Harness correctness”; record each producer, representation and missing-value meaning.
- [ ] **UC-M12.02-C011-T03 · Output inventory:** List the outputs of “Harness correctness” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M12.02-C011-T04 · Field dictionary:** Create a field-and-term dictionary for “Harness correctness”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M12.02-C011-T05 · Prerequisite contract:** Map “Harness correctness” to the source component prerequisites (UC-M07.04, UC-M08.02, UC-M09.06); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M12.02-C011-T06 · Authority map:** Identify who may produce, change and consume “Harness correctness”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M12.02-C011-T07 · Invariant clause:** Add a normative clause for “Harness correctness” that preserves “A harness cannot pass by never reaching the parser”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M12.02-C011-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Harness correctness”; include the source counterexample “Malformed input is rejected by a stub before real parsing runs” and the intended safe disposition.
- [ ] **UC-M12.02-C011-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Harness count and setup time” in the “Harness correctness” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M12.02-C011-T10 · Contract review:** Review the “Harness correctness” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M12.02-C012 · Delivery

**Original checklist item:** Create harnesses that call production parsing logic and validate outcomes.

- [ ] **UC-M12.02-C012-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Harness correctness”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M12.02-C012-T02 · Change plan:** Break the source delivery for “Harness correctness” into concrete edit targets and reviewable outputs; keep the UC-M12.02 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M12.02-C012-T03 · Core artifact:** Implement the smallest selected-profile change for “Harness correctness” that realizes this source instruction: Create harnesses that call production parsing logic and validate outcomes.
- [ ] **UC-M12.02-C012-T04 · Concrete realization:** Trace “Harness correctness” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M12.02-C012-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Harness correctness” needed to preserve “A harness cannot pass by never reaching the parser”; record an enforcement gap where only a model exists.
- [ ] **UC-M12.02-C012-T06 · Dependency connection:** Connect the “Harness correctness” qualification artifact to production parser harnesses, resource-limited workers and retained seed corpora; record the target identity and what the harness actually exercises.
- [ ] **UC-M12.02-C012-T07 · Resource behavior:** Account for “Harness count and setup time” in “Harness correctness”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M12.02-C012-T08 · Delivery check:** Run a known-valid control and a deliberately failing control for “Harness correctness”; confirm the harness distinguishes their observed outcomes.
- [ ] **UC-M12.02-C012-T09 · Patch review:** Review the “Harness correctness” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M12.02-C012-T10 · Delivery handoff:** Publish the “Harness correctness” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M12.02-C013 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: A harness cannot pass by never reaching the parser. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M12.02-C013-T01 · Named property:** Create a stable property/check name under this parent for “Harness correctness”; copy its required invariant exactly: “A harness cannot pass by never reaching the parser”.
- [ ] **UC-M12.02-C013-T02 · Observable terms:** Define each term in the “Harness correctness” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M12.02-C013-T03 · Precondition set:** List the preconditions under which “A harness cannot pass by never reaching the parser” must hold for “Harness correctness”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M12.02-C013-T04 · Transition coverage:** Map the “Harness correctness” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M12.02-C013-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Harness correctness”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M12.02-C013-T06 · Satisfying fixture:** Create a concrete “Harness correctness” case that satisfies “A harness cannot pass by never reaching the parser”; record its expected observation before running the assertion or review.
- [ ] **UC-M12.02-C013-T07 · Violating fixture:** Create the source counterexample “Malformed input is rejected by a stub before real parsing runs” for “Harness correctness”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M12.02-C013-T08 · Enforcement evidence:** Exercise the “Harness correctness” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M12.02-C013-T09 · Regression linkage:** Link the “Harness correctness” property to changes in production parser harnesses, resource-limited workers and retained seed corpora; record which dependency or contract changes require rerunning it.
- [ ] **UC-M12.02-C013-T10 · Property disposition:** Compare the satisfying and violating “Harness correctness” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M12.02-C014 · Integration

**Original checklist item:** Integrate harness correctness with production parser harnesses, resource-limited workers and retained seed corpora; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M12.02-C014-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Harness correctness” across production parser harnesses, resource-limited workers and retained seed corpora; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M12.02-C014-T02 · Field mapping:** Map every “Harness correctness” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M12.02-C014-T03 · Prerequisite identities:** Record the actual prerequisites for “Harness correctness” (source dependency list: UC-M07.04, UC-M08.02, UC-M09.06); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M12.02-C014-T04 · Ownership agreement:** Specify who owns “Harness correctness” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M12.02-C014-T05 · Handoff implementation:** Connect “Harness correctness” through the mapped seam using the real adapter or explicit specification reference; preserve “A harness cannot pass by never reaching the parser” across the handoff.
- [ ] **UC-M12.02-C014-T06 · Absent-input case:** Omit one required “Harness correctness” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M12.02-C014-T07 · Stale-input case:** Supply an outdated “Harness correctness” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M12.02-C014-T08 · Incompatible-input case:** Supply an incompatible “Harness correctness” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M12.02-C014-T09 · Valid integration trace:** Run a valid “Harness correctness” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M12.02-C014-T10 · Seam review:** Reconcile the “Harness correctness” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M12.02-C015 · Valid-case test

**Original checklist item:** Run a known-valid control for harness correctness; verify that the harness reaches its intended target and compare observed measurements or verdicts with predeclared expectations.

- [ ] **UC-M12.02-C015-T01 · Valid fixture choice:** Choose a known-valid control for “Harness correctness”; document why it should pass and how it proves the harness reaches the intended target.
- [ ] **UC-M12.02-C015-T02 · Expected-result oracle:** Specify the “Harness correctness” expected result independently of the implementation output; include the property “A harness cannot pass by never reaching the parser” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M12.02-C015-T03 · Fixture material:** Create the concrete “Harness correctness” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M12.02-C015-T04 · Target preparation:** Prepare the “Harness correctness” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M12.02-C015-T05 · Initial-state record:** Record the initial “Harness correctness” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M12.02-C015-T06 · Valid-path execution:** Run the “Harness correctness” known-valid control on the identified target; retain enough observations to prove the correct target was exercised.
- [ ] **UC-M12.02-C015-T07 · Outcome comparison:** Compare every declared “Harness correctness” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M12.02-C015-T08 · State and bounds check:** Inspect the “Harness correctness” ownership/state effects and actual use of “Harness count and setup time”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M12.02-C015-T09 · Repeatability check:** Repeat the same “Harness correctness” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M12.02-C015-T10 · Positive evidence:** Attach the “Harness correctness” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M12.02-C016 · Negative test

**Original checklist item:** Negative case: Malformed input is rejected by a stub before real parsing runs. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M12.02-C016-T01 · Adverse-case definition:** Create a test record for the exact “Harness correctness” source counterexample: “Malformed input is rejected by a stub before real parsing runs”; state which precondition or invariant it challenges.
- [ ] **UC-M12.02-C016-T02 · Safe fixture boundary:** Define the contained test boundary for “Harness correctness”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M12.02-C016-T03 · Valid control:** Construct a valid “Harness correctness” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M12.02-C016-T04 · Minimal adverse input:** Derive the “Harness correctness” adverse fixture from the control with the smallest documented change needed to reproduce “Malformed input is rejected by a stub before real parsing runs”; retain that change as reproducible data.
- [ ] **UC-M12.02-C016-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Harness correctness”; require “A harness cannot pass by never reaching the parser” and forbid a false-success verdict.
- [ ] **UC-M12.02-C016-T06 · Adverse execution:** Exercise the “Harness correctness” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M12.02-C016-T07 · Effect inspection:** Inspect “Harness correctness” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M12.02-C016-T08 · Refusal versus failure:** Confirm the “Harness correctness” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M12.02-C016-T09 · Reset and retention:** Restore only the disposable “Harness correctness” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M12.02-C016-T10 · Negative regression:** Register the “Harness correctness” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M12.02-C017 · Change / failure test

**Original checklist item:** Exercise harness correctness when a campaign worker crashes or hangs on a reproducible generated input; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M12.02-C017-T01 · Scenario record:** Write the “Harness correctness” change/failure scenario exactly as supplied: a campaign worker crashes or hangs on a reproducible generated input; identify the property that must remain true: “A harness cannot pass by never reaching the parser”.
- [ ] **UC-M12.02-C017-T02 · Baseline capture:** Create a known-valid “Harness correctness” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M12.02-C017-T03 · Injection map:** Locate the “Harness correctness” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M12.02-C017-T04 · Disposition oracle:** Define the legal intermediate and final “Harness correctness” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M12.02-C017-T05 · Controlled trigger:** Introduce the controlled “Harness correctness” scenario in the disposable fixture: a campaign worker crashes or hangs on a reproducible generated input; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M12.02-C017-T06 · Intermediate inspection:** Inspect the “Harness correctness” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M12.02-C017-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Harness correctness”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M12.02-C017-T08 · Stale-evidence cleanup:** Invalidate superseded “Harness correctness” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M12.02-C017-T09 · Repeat and compare:** Repeat the selected “Harness correctness” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M12.02-C017-T10 · Failure evidence:** Publish the “Harness correctness” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M12.02-C018 · Bounds

**Original checklist item:** Set a documented campaign budget for harness count and setup time; record actual consumption, incomplete coverage and the disposition when the budget is exhausted.

- [ ] **UC-M12.02-C018-T01 · Quantity inventory:** Create a measurement inventory for “Harness correctness”: “Harness count and setup time”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M12.02-C018-T02 · Measurement method:** Choose how to observe each “Harness correctness” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M12.02-C018-T03 · Budget decision:** Select justified campaign and target-resource budgets for “Harness correctness”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M12.02-C018-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Harness correctness” cases for “Harness count and setup time”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M12.02-C018-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Harness correctness” limit; preserve “A harness cannot pass by never reaching the parser”.
- [ ] **UC-M12.02-C018-T06 · Normal measurement:** Run or review the normal “Harness correctness” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M12.02-C018-T07 · At-limit measurement:** Exercise the “Harness correctness” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M12.02-C018-T08 · Over-limit measurement:** Exercise the “Harness correctness” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M12.02-C018-T09 · Uncovered-scope report:** List the “Harness correctness” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M12.02-C018-T10 · Limit evidence:** Publish the selected “Harness correctness” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M12.02-C019 · Diagnostics / review

**Original checklist item:** Report harness correctness results with executed, failed, skipped and unavailable cases separated; preserve the underlying observations and do not manufacture missing measurements.

- [ ] **UC-M12.02-C019-T01 · Result inventory:** Enumerate the required “Harness correctness” qualification cases and intended targets before aggregating results; keep the planned denominator visible.
- [ ] **UC-M12.02-C019-T02 · Verdict schema:** Define separate executed-pass, executed-fail, skipped, unavailable and untested outcomes for “Harness correctness”; document how incomplete cases block relevant claims.
- [ ] **UC-M12.02-C019-T03 · Identity fields:** Attach the actual target, fixture, configuration and revision identifiers to each “Harness correctness” result; do not attribute host-only evidence to a guest or another OS.
- [ ] **UC-M12.02-C019-T04 · Observation capture:** Capture bounded raw “Harness correctness” observations and harness errors; retain enough information to verify the reported oracle comparison.
- [ ] **UC-M12.02-C019-T05 · Aggregation rules:** Implement the “Harness correctness” count/reduction rule so failures and missing measurements cannot disappear; preserve “A harness cannot pass by never reaching the parser”.
- [ ] **UC-M12.02-C019-T06 · Failure visibility:** Feed a failing “Harness correctness” control through the report path; assert the exact failed case and underlying observation remain visible.
- [ ] **UC-M12.02-C019-T07 · Missing-result visibility:** Withhold a required “Harness correctness” measurement or target; verify the report uses unavailable/untested rather than a fabricated zero or passing value.
- [ ] **UC-M12.02-C019-T08 · Bounds and redaction:** Check “Harness correctness” report size and retention against “Harness count and setup time”; remove secrets while retaining fixture and subject references.
- [ ] **UC-M12.02-C019-T09 · Report reconciliation:** Reconcile the “Harness correctness” summary with every underlying case record; account for the full planned denominator and all omitted scope.
- [ ] **UC-M12.02-C019-T10 · Qualification handoff:** Publish the “Harness correctness” report with measured observations, coverage limits and blockers; state which actual targets remain unqualified.

### UC-M12.02-C020 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for harness correctness; label unexecuted checks as untested.

- [ ] **UC-M12.02-C020-T01 · Evidence inventory:** List the “Harness correctness” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M12.02-C020-T02 · Artifact references:** Record the exact “Harness correctness” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M12.02-C020-T03 · Fixture references:** Attach the “Harness correctness” fixture IDs, input identities and oracle definition; preserve the source counterexample “Malformed input is rejected by a stub before real parsing runs” as a distinct evidence case.
- [ ] **UC-M12.02-C020-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Harness correctness”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M12.02-C020-T05 · Environment record:** Record the actual “Harness correctness” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M12.02-C020-T06 · Expected versus observed:** Pair every “Harness correctness” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M12.02-C020-T07 · Failure and limit records:** Attach “Harness correctness” change/failure and bounds evidence where required; include uncovered “Harness count and setup time” and unresolved violations of “A harness cannot pass by never reaching the parser”.
- [ ] **UC-M12.02-C020-T08 · Evidence hygiene:** Check the “Harness correctness” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M12.02-C020-T09 · Reproduction review:** Have the “Harness correctness” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M12.02-C020-T10 · Acceptance linkage:** Link the “Harness correctness” evidence to its parent and UC-M12.02 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 03. Seed corpus

**Source delivery:** Collect valid and known-malformed source-boundary examples with identities.

**Source invariant:** Seeds remain reproducible and attributable to a parser version.

**Source negative case:** A crash seed is stored without its target or configuration.

**Source bounded quantities:** Seed bytes and corpus entries.

### UC-M12.02-C021 · Contract

**Original checklist item:** Define the qualification objective for seed corpus, including the actual target implementation, prerequisites, observable oracle and explicit exclusions.

- [ ] **UC-M12.02-C021-T01 · Scope statement:** Write the qualification question for “Seed corpus”; identify the actual target, claimed capability and observations that can answer that question.
- [ ] **UC-M12.02-C021-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Seed corpus”; record each producer, representation and missing-value meaning.
- [ ] **UC-M12.02-C021-T03 · Output inventory:** List the outputs of “Seed corpus” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M12.02-C021-T04 · Field dictionary:** Create a field-and-term dictionary for “Seed corpus”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M12.02-C021-T05 · Prerequisite contract:** Map “Seed corpus” to the source component prerequisites (UC-M07.04, UC-M08.02, UC-M09.06); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M12.02-C021-T06 · Authority map:** Identify who may produce, change and consume “Seed corpus”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M12.02-C021-T07 · Invariant clause:** Add a normative clause for “Seed corpus” that preserves “Seeds remain reproducible and attributable to a parser version”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M12.02-C021-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Seed corpus”; include the source counterexample “A crash seed is stored without its target or configuration” and the intended safe disposition.
- [ ] **UC-M12.02-C021-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Seed bytes and corpus entries” in the “Seed corpus” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M12.02-C021-T10 · Contract review:** Review the “Seed corpus” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M12.02-C022 · Delivery

**Original checklist item:** Collect valid and known-malformed source-boundary examples with identities.

- [ ] **UC-M12.02-C022-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Seed corpus”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M12.02-C022-T02 · Change plan:** Break the source delivery for “Seed corpus” into concrete edit targets and reviewable outputs; keep the UC-M12.02 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M12.02-C022-T03 · Core artifact:** Create the “Seed corpus” output artifact for this source instruction: Collect valid and known-malformed source-boundary examples with identities.
- [ ] **UC-M12.02-C022-T04 · Concrete realization:** Populate the “Seed corpus” artifact from identified observations; keep unknown, failed and unexecuted results distinct and exclude unapproved sensitive material.
- [ ] **UC-M12.02-C022-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Seed corpus” needed to preserve “Seeds remain reproducible and attributable to a parser version”; record an enforcement gap where only a model exists.
- [ ] **UC-M12.02-C022-T06 · Dependency connection:** Connect the “Seed corpus” qualification artifact to production parser harnesses, resource-limited workers and retained seed corpora; record the target identity and what the harness actually exercises.
- [ ] **UC-M12.02-C022-T07 · Resource behavior:** Account for “Seed bytes and corpus entries” in “Seed corpus”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M12.02-C022-T08 · Delivery check:** Run a known-valid control and a deliberately failing control for “Seed corpus”; confirm the harness distinguishes their observed outcomes.
- [ ] **UC-M12.02-C022-T09 · Patch review:** Review the “Seed corpus” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M12.02-C022-T10 · Delivery handoff:** Publish the “Seed corpus” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M12.02-C023 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Seeds remain reproducible and attributable to a parser version. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M12.02-C023-T01 · Named property:** Create a stable property/check name under this parent for “Seed corpus”; copy its required invariant exactly: “Seeds remain reproducible and attributable to a parser version”.
- [ ] **UC-M12.02-C023-T02 · Observable terms:** Define each term in the “Seed corpus” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M12.02-C023-T03 · Precondition set:** List the preconditions under which “Seeds remain reproducible and attributable to a parser version” must hold for “Seed corpus”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M12.02-C023-T04 · Transition coverage:** Map the “Seed corpus” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M12.02-C023-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Seed corpus”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M12.02-C023-T06 · Satisfying fixture:** Create a concrete “Seed corpus” case that satisfies “Seeds remain reproducible and attributable to a parser version”; record its expected observation before running the assertion or review.
- [ ] **UC-M12.02-C023-T07 · Violating fixture:** Create the source counterexample “A crash seed is stored without its target or configuration” for “Seed corpus”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M12.02-C023-T08 · Enforcement evidence:** Exercise the “Seed corpus” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M12.02-C023-T09 · Regression linkage:** Link the “Seed corpus” property to changes in production parser harnesses, resource-limited workers and retained seed corpora; record which dependency or contract changes require rerunning it.
- [ ] **UC-M12.02-C023-T10 · Property disposition:** Compare the satisfying and violating “Seed corpus” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M12.02-C024 · Integration

**Original checklist item:** Integrate seed corpus with production parser harnesses, resource-limited workers and retained seed corpora; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M12.02-C024-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Seed corpus” across production parser harnesses, resource-limited workers and retained seed corpora; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M12.02-C024-T02 · Field mapping:** Map every “Seed corpus” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M12.02-C024-T03 · Prerequisite identities:** Record the actual prerequisites for “Seed corpus” (source dependency list: UC-M07.04, UC-M08.02, UC-M09.06); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M12.02-C024-T04 · Ownership agreement:** Specify who owns “Seed corpus” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M12.02-C024-T05 · Handoff implementation:** Connect “Seed corpus” through the mapped seam using the real adapter or explicit specification reference; preserve “Seeds remain reproducible and attributable to a parser version” across the handoff.
- [ ] **UC-M12.02-C024-T06 · Absent-input case:** Omit one required “Seed corpus” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M12.02-C024-T07 · Stale-input case:** Supply an outdated “Seed corpus” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M12.02-C024-T08 · Incompatible-input case:** Supply an incompatible “Seed corpus” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M12.02-C024-T09 · Valid integration trace:** Run a valid “Seed corpus” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M12.02-C024-T10 · Seam review:** Reconcile the “Seed corpus” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M12.02-C025 · Valid-case test

**Original checklist item:** Run a known-valid control for seed corpus; verify that the harness reaches its intended target and compare observed measurements or verdicts with predeclared expectations.

- [ ] **UC-M12.02-C025-T01 · Valid fixture choice:** Choose a known-valid control for “Seed corpus”; document why it should pass and how it proves the harness reaches the intended target.
- [ ] **UC-M12.02-C025-T02 · Expected-result oracle:** Specify the “Seed corpus” expected result independently of the implementation output; include the property “Seeds remain reproducible and attributable to a parser version” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M12.02-C025-T03 · Fixture material:** Create the concrete “Seed corpus” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M12.02-C025-T04 · Target preparation:** Prepare the “Seed corpus” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M12.02-C025-T05 · Initial-state record:** Record the initial “Seed corpus” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M12.02-C025-T06 · Valid-path execution:** Run the “Seed corpus” known-valid control on the identified target; retain enough observations to prove the correct target was exercised.
- [ ] **UC-M12.02-C025-T07 · Outcome comparison:** Compare every declared “Seed corpus” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M12.02-C025-T08 · State and bounds check:** Inspect the “Seed corpus” ownership/state effects and actual use of “Seed bytes and corpus entries”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M12.02-C025-T09 · Repeatability check:** Repeat the same “Seed corpus” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M12.02-C025-T10 · Positive evidence:** Attach the “Seed corpus” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M12.02-C026 · Negative test

**Original checklist item:** Negative case: A crash seed is stored without its target or configuration. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M12.02-C026-T01 · Adverse-case definition:** Create a test record for the exact “Seed corpus” source counterexample: “A crash seed is stored without its target or configuration”; state which precondition or invariant it challenges.
- [ ] **UC-M12.02-C026-T02 · Safe fixture boundary:** Define the contained test boundary for “Seed corpus”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M12.02-C026-T03 · Valid control:** Construct a valid “Seed corpus” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M12.02-C026-T04 · Minimal adverse input:** Derive the “Seed corpus” adverse fixture from the control with the smallest documented change needed to reproduce “A crash seed is stored without its target or configuration”; retain that change as reproducible data.
- [ ] **UC-M12.02-C026-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Seed corpus”; require “Seeds remain reproducible and attributable to a parser version” and forbid a false-success verdict.
- [ ] **UC-M12.02-C026-T06 · Adverse execution:** Exercise the “Seed corpus” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M12.02-C026-T07 · Effect inspection:** Inspect “Seed corpus” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M12.02-C026-T08 · Refusal versus failure:** Confirm the “Seed corpus” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M12.02-C026-T09 · Reset and retention:** Restore only the disposable “Seed corpus” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M12.02-C026-T10 · Negative regression:** Register the “Seed corpus” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M12.02-C027 · Change / failure test

**Original checklist item:** Exercise seed corpus when a campaign worker crashes or hangs on a reproducible generated input; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M12.02-C027-T01 · Scenario record:** Write the “Seed corpus” change/failure scenario exactly as supplied: a campaign worker crashes or hangs on a reproducible generated input; identify the property that must remain true: “Seeds remain reproducible and attributable to a parser version”.
- [ ] **UC-M12.02-C027-T02 · Baseline capture:** Create a known-valid “Seed corpus” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M12.02-C027-T03 · Injection map:** Locate the “Seed corpus” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M12.02-C027-T04 · Disposition oracle:** Define the legal intermediate and final “Seed corpus” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M12.02-C027-T05 · Controlled trigger:** Introduce the controlled “Seed corpus” scenario in the disposable fixture: a campaign worker crashes or hangs on a reproducible generated input; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M12.02-C027-T06 · Intermediate inspection:** Inspect the “Seed corpus” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M12.02-C027-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Seed corpus”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M12.02-C027-T08 · Stale-evidence cleanup:** Invalidate superseded “Seed corpus” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M12.02-C027-T09 · Repeat and compare:** Repeat the selected “Seed corpus” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M12.02-C027-T10 · Failure evidence:** Publish the “Seed corpus” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M12.02-C028 · Bounds

**Original checklist item:** Set a documented campaign budget for seed bytes and corpus entries; record actual consumption, incomplete coverage and the disposition when the budget is exhausted.

- [ ] **UC-M12.02-C028-T01 · Quantity inventory:** Create a measurement inventory for “Seed corpus”: “Seed bytes and corpus entries”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M12.02-C028-T02 · Measurement method:** Choose how to observe each “Seed corpus” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M12.02-C028-T03 · Budget decision:** Select justified campaign and target-resource budgets for “Seed corpus”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M12.02-C028-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Seed corpus” cases for “Seed bytes and corpus entries”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M12.02-C028-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Seed corpus” limit; preserve “Seeds remain reproducible and attributable to a parser version”.
- [ ] **UC-M12.02-C028-T06 · Normal measurement:** Run or review the normal “Seed corpus” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M12.02-C028-T07 · At-limit measurement:** Exercise the “Seed corpus” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M12.02-C028-T08 · Over-limit measurement:** Exercise the “Seed corpus” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M12.02-C028-T09 · Uncovered-scope report:** List the “Seed corpus” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M12.02-C028-T10 · Limit evidence:** Publish the selected “Seed corpus” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M12.02-C029 · Diagnostics / review

**Original checklist item:** Report seed corpus results with executed, failed, skipped and unavailable cases separated; preserve the underlying observations and do not manufacture missing measurements.

- [ ] **UC-M12.02-C029-T01 · Result inventory:** Enumerate the required “Seed corpus” qualification cases and intended targets before aggregating results; keep the planned denominator visible.
- [ ] **UC-M12.02-C029-T02 · Verdict schema:** Define separate executed-pass, executed-fail, skipped, unavailable and untested outcomes for “Seed corpus”; document how incomplete cases block relevant claims.
- [ ] **UC-M12.02-C029-T03 · Identity fields:** Attach the actual target, fixture, configuration and revision identifiers to each “Seed corpus” result; do not attribute host-only evidence to a guest or another OS.
- [ ] **UC-M12.02-C029-T04 · Observation capture:** Capture bounded raw “Seed corpus” observations and harness errors; retain enough information to verify the reported oracle comparison.
- [ ] **UC-M12.02-C029-T05 · Aggregation rules:** Implement the “Seed corpus” count/reduction rule so failures and missing measurements cannot disappear; preserve “Seeds remain reproducible and attributable to a parser version”.
- [ ] **UC-M12.02-C029-T06 · Failure visibility:** Feed a failing “Seed corpus” control through the report path; assert the exact failed case and underlying observation remain visible.
- [ ] **UC-M12.02-C029-T07 · Missing-result visibility:** Withhold a required “Seed corpus” measurement or target; verify the report uses unavailable/untested rather than a fabricated zero or passing value.
- [ ] **UC-M12.02-C029-T08 · Bounds and redaction:** Check “Seed corpus” report size and retention against “Seed bytes and corpus entries”; remove secrets while retaining fixture and subject references.
- [ ] **UC-M12.02-C029-T09 · Report reconciliation:** Reconcile the “Seed corpus” summary with every underlying case record; account for the full planned denominator and all omitted scope.
- [ ] **UC-M12.02-C029-T10 · Qualification handoff:** Publish the “Seed corpus” report with measured observations, coverage limits and blockers; state which actual targets remain unqualified.

### UC-M12.02-C030 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for seed corpus; label unexecuted checks as untested.

- [ ] **UC-M12.02-C030-T01 · Evidence inventory:** List the “Seed corpus” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M12.02-C030-T02 · Artifact references:** Record the exact “Seed corpus” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M12.02-C030-T03 · Fixture references:** Attach the “Seed corpus” fixture IDs, input identities and oracle definition; preserve the source counterexample “A crash seed is stored without its target or configuration” as a distinct evidence case.
- [ ] **UC-M12.02-C030-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Seed corpus”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M12.02-C030-T05 · Environment record:** Record the actual “Seed corpus” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M12.02-C030-T06 · Expected versus observed:** Pair every “Seed corpus” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M12.02-C030-T07 · Failure and limit records:** Attach “Seed corpus” change/failure and bounds evidence where required; include uncovered “Seed bytes and corpus entries” and unresolved violations of “Seeds remain reproducible and attributable to a parser version”.
- [ ] **UC-M12.02-C030-T08 · Evidence hygiene:** Check the “Seed corpus” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M12.02-C030-T09 · Reproduction review:** Have the “Seed corpus” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M12.02-C030-T10 · Acceptance linkage:** Link the “Seed corpus” evidence to its parent and UC-M12.02 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 04. Input mutation strategy

**Source delivery:** Define bounded mutation and generation appropriate to each parser format.

**Source invariant:** The campaign exercises structural boundaries rather than only random noise.

**Source negative case:** A length field is never varied by the chosen generator.

**Source bounded quantities:** Mutation cases and generated input bytes.

### UC-M12.02-C031 · Contract

**Original checklist item:** Define the qualification objective for input mutation strategy, including the actual target implementation, prerequisites, observable oracle and explicit exclusions.

- [ ] **UC-M12.02-C031-T01 · Scope statement:** Write the qualification question for “Input mutation strategy”; identify the actual target, claimed capability and observations that can answer that question.
- [ ] **UC-M12.02-C031-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Input mutation strategy”; record each producer, representation and missing-value meaning.
- [ ] **UC-M12.02-C031-T03 · Output inventory:** List the outputs of “Input mutation strategy” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M12.02-C031-T04 · Field dictionary:** Create a field-and-term dictionary for “Input mutation strategy”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M12.02-C031-T05 · Prerequisite contract:** Map “Input mutation strategy” to the source component prerequisites (UC-M07.04, UC-M08.02, UC-M09.06); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M12.02-C031-T06 · Authority map:** Identify who may produce, change and consume “Input mutation strategy”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M12.02-C031-T07 · Invariant clause:** Add a normative clause for “Input mutation strategy” that preserves “The campaign exercises structural boundaries rather than only random noise”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M12.02-C031-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Input mutation strategy”; include the source counterexample “A length field is never varied by the chosen generator” and the intended safe disposition.
- [ ] **UC-M12.02-C031-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Mutation cases and generated input bytes” in the “Input mutation strategy” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M12.02-C031-T10 · Contract review:** Review the “Input mutation strategy” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M12.02-C032 · Delivery

**Original checklist item:** Define bounded mutation and generation appropriate to each parser format.

- [ ] **UC-M12.02-C032-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Input mutation strategy”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M12.02-C032-T02 · Change plan:** Break the source delivery for “Input mutation strategy” into concrete edit targets and reviewable outputs; keep the UC-M12.02 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M12.02-C032-T03 · Core artifact:** Create the “Input mutation strategy” model, schema or inventory that realizes this source instruction: Define bounded mutation and generation appropriate to each parser format.
- [ ] **UC-M12.02-C032-T04 · Concrete realization:** Populate “Input mutation strategy” with one concrete worked case; map every required entity or field to its source and flag any unmapped entry.
- [ ] **UC-M12.02-C032-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Input mutation strategy” needed to preserve “The campaign exercises structural boundaries rather than only random noise”; record an enforcement gap where only a model exists.
- [ ] **UC-M12.02-C032-T06 · Dependency connection:** Connect the “Input mutation strategy” qualification artifact to production parser harnesses, resource-limited workers and retained seed corpora; record the target identity and what the harness actually exercises.
- [ ] **UC-M12.02-C032-T07 · Resource behavior:** Account for “Mutation cases and generated input bytes” in “Input mutation strategy”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M12.02-C032-T08 · Delivery check:** Run a known-valid control and a deliberately failing control for “Input mutation strategy”; confirm the harness distinguishes their observed outcomes.
- [ ] **UC-M12.02-C032-T09 · Patch review:** Review the “Input mutation strategy” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M12.02-C032-T10 · Delivery handoff:** Publish the “Input mutation strategy” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M12.02-C033 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: The campaign exercises structural boundaries rather than only random noise. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M12.02-C033-T01 · Named property:** Create a stable property/check name under this parent for “Input mutation strategy”; copy its required invariant exactly: “The campaign exercises structural boundaries rather than only random noise”.
- [ ] **UC-M12.02-C033-T02 · Observable terms:** Define each term in the “Input mutation strategy” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M12.02-C033-T03 · Precondition set:** List the preconditions under which “The campaign exercises structural boundaries rather than only random noise” must hold for “Input mutation strategy”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M12.02-C033-T04 · Transition coverage:** Map the “Input mutation strategy” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M12.02-C033-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Input mutation strategy”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M12.02-C033-T06 · Satisfying fixture:** Create a concrete “Input mutation strategy” case that satisfies “The campaign exercises structural boundaries rather than only random noise”; record its expected observation before running the assertion or review.
- [ ] **UC-M12.02-C033-T07 · Violating fixture:** Create the source counterexample “A length field is never varied by the chosen generator” for “Input mutation strategy”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M12.02-C033-T08 · Enforcement evidence:** Exercise the “Input mutation strategy” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M12.02-C033-T09 · Regression linkage:** Link the “Input mutation strategy” property to changes in production parser harnesses, resource-limited workers and retained seed corpora; record which dependency or contract changes require rerunning it.
- [ ] **UC-M12.02-C033-T10 · Property disposition:** Compare the satisfying and violating “Input mutation strategy” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M12.02-C034 · Integration

**Original checklist item:** Integrate input mutation strategy with production parser harnesses, resource-limited workers and retained seed corpora; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M12.02-C034-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Input mutation strategy” across production parser harnesses, resource-limited workers and retained seed corpora; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M12.02-C034-T02 · Field mapping:** Map every “Input mutation strategy” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M12.02-C034-T03 · Prerequisite identities:** Record the actual prerequisites for “Input mutation strategy” (source dependency list: UC-M07.04, UC-M08.02, UC-M09.06); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M12.02-C034-T04 · Ownership agreement:** Specify who owns “Input mutation strategy” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M12.02-C034-T05 · Handoff implementation:** Connect “Input mutation strategy” through the mapped seam using the real adapter or explicit specification reference; preserve “The campaign exercises structural boundaries rather than only random noise” across the handoff.
- [ ] **UC-M12.02-C034-T06 · Absent-input case:** Omit one required “Input mutation strategy” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M12.02-C034-T07 · Stale-input case:** Supply an outdated “Input mutation strategy” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M12.02-C034-T08 · Incompatible-input case:** Supply an incompatible “Input mutation strategy” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M12.02-C034-T09 · Valid integration trace:** Run a valid “Input mutation strategy” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M12.02-C034-T10 · Seam review:** Reconcile the “Input mutation strategy” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M12.02-C035 · Valid-case test

**Original checklist item:** Run a known-valid control for input mutation strategy; verify that the harness reaches its intended target and compare observed measurements or verdicts with predeclared expectations.

- [ ] **UC-M12.02-C035-T01 · Valid fixture choice:** Choose a known-valid control for “Input mutation strategy”; document why it should pass and how it proves the harness reaches the intended target.
- [ ] **UC-M12.02-C035-T02 · Expected-result oracle:** Specify the “Input mutation strategy” expected result independently of the implementation output; include the property “The campaign exercises structural boundaries rather than only random noise” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M12.02-C035-T03 · Fixture material:** Create the concrete “Input mutation strategy” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M12.02-C035-T04 · Target preparation:** Prepare the “Input mutation strategy” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M12.02-C035-T05 · Initial-state record:** Record the initial “Input mutation strategy” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M12.02-C035-T06 · Valid-path execution:** Run the “Input mutation strategy” known-valid control on the identified target; retain enough observations to prove the correct target was exercised.
- [ ] **UC-M12.02-C035-T07 · Outcome comparison:** Compare every declared “Input mutation strategy” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M12.02-C035-T08 · State and bounds check:** Inspect the “Input mutation strategy” ownership/state effects and actual use of “Mutation cases and generated input bytes”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M12.02-C035-T09 · Repeatability check:** Repeat the same “Input mutation strategy” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M12.02-C035-T10 · Positive evidence:** Attach the “Input mutation strategy” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M12.02-C036 · Negative test

**Original checklist item:** Negative case: A length field is never varied by the chosen generator. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M12.02-C036-T01 · Adverse-case definition:** Create a test record for the exact “Input mutation strategy” source counterexample: “A length field is never varied by the chosen generator”; state which precondition or invariant it challenges.
- [ ] **UC-M12.02-C036-T02 · Safe fixture boundary:** Define the contained test boundary for “Input mutation strategy”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M12.02-C036-T03 · Valid control:** Construct a valid “Input mutation strategy” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M12.02-C036-T04 · Minimal adverse input:** Derive the “Input mutation strategy” adverse fixture from the control with the smallest documented change needed to reproduce “A length field is never varied by the chosen generator”; retain that change as reproducible data.
- [ ] **UC-M12.02-C036-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Input mutation strategy”; require “The campaign exercises structural boundaries rather than only random noise” and forbid a false-success verdict.
- [ ] **UC-M12.02-C036-T06 · Adverse execution:** Exercise the “Input mutation strategy” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M12.02-C036-T07 · Effect inspection:** Inspect “Input mutation strategy” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M12.02-C036-T08 · Refusal versus failure:** Confirm the “Input mutation strategy” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M12.02-C036-T09 · Reset and retention:** Restore only the disposable “Input mutation strategy” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M12.02-C036-T10 · Negative regression:** Register the “Input mutation strategy” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M12.02-C037 · Change / failure test

**Original checklist item:** Exercise input mutation strategy when a campaign worker crashes or hangs on a reproducible generated input; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M12.02-C037-T01 · Scenario record:** Write the “Input mutation strategy” change/failure scenario exactly as supplied: a campaign worker crashes or hangs on a reproducible generated input; identify the property that must remain true: “The campaign exercises structural boundaries rather than only random noise”.
- [ ] **UC-M12.02-C037-T02 · Baseline capture:** Create a known-valid “Input mutation strategy” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M12.02-C037-T03 · Injection map:** Locate the “Input mutation strategy” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M12.02-C037-T04 · Disposition oracle:** Define the legal intermediate and final “Input mutation strategy” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M12.02-C037-T05 · Controlled trigger:** Introduce the controlled “Input mutation strategy” scenario in the disposable fixture: a campaign worker crashes or hangs on a reproducible generated input; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M12.02-C037-T06 · Intermediate inspection:** Inspect the “Input mutation strategy” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M12.02-C037-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Input mutation strategy”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M12.02-C037-T08 · Stale-evidence cleanup:** Invalidate superseded “Input mutation strategy” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M12.02-C037-T09 · Repeat and compare:** Repeat the selected “Input mutation strategy” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M12.02-C037-T10 · Failure evidence:** Publish the “Input mutation strategy” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M12.02-C038 · Bounds

**Original checklist item:** Set a documented campaign budget for mutation cases and generated input bytes; record actual consumption, incomplete coverage and the disposition when the budget is exhausted.

- [ ] **UC-M12.02-C038-T01 · Quantity inventory:** Create a measurement inventory for “Input mutation strategy”: “Mutation cases and generated input bytes”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M12.02-C038-T02 · Measurement method:** Choose how to observe each “Input mutation strategy” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M12.02-C038-T03 · Budget decision:** Select justified campaign and target-resource budgets for “Input mutation strategy”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M12.02-C038-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Input mutation strategy” cases for “Mutation cases and generated input bytes”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M12.02-C038-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Input mutation strategy” limit; preserve “The campaign exercises structural boundaries rather than only random noise”.
- [ ] **UC-M12.02-C038-T06 · Normal measurement:** Run or review the normal “Input mutation strategy” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M12.02-C038-T07 · At-limit measurement:** Exercise the “Input mutation strategy” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M12.02-C038-T08 · Over-limit measurement:** Exercise the “Input mutation strategy” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M12.02-C038-T09 · Uncovered-scope report:** List the “Input mutation strategy” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M12.02-C038-T10 · Limit evidence:** Publish the selected “Input mutation strategy” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M12.02-C039 · Diagnostics / review

**Original checklist item:** Report input mutation strategy results with executed, failed, skipped and unavailable cases separated; preserve the underlying observations and do not manufacture missing measurements.

- [ ] **UC-M12.02-C039-T01 · Result inventory:** Enumerate the required “Input mutation strategy” qualification cases and intended targets before aggregating results; keep the planned denominator visible.
- [ ] **UC-M12.02-C039-T02 · Verdict schema:** Define separate executed-pass, executed-fail, skipped, unavailable and untested outcomes for “Input mutation strategy”; document how incomplete cases block relevant claims.
- [ ] **UC-M12.02-C039-T03 · Identity fields:** Attach the actual target, fixture, configuration and revision identifiers to each “Input mutation strategy” result; do not attribute host-only evidence to a guest or another OS.
- [ ] **UC-M12.02-C039-T04 · Observation capture:** Capture bounded raw “Input mutation strategy” observations and harness errors; retain enough information to verify the reported oracle comparison.
- [ ] **UC-M12.02-C039-T05 · Aggregation rules:** Implement the “Input mutation strategy” count/reduction rule so failures and missing measurements cannot disappear; preserve “The campaign exercises structural boundaries rather than only random noise”.
- [ ] **UC-M12.02-C039-T06 · Failure visibility:** Feed a failing “Input mutation strategy” control through the report path; assert the exact failed case and underlying observation remain visible.
- [ ] **UC-M12.02-C039-T07 · Missing-result visibility:** Withhold a required “Input mutation strategy” measurement or target; verify the report uses unavailable/untested rather than a fabricated zero or passing value.
- [ ] **UC-M12.02-C039-T08 · Bounds and redaction:** Check “Input mutation strategy” report size and retention against “Mutation cases and generated input bytes”; remove secrets while retaining fixture and subject references.
- [ ] **UC-M12.02-C039-T09 · Report reconciliation:** Reconcile the “Input mutation strategy” summary with every underlying case record; account for the full planned denominator and all omitted scope.
- [ ] **UC-M12.02-C039-T10 · Qualification handoff:** Publish the “Input mutation strategy” report with measured observations, coverage limits and blockers; state which actual targets remain unqualified.

### UC-M12.02-C040 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for input mutation strategy; label unexecuted checks as untested.

- [ ] **UC-M12.02-C040-T01 · Evidence inventory:** List the “Input mutation strategy” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M12.02-C040-T02 · Artifact references:** Record the exact “Input mutation strategy” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M12.02-C040-T03 · Fixture references:** Attach the “Input mutation strategy” fixture IDs, input identities and oracle definition; preserve the source counterexample “A length field is never varied by the chosen generator” as a distinct evidence case.
- [ ] **UC-M12.02-C040-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Input mutation strategy”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M12.02-C040-T05 · Environment record:** Record the actual “Input mutation strategy” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M12.02-C040-T06 · Expected versus observed:** Pair every “Input mutation strategy” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M12.02-C040-T07 · Failure and limit records:** Attach “Input mutation strategy” change/failure and bounds evidence where required; include uncovered “Mutation cases and generated input bytes” and unresolved violations of “The campaign exercises structural boundaries rather than only random noise”.
- [ ] **UC-M12.02-C040-T08 · Evidence hygiene:** Check the “Input mutation strategy” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M12.02-C040-T09 · Reproduction review:** Have the “Input mutation strategy” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M12.02-C040-T10 · Acceptance linkage:** Link the “Input mutation strategy” evidence to its parent and UC-M12.02 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 05. Resource-limited workers

**Source delivery:** Run fuzz cases inside declared CPU, memory, process and wall-time limits.

**Source invariant:** Fuzzing cannot exhaust the management host through malformed input.

**Source negative case:** A decompression case consumes memory outside the worker budget.

**Source bounded quantities:** Worker resources and concurrent workers.

### UC-M12.02-C041 · Contract

**Original checklist item:** Define the qualification objective for resource-limited workers, including the actual target implementation, prerequisites, observable oracle and explicit exclusions.

- [ ] **UC-M12.02-C041-T01 · Scope statement:** Write the qualification question for “Resource-limited workers”; identify the actual target, claimed capability and observations that can answer that question.
- [ ] **UC-M12.02-C041-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Resource-limited workers”; record each producer, representation and missing-value meaning.
- [ ] **UC-M12.02-C041-T03 · Output inventory:** List the outputs of “Resource-limited workers” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M12.02-C041-T04 · Field dictionary:** Create a field-and-term dictionary for “Resource-limited workers”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M12.02-C041-T05 · Prerequisite contract:** Map “Resource-limited workers” to the source component prerequisites (UC-M07.04, UC-M08.02, UC-M09.06); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M12.02-C041-T06 · Authority map:** Identify who may produce, change and consume “Resource-limited workers”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M12.02-C041-T07 · Invariant clause:** Add a normative clause for “Resource-limited workers” that preserves “Fuzzing cannot exhaust the management host through malformed input”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M12.02-C041-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Resource-limited workers”; include the source counterexample “A decompression case consumes memory outside the worker budget” and the intended safe disposition.
- [ ] **UC-M12.02-C041-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Worker resources and concurrent workers” in the “Resource-limited workers” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M12.02-C041-T10 · Contract review:** Review the “Resource-limited workers” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M12.02-C042 · Delivery

**Original checklist item:** Run fuzz cases inside declared CPU, memory, process and wall-time limits.

- [ ] **UC-M12.02-C042-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Resource-limited workers”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M12.02-C042-T02 · Change plan:** Break the source delivery for “Resource-limited workers” into concrete edit targets and reviewable outputs; keep the UC-M12.02 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M12.02-C042-T03 · Core artifact:** Create the “Resource-limited workers” fixture or harness for this source instruction: Run fuzz cases inside declared CPU, memory, process and wall-time limits.
- [ ] **UC-M12.02-C042-T04 · Concrete realization:** Connect the “Resource-limited workers” harness to its actual intended target, set the expected oracle before running it, and distinguish a mock/control run from a target run.
- [ ] **UC-M12.02-C042-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Resource-limited workers” needed to preserve “Fuzzing cannot exhaust the management host through malformed input”; record an enforcement gap where only a model exists.
- [ ] **UC-M12.02-C042-T06 · Dependency connection:** Connect the “Resource-limited workers” qualification artifact to production parser harnesses, resource-limited workers and retained seed corpora; record the target identity and what the harness actually exercises.
- [ ] **UC-M12.02-C042-T07 · Resource behavior:** Account for “Worker resources and concurrent workers” in “Resource-limited workers”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M12.02-C042-T08 · Delivery check:** Run a known-valid control and a deliberately failing control for “Resource-limited workers”; confirm the harness distinguishes their observed outcomes.
- [ ] **UC-M12.02-C042-T09 · Patch review:** Review the “Resource-limited workers” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M12.02-C042-T10 · Delivery handoff:** Publish the “Resource-limited workers” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M12.02-C043 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Fuzzing cannot exhaust the management host through malformed input. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M12.02-C043-T01 · Named property:** Create a stable property/check name under this parent for “Resource-limited workers”; copy its required invariant exactly: “Fuzzing cannot exhaust the management host through malformed input”.
- [ ] **UC-M12.02-C043-T02 · Observable terms:** Define each term in the “Resource-limited workers” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M12.02-C043-T03 · Precondition set:** List the preconditions under which “Fuzzing cannot exhaust the management host through malformed input” must hold for “Resource-limited workers”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M12.02-C043-T04 · Transition coverage:** Map the “Resource-limited workers” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M12.02-C043-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Resource-limited workers”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M12.02-C043-T06 · Satisfying fixture:** Create a concrete “Resource-limited workers” case that satisfies “Fuzzing cannot exhaust the management host through malformed input”; record its expected observation before running the assertion or review.
- [ ] **UC-M12.02-C043-T07 · Violating fixture:** Create the source counterexample “A decompression case consumes memory outside the worker budget” for “Resource-limited workers”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M12.02-C043-T08 · Enforcement evidence:** Exercise the “Resource-limited workers” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M12.02-C043-T09 · Regression linkage:** Link the “Resource-limited workers” property to changes in production parser harnesses, resource-limited workers and retained seed corpora; record which dependency or contract changes require rerunning it.
- [ ] **UC-M12.02-C043-T10 · Property disposition:** Compare the satisfying and violating “Resource-limited workers” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M12.02-C044 · Integration

**Original checklist item:** Integrate resource-limited workers with production parser harnesses, resource-limited workers and retained seed corpora; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M12.02-C044-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Resource-limited workers” across production parser harnesses, resource-limited workers and retained seed corpora; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M12.02-C044-T02 · Field mapping:** Map every “Resource-limited workers” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M12.02-C044-T03 · Prerequisite identities:** Record the actual prerequisites for “Resource-limited workers” (source dependency list: UC-M07.04, UC-M08.02, UC-M09.06); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M12.02-C044-T04 · Ownership agreement:** Specify who owns “Resource-limited workers” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M12.02-C044-T05 · Handoff implementation:** Connect “Resource-limited workers” through the mapped seam using the real adapter or explicit specification reference; preserve “Fuzzing cannot exhaust the management host through malformed input” across the handoff.
- [ ] **UC-M12.02-C044-T06 · Absent-input case:** Omit one required “Resource-limited workers” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M12.02-C044-T07 · Stale-input case:** Supply an outdated “Resource-limited workers” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M12.02-C044-T08 · Incompatible-input case:** Supply an incompatible “Resource-limited workers” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M12.02-C044-T09 · Valid integration trace:** Run a valid “Resource-limited workers” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M12.02-C044-T10 · Seam review:** Reconcile the “Resource-limited workers” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M12.02-C045 · Valid-case test

**Original checklist item:** Run a known-valid control for resource-limited workers; verify that the harness reaches its intended target and compare observed measurements or verdicts with predeclared expectations.

- [ ] **UC-M12.02-C045-T01 · Valid fixture choice:** Choose a known-valid control for “Resource-limited workers”; document why it should pass and how it proves the harness reaches the intended target.
- [ ] **UC-M12.02-C045-T02 · Expected-result oracle:** Specify the “Resource-limited workers” expected result independently of the implementation output; include the property “Fuzzing cannot exhaust the management host through malformed input” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M12.02-C045-T03 · Fixture material:** Create the concrete “Resource-limited workers” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M12.02-C045-T04 · Target preparation:** Prepare the “Resource-limited workers” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M12.02-C045-T05 · Initial-state record:** Record the initial “Resource-limited workers” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M12.02-C045-T06 · Valid-path execution:** Run the “Resource-limited workers” known-valid control on the identified target; retain enough observations to prove the correct target was exercised.
- [ ] **UC-M12.02-C045-T07 · Outcome comparison:** Compare every declared “Resource-limited workers” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M12.02-C045-T08 · State and bounds check:** Inspect the “Resource-limited workers” ownership/state effects and actual use of “Worker resources and concurrent workers”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M12.02-C045-T09 · Repeatability check:** Repeat the same “Resource-limited workers” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M12.02-C045-T10 · Positive evidence:** Attach the “Resource-limited workers” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M12.02-C046 · Negative test

**Original checklist item:** Negative case: A decompression case consumes memory outside the worker budget. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M12.02-C046-T01 · Adverse-case definition:** Create a test record for the exact “Resource-limited workers” source counterexample: “A decompression case consumes memory outside the worker budget”; state which precondition or invariant it challenges.
- [ ] **UC-M12.02-C046-T02 · Safe fixture boundary:** Define the contained test boundary for “Resource-limited workers”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M12.02-C046-T03 · Valid control:** Construct a valid “Resource-limited workers” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M12.02-C046-T04 · Minimal adverse input:** Derive the “Resource-limited workers” adverse fixture from the control with the smallest documented change needed to reproduce “A decompression case consumes memory outside the worker budget”; retain that change as reproducible data.
- [ ] **UC-M12.02-C046-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Resource-limited workers”; require “Fuzzing cannot exhaust the management host through malformed input” and forbid a false-success verdict.
- [ ] **UC-M12.02-C046-T06 · Adverse execution:** Exercise the “Resource-limited workers” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M12.02-C046-T07 · Effect inspection:** Inspect “Resource-limited workers” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M12.02-C046-T08 · Refusal versus failure:** Confirm the “Resource-limited workers” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M12.02-C046-T09 · Reset and retention:** Restore only the disposable “Resource-limited workers” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M12.02-C046-T10 · Negative regression:** Register the “Resource-limited workers” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M12.02-C047 · Change / failure test

**Original checklist item:** Exercise resource-limited workers when a campaign worker crashes or hangs on a reproducible generated input; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M12.02-C047-T01 · Scenario record:** Write the “Resource-limited workers” change/failure scenario exactly as supplied: a campaign worker crashes or hangs on a reproducible generated input; identify the property that must remain true: “Fuzzing cannot exhaust the management host through malformed input”.
- [ ] **UC-M12.02-C047-T02 · Baseline capture:** Create a known-valid “Resource-limited workers” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M12.02-C047-T03 · Injection map:** Locate the “Resource-limited workers” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M12.02-C047-T04 · Disposition oracle:** Define the legal intermediate and final “Resource-limited workers” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M12.02-C047-T05 · Controlled trigger:** Introduce the controlled “Resource-limited workers” scenario in the disposable fixture: a campaign worker crashes or hangs on a reproducible generated input; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M12.02-C047-T06 · Intermediate inspection:** Inspect the “Resource-limited workers” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M12.02-C047-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Resource-limited workers”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M12.02-C047-T08 · Stale-evidence cleanup:** Invalidate superseded “Resource-limited workers” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M12.02-C047-T09 · Repeat and compare:** Repeat the selected “Resource-limited workers” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M12.02-C047-T10 · Failure evidence:** Publish the “Resource-limited workers” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M12.02-C048 · Bounds

**Original checklist item:** Set a documented campaign budget for worker resources and concurrent workers; record actual consumption, incomplete coverage and the disposition when the budget is exhausted.

- [ ] **UC-M12.02-C048-T01 · Quantity inventory:** Create a measurement inventory for “Resource-limited workers”: “Worker resources and concurrent workers”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M12.02-C048-T02 · Measurement method:** Choose how to observe each “Resource-limited workers” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M12.02-C048-T03 · Budget decision:** Select justified campaign and target-resource budgets for “Resource-limited workers”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M12.02-C048-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Resource-limited workers” cases for “Worker resources and concurrent workers”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M12.02-C048-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Resource-limited workers” limit; preserve “Fuzzing cannot exhaust the management host through malformed input”.
- [ ] **UC-M12.02-C048-T06 · Normal measurement:** Run or review the normal “Resource-limited workers” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M12.02-C048-T07 · At-limit measurement:** Exercise the “Resource-limited workers” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M12.02-C048-T08 · Over-limit measurement:** Exercise the “Resource-limited workers” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M12.02-C048-T09 · Uncovered-scope report:** List the “Resource-limited workers” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M12.02-C048-T10 · Limit evidence:** Publish the selected “Resource-limited workers” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M12.02-C049 · Diagnostics / review

**Original checklist item:** Report resource-limited workers results with executed, failed, skipped and unavailable cases separated; preserve the underlying observations and do not manufacture missing measurements.

- [ ] **UC-M12.02-C049-T01 · Result inventory:** Enumerate the required “Resource-limited workers” qualification cases and intended targets before aggregating results; keep the planned denominator visible.
- [ ] **UC-M12.02-C049-T02 · Verdict schema:** Define separate executed-pass, executed-fail, skipped, unavailable and untested outcomes for “Resource-limited workers”; document how incomplete cases block relevant claims.
- [ ] **UC-M12.02-C049-T03 · Identity fields:** Attach the actual target, fixture, configuration and revision identifiers to each “Resource-limited workers” result; do not attribute host-only evidence to a guest or another OS.
- [ ] **UC-M12.02-C049-T04 · Observation capture:** Capture bounded raw “Resource-limited workers” observations and harness errors; retain enough information to verify the reported oracle comparison.
- [ ] **UC-M12.02-C049-T05 · Aggregation rules:** Implement the “Resource-limited workers” count/reduction rule so failures and missing measurements cannot disappear; preserve “Fuzzing cannot exhaust the management host through malformed input”.
- [ ] **UC-M12.02-C049-T06 · Failure visibility:** Feed a failing “Resource-limited workers” control through the report path; assert the exact failed case and underlying observation remain visible.
- [ ] **UC-M12.02-C049-T07 · Missing-result visibility:** Withhold a required “Resource-limited workers” measurement or target; verify the report uses unavailable/untested rather than a fabricated zero or passing value.
- [ ] **UC-M12.02-C049-T08 · Bounds and redaction:** Check “Resource-limited workers” report size and retention against “Worker resources and concurrent workers”; remove secrets while retaining fixture and subject references.
- [ ] **UC-M12.02-C049-T09 · Report reconciliation:** Reconcile the “Resource-limited workers” summary with every underlying case record; account for the full planned denominator and all omitted scope.
- [ ] **UC-M12.02-C049-T10 · Qualification handoff:** Publish the “Resource-limited workers” report with measured observations, coverage limits and blockers; state which actual targets remain unqualified.

### UC-M12.02-C050 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for resource-limited workers; label unexecuted checks as untested.

- [ ] **UC-M12.02-C050-T01 · Evidence inventory:** List the “Resource-limited workers” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M12.02-C050-T02 · Artifact references:** Record the exact “Resource-limited workers” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M12.02-C050-T03 · Fixture references:** Attach the “Resource-limited workers” fixture IDs, input identities and oracle definition; preserve the source counterexample “A decompression case consumes memory outside the worker budget” as a distinct evidence case.
- [ ] **UC-M12.02-C050-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Resource-limited workers”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M12.02-C050-T05 · Environment record:** Record the actual “Resource-limited workers” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M12.02-C050-T06 · Expected versus observed:** Pair every “Resource-limited workers” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M12.02-C050-T07 · Failure and limit records:** Attach “Resource-limited workers” change/failure and bounds evidence where required; include uncovered “Worker resources and concurrent workers” and unresolved violations of “Fuzzing cannot exhaust the management host through malformed input”.
- [ ] **UC-M12.02-C050-T08 · Evidence hygiene:** Check the “Resource-limited workers” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M12.02-C050-T09 · Reproduction review:** Have the “Resource-limited workers” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M12.02-C050-T10 · Acceptance linkage:** Link the “Resource-limited workers” evidence to its parent and UC-M12.02 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 06. Crash and hang detection

**Source delivery:** Capture abnormal exits, sanitizer findings and exceeded deadlines distinctly.

**Source invariant:** A timeout or crash cannot appear as an ordinary parser refusal.

**Source negative case:** The harness treats every nonzero exit as an expected reject.

**Source bounded quantities:** Outcome classes and detection latency.

### UC-M12.02-C051 · Contract

**Original checklist item:** Define the qualification objective for crash and hang detection, including the actual target implementation, prerequisites, observable oracle and explicit exclusions.

- [ ] **UC-M12.02-C051-T01 · Scope statement:** Write the qualification question for “Crash and hang detection”; identify the actual target, claimed capability and observations that can answer that question.
- [ ] **UC-M12.02-C051-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Crash and hang detection”; record each producer, representation and missing-value meaning.
- [ ] **UC-M12.02-C051-T03 · Output inventory:** List the outputs of “Crash and hang detection” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M12.02-C051-T04 · Field dictionary:** Create a field-and-term dictionary for “Crash and hang detection”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M12.02-C051-T05 · Prerequisite contract:** Map “Crash and hang detection” to the source component prerequisites (UC-M07.04, UC-M08.02, UC-M09.06); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M12.02-C051-T06 · Authority map:** Identify who may produce, change and consume “Crash and hang detection”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M12.02-C051-T07 · Invariant clause:** Add a normative clause for “Crash and hang detection” that preserves “A timeout or crash cannot appear as an ordinary parser refusal”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M12.02-C051-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Crash and hang detection”; include the source counterexample “The harness treats every nonzero exit as an expected reject” and the intended safe disposition.
- [ ] **UC-M12.02-C051-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Outcome classes and detection latency” in the “Crash and hang detection” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M12.02-C051-T10 · Contract review:** Review the “Crash and hang detection” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M12.02-C052 · Delivery

**Original checklist item:** Capture abnormal exits, sanitizer findings and exceeded deadlines distinctly.

- [ ] **UC-M12.02-C052-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Crash and hang detection”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M12.02-C052-T02 · Change plan:** Break the source delivery for “Crash and hang detection” into concrete edit targets and reviewable outputs; keep the UC-M12.02 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M12.02-C052-T03 · Core artifact:** Create the “Crash and hang detection” output artifact for this source instruction: Capture abnormal exits, sanitizer findings and exceeded deadlines distinctly.
- [ ] **UC-M12.02-C052-T04 · Concrete realization:** Populate the “Crash and hang detection” artifact from identified observations; keep unknown, failed and unexecuted results distinct and exclude unapproved sensitive material.
- [ ] **UC-M12.02-C052-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Crash and hang detection” needed to preserve “A timeout or crash cannot appear as an ordinary parser refusal”; record an enforcement gap where only a model exists.
- [ ] **UC-M12.02-C052-T06 · Dependency connection:** Connect the “Crash and hang detection” qualification artifact to production parser harnesses, resource-limited workers and retained seed corpora; record the target identity and what the harness actually exercises.
- [ ] **UC-M12.02-C052-T07 · Resource behavior:** Account for “Outcome classes and detection latency” in “Crash and hang detection”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M12.02-C052-T08 · Delivery check:** Run a known-valid control and a deliberately failing control for “Crash and hang detection”; confirm the harness distinguishes their observed outcomes.
- [ ] **UC-M12.02-C052-T09 · Patch review:** Review the “Crash and hang detection” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M12.02-C052-T10 · Delivery handoff:** Publish the “Crash and hang detection” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M12.02-C053 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: A timeout or crash cannot appear as an ordinary parser refusal. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M12.02-C053-T01 · Named property:** Create a stable property/check name under this parent for “Crash and hang detection”; copy its required invariant exactly: “A timeout or crash cannot appear as an ordinary parser refusal”.
- [ ] **UC-M12.02-C053-T02 · Observable terms:** Define each term in the “Crash and hang detection” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M12.02-C053-T03 · Precondition set:** List the preconditions under which “A timeout or crash cannot appear as an ordinary parser refusal” must hold for “Crash and hang detection”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M12.02-C053-T04 · Transition coverage:** Map the “Crash and hang detection” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M12.02-C053-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Crash and hang detection”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M12.02-C053-T06 · Satisfying fixture:** Create a concrete “Crash and hang detection” case that satisfies “A timeout or crash cannot appear as an ordinary parser refusal”; record its expected observation before running the assertion or review.
- [ ] **UC-M12.02-C053-T07 · Violating fixture:** Create the source counterexample “The harness treats every nonzero exit as an expected reject” for “Crash and hang detection”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M12.02-C053-T08 · Enforcement evidence:** Exercise the “Crash and hang detection” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M12.02-C053-T09 · Regression linkage:** Link the “Crash and hang detection” property to changes in production parser harnesses, resource-limited workers and retained seed corpora; record which dependency or contract changes require rerunning it.
- [ ] **UC-M12.02-C053-T10 · Property disposition:** Compare the satisfying and violating “Crash and hang detection” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M12.02-C054 · Integration

**Original checklist item:** Integrate crash and hang detection with production parser harnesses, resource-limited workers and retained seed corpora; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M12.02-C054-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Crash and hang detection” across production parser harnesses, resource-limited workers and retained seed corpora; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M12.02-C054-T02 · Field mapping:** Map every “Crash and hang detection” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M12.02-C054-T03 · Prerequisite identities:** Record the actual prerequisites for “Crash and hang detection” (source dependency list: UC-M07.04, UC-M08.02, UC-M09.06); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M12.02-C054-T04 · Ownership agreement:** Specify who owns “Crash and hang detection” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M12.02-C054-T05 · Handoff implementation:** Connect “Crash and hang detection” through the mapped seam using the real adapter or explicit specification reference; preserve “A timeout or crash cannot appear as an ordinary parser refusal” across the handoff.
- [ ] **UC-M12.02-C054-T06 · Absent-input case:** Omit one required “Crash and hang detection” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M12.02-C054-T07 · Stale-input case:** Supply an outdated “Crash and hang detection” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M12.02-C054-T08 · Incompatible-input case:** Supply an incompatible “Crash and hang detection” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M12.02-C054-T09 · Valid integration trace:** Run a valid “Crash and hang detection” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M12.02-C054-T10 · Seam review:** Reconcile the “Crash and hang detection” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M12.02-C055 · Valid-case test

**Original checklist item:** Run a known-valid control for crash and hang detection; verify that the harness reaches its intended target and compare observed measurements or verdicts with predeclared expectations.

- [ ] **UC-M12.02-C055-T01 · Valid fixture choice:** Choose a known-valid control for “Crash and hang detection”; document why it should pass and how it proves the harness reaches the intended target.
- [ ] **UC-M12.02-C055-T02 · Expected-result oracle:** Specify the “Crash and hang detection” expected result independently of the implementation output; include the property “A timeout or crash cannot appear as an ordinary parser refusal” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M12.02-C055-T03 · Fixture material:** Create the concrete “Crash and hang detection” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M12.02-C055-T04 · Target preparation:** Prepare the “Crash and hang detection” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M12.02-C055-T05 · Initial-state record:** Record the initial “Crash and hang detection” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M12.02-C055-T06 · Valid-path execution:** Run the “Crash and hang detection” known-valid control on the identified target; retain enough observations to prove the correct target was exercised.
- [ ] **UC-M12.02-C055-T07 · Outcome comparison:** Compare every declared “Crash and hang detection” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M12.02-C055-T08 · State and bounds check:** Inspect the “Crash and hang detection” ownership/state effects and actual use of “Outcome classes and detection latency”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M12.02-C055-T09 · Repeatability check:** Repeat the same “Crash and hang detection” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M12.02-C055-T10 · Positive evidence:** Attach the “Crash and hang detection” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M12.02-C056 · Negative test

**Original checklist item:** Negative case: The harness treats every nonzero exit as an expected reject. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M12.02-C056-T01 · Adverse-case definition:** Create a test record for the exact “Crash and hang detection” source counterexample: “The harness treats every nonzero exit as an expected reject”; state which precondition or invariant it challenges.
- [ ] **UC-M12.02-C056-T02 · Safe fixture boundary:** Define the contained test boundary for “Crash and hang detection”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M12.02-C056-T03 · Valid control:** Construct a valid “Crash and hang detection” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M12.02-C056-T04 · Minimal adverse input:** Derive the “Crash and hang detection” adverse fixture from the control with the smallest documented change needed to reproduce “The harness treats every nonzero exit as an expected reject”; retain that change as reproducible data.
- [ ] **UC-M12.02-C056-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Crash and hang detection”; require “A timeout or crash cannot appear as an ordinary parser refusal” and forbid a false-success verdict.
- [ ] **UC-M12.02-C056-T06 · Adverse execution:** Exercise the “Crash and hang detection” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M12.02-C056-T07 · Effect inspection:** Inspect “Crash and hang detection” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M12.02-C056-T08 · Refusal versus failure:** Confirm the “Crash and hang detection” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M12.02-C056-T09 · Reset and retention:** Restore only the disposable “Crash and hang detection” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M12.02-C056-T10 · Negative regression:** Register the “Crash and hang detection” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M12.02-C057 · Change / failure test

**Original checklist item:** Exercise crash and hang detection when a campaign worker crashes or hangs on a reproducible generated input; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M12.02-C057-T01 · Scenario record:** Write the “Crash and hang detection” change/failure scenario exactly as supplied: a campaign worker crashes or hangs on a reproducible generated input; identify the property that must remain true: “A timeout or crash cannot appear as an ordinary parser refusal”.
- [ ] **UC-M12.02-C057-T02 · Baseline capture:** Create a known-valid “Crash and hang detection” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M12.02-C057-T03 · Injection map:** Locate the “Crash and hang detection” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M12.02-C057-T04 · Disposition oracle:** Define the legal intermediate and final “Crash and hang detection” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M12.02-C057-T05 · Controlled trigger:** Introduce the controlled “Crash and hang detection” scenario in the disposable fixture: a campaign worker crashes or hangs on a reproducible generated input; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M12.02-C057-T06 · Intermediate inspection:** Inspect the “Crash and hang detection” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M12.02-C057-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Crash and hang detection”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M12.02-C057-T08 · Stale-evidence cleanup:** Invalidate superseded “Crash and hang detection” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M12.02-C057-T09 · Repeat and compare:** Repeat the selected “Crash and hang detection” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M12.02-C057-T10 · Failure evidence:** Publish the “Crash and hang detection” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M12.02-C058 · Bounds

**Original checklist item:** Set a documented campaign budget for outcome classes and detection latency; record actual consumption, incomplete coverage and the disposition when the budget is exhausted.

- [ ] **UC-M12.02-C058-T01 · Quantity inventory:** Create a measurement inventory for “Crash and hang detection”: “Outcome classes and detection latency”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M12.02-C058-T02 · Measurement method:** Choose how to observe each “Crash and hang detection” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M12.02-C058-T03 · Budget decision:** Select justified campaign and target-resource budgets for “Crash and hang detection”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M12.02-C058-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Crash and hang detection” cases for “Outcome classes and detection latency”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M12.02-C058-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Crash and hang detection” limit; preserve “A timeout or crash cannot appear as an ordinary parser refusal”.
- [ ] **UC-M12.02-C058-T06 · Normal measurement:** Run or review the normal “Crash and hang detection” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M12.02-C058-T07 · At-limit measurement:** Exercise the “Crash and hang detection” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M12.02-C058-T08 · Over-limit measurement:** Exercise the “Crash and hang detection” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M12.02-C058-T09 · Uncovered-scope report:** List the “Crash and hang detection” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M12.02-C058-T10 · Limit evidence:** Publish the selected “Crash and hang detection” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M12.02-C059 · Diagnostics / review

**Original checklist item:** Report crash and hang detection results with executed, failed, skipped and unavailable cases separated; preserve the underlying observations and do not manufacture missing measurements.

- [ ] **UC-M12.02-C059-T01 · Result inventory:** Enumerate the required “Crash and hang detection” qualification cases and intended targets before aggregating results; keep the planned denominator visible.
- [ ] **UC-M12.02-C059-T02 · Verdict schema:** Define separate executed-pass, executed-fail, skipped, unavailable and untested outcomes for “Crash and hang detection”; document how incomplete cases block relevant claims.
- [ ] **UC-M12.02-C059-T03 · Identity fields:** Attach the actual target, fixture, configuration and revision identifiers to each “Crash and hang detection” result; do not attribute host-only evidence to a guest or another OS.
- [ ] **UC-M12.02-C059-T04 · Observation capture:** Capture bounded raw “Crash and hang detection” observations and harness errors; retain enough information to verify the reported oracle comparison.
- [ ] **UC-M12.02-C059-T05 · Aggregation rules:** Implement the “Crash and hang detection” count/reduction rule so failures and missing measurements cannot disappear; preserve “A timeout or crash cannot appear as an ordinary parser refusal”.
- [ ] **UC-M12.02-C059-T06 · Failure visibility:** Feed a failing “Crash and hang detection” control through the report path; assert the exact failed case and underlying observation remain visible.
- [ ] **UC-M12.02-C059-T07 · Missing-result visibility:** Withhold a required “Crash and hang detection” measurement or target; verify the report uses unavailable/untested rather than a fabricated zero or passing value.
- [ ] **UC-M12.02-C059-T08 · Bounds and redaction:** Check “Crash and hang detection” report size and retention against “Outcome classes and detection latency”; remove secrets while retaining fixture and subject references.
- [ ] **UC-M12.02-C059-T09 · Report reconciliation:** Reconcile the “Crash and hang detection” summary with every underlying case record; account for the full planned denominator and all omitted scope.
- [ ] **UC-M12.02-C059-T10 · Qualification handoff:** Publish the “Crash and hang detection” report with measured observations, coverage limits and blockers; state which actual targets remain unqualified.

### UC-M12.02-C060 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for crash and hang detection; label unexecuted checks as untested.

- [ ] **UC-M12.02-C060-T01 · Evidence inventory:** List the “Crash and hang detection” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M12.02-C060-T02 · Artifact references:** Record the exact “Crash and hang detection” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M12.02-C060-T03 · Fixture references:** Attach the “Crash and hang detection” fixture IDs, input identities and oracle definition; preserve the source counterexample “The harness treats every nonzero exit as an expected reject” as a distinct evidence case.
- [ ] **UC-M12.02-C060-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Crash and hang detection”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M12.02-C060-T05 · Environment record:** Record the actual “Crash and hang detection” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M12.02-C060-T06 · Expected versus observed:** Pair every “Crash and hang detection” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M12.02-C060-T07 · Failure and limit records:** Attach “Crash and hang detection” change/failure and bounds evidence where required; include uncovered “Outcome classes and detection latency” and unresolved violations of “A timeout or crash cannot appear as an ordinary parser refusal”.
- [ ] **UC-M12.02-C060-T08 · Evidence hygiene:** Check the “Crash and hang detection” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M12.02-C060-T09 · Reproduction review:** Have the “Crash and hang detection” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M12.02-C060-T10 · Acceptance linkage:** Link the “Crash and hang detection” evidence to its parent and UC-M12.02 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 07. Finding preservation

**Source delivery:** Retain crashing inputs, seeds, commands and environment identities.

**Source invariant:** Every reported finding can be reproduced independently.

**Source negative case:** Only a screenshot of the crash survives the campaign.

**Source bounded quantities:** Finding bytes and reproduction records.

### UC-M12.02-C061 · Contract

**Original checklist item:** Define the qualification objective for finding preservation, including the actual target implementation, prerequisites, observable oracle and explicit exclusions.

- [ ] **UC-M12.02-C061-T01 · Scope statement:** Write the qualification question for “Finding preservation”; identify the actual target, claimed capability and observations that can answer that question.
- [ ] **UC-M12.02-C061-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Finding preservation”; record each producer, representation and missing-value meaning.
- [ ] **UC-M12.02-C061-T03 · Output inventory:** List the outputs of “Finding preservation” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M12.02-C061-T04 · Field dictionary:** Create a field-and-term dictionary for “Finding preservation”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M12.02-C061-T05 · Prerequisite contract:** Map “Finding preservation” to the source component prerequisites (UC-M07.04, UC-M08.02, UC-M09.06); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M12.02-C061-T06 · Authority map:** Identify who may produce, change and consume “Finding preservation”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M12.02-C061-T07 · Invariant clause:** Add a normative clause for “Finding preservation” that preserves “Every reported finding can be reproduced independently”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M12.02-C061-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Finding preservation”; include the source counterexample “Only a screenshot of the crash survives the campaign” and the intended safe disposition.
- [ ] **UC-M12.02-C061-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Finding bytes and reproduction records” in the “Finding preservation” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M12.02-C061-T10 · Contract review:** Review the “Finding preservation” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M12.02-C062 · Delivery

**Original checklist item:** Retain crashing inputs, seeds, commands and environment identities.

- [ ] **UC-M12.02-C062-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Finding preservation”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M12.02-C062-T02 · Change plan:** Break the source delivery for “Finding preservation” into concrete edit targets and reviewable outputs; keep the UC-M12.02 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M12.02-C062-T03 · Core artifact:** Implement the smallest selected-profile change for “Finding preservation” that realizes this source instruction: Retain crashing inputs, seeds, commands and environment identities.
- [ ] **UC-M12.02-C062-T04 · Concrete realization:** Trace “Finding preservation” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M12.02-C062-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Finding preservation” needed to preserve “Every reported finding can be reproduced independently”; record an enforcement gap where only a model exists.
- [ ] **UC-M12.02-C062-T06 · Dependency connection:** Connect the “Finding preservation” qualification artifact to production parser harnesses, resource-limited workers and retained seed corpora; record the target identity and what the harness actually exercises.
- [ ] **UC-M12.02-C062-T07 · Resource behavior:** Account for “Finding bytes and reproduction records” in “Finding preservation”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M12.02-C062-T08 · Delivery check:** Run a known-valid control and a deliberately failing control for “Finding preservation”; confirm the harness distinguishes their observed outcomes.
- [ ] **UC-M12.02-C062-T09 · Patch review:** Review the “Finding preservation” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M12.02-C062-T10 · Delivery handoff:** Publish the “Finding preservation” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M12.02-C063 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Every reported finding can be reproduced independently. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M12.02-C063-T01 · Named property:** Create a stable property/check name under this parent for “Finding preservation”; copy its required invariant exactly: “Every reported finding can be reproduced independently”.
- [ ] **UC-M12.02-C063-T02 · Observable terms:** Define each term in the “Finding preservation” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M12.02-C063-T03 · Precondition set:** List the preconditions under which “Every reported finding can be reproduced independently” must hold for “Finding preservation”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M12.02-C063-T04 · Transition coverage:** Map the “Finding preservation” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M12.02-C063-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Finding preservation”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M12.02-C063-T06 · Satisfying fixture:** Create a concrete “Finding preservation” case that satisfies “Every reported finding can be reproduced independently”; record its expected observation before running the assertion or review.
- [ ] **UC-M12.02-C063-T07 · Violating fixture:** Create the source counterexample “Only a screenshot of the crash survives the campaign” for “Finding preservation”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M12.02-C063-T08 · Enforcement evidence:** Exercise the “Finding preservation” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M12.02-C063-T09 · Regression linkage:** Link the “Finding preservation” property to changes in production parser harnesses, resource-limited workers and retained seed corpora; record which dependency or contract changes require rerunning it.
- [ ] **UC-M12.02-C063-T10 · Property disposition:** Compare the satisfying and violating “Finding preservation” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M12.02-C064 · Integration

**Original checklist item:** Integrate finding preservation with production parser harnesses, resource-limited workers and retained seed corpora; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M12.02-C064-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Finding preservation” across production parser harnesses, resource-limited workers and retained seed corpora; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M12.02-C064-T02 · Field mapping:** Map every “Finding preservation” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M12.02-C064-T03 · Prerequisite identities:** Record the actual prerequisites for “Finding preservation” (source dependency list: UC-M07.04, UC-M08.02, UC-M09.06); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M12.02-C064-T04 · Ownership agreement:** Specify who owns “Finding preservation” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M12.02-C064-T05 · Handoff implementation:** Connect “Finding preservation” through the mapped seam using the real adapter or explicit specification reference; preserve “Every reported finding can be reproduced independently” across the handoff.
- [ ] **UC-M12.02-C064-T06 · Absent-input case:** Omit one required “Finding preservation” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M12.02-C064-T07 · Stale-input case:** Supply an outdated “Finding preservation” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M12.02-C064-T08 · Incompatible-input case:** Supply an incompatible “Finding preservation” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M12.02-C064-T09 · Valid integration trace:** Run a valid “Finding preservation” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M12.02-C064-T10 · Seam review:** Reconcile the “Finding preservation” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M12.02-C065 · Valid-case test

**Original checklist item:** Run a known-valid control for finding preservation; verify that the harness reaches its intended target and compare observed measurements or verdicts with predeclared expectations.

- [ ] **UC-M12.02-C065-T01 · Valid fixture choice:** Choose a known-valid control for “Finding preservation”; document why it should pass and how it proves the harness reaches the intended target.
- [ ] **UC-M12.02-C065-T02 · Expected-result oracle:** Specify the “Finding preservation” expected result independently of the implementation output; include the property “Every reported finding can be reproduced independently” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M12.02-C065-T03 · Fixture material:** Create the concrete “Finding preservation” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M12.02-C065-T04 · Target preparation:** Prepare the “Finding preservation” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M12.02-C065-T05 · Initial-state record:** Record the initial “Finding preservation” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M12.02-C065-T06 · Valid-path execution:** Run the “Finding preservation” known-valid control on the identified target; retain enough observations to prove the correct target was exercised.
- [ ] **UC-M12.02-C065-T07 · Outcome comparison:** Compare every declared “Finding preservation” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M12.02-C065-T08 · State and bounds check:** Inspect the “Finding preservation” ownership/state effects and actual use of “Finding bytes and reproduction records”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M12.02-C065-T09 · Repeatability check:** Repeat the same “Finding preservation” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M12.02-C065-T10 · Positive evidence:** Attach the “Finding preservation” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M12.02-C066 · Negative test

**Original checklist item:** Negative case: Only a screenshot of the crash survives the campaign. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M12.02-C066-T01 · Adverse-case definition:** Create a test record for the exact “Finding preservation” source counterexample: “Only a screenshot of the crash survives the campaign”; state which precondition or invariant it challenges.
- [ ] **UC-M12.02-C066-T02 · Safe fixture boundary:** Define the contained test boundary for “Finding preservation”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M12.02-C066-T03 · Valid control:** Construct a valid “Finding preservation” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M12.02-C066-T04 · Minimal adverse input:** Derive the “Finding preservation” adverse fixture from the control with the smallest documented change needed to reproduce “Only a screenshot of the crash survives the campaign”; retain that change as reproducible data.
- [ ] **UC-M12.02-C066-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Finding preservation”; require “Every reported finding can be reproduced independently” and forbid a false-success verdict.
- [ ] **UC-M12.02-C066-T06 · Adverse execution:** Exercise the “Finding preservation” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M12.02-C066-T07 · Effect inspection:** Inspect “Finding preservation” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M12.02-C066-T08 · Refusal versus failure:** Confirm the “Finding preservation” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M12.02-C066-T09 · Reset and retention:** Restore only the disposable “Finding preservation” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M12.02-C066-T10 · Negative regression:** Register the “Finding preservation” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M12.02-C067 · Change / failure test

**Original checklist item:** Exercise finding preservation when a campaign worker crashes or hangs on a reproducible generated input; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M12.02-C067-T01 · Scenario record:** Write the “Finding preservation” change/failure scenario exactly as supplied: a campaign worker crashes or hangs on a reproducible generated input; identify the property that must remain true: “Every reported finding can be reproduced independently”.
- [ ] **UC-M12.02-C067-T02 · Baseline capture:** Create a known-valid “Finding preservation” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M12.02-C067-T03 · Injection map:** Locate the “Finding preservation” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M12.02-C067-T04 · Disposition oracle:** Define the legal intermediate and final “Finding preservation” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M12.02-C067-T05 · Controlled trigger:** Introduce the controlled “Finding preservation” scenario in the disposable fixture: a campaign worker crashes or hangs on a reproducible generated input; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M12.02-C067-T06 · Intermediate inspection:** Inspect the “Finding preservation” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M12.02-C067-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Finding preservation”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M12.02-C067-T08 · Stale-evidence cleanup:** Invalidate superseded “Finding preservation” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M12.02-C067-T09 · Repeat and compare:** Repeat the selected “Finding preservation” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M12.02-C067-T10 · Failure evidence:** Publish the “Finding preservation” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M12.02-C068 · Bounds

**Original checklist item:** Set a documented campaign budget for finding bytes and reproduction records; record actual consumption, incomplete coverage and the disposition when the budget is exhausted.

- [ ] **UC-M12.02-C068-T01 · Quantity inventory:** Create a measurement inventory for “Finding preservation”: “Finding bytes and reproduction records”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M12.02-C068-T02 · Measurement method:** Choose how to observe each “Finding preservation” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M12.02-C068-T03 · Budget decision:** Select justified campaign and target-resource budgets for “Finding preservation”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M12.02-C068-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Finding preservation” cases for “Finding bytes and reproduction records”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M12.02-C068-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Finding preservation” limit; preserve “Every reported finding can be reproduced independently”.
- [ ] **UC-M12.02-C068-T06 · Normal measurement:** Run or review the normal “Finding preservation” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M12.02-C068-T07 · At-limit measurement:** Exercise the “Finding preservation” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M12.02-C068-T08 · Over-limit measurement:** Exercise the “Finding preservation” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M12.02-C068-T09 · Uncovered-scope report:** List the “Finding preservation” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M12.02-C068-T10 · Limit evidence:** Publish the selected “Finding preservation” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M12.02-C069 · Diagnostics / review

**Original checklist item:** Report finding preservation results with executed, failed, skipped and unavailable cases separated; preserve the underlying observations and do not manufacture missing measurements.

- [ ] **UC-M12.02-C069-T01 · Result inventory:** Enumerate the required “Finding preservation” qualification cases and intended targets before aggregating results; keep the planned denominator visible.
- [ ] **UC-M12.02-C069-T02 · Verdict schema:** Define separate executed-pass, executed-fail, skipped, unavailable and untested outcomes for “Finding preservation”; document how incomplete cases block relevant claims.
- [ ] **UC-M12.02-C069-T03 · Identity fields:** Attach the actual target, fixture, configuration and revision identifiers to each “Finding preservation” result; do not attribute host-only evidence to a guest or another OS.
- [ ] **UC-M12.02-C069-T04 · Observation capture:** Capture bounded raw “Finding preservation” observations and harness errors; retain enough information to verify the reported oracle comparison.
- [ ] **UC-M12.02-C069-T05 · Aggregation rules:** Implement the “Finding preservation” count/reduction rule so failures and missing measurements cannot disappear; preserve “Every reported finding can be reproduced independently”.
- [ ] **UC-M12.02-C069-T06 · Failure visibility:** Feed a failing “Finding preservation” control through the report path; assert the exact failed case and underlying observation remain visible.
- [ ] **UC-M12.02-C069-T07 · Missing-result visibility:** Withhold a required “Finding preservation” measurement or target; verify the report uses unavailable/untested rather than a fabricated zero or passing value.
- [ ] **UC-M12.02-C069-T08 · Bounds and redaction:** Check “Finding preservation” report size and retention against “Finding bytes and reproduction records”; remove secrets while retaining fixture and subject references.
- [ ] **UC-M12.02-C069-T09 · Report reconciliation:** Reconcile the “Finding preservation” summary with every underlying case record; account for the full planned denominator and all omitted scope.
- [ ] **UC-M12.02-C069-T10 · Qualification handoff:** Publish the “Finding preservation” report with measured observations, coverage limits and blockers; state which actual targets remain unqualified.

### UC-M12.02-C070 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for finding preservation; label unexecuted checks as untested.

- [ ] **UC-M12.02-C070-T01 · Evidence inventory:** List the “Finding preservation” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M12.02-C070-T02 · Artifact references:** Record the exact “Finding preservation” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M12.02-C070-T03 · Fixture references:** Attach the “Finding preservation” fixture IDs, input identities and oracle definition; preserve the source counterexample “Only a screenshot of the crash survives the campaign” as a distinct evidence case.
- [ ] **UC-M12.02-C070-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Finding preservation”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M12.02-C070-T05 · Environment record:** Record the actual “Finding preservation” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M12.02-C070-T06 · Expected versus observed:** Pair every “Finding preservation” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M12.02-C070-T07 · Failure and limit records:** Attach “Finding preservation” change/failure and bounds evidence where required; include uncovered “Finding bytes and reproduction records” and unresolved violations of “Every reported finding can be reproduced independently”.
- [ ] **UC-M12.02-C070-T08 · Evidence hygiene:** Check the “Finding preservation” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M12.02-C070-T09 · Reproduction review:** Have the “Finding preservation” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M12.02-C070-T10 · Acceptance linkage:** Link the “Finding preservation” evidence to its parent and UC-M12.02 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 08. Corpus minimization

**Source delivery:** Reduce failing inputs without losing the triggering behavior or identity history.

**Source invariant:** A minimized case is verified to reproduce the same classified failure.

**Source negative case:** Minimization produces a different harmless parser error.

**Source bounded quantities:** Minimization steps and per-finding budget.

### UC-M12.02-C071 · Contract

**Original checklist item:** Define the qualification objective for corpus minimization, including the actual target implementation, prerequisites, observable oracle and explicit exclusions.

- [ ] **UC-M12.02-C071-T01 · Scope statement:** Write the qualification question for “Corpus minimization”; identify the actual target, claimed capability and observations that can answer that question.
- [ ] **UC-M12.02-C071-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Corpus minimization”; record each producer, representation and missing-value meaning.
- [ ] **UC-M12.02-C071-T03 · Output inventory:** List the outputs of “Corpus minimization” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M12.02-C071-T04 · Field dictionary:** Create a field-and-term dictionary for “Corpus minimization”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M12.02-C071-T05 · Prerequisite contract:** Map “Corpus minimization” to the source component prerequisites (UC-M07.04, UC-M08.02, UC-M09.06); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M12.02-C071-T06 · Authority map:** Identify who may produce, change and consume “Corpus minimization”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M12.02-C071-T07 · Invariant clause:** Add a normative clause for “Corpus minimization” that preserves “A minimized case is verified to reproduce the same classified failure”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M12.02-C071-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Corpus minimization”; include the source counterexample “Minimization produces a different harmless parser error” and the intended safe disposition.
- [ ] **UC-M12.02-C071-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Minimization steps and per-finding budget” in the “Corpus minimization” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M12.02-C071-T10 · Contract review:** Review the “Corpus minimization” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M12.02-C072 · Delivery

**Original checklist item:** Reduce failing inputs without losing the triggering behavior or identity history.

- [ ] **UC-M12.02-C072-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Corpus minimization”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M12.02-C072-T02 · Change plan:** Break the source delivery for “Corpus minimization” into concrete edit targets and reviewable outputs; keep the UC-M12.02 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M12.02-C072-T03 · Core artifact:** Implement the smallest selected-profile change for “Corpus minimization” that realizes this source instruction: Reduce failing inputs without losing the triggering behavior or identity history.
- [ ] **UC-M12.02-C072-T04 · Concrete realization:** Trace “Corpus minimization” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M12.02-C072-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Corpus minimization” needed to preserve “A minimized case is verified to reproduce the same classified failure”; record an enforcement gap where only a model exists.
- [ ] **UC-M12.02-C072-T06 · Dependency connection:** Connect the “Corpus minimization” qualification artifact to production parser harnesses, resource-limited workers and retained seed corpora; record the target identity and what the harness actually exercises.
- [ ] **UC-M12.02-C072-T07 · Resource behavior:** Account for “Minimization steps and per-finding budget” in “Corpus minimization”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M12.02-C072-T08 · Delivery check:** Run a known-valid control and a deliberately failing control for “Corpus minimization”; confirm the harness distinguishes their observed outcomes.
- [ ] **UC-M12.02-C072-T09 · Patch review:** Review the “Corpus minimization” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M12.02-C072-T10 · Delivery handoff:** Publish the “Corpus minimization” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M12.02-C073 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: A minimized case is verified to reproduce the same classified failure. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M12.02-C073-T01 · Named property:** Create a stable property/check name under this parent for “Corpus minimization”; copy its required invariant exactly: “A minimized case is verified to reproduce the same classified failure”.
- [ ] **UC-M12.02-C073-T02 · Observable terms:** Define each term in the “Corpus minimization” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M12.02-C073-T03 · Precondition set:** List the preconditions under which “A minimized case is verified to reproduce the same classified failure” must hold for “Corpus minimization”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M12.02-C073-T04 · Transition coverage:** Map the “Corpus minimization” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M12.02-C073-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Corpus minimization”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M12.02-C073-T06 · Satisfying fixture:** Create a concrete “Corpus minimization” case that satisfies “A minimized case is verified to reproduce the same classified failure”; record its expected observation before running the assertion or review.
- [ ] **UC-M12.02-C073-T07 · Violating fixture:** Create the source counterexample “Minimization produces a different harmless parser error” for “Corpus minimization”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M12.02-C073-T08 · Enforcement evidence:** Exercise the “Corpus minimization” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M12.02-C073-T09 · Regression linkage:** Link the “Corpus minimization” property to changes in production parser harnesses, resource-limited workers and retained seed corpora; record which dependency or contract changes require rerunning it.
- [ ] **UC-M12.02-C073-T10 · Property disposition:** Compare the satisfying and violating “Corpus minimization” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M12.02-C074 · Integration

**Original checklist item:** Integrate corpus minimization with production parser harnesses, resource-limited workers and retained seed corpora; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M12.02-C074-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Corpus minimization” across production parser harnesses, resource-limited workers and retained seed corpora; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M12.02-C074-T02 · Field mapping:** Map every “Corpus minimization” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M12.02-C074-T03 · Prerequisite identities:** Record the actual prerequisites for “Corpus minimization” (source dependency list: UC-M07.04, UC-M08.02, UC-M09.06); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M12.02-C074-T04 · Ownership agreement:** Specify who owns “Corpus minimization” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M12.02-C074-T05 · Handoff implementation:** Connect “Corpus minimization” through the mapped seam using the real adapter or explicit specification reference; preserve “A minimized case is verified to reproduce the same classified failure” across the handoff.
- [ ] **UC-M12.02-C074-T06 · Absent-input case:** Omit one required “Corpus minimization” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M12.02-C074-T07 · Stale-input case:** Supply an outdated “Corpus minimization” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M12.02-C074-T08 · Incompatible-input case:** Supply an incompatible “Corpus minimization” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M12.02-C074-T09 · Valid integration trace:** Run a valid “Corpus minimization” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M12.02-C074-T10 · Seam review:** Reconcile the “Corpus minimization” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M12.02-C075 · Valid-case test

**Original checklist item:** Run a known-valid control for corpus minimization; verify that the harness reaches its intended target and compare observed measurements or verdicts with predeclared expectations.

- [ ] **UC-M12.02-C075-T01 · Valid fixture choice:** Choose a known-valid control for “Corpus minimization”; document why it should pass and how it proves the harness reaches the intended target.
- [ ] **UC-M12.02-C075-T02 · Expected-result oracle:** Specify the “Corpus minimization” expected result independently of the implementation output; include the property “A minimized case is verified to reproduce the same classified failure” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M12.02-C075-T03 · Fixture material:** Create the concrete “Corpus minimization” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M12.02-C075-T04 · Target preparation:** Prepare the “Corpus minimization” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M12.02-C075-T05 · Initial-state record:** Record the initial “Corpus minimization” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M12.02-C075-T06 · Valid-path execution:** Run the “Corpus minimization” known-valid control on the identified target; retain enough observations to prove the correct target was exercised.
- [ ] **UC-M12.02-C075-T07 · Outcome comparison:** Compare every declared “Corpus minimization” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M12.02-C075-T08 · State and bounds check:** Inspect the “Corpus minimization” ownership/state effects and actual use of “Minimization steps and per-finding budget”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M12.02-C075-T09 · Repeatability check:** Repeat the same “Corpus minimization” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M12.02-C075-T10 · Positive evidence:** Attach the “Corpus minimization” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M12.02-C076 · Negative test

**Original checklist item:** Negative case: Minimization produces a different harmless parser error. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M12.02-C076-T01 · Adverse-case definition:** Create a test record for the exact “Corpus minimization” source counterexample: “Minimization produces a different harmless parser error”; state which precondition or invariant it challenges.
- [ ] **UC-M12.02-C076-T02 · Safe fixture boundary:** Define the contained test boundary for “Corpus minimization”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M12.02-C076-T03 · Valid control:** Construct a valid “Corpus minimization” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M12.02-C076-T04 · Minimal adverse input:** Derive the “Corpus minimization” adverse fixture from the control with the smallest documented change needed to reproduce “Minimization produces a different harmless parser error”; retain that change as reproducible data.
- [ ] **UC-M12.02-C076-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Corpus minimization”; require “A minimized case is verified to reproduce the same classified failure” and forbid a false-success verdict.
- [ ] **UC-M12.02-C076-T06 · Adverse execution:** Exercise the “Corpus minimization” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M12.02-C076-T07 · Effect inspection:** Inspect “Corpus minimization” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M12.02-C076-T08 · Refusal versus failure:** Confirm the “Corpus minimization” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M12.02-C076-T09 · Reset and retention:** Restore only the disposable “Corpus minimization” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M12.02-C076-T10 · Negative regression:** Register the “Corpus minimization” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M12.02-C077 · Change / failure test

**Original checklist item:** Exercise corpus minimization when a campaign worker crashes or hangs on a reproducible generated input; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M12.02-C077-T01 · Scenario record:** Write the “Corpus minimization” change/failure scenario exactly as supplied: a campaign worker crashes or hangs on a reproducible generated input; identify the property that must remain true: “A minimized case is verified to reproduce the same classified failure”.
- [ ] **UC-M12.02-C077-T02 · Baseline capture:** Create a known-valid “Corpus minimization” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M12.02-C077-T03 · Injection map:** Locate the “Corpus minimization” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M12.02-C077-T04 · Disposition oracle:** Define the legal intermediate and final “Corpus minimization” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M12.02-C077-T05 · Controlled trigger:** Introduce the controlled “Corpus minimization” scenario in the disposable fixture: a campaign worker crashes or hangs on a reproducible generated input; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M12.02-C077-T06 · Intermediate inspection:** Inspect the “Corpus minimization” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M12.02-C077-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Corpus minimization”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M12.02-C077-T08 · Stale-evidence cleanup:** Invalidate superseded “Corpus minimization” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M12.02-C077-T09 · Repeat and compare:** Repeat the selected “Corpus minimization” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M12.02-C077-T10 · Failure evidence:** Publish the “Corpus minimization” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M12.02-C078 · Bounds

**Original checklist item:** Set a documented campaign budget for minimization steps and per-finding budget; record actual consumption, incomplete coverage and the disposition when the budget is exhausted.

- [ ] **UC-M12.02-C078-T01 · Quantity inventory:** Create a measurement inventory for “Corpus minimization”: “Minimization steps and per-finding budget”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M12.02-C078-T02 · Measurement method:** Choose how to observe each “Corpus minimization” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M12.02-C078-T03 · Budget decision:** Select justified campaign and target-resource budgets for “Corpus minimization”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M12.02-C078-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Corpus minimization” cases for “Minimization steps and per-finding budget”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M12.02-C078-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Corpus minimization” limit; preserve “A minimized case is verified to reproduce the same classified failure”.
- [ ] **UC-M12.02-C078-T06 · Normal measurement:** Run or review the normal “Corpus minimization” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M12.02-C078-T07 · At-limit measurement:** Exercise the “Corpus minimization” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M12.02-C078-T08 · Over-limit measurement:** Exercise the “Corpus minimization” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M12.02-C078-T09 · Uncovered-scope report:** List the “Corpus minimization” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M12.02-C078-T10 · Limit evidence:** Publish the selected “Corpus minimization” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M12.02-C079 · Diagnostics / review

**Original checklist item:** Report corpus minimization results with executed, failed, skipped and unavailable cases separated; preserve the underlying observations and do not manufacture missing measurements.

- [ ] **UC-M12.02-C079-T01 · Result inventory:** Enumerate the required “Corpus minimization” qualification cases and intended targets before aggregating results; keep the planned denominator visible.
- [ ] **UC-M12.02-C079-T02 · Verdict schema:** Define separate executed-pass, executed-fail, skipped, unavailable and untested outcomes for “Corpus minimization”; document how incomplete cases block relevant claims.
- [ ] **UC-M12.02-C079-T03 · Identity fields:** Attach the actual target, fixture, configuration and revision identifiers to each “Corpus minimization” result; do not attribute host-only evidence to a guest or another OS.
- [ ] **UC-M12.02-C079-T04 · Observation capture:** Capture bounded raw “Corpus minimization” observations and harness errors; retain enough information to verify the reported oracle comparison.
- [ ] **UC-M12.02-C079-T05 · Aggregation rules:** Implement the “Corpus minimization” count/reduction rule so failures and missing measurements cannot disappear; preserve “A minimized case is verified to reproduce the same classified failure”.
- [ ] **UC-M12.02-C079-T06 · Failure visibility:** Feed a failing “Corpus minimization” control through the report path; assert the exact failed case and underlying observation remain visible.
- [ ] **UC-M12.02-C079-T07 · Missing-result visibility:** Withhold a required “Corpus minimization” measurement or target; verify the report uses unavailable/untested rather than a fabricated zero or passing value.
- [ ] **UC-M12.02-C079-T08 · Bounds and redaction:** Check “Corpus minimization” report size and retention against “Minimization steps and per-finding budget”; remove secrets while retaining fixture and subject references.
- [ ] **UC-M12.02-C079-T09 · Report reconciliation:** Reconcile the “Corpus minimization” summary with every underlying case record; account for the full planned denominator and all omitted scope.
- [ ] **UC-M12.02-C079-T10 · Qualification handoff:** Publish the “Corpus minimization” report with measured observations, coverage limits and blockers; state which actual targets remain unqualified.

### UC-M12.02-C080 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for corpus minimization; label unexecuted checks as untested.

- [ ] **UC-M12.02-C080-T01 · Evidence inventory:** List the “Corpus minimization” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M12.02-C080-T02 · Artifact references:** Record the exact “Corpus minimization” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M12.02-C080-T03 · Fixture references:** Attach the “Corpus minimization” fixture IDs, input identities and oracle definition; preserve the source counterexample “Minimization produces a different harmless parser error” as a distinct evidence case.
- [ ] **UC-M12.02-C080-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Corpus minimization”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M12.02-C080-T05 · Environment record:** Record the actual “Corpus minimization” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M12.02-C080-T06 · Expected versus observed:** Pair every “Corpus minimization” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M12.02-C080-T07 · Failure and limit records:** Attach “Corpus minimization” change/failure and bounds evidence where required; include uncovered “Minimization steps and per-finding budget” and unresolved violations of “A minimized case is verified to reproduce the same classified failure”.
- [ ] **UC-M12.02-C080-T08 · Evidence hygiene:** Check the “Corpus minimization” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M12.02-C080-T09 · Reproduction review:** Have the “Corpus minimization” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M12.02-C080-T10 · Acceptance linkage:** Link the “Corpus minimization” evidence to its parent and UC-M12.02 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 09. Regression integration

**Source delivery:** Add resolved cases and relevant adjacent boundaries to required regression tests.

**Source invariant:** A closed finding remains covered in subsequent parser changes.

**Source negative case:** A fixed crash disappears from the retained corpus.

**Source bounded quantities:** Regression cases and execution time.

### UC-M12.02-C081 · Contract

**Original checklist item:** Define the qualification objective for regression integration, including the actual target implementation, prerequisites, observable oracle and explicit exclusions.

- [ ] **UC-M12.02-C081-T01 · Scope statement:** Write the qualification question for “Regression integration”; identify the actual target, claimed capability and observations that can answer that question.
- [ ] **UC-M12.02-C081-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Regression integration”; record each producer, representation and missing-value meaning.
- [ ] **UC-M12.02-C081-T03 · Output inventory:** List the outputs of “Regression integration” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M12.02-C081-T04 · Field dictionary:** Create a field-and-term dictionary for “Regression integration”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M12.02-C081-T05 · Prerequisite contract:** Map “Regression integration” to the source component prerequisites (UC-M07.04, UC-M08.02, UC-M09.06); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M12.02-C081-T06 · Authority map:** Identify who may produce, change and consume “Regression integration”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M12.02-C081-T07 · Invariant clause:** Add a normative clause for “Regression integration” that preserves “A closed finding remains covered in subsequent parser changes”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M12.02-C081-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Regression integration”; include the source counterexample “A fixed crash disappears from the retained corpus” and the intended safe disposition.
- [ ] **UC-M12.02-C081-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Regression cases and execution time” in the “Regression integration” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M12.02-C081-T10 · Contract review:** Review the “Regression integration” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M12.02-C082 · Delivery

**Original checklist item:** Add resolved cases and relevant adjacent boundaries to required regression tests.

- [ ] **UC-M12.02-C082-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Regression integration”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M12.02-C082-T02 · Change plan:** Break the source delivery for “Regression integration” into concrete edit targets and reviewable outputs; keep the UC-M12.02 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M12.02-C082-T03 · Core artifact:** Implement the smallest selected-profile change for “Regression integration” that realizes this source instruction: Add resolved cases and relevant adjacent boundaries to required regression tests.
- [ ] **UC-M12.02-C082-T04 · Concrete realization:** Trace “Regression integration” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M12.02-C082-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Regression integration” needed to preserve “A closed finding remains covered in subsequent parser changes”; record an enforcement gap where only a model exists.
- [ ] **UC-M12.02-C082-T06 · Dependency connection:** Connect the “Regression integration” qualification artifact to production parser harnesses, resource-limited workers and retained seed corpora; record the target identity and what the harness actually exercises.
- [ ] **UC-M12.02-C082-T07 · Resource behavior:** Account for “Regression cases and execution time” in “Regression integration”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M12.02-C082-T08 · Delivery check:** Run a known-valid control and a deliberately failing control for “Regression integration”; confirm the harness distinguishes their observed outcomes.
- [ ] **UC-M12.02-C082-T09 · Patch review:** Review the “Regression integration” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M12.02-C082-T10 · Delivery handoff:** Publish the “Regression integration” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M12.02-C083 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: A closed finding remains covered in subsequent parser changes. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M12.02-C083-T01 · Named property:** Create a stable property/check name under this parent for “Regression integration”; copy its required invariant exactly: “A closed finding remains covered in subsequent parser changes”.
- [ ] **UC-M12.02-C083-T02 · Observable terms:** Define each term in the “Regression integration” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M12.02-C083-T03 · Precondition set:** List the preconditions under which “A closed finding remains covered in subsequent parser changes” must hold for “Regression integration”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M12.02-C083-T04 · Transition coverage:** Map the “Regression integration” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M12.02-C083-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Regression integration”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M12.02-C083-T06 · Satisfying fixture:** Create a concrete “Regression integration” case that satisfies “A closed finding remains covered in subsequent parser changes”; record its expected observation before running the assertion or review.
- [ ] **UC-M12.02-C083-T07 · Violating fixture:** Create the source counterexample “A fixed crash disappears from the retained corpus” for “Regression integration”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M12.02-C083-T08 · Enforcement evidence:** Exercise the “Regression integration” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M12.02-C083-T09 · Regression linkage:** Link the “Regression integration” property to changes in production parser harnesses, resource-limited workers and retained seed corpora; record which dependency or contract changes require rerunning it.
- [ ] **UC-M12.02-C083-T10 · Property disposition:** Compare the satisfying and violating “Regression integration” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M12.02-C084 · Integration

**Original checklist item:** Integrate regression integration with production parser harnesses, resource-limited workers and retained seed corpora; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M12.02-C084-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Regression integration” across production parser harnesses, resource-limited workers and retained seed corpora; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M12.02-C084-T02 · Field mapping:** Map every “Regression integration” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M12.02-C084-T03 · Prerequisite identities:** Record the actual prerequisites for “Regression integration” (source dependency list: UC-M07.04, UC-M08.02, UC-M09.06); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M12.02-C084-T04 · Ownership agreement:** Specify who owns “Regression integration” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M12.02-C084-T05 · Handoff implementation:** Connect “Regression integration” through the mapped seam using the real adapter or explicit specification reference; preserve “A closed finding remains covered in subsequent parser changes” across the handoff.
- [ ] **UC-M12.02-C084-T06 · Absent-input case:** Omit one required “Regression integration” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M12.02-C084-T07 · Stale-input case:** Supply an outdated “Regression integration” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M12.02-C084-T08 · Incompatible-input case:** Supply an incompatible “Regression integration” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M12.02-C084-T09 · Valid integration trace:** Run a valid “Regression integration” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M12.02-C084-T10 · Seam review:** Reconcile the “Regression integration” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M12.02-C085 · Valid-case test

**Original checklist item:** Run a known-valid control for regression integration; verify that the harness reaches its intended target and compare observed measurements or verdicts with predeclared expectations.

- [ ] **UC-M12.02-C085-T01 · Valid fixture choice:** Choose a known-valid control for “Regression integration”; document why it should pass and how it proves the harness reaches the intended target.
- [ ] **UC-M12.02-C085-T02 · Expected-result oracle:** Specify the “Regression integration” expected result independently of the implementation output; include the property “A closed finding remains covered in subsequent parser changes” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M12.02-C085-T03 · Fixture material:** Create the concrete “Regression integration” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M12.02-C085-T04 · Target preparation:** Prepare the “Regression integration” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M12.02-C085-T05 · Initial-state record:** Record the initial “Regression integration” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M12.02-C085-T06 · Valid-path execution:** Run the “Regression integration” known-valid control on the identified target; retain enough observations to prove the correct target was exercised.
- [ ] **UC-M12.02-C085-T07 · Outcome comparison:** Compare every declared “Regression integration” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M12.02-C085-T08 · State and bounds check:** Inspect the “Regression integration” ownership/state effects and actual use of “Regression cases and execution time”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M12.02-C085-T09 · Repeatability check:** Repeat the same “Regression integration” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M12.02-C085-T10 · Positive evidence:** Attach the “Regression integration” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M12.02-C086 · Negative test

**Original checklist item:** Negative case: A fixed crash disappears from the retained corpus. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M12.02-C086-T01 · Adverse-case definition:** Create a test record for the exact “Regression integration” source counterexample: “A fixed crash disappears from the retained corpus”; state which precondition or invariant it challenges.
- [ ] **UC-M12.02-C086-T02 · Safe fixture boundary:** Define the contained test boundary for “Regression integration”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M12.02-C086-T03 · Valid control:** Construct a valid “Regression integration” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M12.02-C086-T04 · Minimal adverse input:** Derive the “Regression integration” adverse fixture from the control with the smallest documented change needed to reproduce “A fixed crash disappears from the retained corpus”; retain that change as reproducible data.
- [ ] **UC-M12.02-C086-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Regression integration”; require “A closed finding remains covered in subsequent parser changes” and forbid a false-success verdict.
- [ ] **UC-M12.02-C086-T06 · Adverse execution:** Exercise the “Regression integration” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M12.02-C086-T07 · Effect inspection:** Inspect “Regression integration” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M12.02-C086-T08 · Refusal versus failure:** Confirm the “Regression integration” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M12.02-C086-T09 · Reset and retention:** Restore only the disposable “Regression integration” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M12.02-C086-T10 · Negative regression:** Register the “Regression integration” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M12.02-C087 · Change / failure test

**Original checklist item:** Exercise regression integration when a campaign worker crashes or hangs on a reproducible generated input; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M12.02-C087-T01 · Scenario record:** Write the “Regression integration” change/failure scenario exactly as supplied: a campaign worker crashes or hangs on a reproducible generated input; identify the property that must remain true: “A closed finding remains covered in subsequent parser changes”.
- [ ] **UC-M12.02-C087-T02 · Baseline capture:** Create a known-valid “Regression integration” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M12.02-C087-T03 · Injection map:** Locate the “Regression integration” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M12.02-C087-T04 · Disposition oracle:** Define the legal intermediate and final “Regression integration” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M12.02-C087-T05 · Controlled trigger:** Introduce the controlled “Regression integration” scenario in the disposable fixture: a campaign worker crashes or hangs on a reproducible generated input; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M12.02-C087-T06 · Intermediate inspection:** Inspect the “Regression integration” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M12.02-C087-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Regression integration”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M12.02-C087-T08 · Stale-evidence cleanup:** Invalidate superseded “Regression integration” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M12.02-C087-T09 · Repeat and compare:** Repeat the selected “Regression integration” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M12.02-C087-T10 · Failure evidence:** Publish the “Regression integration” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M12.02-C088 · Bounds

**Original checklist item:** Set a documented campaign budget for regression cases and execution time; record actual consumption, incomplete coverage and the disposition when the budget is exhausted.

- [ ] **UC-M12.02-C088-T01 · Quantity inventory:** Create a measurement inventory for “Regression integration”: “Regression cases and execution time”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M12.02-C088-T02 · Measurement method:** Choose how to observe each “Regression integration” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M12.02-C088-T03 · Budget decision:** Select justified campaign and target-resource budgets for “Regression integration”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M12.02-C088-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Regression integration” cases for “Regression cases and execution time”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M12.02-C088-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Regression integration” limit; preserve “A closed finding remains covered in subsequent parser changes”.
- [ ] **UC-M12.02-C088-T06 · Normal measurement:** Run or review the normal “Regression integration” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M12.02-C088-T07 · At-limit measurement:** Exercise the “Regression integration” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M12.02-C088-T08 · Over-limit measurement:** Exercise the “Regression integration” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M12.02-C088-T09 · Uncovered-scope report:** List the “Regression integration” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M12.02-C088-T10 · Limit evidence:** Publish the selected “Regression integration” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M12.02-C089 · Diagnostics / review

**Original checklist item:** Report regression integration results with executed, failed, skipped and unavailable cases separated; preserve the underlying observations and do not manufacture missing measurements.

- [ ] **UC-M12.02-C089-T01 · Result inventory:** Enumerate the required “Regression integration” qualification cases and intended targets before aggregating results; keep the planned denominator visible.
- [ ] **UC-M12.02-C089-T02 · Verdict schema:** Define separate executed-pass, executed-fail, skipped, unavailable and untested outcomes for “Regression integration”; document how incomplete cases block relevant claims.
- [ ] **UC-M12.02-C089-T03 · Identity fields:** Attach the actual target, fixture, configuration and revision identifiers to each “Regression integration” result; do not attribute host-only evidence to a guest or another OS.
- [ ] **UC-M12.02-C089-T04 · Observation capture:** Capture bounded raw “Regression integration” observations and harness errors; retain enough information to verify the reported oracle comparison.
- [ ] **UC-M12.02-C089-T05 · Aggregation rules:** Implement the “Regression integration” count/reduction rule so failures and missing measurements cannot disappear; preserve “A closed finding remains covered in subsequent parser changes”.
- [ ] **UC-M12.02-C089-T06 · Failure visibility:** Feed a failing “Regression integration” control through the report path; assert the exact failed case and underlying observation remain visible.
- [ ] **UC-M12.02-C089-T07 · Missing-result visibility:** Withhold a required “Regression integration” measurement or target; verify the report uses unavailable/untested rather than a fabricated zero or passing value.
- [ ] **UC-M12.02-C089-T08 · Bounds and redaction:** Check “Regression integration” report size and retention against “Regression cases and execution time”; remove secrets while retaining fixture and subject references.
- [ ] **UC-M12.02-C089-T09 · Report reconciliation:** Reconcile the “Regression integration” summary with every underlying case record; account for the full planned denominator and all omitted scope.
- [ ] **UC-M12.02-C089-T10 · Qualification handoff:** Publish the “Regression integration” report with measured observations, coverage limits and blockers; state which actual targets remain unqualified.

### UC-M12.02-C090 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for regression integration; label unexecuted checks as untested.

- [ ] **UC-M12.02-C090-T01 · Evidence inventory:** List the “Regression integration” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M12.02-C090-T02 · Artifact references:** Record the exact “Regression integration” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M12.02-C090-T03 · Fixture references:** Attach the “Regression integration” fixture IDs, input identities and oracle definition; preserve the source counterexample “A fixed crash disappears from the retained corpus” as a distinct evidence case.
- [ ] **UC-M12.02-C090-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Regression integration”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M12.02-C090-T05 · Environment record:** Record the actual “Regression integration” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M12.02-C090-T06 · Expected versus observed:** Pair every “Regression integration” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M12.02-C090-T07 · Failure and limit records:** Attach “Regression integration” change/failure and bounds evidence where required; include uncovered “Regression cases and execution time” and unresolved violations of “A closed finding remains covered in subsequent parser changes”.
- [ ] **UC-M12.02-C090-T08 · Evidence hygiene:** Check the “Regression integration” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M12.02-C090-T09 · Reproduction review:** Have the “Regression integration” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M12.02-C090-T10 · Acceptance linkage:** Link the “Regression integration” evidence to its parent and UC-M12.02 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 10. Campaign evidence gate

**Source delivery:** Publish budget, seeds, targets, outcomes and unresolved findings.

**Source invariant:** No unexplained crash, hang, overread or unbounded allocation is hidden.

**Source negative case:** A budgeted run has unexplained timeouts but is summarized as clean.

**Source bounded quantities:** Campaign duration and required target coverage.

### UC-M12.02-C091 · Contract

**Original checklist item:** Define the qualification objective for campaign evidence gate, including the actual target implementation, prerequisites, observable oracle and explicit exclusions.

- [ ] **UC-M12.02-C091-T01 · Scope statement:** Write the qualification question for “Campaign evidence gate”; identify the actual target, claimed capability and observations that can answer that question.
- [ ] **UC-M12.02-C091-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Campaign evidence gate”; record each producer, representation and missing-value meaning.
- [ ] **UC-M12.02-C091-T03 · Output inventory:** List the outputs of “Campaign evidence gate” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M12.02-C091-T04 · Field dictionary:** Create a field-and-term dictionary for “Campaign evidence gate”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M12.02-C091-T05 · Prerequisite contract:** Map “Campaign evidence gate” to the source component prerequisites (UC-M07.04, UC-M08.02, UC-M09.06); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M12.02-C091-T06 · Authority map:** Identify who may produce, change and consume “Campaign evidence gate”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M12.02-C091-T07 · Invariant clause:** Add a normative clause for “Campaign evidence gate” that preserves “No unexplained crash, hang, overread or unbounded allocation is hidden”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M12.02-C091-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Campaign evidence gate”; include the source counterexample “A budgeted run has unexplained timeouts but is summarized as clean” and the intended safe disposition.
- [ ] **UC-M12.02-C091-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Campaign duration and required target coverage” in the “Campaign evidence gate” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M12.02-C091-T10 · Contract review:** Review the “Campaign evidence gate” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M12.02-C092 · Delivery

**Original checklist item:** Publish budget, seeds, targets, outcomes and unresolved findings.

- [ ] **UC-M12.02-C092-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Campaign evidence gate”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M12.02-C092-T02 · Change plan:** Break the source delivery for “Campaign evidence gate” into concrete edit targets and reviewable outputs; keep the UC-M12.02 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M12.02-C092-T03 · Core artifact:** Create the “Campaign evidence gate” output artifact for this source instruction: Publish budget, seeds, targets, outcomes and unresolved findings.
- [ ] **UC-M12.02-C092-T04 · Concrete realization:** Populate the “Campaign evidence gate” artifact from identified observations; keep unknown, failed and unexecuted results distinct and exclude unapproved sensitive material.
- [ ] **UC-M12.02-C092-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Campaign evidence gate” needed to preserve “No unexplained crash, hang, overread or unbounded allocation is hidden”; record an enforcement gap where only a model exists.
- [ ] **UC-M12.02-C092-T06 · Dependency connection:** Connect the “Campaign evidence gate” qualification artifact to production parser harnesses, resource-limited workers and retained seed corpora; record the target identity and what the harness actually exercises.
- [ ] **UC-M12.02-C092-T07 · Resource behavior:** Account for “Campaign duration and required target coverage” in “Campaign evidence gate”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M12.02-C092-T08 · Delivery check:** Run a known-valid control and a deliberately failing control for “Campaign evidence gate”; confirm the harness distinguishes their observed outcomes.
- [ ] **UC-M12.02-C092-T09 · Patch review:** Review the “Campaign evidence gate” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M12.02-C092-T10 · Delivery handoff:** Publish the “Campaign evidence gate” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M12.02-C093 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: No unexplained crash, hang, overread or unbounded allocation is hidden. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M12.02-C093-T01 · Named property:** Create a stable property/check name under this parent for “Campaign evidence gate”; copy its required invariant exactly: “No unexplained crash, hang, overread or unbounded allocation is hidden”.
- [ ] **UC-M12.02-C093-T02 · Observable terms:** Define each term in the “Campaign evidence gate” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M12.02-C093-T03 · Precondition set:** List the preconditions under which “No unexplained crash, hang, overread or unbounded allocation is hidden” must hold for “Campaign evidence gate”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M12.02-C093-T04 · Transition coverage:** Map the “Campaign evidence gate” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M12.02-C093-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Campaign evidence gate”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M12.02-C093-T06 · Satisfying fixture:** Create a concrete “Campaign evidence gate” case that satisfies “No unexplained crash, hang, overread or unbounded allocation is hidden”; record its expected observation before running the assertion or review.
- [ ] **UC-M12.02-C093-T07 · Violating fixture:** Create the source counterexample “A budgeted run has unexplained timeouts but is summarized as clean” for “Campaign evidence gate”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M12.02-C093-T08 · Enforcement evidence:** Exercise the “Campaign evidence gate” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M12.02-C093-T09 · Regression linkage:** Link the “Campaign evidence gate” property to changes in production parser harnesses, resource-limited workers and retained seed corpora; record which dependency or contract changes require rerunning it.
- [ ] **UC-M12.02-C093-T10 · Property disposition:** Compare the satisfying and violating “Campaign evidence gate” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M12.02-C094 · Integration

**Original checklist item:** Integrate campaign evidence gate with production parser harnesses, resource-limited workers and retained seed corpora; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M12.02-C094-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Campaign evidence gate” across production parser harnesses, resource-limited workers and retained seed corpora; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M12.02-C094-T02 · Field mapping:** Map every “Campaign evidence gate” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M12.02-C094-T03 · Prerequisite identities:** Record the actual prerequisites for “Campaign evidence gate” (source dependency list: UC-M07.04, UC-M08.02, UC-M09.06); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M12.02-C094-T04 · Ownership agreement:** Specify who owns “Campaign evidence gate” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M12.02-C094-T05 · Handoff implementation:** Connect “Campaign evidence gate” through the mapped seam using the real adapter or explicit specification reference; preserve “No unexplained crash, hang, overread or unbounded allocation is hidden” across the handoff.
- [ ] **UC-M12.02-C094-T06 · Absent-input case:** Omit one required “Campaign evidence gate” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M12.02-C094-T07 · Stale-input case:** Supply an outdated “Campaign evidence gate” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M12.02-C094-T08 · Incompatible-input case:** Supply an incompatible “Campaign evidence gate” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M12.02-C094-T09 · Valid integration trace:** Run a valid “Campaign evidence gate” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M12.02-C094-T10 · Seam review:** Reconcile the “Campaign evidence gate” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M12.02-C095 · Valid-case test

**Original checklist item:** Run a known-valid control for campaign evidence gate; verify that the harness reaches its intended target and compare observed measurements or verdicts with predeclared expectations.

- [ ] **UC-M12.02-C095-T01 · Valid fixture choice:** Choose a known-valid control for “Campaign evidence gate”; document why it should pass and how it proves the harness reaches the intended target.
- [ ] **UC-M12.02-C095-T02 · Expected-result oracle:** Specify the “Campaign evidence gate” expected result independently of the implementation output; include the property “No unexplained crash, hang, overread or unbounded allocation is hidden” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M12.02-C095-T03 · Fixture material:** Create the concrete “Campaign evidence gate” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M12.02-C095-T04 · Target preparation:** Prepare the “Campaign evidence gate” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M12.02-C095-T05 · Initial-state record:** Record the initial “Campaign evidence gate” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M12.02-C095-T06 · Valid-path execution:** Run the “Campaign evidence gate” known-valid control on the identified target; retain enough observations to prove the correct target was exercised.
- [ ] **UC-M12.02-C095-T07 · Outcome comparison:** Compare every declared “Campaign evidence gate” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M12.02-C095-T08 · State and bounds check:** Inspect the “Campaign evidence gate” ownership/state effects and actual use of “Campaign duration and required target coverage”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M12.02-C095-T09 · Repeatability check:** Repeat the same “Campaign evidence gate” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M12.02-C095-T10 · Positive evidence:** Attach the “Campaign evidence gate” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M12.02-C096 · Negative test

**Original checklist item:** Negative case: A budgeted run has unexplained timeouts but is summarized as clean. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M12.02-C096-T01 · Adverse-case definition:** Create a test record for the exact “Campaign evidence gate” source counterexample: “A budgeted run has unexplained timeouts but is summarized as clean”; state which precondition or invariant it challenges.
- [ ] **UC-M12.02-C096-T02 · Safe fixture boundary:** Define the contained test boundary for “Campaign evidence gate”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M12.02-C096-T03 · Valid control:** Construct a valid “Campaign evidence gate” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M12.02-C096-T04 · Minimal adverse input:** Derive the “Campaign evidence gate” adverse fixture from the control with the smallest documented change needed to reproduce “A budgeted run has unexplained timeouts but is summarized as clean”; retain that change as reproducible data.
- [ ] **UC-M12.02-C096-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Campaign evidence gate”; require “No unexplained crash, hang, overread or unbounded allocation is hidden” and forbid a false-success verdict.
- [ ] **UC-M12.02-C096-T06 · Adverse execution:** Exercise the “Campaign evidence gate” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M12.02-C096-T07 · Effect inspection:** Inspect “Campaign evidence gate” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M12.02-C096-T08 · Refusal versus failure:** Confirm the “Campaign evidence gate” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M12.02-C096-T09 · Reset and retention:** Restore only the disposable “Campaign evidence gate” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M12.02-C096-T10 · Negative regression:** Register the “Campaign evidence gate” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M12.02-C097 · Change / failure test

**Original checklist item:** Exercise campaign evidence gate when a campaign worker crashes or hangs on a reproducible generated input; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M12.02-C097-T01 · Scenario record:** Write the “Campaign evidence gate” change/failure scenario exactly as supplied: a campaign worker crashes or hangs on a reproducible generated input; identify the property that must remain true: “No unexplained crash, hang, overread or unbounded allocation is hidden”.
- [ ] **UC-M12.02-C097-T02 · Baseline capture:** Create a known-valid “Campaign evidence gate” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M12.02-C097-T03 · Injection map:** Locate the “Campaign evidence gate” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M12.02-C097-T04 · Disposition oracle:** Define the legal intermediate and final “Campaign evidence gate” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M12.02-C097-T05 · Controlled trigger:** Introduce the controlled “Campaign evidence gate” scenario in the disposable fixture: a campaign worker crashes or hangs on a reproducible generated input; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M12.02-C097-T06 · Intermediate inspection:** Inspect the “Campaign evidence gate” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M12.02-C097-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Campaign evidence gate”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M12.02-C097-T08 · Stale-evidence cleanup:** Invalidate superseded “Campaign evidence gate” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M12.02-C097-T09 · Repeat and compare:** Repeat the selected “Campaign evidence gate” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M12.02-C097-T10 · Failure evidence:** Publish the “Campaign evidence gate” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M12.02-C098 · Bounds

**Original checklist item:** Set a documented campaign budget for campaign duration and required target coverage; record actual consumption, incomplete coverage and the disposition when the budget is exhausted.

- [ ] **UC-M12.02-C098-T01 · Quantity inventory:** Create a measurement inventory for “Campaign evidence gate”: “Campaign duration and required target coverage”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M12.02-C098-T02 · Measurement method:** Choose how to observe each “Campaign evidence gate” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M12.02-C098-T03 · Budget decision:** Select justified campaign and target-resource budgets for “Campaign evidence gate”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M12.02-C098-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Campaign evidence gate” cases for “Campaign duration and required target coverage”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M12.02-C098-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Campaign evidence gate” limit; preserve “No unexplained crash, hang, overread or unbounded allocation is hidden”.
- [ ] **UC-M12.02-C098-T06 · Normal measurement:** Run or review the normal “Campaign evidence gate” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M12.02-C098-T07 · At-limit measurement:** Exercise the “Campaign evidence gate” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M12.02-C098-T08 · Over-limit measurement:** Exercise the “Campaign evidence gate” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M12.02-C098-T09 · Uncovered-scope report:** List the “Campaign evidence gate” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M12.02-C098-T10 · Limit evidence:** Publish the selected “Campaign evidence gate” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M12.02-C099 · Diagnostics / review

**Original checklist item:** Report campaign evidence gate results with executed, failed, skipped and unavailable cases separated; preserve the underlying observations and do not manufacture missing measurements.

- [ ] **UC-M12.02-C099-T01 · Result inventory:** Enumerate the required “Campaign evidence gate” qualification cases and intended targets before aggregating results; keep the planned denominator visible.
- [ ] **UC-M12.02-C099-T02 · Verdict schema:** Define separate executed-pass, executed-fail, skipped, unavailable and untested outcomes for “Campaign evidence gate”; document how incomplete cases block relevant claims.
- [ ] **UC-M12.02-C099-T03 · Identity fields:** Attach the actual target, fixture, configuration and revision identifiers to each “Campaign evidence gate” result; do not attribute host-only evidence to a guest or another OS.
- [ ] **UC-M12.02-C099-T04 · Observation capture:** Capture bounded raw “Campaign evidence gate” observations and harness errors; retain enough information to verify the reported oracle comparison.
- [ ] **UC-M12.02-C099-T05 · Aggregation rules:** Implement the “Campaign evidence gate” count/reduction rule so failures and missing measurements cannot disappear; preserve “No unexplained crash, hang, overread or unbounded allocation is hidden”.
- [ ] **UC-M12.02-C099-T06 · Failure visibility:** Feed a failing “Campaign evidence gate” control through the report path; assert the exact failed case and underlying observation remain visible.
- [ ] **UC-M12.02-C099-T07 · Missing-result visibility:** Withhold a required “Campaign evidence gate” measurement or target; verify the report uses unavailable/untested rather than a fabricated zero or passing value.
- [ ] **UC-M12.02-C099-T08 · Bounds and redaction:** Check “Campaign evidence gate” report size and retention against “Campaign duration and required target coverage”; remove secrets while retaining fixture and subject references.
- [ ] **UC-M12.02-C099-T09 · Report reconciliation:** Reconcile the “Campaign evidence gate” summary with every underlying case record; account for the full planned denominator and all omitted scope.
- [ ] **UC-M12.02-C099-T10 · Qualification handoff:** Publish the “Campaign evidence gate” report with measured observations, coverage limits and blockers; state which actual targets remain unqualified.

### UC-M12.02-C100 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for campaign evidence gate; label unexecuted checks as untested.

- [ ] **UC-M12.02-C100-T01 · Evidence inventory:** List the “Campaign evidence gate” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M12.02-C100-T02 · Artifact references:** Record the exact “Campaign evidence gate” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M12.02-C100-T03 · Fixture references:** Attach the “Campaign evidence gate” fixture IDs, input identities and oracle definition; preserve the source counterexample “A budgeted run has unexplained timeouts but is summarized as clean” as a distinct evidence case.
- [ ] **UC-M12.02-C100-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Campaign evidence gate”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M12.02-C100-T05 · Environment record:** Record the actual “Campaign evidence gate” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M12.02-C100-T06 · Expected versus observed:** Pair every “Campaign evidence gate” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M12.02-C100-T07 · Failure and limit records:** Attach “Campaign evidence gate” change/failure and bounds evidence where required; include uncovered “Campaign duration and required target coverage” and unresolved violations of “No unexplained crash, hang, overread or unbounded allocation is hidden”.
- [ ] **UC-M12.02-C100-T08 · Evidence hygiene:** Check the “Campaign evidence gate” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M12.02-C100-T09 · Reproduction review:** Have the “Campaign evidence gate” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M12.02-C100-T10 · Acceptance linkage:** Link the “Campaign evidence gate” evidence to its parent and UC-M12.02 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

