# UC-M12.05 — Performance and capacity qualification

**To-Do Pack 2.0.0 · Baseline UC-2.2.0 · 100 parent checks × 10 subtasks = 1,000 to-dos**

[Master index](../../INDEX.md) · [Workstream index](../../w/12.md)

| Field | Preserved source value |
|---|---|
| Workstream | 12. Qualification, packaging and release |
| Milestone | C |
| Priority | P1 |
| Source assessment | MISSING |
| Scope | core or selected profile |
| Dependencies | [UC-M04.02](../04/UC-M04.02.md), [UC-M10.02](../10/UC-M10.02.md) |
| Source checklist pack | 1.0.0 |
| Original reference labels | [S5], [S6], [S7], [S8]. |

## Original requirement

Benchmark boot, workload throughput, tail latency, peak RSS and long-run TIFF/checkpoint growth against explicit baselines.

**Original acceptance criterion:** Published measurements include hardware, toolchain, sample count and failure rates; no estimated speedup is presented as measured.

**Source trace:** Original checklist `UC100/c/12/UC-M12.05.md` inside [s/checklists.zip](../../s/checklists.zip); exact parent records in [data/parents.jsonl](../../data/parents.jsonl). Original roadmap lines 1138–1148 are preserved in [s/roadmap.md](../../s/roadmap.md).

## How to use these lists

Every parent statement below is preserved verbatim. Its ten child tasks are proposed decomposition, not implemented capabilities or executed tests. Child IDs append `-T01` through `-T10` to the original parent ID. All begin unchecked / `TODO`. Design/review evidence does not establish runtime enforcement; observe the actual selected target where the parent requires it.

The source dependency graph and selected release profile determine applicability. The numbered child sequence is a local working order, not an added hard dependency graph. An unselected optional feature needs a recorded not-applicable rationale; missing prerequisites for selected work remain blockers. Numerical budgets, backends and trust mechanisms remain decisions unless fixed by the source. Test hostile cases only with synthetic inputs in authorized disposable environments.

## 01. Benchmark questions

**Source delivery:** Define specific boot, throughput, latency, memory and state-growth questions.

**Source invariant:** A performance claim has an explicit measured quantity and scope.

**Source negative case:** A generic fast label replaces a defined benchmark.

**Source bounded quantities:** Metric count and tested workload profiles.

### UC-M12.05-C001 · Contract

**Original checklist item:** Define the qualification objective for benchmark questions, including the actual target implementation, prerequisites, observable oracle and explicit exclusions.

- [ ] **UC-M12.05-C001-T01 · Scope statement:** Write the qualification question for “Benchmark questions”; identify the actual target, claimed capability and observations that can answer that question.
- [ ] **UC-M12.05-C001-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Benchmark questions”; record each producer, representation and missing-value meaning.
- [ ] **UC-M12.05-C001-T03 · Output inventory:** List the outputs of “Benchmark questions” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M12.05-C001-T04 · Field dictionary:** Create a field-and-term dictionary for “Benchmark questions”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M12.05-C001-T05 · Prerequisite contract:** Map “Benchmark questions” to the source component prerequisites (UC-M04.02, UC-M10.02); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M12.05-C001-T06 · Authority map:** Identify who may produce, change and consume “Benchmark questions”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M12.05-C001-T07 · Invariant clause:** Add a normative clause for “Benchmark questions” that preserves “A performance claim has an explicit measured quantity and scope”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M12.05-C001-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Benchmark questions”; include the source counterexample “A generic fast label replaces a defined benchmark” and the intended safe disposition.
- [ ] **UC-M12.05-C001-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Metric count and tested workload profiles” in the “Benchmark questions” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M12.05-C001-T10 · Contract review:** Review the “Benchmark questions” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M12.05-C002 · Delivery

**Original checklist item:** Define specific boot, throughput, latency, memory and state-growth questions.

- [ ] **UC-M12.05-C002-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Benchmark questions”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M12.05-C002-T02 · Change plan:** Break the source delivery for “Benchmark questions” into concrete edit targets and reviewable outputs; keep the UC-M12.05 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M12.05-C002-T03 · Core artifact:** Create the “Benchmark questions” model, schema or inventory that realizes this source instruction: Define specific boot, throughput, latency, memory and state-growth questions.
- [ ] **UC-M12.05-C002-T04 · Concrete realization:** Populate “Benchmark questions” with one concrete worked case; map every required entity or field to its source and flag any unmapped entry.
- [ ] **UC-M12.05-C002-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Benchmark questions” needed to preserve “A performance claim has an explicit measured quantity and scope”; record an enforcement gap where only a model exists.
- [ ] **UC-M12.05-C002-T06 · Dependency connection:** Connect the “Benchmark questions” qualification artifact to repeatable workloads, phase/resource metrics and explicit comparison baselines; record the target identity and what the harness actually exercises.
- [ ] **UC-M12.05-C002-T07 · Resource behavior:** Account for “Metric count and tested workload profiles” in “Benchmark questions”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M12.05-C002-T08 · Delivery check:** Run a known-valid control and a deliberately failing control for “Benchmark questions”; confirm the harness distinguishes their observed outcomes.
- [ ] **UC-M12.05-C002-T09 · Patch review:** Review the “Benchmark questions” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M12.05-C002-T10 · Delivery handoff:** Publish the “Benchmark questions” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M12.05-C003 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: A performance claim has an explicit measured quantity and scope. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M12.05-C003-T01 · Named property:** Create a stable property/check name under this parent for “Benchmark questions”; copy its required invariant exactly: “A performance claim has an explicit measured quantity and scope”.
- [ ] **UC-M12.05-C003-T02 · Observable terms:** Define each term in the “Benchmark questions” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M12.05-C003-T03 · Precondition set:** List the preconditions under which “A performance claim has an explicit measured quantity and scope” must hold for “Benchmark questions”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M12.05-C003-T04 · Transition coverage:** Map the “Benchmark questions” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M12.05-C003-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Benchmark questions”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M12.05-C003-T06 · Satisfying fixture:** Create a concrete “Benchmark questions” case that satisfies “A performance claim has an explicit measured quantity and scope”; record its expected observation before running the assertion or review.
- [ ] **UC-M12.05-C003-T07 · Violating fixture:** Create the source counterexample “A generic fast label replaces a defined benchmark” for “Benchmark questions”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M12.05-C003-T08 · Enforcement evidence:** Exercise the “Benchmark questions” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M12.05-C003-T09 · Regression linkage:** Link the “Benchmark questions” property to changes in repeatable workloads, phase/resource metrics and explicit comparison baselines; record which dependency or contract changes require rerunning it.
- [ ] **UC-M12.05-C003-T10 · Property disposition:** Compare the satisfying and violating “Benchmark questions” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M12.05-C004 · Integration

**Original checklist item:** Integrate benchmark questions with repeatable workloads, phase/resource metrics and explicit comparison baselines; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M12.05-C004-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Benchmark questions” across repeatable workloads, phase/resource metrics and explicit comparison baselines; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M12.05-C004-T02 · Field mapping:** Map every “Benchmark questions” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M12.05-C004-T03 · Prerequisite identities:** Record the actual prerequisites for “Benchmark questions” (source dependency list: UC-M04.02, UC-M10.02); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M12.05-C004-T04 · Ownership agreement:** Specify who owns “Benchmark questions” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M12.05-C004-T05 · Handoff implementation:** Connect “Benchmark questions” through the mapped seam using the real adapter or explicit specification reference; preserve “A performance claim has an explicit measured quantity and scope” across the handoff.
- [ ] **UC-M12.05-C004-T06 · Absent-input case:** Omit one required “Benchmark questions” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M12.05-C004-T07 · Stale-input case:** Supply an outdated “Benchmark questions” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M12.05-C004-T08 · Incompatible-input case:** Supply an incompatible “Benchmark questions” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M12.05-C004-T09 · Valid integration trace:** Run a valid “Benchmark questions” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M12.05-C004-T10 · Seam review:** Reconcile the “Benchmark questions” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M12.05-C005 · Valid-case test

**Original checklist item:** Run a known-valid control for benchmark questions; verify that the harness reaches its intended target and compare observed measurements or verdicts with predeclared expectations.

- [ ] **UC-M12.05-C005-T01 · Valid fixture choice:** Choose a known-valid control for “Benchmark questions”; document why it should pass and how it proves the harness reaches the intended target.
- [ ] **UC-M12.05-C005-T02 · Expected-result oracle:** Specify the “Benchmark questions” expected result independently of the implementation output; include the property “A performance claim has an explicit measured quantity and scope” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M12.05-C005-T03 · Fixture material:** Create the concrete “Benchmark questions” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M12.05-C005-T04 · Target preparation:** Prepare the “Benchmark questions” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M12.05-C005-T05 · Initial-state record:** Record the initial “Benchmark questions” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M12.05-C005-T06 · Valid-path execution:** Run the “Benchmark questions” known-valid control on the identified target; retain enough observations to prove the correct target was exercised.
- [ ] **UC-M12.05-C005-T07 · Outcome comparison:** Compare every declared “Benchmark questions” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M12.05-C005-T08 · State and bounds check:** Inspect the “Benchmark questions” ownership/state effects and actual use of “Metric count and tested workload profiles”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M12.05-C005-T09 · Repeatability check:** Repeat the same “Benchmark questions” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M12.05-C005-T10 · Positive evidence:** Attach the “Benchmark questions” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M12.05-C006 · Negative test

**Original checklist item:** Negative case: A generic fast label replaces a defined benchmark. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M12.05-C006-T01 · Adverse-case definition:** Create a test record for the exact “Benchmark questions” source counterexample: “A generic fast label replaces a defined benchmark”; state which precondition or invariant it challenges.
- [ ] **UC-M12.05-C006-T02 · Safe fixture boundary:** Define the contained test boundary for “Benchmark questions”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M12.05-C006-T03 · Valid control:** Construct a valid “Benchmark questions” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M12.05-C006-T04 · Minimal adverse input:** Derive the “Benchmark questions” adverse fixture from the control with the smallest documented change needed to reproduce “A generic fast label replaces a defined benchmark”; retain that change as reproducible data.
- [ ] **UC-M12.05-C006-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Benchmark questions”; require “A performance claim has an explicit measured quantity and scope” and forbid a false-success verdict.
- [ ] **UC-M12.05-C006-T06 · Adverse execution:** Exercise the “Benchmark questions” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M12.05-C006-T07 · Effect inspection:** Inspect “Benchmark questions” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M12.05-C006-T08 · Refusal versus failure:** Confirm the “Benchmark questions” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M12.05-C006-T09 · Reset and retention:** Restore only the disposable “Benchmark questions” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M12.05-C006-T10 · Negative regression:** Register the “Benchmark questions” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M12.05-C007 · Change / failure test

**Original checklist item:** Exercise benchmark questions when a run fails, times out or changes environment during a measurement series; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M12.05-C007-T01 · Scenario record:** Write the “Benchmark questions” change/failure scenario exactly as supplied: a run fails, times out or changes environment during a measurement series; identify the property that must remain true: “A performance claim has an explicit measured quantity and scope”.
- [ ] **UC-M12.05-C007-T02 · Baseline capture:** Create a known-valid “Benchmark questions” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M12.05-C007-T03 · Injection map:** Locate the “Benchmark questions” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M12.05-C007-T04 · Disposition oracle:** Define the legal intermediate and final “Benchmark questions” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M12.05-C007-T05 · Controlled trigger:** Introduce the controlled “Benchmark questions” scenario in the disposable fixture: a run fails, times out or changes environment during a measurement series; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M12.05-C007-T06 · Intermediate inspection:** Inspect the “Benchmark questions” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M12.05-C007-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Benchmark questions”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M12.05-C007-T08 · Stale-evidence cleanup:** Invalidate superseded “Benchmark questions” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M12.05-C007-T09 · Repeat and compare:** Repeat the selected “Benchmark questions” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M12.05-C007-T10 · Failure evidence:** Publish the “Benchmark questions” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M12.05-C008 · Bounds

**Original checklist item:** Set a documented campaign budget for metric count and tested workload profiles; record actual consumption, incomplete coverage and the disposition when the budget is exhausted.

- [ ] **UC-M12.05-C008-T01 · Quantity inventory:** Create a measurement inventory for “Benchmark questions”: “Metric count and tested workload profiles”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M12.05-C008-T02 · Measurement method:** Choose how to observe each “Benchmark questions” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M12.05-C008-T03 · Budget decision:** Select justified campaign and target-resource budgets for “Benchmark questions”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M12.05-C008-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Benchmark questions” cases for “Metric count and tested workload profiles”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M12.05-C008-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Benchmark questions” limit; preserve “A performance claim has an explicit measured quantity and scope”.
- [ ] **UC-M12.05-C008-T06 · Normal measurement:** Run or review the normal “Benchmark questions” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M12.05-C008-T07 · At-limit measurement:** Exercise the “Benchmark questions” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M12.05-C008-T08 · Over-limit measurement:** Exercise the “Benchmark questions” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M12.05-C008-T09 · Uncovered-scope report:** List the “Benchmark questions” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M12.05-C008-T10 · Limit evidence:** Publish the selected “Benchmark questions” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M12.05-C009 · Diagnostics / review

**Original checklist item:** Report benchmark questions results with executed, failed, skipped and unavailable cases separated; preserve the underlying observations and do not manufacture missing measurements.

- [ ] **UC-M12.05-C009-T01 · Result inventory:** Enumerate the required “Benchmark questions” qualification cases and intended targets before aggregating results; keep the planned denominator visible.
- [ ] **UC-M12.05-C009-T02 · Verdict schema:** Define separate executed-pass, executed-fail, skipped, unavailable and untested outcomes for “Benchmark questions”; document how incomplete cases block relevant claims.
- [ ] **UC-M12.05-C009-T03 · Identity fields:** Attach the actual target, fixture, configuration and revision identifiers to each “Benchmark questions” result; do not attribute host-only evidence to a guest or another OS.
- [ ] **UC-M12.05-C009-T04 · Observation capture:** Capture bounded raw “Benchmark questions” observations and harness errors; retain enough information to verify the reported oracle comparison.
- [ ] **UC-M12.05-C009-T05 · Aggregation rules:** Implement the “Benchmark questions” count/reduction rule so failures and missing measurements cannot disappear; preserve “A performance claim has an explicit measured quantity and scope”.
- [ ] **UC-M12.05-C009-T06 · Failure visibility:** Feed a failing “Benchmark questions” control through the report path; assert the exact failed case and underlying observation remain visible.
- [ ] **UC-M12.05-C009-T07 · Missing-result visibility:** Withhold a required “Benchmark questions” measurement or target; verify the report uses unavailable/untested rather than a fabricated zero or passing value.
- [ ] **UC-M12.05-C009-T08 · Bounds and redaction:** Check “Benchmark questions” report size and retention against “Metric count and tested workload profiles”; remove secrets while retaining fixture and subject references.
- [ ] **UC-M12.05-C009-T09 · Report reconciliation:** Reconcile the “Benchmark questions” summary with every underlying case record; account for the full planned denominator and all omitted scope.
- [ ] **UC-M12.05-C009-T10 · Qualification handoff:** Publish the “Benchmark questions” report with measured observations, coverage limits and blockers; state which actual targets remain unqualified.

### UC-M12.05-C010 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for benchmark questions; label unexecuted checks as untested.

- [ ] **UC-M12.05-C010-T01 · Evidence inventory:** List the “Benchmark questions” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M12.05-C010-T02 · Artifact references:** Record the exact “Benchmark questions” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M12.05-C010-T03 · Fixture references:** Attach the “Benchmark questions” fixture IDs, input identities and oracle definition; preserve the source counterexample “A generic fast label replaces a defined benchmark” as a distinct evidence case.
- [ ] **UC-M12.05-C010-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Benchmark questions”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M12.05-C010-T05 · Environment record:** Record the actual “Benchmark questions” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M12.05-C010-T06 · Expected versus observed:** Pair every “Benchmark questions” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M12.05-C010-T07 · Failure and limit records:** Attach “Benchmark questions” change/failure and bounds evidence where required; include uncovered “Metric count and tested workload profiles” and unresolved violations of “A performance claim has an explicit measured quantity and scope”.
- [ ] **UC-M12.05-C010-T08 · Evidence hygiene:** Check the “Benchmark questions” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M12.05-C010-T09 · Reproduction review:** Have the “Benchmark questions” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M12.05-C010-T10 · Acceptance linkage:** Link the “Benchmark questions” evidence to its parent and UC-M12.05 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 02. Baseline definition

**Source delivery:** Choose explicit comparable baselines and record their configuration.

**Source invariant:** A comparison does not silently change workload or resource allocation.

**Source negative case:** The candidate gets more CPUs than the reported baseline.

**Source bounded quantities:** Baseline variants and configuration fields.

### UC-M12.05-C011 · Contract

**Original checklist item:** Define the qualification objective for baseline definition, including the actual target implementation, prerequisites, observable oracle and explicit exclusions.

- [ ] **UC-M12.05-C011-T01 · Scope statement:** Write the qualification question for “Baseline definition”; identify the actual target, claimed capability and observations that can answer that question.
- [ ] **UC-M12.05-C011-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Baseline definition”; record each producer, representation and missing-value meaning.
- [ ] **UC-M12.05-C011-T03 · Output inventory:** List the outputs of “Baseline definition” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M12.05-C011-T04 · Field dictionary:** Create a field-and-term dictionary for “Baseline definition”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M12.05-C011-T05 · Prerequisite contract:** Map “Baseline definition” to the source component prerequisites (UC-M04.02, UC-M10.02); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M12.05-C011-T06 · Authority map:** Identify who may produce, change and consume “Baseline definition”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M12.05-C011-T07 · Invariant clause:** Add a normative clause for “Baseline definition” that preserves “A comparison does not silently change workload or resource allocation”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M12.05-C011-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Baseline definition”; include the source counterexample “The candidate gets more CPUs than the reported baseline” and the intended safe disposition.
- [ ] **UC-M12.05-C011-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Baseline variants and configuration fields” in the “Baseline definition” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M12.05-C011-T10 · Contract review:** Review the “Baseline definition” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M12.05-C012 · Delivery

**Original checklist item:** Choose explicit comparable baselines and record their configuration.

- [ ] **UC-M12.05-C012-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Baseline definition”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M12.05-C012-T02 · Change plan:** Break the source delivery for “Baseline definition” into concrete edit targets and reviewable outputs; keep the UC-M12.05 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M12.05-C012-T03 · Core artifact:** Prepare the “Baseline definition” decision record for this source instruction: Choose explicit comparable baselines and record their configuration.
- [ ] **UC-M12.05-C012-T04 · Concrete realization:** Evaluate the “Baseline definition” choice against its declared constraints; record the exact selected target/configuration and rejected alternatives, leaving unverified compatibility as a blocker.
- [ ] **UC-M12.05-C012-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Baseline definition” needed to preserve “A comparison does not silently change workload or resource allocation”; record an enforcement gap where only a model exists.
- [ ] **UC-M12.05-C012-T06 · Dependency connection:** Connect the “Baseline definition” qualification artifact to repeatable workloads, phase/resource metrics and explicit comparison baselines; record the target identity and what the harness actually exercises.
- [ ] **UC-M12.05-C012-T07 · Resource behavior:** Account for “Baseline variants and configuration fields” in “Baseline definition”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M12.05-C012-T08 · Delivery check:** Run a known-valid control and a deliberately failing control for “Baseline definition”; confirm the harness distinguishes their observed outcomes.
- [ ] **UC-M12.05-C012-T09 · Patch review:** Review the “Baseline definition” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M12.05-C012-T10 · Delivery handoff:** Publish the “Baseline definition” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M12.05-C013 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: A comparison does not silently change workload or resource allocation. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M12.05-C013-T01 · Named property:** Create a stable property/check name under this parent for “Baseline definition”; copy its required invariant exactly: “A comparison does not silently change workload or resource allocation”.
- [ ] **UC-M12.05-C013-T02 · Observable terms:** Define each term in the “Baseline definition” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M12.05-C013-T03 · Precondition set:** List the preconditions under which “A comparison does not silently change workload or resource allocation” must hold for “Baseline definition”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M12.05-C013-T04 · Transition coverage:** Map the “Baseline definition” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M12.05-C013-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Baseline definition”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M12.05-C013-T06 · Satisfying fixture:** Create a concrete “Baseline definition” case that satisfies “A comparison does not silently change workload or resource allocation”; record its expected observation before running the assertion or review.
- [ ] **UC-M12.05-C013-T07 · Violating fixture:** Create the source counterexample “The candidate gets more CPUs than the reported baseline” for “Baseline definition”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M12.05-C013-T08 · Enforcement evidence:** Exercise the “Baseline definition” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M12.05-C013-T09 · Regression linkage:** Link the “Baseline definition” property to changes in repeatable workloads, phase/resource metrics and explicit comparison baselines; record which dependency or contract changes require rerunning it.
- [ ] **UC-M12.05-C013-T10 · Property disposition:** Compare the satisfying and violating “Baseline definition” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M12.05-C014 · Integration

**Original checklist item:** Integrate baseline definition with repeatable workloads, phase/resource metrics and explicit comparison baselines; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M12.05-C014-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Baseline definition” across repeatable workloads, phase/resource metrics and explicit comparison baselines; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M12.05-C014-T02 · Field mapping:** Map every “Baseline definition” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M12.05-C014-T03 · Prerequisite identities:** Record the actual prerequisites for “Baseline definition” (source dependency list: UC-M04.02, UC-M10.02); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M12.05-C014-T04 · Ownership agreement:** Specify who owns “Baseline definition” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M12.05-C014-T05 · Handoff implementation:** Connect “Baseline definition” through the mapped seam using the real adapter or explicit specification reference; preserve “A comparison does not silently change workload or resource allocation” across the handoff.
- [ ] **UC-M12.05-C014-T06 · Absent-input case:** Omit one required “Baseline definition” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M12.05-C014-T07 · Stale-input case:** Supply an outdated “Baseline definition” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M12.05-C014-T08 · Incompatible-input case:** Supply an incompatible “Baseline definition” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M12.05-C014-T09 · Valid integration trace:** Run a valid “Baseline definition” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M12.05-C014-T10 · Seam review:** Reconcile the “Baseline definition” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M12.05-C015 · Valid-case test

**Original checklist item:** Run a known-valid control for baseline definition; verify that the harness reaches its intended target and compare observed measurements or verdicts with predeclared expectations.

- [ ] **UC-M12.05-C015-T01 · Valid fixture choice:** Choose a known-valid control for “Baseline definition”; document why it should pass and how it proves the harness reaches the intended target.
- [ ] **UC-M12.05-C015-T02 · Expected-result oracle:** Specify the “Baseline definition” expected result independently of the implementation output; include the property “A comparison does not silently change workload or resource allocation” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M12.05-C015-T03 · Fixture material:** Create the concrete “Baseline definition” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M12.05-C015-T04 · Target preparation:** Prepare the “Baseline definition” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M12.05-C015-T05 · Initial-state record:** Record the initial “Baseline definition” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M12.05-C015-T06 · Valid-path execution:** Run the “Baseline definition” known-valid control on the identified target; retain enough observations to prove the correct target was exercised.
- [ ] **UC-M12.05-C015-T07 · Outcome comparison:** Compare every declared “Baseline definition” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M12.05-C015-T08 · State and bounds check:** Inspect the “Baseline definition” ownership/state effects and actual use of “Baseline variants and configuration fields”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M12.05-C015-T09 · Repeatability check:** Repeat the same “Baseline definition” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M12.05-C015-T10 · Positive evidence:** Attach the “Baseline definition” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M12.05-C016 · Negative test

**Original checklist item:** Negative case: The candidate gets more CPUs than the reported baseline. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M12.05-C016-T01 · Adverse-case definition:** Create a test record for the exact “Baseline definition” source counterexample: “The candidate gets more CPUs than the reported baseline”; state which precondition or invariant it challenges.
- [ ] **UC-M12.05-C016-T02 · Safe fixture boundary:** Define the contained test boundary for “Baseline definition”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M12.05-C016-T03 · Valid control:** Construct a valid “Baseline definition” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M12.05-C016-T04 · Minimal adverse input:** Derive the “Baseline definition” adverse fixture from the control with the smallest documented change needed to reproduce “The candidate gets more CPUs than the reported baseline”; retain that change as reproducible data.
- [ ] **UC-M12.05-C016-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Baseline definition”; require “A comparison does not silently change workload or resource allocation” and forbid a false-success verdict.
- [ ] **UC-M12.05-C016-T06 · Adverse execution:** Exercise the “Baseline definition” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M12.05-C016-T07 · Effect inspection:** Inspect “Baseline definition” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M12.05-C016-T08 · Refusal versus failure:** Confirm the “Baseline definition” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M12.05-C016-T09 · Reset and retention:** Restore only the disposable “Baseline definition” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M12.05-C016-T10 · Negative regression:** Register the “Baseline definition” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M12.05-C017 · Change / failure test

**Original checklist item:** Exercise baseline definition when a run fails, times out or changes environment during a measurement series; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M12.05-C017-T01 · Scenario record:** Write the “Baseline definition” change/failure scenario exactly as supplied: a run fails, times out or changes environment during a measurement series; identify the property that must remain true: “A comparison does not silently change workload or resource allocation”.
- [ ] **UC-M12.05-C017-T02 · Baseline capture:** Create a known-valid “Baseline definition” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M12.05-C017-T03 · Injection map:** Locate the “Baseline definition” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M12.05-C017-T04 · Disposition oracle:** Define the legal intermediate and final “Baseline definition” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M12.05-C017-T05 · Controlled trigger:** Introduce the controlled “Baseline definition” scenario in the disposable fixture: a run fails, times out or changes environment during a measurement series; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M12.05-C017-T06 · Intermediate inspection:** Inspect the “Baseline definition” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M12.05-C017-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Baseline definition”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M12.05-C017-T08 · Stale-evidence cleanup:** Invalidate superseded “Baseline definition” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M12.05-C017-T09 · Repeat and compare:** Repeat the selected “Baseline definition” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M12.05-C017-T10 · Failure evidence:** Publish the “Baseline definition” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M12.05-C018 · Bounds

**Original checklist item:** Set a documented campaign budget for baseline variants and configuration fields; record actual consumption, incomplete coverage and the disposition when the budget is exhausted.

- [ ] **UC-M12.05-C018-T01 · Quantity inventory:** Create a measurement inventory for “Baseline definition”: “Baseline variants and configuration fields”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M12.05-C018-T02 · Measurement method:** Choose how to observe each “Baseline definition” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M12.05-C018-T03 · Budget decision:** Select justified campaign and target-resource budgets for “Baseline definition”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M12.05-C018-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Baseline definition” cases for “Baseline variants and configuration fields”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M12.05-C018-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Baseline definition” limit; preserve “A comparison does not silently change workload or resource allocation”.
- [ ] **UC-M12.05-C018-T06 · Normal measurement:** Run or review the normal “Baseline definition” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M12.05-C018-T07 · At-limit measurement:** Exercise the “Baseline definition” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M12.05-C018-T08 · Over-limit measurement:** Exercise the “Baseline definition” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M12.05-C018-T09 · Uncovered-scope report:** List the “Baseline definition” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M12.05-C018-T10 · Limit evidence:** Publish the selected “Baseline definition” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M12.05-C019 · Diagnostics / review

**Original checklist item:** Report baseline definition results with executed, failed, skipped and unavailable cases separated; preserve the underlying observations and do not manufacture missing measurements.

- [ ] **UC-M12.05-C019-T01 · Result inventory:** Enumerate the required “Baseline definition” qualification cases and intended targets before aggregating results; keep the planned denominator visible.
- [ ] **UC-M12.05-C019-T02 · Verdict schema:** Define separate executed-pass, executed-fail, skipped, unavailable and untested outcomes for “Baseline definition”; document how incomplete cases block relevant claims.
- [ ] **UC-M12.05-C019-T03 · Identity fields:** Attach the actual target, fixture, configuration and revision identifiers to each “Baseline definition” result; do not attribute host-only evidence to a guest or another OS.
- [ ] **UC-M12.05-C019-T04 · Observation capture:** Capture bounded raw “Baseline definition” observations and harness errors; retain enough information to verify the reported oracle comparison.
- [ ] **UC-M12.05-C019-T05 · Aggregation rules:** Implement the “Baseline definition” count/reduction rule so failures and missing measurements cannot disappear; preserve “A comparison does not silently change workload or resource allocation”.
- [ ] **UC-M12.05-C019-T06 · Failure visibility:** Feed a failing “Baseline definition” control through the report path; assert the exact failed case and underlying observation remain visible.
- [ ] **UC-M12.05-C019-T07 · Missing-result visibility:** Withhold a required “Baseline definition” measurement or target; verify the report uses unavailable/untested rather than a fabricated zero or passing value.
- [ ] **UC-M12.05-C019-T08 · Bounds and redaction:** Check “Baseline definition” report size and retention against “Baseline variants and configuration fields”; remove secrets while retaining fixture and subject references.
- [ ] **UC-M12.05-C019-T09 · Report reconciliation:** Reconcile the “Baseline definition” summary with every underlying case record; account for the full planned denominator and all omitted scope.
- [ ] **UC-M12.05-C019-T10 · Qualification handoff:** Publish the “Baseline definition” report with measured observations, coverage limits and blockers; state which actual targets remain unqualified.

### UC-M12.05-C020 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for baseline definition; label unexecuted checks as untested.

- [ ] **UC-M12.05-C020-T01 · Evidence inventory:** List the “Baseline definition” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M12.05-C020-T02 · Artifact references:** Record the exact “Baseline definition” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M12.05-C020-T03 · Fixture references:** Attach the “Baseline definition” fixture IDs, input identities and oracle definition; preserve the source counterexample “The candidate gets more CPUs than the reported baseline” as a distinct evidence case.
- [ ] **UC-M12.05-C020-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Baseline definition”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M12.05-C020-T05 · Environment record:** Record the actual “Baseline definition” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M12.05-C020-T06 · Expected versus observed:** Pair every “Baseline definition” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M12.05-C020-T07 · Failure and limit records:** Attach “Baseline definition” change/failure and bounds evidence where required; include uncovered “Baseline variants and configuration fields” and unresolved violations of “A comparison does not silently change workload or resource allocation”.
- [ ] **UC-M12.05-C020-T08 · Evidence hygiene:** Check the “Baseline definition” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M12.05-C020-T09 · Reproduction review:** Have the “Baseline definition” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M12.05-C020-T10 · Acceptance linkage:** Link the “Baseline definition” evidence to its parent and UC-M12.05 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 03. Hardware and toolchain record

**Source delivery:** Record hardware, host, backend, compiler and relevant runtime identities.

**Source invariant:** Measurements can be interpreted against their actual environment.

**Source negative case:** A result omits the host or build configuration.

**Source bounded quantities:** Environment fields and artifact references.

### UC-M12.05-C021 · Contract

**Original checklist item:** Define the qualification objective for hardware and toolchain record, including the actual target implementation, prerequisites, observable oracle and explicit exclusions.

- [ ] **UC-M12.05-C021-T01 · Scope statement:** Write the qualification question for “Hardware and toolchain record”; identify the actual target, claimed capability and observations that can answer that question.
- [ ] **UC-M12.05-C021-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Hardware and toolchain record”; record each producer, representation and missing-value meaning.
- [ ] **UC-M12.05-C021-T03 · Output inventory:** List the outputs of “Hardware and toolchain record” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M12.05-C021-T04 · Field dictionary:** Create a field-and-term dictionary for “Hardware and toolchain record”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M12.05-C021-T05 · Prerequisite contract:** Map “Hardware and toolchain record” to the source component prerequisites (UC-M04.02, UC-M10.02); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M12.05-C021-T06 · Authority map:** Identify who may produce, change and consume “Hardware and toolchain record”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M12.05-C021-T07 · Invariant clause:** Add a normative clause for “Hardware and toolchain record” that preserves “Measurements can be interpreted against their actual environment”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M12.05-C021-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Hardware and toolchain record”; include the source counterexample “A result omits the host or build configuration” and the intended safe disposition.
- [ ] **UC-M12.05-C021-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Environment fields and artifact references” in the “Hardware and toolchain record” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M12.05-C021-T10 · Contract review:** Review the “Hardware and toolchain record” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M12.05-C022 · Delivery

**Original checklist item:** Record hardware, host, backend, compiler and relevant runtime identities.

- [ ] **UC-M12.05-C022-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Hardware and toolchain record”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M12.05-C022-T02 · Change plan:** Break the source delivery for “Hardware and toolchain record” into concrete edit targets and reviewable outputs; keep the UC-M12.05 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M12.05-C022-T03 · Core artifact:** Create the “Hardware and toolchain record” model, schema or inventory that realizes this source instruction: Record hardware, host, backend, compiler and relevant runtime identities.
- [ ] **UC-M12.05-C022-T04 · Concrete realization:** Populate “Hardware and toolchain record” with one concrete worked case; map every required entity or field to its source and flag any unmapped entry.
- [ ] **UC-M12.05-C022-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Hardware and toolchain record” needed to preserve “Measurements can be interpreted against their actual environment”; record an enforcement gap where only a model exists.
- [ ] **UC-M12.05-C022-T06 · Dependency connection:** Connect the “Hardware and toolchain record” qualification artifact to repeatable workloads, phase/resource metrics and explicit comparison baselines; record the target identity and what the harness actually exercises.
- [ ] **UC-M12.05-C022-T07 · Resource behavior:** Account for “Environment fields and artifact references” in “Hardware and toolchain record”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M12.05-C022-T08 · Delivery check:** Run a known-valid control and a deliberately failing control for “Hardware and toolchain record”; confirm the harness distinguishes their observed outcomes.
- [ ] **UC-M12.05-C022-T09 · Patch review:** Review the “Hardware and toolchain record” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M12.05-C022-T10 · Delivery handoff:** Publish the “Hardware and toolchain record” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M12.05-C023 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Measurements can be interpreted against their actual environment. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M12.05-C023-T01 · Named property:** Create a stable property/check name under this parent for “Hardware and toolchain record”; copy its required invariant exactly: “Measurements can be interpreted against their actual environment”.
- [ ] **UC-M12.05-C023-T02 · Observable terms:** Define each term in the “Hardware and toolchain record” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M12.05-C023-T03 · Precondition set:** List the preconditions under which “Measurements can be interpreted against their actual environment” must hold for “Hardware and toolchain record”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M12.05-C023-T04 · Transition coverage:** Map the “Hardware and toolchain record” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M12.05-C023-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Hardware and toolchain record”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M12.05-C023-T06 · Satisfying fixture:** Create a concrete “Hardware and toolchain record” case that satisfies “Measurements can be interpreted against their actual environment”; record its expected observation before running the assertion or review.
- [ ] **UC-M12.05-C023-T07 · Violating fixture:** Create the source counterexample “A result omits the host or build configuration” for “Hardware and toolchain record”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M12.05-C023-T08 · Enforcement evidence:** Exercise the “Hardware and toolchain record” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M12.05-C023-T09 · Regression linkage:** Link the “Hardware and toolchain record” property to changes in repeatable workloads, phase/resource metrics and explicit comparison baselines; record which dependency or contract changes require rerunning it.
- [ ] **UC-M12.05-C023-T10 · Property disposition:** Compare the satisfying and violating “Hardware and toolchain record” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M12.05-C024 · Integration

**Original checklist item:** Integrate hardware and toolchain record with repeatable workloads, phase/resource metrics and explicit comparison baselines; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M12.05-C024-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Hardware and toolchain record” across repeatable workloads, phase/resource metrics and explicit comparison baselines; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M12.05-C024-T02 · Field mapping:** Map every “Hardware and toolchain record” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M12.05-C024-T03 · Prerequisite identities:** Record the actual prerequisites for “Hardware and toolchain record” (source dependency list: UC-M04.02, UC-M10.02); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M12.05-C024-T04 · Ownership agreement:** Specify who owns “Hardware and toolchain record” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M12.05-C024-T05 · Handoff implementation:** Connect “Hardware and toolchain record” through the mapped seam using the real adapter or explicit specification reference; preserve “Measurements can be interpreted against their actual environment” across the handoff.
- [ ] **UC-M12.05-C024-T06 · Absent-input case:** Omit one required “Hardware and toolchain record” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M12.05-C024-T07 · Stale-input case:** Supply an outdated “Hardware and toolchain record” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M12.05-C024-T08 · Incompatible-input case:** Supply an incompatible “Hardware and toolchain record” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M12.05-C024-T09 · Valid integration trace:** Run a valid “Hardware and toolchain record” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M12.05-C024-T10 · Seam review:** Reconcile the “Hardware and toolchain record” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M12.05-C025 · Valid-case test

**Original checklist item:** Run a known-valid control for hardware and toolchain record; verify that the harness reaches its intended target and compare observed measurements or verdicts with predeclared expectations.

- [ ] **UC-M12.05-C025-T01 · Valid fixture choice:** Choose a known-valid control for “Hardware and toolchain record”; document why it should pass and how it proves the harness reaches the intended target.
- [ ] **UC-M12.05-C025-T02 · Expected-result oracle:** Specify the “Hardware and toolchain record” expected result independently of the implementation output; include the property “Measurements can be interpreted against their actual environment” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M12.05-C025-T03 · Fixture material:** Create the concrete “Hardware and toolchain record” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M12.05-C025-T04 · Target preparation:** Prepare the “Hardware and toolchain record” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M12.05-C025-T05 · Initial-state record:** Record the initial “Hardware and toolchain record” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M12.05-C025-T06 · Valid-path execution:** Run the “Hardware and toolchain record” known-valid control on the identified target; retain enough observations to prove the correct target was exercised.
- [ ] **UC-M12.05-C025-T07 · Outcome comparison:** Compare every declared “Hardware and toolchain record” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M12.05-C025-T08 · State and bounds check:** Inspect the “Hardware and toolchain record” ownership/state effects and actual use of “Environment fields and artifact references”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M12.05-C025-T09 · Repeatability check:** Repeat the same “Hardware and toolchain record” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M12.05-C025-T10 · Positive evidence:** Attach the “Hardware and toolchain record” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M12.05-C026 · Negative test

**Original checklist item:** Negative case: A result omits the host or build configuration. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M12.05-C026-T01 · Adverse-case definition:** Create a test record for the exact “Hardware and toolchain record” source counterexample: “A result omits the host or build configuration”; state which precondition or invariant it challenges.
- [ ] **UC-M12.05-C026-T02 · Safe fixture boundary:** Define the contained test boundary for “Hardware and toolchain record”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M12.05-C026-T03 · Valid control:** Construct a valid “Hardware and toolchain record” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M12.05-C026-T04 · Minimal adverse input:** Derive the “Hardware and toolchain record” adverse fixture from the control with the smallest documented change needed to reproduce “A result omits the host or build configuration”; retain that change as reproducible data.
- [ ] **UC-M12.05-C026-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Hardware and toolchain record”; require “Measurements can be interpreted against their actual environment” and forbid a false-success verdict.
- [ ] **UC-M12.05-C026-T06 · Adverse execution:** Exercise the “Hardware and toolchain record” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M12.05-C026-T07 · Effect inspection:** Inspect “Hardware and toolchain record” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M12.05-C026-T08 · Refusal versus failure:** Confirm the “Hardware and toolchain record” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M12.05-C026-T09 · Reset and retention:** Restore only the disposable “Hardware and toolchain record” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M12.05-C026-T10 · Negative regression:** Register the “Hardware and toolchain record” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M12.05-C027 · Change / failure test

**Original checklist item:** Exercise hardware and toolchain record when a run fails, times out or changes environment during a measurement series; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M12.05-C027-T01 · Scenario record:** Write the “Hardware and toolchain record” change/failure scenario exactly as supplied: a run fails, times out or changes environment during a measurement series; identify the property that must remain true: “Measurements can be interpreted against their actual environment”.
- [ ] **UC-M12.05-C027-T02 · Baseline capture:** Create a known-valid “Hardware and toolchain record” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M12.05-C027-T03 · Injection map:** Locate the “Hardware and toolchain record” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M12.05-C027-T04 · Disposition oracle:** Define the legal intermediate and final “Hardware and toolchain record” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M12.05-C027-T05 · Controlled trigger:** Introduce the controlled “Hardware and toolchain record” scenario in the disposable fixture: a run fails, times out or changes environment during a measurement series; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M12.05-C027-T06 · Intermediate inspection:** Inspect the “Hardware and toolchain record” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M12.05-C027-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Hardware and toolchain record”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M12.05-C027-T08 · Stale-evidence cleanup:** Invalidate superseded “Hardware and toolchain record” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M12.05-C027-T09 · Repeat and compare:** Repeat the selected “Hardware and toolchain record” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M12.05-C027-T10 · Failure evidence:** Publish the “Hardware and toolchain record” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M12.05-C028 · Bounds

**Original checklist item:** Set a documented campaign budget for environment fields and artifact references; record actual consumption, incomplete coverage and the disposition when the budget is exhausted.

- [ ] **UC-M12.05-C028-T01 · Quantity inventory:** Create a measurement inventory for “Hardware and toolchain record”: “Environment fields and artifact references”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M12.05-C028-T02 · Measurement method:** Choose how to observe each “Hardware and toolchain record” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M12.05-C028-T03 · Budget decision:** Select justified campaign and target-resource budgets for “Hardware and toolchain record”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M12.05-C028-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Hardware and toolchain record” cases for “Environment fields and artifact references”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M12.05-C028-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Hardware and toolchain record” limit; preserve “Measurements can be interpreted against their actual environment”.
- [ ] **UC-M12.05-C028-T06 · Normal measurement:** Run or review the normal “Hardware and toolchain record” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M12.05-C028-T07 · At-limit measurement:** Exercise the “Hardware and toolchain record” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M12.05-C028-T08 · Over-limit measurement:** Exercise the “Hardware and toolchain record” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M12.05-C028-T09 · Uncovered-scope report:** List the “Hardware and toolchain record” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M12.05-C028-T10 · Limit evidence:** Publish the selected “Hardware and toolchain record” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M12.05-C029 · Diagnostics / review

**Original checklist item:** Report hardware and toolchain record results with executed, failed, skipped and unavailable cases separated; preserve the underlying observations and do not manufacture missing measurements.

- [ ] **UC-M12.05-C029-T01 · Result inventory:** Enumerate the required “Hardware and toolchain record” qualification cases and intended targets before aggregating results; keep the planned denominator visible.
- [ ] **UC-M12.05-C029-T02 · Verdict schema:** Define separate executed-pass, executed-fail, skipped, unavailable and untested outcomes for “Hardware and toolchain record”; document how incomplete cases block relevant claims.
- [ ] **UC-M12.05-C029-T03 · Identity fields:** Attach the actual target, fixture, configuration and revision identifiers to each “Hardware and toolchain record” result; do not attribute host-only evidence to a guest or another OS.
- [ ] **UC-M12.05-C029-T04 · Observation capture:** Capture bounded raw “Hardware and toolchain record” observations and harness errors; retain enough information to verify the reported oracle comparison.
- [ ] **UC-M12.05-C029-T05 · Aggregation rules:** Implement the “Hardware and toolchain record” count/reduction rule so failures and missing measurements cannot disappear; preserve “Measurements can be interpreted against their actual environment”.
- [ ] **UC-M12.05-C029-T06 · Failure visibility:** Feed a failing “Hardware and toolchain record” control through the report path; assert the exact failed case and underlying observation remain visible.
- [ ] **UC-M12.05-C029-T07 · Missing-result visibility:** Withhold a required “Hardware and toolchain record” measurement or target; verify the report uses unavailable/untested rather than a fabricated zero or passing value.
- [ ] **UC-M12.05-C029-T08 · Bounds and redaction:** Check “Hardware and toolchain record” report size and retention against “Environment fields and artifact references”; remove secrets while retaining fixture and subject references.
- [ ] **UC-M12.05-C029-T09 · Report reconciliation:** Reconcile the “Hardware and toolchain record” summary with every underlying case record; account for the full planned denominator and all omitted scope.
- [ ] **UC-M12.05-C029-T10 · Qualification handoff:** Publish the “Hardware and toolchain record” report with measured observations, coverage limits and blockers; state which actual targets remain unqualified.

### UC-M12.05-C030 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for hardware and toolchain record; label unexecuted checks as untested.

- [ ] **UC-M12.05-C030-T01 · Evidence inventory:** List the “Hardware and toolchain record” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M12.05-C030-T02 · Artifact references:** Record the exact “Hardware and toolchain record” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M12.05-C030-T03 · Fixture references:** Attach the “Hardware and toolchain record” fixture IDs, input identities and oracle definition; preserve the source counterexample “A result omits the host or build configuration” as a distinct evidence case.
- [ ] **UC-M12.05-C030-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Hardware and toolchain record”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M12.05-C030-T05 · Environment record:** Record the actual “Hardware and toolchain record” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M12.05-C030-T06 · Expected versus observed:** Pair every “Hardware and toolchain record” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M12.05-C030-T07 · Failure and limit records:** Attach “Hardware and toolchain record” change/failure and bounds evidence where required; include uncovered “Environment fields and artifact references” and unresolved violations of “Measurements can be interpreted against their actual environment”.
- [ ] **UC-M12.05-C030-T08 · Evidence hygiene:** Check the “Hardware and toolchain record” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M12.05-C030-T09 · Reproduction review:** Have the “Hardware and toolchain record” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M12.05-C030-T10 · Acceptance linkage:** Link the “Hardware and toolchain record” evidence to its parent and UC-M12.05 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 04. Boot benchmark

**Source delivery:** Measure the defined start-to-guest-ready interval repeatedly.

**Source invariant:** Host launcher latency alone is not labeled guest boot time.

**Source negative case:** Readiness is inferred from process creation.

**Source bounded quantities:** Boot repetitions and timing resolution.

### UC-M12.05-C031 · Contract

**Original checklist item:** Define the qualification objective for boot benchmark, including the actual target implementation, prerequisites, observable oracle and explicit exclusions.

- [ ] **UC-M12.05-C031-T01 · Scope statement:** Write the qualification question for “Boot benchmark”; identify the actual target, claimed capability and observations that can answer that question.
- [ ] **UC-M12.05-C031-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Boot benchmark”; record each producer, representation and missing-value meaning.
- [ ] **UC-M12.05-C031-T03 · Output inventory:** List the outputs of “Boot benchmark” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M12.05-C031-T04 · Field dictionary:** Create a field-and-term dictionary for “Boot benchmark”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M12.05-C031-T05 · Prerequisite contract:** Map “Boot benchmark” to the source component prerequisites (UC-M04.02, UC-M10.02); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M12.05-C031-T06 · Authority map:** Identify who may produce, change and consume “Boot benchmark”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M12.05-C031-T07 · Invariant clause:** Add a normative clause for “Boot benchmark” that preserves “Host launcher latency alone is not labeled guest boot time”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M12.05-C031-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Boot benchmark”; include the source counterexample “Readiness is inferred from process creation” and the intended safe disposition.
- [ ] **UC-M12.05-C031-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Boot repetitions and timing resolution” in the “Boot benchmark” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M12.05-C031-T10 · Contract review:** Review the “Boot benchmark” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M12.05-C032 · Delivery

**Original checklist item:** Measure the defined start-to-guest-ready interval repeatedly.

- [ ] **UC-M12.05-C032-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Boot benchmark”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M12.05-C032-T02 · Change plan:** Break the source delivery for “Boot benchmark” into concrete edit targets and reviewable outputs; keep the UC-M12.05 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M12.05-C032-T03 · Core artifact:** Create the “Boot benchmark” fixture or harness for this source instruction: Measure the defined start-to-guest-ready interval repeatedly.
- [ ] **UC-M12.05-C032-T04 · Concrete realization:** Connect the “Boot benchmark” harness to its actual intended target, set the expected oracle before running it, and distinguish a mock/control run from a target run.
- [ ] **UC-M12.05-C032-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Boot benchmark” needed to preserve “Host launcher latency alone is not labeled guest boot time”; record an enforcement gap where only a model exists.
- [ ] **UC-M12.05-C032-T06 · Dependency connection:** Connect the “Boot benchmark” qualification artifact to repeatable workloads, phase/resource metrics and explicit comparison baselines; record the target identity and what the harness actually exercises.
- [ ] **UC-M12.05-C032-T07 · Resource behavior:** Account for “Boot repetitions and timing resolution” in “Boot benchmark”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M12.05-C032-T08 · Delivery check:** Run a known-valid control and a deliberately failing control for “Boot benchmark”; confirm the harness distinguishes their observed outcomes.
- [ ] **UC-M12.05-C032-T09 · Patch review:** Review the “Boot benchmark” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M12.05-C032-T10 · Delivery handoff:** Publish the “Boot benchmark” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M12.05-C033 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Host launcher latency alone is not labeled guest boot time. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M12.05-C033-T01 · Named property:** Create a stable property/check name under this parent for “Boot benchmark”; copy its required invariant exactly: “Host launcher latency alone is not labeled guest boot time”.
- [ ] **UC-M12.05-C033-T02 · Observable terms:** Define each term in the “Boot benchmark” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M12.05-C033-T03 · Precondition set:** List the preconditions under which “Host launcher latency alone is not labeled guest boot time” must hold for “Boot benchmark”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M12.05-C033-T04 · Transition coverage:** Map the “Boot benchmark” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M12.05-C033-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Boot benchmark”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M12.05-C033-T06 · Satisfying fixture:** Create a concrete “Boot benchmark” case that satisfies “Host launcher latency alone is not labeled guest boot time”; record its expected observation before running the assertion or review.
- [ ] **UC-M12.05-C033-T07 · Violating fixture:** Create the source counterexample “Readiness is inferred from process creation” for “Boot benchmark”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M12.05-C033-T08 · Enforcement evidence:** Exercise the “Boot benchmark” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M12.05-C033-T09 · Regression linkage:** Link the “Boot benchmark” property to changes in repeatable workloads, phase/resource metrics and explicit comparison baselines; record which dependency or contract changes require rerunning it.
- [ ] **UC-M12.05-C033-T10 · Property disposition:** Compare the satisfying and violating “Boot benchmark” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M12.05-C034 · Integration

**Original checklist item:** Integrate boot benchmark with repeatable workloads, phase/resource metrics and explicit comparison baselines; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M12.05-C034-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Boot benchmark” across repeatable workloads, phase/resource metrics and explicit comparison baselines; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M12.05-C034-T02 · Field mapping:** Map every “Boot benchmark” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M12.05-C034-T03 · Prerequisite identities:** Record the actual prerequisites for “Boot benchmark” (source dependency list: UC-M04.02, UC-M10.02); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M12.05-C034-T04 · Ownership agreement:** Specify who owns “Boot benchmark” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M12.05-C034-T05 · Handoff implementation:** Connect “Boot benchmark” through the mapped seam using the real adapter or explicit specification reference; preserve “Host launcher latency alone is not labeled guest boot time” across the handoff.
- [ ] **UC-M12.05-C034-T06 · Absent-input case:** Omit one required “Boot benchmark” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M12.05-C034-T07 · Stale-input case:** Supply an outdated “Boot benchmark” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M12.05-C034-T08 · Incompatible-input case:** Supply an incompatible “Boot benchmark” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M12.05-C034-T09 · Valid integration trace:** Run a valid “Boot benchmark” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M12.05-C034-T10 · Seam review:** Reconcile the “Boot benchmark” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M12.05-C035 · Valid-case test

**Original checklist item:** Run a known-valid control for boot benchmark; verify that the harness reaches its intended target and compare observed measurements or verdicts with predeclared expectations.

- [ ] **UC-M12.05-C035-T01 · Valid fixture choice:** Choose a known-valid control for “Boot benchmark”; document why it should pass and how it proves the harness reaches the intended target.
- [ ] **UC-M12.05-C035-T02 · Expected-result oracle:** Specify the “Boot benchmark” expected result independently of the implementation output; include the property “Host launcher latency alone is not labeled guest boot time” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M12.05-C035-T03 · Fixture material:** Create the concrete “Boot benchmark” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M12.05-C035-T04 · Target preparation:** Prepare the “Boot benchmark” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M12.05-C035-T05 · Initial-state record:** Record the initial “Boot benchmark” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M12.05-C035-T06 · Valid-path execution:** Run the “Boot benchmark” known-valid control on the identified target; retain enough observations to prove the correct target was exercised.
- [ ] **UC-M12.05-C035-T07 · Outcome comparison:** Compare every declared “Boot benchmark” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M12.05-C035-T08 · State and bounds check:** Inspect the “Boot benchmark” ownership/state effects and actual use of “Boot repetitions and timing resolution”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M12.05-C035-T09 · Repeatability check:** Repeat the same “Boot benchmark” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M12.05-C035-T10 · Positive evidence:** Attach the “Boot benchmark” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M12.05-C036 · Negative test

**Original checklist item:** Negative case: Readiness is inferred from process creation. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M12.05-C036-T01 · Adverse-case definition:** Create a test record for the exact “Boot benchmark” source counterexample: “Readiness is inferred from process creation”; state which precondition or invariant it challenges.
- [ ] **UC-M12.05-C036-T02 · Safe fixture boundary:** Define the contained test boundary for “Boot benchmark”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M12.05-C036-T03 · Valid control:** Construct a valid “Boot benchmark” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M12.05-C036-T04 · Minimal adverse input:** Derive the “Boot benchmark” adverse fixture from the control with the smallest documented change needed to reproduce “Readiness is inferred from process creation”; retain that change as reproducible data.
- [ ] **UC-M12.05-C036-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Boot benchmark”; require “Host launcher latency alone is not labeled guest boot time” and forbid a false-success verdict.
- [ ] **UC-M12.05-C036-T06 · Adverse execution:** Exercise the “Boot benchmark” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M12.05-C036-T07 · Effect inspection:** Inspect “Boot benchmark” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M12.05-C036-T08 · Refusal versus failure:** Confirm the “Boot benchmark” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M12.05-C036-T09 · Reset and retention:** Restore only the disposable “Boot benchmark” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M12.05-C036-T10 · Negative regression:** Register the “Boot benchmark” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M12.05-C037 · Change / failure test

**Original checklist item:** Exercise boot benchmark when a run fails, times out or changes environment during a measurement series; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M12.05-C037-T01 · Scenario record:** Write the “Boot benchmark” change/failure scenario exactly as supplied: a run fails, times out or changes environment during a measurement series; identify the property that must remain true: “Host launcher latency alone is not labeled guest boot time”.
- [ ] **UC-M12.05-C037-T02 · Baseline capture:** Create a known-valid “Boot benchmark” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M12.05-C037-T03 · Injection map:** Locate the “Boot benchmark” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M12.05-C037-T04 · Disposition oracle:** Define the legal intermediate and final “Boot benchmark” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M12.05-C037-T05 · Controlled trigger:** Introduce the controlled “Boot benchmark” scenario in the disposable fixture: a run fails, times out or changes environment during a measurement series; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M12.05-C037-T06 · Intermediate inspection:** Inspect the “Boot benchmark” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M12.05-C037-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Boot benchmark”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M12.05-C037-T08 · Stale-evidence cleanup:** Invalidate superseded “Boot benchmark” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M12.05-C037-T09 · Repeat and compare:** Repeat the selected “Boot benchmark” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M12.05-C037-T10 · Failure evidence:** Publish the “Boot benchmark” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M12.05-C038 · Bounds

**Original checklist item:** Set a documented campaign budget for boot repetitions and timing resolution; record actual consumption, incomplete coverage and the disposition when the budget is exhausted.

- [ ] **UC-M12.05-C038-T01 · Quantity inventory:** Create a measurement inventory for “Boot benchmark”: “Boot repetitions and timing resolution”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M12.05-C038-T02 · Measurement method:** Choose how to observe each “Boot benchmark” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M12.05-C038-T03 · Budget decision:** Select justified campaign and target-resource budgets for “Boot benchmark”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M12.05-C038-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Boot benchmark” cases for “Boot repetitions and timing resolution”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M12.05-C038-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Boot benchmark” limit; preserve “Host launcher latency alone is not labeled guest boot time”.
- [ ] **UC-M12.05-C038-T06 · Normal measurement:** Run or review the normal “Boot benchmark” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M12.05-C038-T07 · At-limit measurement:** Exercise the “Boot benchmark” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M12.05-C038-T08 · Over-limit measurement:** Exercise the “Boot benchmark” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M12.05-C038-T09 · Uncovered-scope report:** List the “Boot benchmark” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M12.05-C038-T10 · Limit evidence:** Publish the selected “Boot benchmark” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M12.05-C039 · Diagnostics / review

**Original checklist item:** Report boot benchmark results with executed, failed, skipped and unavailable cases separated; preserve the underlying observations and do not manufacture missing measurements.

- [ ] **UC-M12.05-C039-T01 · Result inventory:** Enumerate the required “Boot benchmark” qualification cases and intended targets before aggregating results; keep the planned denominator visible.
- [ ] **UC-M12.05-C039-T02 · Verdict schema:** Define separate executed-pass, executed-fail, skipped, unavailable and untested outcomes for “Boot benchmark”; document how incomplete cases block relevant claims.
- [ ] **UC-M12.05-C039-T03 · Identity fields:** Attach the actual target, fixture, configuration and revision identifiers to each “Boot benchmark” result; do not attribute host-only evidence to a guest or another OS.
- [ ] **UC-M12.05-C039-T04 · Observation capture:** Capture bounded raw “Boot benchmark” observations and harness errors; retain enough information to verify the reported oracle comparison.
- [ ] **UC-M12.05-C039-T05 · Aggregation rules:** Implement the “Boot benchmark” count/reduction rule so failures and missing measurements cannot disappear; preserve “Host launcher latency alone is not labeled guest boot time”.
- [ ] **UC-M12.05-C039-T06 · Failure visibility:** Feed a failing “Boot benchmark” control through the report path; assert the exact failed case and underlying observation remain visible.
- [ ] **UC-M12.05-C039-T07 · Missing-result visibility:** Withhold a required “Boot benchmark” measurement or target; verify the report uses unavailable/untested rather than a fabricated zero or passing value.
- [ ] **UC-M12.05-C039-T08 · Bounds and redaction:** Check “Boot benchmark” report size and retention against “Boot repetitions and timing resolution”; remove secrets while retaining fixture and subject references.
- [ ] **UC-M12.05-C039-T09 · Report reconciliation:** Reconcile the “Boot benchmark” summary with every underlying case record; account for the full planned denominator and all omitted scope.
- [ ] **UC-M12.05-C039-T10 · Qualification handoff:** Publish the “Boot benchmark” report with measured observations, coverage limits and blockers; state which actual targets remain unqualified.

### UC-M12.05-C040 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for boot benchmark; label unexecuted checks as untested.

- [ ] **UC-M12.05-C040-T01 · Evidence inventory:** List the “Boot benchmark” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M12.05-C040-T02 · Artifact references:** Record the exact “Boot benchmark” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M12.05-C040-T03 · Fixture references:** Attach the “Boot benchmark” fixture IDs, input identities and oracle definition; preserve the source counterexample “Readiness is inferred from process creation” as a distinct evidence case.
- [ ] **UC-M12.05-C040-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Boot benchmark”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M12.05-C040-T05 · Environment record:** Record the actual “Boot benchmark” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M12.05-C040-T06 · Expected versus observed:** Pair every “Boot benchmark” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M12.05-C040-T07 · Failure and limit records:** Attach “Boot benchmark” change/failure and bounds evidence where required; include uncovered “Boot repetitions and timing resolution” and unresolved violations of “Host launcher latency alone is not labeled guest boot time”.
- [ ] **UC-M12.05-C040-T08 · Evidence hygiene:** Check the “Boot benchmark” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M12.05-C040-T09 · Reproduction review:** Have the “Boot benchmark” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M12.05-C040-T10 · Acceptance linkage:** Link the “Boot benchmark” evidence to its parent and UC-M12.05 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 05. Throughput benchmark

**Source delivery:** Measure completed semantically valid workload units per documented interval.

**Source invariant:** Failed or incorrect work is not counted as successful throughput.

**Source negative case:** A workload drops requests while reporting a high completion rate.

**Source bounded quantities:** Request volume and measurement duration.

### UC-M12.05-C041 · Contract

**Original checklist item:** Define the qualification objective for throughput benchmark, including the actual target implementation, prerequisites, observable oracle and explicit exclusions.

- [ ] **UC-M12.05-C041-T01 · Scope statement:** Write the qualification question for “Throughput benchmark”; identify the actual target, claimed capability and observations that can answer that question.
- [ ] **UC-M12.05-C041-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Throughput benchmark”; record each producer, representation and missing-value meaning.
- [ ] **UC-M12.05-C041-T03 · Output inventory:** List the outputs of “Throughput benchmark” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M12.05-C041-T04 · Field dictionary:** Create a field-and-term dictionary for “Throughput benchmark”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M12.05-C041-T05 · Prerequisite contract:** Map “Throughput benchmark” to the source component prerequisites (UC-M04.02, UC-M10.02); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M12.05-C041-T06 · Authority map:** Identify who may produce, change and consume “Throughput benchmark”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M12.05-C041-T07 · Invariant clause:** Add a normative clause for “Throughput benchmark” that preserves “Failed or incorrect work is not counted as successful throughput”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M12.05-C041-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Throughput benchmark”; include the source counterexample “A workload drops requests while reporting a high completion rate” and the intended safe disposition.
- [ ] **UC-M12.05-C041-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Request volume and measurement duration” in the “Throughput benchmark” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M12.05-C041-T10 · Contract review:** Review the “Throughput benchmark” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M12.05-C042 · Delivery

**Original checklist item:** Measure completed semantically valid workload units per documented interval.

- [ ] **UC-M12.05-C042-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Throughput benchmark”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M12.05-C042-T02 · Change plan:** Break the source delivery for “Throughput benchmark” into concrete edit targets and reviewable outputs; keep the UC-M12.05 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M12.05-C042-T03 · Core artifact:** Create the “Throughput benchmark” fixture or harness for this source instruction: Measure completed semantically valid workload units per documented interval.
- [ ] **UC-M12.05-C042-T04 · Concrete realization:** Connect the “Throughput benchmark” harness to its actual intended target, set the expected oracle before running it, and distinguish a mock/control run from a target run.
- [ ] **UC-M12.05-C042-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Throughput benchmark” needed to preserve “Failed or incorrect work is not counted as successful throughput”; record an enforcement gap where only a model exists.
- [ ] **UC-M12.05-C042-T06 · Dependency connection:** Connect the “Throughput benchmark” qualification artifact to repeatable workloads, phase/resource metrics and explicit comparison baselines; record the target identity and what the harness actually exercises.
- [ ] **UC-M12.05-C042-T07 · Resource behavior:** Account for “Request volume and measurement duration” in “Throughput benchmark”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M12.05-C042-T08 · Delivery check:** Run a known-valid control and a deliberately failing control for “Throughput benchmark”; confirm the harness distinguishes their observed outcomes.
- [ ] **UC-M12.05-C042-T09 · Patch review:** Review the “Throughput benchmark” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M12.05-C042-T10 · Delivery handoff:** Publish the “Throughput benchmark” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M12.05-C043 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Failed or incorrect work is not counted as successful throughput. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M12.05-C043-T01 · Named property:** Create a stable property/check name under this parent for “Throughput benchmark”; copy its required invariant exactly: “Failed or incorrect work is not counted as successful throughput”.
- [ ] **UC-M12.05-C043-T02 · Observable terms:** Define each term in the “Throughput benchmark” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M12.05-C043-T03 · Precondition set:** List the preconditions under which “Failed or incorrect work is not counted as successful throughput” must hold for “Throughput benchmark”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M12.05-C043-T04 · Transition coverage:** Map the “Throughput benchmark” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M12.05-C043-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Throughput benchmark”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M12.05-C043-T06 · Satisfying fixture:** Create a concrete “Throughput benchmark” case that satisfies “Failed or incorrect work is not counted as successful throughput”; record its expected observation before running the assertion or review.
- [ ] **UC-M12.05-C043-T07 · Violating fixture:** Create the source counterexample “A workload drops requests while reporting a high completion rate” for “Throughput benchmark”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M12.05-C043-T08 · Enforcement evidence:** Exercise the “Throughput benchmark” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M12.05-C043-T09 · Regression linkage:** Link the “Throughput benchmark” property to changes in repeatable workloads, phase/resource metrics and explicit comparison baselines; record which dependency or contract changes require rerunning it.
- [ ] **UC-M12.05-C043-T10 · Property disposition:** Compare the satisfying and violating “Throughput benchmark” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M12.05-C044 · Integration

**Original checklist item:** Integrate throughput benchmark with repeatable workloads, phase/resource metrics and explicit comparison baselines; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M12.05-C044-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Throughput benchmark” across repeatable workloads, phase/resource metrics and explicit comparison baselines; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M12.05-C044-T02 · Field mapping:** Map every “Throughput benchmark” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M12.05-C044-T03 · Prerequisite identities:** Record the actual prerequisites for “Throughput benchmark” (source dependency list: UC-M04.02, UC-M10.02); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M12.05-C044-T04 · Ownership agreement:** Specify who owns “Throughput benchmark” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M12.05-C044-T05 · Handoff implementation:** Connect “Throughput benchmark” through the mapped seam using the real adapter or explicit specification reference; preserve “Failed or incorrect work is not counted as successful throughput” across the handoff.
- [ ] **UC-M12.05-C044-T06 · Absent-input case:** Omit one required “Throughput benchmark” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M12.05-C044-T07 · Stale-input case:** Supply an outdated “Throughput benchmark” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M12.05-C044-T08 · Incompatible-input case:** Supply an incompatible “Throughput benchmark” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M12.05-C044-T09 · Valid integration trace:** Run a valid “Throughput benchmark” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M12.05-C044-T10 · Seam review:** Reconcile the “Throughput benchmark” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M12.05-C045 · Valid-case test

**Original checklist item:** Run a known-valid control for throughput benchmark; verify that the harness reaches its intended target and compare observed measurements or verdicts with predeclared expectations.

- [ ] **UC-M12.05-C045-T01 · Valid fixture choice:** Choose a known-valid control for “Throughput benchmark”; document why it should pass and how it proves the harness reaches the intended target.
- [ ] **UC-M12.05-C045-T02 · Expected-result oracle:** Specify the “Throughput benchmark” expected result independently of the implementation output; include the property “Failed or incorrect work is not counted as successful throughput” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M12.05-C045-T03 · Fixture material:** Create the concrete “Throughput benchmark” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M12.05-C045-T04 · Target preparation:** Prepare the “Throughput benchmark” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M12.05-C045-T05 · Initial-state record:** Record the initial “Throughput benchmark” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M12.05-C045-T06 · Valid-path execution:** Run the “Throughput benchmark” known-valid control on the identified target; retain enough observations to prove the correct target was exercised.
- [ ] **UC-M12.05-C045-T07 · Outcome comparison:** Compare every declared “Throughput benchmark” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M12.05-C045-T08 · State and bounds check:** Inspect the “Throughput benchmark” ownership/state effects and actual use of “Request volume and measurement duration”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M12.05-C045-T09 · Repeatability check:** Repeat the same “Throughput benchmark” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M12.05-C045-T10 · Positive evidence:** Attach the “Throughput benchmark” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M12.05-C046 · Negative test

**Original checklist item:** Negative case: A workload drops requests while reporting a high completion rate. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M12.05-C046-T01 · Adverse-case definition:** Create a test record for the exact “Throughput benchmark” source counterexample: “A workload drops requests while reporting a high completion rate”; state which precondition or invariant it challenges.
- [ ] **UC-M12.05-C046-T02 · Safe fixture boundary:** Define the contained test boundary for “Throughput benchmark”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M12.05-C046-T03 · Valid control:** Construct a valid “Throughput benchmark” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M12.05-C046-T04 · Minimal adverse input:** Derive the “Throughput benchmark” adverse fixture from the control with the smallest documented change needed to reproduce “A workload drops requests while reporting a high completion rate”; retain that change as reproducible data.
- [ ] **UC-M12.05-C046-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Throughput benchmark”; require “Failed or incorrect work is not counted as successful throughput” and forbid a false-success verdict.
- [ ] **UC-M12.05-C046-T06 · Adverse execution:** Exercise the “Throughput benchmark” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M12.05-C046-T07 · Effect inspection:** Inspect “Throughput benchmark” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M12.05-C046-T08 · Refusal versus failure:** Confirm the “Throughput benchmark” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M12.05-C046-T09 · Reset and retention:** Restore only the disposable “Throughput benchmark” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M12.05-C046-T10 · Negative regression:** Register the “Throughput benchmark” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M12.05-C047 · Change / failure test

**Original checklist item:** Exercise throughput benchmark when a run fails, times out or changes environment during a measurement series; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M12.05-C047-T01 · Scenario record:** Write the “Throughput benchmark” change/failure scenario exactly as supplied: a run fails, times out or changes environment during a measurement series; identify the property that must remain true: “Failed or incorrect work is not counted as successful throughput”.
- [ ] **UC-M12.05-C047-T02 · Baseline capture:** Create a known-valid “Throughput benchmark” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M12.05-C047-T03 · Injection map:** Locate the “Throughput benchmark” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M12.05-C047-T04 · Disposition oracle:** Define the legal intermediate and final “Throughput benchmark” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M12.05-C047-T05 · Controlled trigger:** Introduce the controlled “Throughput benchmark” scenario in the disposable fixture: a run fails, times out or changes environment during a measurement series; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M12.05-C047-T06 · Intermediate inspection:** Inspect the “Throughput benchmark” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M12.05-C047-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Throughput benchmark”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M12.05-C047-T08 · Stale-evidence cleanup:** Invalidate superseded “Throughput benchmark” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M12.05-C047-T09 · Repeat and compare:** Repeat the selected “Throughput benchmark” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M12.05-C047-T10 · Failure evidence:** Publish the “Throughput benchmark” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M12.05-C048 · Bounds

**Original checklist item:** Set a documented campaign budget for request volume and measurement duration; record actual consumption, incomplete coverage and the disposition when the budget is exhausted.

- [ ] **UC-M12.05-C048-T01 · Quantity inventory:** Create a measurement inventory for “Throughput benchmark”: “Request volume and measurement duration”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M12.05-C048-T02 · Measurement method:** Choose how to observe each “Throughput benchmark” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M12.05-C048-T03 · Budget decision:** Select justified campaign and target-resource budgets for “Throughput benchmark”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M12.05-C048-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Throughput benchmark” cases for “Request volume and measurement duration”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M12.05-C048-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Throughput benchmark” limit; preserve “Failed or incorrect work is not counted as successful throughput”.
- [ ] **UC-M12.05-C048-T06 · Normal measurement:** Run or review the normal “Throughput benchmark” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M12.05-C048-T07 · At-limit measurement:** Exercise the “Throughput benchmark” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M12.05-C048-T08 · Over-limit measurement:** Exercise the “Throughput benchmark” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M12.05-C048-T09 · Uncovered-scope report:** List the “Throughput benchmark” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M12.05-C048-T10 · Limit evidence:** Publish the selected “Throughput benchmark” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M12.05-C049 · Diagnostics / review

**Original checklist item:** Report throughput benchmark results with executed, failed, skipped and unavailable cases separated; preserve the underlying observations and do not manufacture missing measurements.

- [ ] **UC-M12.05-C049-T01 · Result inventory:** Enumerate the required “Throughput benchmark” qualification cases and intended targets before aggregating results; keep the planned denominator visible.
- [ ] **UC-M12.05-C049-T02 · Verdict schema:** Define separate executed-pass, executed-fail, skipped, unavailable and untested outcomes for “Throughput benchmark”; document how incomplete cases block relevant claims.
- [ ] **UC-M12.05-C049-T03 · Identity fields:** Attach the actual target, fixture, configuration and revision identifiers to each “Throughput benchmark” result; do not attribute host-only evidence to a guest or another OS.
- [ ] **UC-M12.05-C049-T04 · Observation capture:** Capture bounded raw “Throughput benchmark” observations and harness errors; retain enough information to verify the reported oracle comparison.
- [ ] **UC-M12.05-C049-T05 · Aggregation rules:** Implement the “Throughput benchmark” count/reduction rule so failures and missing measurements cannot disappear; preserve “Failed or incorrect work is not counted as successful throughput”.
- [ ] **UC-M12.05-C049-T06 · Failure visibility:** Feed a failing “Throughput benchmark” control through the report path; assert the exact failed case and underlying observation remain visible.
- [ ] **UC-M12.05-C049-T07 · Missing-result visibility:** Withhold a required “Throughput benchmark” measurement or target; verify the report uses unavailable/untested rather than a fabricated zero or passing value.
- [ ] **UC-M12.05-C049-T08 · Bounds and redaction:** Check “Throughput benchmark” report size and retention against “Request volume and measurement duration”; remove secrets while retaining fixture and subject references.
- [ ] **UC-M12.05-C049-T09 · Report reconciliation:** Reconcile the “Throughput benchmark” summary with every underlying case record; account for the full planned denominator and all omitted scope.
- [ ] **UC-M12.05-C049-T10 · Qualification handoff:** Publish the “Throughput benchmark” report with measured observations, coverage limits and blockers; state which actual targets remain unqualified.

### UC-M12.05-C050 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for throughput benchmark; label unexecuted checks as untested.

- [ ] **UC-M12.05-C050-T01 · Evidence inventory:** List the “Throughput benchmark” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M12.05-C050-T02 · Artifact references:** Record the exact “Throughput benchmark” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M12.05-C050-T03 · Fixture references:** Attach the “Throughput benchmark” fixture IDs, input identities and oracle definition; preserve the source counterexample “A workload drops requests while reporting a high completion rate” as a distinct evidence case.
- [ ] **UC-M12.05-C050-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Throughput benchmark”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M12.05-C050-T05 · Environment record:** Record the actual “Throughput benchmark” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M12.05-C050-T06 · Expected versus observed:** Pair every “Throughput benchmark” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M12.05-C050-T07 · Failure and limit records:** Attach “Throughput benchmark” change/failure and bounds evidence where required; include uncovered “Request volume and measurement duration” and unresolved violations of “Failed or incorrect work is not counted as successful throughput”.
- [ ] **UC-M12.05-C050-T08 · Evidence hygiene:** Check the “Throughput benchmark” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M12.05-C050-T09 · Reproduction review:** Have the “Throughput benchmark” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M12.05-C050-T10 · Acceptance linkage:** Link the “Throughput benchmark” evidence to its parent and UC-M12.05 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 06. Tail latency benchmark

**Source delivery:** Measure latency distributions using an explicit workload and sufficient recorded samples.

**Source invariant:** Tail results identify sample count and include failure treatment.

**Source negative case:** Only average latency is used to claim low tail latency.

**Source bounded quantities:** Samples and retained distribution data.

### UC-M12.05-C051 · Contract

**Original checklist item:** Define the qualification objective for tail latency benchmark, including the actual target implementation, prerequisites, observable oracle and explicit exclusions.

- [ ] **UC-M12.05-C051-T01 · Scope statement:** Write the qualification question for “Tail latency benchmark”; identify the actual target, claimed capability and observations that can answer that question.
- [ ] **UC-M12.05-C051-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Tail latency benchmark”; record each producer, representation and missing-value meaning.
- [ ] **UC-M12.05-C051-T03 · Output inventory:** List the outputs of “Tail latency benchmark” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M12.05-C051-T04 · Field dictionary:** Create a field-and-term dictionary for “Tail latency benchmark”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M12.05-C051-T05 · Prerequisite contract:** Map “Tail latency benchmark” to the source component prerequisites (UC-M04.02, UC-M10.02); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M12.05-C051-T06 · Authority map:** Identify who may produce, change and consume “Tail latency benchmark”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M12.05-C051-T07 · Invariant clause:** Add a normative clause for “Tail latency benchmark” that preserves “Tail results identify sample count and include failure treatment”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M12.05-C051-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Tail latency benchmark”; include the source counterexample “Only average latency is used to claim low tail latency” and the intended safe disposition.
- [ ] **UC-M12.05-C051-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Samples and retained distribution data” in the “Tail latency benchmark” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M12.05-C051-T10 · Contract review:** Review the “Tail latency benchmark” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M12.05-C052 · Delivery

**Original checklist item:** Measure latency distributions using an explicit workload and sufficient recorded samples.

- [ ] **UC-M12.05-C052-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Tail latency benchmark”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M12.05-C052-T02 · Change plan:** Break the source delivery for “Tail latency benchmark” into concrete edit targets and reviewable outputs; keep the UC-M12.05 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M12.05-C052-T03 · Core artifact:** Create the “Tail latency benchmark” fixture or harness for this source instruction: Measure latency distributions using an explicit workload and sufficient recorded samples.
- [ ] **UC-M12.05-C052-T04 · Concrete realization:** Connect the “Tail latency benchmark” harness to its actual intended target, set the expected oracle before running it, and distinguish a mock/control run from a target run.
- [ ] **UC-M12.05-C052-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Tail latency benchmark” needed to preserve “Tail results identify sample count and include failure treatment”; record an enforcement gap where only a model exists.
- [ ] **UC-M12.05-C052-T06 · Dependency connection:** Connect the “Tail latency benchmark” qualification artifact to repeatable workloads, phase/resource metrics and explicit comparison baselines; record the target identity and what the harness actually exercises.
- [ ] **UC-M12.05-C052-T07 · Resource behavior:** Account for “Samples and retained distribution data” in “Tail latency benchmark”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M12.05-C052-T08 · Delivery check:** Run a known-valid control and a deliberately failing control for “Tail latency benchmark”; confirm the harness distinguishes their observed outcomes.
- [ ] **UC-M12.05-C052-T09 · Patch review:** Review the “Tail latency benchmark” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M12.05-C052-T10 · Delivery handoff:** Publish the “Tail latency benchmark” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M12.05-C053 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Tail results identify sample count and include failure treatment. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M12.05-C053-T01 · Named property:** Create a stable property/check name under this parent for “Tail latency benchmark”; copy its required invariant exactly: “Tail results identify sample count and include failure treatment”.
- [ ] **UC-M12.05-C053-T02 · Observable terms:** Define each term in the “Tail latency benchmark” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M12.05-C053-T03 · Precondition set:** List the preconditions under which “Tail results identify sample count and include failure treatment” must hold for “Tail latency benchmark”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M12.05-C053-T04 · Transition coverage:** Map the “Tail latency benchmark” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M12.05-C053-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Tail latency benchmark”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M12.05-C053-T06 · Satisfying fixture:** Create a concrete “Tail latency benchmark” case that satisfies “Tail results identify sample count and include failure treatment”; record its expected observation before running the assertion or review.
- [ ] **UC-M12.05-C053-T07 · Violating fixture:** Create the source counterexample “Only average latency is used to claim low tail latency” for “Tail latency benchmark”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M12.05-C053-T08 · Enforcement evidence:** Exercise the “Tail latency benchmark” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M12.05-C053-T09 · Regression linkage:** Link the “Tail latency benchmark” property to changes in repeatable workloads, phase/resource metrics and explicit comparison baselines; record which dependency or contract changes require rerunning it.
- [ ] **UC-M12.05-C053-T10 · Property disposition:** Compare the satisfying and violating “Tail latency benchmark” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M12.05-C054 · Integration

**Original checklist item:** Integrate tail latency benchmark with repeatable workloads, phase/resource metrics and explicit comparison baselines; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M12.05-C054-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Tail latency benchmark” across repeatable workloads, phase/resource metrics and explicit comparison baselines; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M12.05-C054-T02 · Field mapping:** Map every “Tail latency benchmark” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M12.05-C054-T03 · Prerequisite identities:** Record the actual prerequisites for “Tail latency benchmark” (source dependency list: UC-M04.02, UC-M10.02); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M12.05-C054-T04 · Ownership agreement:** Specify who owns “Tail latency benchmark” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M12.05-C054-T05 · Handoff implementation:** Connect “Tail latency benchmark” through the mapped seam using the real adapter or explicit specification reference; preserve “Tail results identify sample count and include failure treatment” across the handoff.
- [ ] **UC-M12.05-C054-T06 · Absent-input case:** Omit one required “Tail latency benchmark” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M12.05-C054-T07 · Stale-input case:** Supply an outdated “Tail latency benchmark” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M12.05-C054-T08 · Incompatible-input case:** Supply an incompatible “Tail latency benchmark” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M12.05-C054-T09 · Valid integration trace:** Run a valid “Tail latency benchmark” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M12.05-C054-T10 · Seam review:** Reconcile the “Tail latency benchmark” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M12.05-C055 · Valid-case test

**Original checklist item:** Run a known-valid control for tail latency benchmark; verify that the harness reaches its intended target and compare observed measurements or verdicts with predeclared expectations.

- [ ] **UC-M12.05-C055-T01 · Valid fixture choice:** Choose a known-valid control for “Tail latency benchmark”; document why it should pass and how it proves the harness reaches the intended target.
- [ ] **UC-M12.05-C055-T02 · Expected-result oracle:** Specify the “Tail latency benchmark” expected result independently of the implementation output; include the property “Tail results identify sample count and include failure treatment” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M12.05-C055-T03 · Fixture material:** Create the concrete “Tail latency benchmark” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M12.05-C055-T04 · Target preparation:** Prepare the “Tail latency benchmark” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M12.05-C055-T05 · Initial-state record:** Record the initial “Tail latency benchmark” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M12.05-C055-T06 · Valid-path execution:** Run the “Tail latency benchmark” known-valid control on the identified target; retain enough observations to prove the correct target was exercised.
- [ ] **UC-M12.05-C055-T07 · Outcome comparison:** Compare every declared “Tail latency benchmark” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M12.05-C055-T08 · State and bounds check:** Inspect the “Tail latency benchmark” ownership/state effects and actual use of “Samples and retained distribution data”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M12.05-C055-T09 · Repeatability check:** Repeat the same “Tail latency benchmark” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M12.05-C055-T10 · Positive evidence:** Attach the “Tail latency benchmark” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M12.05-C056 · Negative test

**Original checklist item:** Negative case: Only average latency is used to claim low tail latency. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M12.05-C056-T01 · Adverse-case definition:** Create a test record for the exact “Tail latency benchmark” source counterexample: “Only average latency is used to claim low tail latency”; state which precondition or invariant it challenges.
- [ ] **UC-M12.05-C056-T02 · Safe fixture boundary:** Define the contained test boundary for “Tail latency benchmark”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M12.05-C056-T03 · Valid control:** Construct a valid “Tail latency benchmark” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M12.05-C056-T04 · Minimal adverse input:** Derive the “Tail latency benchmark” adverse fixture from the control with the smallest documented change needed to reproduce “Only average latency is used to claim low tail latency”; retain that change as reproducible data.
- [ ] **UC-M12.05-C056-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Tail latency benchmark”; require “Tail results identify sample count and include failure treatment” and forbid a false-success verdict.
- [ ] **UC-M12.05-C056-T06 · Adverse execution:** Exercise the “Tail latency benchmark” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M12.05-C056-T07 · Effect inspection:** Inspect “Tail latency benchmark” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M12.05-C056-T08 · Refusal versus failure:** Confirm the “Tail latency benchmark” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M12.05-C056-T09 · Reset and retention:** Restore only the disposable “Tail latency benchmark” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M12.05-C056-T10 · Negative regression:** Register the “Tail latency benchmark” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M12.05-C057 · Change / failure test

**Original checklist item:** Exercise tail latency benchmark when a run fails, times out or changes environment during a measurement series; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M12.05-C057-T01 · Scenario record:** Write the “Tail latency benchmark” change/failure scenario exactly as supplied: a run fails, times out or changes environment during a measurement series; identify the property that must remain true: “Tail results identify sample count and include failure treatment”.
- [ ] **UC-M12.05-C057-T02 · Baseline capture:** Create a known-valid “Tail latency benchmark” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M12.05-C057-T03 · Injection map:** Locate the “Tail latency benchmark” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M12.05-C057-T04 · Disposition oracle:** Define the legal intermediate and final “Tail latency benchmark” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M12.05-C057-T05 · Controlled trigger:** Introduce the controlled “Tail latency benchmark” scenario in the disposable fixture: a run fails, times out or changes environment during a measurement series; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M12.05-C057-T06 · Intermediate inspection:** Inspect the “Tail latency benchmark” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M12.05-C057-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Tail latency benchmark”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M12.05-C057-T08 · Stale-evidence cleanup:** Invalidate superseded “Tail latency benchmark” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M12.05-C057-T09 · Repeat and compare:** Repeat the selected “Tail latency benchmark” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M12.05-C057-T10 · Failure evidence:** Publish the “Tail latency benchmark” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M12.05-C058 · Bounds

**Original checklist item:** Set a documented campaign budget for samples and retained distribution data; record actual consumption, incomplete coverage and the disposition when the budget is exhausted.

- [ ] **UC-M12.05-C058-T01 · Quantity inventory:** Create a measurement inventory for “Tail latency benchmark”: “Samples and retained distribution data”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M12.05-C058-T02 · Measurement method:** Choose how to observe each “Tail latency benchmark” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M12.05-C058-T03 · Budget decision:** Select justified campaign and target-resource budgets for “Tail latency benchmark”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M12.05-C058-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Tail latency benchmark” cases for “Samples and retained distribution data”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M12.05-C058-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Tail latency benchmark” limit; preserve “Tail results identify sample count and include failure treatment”.
- [ ] **UC-M12.05-C058-T06 · Normal measurement:** Run or review the normal “Tail latency benchmark” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M12.05-C058-T07 · At-limit measurement:** Exercise the “Tail latency benchmark” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M12.05-C058-T08 · Over-limit measurement:** Exercise the “Tail latency benchmark” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M12.05-C058-T09 · Uncovered-scope report:** List the “Tail latency benchmark” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M12.05-C058-T10 · Limit evidence:** Publish the selected “Tail latency benchmark” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M12.05-C059 · Diagnostics / review

**Original checklist item:** Report tail latency benchmark results with executed, failed, skipped and unavailable cases separated; preserve the underlying observations and do not manufacture missing measurements.

- [ ] **UC-M12.05-C059-T01 · Result inventory:** Enumerate the required “Tail latency benchmark” qualification cases and intended targets before aggregating results; keep the planned denominator visible.
- [ ] **UC-M12.05-C059-T02 · Verdict schema:** Define separate executed-pass, executed-fail, skipped, unavailable and untested outcomes for “Tail latency benchmark”; document how incomplete cases block relevant claims.
- [ ] **UC-M12.05-C059-T03 · Identity fields:** Attach the actual target, fixture, configuration and revision identifiers to each “Tail latency benchmark” result; do not attribute host-only evidence to a guest or another OS.
- [ ] **UC-M12.05-C059-T04 · Observation capture:** Capture bounded raw “Tail latency benchmark” observations and harness errors; retain enough information to verify the reported oracle comparison.
- [ ] **UC-M12.05-C059-T05 · Aggregation rules:** Implement the “Tail latency benchmark” count/reduction rule so failures and missing measurements cannot disappear; preserve “Tail results identify sample count and include failure treatment”.
- [ ] **UC-M12.05-C059-T06 · Failure visibility:** Feed a failing “Tail latency benchmark” control through the report path; assert the exact failed case and underlying observation remain visible.
- [ ] **UC-M12.05-C059-T07 · Missing-result visibility:** Withhold a required “Tail latency benchmark” measurement or target; verify the report uses unavailable/untested rather than a fabricated zero or passing value.
- [ ] **UC-M12.05-C059-T08 · Bounds and redaction:** Check “Tail latency benchmark” report size and retention against “Samples and retained distribution data”; remove secrets while retaining fixture and subject references.
- [ ] **UC-M12.05-C059-T09 · Report reconciliation:** Reconcile the “Tail latency benchmark” summary with every underlying case record; account for the full planned denominator and all omitted scope.
- [ ] **UC-M12.05-C059-T10 · Qualification handoff:** Publish the “Tail latency benchmark” report with measured observations, coverage limits and blockers; state which actual targets remain unqualified.

### UC-M12.05-C060 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for tail latency benchmark; label unexecuted checks as untested.

- [ ] **UC-M12.05-C060-T01 · Evidence inventory:** List the “Tail latency benchmark” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M12.05-C060-T02 · Artifact references:** Record the exact “Tail latency benchmark” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M12.05-C060-T03 · Fixture references:** Attach the “Tail latency benchmark” fixture IDs, input identities and oracle definition; preserve the source counterexample “Only average latency is used to claim low tail latency” as a distinct evidence case.
- [ ] **UC-M12.05-C060-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Tail latency benchmark”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M12.05-C060-T05 · Environment record:** Record the actual “Tail latency benchmark” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M12.05-C060-T06 · Expected versus observed:** Pair every “Tail latency benchmark” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M12.05-C060-T07 · Failure and limit records:** Attach “Tail latency benchmark” change/failure and bounds evidence where required; include uncovered “Samples and retained distribution data” and unresolved violations of “Tail results identify sample count and include failure treatment”.
- [ ] **UC-M12.05-C060-T08 · Evidence hygiene:** Check the “Tail latency benchmark” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M12.05-C060-T09 · Reproduction review:** Have the “Tail latency benchmark” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M12.05-C060-T10 · Acceptance linkage:** Link the “Tail latency benchmark” evidence to its parent and UC-M12.05 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 07. Peak memory benchmark

**Source delivery:** Measure guest and required host overhead within a documented accounting boundary.

**Source invariant:** Peak RSS claims do not silently exclude compiler or decoder workers.

**Source negative case:** The memory peak occurs in an unmeasured helper process.

**Source bounded quantities:** Processes and sampling interval.

### UC-M12.05-C061 · Contract

**Original checklist item:** Define the qualification objective for peak memory benchmark, including the actual target implementation, prerequisites, observable oracle and explicit exclusions.

- [ ] **UC-M12.05-C061-T01 · Scope statement:** Write the qualification question for “Peak memory benchmark”; identify the actual target, claimed capability and observations that can answer that question.
- [ ] **UC-M12.05-C061-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Peak memory benchmark”; record each producer, representation and missing-value meaning.
- [ ] **UC-M12.05-C061-T03 · Output inventory:** List the outputs of “Peak memory benchmark” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M12.05-C061-T04 · Field dictionary:** Create a field-and-term dictionary for “Peak memory benchmark”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M12.05-C061-T05 · Prerequisite contract:** Map “Peak memory benchmark” to the source component prerequisites (UC-M04.02, UC-M10.02); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M12.05-C061-T06 · Authority map:** Identify who may produce, change and consume “Peak memory benchmark”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M12.05-C061-T07 · Invariant clause:** Add a normative clause for “Peak memory benchmark” that preserves “Peak RSS claims do not silently exclude compiler or decoder workers”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M12.05-C061-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Peak memory benchmark”; include the source counterexample “The memory peak occurs in an unmeasured helper process” and the intended safe disposition.
- [ ] **UC-M12.05-C061-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Processes and sampling interval” in the “Peak memory benchmark” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M12.05-C061-T10 · Contract review:** Review the “Peak memory benchmark” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M12.05-C062 · Delivery

**Original checklist item:** Measure guest and required host overhead within a documented accounting boundary.

- [ ] **UC-M12.05-C062-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Peak memory benchmark”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M12.05-C062-T02 · Change plan:** Break the source delivery for “Peak memory benchmark” into concrete edit targets and reviewable outputs; keep the UC-M12.05 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M12.05-C062-T03 · Core artifact:** Create the “Peak memory benchmark” fixture or harness for this source instruction: Measure guest and required host overhead within a documented accounting boundary.
- [ ] **UC-M12.05-C062-T04 · Concrete realization:** Connect the “Peak memory benchmark” harness to its actual intended target, set the expected oracle before running it, and distinguish a mock/control run from a target run.
- [ ] **UC-M12.05-C062-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Peak memory benchmark” needed to preserve “Peak RSS claims do not silently exclude compiler or decoder workers”; record an enforcement gap where only a model exists.
- [ ] **UC-M12.05-C062-T06 · Dependency connection:** Connect the “Peak memory benchmark” qualification artifact to repeatable workloads, phase/resource metrics and explicit comparison baselines; record the target identity and what the harness actually exercises.
- [ ] **UC-M12.05-C062-T07 · Resource behavior:** Account for “Processes and sampling interval” in “Peak memory benchmark”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M12.05-C062-T08 · Delivery check:** Run a known-valid control and a deliberately failing control for “Peak memory benchmark”; confirm the harness distinguishes their observed outcomes.
- [ ] **UC-M12.05-C062-T09 · Patch review:** Review the “Peak memory benchmark” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M12.05-C062-T10 · Delivery handoff:** Publish the “Peak memory benchmark” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M12.05-C063 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Peak RSS claims do not silently exclude compiler or decoder workers. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M12.05-C063-T01 · Named property:** Create a stable property/check name under this parent for “Peak memory benchmark”; copy its required invariant exactly: “Peak RSS claims do not silently exclude compiler or decoder workers”.
- [ ] **UC-M12.05-C063-T02 · Observable terms:** Define each term in the “Peak memory benchmark” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M12.05-C063-T03 · Precondition set:** List the preconditions under which “Peak RSS claims do not silently exclude compiler or decoder workers” must hold for “Peak memory benchmark”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M12.05-C063-T04 · Transition coverage:** Map the “Peak memory benchmark” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M12.05-C063-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Peak memory benchmark”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M12.05-C063-T06 · Satisfying fixture:** Create a concrete “Peak memory benchmark” case that satisfies “Peak RSS claims do not silently exclude compiler or decoder workers”; record its expected observation before running the assertion or review.
- [ ] **UC-M12.05-C063-T07 · Violating fixture:** Create the source counterexample “The memory peak occurs in an unmeasured helper process” for “Peak memory benchmark”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M12.05-C063-T08 · Enforcement evidence:** Exercise the “Peak memory benchmark” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M12.05-C063-T09 · Regression linkage:** Link the “Peak memory benchmark” property to changes in repeatable workloads, phase/resource metrics and explicit comparison baselines; record which dependency or contract changes require rerunning it.
- [ ] **UC-M12.05-C063-T10 · Property disposition:** Compare the satisfying and violating “Peak memory benchmark” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M12.05-C064 · Integration

**Original checklist item:** Integrate peak memory benchmark with repeatable workloads, phase/resource metrics and explicit comparison baselines; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M12.05-C064-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Peak memory benchmark” across repeatable workloads, phase/resource metrics and explicit comparison baselines; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M12.05-C064-T02 · Field mapping:** Map every “Peak memory benchmark” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M12.05-C064-T03 · Prerequisite identities:** Record the actual prerequisites for “Peak memory benchmark” (source dependency list: UC-M04.02, UC-M10.02); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M12.05-C064-T04 · Ownership agreement:** Specify who owns “Peak memory benchmark” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M12.05-C064-T05 · Handoff implementation:** Connect “Peak memory benchmark” through the mapped seam using the real adapter or explicit specification reference; preserve “Peak RSS claims do not silently exclude compiler or decoder workers” across the handoff.
- [ ] **UC-M12.05-C064-T06 · Absent-input case:** Omit one required “Peak memory benchmark” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M12.05-C064-T07 · Stale-input case:** Supply an outdated “Peak memory benchmark” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M12.05-C064-T08 · Incompatible-input case:** Supply an incompatible “Peak memory benchmark” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M12.05-C064-T09 · Valid integration trace:** Run a valid “Peak memory benchmark” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M12.05-C064-T10 · Seam review:** Reconcile the “Peak memory benchmark” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M12.05-C065 · Valid-case test

**Original checklist item:** Run a known-valid control for peak memory benchmark; verify that the harness reaches its intended target and compare observed measurements or verdicts with predeclared expectations.

- [ ] **UC-M12.05-C065-T01 · Valid fixture choice:** Choose a known-valid control for “Peak memory benchmark”; document why it should pass and how it proves the harness reaches the intended target.
- [ ] **UC-M12.05-C065-T02 · Expected-result oracle:** Specify the “Peak memory benchmark” expected result independently of the implementation output; include the property “Peak RSS claims do not silently exclude compiler or decoder workers” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M12.05-C065-T03 · Fixture material:** Create the concrete “Peak memory benchmark” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M12.05-C065-T04 · Target preparation:** Prepare the “Peak memory benchmark” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M12.05-C065-T05 · Initial-state record:** Record the initial “Peak memory benchmark” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M12.05-C065-T06 · Valid-path execution:** Run the “Peak memory benchmark” known-valid control on the identified target; retain enough observations to prove the correct target was exercised.
- [ ] **UC-M12.05-C065-T07 · Outcome comparison:** Compare every declared “Peak memory benchmark” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M12.05-C065-T08 · State and bounds check:** Inspect the “Peak memory benchmark” ownership/state effects and actual use of “Processes and sampling interval”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M12.05-C065-T09 · Repeatability check:** Repeat the same “Peak memory benchmark” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M12.05-C065-T10 · Positive evidence:** Attach the “Peak memory benchmark” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M12.05-C066 · Negative test

**Original checklist item:** Negative case: The memory peak occurs in an unmeasured helper process. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M12.05-C066-T01 · Adverse-case definition:** Create a test record for the exact “Peak memory benchmark” source counterexample: “The memory peak occurs in an unmeasured helper process”; state which precondition or invariant it challenges.
- [ ] **UC-M12.05-C066-T02 · Safe fixture boundary:** Define the contained test boundary for “Peak memory benchmark”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M12.05-C066-T03 · Valid control:** Construct a valid “Peak memory benchmark” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M12.05-C066-T04 · Minimal adverse input:** Derive the “Peak memory benchmark” adverse fixture from the control with the smallest documented change needed to reproduce “The memory peak occurs in an unmeasured helper process”; retain that change as reproducible data.
- [ ] **UC-M12.05-C066-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Peak memory benchmark”; require “Peak RSS claims do not silently exclude compiler or decoder workers” and forbid a false-success verdict.
- [ ] **UC-M12.05-C066-T06 · Adverse execution:** Exercise the “Peak memory benchmark” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M12.05-C066-T07 · Effect inspection:** Inspect “Peak memory benchmark” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M12.05-C066-T08 · Refusal versus failure:** Confirm the “Peak memory benchmark” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M12.05-C066-T09 · Reset and retention:** Restore only the disposable “Peak memory benchmark” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M12.05-C066-T10 · Negative regression:** Register the “Peak memory benchmark” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M12.05-C067 · Change / failure test

**Original checklist item:** Exercise peak memory benchmark when a run fails, times out or changes environment during a measurement series; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M12.05-C067-T01 · Scenario record:** Write the “Peak memory benchmark” change/failure scenario exactly as supplied: a run fails, times out or changes environment during a measurement series; identify the property that must remain true: “Peak RSS claims do not silently exclude compiler or decoder workers”.
- [ ] **UC-M12.05-C067-T02 · Baseline capture:** Create a known-valid “Peak memory benchmark” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M12.05-C067-T03 · Injection map:** Locate the “Peak memory benchmark” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M12.05-C067-T04 · Disposition oracle:** Define the legal intermediate and final “Peak memory benchmark” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M12.05-C067-T05 · Controlled trigger:** Introduce the controlled “Peak memory benchmark” scenario in the disposable fixture: a run fails, times out or changes environment during a measurement series; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M12.05-C067-T06 · Intermediate inspection:** Inspect the “Peak memory benchmark” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M12.05-C067-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Peak memory benchmark”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M12.05-C067-T08 · Stale-evidence cleanup:** Invalidate superseded “Peak memory benchmark” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M12.05-C067-T09 · Repeat and compare:** Repeat the selected “Peak memory benchmark” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M12.05-C067-T10 · Failure evidence:** Publish the “Peak memory benchmark” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M12.05-C068 · Bounds

**Original checklist item:** Set a documented campaign budget for processes and sampling interval; record actual consumption, incomplete coverage and the disposition when the budget is exhausted.

- [ ] **UC-M12.05-C068-T01 · Quantity inventory:** Create a measurement inventory for “Peak memory benchmark”: “Processes and sampling interval”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M12.05-C068-T02 · Measurement method:** Choose how to observe each “Peak memory benchmark” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M12.05-C068-T03 · Budget decision:** Select justified campaign and target-resource budgets for “Peak memory benchmark”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M12.05-C068-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Peak memory benchmark” cases for “Processes and sampling interval”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M12.05-C068-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Peak memory benchmark” limit; preserve “Peak RSS claims do not silently exclude compiler or decoder workers”.
- [ ] **UC-M12.05-C068-T06 · Normal measurement:** Run or review the normal “Peak memory benchmark” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M12.05-C068-T07 · At-limit measurement:** Exercise the “Peak memory benchmark” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M12.05-C068-T08 · Over-limit measurement:** Exercise the “Peak memory benchmark” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M12.05-C068-T09 · Uncovered-scope report:** List the “Peak memory benchmark” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M12.05-C068-T10 · Limit evidence:** Publish the selected “Peak memory benchmark” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M12.05-C069 · Diagnostics / review

**Original checklist item:** Report peak memory benchmark results with executed, failed, skipped and unavailable cases separated; preserve the underlying observations and do not manufacture missing measurements.

- [ ] **UC-M12.05-C069-T01 · Result inventory:** Enumerate the required “Peak memory benchmark” qualification cases and intended targets before aggregating results; keep the planned denominator visible.
- [ ] **UC-M12.05-C069-T02 · Verdict schema:** Define separate executed-pass, executed-fail, skipped, unavailable and untested outcomes for “Peak memory benchmark”; document how incomplete cases block relevant claims.
- [ ] **UC-M12.05-C069-T03 · Identity fields:** Attach the actual target, fixture, configuration and revision identifiers to each “Peak memory benchmark” result; do not attribute host-only evidence to a guest or another OS.
- [ ] **UC-M12.05-C069-T04 · Observation capture:** Capture bounded raw “Peak memory benchmark” observations and harness errors; retain enough information to verify the reported oracle comparison.
- [ ] **UC-M12.05-C069-T05 · Aggregation rules:** Implement the “Peak memory benchmark” count/reduction rule so failures and missing measurements cannot disappear; preserve “Peak RSS claims do not silently exclude compiler or decoder workers”.
- [ ] **UC-M12.05-C069-T06 · Failure visibility:** Feed a failing “Peak memory benchmark” control through the report path; assert the exact failed case and underlying observation remain visible.
- [ ] **UC-M12.05-C069-T07 · Missing-result visibility:** Withhold a required “Peak memory benchmark” measurement or target; verify the report uses unavailable/untested rather than a fabricated zero or passing value.
- [ ] **UC-M12.05-C069-T08 · Bounds and redaction:** Check “Peak memory benchmark” report size and retention against “Processes and sampling interval”; remove secrets while retaining fixture and subject references.
- [ ] **UC-M12.05-C069-T09 · Report reconciliation:** Reconcile the “Peak memory benchmark” summary with every underlying case record; account for the full planned denominator and all omitted scope.
- [ ] **UC-M12.05-C069-T10 · Qualification handoff:** Publish the “Peak memory benchmark” report with measured observations, coverage limits and blockers; state which actual targets remain unqualified.

### UC-M12.05-C070 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for peak memory benchmark; label unexecuted checks as untested.

- [ ] **UC-M12.05-C070-T01 · Evidence inventory:** List the “Peak memory benchmark” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M12.05-C070-T02 · Artifact references:** Record the exact “Peak memory benchmark” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M12.05-C070-T03 · Fixture references:** Attach the “Peak memory benchmark” fixture IDs, input identities and oracle definition; preserve the source counterexample “The memory peak occurs in an unmeasured helper process” as a distinct evidence case.
- [ ] **UC-M12.05-C070-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Peak memory benchmark”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M12.05-C070-T05 · Environment record:** Record the actual “Peak memory benchmark” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M12.05-C070-T06 · Expected versus observed:** Pair every “Peak memory benchmark” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M12.05-C070-T07 · Failure and limit records:** Attach “Peak memory benchmark” change/failure and bounds evidence where required; include uncovered “Processes and sampling interval” and unresolved violations of “Peak RSS claims do not silently exclude compiler or decoder workers”.
- [ ] **UC-M12.05-C070-T08 · Evidence hygiene:** Check the “Peak memory benchmark” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M12.05-C070-T09 · Reproduction review:** Have the “Peak memory benchmark” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M12.05-C070-T10 · Acceptance linkage:** Link the “Peak memory benchmark” evidence to its parent and UC-M12.05 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 08. Long-run state growth

**Source delivery:** Measure TIFF, checkpoint and retained-history growth over repeated workload progress.

**Source invariant:** Initial image size is not presented as long-run storage cost.

**Source negative case:** History rollover adds unreported retained storage.

**Source bounded quantities:** Ticks, pages and retained bytes.

### UC-M12.05-C071 · Contract

**Original checklist item:** Define the qualification objective for long-run state growth, including the actual target implementation, prerequisites, observable oracle and explicit exclusions.

- [ ] **UC-M12.05-C071-T01 · Scope statement:** Write the qualification question for “Long-run state growth”; identify the actual target, claimed capability and observations that can answer that question.
- [ ] **UC-M12.05-C071-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Long-run state growth”; record each producer, representation and missing-value meaning.
- [ ] **UC-M12.05-C071-T03 · Output inventory:** List the outputs of “Long-run state growth” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M12.05-C071-T04 · Field dictionary:** Create a field-and-term dictionary for “Long-run state growth”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M12.05-C071-T05 · Prerequisite contract:** Map “Long-run state growth” to the source component prerequisites (UC-M04.02, UC-M10.02); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M12.05-C071-T06 · Authority map:** Identify who may produce, change and consume “Long-run state growth”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M12.05-C071-T07 · Invariant clause:** Add a normative clause for “Long-run state growth” that preserves “Initial image size is not presented as long-run storage cost”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M12.05-C071-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Long-run state growth”; include the source counterexample “History rollover adds unreported retained storage” and the intended safe disposition.
- [ ] **UC-M12.05-C071-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Ticks, pages and retained bytes” in the “Long-run state growth” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M12.05-C071-T10 · Contract review:** Review the “Long-run state growth” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M12.05-C072 · Delivery

**Original checklist item:** Measure TIFF, checkpoint and retained-history growth over repeated workload progress.

- [ ] **UC-M12.05-C072-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Long-run state growth”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M12.05-C072-T02 · Change plan:** Break the source delivery for “Long-run state growth” into concrete edit targets and reviewable outputs; keep the UC-M12.05 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M12.05-C072-T03 · Core artifact:** Create the “Long-run state growth” fixture or harness for this source instruction: Measure TIFF, checkpoint and retained-history growth over repeated workload progress.
- [ ] **UC-M12.05-C072-T04 · Concrete realization:** Connect the “Long-run state growth” harness to its actual intended target, set the expected oracle before running it, and distinguish a mock/control run from a target run.
- [ ] **UC-M12.05-C072-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Long-run state growth” needed to preserve “Initial image size is not presented as long-run storage cost”; record an enforcement gap where only a model exists.
- [ ] **UC-M12.05-C072-T06 · Dependency connection:** Connect the “Long-run state growth” qualification artifact to repeatable workloads, phase/resource metrics and explicit comparison baselines; record the target identity and what the harness actually exercises.
- [ ] **UC-M12.05-C072-T07 · Resource behavior:** Account for “Ticks, pages and retained bytes” in “Long-run state growth”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M12.05-C072-T08 · Delivery check:** Run a known-valid control and a deliberately failing control for “Long-run state growth”; confirm the harness distinguishes their observed outcomes.
- [ ] **UC-M12.05-C072-T09 · Patch review:** Review the “Long-run state growth” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M12.05-C072-T10 · Delivery handoff:** Publish the “Long-run state growth” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M12.05-C073 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Initial image size is not presented as long-run storage cost. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M12.05-C073-T01 · Named property:** Create a stable property/check name under this parent for “Long-run state growth”; copy its required invariant exactly: “Initial image size is not presented as long-run storage cost”.
- [ ] **UC-M12.05-C073-T02 · Observable terms:** Define each term in the “Long-run state growth” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M12.05-C073-T03 · Precondition set:** List the preconditions under which “Initial image size is not presented as long-run storage cost” must hold for “Long-run state growth”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M12.05-C073-T04 · Transition coverage:** Map the “Long-run state growth” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M12.05-C073-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Long-run state growth”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M12.05-C073-T06 · Satisfying fixture:** Create a concrete “Long-run state growth” case that satisfies “Initial image size is not presented as long-run storage cost”; record its expected observation before running the assertion or review.
- [ ] **UC-M12.05-C073-T07 · Violating fixture:** Create the source counterexample “History rollover adds unreported retained storage” for “Long-run state growth”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M12.05-C073-T08 · Enforcement evidence:** Exercise the “Long-run state growth” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M12.05-C073-T09 · Regression linkage:** Link the “Long-run state growth” property to changes in repeatable workloads, phase/resource metrics and explicit comparison baselines; record which dependency or contract changes require rerunning it.
- [ ] **UC-M12.05-C073-T10 · Property disposition:** Compare the satisfying and violating “Long-run state growth” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M12.05-C074 · Integration

**Original checklist item:** Integrate long-run state growth with repeatable workloads, phase/resource metrics and explicit comparison baselines; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M12.05-C074-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Long-run state growth” across repeatable workloads, phase/resource metrics and explicit comparison baselines; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M12.05-C074-T02 · Field mapping:** Map every “Long-run state growth” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M12.05-C074-T03 · Prerequisite identities:** Record the actual prerequisites for “Long-run state growth” (source dependency list: UC-M04.02, UC-M10.02); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M12.05-C074-T04 · Ownership agreement:** Specify who owns “Long-run state growth” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M12.05-C074-T05 · Handoff implementation:** Connect “Long-run state growth” through the mapped seam using the real adapter or explicit specification reference; preserve “Initial image size is not presented as long-run storage cost” across the handoff.
- [ ] **UC-M12.05-C074-T06 · Absent-input case:** Omit one required “Long-run state growth” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M12.05-C074-T07 · Stale-input case:** Supply an outdated “Long-run state growth” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M12.05-C074-T08 · Incompatible-input case:** Supply an incompatible “Long-run state growth” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M12.05-C074-T09 · Valid integration trace:** Run a valid “Long-run state growth” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M12.05-C074-T10 · Seam review:** Reconcile the “Long-run state growth” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M12.05-C075 · Valid-case test

**Original checklist item:** Run a known-valid control for long-run state growth; verify that the harness reaches its intended target and compare observed measurements or verdicts with predeclared expectations.

- [ ] **UC-M12.05-C075-T01 · Valid fixture choice:** Choose a known-valid control for “Long-run state growth”; document why it should pass and how it proves the harness reaches the intended target.
- [ ] **UC-M12.05-C075-T02 · Expected-result oracle:** Specify the “Long-run state growth” expected result independently of the implementation output; include the property “Initial image size is not presented as long-run storage cost” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M12.05-C075-T03 · Fixture material:** Create the concrete “Long-run state growth” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M12.05-C075-T04 · Target preparation:** Prepare the “Long-run state growth” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M12.05-C075-T05 · Initial-state record:** Record the initial “Long-run state growth” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M12.05-C075-T06 · Valid-path execution:** Run the “Long-run state growth” known-valid control on the identified target; retain enough observations to prove the correct target was exercised.
- [ ] **UC-M12.05-C075-T07 · Outcome comparison:** Compare every declared “Long-run state growth” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M12.05-C075-T08 · State and bounds check:** Inspect the “Long-run state growth” ownership/state effects and actual use of “Ticks, pages and retained bytes”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M12.05-C075-T09 · Repeatability check:** Repeat the same “Long-run state growth” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M12.05-C075-T10 · Positive evidence:** Attach the “Long-run state growth” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M12.05-C076 · Negative test

**Original checklist item:** Negative case: History rollover adds unreported retained storage. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M12.05-C076-T01 · Adverse-case definition:** Create a test record for the exact “Long-run state growth” source counterexample: “History rollover adds unreported retained storage”; state which precondition or invariant it challenges.
- [ ] **UC-M12.05-C076-T02 · Safe fixture boundary:** Define the contained test boundary for “Long-run state growth”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M12.05-C076-T03 · Valid control:** Construct a valid “Long-run state growth” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M12.05-C076-T04 · Minimal adverse input:** Derive the “Long-run state growth” adverse fixture from the control with the smallest documented change needed to reproduce “History rollover adds unreported retained storage”; retain that change as reproducible data.
- [ ] **UC-M12.05-C076-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Long-run state growth”; require “Initial image size is not presented as long-run storage cost” and forbid a false-success verdict.
- [ ] **UC-M12.05-C076-T06 · Adverse execution:** Exercise the “Long-run state growth” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M12.05-C076-T07 · Effect inspection:** Inspect “Long-run state growth” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M12.05-C076-T08 · Refusal versus failure:** Confirm the “Long-run state growth” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M12.05-C076-T09 · Reset and retention:** Restore only the disposable “Long-run state growth” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M12.05-C076-T10 · Negative regression:** Register the “Long-run state growth” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M12.05-C077 · Change / failure test

**Original checklist item:** Exercise long-run state growth when a run fails, times out or changes environment during a measurement series; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M12.05-C077-T01 · Scenario record:** Write the “Long-run state growth” change/failure scenario exactly as supplied: a run fails, times out or changes environment during a measurement series; identify the property that must remain true: “Initial image size is not presented as long-run storage cost”.
- [ ] **UC-M12.05-C077-T02 · Baseline capture:** Create a known-valid “Long-run state growth” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M12.05-C077-T03 · Injection map:** Locate the “Long-run state growth” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M12.05-C077-T04 · Disposition oracle:** Define the legal intermediate and final “Long-run state growth” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M12.05-C077-T05 · Controlled trigger:** Introduce the controlled “Long-run state growth” scenario in the disposable fixture: a run fails, times out or changes environment during a measurement series; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M12.05-C077-T06 · Intermediate inspection:** Inspect the “Long-run state growth” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M12.05-C077-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Long-run state growth”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M12.05-C077-T08 · Stale-evidence cleanup:** Invalidate superseded “Long-run state growth” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M12.05-C077-T09 · Repeat and compare:** Repeat the selected “Long-run state growth” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M12.05-C077-T10 · Failure evidence:** Publish the “Long-run state growth” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M12.05-C078 · Bounds

**Original checklist item:** Set a documented campaign budget for ticks, pages and retained bytes; record actual consumption, incomplete coverage and the disposition when the budget is exhausted.

- [ ] **UC-M12.05-C078-T01 · Quantity inventory:** Create a measurement inventory for “Long-run state growth”: “Ticks, pages and retained bytes”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M12.05-C078-T02 · Measurement method:** Choose how to observe each “Long-run state growth” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M12.05-C078-T03 · Budget decision:** Select justified campaign and target-resource budgets for “Long-run state growth”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M12.05-C078-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Long-run state growth” cases for “Ticks, pages and retained bytes”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M12.05-C078-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Long-run state growth” limit; preserve “Initial image size is not presented as long-run storage cost”.
- [ ] **UC-M12.05-C078-T06 · Normal measurement:** Run or review the normal “Long-run state growth” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M12.05-C078-T07 · At-limit measurement:** Exercise the “Long-run state growth” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M12.05-C078-T08 · Over-limit measurement:** Exercise the “Long-run state growth” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M12.05-C078-T09 · Uncovered-scope report:** List the “Long-run state growth” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M12.05-C078-T10 · Limit evidence:** Publish the selected “Long-run state growth” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M12.05-C079 · Diagnostics / review

**Original checklist item:** Report long-run state growth results with executed, failed, skipped and unavailable cases separated; preserve the underlying observations and do not manufacture missing measurements.

- [ ] **UC-M12.05-C079-T01 · Result inventory:** Enumerate the required “Long-run state growth” qualification cases and intended targets before aggregating results; keep the planned denominator visible.
- [ ] **UC-M12.05-C079-T02 · Verdict schema:** Define separate executed-pass, executed-fail, skipped, unavailable and untested outcomes for “Long-run state growth”; document how incomplete cases block relevant claims.
- [ ] **UC-M12.05-C079-T03 · Identity fields:** Attach the actual target, fixture, configuration and revision identifiers to each “Long-run state growth” result; do not attribute host-only evidence to a guest or another OS.
- [ ] **UC-M12.05-C079-T04 · Observation capture:** Capture bounded raw “Long-run state growth” observations and harness errors; retain enough information to verify the reported oracle comparison.
- [ ] **UC-M12.05-C079-T05 · Aggregation rules:** Implement the “Long-run state growth” count/reduction rule so failures and missing measurements cannot disappear; preserve “Initial image size is not presented as long-run storage cost”.
- [ ] **UC-M12.05-C079-T06 · Failure visibility:** Feed a failing “Long-run state growth” control through the report path; assert the exact failed case and underlying observation remain visible.
- [ ] **UC-M12.05-C079-T07 · Missing-result visibility:** Withhold a required “Long-run state growth” measurement or target; verify the report uses unavailable/untested rather than a fabricated zero or passing value.
- [ ] **UC-M12.05-C079-T08 · Bounds and redaction:** Check “Long-run state growth” report size and retention against “Ticks, pages and retained bytes”; remove secrets while retaining fixture and subject references.
- [ ] **UC-M12.05-C079-T09 · Report reconciliation:** Reconcile the “Long-run state growth” summary with every underlying case record; account for the full planned denominator and all omitted scope.
- [ ] **UC-M12.05-C079-T10 · Qualification handoff:** Publish the “Long-run state growth” report with measured observations, coverage limits and blockers; state which actual targets remain unqualified.

### UC-M12.05-C080 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for long-run state growth; label unexecuted checks as untested.

- [ ] **UC-M12.05-C080-T01 · Evidence inventory:** List the “Long-run state growth” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M12.05-C080-T02 · Artifact references:** Record the exact “Long-run state growth” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M12.05-C080-T03 · Fixture references:** Attach the “Long-run state growth” fixture IDs, input identities and oracle definition; preserve the source counterexample “History rollover adds unreported retained storage” as a distinct evidence case.
- [ ] **UC-M12.05-C080-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Long-run state growth”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M12.05-C080-T05 · Environment record:** Record the actual “Long-run state growth” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M12.05-C080-T06 · Expected versus observed:** Pair every “Long-run state growth” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M12.05-C080-T07 · Failure and limit records:** Attach “Long-run state growth” change/failure and bounds evidence where required; include uncovered “Ticks, pages and retained bytes” and unresolved violations of “Initial image size is not presented as long-run storage cost”.
- [ ] **UC-M12.05-C080-T08 · Evidence hygiene:** Check the “Long-run state growth” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M12.05-C080-T09 · Reproduction review:** Have the “Long-run state growth” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M12.05-C080-T10 · Acceptance linkage:** Link the “Long-run state growth” evidence to its parent and UC-M12.05 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 09. Failure-rate accounting

**Source delivery:** Record unsuccessful runs, timeouts and invalid outputs alongside successful measurements.

**Source invariant:** Performance summaries cannot discard inconvenient failures silently.

**Source negative case:** Only successful runs are used without reporting excluded failures.

**Source bounded quantities:** Trial count and failure categories.

### UC-M12.05-C081 · Contract

**Original checklist item:** Define the qualification objective for failure-rate accounting, including the actual target implementation, prerequisites, observable oracle and explicit exclusions.

- [ ] **UC-M12.05-C081-T01 · Scope statement:** Write the qualification question for “Failure-rate accounting”; identify the actual target, claimed capability and observations that can answer that question.
- [ ] **UC-M12.05-C081-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Failure-rate accounting”; record each producer, representation and missing-value meaning.
- [ ] **UC-M12.05-C081-T03 · Output inventory:** List the outputs of “Failure-rate accounting” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M12.05-C081-T04 · Field dictionary:** Create a field-and-term dictionary for “Failure-rate accounting”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M12.05-C081-T05 · Prerequisite contract:** Map “Failure-rate accounting” to the source component prerequisites (UC-M04.02, UC-M10.02); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M12.05-C081-T06 · Authority map:** Identify who may produce, change and consume “Failure-rate accounting”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M12.05-C081-T07 · Invariant clause:** Add a normative clause for “Failure-rate accounting” that preserves “Performance summaries cannot discard inconvenient failures silently”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M12.05-C081-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Failure-rate accounting”; include the source counterexample “Only successful runs are used without reporting excluded failures” and the intended safe disposition.
- [ ] **UC-M12.05-C081-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Trial count and failure categories” in the “Failure-rate accounting” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M12.05-C081-T10 · Contract review:** Review the “Failure-rate accounting” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M12.05-C082 · Delivery

**Original checklist item:** Record unsuccessful runs, timeouts and invalid outputs alongside successful measurements.

- [ ] **UC-M12.05-C082-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Failure-rate accounting”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M12.05-C082-T02 · Change plan:** Break the source delivery for “Failure-rate accounting” into concrete edit targets and reviewable outputs; keep the UC-M12.05 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M12.05-C082-T03 · Core artifact:** Create the “Failure-rate accounting” model, schema or inventory that realizes this source instruction: Record unsuccessful runs, timeouts and invalid outputs alongside successful measurements.
- [ ] **UC-M12.05-C082-T04 · Concrete realization:** Populate “Failure-rate accounting” with one concrete worked case; map every required entity or field to its source and flag any unmapped entry.
- [ ] **UC-M12.05-C082-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Failure-rate accounting” needed to preserve “Performance summaries cannot discard inconvenient failures silently”; record an enforcement gap where only a model exists.
- [ ] **UC-M12.05-C082-T06 · Dependency connection:** Connect the “Failure-rate accounting” qualification artifact to repeatable workloads, phase/resource metrics and explicit comparison baselines; record the target identity and what the harness actually exercises.
- [ ] **UC-M12.05-C082-T07 · Resource behavior:** Account for “Trial count and failure categories” in “Failure-rate accounting”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M12.05-C082-T08 · Delivery check:** Run a known-valid control and a deliberately failing control for “Failure-rate accounting”; confirm the harness distinguishes their observed outcomes.
- [ ] **UC-M12.05-C082-T09 · Patch review:** Review the “Failure-rate accounting” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M12.05-C082-T10 · Delivery handoff:** Publish the “Failure-rate accounting” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M12.05-C083 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Performance summaries cannot discard inconvenient failures silently. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M12.05-C083-T01 · Named property:** Create a stable property/check name under this parent for “Failure-rate accounting”; copy its required invariant exactly: “Performance summaries cannot discard inconvenient failures silently”.
- [ ] **UC-M12.05-C083-T02 · Observable terms:** Define each term in the “Failure-rate accounting” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M12.05-C083-T03 · Precondition set:** List the preconditions under which “Performance summaries cannot discard inconvenient failures silently” must hold for “Failure-rate accounting”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M12.05-C083-T04 · Transition coverage:** Map the “Failure-rate accounting” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M12.05-C083-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Failure-rate accounting”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M12.05-C083-T06 · Satisfying fixture:** Create a concrete “Failure-rate accounting” case that satisfies “Performance summaries cannot discard inconvenient failures silently”; record its expected observation before running the assertion or review.
- [ ] **UC-M12.05-C083-T07 · Violating fixture:** Create the source counterexample “Only successful runs are used without reporting excluded failures” for “Failure-rate accounting”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M12.05-C083-T08 · Enforcement evidence:** Exercise the “Failure-rate accounting” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M12.05-C083-T09 · Regression linkage:** Link the “Failure-rate accounting” property to changes in repeatable workloads, phase/resource metrics and explicit comparison baselines; record which dependency or contract changes require rerunning it.
- [ ] **UC-M12.05-C083-T10 · Property disposition:** Compare the satisfying and violating “Failure-rate accounting” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M12.05-C084 · Integration

**Original checklist item:** Integrate failure-rate accounting with repeatable workloads, phase/resource metrics and explicit comparison baselines; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M12.05-C084-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Failure-rate accounting” across repeatable workloads, phase/resource metrics and explicit comparison baselines; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M12.05-C084-T02 · Field mapping:** Map every “Failure-rate accounting” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M12.05-C084-T03 · Prerequisite identities:** Record the actual prerequisites for “Failure-rate accounting” (source dependency list: UC-M04.02, UC-M10.02); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M12.05-C084-T04 · Ownership agreement:** Specify who owns “Failure-rate accounting” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M12.05-C084-T05 · Handoff implementation:** Connect “Failure-rate accounting” through the mapped seam using the real adapter or explicit specification reference; preserve “Performance summaries cannot discard inconvenient failures silently” across the handoff.
- [ ] **UC-M12.05-C084-T06 · Absent-input case:** Omit one required “Failure-rate accounting” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M12.05-C084-T07 · Stale-input case:** Supply an outdated “Failure-rate accounting” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M12.05-C084-T08 · Incompatible-input case:** Supply an incompatible “Failure-rate accounting” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M12.05-C084-T09 · Valid integration trace:** Run a valid “Failure-rate accounting” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M12.05-C084-T10 · Seam review:** Reconcile the “Failure-rate accounting” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M12.05-C085 · Valid-case test

**Original checklist item:** Run a known-valid control for failure-rate accounting; verify that the harness reaches its intended target and compare observed measurements or verdicts with predeclared expectations.

- [ ] **UC-M12.05-C085-T01 · Valid fixture choice:** Choose a known-valid control for “Failure-rate accounting”; document why it should pass and how it proves the harness reaches the intended target.
- [ ] **UC-M12.05-C085-T02 · Expected-result oracle:** Specify the “Failure-rate accounting” expected result independently of the implementation output; include the property “Performance summaries cannot discard inconvenient failures silently” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M12.05-C085-T03 · Fixture material:** Create the concrete “Failure-rate accounting” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M12.05-C085-T04 · Target preparation:** Prepare the “Failure-rate accounting” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M12.05-C085-T05 · Initial-state record:** Record the initial “Failure-rate accounting” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M12.05-C085-T06 · Valid-path execution:** Run the “Failure-rate accounting” known-valid control on the identified target; retain enough observations to prove the correct target was exercised.
- [ ] **UC-M12.05-C085-T07 · Outcome comparison:** Compare every declared “Failure-rate accounting” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M12.05-C085-T08 · State and bounds check:** Inspect the “Failure-rate accounting” ownership/state effects and actual use of “Trial count and failure categories”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M12.05-C085-T09 · Repeatability check:** Repeat the same “Failure-rate accounting” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M12.05-C085-T10 · Positive evidence:** Attach the “Failure-rate accounting” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M12.05-C086 · Negative test

**Original checklist item:** Negative case: Only successful runs are used without reporting excluded failures. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M12.05-C086-T01 · Adverse-case definition:** Create a test record for the exact “Failure-rate accounting” source counterexample: “Only successful runs are used without reporting excluded failures”; state which precondition or invariant it challenges.
- [ ] **UC-M12.05-C086-T02 · Safe fixture boundary:** Define the contained test boundary for “Failure-rate accounting”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M12.05-C086-T03 · Valid control:** Construct a valid “Failure-rate accounting” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M12.05-C086-T04 · Minimal adverse input:** Derive the “Failure-rate accounting” adverse fixture from the control with the smallest documented change needed to reproduce “Only successful runs are used without reporting excluded failures”; retain that change as reproducible data.
- [ ] **UC-M12.05-C086-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Failure-rate accounting”; require “Performance summaries cannot discard inconvenient failures silently” and forbid a false-success verdict.
- [ ] **UC-M12.05-C086-T06 · Adverse execution:** Exercise the “Failure-rate accounting” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M12.05-C086-T07 · Effect inspection:** Inspect “Failure-rate accounting” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M12.05-C086-T08 · Refusal versus failure:** Confirm the “Failure-rate accounting” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M12.05-C086-T09 · Reset and retention:** Restore only the disposable “Failure-rate accounting” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M12.05-C086-T10 · Negative regression:** Register the “Failure-rate accounting” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M12.05-C087 · Change / failure test

**Original checklist item:** Exercise failure-rate accounting when a run fails, times out or changes environment during a measurement series; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M12.05-C087-T01 · Scenario record:** Write the “Failure-rate accounting” change/failure scenario exactly as supplied: a run fails, times out or changes environment during a measurement series; identify the property that must remain true: “Performance summaries cannot discard inconvenient failures silently”.
- [ ] **UC-M12.05-C087-T02 · Baseline capture:** Create a known-valid “Failure-rate accounting” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M12.05-C087-T03 · Injection map:** Locate the “Failure-rate accounting” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M12.05-C087-T04 · Disposition oracle:** Define the legal intermediate and final “Failure-rate accounting” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M12.05-C087-T05 · Controlled trigger:** Introduce the controlled “Failure-rate accounting” scenario in the disposable fixture: a run fails, times out or changes environment during a measurement series; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M12.05-C087-T06 · Intermediate inspection:** Inspect the “Failure-rate accounting” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M12.05-C087-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Failure-rate accounting”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M12.05-C087-T08 · Stale-evidence cleanup:** Invalidate superseded “Failure-rate accounting” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M12.05-C087-T09 · Repeat and compare:** Repeat the selected “Failure-rate accounting” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M12.05-C087-T10 · Failure evidence:** Publish the “Failure-rate accounting” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M12.05-C088 · Bounds

**Original checklist item:** Set a documented campaign budget for trial count and failure categories; record actual consumption, incomplete coverage and the disposition when the budget is exhausted.

- [ ] **UC-M12.05-C088-T01 · Quantity inventory:** Create a measurement inventory for “Failure-rate accounting”: “Trial count and failure categories”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M12.05-C088-T02 · Measurement method:** Choose how to observe each “Failure-rate accounting” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M12.05-C088-T03 · Budget decision:** Select justified campaign and target-resource budgets for “Failure-rate accounting”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M12.05-C088-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Failure-rate accounting” cases for “Trial count and failure categories”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M12.05-C088-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Failure-rate accounting” limit; preserve “Performance summaries cannot discard inconvenient failures silently”.
- [ ] **UC-M12.05-C088-T06 · Normal measurement:** Run or review the normal “Failure-rate accounting” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M12.05-C088-T07 · At-limit measurement:** Exercise the “Failure-rate accounting” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M12.05-C088-T08 · Over-limit measurement:** Exercise the “Failure-rate accounting” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M12.05-C088-T09 · Uncovered-scope report:** List the “Failure-rate accounting” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M12.05-C088-T10 · Limit evidence:** Publish the selected “Failure-rate accounting” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M12.05-C089 · Diagnostics / review

**Original checklist item:** Report failure-rate accounting results with executed, failed, skipped and unavailable cases separated; preserve the underlying observations and do not manufacture missing measurements.

- [ ] **UC-M12.05-C089-T01 · Result inventory:** Enumerate the required “Failure-rate accounting” qualification cases and intended targets before aggregating results; keep the planned denominator visible.
- [ ] **UC-M12.05-C089-T02 · Verdict schema:** Define separate executed-pass, executed-fail, skipped, unavailable and untested outcomes for “Failure-rate accounting”; document how incomplete cases block relevant claims.
- [ ] **UC-M12.05-C089-T03 · Identity fields:** Attach the actual target, fixture, configuration and revision identifiers to each “Failure-rate accounting” result; do not attribute host-only evidence to a guest or another OS.
- [ ] **UC-M12.05-C089-T04 · Observation capture:** Capture bounded raw “Failure-rate accounting” observations and harness errors; retain enough information to verify the reported oracle comparison.
- [ ] **UC-M12.05-C089-T05 · Aggregation rules:** Implement the “Failure-rate accounting” count/reduction rule so failures and missing measurements cannot disappear; preserve “Performance summaries cannot discard inconvenient failures silently”.
- [ ] **UC-M12.05-C089-T06 · Failure visibility:** Feed a failing “Failure-rate accounting” control through the report path; assert the exact failed case and underlying observation remain visible.
- [ ] **UC-M12.05-C089-T07 · Missing-result visibility:** Withhold a required “Failure-rate accounting” measurement or target; verify the report uses unavailable/untested rather than a fabricated zero or passing value.
- [ ] **UC-M12.05-C089-T08 · Bounds and redaction:** Check “Failure-rate accounting” report size and retention against “Trial count and failure categories”; remove secrets while retaining fixture and subject references.
- [ ] **UC-M12.05-C089-T09 · Report reconciliation:** Reconcile the “Failure-rate accounting” summary with every underlying case record; account for the full planned denominator and all omitted scope.
- [ ] **UC-M12.05-C089-T10 · Qualification handoff:** Publish the “Failure-rate accounting” report with measured observations, coverage limits and blockers; state which actual targets remain unqualified.

### UC-M12.05-C090 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for failure-rate accounting; label unexecuted checks as untested.

- [ ] **UC-M12.05-C090-T01 · Evidence inventory:** List the “Failure-rate accounting” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M12.05-C090-T02 · Artifact references:** Record the exact “Failure-rate accounting” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M12.05-C090-T03 · Fixture references:** Attach the “Failure-rate accounting” fixture IDs, input identities and oracle definition; preserve the source counterexample “Only successful runs are used without reporting excluded failures” as a distinct evidence case.
- [ ] **UC-M12.05-C090-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Failure-rate accounting”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M12.05-C090-T05 · Environment record:** Record the actual “Failure-rate accounting” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M12.05-C090-T06 · Expected versus observed:** Pair every “Failure-rate accounting” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M12.05-C090-T07 · Failure and limit records:** Attach “Failure-rate accounting” change/failure and bounds evidence where required; include uncovered “Trial count and failure categories” and unresolved violations of “Performance summaries cannot discard inconvenient failures silently”.
- [ ] **UC-M12.05-C090-T08 · Evidence hygiene:** Check the “Failure-rate accounting” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M12.05-C090-T09 · Reproduction review:** Have the “Failure-rate accounting” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M12.05-C090-T10 · Acceptance linkage:** Link the “Failure-rate accounting” evidence to its parent and UC-M12.05 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 10. Performance publication gate

**Source delivery:** Publish raw observations, methodology, baselines and limitations.

**Source invariant:** Estimated speedups are never presented as observed measurements.

**Source negative case:** A theoretical improvement is labeled as benchmarked acceleration.

**Source bounded quantities:** Report size and reproducible benchmark artifacts.

### UC-M12.05-C091 · Contract

**Original checklist item:** Define the qualification objective for performance publication gate, including the actual target implementation, prerequisites, observable oracle and explicit exclusions.

- [ ] **UC-M12.05-C091-T01 · Scope statement:** Write the qualification question for “Performance publication gate”; identify the actual target, claimed capability and observations that can answer that question.
- [ ] **UC-M12.05-C091-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Performance publication gate”; record each producer, representation and missing-value meaning.
- [ ] **UC-M12.05-C091-T03 · Output inventory:** List the outputs of “Performance publication gate” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M12.05-C091-T04 · Field dictionary:** Create a field-and-term dictionary for “Performance publication gate”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M12.05-C091-T05 · Prerequisite contract:** Map “Performance publication gate” to the source component prerequisites (UC-M04.02, UC-M10.02); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M12.05-C091-T06 · Authority map:** Identify who may produce, change and consume “Performance publication gate”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M12.05-C091-T07 · Invariant clause:** Add a normative clause for “Performance publication gate” that preserves “Estimated speedups are never presented as observed measurements”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M12.05-C091-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Performance publication gate”; include the source counterexample “A theoretical improvement is labeled as benchmarked acceleration” and the intended safe disposition.
- [ ] **UC-M12.05-C091-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Report size and reproducible benchmark artifacts” in the “Performance publication gate” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M12.05-C091-T10 · Contract review:** Review the “Performance publication gate” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M12.05-C092 · Delivery

**Original checklist item:** Publish raw observations, methodology, baselines and limitations.

- [ ] **UC-M12.05-C092-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Performance publication gate”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M12.05-C092-T02 · Change plan:** Break the source delivery for “Performance publication gate” into concrete edit targets and reviewable outputs; keep the UC-M12.05 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M12.05-C092-T03 · Core artifact:** Create the “Performance publication gate” output artifact for this source instruction: Publish raw observations, methodology, baselines and limitations.
- [ ] **UC-M12.05-C092-T04 · Concrete realization:** Populate the “Performance publication gate” artifact from identified observations; keep unknown, failed and unexecuted results distinct and exclude unapproved sensitive material.
- [ ] **UC-M12.05-C092-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Performance publication gate” needed to preserve “Estimated speedups are never presented as observed measurements”; record an enforcement gap where only a model exists.
- [ ] **UC-M12.05-C092-T06 · Dependency connection:** Connect the “Performance publication gate” qualification artifact to repeatable workloads, phase/resource metrics and explicit comparison baselines; record the target identity and what the harness actually exercises.
- [ ] **UC-M12.05-C092-T07 · Resource behavior:** Account for “Report size and reproducible benchmark artifacts” in “Performance publication gate”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M12.05-C092-T08 · Delivery check:** Run a known-valid control and a deliberately failing control for “Performance publication gate”; confirm the harness distinguishes their observed outcomes.
- [ ] **UC-M12.05-C092-T09 · Patch review:** Review the “Performance publication gate” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M12.05-C092-T10 · Delivery handoff:** Publish the “Performance publication gate” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M12.05-C093 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Estimated speedups are never presented as observed measurements. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M12.05-C093-T01 · Named property:** Create a stable property/check name under this parent for “Performance publication gate”; copy its required invariant exactly: “Estimated speedups are never presented as observed measurements”.
- [ ] **UC-M12.05-C093-T02 · Observable terms:** Define each term in the “Performance publication gate” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M12.05-C093-T03 · Precondition set:** List the preconditions under which “Estimated speedups are never presented as observed measurements” must hold for “Performance publication gate”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M12.05-C093-T04 · Transition coverage:** Map the “Performance publication gate” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M12.05-C093-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Performance publication gate”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M12.05-C093-T06 · Satisfying fixture:** Create a concrete “Performance publication gate” case that satisfies “Estimated speedups are never presented as observed measurements”; record its expected observation before running the assertion or review.
- [ ] **UC-M12.05-C093-T07 · Violating fixture:** Create the source counterexample “A theoretical improvement is labeled as benchmarked acceleration” for “Performance publication gate”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M12.05-C093-T08 · Enforcement evidence:** Exercise the “Performance publication gate” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M12.05-C093-T09 · Regression linkage:** Link the “Performance publication gate” property to changes in repeatable workloads, phase/resource metrics and explicit comparison baselines; record which dependency or contract changes require rerunning it.
- [ ] **UC-M12.05-C093-T10 · Property disposition:** Compare the satisfying and violating “Performance publication gate” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M12.05-C094 · Integration

**Original checklist item:** Integrate performance publication gate with repeatable workloads, phase/resource metrics and explicit comparison baselines; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M12.05-C094-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Performance publication gate” across repeatable workloads, phase/resource metrics and explicit comparison baselines; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M12.05-C094-T02 · Field mapping:** Map every “Performance publication gate” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M12.05-C094-T03 · Prerequisite identities:** Record the actual prerequisites for “Performance publication gate” (source dependency list: UC-M04.02, UC-M10.02); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M12.05-C094-T04 · Ownership agreement:** Specify who owns “Performance publication gate” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M12.05-C094-T05 · Handoff implementation:** Connect “Performance publication gate” through the mapped seam using the real adapter or explicit specification reference; preserve “Estimated speedups are never presented as observed measurements” across the handoff.
- [ ] **UC-M12.05-C094-T06 · Absent-input case:** Omit one required “Performance publication gate” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M12.05-C094-T07 · Stale-input case:** Supply an outdated “Performance publication gate” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M12.05-C094-T08 · Incompatible-input case:** Supply an incompatible “Performance publication gate” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M12.05-C094-T09 · Valid integration trace:** Run a valid “Performance publication gate” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M12.05-C094-T10 · Seam review:** Reconcile the “Performance publication gate” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M12.05-C095 · Valid-case test

**Original checklist item:** Run a known-valid control for performance publication gate; verify that the harness reaches its intended target and compare observed measurements or verdicts with predeclared expectations.

- [ ] **UC-M12.05-C095-T01 · Valid fixture choice:** Choose a known-valid control for “Performance publication gate”; document why it should pass and how it proves the harness reaches the intended target.
- [ ] **UC-M12.05-C095-T02 · Expected-result oracle:** Specify the “Performance publication gate” expected result independently of the implementation output; include the property “Estimated speedups are never presented as observed measurements” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M12.05-C095-T03 · Fixture material:** Create the concrete “Performance publication gate” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M12.05-C095-T04 · Target preparation:** Prepare the “Performance publication gate” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M12.05-C095-T05 · Initial-state record:** Record the initial “Performance publication gate” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M12.05-C095-T06 · Valid-path execution:** Run the “Performance publication gate” known-valid control on the identified target; retain enough observations to prove the correct target was exercised.
- [ ] **UC-M12.05-C095-T07 · Outcome comparison:** Compare every declared “Performance publication gate” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M12.05-C095-T08 · State and bounds check:** Inspect the “Performance publication gate” ownership/state effects and actual use of “Report size and reproducible benchmark artifacts”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M12.05-C095-T09 · Repeatability check:** Repeat the same “Performance publication gate” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M12.05-C095-T10 · Positive evidence:** Attach the “Performance publication gate” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M12.05-C096 · Negative test

**Original checklist item:** Negative case: A theoretical improvement is labeled as benchmarked acceleration. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M12.05-C096-T01 · Adverse-case definition:** Create a test record for the exact “Performance publication gate” source counterexample: “A theoretical improvement is labeled as benchmarked acceleration”; state which precondition or invariant it challenges.
- [ ] **UC-M12.05-C096-T02 · Safe fixture boundary:** Define the contained test boundary for “Performance publication gate”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M12.05-C096-T03 · Valid control:** Construct a valid “Performance publication gate” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M12.05-C096-T04 · Minimal adverse input:** Derive the “Performance publication gate” adverse fixture from the control with the smallest documented change needed to reproduce “A theoretical improvement is labeled as benchmarked acceleration”; retain that change as reproducible data.
- [ ] **UC-M12.05-C096-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Performance publication gate”; require “Estimated speedups are never presented as observed measurements” and forbid a false-success verdict.
- [ ] **UC-M12.05-C096-T06 · Adverse execution:** Exercise the “Performance publication gate” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M12.05-C096-T07 · Effect inspection:** Inspect “Performance publication gate” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M12.05-C096-T08 · Refusal versus failure:** Confirm the “Performance publication gate” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M12.05-C096-T09 · Reset and retention:** Restore only the disposable “Performance publication gate” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M12.05-C096-T10 · Negative regression:** Register the “Performance publication gate” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M12.05-C097 · Change / failure test

**Original checklist item:** Exercise performance publication gate when a run fails, times out or changes environment during a measurement series; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M12.05-C097-T01 · Scenario record:** Write the “Performance publication gate” change/failure scenario exactly as supplied: a run fails, times out or changes environment during a measurement series; identify the property that must remain true: “Estimated speedups are never presented as observed measurements”.
- [ ] **UC-M12.05-C097-T02 · Baseline capture:** Create a known-valid “Performance publication gate” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M12.05-C097-T03 · Injection map:** Locate the “Performance publication gate” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M12.05-C097-T04 · Disposition oracle:** Define the legal intermediate and final “Performance publication gate” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M12.05-C097-T05 · Controlled trigger:** Introduce the controlled “Performance publication gate” scenario in the disposable fixture: a run fails, times out or changes environment during a measurement series; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M12.05-C097-T06 · Intermediate inspection:** Inspect the “Performance publication gate” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M12.05-C097-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Performance publication gate”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M12.05-C097-T08 · Stale-evidence cleanup:** Invalidate superseded “Performance publication gate” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M12.05-C097-T09 · Repeat and compare:** Repeat the selected “Performance publication gate” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M12.05-C097-T10 · Failure evidence:** Publish the “Performance publication gate” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M12.05-C098 · Bounds

**Original checklist item:** Set a documented campaign budget for report size and reproducible benchmark artifacts; record actual consumption, incomplete coverage and the disposition when the budget is exhausted.

- [ ] **UC-M12.05-C098-T01 · Quantity inventory:** Create a measurement inventory for “Performance publication gate”: “Report size and reproducible benchmark artifacts”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M12.05-C098-T02 · Measurement method:** Choose how to observe each “Performance publication gate” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M12.05-C098-T03 · Budget decision:** Select justified campaign and target-resource budgets for “Performance publication gate”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M12.05-C098-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Performance publication gate” cases for “Report size and reproducible benchmark artifacts”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M12.05-C098-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Performance publication gate” limit; preserve “Estimated speedups are never presented as observed measurements”.
- [ ] **UC-M12.05-C098-T06 · Normal measurement:** Run or review the normal “Performance publication gate” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M12.05-C098-T07 · At-limit measurement:** Exercise the “Performance publication gate” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M12.05-C098-T08 · Over-limit measurement:** Exercise the “Performance publication gate” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M12.05-C098-T09 · Uncovered-scope report:** List the “Performance publication gate” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M12.05-C098-T10 · Limit evidence:** Publish the selected “Performance publication gate” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M12.05-C099 · Diagnostics / review

**Original checklist item:** Report performance publication gate results with executed, failed, skipped and unavailable cases separated; preserve the underlying observations and do not manufacture missing measurements.

- [ ] **UC-M12.05-C099-T01 · Result inventory:** Enumerate the required “Performance publication gate” qualification cases and intended targets before aggregating results; keep the planned denominator visible.
- [ ] **UC-M12.05-C099-T02 · Verdict schema:** Define separate executed-pass, executed-fail, skipped, unavailable and untested outcomes for “Performance publication gate”; document how incomplete cases block relevant claims.
- [ ] **UC-M12.05-C099-T03 · Identity fields:** Attach the actual target, fixture, configuration and revision identifiers to each “Performance publication gate” result; do not attribute host-only evidence to a guest or another OS.
- [ ] **UC-M12.05-C099-T04 · Observation capture:** Capture bounded raw “Performance publication gate” observations and harness errors; retain enough information to verify the reported oracle comparison.
- [ ] **UC-M12.05-C099-T05 · Aggregation rules:** Implement the “Performance publication gate” count/reduction rule so failures and missing measurements cannot disappear; preserve “Estimated speedups are never presented as observed measurements”.
- [ ] **UC-M12.05-C099-T06 · Failure visibility:** Feed a failing “Performance publication gate” control through the report path; assert the exact failed case and underlying observation remain visible.
- [ ] **UC-M12.05-C099-T07 · Missing-result visibility:** Withhold a required “Performance publication gate” measurement or target; verify the report uses unavailable/untested rather than a fabricated zero or passing value.
- [ ] **UC-M12.05-C099-T08 · Bounds and redaction:** Check “Performance publication gate” report size and retention against “Report size and reproducible benchmark artifacts”; remove secrets while retaining fixture and subject references.
- [ ] **UC-M12.05-C099-T09 · Report reconciliation:** Reconcile the “Performance publication gate” summary with every underlying case record; account for the full planned denominator and all omitted scope.
- [ ] **UC-M12.05-C099-T10 · Qualification handoff:** Publish the “Performance publication gate” report with measured observations, coverage limits and blockers; state which actual targets remain unqualified.

### UC-M12.05-C100 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for performance publication gate; label unexecuted checks as untested.

- [ ] **UC-M12.05-C100-T01 · Evidence inventory:** List the “Performance publication gate” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M12.05-C100-T02 · Artifact references:** Record the exact “Performance publication gate” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M12.05-C100-T03 · Fixture references:** Attach the “Performance publication gate” fixture IDs, input identities and oracle definition; preserve the source counterexample “A theoretical improvement is labeled as benchmarked acceleration” as a distinct evidence case.
- [ ] **UC-M12.05-C100-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Performance publication gate”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M12.05-C100-T05 · Environment record:** Record the actual “Performance publication gate” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M12.05-C100-T06 · Expected versus observed:** Pair every “Performance publication gate” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M12.05-C100-T07 · Failure and limit records:** Attach “Performance publication gate” change/failure and bounds evidence where required; include uncovered “Report size and reproducible benchmark artifacts” and unresolved violations of “Estimated speedups are never presented as observed measurements”.
- [ ] **UC-M12.05-C100-T08 · Evidence hygiene:** Check the “Performance publication gate” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M12.05-C100-T09 · Reproduction review:** Have the “Performance publication gate” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M12.05-C100-T10 · Acceptance linkage:** Link the “Performance publication gate” evidence to its parent and UC-M12.05 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

