# UC-M12.01 — Real operating-system CI matrix

**To-Do Pack 2.0.0 · Baseline UC-2.2.0 · 100 parent checks × 10 subtasks = 1,000 to-dos**

[Master index](../../INDEX.md) · [Workstream index](../../w/12.md)

| Field | Preserved source value |
|---|---|
| Workstream | 12. Qualification, packaging and release |
| Milestone | C |
| Priority | P0 |
| Source assessment | PARTIAL |
| Scope | core or selected profile |
| Dependencies | [UC-M03.08](../03/UC-M03.08.md), [UC-M04.01](../04/UC-M04.01.md) |
| Source checklist pack | 1.0.0 |
| Original reference labels | [S5], [S6], [S7], [S8]. |

## Original requirement

Run native Windows, Linux and any claimed macOS environments, including spaces, long roots, NTFS reparse points and no-toolchain hosts.

**Original acceptance criterion:** Every supported platform has machine-recorded launch/build/verify results; simulated path checks do not count as OS execution.

**Source trace:** Original checklist `UC100/c/12/UC-M12.01.md` inside [s/checklists.zip](../../s/checklists.zip); exact parent records in [data/parents.jsonl](../../data/parents.jsonl). Original roadmap lines 1094–1104 are preserved in [s/roadmap.md](../../s/roadmap.md).

## How to use these lists

Every parent statement below is preserved verbatim. Its ten child tasks are proposed decomposition, not implemented capabilities or executed tests. Child IDs append `-T01` through `-T10` to the original parent ID. All begin unchecked / `TODO`. Design/review evidence does not establish runtime enforcement; observe the actual selected target where the parent requires it.

The source dependency graph and selected release profile determine applicability. The numbered child sequence is a local working order, not an added hard dependency graph. An unselected optional feature needs a recorded not-applicable rationale; missing prerequisites for selected work remain blockers. Numerical budgets, backends and trust mechanisms remain decisions unless fixed by the source. Test hostile cases only with synthetic inputs in authorized disposable environments.

## 01. Supported platform declaration

**Source delivery:** List native Windows, Linux and only explicitly claimed macOS environments.

**Source invariant:** Unsupported platforms are not implied by portable-looking source.

**Source negative case:** A macOS support claim has no native execution evidence.

**Source bounded quantities:** Platforms, architectures and version matrix.

### UC-M12.01-C001 · Contract

**Original checklist item:** Define the qualification objective for supported platform declaration, including the actual target implementation, prerequisites, observable oracle and explicit exclusions.

- [ ] **UC-M12.01-C001-T01 · Scope statement:** Write the qualification question for “Supported platform declaration”; identify the actual target, claimed capability and observations that can answer that question.
- [ ] **UC-M12.01-C001-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Supported platform declaration”; record each producer, representation and missing-value meaning.
- [ ] **UC-M12.01-C001-T03 · Output inventory:** List the outputs of “Supported platform declaration” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M12.01-C001-T04 · Field dictionary:** Create a field-and-term dictionary for “Supported platform declaration”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M12.01-C001-T05 · Prerequisite contract:** Map “Supported platform declaration” to the source component prerequisites (UC-M03.08, UC-M04.01); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M12.01-C001-T06 · Authority map:** Identify who may produce, change and consume “Supported platform declaration”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M12.01-C001-T07 · Invariant clause:** Add a normative clause for “Supported platform declaration” that preserves “Unsupported platforms are not implied by portable-looking source”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M12.01-C001-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Supported platform declaration”; include the source counterexample “A macOS support claim has no native execution evidence” and the intended safe disposition.
- [ ] **UC-M12.01-C001-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Platforms, architectures and version matrix” in the “Supported platform declaration” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M12.01-C001-T10 · Contract review:** Review the “Supported platform declaration” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M12.01-C002 · Delivery

**Original checklist item:** List native Windows, Linux and only explicitly claimed macOS environments.

- [ ] **UC-M12.01-C002-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Supported platform declaration”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M12.01-C002-T02 · Change plan:** Break the source delivery for “Supported platform declaration” into concrete edit targets and reviewable outputs; keep the UC-M12.01 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M12.01-C002-T03 · Core artifact:** Create the “Supported platform declaration” model, schema or inventory that realizes this source instruction: List native Windows, Linux and only explicitly claimed macOS environments.
- [ ] **UC-M12.01-C002-T04 · Concrete realization:** Populate “Supported platform declaration” with one concrete worked case; map every required entity or field to its source and flag any unmapped entry.
- [ ] **UC-M12.01-C002-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Supported platform declaration” needed to preserve “Unsupported platforms are not implied by portable-looking source”; record an enforcement gap where only a model exists.
- [ ] **UC-M12.01-C002-T06 · Dependency connection:** Connect the “Supported platform declaration” qualification artifact to native host runners, supplied launchers and machine-recorded build/verify results; record the target identity and what the harness actually exercises.
- [ ] **UC-M12.01-C002-T07 · Resource behavior:** Account for “Platforms, architectures and version matrix” in “Supported platform declaration”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M12.01-C002-T08 · Delivery check:** Run a known-valid control and a deliberately failing control for “Supported platform declaration”; confirm the harness distinguishes their observed outcomes.
- [ ] **UC-M12.01-C002-T09 · Patch review:** Review the “Supported platform declaration” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M12.01-C002-T10 · Delivery handoff:** Publish the “Supported platform declaration” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M12.01-C003 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Unsupported platforms are not implied by portable-looking source. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M12.01-C003-T01 · Named property:** Create a stable property/check name under this parent for “Supported platform declaration”; copy its required invariant exactly: “Unsupported platforms are not implied by portable-looking source”.
- [ ] **UC-M12.01-C003-T02 · Observable terms:** Define each term in the “Supported platform declaration” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M12.01-C003-T03 · Precondition set:** List the preconditions under which “Unsupported platforms are not implied by portable-looking source” must hold for “Supported platform declaration”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M12.01-C003-T04 · Transition coverage:** Map the “Supported platform declaration” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M12.01-C003-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Supported platform declaration”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M12.01-C003-T06 · Satisfying fixture:** Create a concrete “Supported platform declaration” case that satisfies “Unsupported platforms are not implied by portable-looking source”; record its expected observation before running the assertion or review.
- [ ] **UC-M12.01-C003-T07 · Violating fixture:** Create the source counterexample “A macOS support claim has no native execution evidence” for “Supported platform declaration”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M12.01-C003-T08 · Enforcement evidence:** Exercise the “Supported platform declaration” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M12.01-C003-T09 · Regression linkage:** Link the “Supported platform declaration” property to changes in native host runners, supplied launchers and machine-recorded build/verify results; record which dependency or contract changes require rerunning it.
- [ ] **UC-M12.01-C003-T10 · Property disposition:** Compare the satisfying and violating “Supported platform declaration” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M12.01-C004 · Integration

**Original checklist item:** Integrate supported platform declaration with native host runners, supplied launchers and machine-recorded build/verify results; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M12.01-C004-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Supported platform declaration” across native host runners, supplied launchers and machine-recorded build/verify results; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M12.01-C004-T02 · Field mapping:** Map every “Supported platform declaration” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M12.01-C004-T03 · Prerequisite identities:** Record the actual prerequisites for “Supported platform declaration” (source dependency list: UC-M03.08, UC-M04.01); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M12.01-C004-T04 · Ownership agreement:** Specify who owns “Supported platform declaration” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M12.01-C004-T05 · Handoff implementation:** Connect “Supported platform declaration” through the mapped seam using the real adapter or explicit specification reference; preserve “Unsupported platforms are not implied by portable-looking source” across the handoff.
- [ ] **UC-M12.01-C004-T06 · Absent-input case:** Omit one required “Supported platform declaration” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M12.01-C004-T07 · Stale-input case:** Supply an outdated “Supported platform declaration” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M12.01-C004-T08 · Incompatible-input case:** Supply an incompatible “Supported platform declaration” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M12.01-C004-T09 · Valid integration trace:** Run a valid “Supported platform declaration” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M12.01-C004-T10 · Seam review:** Reconcile the “Supported platform declaration” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M12.01-C005 · Valid-case test

**Original checklist item:** Run a known-valid control for supported platform declaration; verify that the harness reaches its intended target and compare observed measurements or verdicts with predeclared expectations.

- [ ] **UC-M12.01-C005-T01 · Valid fixture choice:** Choose a known-valid control for “Supported platform declaration”; document why it should pass and how it proves the harness reaches the intended target.
- [ ] **UC-M12.01-C005-T02 · Expected-result oracle:** Specify the “Supported platform declaration” expected result independently of the implementation output; include the property “Unsupported platforms are not implied by portable-looking source” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M12.01-C005-T03 · Fixture material:** Create the concrete “Supported platform declaration” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M12.01-C005-T04 · Target preparation:** Prepare the “Supported platform declaration” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M12.01-C005-T05 · Initial-state record:** Record the initial “Supported platform declaration” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M12.01-C005-T06 · Valid-path execution:** Run the “Supported platform declaration” known-valid control on the identified target; retain enough observations to prove the correct target was exercised.
- [ ] **UC-M12.01-C005-T07 · Outcome comparison:** Compare every declared “Supported platform declaration” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M12.01-C005-T08 · State and bounds check:** Inspect the “Supported platform declaration” ownership/state effects and actual use of “Platforms, architectures and version matrix”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M12.01-C005-T09 · Repeatability check:** Repeat the same “Supported platform declaration” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M12.01-C005-T10 · Positive evidence:** Attach the “Supported platform declaration” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M12.01-C006 · Negative test

**Original checklist item:** Negative case: A macOS support claim has no native execution evidence. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M12.01-C006-T01 · Adverse-case definition:** Create a test record for the exact “Supported platform declaration” source counterexample: “A macOS support claim has no native execution evidence”; state which precondition or invariant it challenges.
- [ ] **UC-M12.01-C006-T02 · Safe fixture boundary:** Define the contained test boundary for “Supported platform declaration”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M12.01-C006-T03 · Valid control:** Construct a valid “Supported platform declaration” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M12.01-C006-T04 · Minimal adverse input:** Derive the “Supported platform declaration” adverse fixture from the control with the smallest documented change needed to reproduce “A macOS support claim has no native execution evidence”; retain that change as reproducible data.
- [ ] **UC-M12.01-C006-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Supported platform declaration”; require “Unsupported platforms are not implied by portable-looking source” and forbid a false-success verdict.
- [ ] **UC-M12.01-C006-T06 · Adverse execution:** Exercise the “Supported platform declaration” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M12.01-C006-T07 · Effect inspection:** Inspect “Supported platform declaration” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M12.01-C006-T08 · Refusal versus failure:** Confirm the “Supported platform declaration” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M12.01-C006-T09 · Reset and retention:** Restore only the disposable “Supported platform declaration” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M12.01-C006-T10 · Negative regression:** Register the “Supported platform declaration” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M12.01-C007 · Change / failure test

**Original checklist item:** Exercise supported platform declaration when a supported host lacks a toolchain or uses a spaced/long installation root; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M12.01-C007-T01 · Scenario record:** Write the “Supported platform declaration” change/failure scenario exactly as supplied: a supported host lacks a toolchain or uses a spaced/long installation root; identify the property that must remain true: “Unsupported platforms are not implied by portable-looking source”.
- [ ] **UC-M12.01-C007-T02 · Baseline capture:** Create a known-valid “Supported platform declaration” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M12.01-C007-T03 · Injection map:** Locate the “Supported platform declaration” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M12.01-C007-T04 · Disposition oracle:** Define the legal intermediate and final “Supported platform declaration” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M12.01-C007-T05 · Controlled trigger:** Introduce the controlled “Supported platform declaration” scenario in the disposable fixture: a supported host lacks a toolchain or uses a spaced/long installation root; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M12.01-C007-T06 · Intermediate inspection:** Inspect the “Supported platform declaration” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M12.01-C007-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Supported platform declaration”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M12.01-C007-T08 · Stale-evidence cleanup:** Invalidate superseded “Supported platform declaration” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M12.01-C007-T09 · Repeat and compare:** Repeat the selected “Supported platform declaration” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M12.01-C007-T10 · Failure evidence:** Publish the “Supported platform declaration” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M12.01-C008 · Bounds

**Original checklist item:** Set a documented campaign budget for platforms, architectures and version matrix; record actual consumption, incomplete coverage and the disposition when the budget is exhausted.

- [ ] **UC-M12.01-C008-T01 · Quantity inventory:** Create a measurement inventory for “Supported platform declaration”: “Platforms, architectures and version matrix”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M12.01-C008-T02 · Measurement method:** Choose how to observe each “Supported platform declaration” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M12.01-C008-T03 · Budget decision:** Select justified campaign and target-resource budgets for “Supported platform declaration”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M12.01-C008-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Supported platform declaration” cases for “Platforms, architectures and version matrix”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M12.01-C008-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Supported platform declaration” limit; preserve “Unsupported platforms are not implied by portable-looking source”.
- [ ] **UC-M12.01-C008-T06 · Normal measurement:** Run or review the normal “Supported platform declaration” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M12.01-C008-T07 · At-limit measurement:** Exercise the “Supported platform declaration” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M12.01-C008-T08 · Over-limit measurement:** Exercise the “Supported platform declaration” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M12.01-C008-T09 · Uncovered-scope report:** List the “Supported platform declaration” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M12.01-C008-T10 · Limit evidence:** Publish the selected “Supported platform declaration” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M12.01-C009 · Diagnostics / review

**Original checklist item:** Report supported platform declaration results with executed, failed, skipped and unavailable cases separated; preserve the underlying observations and do not manufacture missing measurements.

- [ ] **UC-M12.01-C009-T01 · Result inventory:** Enumerate the required “Supported platform declaration” qualification cases and intended targets before aggregating results; keep the planned denominator visible.
- [ ] **UC-M12.01-C009-T02 · Verdict schema:** Define separate executed-pass, executed-fail, skipped, unavailable and untested outcomes for “Supported platform declaration”; document how incomplete cases block relevant claims.
- [ ] **UC-M12.01-C009-T03 · Identity fields:** Attach the actual target, fixture, configuration and revision identifiers to each “Supported platform declaration” result; do not attribute host-only evidence to a guest or another OS.
- [ ] **UC-M12.01-C009-T04 · Observation capture:** Capture bounded raw “Supported platform declaration” observations and harness errors; retain enough information to verify the reported oracle comparison.
- [ ] **UC-M12.01-C009-T05 · Aggregation rules:** Implement the “Supported platform declaration” count/reduction rule so failures and missing measurements cannot disappear; preserve “Unsupported platforms are not implied by portable-looking source”.
- [ ] **UC-M12.01-C009-T06 · Failure visibility:** Feed a failing “Supported platform declaration” control through the report path; assert the exact failed case and underlying observation remain visible.
- [ ] **UC-M12.01-C009-T07 · Missing-result visibility:** Withhold a required “Supported platform declaration” measurement or target; verify the report uses unavailable/untested rather than a fabricated zero or passing value.
- [ ] **UC-M12.01-C009-T08 · Bounds and redaction:** Check “Supported platform declaration” report size and retention against “Platforms, architectures and version matrix”; remove secrets while retaining fixture and subject references.
- [ ] **UC-M12.01-C009-T09 · Report reconciliation:** Reconcile the “Supported platform declaration” summary with every underlying case record; account for the full planned denominator and all omitted scope.
- [ ] **UC-M12.01-C009-T10 · Qualification handoff:** Publish the “Supported platform declaration” report with measured observations, coverage limits and blockers; state which actual targets remain unqualified.

### UC-M12.01-C010 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for supported platform declaration; label unexecuted checks as untested.

- [ ] **UC-M12.01-C010-T01 · Evidence inventory:** List the “Supported platform declaration” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M12.01-C010-T02 · Artifact references:** Record the exact “Supported platform declaration” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M12.01-C010-T03 · Fixture references:** Attach the “Supported platform declaration” fixture IDs, input identities and oracle definition; preserve the source counterexample “A macOS support claim has no native execution evidence” as a distinct evidence case.
- [ ] **UC-M12.01-C010-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Supported platform declaration”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M12.01-C010-T05 · Environment record:** Record the actual “Supported platform declaration” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M12.01-C010-T06 · Expected versus observed:** Pair every “Supported platform declaration” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M12.01-C010-T07 · Failure and limit records:** Attach “Supported platform declaration” change/failure and bounds evidence where required; include uncovered “Platforms, architectures and version matrix” and unresolved violations of “Unsupported platforms are not implied by portable-looking source”.
- [ ] **UC-M12.01-C010-T08 · Evidence hygiene:** Check the “Supported platform declaration” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M12.01-C010-T09 · Reproduction review:** Have the “Supported platform declaration” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M12.01-C010-T10 · Acceptance linkage:** Link the “Supported platform declaration” evidence to its parent and UC-M12.01 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 02. Native runner identity

**Source delivery:** Record the actual OS, architecture, interpreter and toolchain used by each job.

**Source invariant:** Simulated path checks cannot count as native OS execution.

**Source negative case:** A Linux path simulation is reported as a Windows test.

**Source bounded quantities:** Runner profiles and environment metadata bytes.

### UC-M12.01-C011 · Contract

**Original checklist item:** Define the qualification objective for native runner identity, including the actual target implementation, prerequisites, observable oracle and explicit exclusions.

- [ ] **UC-M12.01-C011-T01 · Scope statement:** Write the qualification question for “Native runner identity”; identify the actual target, claimed capability and observations that can answer that question.
- [ ] **UC-M12.01-C011-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Native runner identity”; record each producer, representation and missing-value meaning.
- [ ] **UC-M12.01-C011-T03 · Output inventory:** List the outputs of “Native runner identity” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M12.01-C011-T04 · Field dictionary:** Create a field-and-term dictionary for “Native runner identity”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M12.01-C011-T05 · Prerequisite contract:** Map “Native runner identity” to the source component prerequisites (UC-M03.08, UC-M04.01); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M12.01-C011-T06 · Authority map:** Identify who may produce, change and consume “Native runner identity”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M12.01-C011-T07 · Invariant clause:** Add a normative clause for “Native runner identity” that preserves “Simulated path checks cannot count as native OS execution”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M12.01-C011-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Native runner identity”; include the source counterexample “A Linux path simulation is reported as a Windows test” and the intended safe disposition.
- [ ] **UC-M12.01-C011-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Runner profiles and environment metadata bytes” in the “Native runner identity” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M12.01-C011-T10 · Contract review:** Review the “Native runner identity” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M12.01-C012 · Delivery

**Original checklist item:** Record the actual OS, architecture, interpreter and toolchain used by each job.

- [ ] **UC-M12.01-C012-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Native runner identity”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M12.01-C012-T02 · Change plan:** Break the source delivery for “Native runner identity” into concrete edit targets and reviewable outputs; keep the UC-M12.01 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M12.01-C012-T03 · Core artifact:** Create the “Native runner identity” model, schema or inventory that realizes this source instruction: Record the actual OS, architecture, interpreter and toolchain used by each job.
- [ ] **UC-M12.01-C012-T04 · Concrete realization:** Populate “Native runner identity” with one concrete worked case; map every required entity or field to its source and flag any unmapped entry.
- [ ] **UC-M12.01-C012-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Native runner identity” needed to preserve “Simulated path checks cannot count as native OS execution”; record an enforcement gap where only a model exists.
- [ ] **UC-M12.01-C012-T06 · Dependency connection:** Connect the “Native runner identity” qualification artifact to native host runners, supplied launchers and machine-recorded build/verify results; record the target identity and what the harness actually exercises.
- [ ] **UC-M12.01-C012-T07 · Resource behavior:** Account for “Runner profiles and environment metadata bytes” in “Native runner identity”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M12.01-C012-T08 · Delivery check:** Run a known-valid control and a deliberately failing control for “Native runner identity”; confirm the harness distinguishes their observed outcomes.
- [ ] **UC-M12.01-C012-T09 · Patch review:** Review the “Native runner identity” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M12.01-C012-T10 · Delivery handoff:** Publish the “Native runner identity” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M12.01-C013 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Simulated path checks cannot count as native OS execution. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M12.01-C013-T01 · Named property:** Create a stable property/check name under this parent for “Native runner identity”; copy its required invariant exactly: “Simulated path checks cannot count as native OS execution”.
- [ ] **UC-M12.01-C013-T02 · Observable terms:** Define each term in the “Native runner identity” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M12.01-C013-T03 · Precondition set:** List the preconditions under which “Simulated path checks cannot count as native OS execution” must hold for “Native runner identity”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M12.01-C013-T04 · Transition coverage:** Map the “Native runner identity” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M12.01-C013-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Native runner identity”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M12.01-C013-T06 · Satisfying fixture:** Create a concrete “Native runner identity” case that satisfies “Simulated path checks cannot count as native OS execution”; record its expected observation before running the assertion or review.
- [ ] **UC-M12.01-C013-T07 · Violating fixture:** Create the source counterexample “A Linux path simulation is reported as a Windows test” for “Native runner identity”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M12.01-C013-T08 · Enforcement evidence:** Exercise the “Native runner identity” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M12.01-C013-T09 · Regression linkage:** Link the “Native runner identity” property to changes in native host runners, supplied launchers and machine-recorded build/verify results; record which dependency or contract changes require rerunning it.
- [ ] **UC-M12.01-C013-T10 · Property disposition:** Compare the satisfying and violating “Native runner identity” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M12.01-C014 · Integration

**Original checklist item:** Integrate native runner identity with native host runners, supplied launchers and machine-recorded build/verify results; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M12.01-C014-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Native runner identity” across native host runners, supplied launchers and machine-recorded build/verify results; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M12.01-C014-T02 · Field mapping:** Map every “Native runner identity” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M12.01-C014-T03 · Prerequisite identities:** Record the actual prerequisites for “Native runner identity” (source dependency list: UC-M03.08, UC-M04.01); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M12.01-C014-T04 · Ownership agreement:** Specify who owns “Native runner identity” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M12.01-C014-T05 · Handoff implementation:** Connect “Native runner identity” through the mapped seam using the real adapter or explicit specification reference; preserve “Simulated path checks cannot count as native OS execution” across the handoff.
- [ ] **UC-M12.01-C014-T06 · Absent-input case:** Omit one required “Native runner identity” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M12.01-C014-T07 · Stale-input case:** Supply an outdated “Native runner identity” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M12.01-C014-T08 · Incompatible-input case:** Supply an incompatible “Native runner identity” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M12.01-C014-T09 · Valid integration trace:** Run a valid “Native runner identity” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M12.01-C014-T10 · Seam review:** Reconcile the “Native runner identity” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M12.01-C015 · Valid-case test

**Original checklist item:** Run a known-valid control for native runner identity; verify that the harness reaches its intended target and compare observed measurements or verdicts with predeclared expectations.

- [ ] **UC-M12.01-C015-T01 · Valid fixture choice:** Choose a known-valid control for “Native runner identity”; document why it should pass and how it proves the harness reaches the intended target.
- [ ] **UC-M12.01-C015-T02 · Expected-result oracle:** Specify the “Native runner identity” expected result independently of the implementation output; include the property “Simulated path checks cannot count as native OS execution” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M12.01-C015-T03 · Fixture material:** Create the concrete “Native runner identity” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M12.01-C015-T04 · Target preparation:** Prepare the “Native runner identity” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M12.01-C015-T05 · Initial-state record:** Record the initial “Native runner identity” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M12.01-C015-T06 · Valid-path execution:** Run the “Native runner identity” known-valid control on the identified target; retain enough observations to prove the correct target was exercised.
- [ ] **UC-M12.01-C015-T07 · Outcome comparison:** Compare every declared “Native runner identity” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M12.01-C015-T08 · State and bounds check:** Inspect the “Native runner identity” ownership/state effects and actual use of “Runner profiles and environment metadata bytes”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M12.01-C015-T09 · Repeatability check:** Repeat the same “Native runner identity” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M12.01-C015-T10 · Positive evidence:** Attach the “Native runner identity” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M12.01-C016 · Negative test

**Original checklist item:** Negative case: A Linux path simulation is reported as a Windows test. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M12.01-C016-T01 · Adverse-case definition:** Create a test record for the exact “Native runner identity” source counterexample: “A Linux path simulation is reported as a Windows test”; state which precondition or invariant it challenges.
- [ ] **UC-M12.01-C016-T02 · Safe fixture boundary:** Define the contained test boundary for “Native runner identity”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M12.01-C016-T03 · Valid control:** Construct a valid “Native runner identity” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M12.01-C016-T04 · Minimal adverse input:** Derive the “Native runner identity” adverse fixture from the control with the smallest documented change needed to reproduce “A Linux path simulation is reported as a Windows test”; retain that change as reproducible data.
- [ ] **UC-M12.01-C016-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Native runner identity”; require “Simulated path checks cannot count as native OS execution” and forbid a false-success verdict.
- [ ] **UC-M12.01-C016-T06 · Adverse execution:** Exercise the “Native runner identity” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M12.01-C016-T07 · Effect inspection:** Inspect “Native runner identity” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M12.01-C016-T08 · Refusal versus failure:** Confirm the “Native runner identity” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M12.01-C016-T09 · Reset and retention:** Restore only the disposable “Native runner identity” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M12.01-C016-T10 · Negative regression:** Register the “Native runner identity” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M12.01-C017 · Change / failure test

**Original checklist item:** Exercise native runner identity when a supported host lacks a toolchain or uses a spaced/long installation root; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M12.01-C017-T01 · Scenario record:** Write the “Native runner identity” change/failure scenario exactly as supplied: a supported host lacks a toolchain or uses a spaced/long installation root; identify the property that must remain true: “Simulated path checks cannot count as native OS execution”.
- [ ] **UC-M12.01-C017-T02 · Baseline capture:** Create a known-valid “Native runner identity” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M12.01-C017-T03 · Injection map:** Locate the “Native runner identity” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M12.01-C017-T04 · Disposition oracle:** Define the legal intermediate and final “Native runner identity” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M12.01-C017-T05 · Controlled trigger:** Introduce the controlled “Native runner identity” scenario in the disposable fixture: a supported host lacks a toolchain or uses a spaced/long installation root; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M12.01-C017-T06 · Intermediate inspection:** Inspect the “Native runner identity” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M12.01-C017-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Native runner identity”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M12.01-C017-T08 · Stale-evidence cleanup:** Invalidate superseded “Native runner identity” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M12.01-C017-T09 · Repeat and compare:** Repeat the selected “Native runner identity” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M12.01-C017-T10 · Failure evidence:** Publish the “Native runner identity” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M12.01-C018 · Bounds

**Original checklist item:** Set a documented campaign budget for runner profiles and environment metadata bytes; record actual consumption, incomplete coverage and the disposition when the budget is exhausted.

- [ ] **UC-M12.01-C018-T01 · Quantity inventory:** Create a measurement inventory for “Native runner identity”: “Runner profiles and environment metadata bytes”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M12.01-C018-T02 · Measurement method:** Choose how to observe each “Native runner identity” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M12.01-C018-T03 · Budget decision:** Select justified campaign and target-resource budgets for “Native runner identity”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M12.01-C018-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Native runner identity” cases for “Runner profiles and environment metadata bytes”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M12.01-C018-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Native runner identity” limit; preserve “Simulated path checks cannot count as native OS execution”.
- [ ] **UC-M12.01-C018-T06 · Normal measurement:** Run or review the normal “Native runner identity” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M12.01-C018-T07 · At-limit measurement:** Exercise the “Native runner identity” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M12.01-C018-T08 · Over-limit measurement:** Exercise the “Native runner identity” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M12.01-C018-T09 · Uncovered-scope report:** List the “Native runner identity” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M12.01-C018-T10 · Limit evidence:** Publish the selected “Native runner identity” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M12.01-C019 · Diagnostics / review

**Original checklist item:** Report native runner identity results with executed, failed, skipped and unavailable cases separated; preserve the underlying observations and do not manufacture missing measurements.

- [ ] **UC-M12.01-C019-T01 · Result inventory:** Enumerate the required “Native runner identity” qualification cases and intended targets before aggregating results; keep the planned denominator visible.
- [ ] **UC-M12.01-C019-T02 · Verdict schema:** Define separate executed-pass, executed-fail, skipped, unavailable and untested outcomes for “Native runner identity”; document how incomplete cases block relevant claims.
- [ ] **UC-M12.01-C019-T03 · Identity fields:** Attach the actual target, fixture, configuration and revision identifiers to each “Native runner identity” result; do not attribute host-only evidence to a guest or another OS.
- [ ] **UC-M12.01-C019-T04 · Observation capture:** Capture bounded raw “Native runner identity” observations and harness errors; retain enough information to verify the reported oracle comparison.
- [ ] **UC-M12.01-C019-T05 · Aggregation rules:** Implement the “Native runner identity” count/reduction rule so failures and missing measurements cannot disappear; preserve “Simulated path checks cannot count as native OS execution”.
- [ ] **UC-M12.01-C019-T06 · Failure visibility:** Feed a failing “Native runner identity” control through the report path; assert the exact failed case and underlying observation remain visible.
- [ ] **UC-M12.01-C019-T07 · Missing-result visibility:** Withhold a required “Native runner identity” measurement or target; verify the report uses unavailable/untested rather than a fabricated zero or passing value.
- [ ] **UC-M12.01-C019-T08 · Bounds and redaction:** Check “Native runner identity” report size and retention against “Runner profiles and environment metadata bytes”; remove secrets while retaining fixture and subject references.
- [ ] **UC-M12.01-C019-T09 · Report reconciliation:** Reconcile the “Native runner identity” summary with every underlying case record; account for the full planned denominator and all omitted scope.
- [ ] **UC-M12.01-C019-T10 · Qualification handoff:** Publish the “Native runner identity” report with measured observations, coverage limits and blockers; state which actual targets remain unqualified.

### UC-M12.01-C020 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for native runner identity; label unexecuted checks as untested.

- [ ] **UC-M12.01-C020-T01 · Evidence inventory:** List the “Native runner identity” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M12.01-C020-T02 · Artifact references:** Record the exact “Native runner identity” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M12.01-C020-T03 · Fixture references:** Attach the “Native runner identity” fixture IDs, input identities and oracle definition; preserve the source counterexample “A Linux path simulation is reported as a Windows test” as a distinct evidence case.
- [ ] **UC-M12.01-C020-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Native runner identity”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M12.01-C020-T05 · Environment record:** Record the actual “Native runner identity” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M12.01-C020-T06 · Expected versus observed:** Pair every “Native runner identity” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M12.01-C020-T07 · Failure and limit records:** Attach “Native runner identity” change/failure and bounds evidence where required; include uncovered “Runner profiles and environment metadata bytes” and unresolved violations of “Simulated path checks cannot count as native OS execution”.
- [ ] **UC-M12.01-C020-T08 · Evidence hygiene:** Check the “Native runner identity” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M12.01-C020-T09 · Reproduction review:** Have the “Native runner identity” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M12.01-C020-T10 · Acceptance linkage:** Link the “Native runner identity” evidence to its parent and UC-M12.01 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 03. Launcher qualification

**Source delivery:** Run supplied launchers on their claimed native platforms.

**Source invariant:** Static inspection alone does not qualify native launcher behavior.

**Source negative case:** A Windows launcher is marked passed without invoking it on Windows.

**Source bounded quantities:** Launch modes and command count.

### UC-M12.01-C021 · Contract

**Original checklist item:** Define the qualification objective for launcher qualification, including the actual target implementation, prerequisites, observable oracle and explicit exclusions.

- [ ] **UC-M12.01-C021-T01 · Scope statement:** Write the qualification question for “Launcher qualification”; identify the actual target, claimed capability and observations that can answer that question.
- [ ] **UC-M12.01-C021-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Launcher qualification”; record each producer, representation and missing-value meaning.
- [ ] **UC-M12.01-C021-T03 · Output inventory:** List the outputs of “Launcher qualification” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M12.01-C021-T04 · Field dictionary:** Create a field-and-term dictionary for “Launcher qualification”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M12.01-C021-T05 · Prerequisite contract:** Map “Launcher qualification” to the source component prerequisites (UC-M03.08, UC-M04.01); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M12.01-C021-T06 · Authority map:** Identify who may produce, change and consume “Launcher qualification”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M12.01-C021-T07 · Invariant clause:** Add a normative clause for “Launcher qualification” that preserves “Static inspection alone does not qualify native launcher behavior”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M12.01-C021-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Launcher qualification”; include the source counterexample “A Windows launcher is marked passed without invoking it on Windows” and the intended safe disposition.
- [ ] **UC-M12.01-C021-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Launch modes and command count” in the “Launcher qualification” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M12.01-C021-T10 · Contract review:** Review the “Launcher qualification” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M12.01-C022 · Delivery

**Original checklist item:** Run supplied launchers on their claimed native platforms.

- [ ] **UC-M12.01-C022-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Launcher qualification”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M12.01-C022-T02 · Change plan:** Break the source delivery for “Launcher qualification” into concrete edit targets and reviewable outputs; keep the UC-M12.01 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M12.01-C022-T03 · Core artifact:** Create the “Launcher qualification” fixture or harness for this source instruction: Run supplied launchers on their claimed native platforms.
- [ ] **UC-M12.01-C022-T04 · Concrete realization:** Connect the “Launcher qualification” harness to its actual intended target, set the expected oracle before running it, and distinguish a mock/control run from a target run.
- [ ] **UC-M12.01-C022-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Launcher qualification” needed to preserve “Static inspection alone does not qualify native launcher behavior”; record an enforcement gap where only a model exists.
- [ ] **UC-M12.01-C022-T06 · Dependency connection:** Connect the “Launcher qualification” qualification artifact to native host runners, supplied launchers and machine-recorded build/verify results; record the target identity and what the harness actually exercises.
- [ ] **UC-M12.01-C022-T07 · Resource behavior:** Account for “Launch modes and command count” in “Launcher qualification”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M12.01-C022-T08 · Delivery check:** Run a known-valid control and a deliberately failing control for “Launcher qualification”; confirm the harness distinguishes their observed outcomes.
- [ ] **UC-M12.01-C022-T09 · Patch review:** Review the “Launcher qualification” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M12.01-C022-T10 · Delivery handoff:** Publish the “Launcher qualification” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M12.01-C023 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Static inspection alone does not qualify native launcher behavior. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M12.01-C023-T01 · Named property:** Create a stable property/check name under this parent for “Launcher qualification”; copy its required invariant exactly: “Static inspection alone does not qualify native launcher behavior”.
- [ ] **UC-M12.01-C023-T02 · Observable terms:** Define each term in the “Launcher qualification” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M12.01-C023-T03 · Precondition set:** List the preconditions under which “Static inspection alone does not qualify native launcher behavior” must hold for “Launcher qualification”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M12.01-C023-T04 · Transition coverage:** Map the “Launcher qualification” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M12.01-C023-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Launcher qualification”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M12.01-C023-T06 · Satisfying fixture:** Create a concrete “Launcher qualification” case that satisfies “Static inspection alone does not qualify native launcher behavior”; record its expected observation before running the assertion or review.
- [ ] **UC-M12.01-C023-T07 · Violating fixture:** Create the source counterexample “A Windows launcher is marked passed without invoking it on Windows” for “Launcher qualification”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M12.01-C023-T08 · Enforcement evidence:** Exercise the “Launcher qualification” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M12.01-C023-T09 · Regression linkage:** Link the “Launcher qualification” property to changes in native host runners, supplied launchers and machine-recorded build/verify results; record which dependency or contract changes require rerunning it.
- [ ] **UC-M12.01-C023-T10 · Property disposition:** Compare the satisfying and violating “Launcher qualification” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M12.01-C024 · Integration

**Original checklist item:** Integrate launcher qualification with native host runners, supplied launchers and machine-recorded build/verify results; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M12.01-C024-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Launcher qualification” across native host runners, supplied launchers and machine-recorded build/verify results; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M12.01-C024-T02 · Field mapping:** Map every “Launcher qualification” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M12.01-C024-T03 · Prerequisite identities:** Record the actual prerequisites for “Launcher qualification” (source dependency list: UC-M03.08, UC-M04.01); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M12.01-C024-T04 · Ownership agreement:** Specify who owns “Launcher qualification” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M12.01-C024-T05 · Handoff implementation:** Connect “Launcher qualification” through the mapped seam using the real adapter or explicit specification reference; preserve “Static inspection alone does not qualify native launcher behavior” across the handoff.
- [ ] **UC-M12.01-C024-T06 · Absent-input case:** Omit one required “Launcher qualification” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M12.01-C024-T07 · Stale-input case:** Supply an outdated “Launcher qualification” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M12.01-C024-T08 · Incompatible-input case:** Supply an incompatible “Launcher qualification” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M12.01-C024-T09 · Valid integration trace:** Run a valid “Launcher qualification” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M12.01-C024-T10 · Seam review:** Reconcile the “Launcher qualification” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M12.01-C025 · Valid-case test

**Original checklist item:** Run a known-valid control for launcher qualification; verify that the harness reaches its intended target and compare observed measurements or verdicts with predeclared expectations.

- [ ] **UC-M12.01-C025-T01 · Valid fixture choice:** Choose a known-valid control for “Launcher qualification”; document why it should pass and how it proves the harness reaches the intended target.
- [ ] **UC-M12.01-C025-T02 · Expected-result oracle:** Specify the “Launcher qualification” expected result independently of the implementation output; include the property “Static inspection alone does not qualify native launcher behavior” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M12.01-C025-T03 · Fixture material:** Create the concrete “Launcher qualification” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M12.01-C025-T04 · Target preparation:** Prepare the “Launcher qualification” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M12.01-C025-T05 · Initial-state record:** Record the initial “Launcher qualification” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M12.01-C025-T06 · Valid-path execution:** Run the “Launcher qualification” known-valid control on the identified target; retain enough observations to prove the correct target was exercised.
- [ ] **UC-M12.01-C025-T07 · Outcome comparison:** Compare every declared “Launcher qualification” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M12.01-C025-T08 · State and bounds check:** Inspect the “Launcher qualification” ownership/state effects and actual use of “Launch modes and command count”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M12.01-C025-T09 · Repeatability check:** Repeat the same “Launcher qualification” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M12.01-C025-T10 · Positive evidence:** Attach the “Launcher qualification” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M12.01-C026 · Negative test

**Original checklist item:** Negative case: A Windows launcher is marked passed without invoking it on Windows. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M12.01-C026-T01 · Adverse-case definition:** Create a test record for the exact “Launcher qualification” source counterexample: “A Windows launcher is marked passed without invoking it on Windows”; state which precondition or invariant it challenges.
- [ ] **UC-M12.01-C026-T02 · Safe fixture boundary:** Define the contained test boundary for “Launcher qualification”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M12.01-C026-T03 · Valid control:** Construct a valid “Launcher qualification” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M12.01-C026-T04 · Minimal adverse input:** Derive the “Launcher qualification” adverse fixture from the control with the smallest documented change needed to reproduce “A Windows launcher is marked passed without invoking it on Windows”; retain that change as reproducible data.
- [ ] **UC-M12.01-C026-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Launcher qualification”; require “Static inspection alone does not qualify native launcher behavior” and forbid a false-success verdict.
- [ ] **UC-M12.01-C026-T06 · Adverse execution:** Exercise the “Launcher qualification” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M12.01-C026-T07 · Effect inspection:** Inspect “Launcher qualification” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M12.01-C026-T08 · Refusal versus failure:** Confirm the “Launcher qualification” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M12.01-C026-T09 · Reset and retention:** Restore only the disposable “Launcher qualification” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M12.01-C026-T10 · Negative regression:** Register the “Launcher qualification” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M12.01-C027 · Change / failure test

**Original checklist item:** Exercise launcher qualification when a supported host lacks a toolchain or uses a spaced/long installation root; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M12.01-C027-T01 · Scenario record:** Write the “Launcher qualification” change/failure scenario exactly as supplied: a supported host lacks a toolchain or uses a spaced/long installation root; identify the property that must remain true: “Static inspection alone does not qualify native launcher behavior”.
- [ ] **UC-M12.01-C027-T02 · Baseline capture:** Create a known-valid “Launcher qualification” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M12.01-C027-T03 · Injection map:** Locate the “Launcher qualification” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M12.01-C027-T04 · Disposition oracle:** Define the legal intermediate and final “Launcher qualification” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M12.01-C027-T05 · Controlled trigger:** Introduce the controlled “Launcher qualification” scenario in the disposable fixture: a supported host lacks a toolchain or uses a spaced/long installation root; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M12.01-C027-T06 · Intermediate inspection:** Inspect the “Launcher qualification” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M12.01-C027-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Launcher qualification”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M12.01-C027-T08 · Stale-evidence cleanup:** Invalidate superseded “Launcher qualification” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M12.01-C027-T09 · Repeat and compare:** Repeat the selected “Launcher qualification” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M12.01-C027-T10 · Failure evidence:** Publish the “Launcher qualification” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M12.01-C028 · Bounds

**Original checklist item:** Set a documented campaign budget for launch modes and command count; record actual consumption, incomplete coverage and the disposition when the budget is exhausted.

- [ ] **UC-M12.01-C028-T01 · Quantity inventory:** Create a measurement inventory for “Launcher qualification”: “Launch modes and command count”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M12.01-C028-T02 · Measurement method:** Choose how to observe each “Launcher qualification” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M12.01-C028-T03 · Budget decision:** Select justified campaign and target-resource budgets for “Launcher qualification”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M12.01-C028-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Launcher qualification” cases for “Launch modes and command count”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M12.01-C028-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Launcher qualification” limit; preserve “Static inspection alone does not qualify native launcher behavior”.
- [ ] **UC-M12.01-C028-T06 · Normal measurement:** Run or review the normal “Launcher qualification” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M12.01-C028-T07 · At-limit measurement:** Exercise the “Launcher qualification” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M12.01-C028-T08 · Over-limit measurement:** Exercise the “Launcher qualification” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M12.01-C028-T09 · Uncovered-scope report:** List the “Launcher qualification” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M12.01-C028-T10 · Limit evidence:** Publish the selected “Launcher qualification” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M12.01-C029 · Diagnostics / review

**Original checklist item:** Report launcher qualification results with executed, failed, skipped and unavailable cases separated; preserve the underlying observations and do not manufacture missing measurements.

- [ ] **UC-M12.01-C029-T01 · Result inventory:** Enumerate the required “Launcher qualification” qualification cases and intended targets before aggregating results; keep the planned denominator visible.
- [ ] **UC-M12.01-C029-T02 · Verdict schema:** Define separate executed-pass, executed-fail, skipped, unavailable and untested outcomes for “Launcher qualification”; document how incomplete cases block relevant claims.
- [ ] **UC-M12.01-C029-T03 · Identity fields:** Attach the actual target, fixture, configuration and revision identifiers to each “Launcher qualification” result; do not attribute host-only evidence to a guest or another OS.
- [ ] **UC-M12.01-C029-T04 · Observation capture:** Capture bounded raw “Launcher qualification” observations and harness errors; retain enough information to verify the reported oracle comparison.
- [ ] **UC-M12.01-C029-T05 · Aggregation rules:** Implement the “Launcher qualification” count/reduction rule so failures and missing measurements cannot disappear; preserve “Static inspection alone does not qualify native launcher behavior”.
- [ ] **UC-M12.01-C029-T06 · Failure visibility:** Feed a failing “Launcher qualification” control through the report path; assert the exact failed case and underlying observation remain visible.
- [ ] **UC-M12.01-C029-T07 · Missing-result visibility:** Withhold a required “Launcher qualification” measurement or target; verify the report uses unavailable/untested rather than a fabricated zero or passing value.
- [ ] **UC-M12.01-C029-T08 · Bounds and redaction:** Check “Launcher qualification” report size and retention against “Launch modes and command count”; remove secrets while retaining fixture and subject references.
- [ ] **UC-M12.01-C029-T09 · Report reconciliation:** Reconcile the “Launcher qualification” summary with every underlying case record; account for the full planned denominator and all omitted scope.
- [ ] **UC-M12.01-C029-T10 · Qualification handoff:** Publish the “Launcher qualification” report with measured observations, coverage limits and blockers; state which actual targets remain unqualified.

### UC-M12.01-C030 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for launcher qualification; label unexecuted checks as untested.

- [ ] **UC-M12.01-C030-T01 · Evidence inventory:** List the “Launcher qualification” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M12.01-C030-T02 · Artifact references:** Record the exact “Launcher qualification” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M12.01-C030-T03 · Fixture references:** Attach the “Launcher qualification” fixture IDs, input identities and oracle definition; preserve the source counterexample “A Windows launcher is marked passed without invoking it on Windows” as a distinct evidence case.
- [ ] **UC-M12.01-C030-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Launcher qualification”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M12.01-C030-T05 · Environment record:** Record the actual “Launcher qualification” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M12.01-C030-T06 · Expected versus observed:** Pair every “Launcher qualification” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M12.01-C030-T07 · Failure and limit records:** Attach “Launcher qualification” change/failure and bounds evidence where required; include uncovered “Launch modes and command count” and unresolved violations of “Static inspection alone does not qualify native launcher behavior”.
- [ ] **UC-M12.01-C030-T08 · Evidence hygiene:** Check the “Launcher qualification” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M12.01-C030-T09 · Reproduction review:** Have the “Launcher qualification” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M12.01-C030-T10 · Acceptance linkage:** Link the “Launcher qualification” evidence to its parent and UC-M12.01 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 04. Native build qualification

**Source delivery:** Build actual required engines and guest artifacts on supported build hosts.

**Source invariant:** A dependency check is not a substitute for native compilation evidence.

**Source negative case:** A CI job finds the compiler but never builds the target.

**Source bounded quantities:** Build targets and compute/storage budget.

### UC-M12.01-C031 · Contract

**Original checklist item:** Define the qualification objective for native build qualification, including the actual target implementation, prerequisites, observable oracle and explicit exclusions.

- [ ] **UC-M12.01-C031-T01 · Scope statement:** Write the qualification question for “Native build qualification”; identify the actual target, claimed capability and observations that can answer that question.
- [ ] **UC-M12.01-C031-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Native build qualification”; record each producer, representation and missing-value meaning.
- [ ] **UC-M12.01-C031-T03 · Output inventory:** List the outputs of “Native build qualification” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M12.01-C031-T04 · Field dictionary:** Create a field-and-term dictionary for “Native build qualification”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M12.01-C031-T05 · Prerequisite contract:** Map “Native build qualification” to the source component prerequisites (UC-M03.08, UC-M04.01); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M12.01-C031-T06 · Authority map:** Identify who may produce, change and consume “Native build qualification”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M12.01-C031-T07 · Invariant clause:** Add a normative clause for “Native build qualification” that preserves “A dependency check is not a substitute for native compilation evidence”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M12.01-C031-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Native build qualification”; include the source counterexample “A CI job finds the compiler but never builds the target” and the intended safe disposition.
- [ ] **UC-M12.01-C031-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Build targets and compute/storage budget” in the “Native build qualification” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M12.01-C031-T10 · Contract review:** Review the “Native build qualification” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M12.01-C032 · Delivery

**Original checklist item:** Build actual required engines and guest artifacts on supported build hosts.

- [ ] **UC-M12.01-C032-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Native build qualification”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M12.01-C032-T02 · Change plan:** Break the source delivery for “Native build qualification” into concrete edit targets and reviewable outputs; keep the UC-M12.01 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M12.01-C032-T03 · Core artifact:** Implement the smallest selected-profile change for “Native build qualification” that realizes this source instruction: Build actual required engines and guest artifacts on supported build hosts.
- [ ] **UC-M12.01-C032-T04 · Concrete realization:** Trace “Native build qualification” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M12.01-C032-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Native build qualification” needed to preserve “A dependency check is not a substitute for native compilation evidence”; record an enforcement gap where only a model exists.
- [ ] **UC-M12.01-C032-T06 · Dependency connection:** Connect the “Native build qualification” qualification artifact to native host runners, supplied launchers and machine-recorded build/verify results; record the target identity and what the harness actually exercises.
- [ ] **UC-M12.01-C032-T07 · Resource behavior:** Account for “Build targets and compute/storage budget” in “Native build qualification”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M12.01-C032-T08 · Delivery check:** Run a known-valid control and a deliberately failing control for “Native build qualification”; confirm the harness distinguishes their observed outcomes.
- [ ] **UC-M12.01-C032-T09 · Patch review:** Review the “Native build qualification” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M12.01-C032-T10 · Delivery handoff:** Publish the “Native build qualification” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M12.01-C033 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: A dependency check is not a substitute for native compilation evidence. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M12.01-C033-T01 · Named property:** Create a stable property/check name under this parent for “Native build qualification”; copy its required invariant exactly: “A dependency check is not a substitute for native compilation evidence”.
- [ ] **UC-M12.01-C033-T02 · Observable terms:** Define each term in the “Native build qualification” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M12.01-C033-T03 · Precondition set:** List the preconditions under which “A dependency check is not a substitute for native compilation evidence” must hold for “Native build qualification”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M12.01-C033-T04 · Transition coverage:** Map the “Native build qualification” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M12.01-C033-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Native build qualification”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M12.01-C033-T06 · Satisfying fixture:** Create a concrete “Native build qualification” case that satisfies “A dependency check is not a substitute for native compilation evidence”; record its expected observation before running the assertion or review.
- [ ] **UC-M12.01-C033-T07 · Violating fixture:** Create the source counterexample “A CI job finds the compiler but never builds the target” for “Native build qualification”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M12.01-C033-T08 · Enforcement evidence:** Exercise the “Native build qualification” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M12.01-C033-T09 · Regression linkage:** Link the “Native build qualification” property to changes in native host runners, supplied launchers and machine-recorded build/verify results; record which dependency or contract changes require rerunning it.
- [ ] **UC-M12.01-C033-T10 · Property disposition:** Compare the satisfying and violating “Native build qualification” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M12.01-C034 · Integration

**Original checklist item:** Integrate native build qualification with native host runners, supplied launchers and machine-recorded build/verify results; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M12.01-C034-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Native build qualification” across native host runners, supplied launchers and machine-recorded build/verify results; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M12.01-C034-T02 · Field mapping:** Map every “Native build qualification” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M12.01-C034-T03 · Prerequisite identities:** Record the actual prerequisites for “Native build qualification” (source dependency list: UC-M03.08, UC-M04.01); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M12.01-C034-T04 · Ownership agreement:** Specify who owns “Native build qualification” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M12.01-C034-T05 · Handoff implementation:** Connect “Native build qualification” through the mapped seam using the real adapter or explicit specification reference; preserve “A dependency check is not a substitute for native compilation evidence” across the handoff.
- [ ] **UC-M12.01-C034-T06 · Absent-input case:** Omit one required “Native build qualification” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M12.01-C034-T07 · Stale-input case:** Supply an outdated “Native build qualification” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M12.01-C034-T08 · Incompatible-input case:** Supply an incompatible “Native build qualification” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M12.01-C034-T09 · Valid integration trace:** Run a valid “Native build qualification” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M12.01-C034-T10 · Seam review:** Reconcile the “Native build qualification” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M12.01-C035 · Valid-case test

**Original checklist item:** Run a known-valid control for native build qualification; verify that the harness reaches its intended target and compare observed measurements or verdicts with predeclared expectations.

- [ ] **UC-M12.01-C035-T01 · Valid fixture choice:** Choose a known-valid control for “Native build qualification”; document why it should pass and how it proves the harness reaches the intended target.
- [ ] **UC-M12.01-C035-T02 · Expected-result oracle:** Specify the “Native build qualification” expected result independently of the implementation output; include the property “A dependency check is not a substitute for native compilation evidence” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M12.01-C035-T03 · Fixture material:** Create the concrete “Native build qualification” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M12.01-C035-T04 · Target preparation:** Prepare the “Native build qualification” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M12.01-C035-T05 · Initial-state record:** Record the initial “Native build qualification” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M12.01-C035-T06 · Valid-path execution:** Run the “Native build qualification” known-valid control on the identified target; retain enough observations to prove the correct target was exercised.
- [ ] **UC-M12.01-C035-T07 · Outcome comparison:** Compare every declared “Native build qualification” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M12.01-C035-T08 · State and bounds check:** Inspect the “Native build qualification” ownership/state effects and actual use of “Build targets and compute/storage budget”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M12.01-C035-T09 · Repeatability check:** Repeat the same “Native build qualification” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M12.01-C035-T10 · Positive evidence:** Attach the “Native build qualification” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M12.01-C036 · Negative test

**Original checklist item:** Negative case: A CI job finds the compiler but never builds the target. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M12.01-C036-T01 · Adverse-case definition:** Create a test record for the exact “Native build qualification” source counterexample: “A CI job finds the compiler but never builds the target”; state which precondition or invariant it challenges.
- [ ] **UC-M12.01-C036-T02 · Safe fixture boundary:** Define the contained test boundary for “Native build qualification”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M12.01-C036-T03 · Valid control:** Construct a valid “Native build qualification” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M12.01-C036-T04 · Minimal adverse input:** Derive the “Native build qualification” adverse fixture from the control with the smallest documented change needed to reproduce “A CI job finds the compiler but never builds the target”; retain that change as reproducible data.
- [ ] **UC-M12.01-C036-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Native build qualification”; require “A dependency check is not a substitute for native compilation evidence” and forbid a false-success verdict.
- [ ] **UC-M12.01-C036-T06 · Adverse execution:** Exercise the “Native build qualification” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M12.01-C036-T07 · Effect inspection:** Inspect “Native build qualification” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M12.01-C036-T08 · Refusal versus failure:** Confirm the “Native build qualification” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M12.01-C036-T09 · Reset and retention:** Restore only the disposable “Native build qualification” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M12.01-C036-T10 · Negative regression:** Register the “Native build qualification” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M12.01-C037 · Change / failure test

**Original checklist item:** Exercise native build qualification when a supported host lacks a toolchain or uses a spaced/long installation root; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M12.01-C037-T01 · Scenario record:** Write the “Native build qualification” change/failure scenario exactly as supplied: a supported host lacks a toolchain or uses a spaced/long installation root; identify the property that must remain true: “A dependency check is not a substitute for native compilation evidence”.
- [ ] **UC-M12.01-C037-T02 · Baseline capture:** Create a known-valid “Native build qualification” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M12.01-C037-T03 · Injection map:** Locate the “Native build qualification” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M12.01-C037-T04 · Disposition oracle:** Define the legal intermediate and final “Native build qualification” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M12.01-C037-T05 · Controlled trigger:** Introduce the controlled “Native build qualification” scenario in the disposable fixture: a supported host lacks a toolchain or uses a spaced/long installation root; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M12.01-C037-T06 · Intermediate inspection:** Inspect the “Native build qualification” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M12.01-C037-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Native build qualification”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M12.01-C037-T08 · Stale-evidence cleanup:** Invalidate superseded “Native build qualification” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M12.01-C037-T09 · Repeat and compare:** Repeat the selected “Native build qualification” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M12.01-C037-T10 · Failure evidence:** Publish the “Native build qualification” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M12.01-C038 · Bounds

**Original checklist item:** Set a documented campaign budget for build targets and compute/storage budget; record actual consumption, incomplete coverage and the disposition when the budget is exhausted.

- [ ] **UC-M12.01-C038-T01 · Quantity inventory:** Create a measurement inventory for “Native build qualification”: “Build targets and compute/storage budget”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M12.01-C038-T02 · Measurement method:** Choose how to observe each “Native build qualification” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M12.01-C038-T03 · Budget decision:** Select justified campaign and target-resource budgets for “Native build qualification”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M12.01-C038-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Native build qualification” cases for “Build targets and compute/storage budget”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M12.01-C038-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Native build qualification” limit; preserve “A dependency check is not a substitute for native compilation evidence”.
- [ ] **UC-M12.01-C038-T06 · Normal measurement:** Run or review the normal “Native build qualification” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M12.01-C038-T07 · At-limit measurement:** Exercise the “Native build qualification” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M12.01-C038-T08 · Over-limit measurement:** Exercise the “Native build qualification” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M12.01-C038-T09 · Uncovered-scope report:** List the “Native build qualification” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M12.01-C038-T10 · Limit evidence:** Publish the selected “Native build qualification” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M12.01-C039 · Diagnostics / review

**Original checklist item:** Report native build qualification results with executed, failed, skipped and unavailable cases separated; preserve the underlying observations and do not manufacture missing measurements.

- [ ] **UC-M12.01-C039-T01 · Result inventory:** Enumerate the required “Native build qualification” qualification cases and intended targets before aggregating results; keep the planned denominator visible.
- [ ] **UC-M12.01-C039-T02 · Verdict schema:** Define separate executed-pass, executed-fail, skipped, unavailable and untested outcomes for “Native build qualification”; document how incomplete cases block relevant claims.
- [ ] **UC-M12.01-C039-T03 · Identity fields:** Attach the actual target, fixture, configuration and revision identifiers to each “Native build qualification” result; do not attribute host-only evidence to a guest or another OS.
- [ ] **UC-M12.01-C039-T04 · Observation capture:** Capture bounded raw “Native build qualification” observations and harness errors; retain enough information to verify the reported oracle comparison.
- [ ] **UC-M12.01-C039-T05 · Aggregation rules:** Implement the “Native build qualification” count/reduction rule so failures and missing measurements cannot disappear; preserve “A dependency check is not a substitute for native compilation evidence”.
- [ ] **UC-M12.01-C039-T06 · Failure visibility:** Feed a failing “Native build qualification” control through the report path; assert the exact failed case and underlying observation remain visible.
- [ ] **UC-M12.01-C039-T07 · Missing-result visibility:** Withhold a required “Native build qualification” measurement or target; verify the report uses unavailable/untested rather than a fabricated zero or passing value.
- [ ] **UC-M12.01-C039-T08 · Bounds and redaction:** Check “Native build qualification” report size and retention against “Build targets and compute/storage budget”; remove secrets while retaining fixture and subject references.
- [ ] **UC-M12.01-C039-T09 · Report reconciliation:** Reconcile the “Native build qualification” summary with every underlying case record; account for the full planned denominator and all omitted scope.
- [ ] **UC-M12.01-C039-T10 · Qualification handoff:** Publish the “Native build qualification” report with measured observations, coverage limits and blockers; state which actual targets remain unqualified.

### UC-M12.01-C040 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for native build qualification; label unexecuted checks as untested.

- [ ] **UC-M12.01-C040-T01 · Evidence inventory:** List the “Native build qualification” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M12.01-C040-T02 · Artifact references:** Record the exact “Native build qualification” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M12.01-C040-T03 · Fixture references:** Attach the “Native build qualification” fixture IDs, input identities and oracle definition; preserve the source counterexample “A CI job finds the compiler but never builds the target” as a distinct evidence case.
- [ ] **UC-M12.01-C040-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Native build qualification”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M12.01-C040-T05 · Environment record:** Record the actual “Native build qualification” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M12.01-C040-T06 · Expected versus observed:** Pair every “Native build qualification” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M12.01-C040-T07 · Failure and limit records:** Attach “Native build qualification” change/failure and bounds evidence where required; include uncovered “Build targets and compute/storage budget” and unresolved violations of “A dependency check is not a substitute for native compilation evidence”.
- [ ] **UC-M12.01-C040-T08 · Evidence hygiene:** Check the “Native build qualification” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M12.01-C040-T09 · Reproduction review:** Have the “Native build qualification” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M12.01-C040-T10 · Acceptance linkage:** Link the “Native build qualification” evidence to its parent and UC-M12.01 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 05. Native verification battery

**Source delivery:** Execute required runtime and negative verification gates on supported hosts.

**Source invariant:** Compilation success alone does not qualify execution behavior.

**Source negative case:** A binary builds but all native execution tests are skipped.

**Source bounded quantities:** Test cases and runtime budget.

### UC-M12.01-C041 · Contract

**Original checklist item:** Define the qualification objective for native verification battery, including the actual target implementation, prerequisites, observable oracle and explicit exclusions.

- [ ] **UC-M12.01-C041-T01 · Scope statement:** Write the qualification question for “Native verification battery”; identify the actual target, claimed capability and observations that can answer that question.
- [ ] **UC-M12.01-C041-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Native verification battery”; record each producer, representation and missing-value meaning.
- [ ] **UC-M12.01-C041-T03 · Output inventory:** List the outputs of “Native verification battery” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M12.01-C041-T04 · Field dictionary:** Create a field-and-term dictionary for “Native verification battery”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M12.01-C041-T05 · Prerequisite contract:** Map “Native verification battery” to the source component prerequisites (UC-M03.08, UC-M04.01); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M12.01-C041-T06 · Authority map:** Identify who may produce, change and consume “Native verification battery”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M12.01-C041-T07 · Invariant clause:** Add a normative clause for “Native verification battery” that preserves “Compilation success alone does not qualify execution behavior”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M12.01-C041-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Native verification battery”; include the source counterexample “A binary builds but all native execution tests are skipped” and the intended safe disposition.
- [ ] **UC-M12.01-C041-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Test cases and runtime budget” in the “Native verification battery” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M12.01-C041-T10 · Contract review:** Review the “Native verification battery” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M12.01-C042 · Delivery

**Original checklist item:** Execute required runtime and negative verification gates on supported hosts.

- [ ] **UC-M12.01-C042-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Native verification battery”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M12.01-C042-T02 · Change plan:** Break the source delivery for “Native verification battery” into concrete edit targets and reviewable outputs; keep the UC-M12.01 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M12.01-C042-T03 · Core artifact:** Implement the smallest selected-profile change for “Native verification battery” that realizes this source instruction: Execute required runtime and negative verification gates on supported hosts.
- [ ] **UC-M12.01-C042-T04 · Concrete realization:** Trace “Native verification battery” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M12.01-C042-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Native verification battery” needed to preserve “Compilation success alone does not qualify execution behavior”; record an enforcement gap where only a model exists.
- [ ] **UC-M12.01-C042-T06 · Dependency connection:** Connect the “Native verification battery” qualification artifact to native host runners, supplied launchers and machine-recorded build/verify results; record the target identity and what the harness actually exercises.
- [ ] **UC-M12.01-C042-T07 · Resource behavior:** Account for “Test cases and runtime budget” in “Native verification battery”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M12.01-C042-T08 · Delivery check:** Run a known-valid control and a deliberately failing control for “Native verification battery”; confirm the harness distinguishes their observed outcomes.
- [ ] **UC-M12.01-C042-T09 · Patch review:** Review the “Native verification battery” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M12.01-C042-T10 · Delivery handoff:** Publish the “Native verification battery” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M12.01-C043 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Compilation success alone does not qualify execution behavior. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M12.01-C043-T01 · Named property:** Create a stable property/check name under this parent for “Native verification battery”; copy its required invariant exactly: “Compilation success alone does not qualify execution behavior”.
- [ ] **UC-M12.01-C043-T02 · Observable terms:** Define each term in the “Native verification battery” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M12.01-C043-T03 · Precondition set:** List the preconditions under which “Compilation success alone does not qualify execution behavior” must hold for “Native verification battery”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M12.01-C043-T04 · Transition coverage:** Map the “Native verification battery” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M12.01-C043-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Native verification battery”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M12.01-C043-T06 · Satisfying fixture:** Create a concrete “Native verification battery” case that satisfies “Compilation success alone does not qualify execution behavior”; record its expected observation before running the assertion or review.
- [ ] **UC-M12.01-C043-T07 · Violating fixture:** Create the source counterexample “A binary builds but all native execution tests are skipped” for “Native verification battery”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M12.01-C043-T08 · Enforcement evidence:** Exercise the “Native verification battery” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M12.01-C043-T09 · Regression linkage:** Link the “Native verification battery” property to changes in native host runners, supplied launchers and machine-recorded build/verify results; record which dependency or contract changes require rerunning it.
- [ ] **UC-M12.01-C043-T10 · Property disposition:** Compare the satisfying and violating “Native verification battery” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M12.01-C044 · Integration

**Original checklist item:** Integrate native verification battery with native host runners, supplied launchers and machine-recorded build/verify results; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M12.01-C044-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Native verification battery” across native host runners, supplied launchers and machine-recorded build/verify results; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M12.01-C044-T02 · Field mapping:** Map every “Native verification battery” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M12.01-C044-T03 · Prerequisite identities:** Record the actual prerequisites for “Native verification battery” (source dependency list: UC-M03.08, UC-M04.01); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M12.01-C044-T04 · Ownership agreement:** Specify who owns “Native verification battery” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M12.01-C044-T05 · Handoff implementation:** Connect “Native verification battery” through the mapped seam using the real adapter or explicit specification reference; preserve “Compilation success alone does not qualify execution behavior” across the handoff.
- [ ] **UC-M12.01-C044-T06 · Absent-input case:** Omit one required “Native verification battery” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M12.01-C044-T07 · Stale-input case:** Supply an outdated “Native verification battery” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M12.01-C044-T08 · Incompatible-input case:** Supply an incompatible “Native verification battery” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M12.01-C044-T09 · Valid integration trace:** Run a valid “Native verification battery” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M12.01-C044-T10 · Seam review:** Reconcile the “Native verification battery” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M12.01-C045 · Valid-case test

**Original checklist item:** Run a known-valid control for native verification battery; verify that the harness reaches its intended target and compare observed measurements or verdicts with predeclared expectations.

- [ ] **UC-M12.01-C045-T01 · Valid fixture choice:** Choose a known-valid control for “Native verification battery”; document why it should pass and how it proves the harness reaches the intended target.
- [ ] **UC-M12.01-C045-T02 · Expected-result oracle:** Specify the “Native verification battery” expected result independently of the implementation output; include the property “Compilation success alone does not qualify execution behavior” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M12.01-C045-T03 · Fixture material:** Create the concrete “Native verification battery” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M12.01-C045-T04 · Target preparation:** Prepare the “Native verification battery” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M12.01-C045-T05 · Initial-state record:** Record the initial “Native verification battery” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M12.01-C045-T06 · Valid-path execution:** Run the “Native verification battery” known-valid control on the identified target; retain enough observations to prove the correct target was exercised.
- [ ] **UC-M12.01-C045-T07 · Outcome comparison:** Compare every declared “Native verification battery” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M12.01-C045-T08 · State and bounds check:** Inspect the “Native verification battery” ownership/state effects and actual use of “Test cases and runtime budget”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M12.01-C045-T09 · Repeatability check:** Repeat the same “Native verification battery” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M12.01-C045-T10 · Positive evidence:** Attach the “Native verification battery” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M12.01-C046 · Negative test

**Original checklist item:** Negative case: A binary builds but all native execution tests are skipped. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M12.01-C046-T01 · Adverse-case definition:** Create a test record for the exact “Native verification battery” source counterexample: “A binary builds but all native execution tests are skipped”; state which precondition or invariant it challenges.
- [ ] **UC-M12.01-C046-T02 · Safe fixture boundary:** Define the contained test boundary for “Native verification battery”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M12.01-C046-T03 · Valid control:** Construct a valid “Native verification battery” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M12.01-C046-T04 · Minimal adverse input:** Derive the “Native verification battery” adverse fixture from the control with the smallest documented change needed to reproduce “A binary builds but all native execution tests are skipped”; retain that change as reproducible data.
- [ ] **UC-M12.01-C046-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Native verification battery”; require “Compilation success alone does not qualify execution behavior” and forbid a false-success verdict.
- [ ] **UC-M12.01-C046-T06 · Adverse execution:** Exercise the “Native verification battery” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M12.01-C046-T07 · Effect inspection:** Inspect “Native verification battery” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M12.01-C046-T08 · Refusal versus failure:** Confirm the “Native verification battery” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M12.01-C046-T09 · Reset and retention:** Restore only the disposable “Native verification battery” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M12.01-C046-T10 · Negative regression:** Register the “Native verification battery” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M12.01-C047 · Change / failure test

**Original checklist item:** Exercise native verification battery when a supported host lacks a toolchain or uses a spaced/long installation root; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M12.01-C047-T01 · Scenario record:** Write the “Native verification battery” change/failure scenario exactly as supplied: a supported host lacks a toolchain or uses a spaced/long installation root; identify the property that must remain true: “Compilation success alone does not qualify execution behavior”.
- [ ] **UC-M12.01-C047-T02 · Baseline capture:** Create a known-valid “Native verification battery” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M12.01-C047-T03 · Injection map:** Locate the “Native verification battery” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M12.01-C047-T04 · Disposition oracle:** Define the legal intermediate and final “Native verification battery” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M12.01-C047-T05 · Controlled trigger:** Introduce the controlled “Native verification battery” scenario in the disposable fixture: a supported host lacks a toolchain or uses a spaced/long installation root; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M12.01-C047-T06 · Intermediate inspection:** Inspect the “Native verification battery” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M12.01-C047-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Native verification battery”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M12.01-C047-T08 · Stale-evidence cleanup:** Invalidate superseded “Native verification battery” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M12.01-C047-T09 · Repeat and compare:** Repeat the selected “Native verification battery” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M12.01-C047-T10 · Failure evidence:** Publish the “Native verification battery” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M12.01-C048 · Bounds

**Original checklist item:** Set a documented campaign budget for test cases and runtime budget; record actual consumption, incomplete coverage and the disposition when the budget is exhausted.

- [ ] **UC-M12.01-C048-T01 · Quantity inventory:** Create a measurement inventory for “Native verification battery”: “Test cases and runtime budget”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M12.01-C048-T02 · Measurement method:** Choose how to observe each “Native verification battery” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M12.01-C048-T03 · Budget decision:** Select justified campaign and target-resource budgets for “Native verification battery”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M12.01-C048-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Native verification battery” cases for “Test cases and runtime budget”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M12.01-C048-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Native verification battery” limit; preserve “Compilation success alone does not qualify execution behavior”.
- [ ] **UC-M12.01-C048-T06 · Normal measurement:** Run or review the normal “Native verification battery” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M12.01-C048-T07 · At-limit measurement:** Exercise the “Native verification battery” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M12.01-C048-T08 · Over-limit measurement:** Exercise the “Native verification battery” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M12.01-C048-T09 · Uncovered-scope report:** List the “Native verification battery” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M12.01-C048-T10 · Limit evidence:** Publish the selected “Native verification battery” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M12.01-C049 · Diagnostics / review

**Original checklist item:** Report native verification battery results with executed, failed, skipped and unavailable cases separated; preserve the underlying observations and do not manufacture missing measurements.

- [ ] **UC-M12.01-C049-T01 · Result inventory:** Enumerate the required “Native verification battery” qualification cases and intended targets before aggregating results; keep the planned denominator visible.
- [ ] **UC-M12.01-C049-T02 · Verdict schema:** Define separate executed-pass, executed-fail, skipped, unavailable and untested outcomes for “Native verification battery”; document how incomplete cases block relevant claims.
- [ ] **UC-M12.01-C049-T03 · Identity fields:** Attach the actual target, fixture, configuration and revision identifiers to each “Native verification battery” result; do not attribute host-only evidence to a guest or another OS.
- [ ] **UC-M12.01-C049-T04 · Observation capture:** Capture bounded raw “Native verification battery” observations and harness errors; retain enough information to verify the reported oracle comparison.
- [ ] **UC-M12.01-C049-T05 · Aggregation rules:** Implement the “Native verification battery” count/reduction rule so failures and missing measurements cannot disappear; preserve “Compilation success alone does not qualify execution behavior”.
- [ ] **UC-M12.01-C049-T06 · Failure visibility:** Feed a failing “Native verification battery” control through the report path; assert the exact failed case and underlying observation remain visible.
- [ ] **UC-M12.01-C049-T07 · Missing-result visibility:** Withhold a required “Native verification battery” measurement or target; verify the report uses unavailable/untested rather than a fabricated zero or passing value.
- [ ] **UC-M12.01-C049-T08 · Bounds and redaction:** Check “Native verification battery” report size and retention against “Test cases and runtime budget”; remove secrets while retaining fixture and subject references.
- [ ] **UC-M12.01-C049-T09 · Report reconciliation:** Reconcile the “Native verification battery” summary with every underlying case record; account for the full planned denominator and all omitted scope.
- [ ] **UC-M12.01-C049-T10 · Qualification handoff:** Publish the “Native verification battery” report with measured observations, coverage limits and blockers; state which actual targets remain unqualified.

### UC-M12.01-C050 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for native verification battery; label unexecuted checks as untested.

- [ ] **UC-M12.01-C050-T01 · Evidence inventory:** List the “Native verification battery” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M12.01-C050-T02 · Artifact references:** Record the exact “Native verification battery” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M12.01-C050-T03 · Fixture references:** Attach the “Native verification battery” fixture IDs, input identities and oracle definition; preserve the source counterexample “A binary builds but all native execution tests are skipped” as a distinct evidence case.
- [ ] **UC-M12.01-C050-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Native verification battery”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M12.01-C050-T05 · Environment record:** Record the actual “Native verification battery” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M12.01-C050-T06 · Expected versus observed:** Pair every “Native verification battery” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M12.01-C050-T07 · Failure and limit records:** Attach “Native verification battery” change/failure and bounds evidence where required; include uncovered “Test cases and runtime budget” and unresolved violations of “Compilation success alone does not qualify execution behavior”.
- [ ] **UC-M12.01-C050-T08 · Evidence hygiene:** Check the “Native verification battery” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M12.01-C050-T09 · Reproduction review:** Have the “Native verification battery” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M12.01-C050-T10 · Acceptance linkage:** Link the “Native verification battery” evidence to its parent and UC-M12.01 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 06. Spaces and quoted paths

**Source delivery:** Exercise installation and workspace roots containing spaces on actual supported hosts.

**Source invariant:** Launchers preserve paths and arguments correctly.

**Source negative case:** A quoted root is split into separate command arguments.

**Source bounded quantities:** Path variants and argument bytes.

### UC-M12.01-C051 · Contract

**Original checklist item:** Define the qualification objective for spaces and quoted paths, including the actual target implementation, prerequisites, observable oracle and explicit exclusions.

- [ ] **UC-M12.01-C051-T01 · Scope statement:** Write the qualification question for “Spaces and quoted paths”; identify the actual target, claimed capability and observations that can answer that question.
- [ ] **UC-M12.01-C051-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Spaces and quoted paths”; record each producer, representation and missing-value meaning.
- [ ] **UC-M12.01-C051-T03 · Output inventory:** List the outputs of “Spaces and quoted paths” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M12.01-C051-T04 · Field dictionary:** Create a field-and-term dictionary for “Spaces and quoted paths”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M12.01-C051-T05 · Prerequisite contract:** Map “Spaces and quoted paths” to the source component prerequisites (UC-M03.08, UC-M04.01); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M12.01-C051-T06 · Authority map:** Identify who may produce, change and consume “Spaces and quoted paths”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M12.01-C051-T07 · Invariant clause:** Add a normative clause for “Spaces and quoted paths” that preserves “Launchers preserve paths and arguments correctly”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M12.01-C051-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Spaces and quoted paths”; include the source counterexample “A quoted root is split into separate command arguments” and the intended safe disposition.
- [ ] **UC-M12.01-C051-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Path variants and argument bytes” in the “Spaces and quoted paths” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M12.01-C051-T10 · Contract review:** Review the “Spaces and quoted paths” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M12.01-C052 · Delivery

**Original checklist item:** Exercise installation and workspace roots containing spaces on actual supported hosts.

- [ ] **UC-M12.01-C052-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Spaces and quoted paths”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M12.01-C052-T02 · Change plan:** Break the source delivery for “Spaces and quoted paths” into concrete edit targets and reviewable outputs; keep the UC-M12.01 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M12.01-C052-T03 · Core artifact:** Create the “Spaces and quoted paths” fixture or harness for this source instruction: Exercise installation and workspace roots containing spaces on actual supported hosts.
- [ ] **UC-M12.01-C052-T04 · Concrete realization:** Connect the “Spaces and quoted paths” harness to its actual intended target, set the expected oracle before running it, and distinguish a mock/control run from a target run.
- [ ] **UC-M12.01-C052-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Spaces and quoted paths” needed to preserve “Launchers preserve paths and arguments correctly”; record an enforcement gap where only a model exists.
- [ ] **UC-M12.01-C052-T06 · Dependency connection:** Connect the “Spaces and quoted paths” qualification artifact to native host runners, supplied launchers and machine-recorded build/verify results; record the target identity and what the harness actually exercises.
- [ ] **UC-M12.01-C052-T07 · Resource behavior:** Account for “Path variants and argument bytes” in “Spaces and quoted paths”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M12.01-C052-T08 · Delivery check:** Run a known-valid control and a deliberately failing control for “Spaces and quoted paths”; confirm the harness distinguishes their observed outcomes.
- [ ] **UC-M12.01-C052-T09 · Patch review:** Review the “Spaces and quoted paths” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M12.01-C052-T10 · Delivery handoff:** Publish the “Spaces and quoted paths” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M12.01-C053 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Launchers preserve paths and arguments correctly. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M12.01-C053-T01 · Named property:** Create a stable property/check name under this parent for “Spaces and quoted paths”; copy its required invariant exactly: “Launchers preserve paths and arguments correctly”.
- [ ] **UC-M12.01-C053-T02 · Observable terms:** Define each term in the “Spaces and quoted paths” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M12.01-C053-T03 · Precondition set:** List the preconditions under which “Launchers preserve paths and arguments correctly” must hold for “Spaces and quoted paths”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M12.01-C053-T04 · Transition coverage:** Map the “Spaces and quoted paths” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M12.01-C053-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Spaces and quoted paths”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M12.01-C053-T06 · Satisfying fixture:** Create a concrete “Spaces and quoted paths” case that satisfies “Launchers preserve paths and arguments correctly”; record its expected observation before running the assertion or review.
- [ ] **UC-M12.01-C053-T07 · Violating fixture:** Create the source counterexample “A quoted root is split into separate command arguments” for “Spaces and quoted paths”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M12.01-C053-T08 · Enforcement evidence:** Exercise the “Spaces and quoted paths” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M12.01-C053-T09 · Regression linkage:** Link the “Spaces and quoted paths” property to changes in native host runners, supplied launchers and machine-recorded build/verify results; record which dependency or contract changes require rerunning it.
- [ ] **UC-M12.01-C053-T10 · Property disposition:** Compare the satisfying and violating “Spaces and quoted paths” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M12.01-C054 · Integration

**Original checklist item:** Integrate spaces and quoted paths with native host runners, supplied launchers and machine-recorded build/verify results; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M12.01-C054-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Spaces and quoted paths” across native host runners, supplied launchers and machine-recorded build/verify results; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M12.01-C054-T02 · Field mapping:** Map every “Spaces and quoted paths” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M12.01-C054-T03 · Prerequisite identities:** Record the actual prerequisites for “Spaces and quoted paths” (source dependency list: UC-M03.08, UC-M04.01); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M12.01-C054-T04 · Ownership agreement:** Specify who owns “Spaces and quoted paths” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M12.01-C054-T05 · Handoff implementation:** Connect “Spaces and quoted paths” through the mapped seam using the real adapter or explicit specification reference; preserve “Launchers preserve paths and arguments correctly” across the handoff.
- [ ] **UC-M12.01-C054-T06 · Absent-input case:** Omit one required “Spaces and quoted paths” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M12.01-C054-T07 · Stale-input case:** Supply an outdated “Spaces and quoted paths” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M12.01-C054-T08 · Incompatible-input case:** Supply an incompatible “Spaces and quoted paths” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M12.01-C054-T09 · Valid integration trace:** Run a valid “Spaces and quoted paths” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M12.01-C054-T10 · Seam review:** Reconcile the “Spaces and quoted paths” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M12.01-C055 · Valid-case test

**Original checklist item:** Run a known-valid control for spaces and quoted paths; verify that the harness reaches its intended target and compare observed measurements or verdicts with predeclared expectations.

- [ ] **UC-M12.01-C055-T01 · Valid fixture choice:** Choose a known-valid control for “Spaces and quoted paths”; document why it should pass and how it proves the harness reaches the intended target.
- [ ] **UC-M12.01-C055-T02 · Expected-result oracle:** Specify the “Spaces and quoted paths” expected result independently of the implementation output; include the property “Launchers preserve paths and arguments correctly” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M12.01-C055-T03 · Fixture material:** Create the concrete “Spaces and quoted paths” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M12.01-C055-T04 · Target preparation:** Prepare the “Spaces and quoted paths” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M12.01-C055-T05 · Initial-state record:** Record the initial “Spaces and quoted paths” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M12.01-C055-T06 · Valid-path execution:** Run the “Spaces and quoted paths” known-valid control on the identified target; retain enough observations to prove the correct target was exercised.
- [ ] **UC-M12.01-C055-T07 · Outcome comparison:** Compare every declared “Spaces and quoted paths” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M12.01-C055-T08 · State and bounds check:** Inspect the “Spaces and quoted paths” ownership/state effects and actual use of “Path variants and argument bytes”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M12.01-C055-T09 · Repeatability check:** Repeat the same “Spaces and quoted paths” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M12.01-C055-T10 · Positive evidence:** Attach the “Spaces and quoted paths” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M12.01-C056 · Negative test

**Original checklist item:** Negative case: A quoted root is split into separate command arguments. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M12.01-C056-T01 · Adverse-case definition:** Create a test record for the exact “Spaces and quoted paths” source counterexample: “A quoted root is split into separate command arguments”; state which precondition or invariant it challenges.
- [ ] **UC-M12.01-C056-T02 · Safe fixture boundary:** Define the contained test boundary for “Spaces and quoted paths”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M12.01-C056-T03 · Valid control:** Construct a valid “Spaces and quoted paths” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M12.01-C056-T04 · Minimal adverse input:** Derive the “Spaces and quoted paths” adverse fixture from the control with the smallest documented change needed to reproduce “A quoted root is split into separate command arguments”; retain that change as reproducible data.
- [ ] **UC-M12.01-C056-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Spaces and quoted paths”; require “Launchers preserve paths and arguments correctly” and forbid a false-success verdict.
- [ ] **UC-M12.01-C056-T06 · Adverse execution:** Exercise the “Spaces and quoted paths” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M12.01-C056-T07 · Effect inspection:** Inspect “Spaces and quoted paths” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M12.01-C056-T08 · Refusal versus failure:** Confirm the “Spaces and quoted paths” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M12.01-C056-T09 · Reset and retention:** Restore only the disposable “Spaces and quoted paths” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M12.01-C056-T10 · Negative regression:** Register the “Spaces and quoted paths” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M12.01-C057 · Change / failure test

**Original checklist item:** Exercise spaces and quoted paths when a supported host lacks a toolchain or uses a spaced/long installation root; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M12.01-C057-T01 · Scenario record:** Write the “Spaces and quoted paths” change/failure scenario exactly as supplied: a supported host lacks a toolchain or uses a spaced/long installation root; identify the property that must remain true: “Launchers preserve paths and arguments correctly”.
- [ ] **UC-M12.01-C057-T02 · Baseline capture:** Create a known-valid “Spaces and quoted paths” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M12.01-C057-T03 · Injection map:** Locate the “Spaces and quoted paths” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M12.01-C057-T04 · Disposition oracle:** Define the legal intermediate and final “Spaces and quoted paths” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M12.01-C057-T05 · Controlled trigger:** Introduce the controlled “Spaces and quoted paths” scenario in the disposable fixture: a supported host lacks a toolchain or uses a spaced/long installation root; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M12.01-C057-T06 · Intermediate inspection:** Inspect the “Spaces and quoted paths” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M12.01-C057-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Spaces and quoted paths”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M12.01-C057-T08 · Stale-evidence cleanup:** Invalidate superseded “Spaces and quoted paths” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M12.01-C057-T09 · Repeat and compare:** Repeat the selected “Spaces and quoted paths” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M12.01-C057-T10 · Failure evidence:** Publish the “Spaces and quoted paths” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M12.01-C058 · Bounds

**Original checklist item:** Set a documented campaign budget for path variants and argument bytes; record actual consumption, incomplete coverage and the disposition when the budget is exhausted.

- [ ] **UC-M12.01-C058-T01 · Quantity inventory:** Create a measurement inventory for “Spaces and quoted paths”: “Path variants and argument bytes”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M12.01-C058-T02 · Measurement method:** Choose how to observe each “Spaces and quoted paths” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M12.01-C058-T03 · Budget decision:** Select justified campaign and target-resource budgets for “Spaces and quoted paths”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M12.01-C058-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Spaces and quoted paths” cases for “Path variants and argument bytes”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M12.01-C058-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Spaces and quoted paths” limit; preserve “Launchers preserve paths and arguments correctly”.
- [ ] **UC-M12.01-C058-T06 · Normal measurement:** Run or review the normal “Spaces and quoted paths” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M12.01-C058-T07 · At-limit measurement:** Exercise the “Spaces and quoted paths” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M12.01-C058-T08 · Over-limit measurement:** Exercise the “Spaces and quoted paths” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M12.01-C058-T09 · Uncovered-scope report:** List the “Spaces and quoted paths” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M12.01-C058-T10 · Limit evidence:** Publish the selected “Spaces and quoted paths” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M12.01-C059 · Diagnostics / review

**Original checklist item:** Report spaces and quoted paths results with executed, failed, skipped and unavailable cases separated; preserve the underlying observations and do not manufacture missing measurements.

- [ ] **UC-M12.01-C059-T01 · Result inventory:** Enumerate the required “Spaces and quoted paths” qualification cases and intended targets before aggregating results; keep the planned denominator visible.
- [ ] **UC-M12.01-C059-T02 · Verdict schema:** Define separate executed-pass, executed-fail, skipped, unavailable and untested outcomes for “Spaces and quoted paths”; document how incomplete cases block relevant claims.
- [ ] **UC-M12.01-C059-T03 · Identity fields:** Attach the actual target, fixture, configuration and revision identifiers to each “Spaces and quoted paths” result; do not attribute host-only evidence to a guest or another OS.
- [ ] **UC-M12.01-C059-T04 · Observation capture:** Capture bounded raw “Spaces and quoted paths” observations and harness errors; retain enough information to verify the reported oracle comparison.
- [ ] **UC-M12.01-C059-T05 · Aggregation rules:** Implement the “Spaces and quoted paths” count/reduction rule so failures and missing measurements cannot disappear; preserve “Launchers preserve paths and arguments correctly”.
- [ ] **UC-M12.01-C059-T06 · Failure visibility:** Feed a failing “Spaces and quoted paths” control through the report path; assert the exact failed case and underlying observation remain visible.
- [ ] **UC-M12.01-C059-T07 · Missing-result visibility:** Withhold a required “Spaces and quoted paths” measurement or target; verify the report uses unavailable/untested rather than a fabricated zero or passing value.
- [ ] **UC-M12.01-C059-T08 · Bounds and redaction:** Check “Spaces and quoted paths” report size and retention against “Path variants and argument bytes”; remove secrets while retaining fixture and subject references.
- [ ] **UC-M12.01-C059-T09 · Report reconciliation:** Reconcile the “Spaces and quoted paths” summary with every underlying case record; account for the full planned denominator and all omitted scope.
- [ ] **UC-M12.01-C059-T10 · Qualification handoff:** Publish the “Spaces and quoted paths” report with measured observations, coverage limits and blockers; state which actual targets remain unqualified.

### UC-M12.01-C060 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for spaces and quoted paths; label unexecuted checks as untested.

- [ ] **UC-M12.01-C060-T01 · Evidence inventory:** List the “Spaces and quoted paths” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M12.01-C060-T02 · Artifact references:** Record the exact “Spaces and quoted paths” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M12.01-C060-T03 · Fixture references:** Attach the “Spaces and quoted paths” fixture IDs, input identities and oracle definition; preserve the source counterexample “A quoted root is split into separate command arguments” as a distinct evidence case.
- [ ] **UC-M12.01-C060-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Spaces and quoted paths”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M12.01-C060-T05 · Environment record:** Record the actual “Spaces and quoted paths” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M12.01-C060-T06 · Expected versus observed:** Pair every “Spaces and quoted paths” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M12.01-C060-T07 · Failure and limit records:** Attach “Spaces and quoted paths” change/failure and bounds evidence where required; include uncovered “Path variants and argument bytes” and unresolved violations of “Launchers preserve paths and arguments correctly”.
- [ ] **UC-M12.01-C060-T08 · Evidence hygiene:** Check the “Spaces and quoted paths” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M12.01-C060-T09 · Reproduction review:** Have the “Spaces and quoted paths” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M12.01-C060-T10 · Acceptance linkage:** Link the “Spaces and quoted paths” evidence to its parent and UC-M12.01 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 07. Long-root handling

**Source delivery:** Test supported long-root behavior and explicit refusal beyond the declared path budget.

**Source invariant:** A path preflight failure cannot be mistaken for successful installation.

**Source negative case:** A deep extraction fails after partially overwriting user state.

**Source bounded quantities:** Path length and extracted members.

### UC-M12.01-C061 · Contract

**Original checklist item:** Define the qualification objective for long-root handling, including the actual target implementation, prerequisites, observable oracle and explicit exclusions.

- [ ] **UC-M12.01-C061-T01 · Scope statement:** Write the qualification question for “Long-root handling”; identify the actual target, claimed capability and observations that can answer that question.
- [ ] **UC-M12.01-C061-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Long-root handling”; record each producer, representation and missing-value meaning.
- [ ] **UC-M12.01-C061-T03 · Output inventory:** List the outputs of “Long-root handling” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M12.01-C061-T04 · Field dictionary:** Create a field-and-term dictionary for “Long-root handling”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M12.01-C061-T05 · Prerequisite contract:** Map “Long-root handling” to the source component prerequisites (UC-M03.08, UC-M04.01); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M12.01-C061-T06 · Authority map:** Identify who may produce, change and consume “Long-root handling”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M12.01-C061-T07 · Invariant clause:** Add a normative clause for “Long-root handling” that preserves “A path preflight failure cannot be mistaken for successful installation”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M12.01-C061-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Long-root handling”; include the source counterexample “A deep extraction fails after partially overwriting user state” and the intended safe disposition.
- [ ] **UC-M12.01-C061-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Path length and extracted members” in the “Long-root handling” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M12.01-C061-T10 · Contract review:** Review the “Long-root handling” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M12.01-C062 · Delivery

**Original checklist item:** Test supported long-root behavior and explicit refusal beyond the declared path budget.

- [ ] **UC-M12.01-C062-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Long-root handling”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M12.01-C062-T02 · Change plan:** Break the source delivery for “Long-root handling” into concrete edit targets and reviewable outputs; keep the UC-M12.01 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M12.01-C062-T03 · Core artifact:** Create the “Long-root handling” fixture or harness for this source instruction: Test supported long-root behavior and explicit refusal beyond the declared path budget.
- [ ] **UC-M12.01-C062-T04 · Concrete realization:** Connect the “Long-root handling” harness to its actual intended target, set the expected oracle before running it, and distinguish a mock/control run from a target run.
- [ ] **UC-M12.01-C062-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Long-root handling” needed to preserve “A path preflight failure cannot be mistaken for successful installation”; record an enforcement gap where only a model exists.
- [ ] **UC-M12.01-C062-T06 · Dependency connection:** Connect the “Long-root handling” qualification artifact to native host runners, supplied launchers and machine-recorded build/verify results; record the target identity and what the harness actually exercises.
- [ ] **UC-M12.01-C062-T07 · Resource behavior:** Account for “Path length and extracted members” in “Long-root handling”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M12.01-C062-T08 · Delivery check:** Run a known-valid control and a deliberately failing control for “Long-root handling”; confirm the harness distinguishes their observed outcomes.
- [ ] **UC-M12.01-C062-T09 · Patch review:** Review the “Long-root handling” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M12.01-C062-T10 · Delivery handoff:** Publish the “Long-root handling” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M12.01-C063 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: A path preflight failure cannot be mistaken for successful installation. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M12.01-C063-T01 · Named property:** Create a stable property/check name under this parent for “Long-root handling”; copy its required invariant exactly: “A path preflight failure cannot be mistaken for successful installation”.
- [ ] **UC-M12.01-C063-T02 · Observable terms:** Define each term in the “Long-root handling” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M12.01-C063-T03 · Precondition set:** List the preconditions under which “A path preflight failure cannot be mistaken for successful installation” must hold for “Long-root handling”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M12.01-C063-T04 · Transition coverage:** Map the “Long-root handling” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M12.01-C063-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Long-root handling”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M12.01-C063-T06 · Satisfying fixture:** Create a concrete “Long-root handling” case that satisfies “A path preflight failure cannot be mistaken for successful installation”; record its expected observation before running the assertion or review.
- [ ] **UC-M12.01-C063-T07 · Violating fixture:** Create the source counterexample “A deep extraction fails after partially overwriting user state” for “Long-root handling”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M12.01-C063-T08 · Enforcement evidence:** Exercise the “Long-root handling” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M12.01-C063-T09 · Regression linkage:** Link the “Long-root handling” property to changes in native host runners, supplied launchers and machine-recorded build/verify results; record which dependency or contract changes require rerunning it.
- [ ] **UC-M12.01-C063-T10 · Property disposition:** Compare the satisfying and violating “Long-root handling” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M12.01-C064 · Integration

**Original checklist item:** Integrate long-root handling with native host runners, supplied launchers and machine-recorded build/verify results; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M12.01-C064-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Long-root handling” across native host runners, supplied launchers and machine-recorded build/verify results; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M12.01-C064-T02 · Field mapping:** Map every “Long-root handling” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M12.01-C064-T03 · Prerequisite identities:** Record the actual prerequisites for “Long-root handling” (source dependency list: UC-M03.08, UC-M04.01); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M12.01-C064-T04 · Ownership agreement:** Specify who owns “Long-root handling” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M12.01-C064-T05 · Handoff implementation:** Connect “Long-root handling” through the mapped seam using the real adapter or explicit specification reference; preserve “A path preflight failure cannot be mistaken for successful installation” across the handoff.
- [ ] **UC-M12.01-C064-T06 · Absent-input case:** Omit one required “Long-root handling” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M12.01-C064-T07 · Stale-input case:** Supply an outdated “Long-root handling” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M12.01-C064-T08 · Incompatible-input case:** Supply an incompatible “Long-root handling” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M12.01-C064-T09 · Valid integration trace:** Run a valid “Long-root handling” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M12.01-C064-T10 · Seam review:** Reconcile the “Long-root handling” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M12.01-C065 · Valid-case test

**Original checklist item:** Run a known-valid control for long-root handling; verify that the harness reaches its intended target and compare observed measurements or verdicts with predeclared expectations.

- [ ] **UC-M12.01-C065-T01 · Valid fixture choice:** Choose a known-valid control for “Long-root handling”; document why it should pass and how it proves the harness reaches the intended target.
- [ ] **UC-M12.01-C065-T02 · Expected-result oracle:** Specify the “Long-root handling” expected result independently of the implementation output; include the property “A path preflight failure cannot be mistaken for successful installation” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M12.01-C065-T03 · Fixture material:** Create the concrete “Long-root handling” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M12.01-C065-T04 · Target preparation:** Prepare the “Long-root handling” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M12.01-C065-T05 · Initial-state record:** Record the initial “Long-root handling” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M12.01-C065-T06 · Valid-path execution:** Run the “Long-root handling” known-valid control on the identified target; retain enough observations to prove the correct target was exercised.
- [ ] **UC-M12.01-C065-T07 · Outcome comparison:** Compare every declared “Long-root handling” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M12.01-C065-T08 · State and bounds check:** Inspect the “Long-root handling” ownership/state effects and actual use of “Path length and extracted members”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M12.01-C065-T09 · Repeatability check:** Repeat the same “Long-root handling” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M12.01-C065-T10 · Positive evidence:** Attach the “Long-root handling” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M12.01-C066 · Negative test

**Original checklist item:** Negative case: A deep extraction fails after partially overwriting user state. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M12.01-C066-T01 · Adverse-case definition:** Create a test record for the exact “Long-root handling” source counterexample: “A deep extraction fails after partially overwriting user state”; state which precondition or invariant it challenges.
- [ ] **UC-M12.01-C066-T02 · Safe fixture boundary:** Define the contained test boundary for “Long-root handling”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M12.01-C066-T03 · Valid control:** Construct a valid “Long-root handling” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M12.01-C066-T04 · Minimal adverse input:** Derive the “Long-root handling” adverse fixture from the control with the smallest documented change needed to reproduce “A deep extraction fails after partially overwriting user state”; retain that change as reproducible data.
- [ ] **UC-M12.01-C066-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Long-root handling”; require “A path preflight failure cannot be mistaken for successful installation” and forbid a false-success verdict.
- [ ] **UC-M12.01-C066-T06 · Adverse execution:** Exercise the “Long-root handling” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M12.01-C066-T07 · Effect inspection:** Inspect “Long-root handling” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M12.01-C066-T08 · Refusal versus failure:** Confirm the “Long-root handling” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M12.01-C066-T09 · Reset and retention:** Restore only the disposable “Long-root handling” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M12.01-C066-T10 · Negative regression:** Register the “Long-root handling” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M12.01-C067 · Change / failure test

**Original checklist item:** Exercise long-root handling when a supported host lacks a toolchain or uses a spaced/long installation root; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M12.01-C067-T01 · Scenario record:** Write the “Long-root handling” change/failure scenario exactly as supplied: a supported host lacks a toolchain or uses a spaced/long installation root; identify the property that must remain true: “A path preflight failure cannot be mistaken for successful installation”.
- [ ] **UC-M12.01-C067-T02 · Baseline capture:** Create a known-valid “Long-root handling” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M12.01-C067-T03 · Injection map:** Locate the “Long-root handling” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M12.01-C067-T04 · Disposition oracle:** Define the legal intermediate and final “Long-root handling” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M12.01-C067-T05 · Controlled trigger:** Introduce the controlled “Long-root handling” scenario in the disposable fixture: a supported host lacks a toolchain or uses a spaced/long installation root; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M12.01-C067-T06 · Intermediate inspection:** Inspect the “Long-root handling” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M12.01-C067-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Long-root handling”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M12.01-C067-T08 · Stale-evidence cleanup:** Invalidate superseded “Long-root handling” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M12.01-C067-T09 · Repeat and compare:** Repeat the selected “Long-root handling” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M12.01-C067-T10 · Failure evidence:** Publish the “Long-root handling” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M12.01-C068 · Bounds

**Original checklist item:** Set a documented campaign budget for path length and extracted members; record actual consumption, incomplete coverage and the disposition when the budget is exhausted.

- [ ] **UC-M12.01-C068-T01 · Quantity inventory:** Create a measurement inventory for “Long-root handling”: “Path length and extracted members”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M12.01-C068-T02 · Measurement method:** Choose how to observe each “Long-root handling” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M12.01-C068-T03 · Budget decision:** Select justified campaign and target-resource budgets for “Long-root handling”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M12.01-C068-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Long-root handling” cases for “Path length and extracted members”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M12.01-C068-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Long-root handling” limit; preserve “A path preflight failure cannot be mistaken for successful installation”.
- [ ] **UC-M12.01-C068-T06 · Normal measurement:** Run or review the normal “Long-root handling” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M12.01-C068-T07 · At-limit measurement:** Exercise the “Long-root handling” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M12.01-C068-T08 · Over-limit measurement:** Exercise the “Long-root handling” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M12.01-C068-T09 · Uncovered-scope report:** List the “Long-root handling” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M12.01-C068-T10 · Limit evidence:** Publish the selected “Long-root handling” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M12.01-C069 · Diagnostics / review

**Original checklist item:** Report long-root handling results with executed, failed, skipped and unavailable cases separated; preserve the underlying observations and do not manufacture missing measurements.

- [ ] **UC-M12.01-C069-T01 · Result inventory:** Enumerate the required “Long-root handling” qualification cases and intended targets before aggregating results; keep the planned denominator visible.
- [ ] **UC-M12.01-C069-T02 · Verdict schema:** Define separate executed-pass, executed-fail, skipped, unavailable and untested outcomes for “Long-root handling”; document how incomplete cases block relevant claims.
- [ ] **UC-M12.01-C069-T03 · Identity fields:** Attach the actual target, fixture, configuration and revision identifiers to each “Long-root handling” result; do not attribute host-only evidence to a guest or another OS.
- [ ] **UC-M12.01-C069-T04 · Observation capture:** Capture bounded raw “Long-root handling” observations and harness errors; retain enough information to verify the reported oracle comparison.
- [ ] **UC-M12.01-C069-T05 · Aggregation rules:** Implement the “Long-root handling” count/reduction rule so failures and missing measurements cannot disappear; preserve “A path preflight failure cannot be mistaken for successful installation”.
- [ ] **UC-M12.01-C069-T06 · Failure visibility:** Feed a failing “Long-root handling” control through the report path; assert the exact failed case and underlying observation remain visible.
- [ ] **UC-M12.01-C069-T07 · Missing-result visibility:** Withhold a required “Long-root handling” measurement or target; verify the report uses unavailable/untested rather than a fabricated zero or passing value.
- [ ] **UC-M12.01-C069-T08 · Bounds and redaction:** Check “Long-root handling” report size and retention against “Path length and extracted members”; remove secrets while retaining fixture and subject references.
- [ ] **UC-M12.01-C069-T09 · Report reconciliation:** Reconcile the “Long-root handling” summary with every underlying case record; account for the full planned denominator and all omitted scope.
- [ ] **UC-M12.01-C069-T10 · Qualification handoff:** Publish the “Long-root handling” report with measured observations, coverage limits and blockers; state which actual targets remain unqualified.

### UC-M12.01-C070 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for long-root handling; label unexecuted checks as untested.

- [ ] **UC-M12.01-C070-T01 · Evidence inventory:** List the “Long-root handling” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M12.01-C070-T02 · Artifact references:** Record the exact “Long-root handling” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M12.01-C070-T03 · Fixture references:** Attach the “Long-root handling” fixture IDs, input identities and oracle definition; preserve the source counterexample “A deep extraction fails after partially overwriting user state” as a distinct evidence case.
- [ ] **UC-M12.01-C070-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Long-root handling”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M12.01-C070-T05 · Environment record:** Record the actual “Long-root handling” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M12.01-C070-T06 · Expected versus observed:** Pair every “Long-root handling” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M12.01-C070-T07 · Failure and limit records:** Attach “Long-root handling” change/failure and bounds evidence where required; include uncovered “Path length and extracted members” and unresolved violations of “A path preflight failure cannot be mistaken for successful installation”.
- [ ] **UC-M12.01-C070-T08 · Evidence hygiene:** Check the “Long-root handling” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M12.01-C070-T09 · Reproduction review:** Have the “Long-root handling” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M12.01-C070-T10 · Acceptance linkage:** Link the “Long-root handling” evidence to its parent and UC-M12.01 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 08. NTFS reparse-point cases

**Source delivery:** Exercise declared NTFS link and reparse-point handling on native Windows.

**Source invariant:** Windows path-security claims use actual Windows fixtures.

**Source negative case:** A junction redirects a cleanup operation outside its allowed root.

**Source bounded quantities:** Reparse fixtures and cleanup scope.

### UC-M12.01-C071 · Contract

**Original checklist item:** Define the qualification objective for NTFS reparse-point cases, including the actual target implementation, prerequisites, observable oracle and explicit exclusions.

- [ ] **UC-M12.01-C071-T01 · Scope statement:** Write the qualification question for “NTFS reparse-point cases”; identify the actual target, claimed capability and observations that can answer that question.
- [ ] **UC-M12.01-C071-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “NTFS reparse-point cases”; record each producer, representation and missing-value meaning.
- [ ] **UC-M12.01-C071-T03 · Output inventory:** List the outputs of “NTFS reparse-point cases” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M12.01-C071-T04 · Field dictionary:** Create a field-and-term dictionary for “NTFS reparse-point cases”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M12.01-C071-T05 · Prerequisite contract:** Map “NTFS reparse-point cases” to the source component prerequisites (UC-M03.08, UC-M04.01); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M12.01-C071-T06 · Authority map:** Identify who may produce, change and consume “NTFS reparse-point cases”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M12.01-C071-T07 · Invariant clause:** Add a normative clause for “NTFS reparse-point cases” that preserves “Windows path-security claims use actual Windows fixtures”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M12.01-C071-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “NTFS reparse-point cases”; include the source counterexample “A junction redirects a cleanup operation outside its allowed root” and the intended safe disposition.
- [ ] **UC-M12.01-C071-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Reparse fixtures and cleanup scope” in the “NTFS reparse-point cases” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M12.01-C071-T10 · Contract review:** Review the “NTFS reparse-point cases” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M12.01-C072 · Delivery

**Original checklist item:** Exercise declared NTFS link and reparse-point handling on native Windows.

- [ ] **UC-M12.01-C072-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “NTFS reparse-point cases”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M12.01-C072-T02 · Change plan:** Break the source delivery for “NTFS reparse-point cases” into concrete edit targets and reviewable outputs; keep the UC-M12.01 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M12.01-C072-T03 · Core artifact:** Create the “NTFS reparse-point cases” fixture or harness for this source instruction: Exercise declared NTFS link and reparse-point handling on native Windows.
- [ ] **UC-M12.01-C072-T04 · Concrete realization:** Connect the “NTFS reparse-point cases” harness to its actual intended target, set the expected oracle before running it, and distinguish a mock/control run from a target run.
- [ ] **UC-M12.01-C072-T05 · Invariant protection:** Add the actual guard, check or review criterion for “NTFS reparse-point cases” needed to preserve “Windows path-security claims use actual Windows fixtures”; record an enforcement gap where only a model exists.
- [ ] **UC-M12.01-C072-T06 · Dependency connection:** Connect the “NTFS reparse-point cases” qualification artifact to native host runners, supplied launchers and machine-recorded build/verify results; record the target identity and what the harness actually exercises.
- [ ] **UC-M12.01-C072-T07 · Resource behavior:** Account for “Reparse fixtures and cleanup scope” in “NTFS reparse-point cases”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M12.01-C072-T08 · Delivery check:** Run a known-valid control and a deliberately failing control for “NTFS reparse-point cases”; confirm the harness distinguishes their observed outcomes.
- [ ] **UC-M12.01-C072-T09 · Patch review:** Review the “NTFS reparse-point cases” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M12.01-C072-T10 · Delivery handoff:** Publish the “NTFS reparse-point cases” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M12.01-C073 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Windows path-security claims use actual Windows fixtures. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M12.01-C073-T01 · Named property:** Create a stable property/check name under this parent for “NTFS reparse-point cases”; copy its required invariant exactly: “Windows path-security claims use actual Windows fixtures”.
- [ ] **UC-M12.01-C073-T02 · Observable terms:** Define each term in the “NTFS reparse-point cases” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M12.01-C073-T03 · Precondition set:** List the preconditions under which “Windows path-security claims use actual Windows fixtures” must hold for “NTFS reparse-point cases”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M12.01-C073-T04 · Transition coverage:** Map the “NTFS reparse-point cases” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M12.01-C073-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “NTFS reparse-point cases”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M12.01-C073-T06 · Satisfying fixture:** Create a concrete “NTFS reparse-point cases” case that satisfies “Windows path-security claims use actual Windows fixtures”; record its expected observation before running the assertion or review.
- [ ] **UC-M12.01-C073-T07 · Violating fixture:** Create the source counterexample “A junction redirects a cleanup operation outside its allowed root” for “NTFS reparse-point cases”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M12.01-C073-T08 · Enforcement evidence:** Exercise the “NTFS reparse-point cases” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M12.01-C073-T09 · Regression linkage:** Link the “NTFS reparse-point cases” property to changes in native host runners, supplied launchers and machine-recorded build/verify results; record which dependency or contract changes require rerunning it.
- [ ] **UC-M12.01-C073-T10 · Property disposition:** Compare the satisfying and violating “NTFS reparse-point cases” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M12.01-C074 · Integration

**Original checklist item:** Integrate NTFS reparse-point cases with native host runners, supplied launchers and machine-recorded build/verify results; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M12.01-C074-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “NTFS reparse-point cases” across native host runners, supplied launchers and machine-recorded build/verify results; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M12.01-C074-T02 · Field mapping:** Map every “NTFS reparse-point cases” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M12.01-C074-T03 · Prerequisite identities:** Record the actual prerequisites for “NTFS reparse-point cases” (source dependency list: UC-M03.08, UC-M04.01); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M12.01-C074-T04 · Ownership agreement:** Specify who owns “NTFS reparse-point cases” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M12.01-C074-T05 · Handoff implementation:** Connect “NTFS reparse-point cases” through the mapped seam using the real adapter or explicit specification reference; preserve “Windows path-security claims use actual Windows fixtures” across the handoff.
- [ ] **UC-M12.01-C074-T06 · Absent-input case:** Omit one required “NTFS reparse-point cases” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M12.01-C074-T07 · Stale-input case:** Supply an outdated “NTFS reparse-point cases” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M12.01-C074-T08 · Incompatible-input case:** Supply an incompatible “NTFS reparse-point cases” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M12.01-C074-T09 · Valid integration trace:** Run a valid “NTFS reparse-point cases” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M12.01-C074-T10 · Seam review:** Reconcile the “NTFS reparse-point cases” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M12.01-C075 · Valid-case test

**Original checklist item:** Run a known-valid control for NTFS reparse-point cases; verify that the harness reaches its intended target and compare observed measurements or verdicts with predeclared expectations.

- [ ] **UC-M12.01-C075-T01 · Valid fixture choice:** Choose a known-valid control for “NTFS reparse-point cases”; document why it should pass and how it proves the harness reaches the intended target.
- [ ] **UC-M12.01-C075-T02 · Expected-result oracle:** Specify the “NTFS reparse-point cases” expected result independently of the implementation output; include the property “Windows path-security claims use actual Windows fixtures” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M12.01-C075-T03 · Fixture material:** Create the concrete “NTFS reparse-point cases” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M12.01-C075-T04 · Target preparation:** Prepare the “NTFS reparse-point cases” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M12.01-C075-T05 · Initial-state record:** Record the initial “NTFS reparse-point cases” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M12.01-C075-T06 · Valid-path execution:** Run the “NTFS reparse-point cases” known-valid control on the identified target; retain enough observations to prove the correct target was exercised.
- [ ] **UC-M12.01-C075-T07 · Outcome comparison:** Compare every declared “NTFS reparse-point cases” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M12.01-C075-T08 · State and bounds check:** Inspect the “NTFS reparse-point cases” ownership/state effects and actual use of “Reparse fixtures and cleanup scope”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M12.01-C075-T09 · Repeatability check:** Repeat the same “NTFS reparse-point cases” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M12.01-C075-T10 · Positive evidence:** Attach the “NTFS reparse-point cases” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M12.01-C076 · Negative test

**Original checklist item:** Negative case: A junction redirects a cleanup operation outside its allowed root. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M12.01-C076-T01 · Adverse-case definition:** Create a test record for the exact “NTFS reparse-point cases” source counterexample: “A junction redirects a cleanup operation outside its allowed root”; state which precondition or invariant it challenges.
- [ ] **UC-M12.01-C076-T02 · Safe fixture boundary:** Define the contained test boundary for “NTFS reparse-point cases”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M12.01-C076-T03 · Valid control:** Construct a valid “NTFS reparse-point cases” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M12.01-C076-T04 · Minimal adverse input:** Derive the “NTFS reparse-point cases” adverse fixture from the control with the smallest documented change needed to reproduce “A junction redirects a cleanup operation outside its allowed root”; retain that change as reproducible data.
- [ ] **UC-M12.01-C076-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “NTFS reparse-point cases”; require “Windows path-security claims use actual Windows fixtures” and forbid a false-success verdict.
- [ ] **UC-M12.01-C076-T06 · Adverse execution:** Exercise the “NTFS reparse-point cases” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M12.01-C076-T07 · Effect inspection:** Inspect “NTFS reparse-point cases” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M12.01-C076-T08 · Refusal versus failure:** Confirm the “NTFS reparse-point cases” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M12.01-C076-T09 · Reset and retention:** Restore only the disposable “NTFS reparse-point cases” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M12.01-C076-T10 · Negative regression:** Register the “NTFS reparse-point cases” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M12.01-C077 · Change / failure test

**Original checklist item:** Exercise NTFS reparse-point cases when a supported host lacks a toolchain or uses a spaced/long installation root; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M12.01-C077-T01 · Scenario record:** Write the “NTFS reparse-point cases” change/failure scenario exactly as supplied: a supported host lacks a toolchain or uses a spaced/long installation root; identify the property that must remain true: “Windows path-security claims use actual Windows fixtures”.
- [ ] **UC-M12.01-C077-T02 · Baseline capture:** Create a known-valid “NTFS reparse-point cases” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M12.01-C077-T03 · Injection map:** Locate the “NTFS reparse-point cases” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M12.01-C077-T04 · Disposition oracle:** Define the legal intermediate and final “NTFS reparse-point cases” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M12.01-C077-T05 · Controlled trigger:** Introduce the controlled “NTFS reparse-point cases” scenario in the disposable fixture: a supported host lacks a toolchain or uses a spaced/long installation root; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M12.01-C077-T06 · Intermediate inspection:** Inspect the “NTFS reparse-point cases” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M12.01-C077-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “NTFS reparse-point cases”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M12.01-C077-T08 · Stale-evidence cleanup:** Invalidate superseded “NTFS reparse-point cases” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M12.01-C077-T09 · Repeat and compare:** Repeat the selected “NTFS reparse-point cases” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M12.01-C077-T10 · Failure evidence:** Publish the “NTFS reparse-point cases” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M12.01-C078 · Bounds

**Original checklist item:** Set a documented campaign budget for reparse fixtures and cleanup scope; record actual consumption, incomplete coverage and the disposition when the budget is exhausted.

- [ ] **UC-M12.01-C078-T01 · Quantity inventory:** Create a measurement inventory for “NTFS reparse-point cases”: “Reparse fixtures and cleanup scope”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M12.01-C078-T02 · Measurement method:** Choose how to observe each “NTFS reparse-point cases” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M12.01-C078-T03 · Budget decision:** Select justified campaign and target-resource budgets for “NTFS reparse-point cases”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M12.01-C078-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “NTFS reparse-point cases” cases for “Reparse fixtures and cleanup scope”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M12.01-C078-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “NTFS reparse-point cases” limit; preserve “Windows path-security claims use actual Windows fixtures”.
- [ ] **UC-M12.01-C078-T06 · Normal measurement:** Run or review the normal “NTFS reparse-point cases” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M12.01-C078-T07 · At-limit measurement:** Exercise the “NTFS reparse-point cases” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M12.01-C078-T08 · Over-limit measurement:** Exercise the “NTFS reparse-point cases” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M12.01-C078-T09 · Uncovered-scope report:** List the “NTFS reparse-point cases” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M12.01-C078-T10 · Limit evidence:** Publish the selected “NTFS reparse-point cases” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M12.01-C079 · Diagnostics / review

**Original checklist item:** Report NTFS reparse-point cases results with executed, failed, skipped and unavailable cases separated; preserve the underlying observations and do not manufacture missing measurements.

- [ ] **UC-M12.01-C079-T01 · Result inventory:** Enumerate the required “NTFS reparse-point cases” qualification cases and intended targets before aggregating results; keep the planned denominator visible.
- [ ] **UC-M12.01-C079-T02 · Verdict schema:** Define separate executed-pass, executed-fail, skipped, unavailable and untested outcomes for “NTFS reparse-point cases”; document how incomplete cases block relevant claims.
- [ ] **UC-M12.01-C079-T03 · Identity fields:** Attach the actual target, fixture, configuration and revision identifiers to each “NTFS reparse-point cases” result; do not attribute host-only evidence to a guest or another OS.
- [ ] **UC-M12.01-C079-T04 · Observation capture:** Capture bounded raw “NTFS reparse-point cases” observations and harness errors; retain enough information to verify the reported oracle comparison.
- [ ] **UC-M12.01-C079-T05 · Aggregation rules:** Implement the “NTFS reparse-point cases” count/reduction rule so failures and missing measurements cannot disappear; preserve “Windows path-security claims use actual Windows fixtures”.
- [ ] **UC-M12.01-C079-T06 · Failure visibility:** Feed a failing “NTFS reparse-point cases” control through the report path; assert the exact failed case and underlying observation remain visible.
- [ ] **UC-M12.01-C079-T07 · Missing-result visibility:** Withhold a required “NTFS reparse-point cases” measurement or target; verify the report uses unavailable/untested rather than a fabricated zero or passing value.
- [ ] **UC-M12.01-C079-T08 · Bounds and redaction:** Check “NTFS reparse-point cases” report size and retention against “Reparse fixtures and cleanup scope”; remove secrets while retaining fixture and subject references.
- [ ] **UC-M12.01-C079-T09 · Report reconciliation:** Reconcile the “NTFS reparse-point cases” summary with every underlying case record; account for the full planned denominator and all omitted scope.
- [ ] **UC-M12.01-C079-T10 · Qualification handoff:** Publish the “NTFS reparse-point cases” report with measured observations, coverage limits and blockers; state which actual targets remain unqualified.

### UC-M12.01-C080 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for NTFS reparse-point cases; label unexecuted checks as untested.

- [ ] **UC-M12.01-C080-T01 · Evidence inventory:** List the “NTFS reparse-point cases” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M12.01-C080-T02 · Artifact references:** Record the exact “NTFS reparse-point cases” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M12.01-C080-T03 · Fixture references:** Attach the “NTFS reparse-point cases” fixture IDs, input identities and oracle definition; preserve the source counterexample “A junction redirects a cleanup operation outside its allowed root” as a distinct evidence case.
- [ ] **UC-M12.01-C080-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “NTFS reparse-point cases”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M12.01-C080-T05 · Environment record:** Record the actual “NTFS reparse-point cases” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M12.01-C080-T06 · Expected versus observed:** Pair every “NTFS reparse-point cases” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M12.01-C080-T07 · Failure and limit records:** Attach “NTFS reparse-point cases” change/failure and bounds evidence where required; include uncovered “Reparse fixtures and cleanup scope” and unresolved violations of “Windows path-security claims use actual Windows fixtures”.
- [ ] **UC-M12.01-C080-T08 · Evidence hygiene:** Check the “NTFS reparse-point cases” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M12.01-C080-T09 · Reproduction review:** Have the “NTFS reparse-point cases” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M12.01-C080-T10 · Acceptance linkage:** Link the “NTFS reparse-point cases” evidence to its parent and UC-M12.01 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 09. No-toolchain hosts

**Source delivery:** Run prerequisites and failure paths on hosts lacking the required native compiler.

**Source invariant:** Missing tools produce an explicit safe diagnostic rather than a flash-and-close success.

**Source negative case:** A launcher exits silently when no compiler exists.

**Source bounded quantities:** Missing prerequisite combinations and diagnostic size.

### UC-M12.01-C081 · Contract

**Original checklist item:** Define the qualification objective for no-toolchain hosts, including the actual target implementation, prerequisites, observable oracle and explicit exclusions.

- [ ] **UC-M12.01-C081-T01 · Scope statement:** Write the qualification question for “No-toolchain hosts”; identify the actual target, claimed capability and observations that can answer that question.
- [ ] **UC-M12.01-C081-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “No-toolchain hosts”; record each producer, representation and missing-value meaning.
- [ ] **UC-M12.01-C081-T03 · Output inventory:** List the outputs of “No-toolchain hosts” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M12.01-C081-T04 · Field dictionary:** Create a field-and-term dictionary for “No-toolchain hosts”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M12.01-C081-T05 · Prerequisite contract:** Map “No-toolchain hosts” to the source component prerequisites (UC-M03.08, UC-M04.01); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M12.01-C081-T06 · Authority map:** Identify who may produce, change and consume “No-toolchain hosts”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M12.01-C081-T07 · Invariant clause:** Add a normative clause for “No-toolchain hosts” that preserves “Missing tools produce an explicit safe diagnostic rather than a flash-and-close success”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M12.01-C081-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “No-toolchain hosts”; include the source counterexample “A launcher exits silently when no compiler exists” and the intended safe disposition.
- [ ] **UC-M12.01-C081-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Missing prerequisite combinations and diagnostic size” in the “No-toolchain hosts” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M12.01-C081-T10 · Contract review:** Review the “No-toolchain hosts” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M12.01-C082 · Delivery

**Original checklist item:** Run prerequisites and failure paths on hosts lacking the required native compiler.

- [ ] **UC-M12.01-C082-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “No-toolchain hosts”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M12.01-C082-T02 · Change plan:** Break the source delivery for “No-toolchain hosts” into concrete edit targets and reviewable outputs; keep the UC-M12.01 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M12.01-C082-T03 · Core artifact:** Create the “No-toolchain hosts” fixture or harness for this source instruction: Run prerequisites and failure paths on hosts lacking the required native compiler.
- [ ] **UC-M12.01-C082-T04 · Concrete realization:** Connect the “No-toolchain hosts” harness to its actual intended target, set the expected oracle before running it, and distinguish a mock/control run from a target run.
- [ ] **UC-M12.01-C082-T05 · Invariant protection:** Add the actual guard, check or review criterion for “No-toolchain hosts” needed to preserve “Missing tools produce an explicit safe diagnostic rather than a flash-and-close success”; record an enforcement gap where only a model exists.
- [ ] **UC-M12.01-C082-T06 · Dependency connection:** Connect the “No-toolchain hosts” qualification artifact to native host runners, supplied launchers and machine-recorded build/verify results; record the target identity and what the harness actually exercises.
- [ ] **UC-M12.01-C082-T07 · Resource behavior:** Account for “Missing prerequisite combinations and diagnostic size” in “No-toolchain hosts”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M12.01-C082-T08 · Delivery check:** Run a known-valid control and a deliberately failing control for “No-toolchain hosts”; confirm the harness distinguishes their observed outcomes.
- [ ] **UC-M12.01-C082-T09 · Patch review:** Review the “No-toolchain hosts” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M12.01-C082-T10 · Delivery handoff:** Publish the “No-toolchain hosts” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M12.01-C083 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Missing tools produce an explicit safe diagnostic rather than a flash-and-close success. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M12.01-C083-T01 · Named property:** Create a stable property/check name under this parent for “No-toolchain hosts”; copy its required invariant exactly: “Missing tools produce an explicit safe diagnostic rather than a flash-and-close success”.
- [ ] **UC-M12.01-C083-T02 · Observable terms:** Define each term in the “No-toolchain hosts” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M12.01-C083-T03 · Precondition set:** List the preconditions under which “Missing tools produce an explicit safe diagnostic rather than a flash-and-close success” must hold for “No-toolchain hosts”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M12.01-C083-T04 · Transition coverage:** Map the “No-toolchain hosts” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M12.01-C083-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “No-toolchain hosts”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M12.01-C083-T06 · Satisfying fixture:** Create a concrete “No-toolchain hosts” case that satisfies “Missing tools produce an explicit safe diagnostic rather than a flash-and-close success”; record its expected observation before running the assertion or review.
- [ ] **UC-M12.01-C083-T07 · Violating fixture:** Create the source counterexample “A launcher exits silently when no compiler exists” for “No-toolchain hosts”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M12.01-C083-T08 · Enforcement evidence:** Exercise the “No-toolchain hosts” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M12.01-C083-T09 · Regression linkage:** Link the “No-toolchain hosts” property to changes in native host runners, supplied launchers and machine-recorded build/verify results; record which dependency or contract changes require rerunning it.
- [ ] **UC-M12.01-C083-T10 · Property disposition:** Compare the satisfying and violating “No-toolchain hosts” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M12.01-C084 · Integration

**Original checklist item:** Integrate no-toolchain hosts with native host runners, supplied launchers and machine-recorded build/verify results; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M12.01-C084-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “No-toolchain hosts” across native host runners, supplied launchers and machine-recorded build/verify results; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M12.01-C084-T02 · Field mapping:** Map every “No-toolchain hosts” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M12.01-C084-T03 · Prerequisite identities:** Record the actual prerequisites for “No-toolchain hosts” (source dependency list: UC-M03.08, UC-M04.01); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M12.01-C084-T04 · Ownership agreement:** Specify who owns “No-toolchain hosts” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M12.01-C084-T05 · Handoff implementation:** Connect “No-toolchain hosts” through the mapped seam using the real adapter or explicit specification reference; preserve “Missing tools produce an explicit safe diagnostic rather than a flash-and-close success” across the handoff.
- [ ] **UC-M12.01-C084-T06 · Absent-input case:** Omit one required “No-toolchain hosts” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M12.01-C084-T07 · Stale-input case:** Supply an outdated “No-toolchain hosts” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M12.01-C084-T08 · Incompatible-input case:** Supply an incompatible “No-toolchain hosts” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M12.01-C084-T09 · Valid integration trace:** Run a valid “No-toolchain hosts” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M12.01-C084-T10 · Seam review:** Reconcile the “No-toolchain hosts” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M12.01-C085 · Valid-case test

**Original checklist item:** Run a known-valid control for no-toolchain hosts; verify that the harness reaches its intended target and compare observed measurements or verdicts with predeclared expectations.

- [ ] **UC-M12.01-C085-T01 · Valid fixture choice:** Choose a known-valid control for “No-toolchain hosts”; document why it should pass and how it proves the harness reaches the intended target.
- [ ] **UC-M12.01-C085-T02 · Expected-result oracle:** Specify the “No-toolchain hosts” expected result independently of the implementation output; include the property “Missing tools produce an explicit safe diagnostic rather than a flash-and-close success” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M12.01-C085-T03 · Fixture material:** Create the concrete “No-toolchain hosts” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M12.01-C085-T04 · Target preparation:** Prepare the “No-toolchain hosts” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M12.01-C085-T05 · Initial-state record:** Record the initial “No-toolchain hosts” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M12.01-C085-T06 · Valid-path execution:** Run the “No-toolchain hosts” known-valid control on the identified target; retain enough observations to prove the correct target was exercised.
- [ ] **UC-M12.01-C085-T07 · Outcome comparison:** Compare every declared “No-toolchain hosts” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M12.01-C085-T08 · State and bounds check:** Inspect the “No-toolchain hosts” ownership/state effects and actual use of “Missing prerequisite combinations and diagnostic size”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M12.01-C085-T09 · Repeatability check:** Repeat the same “No-toolchain hosts” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M12.01-C085-T10 · Positive evidence:** Attach the “No-toolchain hosts” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M12.01-C086 · Negative test

**Original checklist item:** Negative case: A launcher exits silently when no compiler exists. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M12.01-C086-T01 · Adverse-case definition:** Create a test record for the exact “No-toolchain hosts” source counterexample: “A launcher exits silently when no compiler exists”; state which precondition or invariant it challenges.
- [ ] **UC-M12.01-C086-T02 · Safe fixture boundary:** Define the contained test boundary for “No-toolchain hosts”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M12.01-C086-T03 · Valid control:** Construct a valid “No-toolchain hosts” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M12.01-C086-T04 · Minimal adverse input:** Derive the “No-toolchain hosts” adverse fixture from the control with the smallest documented change needed to reproduce “A launcher exits silently when no compiler exists”; retain that change as reproducible data.
- [ ] **UC-M12.01-C086-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “No-toolchain hosts”; require “Missing tools produce an explicit safe diagnostic rather than a flash-and-close success” and forbid a false-success verdict.
- [ ] **UC-M12.01-C086-T06 · Adverse execution:** Exercise the “No-toolchain hosts” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M12.01-C086-T07 · Effect inspection:** Inspect “No-toolchain hosts” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M12.01-C086-T08 · Refusal versus failure:** Confirm the “No-toolchain hosts” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M12.01-C086-T09 · Reset and retention:** Restore only the disposable “No-toolchain hosts” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M12.01-C086-T10 · Negative regression:** Register the “No-toolchain hosts” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M12.01-C087 · Change / failure test

**Original checklist item:** Exercise no-toolchain hosts when a supported host lacks a toolchain or uses a spaced/long installation root; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M12.01-C087-T01 · Scenario record:** Write the “No-toolchain hosts” change/failure scenario exactly as supplied: a supported host lacks a toolchain or uses a spaced/long installation root; identify the property that must remain true: “Missing tools produce an explicit safe diagnostic rather than a flash-and-close success”.
- [ ] **UC-M12.01-C087-T02 · Baseline capture:** Create a known-valid “No-toolchain hosts” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M12.01-C087-T03 · Injection map:** Locate the “No-toolchain hosts” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M12.01-C087-T04 · Disposition oracle:** Define the legal intermediate and final “No-toolchain hosts” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M12.01-C087-T05 · Controlled trigger:** Introduce the controlled “No-toolchain hosts” scenario in the disposable fixture: a supported host lacks a toolchain or uses a spaced/long installation root; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M12.01-C087-T06 · Intermediate inspection:** Inspect the “No-toolchain hosts” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M12.01-C087-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “No-toolchain hosts”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M12.01-C087-T08 · Stale-evidence cleanup:** Invalidate superseded “No-toolchain hosts” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M12.01-C087-T09 · Repeat and compare:** Repeat the selected “No-toolchain hosts” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M12.01-C087-T10 · Failure evidence:** Publish the “No-toolchain hosts” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M12.01-C088 · Bounds

**Original checklist item:** Set a documented campaign budget for missing prerequisite combinations and diagnostic size; record actual consumption, incomplete coverage and the disposition when the budget is exhausted.

- [ ] **UC-M12.01-C088-T01 · Quantity inventory:** Create a measurement inventory for “No-toolchain hosts”: “Missing prerequisite combinations and diagnostic size”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M12.01-C088-T02 · Measurement method:** Choose how to observe each “No-toolchain hosts” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M12.01-C088-T03 · Budget decision:** Select justified campaign and target-resource budgets for “No-toolchain hosts”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M12.01-C088-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “No-toolchain hosts” cases for “Missing prerequisite combinations and diagnostic size”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M12.01-C088-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “No-toolchain hosts” limit; preserve “Missing tools produce an explicit safe diagnostic rather than a flash-and-close success”.
- [ ] **UC-M12.01-C088-T06 · Normal measurement:** Run or review the normal “No-toolchain hosts” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M12.01-C088-T07 · At-limit measurement:** Exercise the “No-toolchain hosts” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M12.01-C088-T08 · Over-limit measurement:** Exercise the “No-toolchain hosts” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M12.01-C088-T09 · Uncovered-scope report:** List the “No-toolchain hosts” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M12.01-C088-T10 · Limit evidence:** Publish the selected “No-toolchain hosts” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M12.01-C089 · Diagnostics / review

**Original checklist item:** Report no-toolchain hosts results with executed, failed, skipped and unavailable cases separated; preserve the underlying observations and do not manufacture missing measurements.

- [ ] **UC-M12.01-C089-T01 · Result inventory:** Enumerate the required “No-toolchain hosts” qualification cases and intended targets before aggregating results; keep the planned denominator visible.
- [ ] **UC-M12.01-C089-T02 · Verdict schema:** Define separate executed-pass, executed-fail, skipped, unavailable and untested outcomes for “No-toolchain hosts”; document how incomplete cases block relevant claims.
- [ ] **UC-M12.01-C089-T03 · Identity fields:** Attach the actual target, fixture, configuration and revision identifiers to each “No-toolchain hosts” result; do not attribute host-only evidence to a guest or another OS.
- [ ] **UC-M12.01-C089-T04 · Observation capture:** Capture bounded raw “No-toolchain hosts” observations and harness errors; retain enough information to verify the reported oracle comparison.
- [ ] **UC-M12.01-C089-T05 · Aggregation rules:** Implement the “No-toolchain hosts” count/reduction rule so failures and missing measurements cannot disappear; preserve “Missing tools produce an explicit safe diagnostic rather than a flash-and-close success”.
- [ ] **UC-M12.01-C089-T06 · Failure visibility:** Feed a failing “No-toolchain hosts” control through the report path; assert the exact failed case and underlying observation remain visible.
- [ ] **UC-M12.01-C089-T07 · Missing-result visibility:** Withhold a required “No-toolchain hosts” measurement or target; verify the report uses unavailable/untested rather than a fabricated zero or passing value.
- [ ] **UC-M12.01-C089-T08 · Bounds and redaction:** Check “No-toolchain hosts” report size and retention against “Missing prerequisite combinations and diagnostic size”; remove secrets while retaining fixture and subject references.
- [ ] **UC-M12.01-C089-T09 · Report reconciliation:** Reconcile the “No-toolchain hosts” summary with every underlying case record; account for the full planned denominator and all omitted scope.
- [ ] **UC-M12.01-C089-T10 · Qualification handoff:** Publish the “No-toolchain hosts” report with measured observations, coverage limits and blockers; state which actual targets remain unqualified.

### UC-M12.01-C090 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for no-toolchain hosts; label unexecuted checks as untested.

- [ ] **UC-M12.01-C090-T01 · Evidence inventory:** List the “No-toolchain hosts” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M12.01-C090-T02 · Artifact references:** Record the exact “No-toolchain hosts” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M12.01-C090-T03 · Fixture references:** Attach the “No-toolchain hosts” fixture IDs, input identities and oracle definition; preserve the source counterexample “A launcher exits silently when no compiler exists” as a distinct evidence case.
- [ ] **UC-M12.01-C090-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “No-toolchain hosts”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M12.01-C090-T05 · Environment record:** Record the actual “No-toolchain hosts” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M12.01-C090-T06 · Expected versus observed:** Pair every “No-toolchain hosts” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M12.01-C090-T07 · Failure and limit records:** Attach “No-toolchain hosts” change/failure and bounds evidence where required; include uncovered “Missing prerequisite combinations and diagnostic size” and unresolved violations of “Missing tools produce an explicit safe diagnostic rather than a flash-and-close success”.
- [ ] **UC-M12.01-C090-T08 · Evidence hygiene:** Check the “No-toolchain hosts” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M12.01-C090-T09 · Reproduction review:** Have the “No-toolchain hosts” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M12.01-C090-T10 · Acceptance linkage:** Link the “No-toolchain hosts” evidence to its parent and UC-M12.01 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 10. Platform evidence matrix

**Source delivery:** Publish machine-recorded launch, build and verify results with skips and failures visible.

**Source invariant:** Every claimed platform has its own observed evidence.

**Source negative case:** One Linux pass is copied into Windows and macOS columns.

**Source bounded quantities:** Matrix entries and retained evidence bytes.

### UC-M12.01-C091 · Contract

**Original checklist item:** Define the qualification objective for platform evidence matrix, including the actual target implementation, prerequisites, observable oracle and explicit exclusions.

- [ ] **UC-M12.01-C091-T01 · Scope statement:** Write the qualification question for “Platform evidence matrix”; identify the actual target, claimed capability and observations that can answer that question.
- [ ] **UC-M12.01-C091-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Platform evidence matrix”; record each producer, representation and missing-value meaning.
- [ ] **UC-M12.01-C091-T03 · Output inventory:** List the outputs of “Platform evidence matrix” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M12.01-C091-T04 · Field dictionary:** Create a field-and-term dictionary for “Platform evidence matrix”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M12.01-C091-T05 · Prerequisite contract:** Map “Platform evidence matrix” to the source component prerequisites (UC-M03.08, UC-M04.01); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M12.01-C091-T06 · Authority map:** Identify who may produce, change and consume “Platform evidence matrix”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M12.01-C091-T07 · Invariant clause:** Add a normative clause for “Platform evidence matrix” that preserves “Every claimed platform has its own observed evidence”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M12.01-C091-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Platform evidence matrix”; include the source counterexample “One Linux pass is copied into Windows and macOS columns” and the intended safe disposition.
- [ ] **UC-M12.01-C091-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Matrix entries and retained evidence bytes” in the “Platform evidence matrix” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M12.01-C091-T10 · Contract review:** Review the “Platform evidence matrix” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M12.01-C092 · Delivery

**Original checklist item:** Publish machine-recorded launch, build and verify results with skips and failures visible.

- [ ] **UC-M12.01-C092-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Platform evidence matrix”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M12.01-C092-T02 · Change plan:** Break the source delivery for “Platform evidence matrix” into concrete edit targets and reviewable outputs; keep the UC-M12.01 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M12.01-C092-T03 · Core artifact:** Create the “Platform evidence matrix” output artifact for this source instruction: Publish machine-recorded launch, build and verify results with skips and failures visible.
- [ ] **UC-M12.01-C092-T04 · Concrete realization:** Populate the “Platform evidence matrix” artifact from identified observations; keep unknown, failed and unexecuted results distinct and exclude unapproved sensitive material.
- [ ] **UC-M12.01-C092-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Platform evidence matrix” needed to preserve “Every claimed platform has its own observed evidence”; record an enforcement gap where only a model exists.
- [ ] **UC-M12.01-C092-T06 · Dependency connection:** Connect the “Platform evidence matrix” qualification artifact to native host runners, supplied launchers and machine-recorded build/verify results; record the target identity and what the harness actually exercises.
- [ ] **UC-M12.01-C092-T07 · Resource behavior:** Account for “Matrix entries and retained evidence bytes” in “Platform evidence matrix”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M12.01-C092-T08 · Delivery check:** Run a known-valid control and a deliberately failing control for “Platform evidence matrix”; confirm the harness distinguishes their observed outcomes.
- [ ] **UC-M12.01-C092-T09 · Patch review:** Review the “Platform evidence matrix” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M12.01-C092-T10 · Delivery handoff:** Publish the “Platform evidence matrix” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M12.01-C093 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Every claimed platform has its own observed evidence. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M12.01-C093-T01 · Named property:** Create a stable property/check name under this parent for “Platform evidence matrix”; copy its required invariant exactly: “Every claimed platform has its own observed evidence”.
- [ ] **UC-M12.01-C093-T02 · Observable terms:** Define each term in the “Platform evidence matrix” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M12.01-C093-T03 · Precondition set:** List the preconditions under which “Every claimed platform has its own observed evidence” must hold for “Platform evidence matrix”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M12.01-C093-T04 · Transition coverage:** Map the “Platform evidence matrix” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M12.01-C093-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Platform evidence matrix”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M12.01-C093-T06 · Satisfying fixture:** Create a concrete “Platform evidence matrix” case that satisfies “Every claimed platform has its own observed evidence”; record its expected observation before running the assertion or review.
- [ ] **UC-M12.01-C093-T07 · Violating fixture:** Create the source counterexample “One Linux pass is copied into Windows and macOS columns” for “Platform evidence matrix”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M12.01-C093-T08 · Enforcement evidence:** Exercise the “Platform evidence matrix” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M12.01-C093-T09 · Regression linkage:** Link the “Platform evidence matrix” property to changes in native host runners, supplied launchers and machine-recorded build/verify results; record which dependency or contract changes require rerunning it.
- [ ] **UC-M12.01-C093-T10 · Property disposition:** Compare the satisfying and violating “Platform evidence matrix” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M12.01-C094 · Integration

**Original checklist item:** Integrate platform evidence matrix with native host runners, supplied launchers and machine-recorded build/verify results; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M12.01-C094-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Platform evidence matrix” across native host runners, supplied launchers and machine-recorded build/verify results; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M12.01-C094-T02 · Field mapping:** Map every “Platform evidence matrix” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M12.01-C094-T03 · Prerequisite identities:** Record the actual prerequisites for “Platform evidence matrix” (source dependency list: UC-M03.08, UC-M04.01); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M12.01-C094-T04 · Ownership agreement:** Specify who owns “Platform evidence matrix” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M12.01-C094-T05 · Handoff implementation:** Connect “Platform evidence matrix” through the mapped seam using the real adapter or explicit specification reference; preserve “Every claimed platform has its own observed evidence” across the handoff.
- [ ] **UC-M12.01-C094-T06 · Absent-input case:** Omit one required “Platform evidence matrix” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M12.01-C094-T07 · Stale-input case:** Supply an outdated “Platform evidence matrix” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M12.01-C094-T08 · Incompatible-input case:** Supply an incompatible “Platform evidence matrix” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M12.01-C094-T09 · Valid integration trace:** Run a valid “Platform evidence matrix” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M12.01-C094-T10 · Seam review:** Reconcile the “Platform evidence matrix” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M12.01-C095 · Valid-case test

**Original checklist item:** Run a known-valid control for platform evidence matrix; verify that the harness reaches its intended target and compare observed measurements or verdicts with predeclared expectations.

- [ ] **UC-M12.01-C095-T01 · Valid fixture choice:** Choose a known-valid control for “Platform evidence matrix”; document why it should pass and how it proves the harness reaches the intended target.
- [ ] **UC-M12.01-C095-T02 · Expected-result oracle:** Specify the “Platform evidence matrix” expected result independently of the implementation output; include the property “Every claimed platform has its own observed evidence” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M12.01-C095-T03 · Fixture material:** Create the concrete “Platform evidence matrix” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M12.01-C095-T04 · Target preparation:** Prepare the “Platform evidence matrix” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M12.01-C095-T05 · Initial-state record:** Record the initial “Platform evidence matrix” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M12.01-C095-T06 · Valid-path execution:** Run the “Platform evidence matrix” known-valid control on the identified target; retain enough observations to prove the correct target was exercised.
- [ ] **UC-M12.01-C095-T07 · Outcome comparison:** Compare every declared “Platform evidence matrix” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M12.01-C095-T08 · State and bounds check:** Inspect the “Platform evidence matrix” ownership/state effects and actual use of “Matrix entries and retained evidence bytes”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M12.01-C095-T09 · Repeatability check:** Repeat the same “Platform evidence matrix” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M12.01-C095-T10 · Positive evidence:** Attach the “Platform evidence matrix” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M12.01-C096 · Negative test

**Original checklist item:** Negative case: One Linux pass is copied into Windows and macOS columns. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M12.01-C096-T01 · Adverse-case definition:** Create a test record for the exact “Platform evidence matrix” source counterexample: “One Linux pass is copied into Windows and macOS columns”; state which precondition or invariant it challenges.
- [ ] **UC-M12.01-C096-T02 · Safe fixture boundary:** Define the contained test boundary for “Platform evidence matrix”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M12.01-C096-T03 · Valid control:** Construct a valid “Platform evidence matrix” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M12.01-C096-T04 · Minimal adverse input:** Derive the “Platform evidence matrix” adverse fixture from the control with the smallest documented change needed to reproduce “One Linux pass is copied into Windows and macOS columns”; retain that change as reproducible data.
- [ ] **UC-M12.01-C096-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Platform evidence matrix”; require “Every claimed platform has its own observed evidence” and forbid a false-success verdict.
- [ ] **UC-M12.01-C096-T06 · Adverse execution:** Exercise the “Platform evidence matrix” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M12.01-C096-T07 · Effect inspection:** Inspect “Platform evidence matrix” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M12.01-C096-T08 · Refusal versus failure:** Confirm the “Platform evidence matrix” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M12.01-C096-T09 · Reset and retention:** Restore only the disposable “Platform evidence matrix” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M12.01-C096-T10 · Negative regression:** Register the “Platform evidence matrix” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M12.01-C097 · Change / failure test

**Original checklist item:** Exercise platform evidence matrix when a supported host lacks a toolchain or uses a spaced/long installation root; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M12.01-C097-T01 · Scenario record:** Write the “Platform evidence matrix” change/failure scenario exactly as supplied: a supported host lacks a toolchain or uses a spaced/long installation root; identify the property that must remain true: “Every claimed platform has its own observed evidence”.
- [ ] **UC-M12.01-C097-T02 · Baseline capture:** Create a known-valid “Platform evidence matrix” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M12.01-C097-T03 · Injection map:** Locate the “Platform evidence matrix” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M12.01-C097-T04 · Disposition oracle:** Define the legal intermediate and final “Platform evidence matrix” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M12.01-C097-T05 · Controlled trigger:** Introduce the controlled “Platform evidence matrix” scenario in the disposable fixture: a supported host lacks a toolchain or uses a spaced/long installation root; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M12.01-C097-T06 · Intermediate inspection:** Inspect the “Platform evidence matrix” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M12.01-C097-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Platform evidence matrix”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M12.01-C097-T08 · Stale-evidence cleanup:** Invalidate superseded “Platform evidence matrix” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M12.01-C097-T09 · Repeat and compare:** Repeat the selected “Platform evidence matrix” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M12.01-C097-T10 · Failure evidence:** Publish the “Platform evidence matrix” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M12.01-C098 · Bounds

**Original checklist item:** Set a documented campaign budget for matrix entries and retained evidence bytes; record actual consumption, incomplete coverage and the disposition when the budget is exhausted.

- [ ] **UC-M12.01-C098-T01 · Quantity inventory:** Create a measurement inventory for “Platform evidence matrix”: “Matrix entries and retained evidence bytes”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M12.01-C098-T02 · Measurement method:** Choose how to observe each “Platform evidence matrix” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M12.01-C098-T03 · Budget decision:** Select justified campaign and target-resource budgets for “Platform evidence matrix”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M12.01-C098-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Platform evidence matrix” cases for “Matrix entries and retained evidence bytes”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M12.01-C098-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Platform evidence matrix” limit; preserve “Every claimed platform has its own observed evidence”.
- [ ] **UC-M12.01-C098-T06 · Normal measurement:** Run or review the normal “Platform evidence matrix” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M12.01-C098-T07 · At-limit measurement:** Exercise the “Platform evidence matrix” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M12.01-C098-T08 · Over-limit measurement:** Exercise the “Platform evidence matrix” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M12.01-C098-T09 · Uncovered-scope report:** List the “Platform evidence matrix” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M12.01-C098-T10 · Limit evidence:** Publish the selected “Platform evidence matrix” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M12.01-C099 · Diagnostics / review

**Original checklist item:** Report platform evidence matrix results with executed, failed, skipped and unavailable cases separated; preserve the underlying observations and do not manufacture missing measurements.

- [ ] **UC-M12.01-C099-T01 · Result inventory:** Enumerate the required “Platform evidence matrix” qualification cases and intended targets before aggregating results; keep the planned denominator visible.
- [ ] **UC-M12.01-C099-T02 · Verdict schema:** Define separate executed-pass, executed-fail, skipped, unavailable and untested outcomes for “Platform evidence matrix”; document how incomplete cases block relevant claims.
- [ ] **UC-M12.01-C099-T03 · Identity fields:** Attach the actual target, fixture, configuration and revision identifiers to each “Platform evidence matrix” result; do not attribute host-only evidence to a guest or another OS.
- [ ] **UC-M12.01-C099-T04 · Observation capture:** Capture bounded raw “Platform evidence matrix” observations and harness errors; retain enough information to verify the reported oracle comparison.
- [ ] **UC-M12.01-C099-T05 · Aggregation rules:** Implement the “Platform evidence matrix” count/reduction rule so failures and missing measurements cannot disappear; preserve “Every claimed platform has its own observed evidence”.
- [ ] **UC-M12.01-C099-T06 · Failure visibility:** Feed a failing “Platform evidence matrix” control through the report path; assert the exact failed case and underlying observation remain visible.
- [ ] **UC-M12.01-C099-T07 · Missing-result visibility:** Withhold a required “Platform evidence matrix” measurement or target; verify the report uses unavailable/untested rather than a fabricated zero or passing value.
- [ ] **UC-M12.01-C099-T08 · Bounds and redaction:** Check “Platform evidence matrix” report size and retention against “Matrix entries and retained evidence bytes”; remove secrets while retaining fixture and subject references.
- [ ] **UC-M12.01-C099-T09 · Report reconciliation:** Reconcile the “Platform evidence matrix” summary with every underlying case record; account for the full planned denominator and all omitted scope.
- [ ] **UC-M12.01-C099-T10 · Qualification handoff:** Publish the “Platform evidence matrix” report with measured observations, coverage limits and blockers; state which actual targets remain unqualified.

### UC-M12.01-C100 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for platform evidence matrix; label unexecuted checks as untested.

- [ ] **UC-M12.01-C100-T01 · Evidence inventory:** List the “Platform evidence matrix” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M12.01-C100-T02 · Artifact references:** Record the exact “Platform evidence matrix” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M12.01-C100-T03 · Fixture references:** Attach the “Platform evidence matrix” fixture IDs, input identities and oracle definition; preserve the source counterexample “One Linux pass is copied into Windows and macOS columns” as a distinct evidence case.
- [ ] **UC-M12.01-C100-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Platform evidence matrix”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M12.01-C100-T05 · Environment record:** Record the actual “Platform evidence matrix” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M12.01-C100-T06 · Expected versus observed:** Pair every “Platform evidence matrix” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M12.01-C100-T07 · Failure and limit records:** Attach “Platform evidence matrix” change/failure and bounds evidence where required; include uncovered “Matrix entries and retained evidence bytes” and unresolved violations of “Every claimed platform has its own observed evidence”.
- [ ] **UC-M12.01-C100-T08 · Evidence hygiene:** Check the “Platform evidence matrix” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M12.01-C100-T09 · Reproduction review:** Have the “Platform evidence matrix” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M12.01-C100-T10 · Acceptance linkage:** Link the “Platform evidence matrix” evidence to its parent and UC-M12.01 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

