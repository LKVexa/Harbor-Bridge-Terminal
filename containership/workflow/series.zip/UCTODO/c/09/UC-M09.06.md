# UC-M09.06 — Native runtime memory-safety audit

**To-Do Pack 2.0.0 · Baseline UC-2.2.0 · 100 parent checks × 10 subtasks = 1,000 to-dos**

[Master index](../../INDEX.md) · [Workstream index](../../w/09.md)

| Field | Preserved source value |
|---|---|
| Workstream | 09. Trust, integrity and adversarial security |
| Milestone | C |
| Priority | P0 |
| Source assessment | MISSING |
| Scope | core or selected profile |
| Dependencies | [UC-M02.08](../02/UC-M02.08.md), [UC-M03.02](../03/UC-M03.02.md) |
| Source checklist pack | 1.0.0 |
| Original reference labels | [S4], [S7], [S8]. |

## Original requirement

Review and fuzz the actual C engines, image loaders, device handlers and interpreters with sanitizers and hardened builds.

**Original acceptance criterion:** Adversarial image/bytecode corpora complete without sanitizer findings; each remaining finding has an explicit blocker.

**Source trace:** Original checklist `UC100/c/09/UC-M09.06.md` inside [s/checklists.zip](../../s/checklists.zip); exact parent records in [data/parents.jsonl](../../data/parents.jsonl). Original roadmap lines 864–874 are preserved in [s/roadmap.md](../../s/roadmap.md).

## How to use these lists

Every parent statement below is preserved verbatim. Its ten child tasks are proposed decomposition, not implemented capabilities or executed tests. Child IDs append `-T01` through `-T10` to the original parent ID. All begin unchecked / `TODO`. Design/review evidence does not establish runtime enforcement; observe the actual selected target where the parent requires it.

The source dependency graph and selected release profile determine applicability. The numbered child sequence is a local working order, not an added hard dependency graph. An unselected optional feature needs a recorded not-applicable rationale; missing prerequisites for selected work remain blockers. Numerical budgets, backends and trust mechanisms remain decisions unless fixed by the source. Test hostile cases only with synthetic inputs in authorized disposable environments.

## 01. Native attack-surface inventory

**Source delivery:** Inventory C engines, image loaders, device handlers and bytecode interpreters actually executed.

**Source invariant:** The audit covers native code paths in the selected guest and host profiles.

**Source negative case:** A bundled native decoder is omitted because its wrapper is Python.

**Source bounded quantities:** Native targets and source file count.

### UC-M09.06-C001 · Contract

**Original checklist item:** Define the qualification objective for native attack-surface inventory, including the actual target implementation, prerequisites, observable oracle and explicit exclusions.

- [ ] **UC-M09.06-C001-T01 · Scope statement:** Write the qualification question for “Native attack-surface inventory”; identify the actual target, claimed capability and observations that can answer that question.
- [ ] **UC-M09.06-C001-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Native attack-surface inventory”; record each producer, representation and missing-value meaning.
- [ ] **UC-M09.06-C001-T03 · Output inventory:** List the outputs of “Native attack-surface inventory” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M09.06-C001-T04 · Field dictionary:** Create a field-and-term dictionary for “Native attack-surface inventory”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M09.06-C001-T05 · Prerequisite contract:** Map “Native attack-surface inventory” to the source component prerequisites (UC-M02.08, UC-M03.02); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M09.06-C001-T06 · Authority map:** Identify who may produce, change and consume “Native attack-surface inventory”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M09.06-C001-T07 · Invariant clause:** Add a normative clause for “Native attack-surface inventory” that preserves “The audit covers native code paths in the selected guest and host profiles”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M09.06-C001-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Native attack-surface inventory”; include the source counterexample “A bundled native decoder is omitted because its wrapper is Python” and the intended safe disposition.
- [ ] **UC-M09.06-C001-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Native targets and source file count” in the “Native attack-surface inventory” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M09.06-C001-T10 · Contract review:** Review the “Native attack-surface inventory” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M09.06-C002 · Delivery

**Original checklist item:** Inventory C engines, image loaders, device handlers and bytecode interpreters actually executed.

- [ ] **UC-M09.06-C002-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Native attack-surface inventory”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M09.06-C002-T02 · Change plan:** Break the source delivery for “Native attack-surface inventory” into concrete edit targets and reviewable outputs; keep the UC-M09.06 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M09.06-C002-T03 · Core artifact:** Create the “Native attack-surface inventory” model, schema or inventory that realizes this source instruction: Inventory C engines, image loaders, device handlers and bytecode interpreters actually executed.
- [ ] **UC-M09.06-C002-T04 · Concrete realization:** Populate “Native attack-surface inventory” with one concrete worked case; map every required entity or field to its source and flag any unmapped entry.
- [ ] **UC-M09.06-C002-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Native attack-surface inventory” needed to preserve “The audit covers native code paths in the selected guest and host profiles”; record an enforcement gap where only a model exists.
- [ ] **UC-M09.06-C002-T06 · Dependency connection:** Connect the “Native attack-surface inventory” qualification artifact to actual native targets, instrumented builds and reproducible adversarial corpora; record the target identity and what the harness actually exercises.
- [ ] **UC-M09.06-C002-T07 · Resource behavior:** Account for “Native targets and source file count” in “Native attack-surface inventory”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M09.06-C002-T08 · Delivery check:** Run a known-valid control and a deliberately failing control for “Native attack-surface inventory”; confirm the harness distinguishes their observed outcomes.
- [ ] **UC-M09.06-C002-T09 · Patch review:** Review the “Native attack-surface inventory” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M09.06-C002-T10 · Delivery handoff:** Publish the “Native attack-surface inventory” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M09.06-C003 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: The audit covers native code paths in the selected guest and host profiles. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M09.06-C003-T01 · Named property:** Create a stable property/check name under this parent for “Native attack-surface inventory”; copy its required invariant exactly: “The audit covers native code paths in the selected guest and host profiles”.
- [ ] **UC-M09.06-C003-T02 · Observable terms:** Define each term in the “Native attack-surface inventory” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M09.06-C003-T03 · Precondition set:** List the preconditions under which “The audit covers native code paths in the selected guest and host profiles” must hold for “Native attack-surface inventory”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M09.06-C003-T04 · Transition coverage:** Map the “Native attack-surface inventory” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M09.06-C003-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Native attack-surface inventory”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M09.06-C003-T06 · Satisfying fixture:** Create a concrete “Native attack-surface inventory” case that satisfies “The audit covers native code paths in the selected guest and host profiles”; record its expected observation before running the assertion or review.
- [ ] **UC-M09.06-C003-T07 · Violating fixture:** Create the source counterexample “A bundled native decoder is omitted because its wrapper is Python” for “Native attack-surface inventory”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M09.06-C003-T08 · Enforcement evidence:** Exercise the “Native attack-surface inventory” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M09.06-C003-T09 · Regression linkage:** Link the “Native attack-surface inventory” property to changes in actual native targets, instrumented builds and reproducible adversarial corpora; record which dependency or contract changes require rerunning it.
- [ ] **UC-M09.06-C003-T10 · Property disposition:** Compare the satisfying and violating “Native attack-surface inventory” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M09.06-C004 · Integration

**Original checklist item:** Integrate native attack-surface inventory with actual native targets, instrumented builds and reproducible adversarial corpora; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M09.06-C004-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Native attack-surface inventory” across actual native targets, instrumented builds and reproducible adversarial corpora; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M09.06-C004-T02 · Field mapping:** Map every “Native attack-surface inventory” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M09.06-C004-T03 · Prerequisite identities:** Record the actual prerequisites for “Native attack-surface inventory” (source dependency list: UC-M02.08, UC-M03.02); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M09.06-C004-T04 · Ownership agreement:** Specify who owns “Native attack-surface inventory” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M09.06-C004-T05 · Handoff implementation:** Connect “Native attack-surface inventory” through the mapped seam using the real adapter or explicit specification reference; preserve “The audit covers native code paths in the selected guest and host profiles” across the handoff.
- [ ] **UC-M09.06-C004-T06 · Absent-input case:** Omit one required “Native attack-surface inventory” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M09.06-C004-T07 · Stale-input case:** Supply an outdated “Native attack-surface inventory” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M09.06-C004-T08 · Incompatible-input case:** Supply an incompatible “Native attack-surface inventory” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M09.06-C004-T09 · Valid integration trace:** Run a valid “Native attack-surface inventory” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M09.06-C004-T10 · Seam review:** Reconcile the “Native attack-surface inventory” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M09.06-C005 · Valid-case test

**Original checklist item:** Run a known-valid control for native attack-surface inventory; verify that the harness reaches its intended target and compare observed measurements or verdicts with predeclared expectations.

- [ ] **UC-M09.06-C005-T01 · Valid fixture choice:** Choose a known-valid control for “Native attack-surface inventory”; document why it should pass and how it proves the harness reaches the intended target.
- [ ] **UC-M09.06-C005-T02 · Expected-result oracle:** Specify the “Native attack-surface inventory” expected result independently of the implementation output; include the property “The audit covers native code paths in the selected guest and host profiles” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M09.06-C005-T03 · Fixture material:** Create the concrete “Native attack-surface inventory” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M09.06-C005-T04 · Target preparation:** Prepare the “Native attack-surface inventory” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M09.06-C005-T05 · Initial-state record:** Record the initial “Native attack-surface inventory” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M09.06-C005-T06 · Valid-path execution:** Run the “Native attack-surface inventory” known-valid control on the identified target; retain enough observations to prove the correct target was exercised.
- [ ] **UC-M09.06-C005-T07 · Outcome comparison:** Compare every declared “Native attack-surface inventory” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M09.06-C005-T08 · State and bounds check:** Inspect the “Native attack-surface inventory” ownership/state effects and actual use of “Native targets and source file count”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M09.06-C005-T09 · Repeatability check:** Repeat the same “Native attack-surface inventory” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M09.06-C005-T10 · Positive evidence:** Attach the “Native attack-surface inventory” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M09.06-C006 · Negative test

**Original checklist item:** Negative case: A bundled native decoder is omitted because its wrapper is Python. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M09.06-C006-T01 · Adverse-case definition:** Create a test record for the exact “Native attack-surface inventory” source counterexample: “A bundled native decoder is omitted because its wrapper is Python”; state which precondition or invariant it challenges.
- [ ] **UC-M09.06-C006-T02 · Safe fixture boundary:** Define the contained test boundary for “Native attack-surface inventory”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M09.06-C006-T03 · Valid control:** Construct a valid “Native attack-surface inventory” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M09.06-C006-T04 · Minimal adverse input:** Derive the “Native attack-surface inventory” adverse fixture from the control with the smallest documented change needed to reproduce “A bundled native decoder is omitted because its wrapper is Python”; retain that change as reproducible data.
- [ ] **UC-M09.06-C006-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Native attack-surface inventory”; require “The audit covers native code paths in the selected guest and host profiles” and forbid a false-success verdict.
- [ ] **UC-M09.06-C006-T06 · Adverse execution:** Exercise the “Native attack-surface inventory” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M09.06-C006-T07 · Effect inspection:** Inspect “Native attack-surface inventory” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M09.06-C006-T08 · Refusal versus failure:** Confirm the “Native attack-surface inventory” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M09.06-C006-T09 · Reset and retention:** Restore only the disposable “Native attack-surface inventory” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M09.06-C006-T10 · Negative regression:** Register the “Native attack-surface inventory” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M09.06-C007 · Change / failure test

**Original checklist item:** Exercise native attack-surface inventory when a native runtime update changes code previously covered by a clean campaign; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M09.06-C007-T01 · Scenario record:** Write the “Native attack-surface inventory” change/failure scenario exactly as supplied: a native runtime update changes code previously covered by a clean campaign; identify the property that must remain true: “The audit covers native code paths in the selected guest and host profiles”.
- [ ] **UC-M09.06-C007-T02 · Baseline capture:** Create a known-valid “Native attack-surface inventory” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M09.06-C007-T03 · Injection map:** Locate the “Native attack-surface inventory” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M09.06-C007-T04 · Disposition oracle:** Define the legal intermediate and final “Native attack-surface inventory” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M09.06-C007-T05 · Controlled trigger:** Introduce the controlled “Native attack-surface inventory” scenario in the disposable fixture: a native runtime update changes code previously covered by a clean campaign; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M09.06-C007-T06 · Intermediate inspection:** Inspect the “Native attack-surface inventory” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M09.06-C007-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Native attack-surface inventory”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M09.06-C007-T08 · Stale-evidence cleanup:** Invalidate superseded “Native attack-surface inventory” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M09.06-C007-T09 · Repeat and compare:** Repeat the selected “Native attack-surface inventory” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M09.06-C007-T10 · Failure evidence:** Publish the “Native attack-surface inventory” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M09.06-C008 · Bounds

**Original checklist item:** Set a documented campaign budget for native targets and source file count; record actual consumption, incomplete coverage and the disposition when the budget is exhausted.

- [ ] **UC-M09.06-C008-T01 · Quantity inventory:** Create a measurement inventory for “Native attack-surface inventory”: “Native targets and source file count”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M09.06-C008-T02 · Measurement method:** Choose how to observe each “Native attack-surface inventory” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M09.06-C008-T03 · Budget decision:** Select justified campaign and target-resource budgets for “Native attack-surface inventory”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M09.06-C008-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Native attack-surface inventory” cases for “Native targets and source file count”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M09.06-C008-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Native attack-surface inventory” limit; preserve “The audit covers native code paths in the selected guest and host profiles”.
- [ ] **UC-M09.06-C008-T06 · Normal measurement:** Run or review the normal “Native attack-surface inventory” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M09.06-C008-T07 · At-limit measurement:** Exercise the “Native attack-surface inventory” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M09.06-C008-T08 · Over-limit measurement:** Exercise the “Native attack-surface inventory” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M09.06-C008-T09 · Uncovered-scope report:** List the “Native attack-surface inventory” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M09.06-C008-T10 · Limit evidence:** Publish the selected “Native attack-surface inventory” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M09.06-C009 · Diagnostics / review

**Original checklist item:** Report native attack-surface inventory results with executed, failed, skipped and unavailable cases separated; preserve the underlying observations and do not manufacture missing measurements.

- [ ] **UC-M09.06-C009-T01 · Result inventory:** Enumerate the required “Native attack-surface inventory” qualification cases and intended targets before aggregating results; keep the planned denominator visible.
- [ ] **UC-M09.06-C009-T02 · Verdict schema:** Define separate executed-pass, executed-fail, skipped, unavailable and untested outcomes for “Native attack-surface inventory”; document how incomplete cases block relevant claims.
- [ ] **UC-M09.06-C009-T03 · Identity fields:** Attach the actual target, fixture, configuration and revision identifiers to each “Native attack-surface inventory” result; do not attribute host-only evidence to a guest or another OS.
- [ ] **UC-M09.06-C009-T04 · Observation capture:** Capture bounded raw “Native attack-surface inventory” observations and harness errors; retain enough information to verify the reported oracle comparison.
- [ ] **UC-M09.06-C009-T05 · Aggregation rules:** Implement the “Native attack-surface inventory” count/reduction rule so failures and missing measurements cannot disappear; preserve “The audit covers native code paths in the selected guest and host profiles”.
- [ ] **UC-M09.06-C009-T06 · Failure visibility:** Feed a failing “Native attack-surface inventory” control through the report path; assert the exact failed case and underlying observation remain visible.
- [ ] **UC-M09.06-C009-T07 · Missing-result visibility:** Withhold a required “Native attack-surface inventory” measurement or target; verify the report uses unavailable/untested rather than a fabricated zero or passing value.
- [ ] **UC-M09.06-C009-T08 · Bounds and redaction:** Check “Native attack-surface inventory” report size and retention against “Native targets and source file count”; remove secrets while retaining fixture and subject references.
- [ ] **UC-M09.06-C009-T09 · Report reconciliation:** Reconcile the “Native attack-surface inventory” summary with every underlying case record; account for the full planned denominator and all omitted scope.
- [ ] **UC-M09.06-C009-T10 · Qualification handoff:** Publish the “Native attack-surface inventory” report with measured observations, coverage limits and blockers; state which actual targets remain unqualified.

### UC-M09.06-C010 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for native attack-surface inventory; label unexecuted checks as untested.

- [ ] **UC-M09.06-C010-T01 · Evidence inventory:** List the “Native attack-surface inventory” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M09.06-C010-T02 · Artifact references:** Record the exact “Native attack-surface inventory” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M09.06-C010-T03 · Fixture references:** Attach the “Native attack-surface inventory” fixture IDs, input identities and oracle definition; preserve the source counterexample “A bundled native decoder is omitted because its wrapper is Python” as a distinct evidence case.
- [ ] **UC-M09.06-C010-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Native attack-surface inventory”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M09.06-C010-T05 · Environment record:** Record the actual “Native attack-surface inventory” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M09.06-C010-T06 · Expected versus observed:** Pair every “Native attack-surface inventory” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M09.06-C010-T07 · Failure and limit records:** Attach “Native attack-surface inventory” change/failure and bounds evidence where required; include uncovered “Native targets and source file count” and unresolved violations of “The audit covers native code paths in the selected guest and host profiles”.
- [ ] **UC-M09.06-C010-T08 · Evidence hygiene:** Check the “Native attack-surface inventory” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M09.06-C010-T09 · Reproduction review:** Have the “Native attack-surface inventory” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M09.06-C010-T10 · Acceptance linkage:** Link the “Native attack-surface inventory” evidence to its parent and UC-M09.06 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 02. Hardened build profile

**Source delivery:** Define supported hardened build options and record their effective use.

**Source invariant:** Build flags are verified on the tested binaries rather than merely documented.

**Source negative case:** The test binary lacks the flags claimed in its report.

**Source bounded quantities:** Build variants and binary bytes.

### UC-M09.06-C011 · Contract

**Original checklist item:** Define the qualification objective for hardened build profile, including the actual target implementation, prerequisites, observable oracle and explicit exclusions.

- [ ] **UC-M09.06-C011-T01 · Scope statement:** Write the qualification question for “Hardened build profile”; identify the actual target, claimed capability and observations that can answer that question.
- [ ] **UC-M09.06-C011-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Hardened build profile”; record each producer, representation and missing-value meaning.
- [ ] **UC-M09.06-C011-T03 · Output inventory:** List the outputs of “Hardened build profile” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M09.06-C011-T04 · Field dictionary:** Create a field-and-term dictionary for “Hardened build profile”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M09.06-C011-T05 · Prerequisite contract:** Map “Hardened build profile” to the source component prerequisites (UC-M02.08, UC-M03.02); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M09.06-C011-T06 · Authority map:** Identify who may produce, change and consume “Hardened build profile”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M09.06-C011-T07 · Invariant clause:** Add a normative clause for “Hardened build profile” that preserves “Build flags are verified on the tested binaries rather than merely documented”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M09.06-C011-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Hardened build profile”; include the source counterexample “The test binary lacks the flags claimed in its report” and the intended safe disposition.
- [ ] **UC-M09.06-C011-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Build variants and binary bytes” in the “Hardened build profile” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M09.06-C011-T10 · Contract review:** Review the “Hardened build profile” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M09.06-C012 · Delivery

**Original checklist item:** Define supported hardened build options and record their effective use.

- [ ] **UC-M09.06-C012-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Hardened build profile”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M09.06-C012-T02 · Change plan:** Break the source delivery for “Hardened build profile” into concrete edit targets and reviewable outputs; keep the UC-M09.06 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M09.06-C012-T03 · Core artifact:** Create the “Hardened build profile” model, schema or inventory that realizes this source instruction: Define supported hardened build options and record their effective use.
- [ ] **UC-M09.06-C012-T04 · Concrete realization:** Populate “Hardened build profile” with one concrete worked case; map every required entity or field to its source and flag any unmapped entry.
- [ ] **UC-M09.06-C012-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Hardened build profile” needed to preserve “Build flags are verified on the tested binaries rather than merely documented”; record an enforcement gap where only a model exists.
- [ ] **UC-M09.06-C012-T06 · Dependency connection:** Connect the “Hardened build profile” qualification artifact to actual native targets, instrumented builds and reproducible adversarial corpora; record the target identity and what the harness actually exercises.
- [ ] **UC-M09.06-C012-T07 · Resource behavior:** Account for “Build variants and binary bytes” in “Hardened build profile”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M09.06-C012-T08 · Delivery check:** Run a known-valid control and a deliberately failing control for “Hardened build profile”; confirm the harness distinguishes their observed outcomes.
- [ ] **UC-M09.06-C012-T09 · Patch review:** Review the “Hardened build profile” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M09.06-C012-T10 · Delivery handoff:** Publish the “Hardened build profile” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M09.06-C013 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Build flags are verified on the tested binaries rather than merely documented. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M09.06-C013-T01 · Named property:** Create a stable property/check name under this parent for “Hardened build profile”; copy its required invariant exactly: “Build flags are verified on the tested binaries rather than merely documented”.
- [ ] **UC-M09.06-C013-T02 · Observable terms:** Define each term in the “Hardened build profile” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M09.06-C013-T03 · Precondition set:** List the preconditions under which “Build flags are verified on the tested binaries rather than merely documented” must hold for “Hardened build profile”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M09.06-C013-T04 · Transition coverage:** Map the “Hardened build profile” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M09.06-C013-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Hardened build profile”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M09.06-C013-T06 · Satisfying fixture:** Create a concrete “Hardened build profile” case that satisfies “Build flags are verified on the tested binaries rather than merely documented”; record its expected observation before running the assertion or review.
- [ ] **UC-M09.06-C013-T07 · Violating fixture:** Create the source counterexample “The test binary lacks the flags claimed in its report” for “Hardened build profile”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M09.06-C013-T08 · Enforcement evidence:** Exercise the “Hardened build profile” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M09.06-C013-T09 · Regression linkage:** Link the “Hardened build profile” property to changes in actual native targets, instrumented builds and reproducible adversarial corpora; record which dependency or contract changes require rerunning it.
- [ ] **UC-M09.06-C013-T10 · Property disposition:** Compare the satisfying and violating “Hardened build profile” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M09.06-C014 · Integration

**Original checklist item:** Integrate hardened build profile with actual native targets, instrumented builds and reproducible adversarial corpora; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M09.06-C014-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Hardened build profile” across actual native targets, instrumented builds and reproducible adversarial corpora; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M09.06-C014-T02 · Field mapping:** Map every “Hardened build profile” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M09.06-C014-T03 · Prerequisite identities:** Record the actual prerequisites for “Hardened build profile” (source dependency list: UC-M02.08, UC-M03.02); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M09.06-C014-T04 · Ownership agreement:** Specify who owns “Hardened build profile” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M09.06-C014-T05 · Handoff implementation:** Connect “Hardened build profile” through the mapped seam using the real adapter or explicit specification reference; preserve “Build flags are verified on the tested binaries rather than merely documented” across the handoff.
- [ ] **UC-M09.06-C014-T06 · Absent-input case:** Omit one required “Hardened build profile” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M09.06-C014-T07 · Stale-input case:** Supply an outdated “Hardened build profile” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M09.06-C014-T08 · Incompatible-input case:** Supply an incompatible “Hardened build profile” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M09.06-C014-T09 · Valid integration trace:** Run a valid “Hardened build profile” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M09.06-C014-T10 · Seam review:** Reconcile the “Hardened build profile” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M09.06-C015 · Valid-case test

**Original checklist item:** Run a known-valid control for hardened build profile; verify that the harness reaches its intended target and compare observed measurements or verdicts with predeclared expectations.

- [ ] **UC-M09.06-C015-T01 · Valid fixture choice:** Choose a known-valid control for “Hardened build profile”; document why it should pass and how it proves the harness reaches the intended target.
- [ ] **UC-M09.06-C015-T02 · Expected-result oracle:** Specify the “Hardened build profile” expected result independently of the implementation output; include the property “Build flags are verified on the tested binaries rather than merely documented” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M09.06-C015-T03 · Fixture material:** Create the concrete “Hardened build profile” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M09.06-C015-T04 · Target preparation:** Prepare the “Hardened build profile” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M09.06-C015-T05 · Initial-state record:** Record the initial “Hardened build profile” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M09.06-C015-T06 · Valid-path execution:** Run the “Hardened build profile” known-valid control on the identified target; retain enough observations to prove the correct target was exercised.
- [ ] **UC-M09.06-C015-T07 · Outcome comparison:** Compare every declared “Hardened build profile” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M09.06-C015-T08 · State and bounds check:** Inspect the “Hardened build profile” ownership/state effects and actual use of “Build variants and binary bytes”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M09.06-C015-T09 · Repeatability check:** Repeat the same “Hardened build profile” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M09.06-C015-T10 · Positive evidence:** Attach the “Hardened build profile” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M09.06-C016 · Negative test

**Original checklist item:** Negative case: The test binary lacks the flags claimed in its report. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M09.06-C016-T01 · Adverse-case definition:** Create a test record for the exact “Hardened build profile” source counterexample: “The test binary lacks the flags claimed in its report”; state which precondition or invariant it challenges.
- [ ] **UC-M09.06-C016-T02 · Safe fixture boundary:** Define the contained test boundary for “Hardened build profile”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M09.06-C016-T03 · Valid control:** Construct a valid “Hardened build profile” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M09.06-C016-T04 · Minimal adverse input:** Derive the “Hardened build profile” adverse fixture from the control with the smallest documented change needed to reproduce “The test binary lacks the flags claimed in its report”; retain that change as reproducible data.
- [ ] **UC-M09.06-C016-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Hardened build profile”; require “Build flags are verified on the tested binaries rather than merely documented” and forbid a false-success verdict.
- [ ] **UC-M09.06-C016-T06 · Adverse execution:** Exercise the “Hardened build profile” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M09.06-C016-T07 · Effect inspection:** Inspect “Hardened build profile” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M09.06-C016-T08 · Refusal versus failure:** Confirm the “Hardened build profile” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M09.06-C016-T09 · Reset and retention:** Restore only the disposable “Hardened build profile” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M09.06-C016-T10 · Negative regression:** Register the “Hardened build profile” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M09.06-C017 · Change / failure test

**Original checklist item:** Exercise hardened build profile when a native runtime update changes code previously covered by a clean campaign; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M09.06-C017-T01 · Scenario record:** Write the “Hardened build profile” change/failure scenario exactly as supplied: a native runtime update changes code previously covered by a clean campaign; identify the property that must remain true: “Build flags are verified on the tested binaries rather than merely documented”.
- [ ] **UC-M09.06-C017-T02 · Baseline capture:** Create a known-valid “Hardened build profile” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M09.06-C017-T03 · Injection map:** Locate the “Hardened build profile” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M09.06-C017-T04 · Disposition oracle:** Define the legal intermediate and final “Hardened build profile” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M09.06-C017-T05 · Controlled trigger:** Introduce the controlled “Hardened build profile” scenario in the disposable fixture: a native runtime update changes code previously covered by a clean campaign; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M09.06-C017-T06 · Intermediate inspection:** Inspect the “Hardened build profile” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M09.06-C017-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Hardened build profile”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M09.06-C017-T08 · Stale-evidence cleanup:** Invalidate superseded “Hardened build profile” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M09.06-C017-T09 · Repeat and compare:** Repeat the selected “Hardened build profile” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M09.06-C017-T10 · Failure evidence:** Publish the “Hardened build profile” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M09.06-C018 · Bounds

**Original checklist item:** Set a documented campaign budget for build variants and binary bytes; record actual consumption, incomplete coverage and the disposition when the budget is exhausted.

- [ ] **UC-M09.06-C018-T01 · Quantity inventory:** Create a measurement inventory for “Hardened build profile”: “Build variants and binary bytes”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M09.06-C018-T02 · Measurement method:** Choose how to observe each “Hardened build profile” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M09.06-C018-T03 · Budget decision:** Select justified campaign and target-resource budgets for “Hardened build profile”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M09.06-C018-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Hardened build profile” cases for “Build variants and binary bytes”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M09.06-C018-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Hardened build profile” limit; preserve “Build flags are verified on the tested binaries rather than merely documented”.
- [ ] **UC-M09.06-C018-T06 · Normal measurement:** Run or review the normal “Hardened build profile” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M09.06-C018-T07 · At-limit measurement:** Exercise the “Hardened build profile” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M09.06-C018-T08 · Over-limit measurement:** Exercise the “Hardened build profile” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M09.06-C018-T09 · Uncovered-scope report:** List the “Hardened build profile” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M09.06-C018-T10 · Limit evidence:** Publish the selected “Hardened build profile” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M09.06-C019 · Diagnostics / review

**Original checklist item:** Report hardened build profile results with executed, failed, skipped and unavailable cases separated; preserve the underlying observations and do not manufacture missing measurements.

- [ ] **UC-M09.06-C019-T01 · Result inventory:** Enumerate the required “Hardened build profile” qualification cases and intended targets before aggregating results; keep the planned denominator visible.
- [ ] **UC-M09.06-C019-T02 · Verdict schema:** Define separate executed-pass, executed-fail, skipped, unavailable and untested outcomes for “Hardened build profile”; document how incomplete cases block relevant claims.
- [ ] **UC-M09.06-C019-T03 · Identity fields:** Attach the actual target, fixture, configuration and revision identifiers to each “Hardened build profile” result; do not attribute host-only evidence to a guest or another OS.
- [ ] **UC-M09.06-C019-T04 · Observation capture:** Capture bounded raw “Hardened build profile” observations and harness errors; retain enough information to verify the reported oracle comparison.
- [ ] **UC-M09.06-C019-T05 · Aggregation rules:** Implement the “Hardened build profile” count/reduction rule so failures and missing measurements cannot disappear; preserve “Build flags are verified on the tested binaries rather than merely documented”.
- [ ] **UC-M09.06-C019-T06 · Failure visibility:** Feed a failing “Hardened build profile” control through the report path; assert the exact failed case and underlying observation remain visible.
- [ ] **UC-M09.06-C019-T07 · Missing-result visibility:** Withhold a required “Hardened build profile” measurement or target; verify the report uses unavailable/untested rather than a fabricated zero or passing value.
- [ ] **UC-M09.06-C019-T08 · Bounds and redaction:** Check “Hardened build profile” report size and retention against “Build variants and binary bytes”; remove secrets while retaining fixture and subject references.
- [ ] **UC-M09.06-C019-T09 · Report reconciliation:** Reconcile the “Hardened build profile” summary with every underlying case record; account for the full planned denominator and all omitted scope.
- [ ] **UC-M09.06-C019-T10 · Qualification handoff:** Publish the “Hardened build profile” report with measured observations, coverage limits and blockers; state which actual targets remain unqualified.

### UC-M09.06-C020 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for hardened build profile; label unexecuted checks as untested.

- [ ] **UC-M09.06-C020-T01 · Evidence inventory:** List the “Hardened build profile” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M09.06-C020-T02 · Artifact references:** Record the exact “Hardened build profile” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M09.06-C020-T03 · Fixture references:** Attach the “Hardened build profile” fixture IDs, input identities and oracle definition; preserve the source counterexample “The test binary lacks the flags claimed in its report” as a distinct evidence case.
- [ ] **UC-M09.06-C020-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Hardened build profile”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M09.06-C020-T05 · Environment record:** Record the actual “Hardened build profile” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M09.06-C020-T06 · Expected versus observed:** Pair every “Hardened build profile” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M09.06-C020-T07 · Failure and limit records:** Attach “Hardened build profile” change/failure and bounds evidence where required; include uncovered “Build variants and binary bytes” and unresolved violations of “Build flags are verified on the tested binaries rather than merely documented”.
- [ ] **UC-M09.06-C020-T08 · Evidence hygiene:** Check the “Hardened build profile” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M09.06-C020-T09 · Reproduction review:** Have the “Hardened build profile” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M09.06-C020-T10 · Acceptance linkage:** Link the “Hardened build profile” evidence to its parent and UC-M09.06 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 03. Sanitizer instrumentation

**Source delivery:** Instrument supported native targets with suitable diagnostic tooling.

**Source invariant:** Sanitizer claims identify which code was actually instrumented.

**Source negative case:** A release binary is tested while an unrelated instrumented binary is reported.

**Source bounded quantities:** Instrumented targets and runtime overhead.

### UC-M09.06-C021 · Contract

**Original checklist item:** Define the qualification objective for sanitizer instrumentation, including the actual target implementation, prerequisites, observable oracle and explicit exclusions.

- [ ] **UC-M09.06-C021-T01 · Scope statement:** Write the qualification question for “Sanitizer instrumentation”; identify the actual target, claimed capability and observations that can answer that question.
- [ ] **UC-M09.06-C021-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Sanitizer instrumentation”; record each producer, representation and missing-value meaning.
- [ ] **UC-M09.06-C021-T03 · Output inventory:** List the outputs of “Sanitizer instrumentation” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M09.06-C021-T04 · Field dictionary:** Create a field-and-term dictionary for “Sanitizer instrumentation”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M09.06-C021-T05 · Prerequisite contract:** Map “Sanitizer instrumentation” to the source component prerequisites (UC-M02.08, UC-M03.02); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M09.06-C021-T06 · Authority map:** Identify who may produce, change and consume “Sanitizer instrumentation”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M09.06-C021-T07 · Invariant clause:** Add a normative clause for “Sanitizer instrumentation” that preserves “Sanitizer claims identify which code was actually instrumented”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M09.06-C021-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Sanitizer instrumentation”; include the source counterexample “A release binary is tested while an unrelated instrumented binary is reported” and the intended safe disposition.
- [ ] **UC-M09.06-C021-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Instrumented targets and runtime overhead” in the “Sanitizer instrumentation” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M09.06-C021-T10 · Contract review:** Review the “Sanitizer instrumentation” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M09.06-C022 · Delivery

**Original checklist item:** Instrument supported native targets with suitable diagnostic tooling.

- [ ] **UC-M09.06-C022-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Sanitizer instrumentation”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M09.06-C022-T02 · Change plan:** Break the source delivery for “Sanitizer instrumentation” into concrete edit targets and reviewable outputs; keep the UC-M09.06 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M09.06-C022-T03 · Core artifact:** Implement the smallest selected-profile change for “Sanitizer instrumentation” that realizes this source instruction: Instrument supported native targets with suitable diagnostic tooling.
- [ ] **UC-M09.06-C022-T04 · Concrete realization:** Trace “Sanitizer instrumentation” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M09.06-C022-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Sanitizer instrumentation” needed to preserve “Sanitizer claims identify which code was actually instrumented”; record an enforcement gap where only a model exists.
- [ ] **UC-M09.06-C022-T06 · Dependency connection:** Connect the “Sanitizer instrumentation” qualification artifact to actual native targets, instrumented builds and reproducible adversarial corpora; record the target identity and what the harness actually exercises.
- [ ] **UC-M09.06-C022-T07 · Resource behavior:** Account for “Instrumented targets and runtime overhead” in “Sanitizer instrumentation”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M09.06-C022-T08 · Delivery check:** Run a known-valid control and a deliberately failing control for “Sanitizer instrumentation”; confirm the harness distinguishes their observed outcomes.
- [ ] **UC-M09.06-C022-T09 · Patch review:** Review the “Sanitizer instrumentation” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M09.06-C022-T10 · Delivery handoff:** Publish the “Sanitizer instrumentation” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M09.06-C023 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Sanitizer claims identify which code was actually instrumented. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M09.06-C023-T01 · Named property:** Create a stable property/check name under this parent for “Sanitizer instrumentation”; copy its required invariant exactly: “Sanitizer claims identify which code was actually instrumented”.
- [ ] **UC-M09.06-C023-T02 · Observable terms:** Define each term in the “Sanitizer instrumentation” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M09.06-C023-T03 · Precondition set:** List the preconditions under which “Sanitizer claims identify which code was actually instrumented” must hold for “Sanitizer instrumentation”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M09.06-C023-T04 · Transition coverage:** Map the “Sanitizer instrumentation” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M09.06-C023-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Sanitizer instrumentation”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M09.06-C023-T06 · Satisfying fixture:** Create a concrete “Sanitizer instrumentation” case that satisfies “Sanitizer claims identify which code was actually instrumented”; record its expected observation before running the assertion or review.
- [ ] **UC-M09.06-C023-T07 · Violating fixture:** Create the source counterexample “A release binary is tested while an unrelated instrumented binary is reported” for “Sanitizer instrumentation”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M09.06-C023-T08 · Enforcement evidence:** Exercise the “Sanitizer instrumentation” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M09.06-C023-T09 · Regression linkage:** Link the “Sanitizer instrumentation” property to changes in actual native targets, instrumented builds and reproducible adversarial corpora; record which dependency or contract changes require rerunning it.
- [ ] **UC-M09.06-C023-T10 · Property disposition:** Compare the satisfying and violating “Sanitizer instrumentation” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M09.06-C024 · Integration

**Original checklist item:** Integrate sanitizer instrumentation with actual native targets, instrumented builds and reproducible adversarial corpora; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M09.06-C024-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Sanitizer instrumentation” across actual native targets, instrumented builds and reproducible adversarial corpora; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M09.06-C024-T02 · Field mapping:** Map every “Sanitizer instrumentation” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M09.06-C024-T03 · Prerequisite identities:** Record the actual prerequisites for “Sanitizer instrumentation” (source dependency list: UC-M02.08, UC-M03.02); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M09.06-C024-T04 · Ownership agreement:** Specify who owns “Sanitizer instrumentation” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M09.06-C024-T05 · Handoff implementation:** Connect “Sanitizer instrumentation” through the mapped seam using the real adapter or explicit specification reference; preserve “Sanitizer claims identify which code was actually instrumented” across the handoff.
- [ ] **UC-M09.06-C024-T06 · Absent-input case:** Omit one required “Sanitizer instrumentation” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M09.06-C024-T07 · Stale-input case:** Supply an outdated “Sanitizer instrumentation” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M09.06-C024-T08 · Incompatible-input case:** Supply an incompatible “Sanitizer instrumentation” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M09.06-C024-T09 · Valid integration trace:** Run a valid “Sanitizer instrumentation” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M09.06-C024-T10 · Seam review:** Reconcile the “Sanitizer instrumentation” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M09.06-C025 · Valid-case test

**Original checklist item:** Run a known-valid control for sanitizer instrumentation; verify that the harness reaches its intended target and compare observed measurements or verdicts with predeclared expectations.

- [ ] **UC-M09.06-C025-T01 · Valid fixture choice:** Choose a known-valid control for “Sanitizer instrumentation”; document why it should pass and how it proves the harness reaches the intended target.
- [ ] **UC-M09.06-C025-T02 · Expected-result oracle:** Specify the “Sanitizer instrumentation” expected result independently of the implementation output; include the property “Sanitizer claims identify which code was actually instrumented” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M09.06-C025-T03 · Fixture material:** Create the concrete “Sanitizer instrumentation” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M09.06-C025-T04 · Target preparation:** Prepare the “Sanitizer instrumentation” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M09.06-C025-T05 · Initial-state record:** Record the initial “Sanitizer instrumentation” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M09.06-C025-T06 · Valid-path execution:** Run the “Sanitizer instrumentation” known-valid control on the identified target; retain enough observations to prove the correct target was exercised.
- [ ] **UC-M09.06-C025-T07 · Outcome comparison:** Compare every declared “Sanitizer instrumentation” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M09.06-C025-T08 · State and bounds check:** Inspect the “Sanitizer instrumentation” ownership/state effects and actual use of “Instrumented targets and runtime overhead”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M09.06-C025-T09 · Repeatability check:** Repeat the same “Sanitizer instrumentation” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M09.06-C025-T10 · Positive evidence:** Attach the “Sanitizer instrumentation” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M09.06-C026 · Negative test

**Original checklist item:** Negative case: A release binary is tested while an unrelated instrumented binary is reported. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M09.06-C026-T01 · Adverse-case definition:** Create a test record for the exact “Sanitizer instrumentation” source counterexample: “A release binary is tested while an unrelated instrumented binary is reported”; state which precondition or invariant it challenges.
- [ ] **UC-M09.06-C026-T02 · Safe fixture boundary:** Define the contained test boundary for “Sanitizer instrumentation”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M09.06-C026-T03 · Valid control:** Construct a valid “Sanitizer instrumentation” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M09.06-C026-T04 · Minimal adverse input:** Derive the “Sanitizer instrumentation” adverse fixture from the control with the smallest documented change needed to reproduce “A release binary is tested while an unrelated instrumented binary is reported”; retain that change as reproducible data.
- [ ] **UC-M09.06-C026-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Sanitizer instrumentation”; require “Sanitizer claims identify which code was actually instrumented” and forbid a false-success verdict.
- [ ] **UC-M09.06-C026-T06 · Adverse execution:** Exercise the “Sanitizer instrumentation” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M09.06-C026-T07 · Effect inspection:** Inspect “Sanitizer instrumentation” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M09.06-C026-T08 · Refusal versus failure:** Confirm the “Sanitizer instrumentation” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M09.06-C026-T09 · Reset and retention:** Restore only the disposable “Sanitizer instrumentation” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M09.06-C026-T10 · Negative regression:** Register the “Sanitizer instrumentation” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M09.06-C027 · Change / failure test

**Original checklist item:** Exercise sanitizer instrumentation when a native runtime update changes code previously covered by a clean campaign; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M09.06-C027-T01 · Scenario record:** Write the “Sanitizer instrumentation” change/failure scenario exactly as supplied: a native runtime update changes code previously covered by a clean campaign; identify the property that must remain true: “Sanitizer claims identify which code was actually instrumented”.
- [ ] **UC-M09.06-C027-T02 · Baseline capture:** Create a known-valid “Sanitizer instrumentation” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M09.06-C027-T03 · Injection map:** Locate the “Sanitizer instrumentation” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M09.06-C027-T04 · Disposition oracle:** Define the legal intermediate and final “Sanitizer instrumentation” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M09.06-C027-T05 · Controlled trigger:** Introduce the controlled “Sanitizer instrumentation” scenario in the disposable fixture: a native runtime update changes code previously covered by a clean campaign; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M09.06-C027-T06 · Intermediate inspection:** Inspect the “Sanitizer instrumentation” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M09.06-C027-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Sanitizer instrumentation”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M09.06-C027-T08 · Stale-evidence cleanup:** Invalidate superseded “Sanitizer instrumentation” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M09.06-C027-T09 · Repeat and compare:** Repeat the selected “Sanitizer instrumentation” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M09.06-C027-T10 · Failure evidence:** Publish the “Sanitizer instrumentation” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M09.06-C028 · Bounds

**Original checklist item:** Set a documented campaign budget for instrumented targets and runtime overhead; record actual consumption, incomplete coverage and the disposition when the budget is exhausted.

- [ ] **UC-M09.06-C028-T01 · Quantity inventory:** Create a measurement inventory for “Sanitizer instrumentation”: “Instrumented targets and runtime overhead”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M09.06-C028-T02 · Measurement method:** Choose how to observe each “Sanitizer instrumentation” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M09.06-C028-T03 · Budget decision:** Select justified campaign and target-resource budgets for “Sanitizer instrumentation”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M09.06-C028-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Sanitizer instrumentation” cases for “Instrumented targets and runtime overhead”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M09.06-C028-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Sanitizer instrumentation” limit; preserve “Sanitizer claims identify which code was actually instrumented”.
- [ ] **UC-M09.06-C028-T06 · Normal measurement:** Run or review the normal “Sanitizer instrumentation” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M09.06-C028-T07 · At-limit measurement:** Exercise the “Sanitizer instrumentation” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M09.06-C028-T08 · Over-limit measurement:** Exercise the “Sanitizer instrumentation” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M09.06-C028-T09 · Uncovered-scope report:** List the “Sanitizer instrumentation” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M09.06-C028-T10 · Limit evidence:** Publish the selected “Sanitizer instrumentation” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M09.06-C029 · Diagnostics / review

**Original checklist item:** Report sanitizer instrumentation results with executed, failed, skipped and unavailable cases separated; preserve the underlying observations and do not manufacture missing measurements.

- [ ] **UC-M09.06-C029-T01 · Result inventory:** Enumerate the required “Sanitizer instrumentation” qualification cases and intended targets before aggregating results; keep the planned denominator visible.
- [ ] **UC-M09.06-C029-T02 · Verdict schema:** Define separate executed-pass, executed-fail, skipped, unavailable and untested outcomes for “Sanitizer instrumentation”; document how incomplete cases block relevant claims.
- [ ] **UC-M09.06-C029-T03 · Identity fields:** Attach the actual target, fixture, configuration and revision identifiers to each “Sanitizer instrumentation” result; do not attribute host-only evidence to a guest or another OS.
- [ ] **UC-M09.06-C029-T04 · Observation capture:** Capture bounded raw “Sanitizer instrumentation” observations and harness errors; retain enough information to verify the reported oracle comparison.
- [ ] **UC-M09.06-C029-T05 · Aggregation rules:** Implement the “Sanitizer instrumentation” count/reduction rule so failures and missing measurements cannot disappear; preserve “Sanitizer claims identify which code was actually instrumented”.
- [ ] **UC-M09.06-C029-T06 · Failure visibility:** Feed a failing “Sanitizer instrumentation” control through the report path; assert the exact failed case and underlying observation remain visible.
- [ ] **UC-M09.06-C029-T07 · Missing-result visibility:** Withhold a required “Sanitizer instrumentation” measurement or target; verify the report uses unavailable/untested rather than a fabricated zero or passing value.
- [ ] **UC-M09.06-C029-T08 · Bounds and redaction:** Check “Sanitizer instrumentation” report size and retention against “Instrumented targets and runtime overhead”; remove secrets while retaining fixture and subject references.
- [ ] **UC-M09.06-C029-T09 · Report reconciliation:** Reconcile the “Sanitizer instrumentation” summary with every underlying case record; account for the full planned denominator and all omitted scope.
- [ ] **UC-M09.06-C029-T10 · Qualification handoff:** Publish the “Sanitizer instrumentation” report with measured observations, coverage limits and blockers; state which actual targets remain unqualified.

### UC-M09.06-C030 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for sanitizer instrumentation; label unexecuted checks as untested.

- [ ] **UC-M09.06-C030-T01 · Evidence inventory:** List the “Sanitizer instrumentation” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M09.06-C030-T02 · Artifact references:** Record the exact “Sanitizer instrumentation” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M09.06-C030-T03 · Fixture references:** Attach the “Sanitizer instrumentation” fixture IDs, input identities and oracle definition; preserve the source counterexample “A release binary is tested while an unrelated instrumented binary is reported” as a distinct evidence case.
- [ ] **UC-M09.06-C030-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Sanitizer instrumentation”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M09.06-C030-T05 · Environment record:** Record the actual “Sanitizer instrumentation” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M09.06-C030-T06 · Expected versus observed:** Pair every “Sanitizer instrumentation” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M09.06-C030-T07 · Failure and limit records:** Attach “Sanitizer instrumentation” change/failure and bounds evidence where required; include uncovered “Instrumented targets and runtime overhead” and unresolved violations of “Sanitizer claims identify which code was actually instrumented”.
- [ ] **UC-M09.06-C030-T08 · Evidence hygiene:** Check the “Sanitizer instrumentation” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M09.06-C030-T09 · Reproduction review:** Have the “Sanitizer instrumentation” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M09.06-C030-T10 · Acceptance linkage:** Link the “Sanitizer instrumentation” evidence to its parent and UC-M09.06 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 04. Bounds and arithmetic review

**Source delivery:** Review native length, index, pointer and allocation arithmetic at input boundaries.

**Source invariant:** Untrusted sizes cannot silently overflow into unsafe access.

**Source negative case:** A malformed image triggers a wrapped allocation calculation.

**Source bounded quantities:** Reviewed functions and integer boundary cases.

### UC-M09.06-C031 · Contract

**Original checklist item:** Define the qualification objective for bounds and arithmetic review, including the actual target implementation, prerequisites, observable oracle and explicit exclusions.

- [ ] **UC-M09.06-C031-T01 · Scope statement:** Write the qualification question for “Bounds and arithmetic review”; identify the actual target, claimed capability and observations that can answer that question.
- [ ] **UC-M09.06-C031-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Bounds and arithmetic review”; record each producer, representation and missing-value meaning.
- [ ] **UC-M09.06-C031-T03 · Output inventory:** List the outputs of “Bounds and arithmetic review” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M09.06-C031-T04 · Field dictionary:** Create a field-and-term dictionary for “Bounds and arithmetic review”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M09.06-C031-T05 · Prerequisite contract:** Map “Bounds and arithmetic review” to the source component prerequisites (UC-M02.08, UC-M03.02); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M09.06-C031-T06 · Authority map:** Identify who may produce, change and consume “Bounds and arithmetic review”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M09.06-C031-T07 · Invariant clause:** Add a normative clause for “Bounds and arithmetic review” that preserves “Untrusted sizes cannot silently overflow into unsafe access”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M09.06-C031-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Bounds and arithmetic review”; include the source counterexample “A malformed image triggers a wrapped allocation calculation” and the intended safe disposition.
- [ ] **UC-M09.06-C031-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Reviewed functions and integer boundary cases” in the “Bounds and arithmetic review” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M09.06-C031-T10 · Contract review:** Review the “Bounds and arithmetic review” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M09.06-C032 · Delivery

**Original checklist item:** Review native length, index, pointer and allocation arithmetic at input boundaries.

- [ ] **UC-M09.06-C032-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Bounds and arithmetic review”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M09.06-C032-T02 · Change plan:** Break the source delivery for “Bounds and arithmetic review” into concrete edit targets and reviewable outputs; keep the UC-M09.06 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M09.06-C032-T03 · Core artifact:** Implement the smallest selected-profile change for “Bounds and arithmetic review” that realizes this source instruction: Review native length, index, pointer and allocation arithmetic at input boundaries.
- [ ] **UC-M09.06-C032-T04 · Concrete realization:** Trace “Bounds and arithmetic review” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M09.06-C032-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Bounds and arithmetic review” needed to preserve “Untrusted sizes cannot silently overflow into unsafe access”; record an enforcement gap where only a model exists.
- [ ] **UC-M09.06-C032-T06 · Dependency connection:** Connect the “Bounds and arithmetic review” qualification artifact to actual native targets, instrumented builds and reproducible adversarial corpora; record the target identity and what the harness actually exercises.
- [ ] **UC-M09.06-C032-T07 · Resource behavior:** Account for “Reviewed functions and integer boundary cases” in “Bounds and arithmetic review”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M09.06-C032-T08 · Delivery check:** Run a known-valid control and a deliberately failing control for “Bounds and arithmetic review”; confirm the harness distinguishes their observed outcomes.
- [ ] **UC-M09.06-C032-T09 · Patch review:** Review the “Bounds and arithmetic review” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M09.06-C032-T10 · Delivery handoff:** Publish the “Bounds and arithmetic review” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M09.06-C033 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Untrusted sizes cannot silently overflow into unsafe access. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M09.06-C033-T01 · Named property:** Create a stable property/check name under this parent for “Bounds and arithmetic review”; copy its required invariant exactly: “Untrusted sizes cannot silently overflow into unsafe access”.
- [ ] **UC-M09.06-C033-T02 · Observable terms:** Define each term in the “Bounds and arithmetic review” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M09.06-C033-T03 · Precondition set:** List the preconditions under which “Untrusted sizes cannot silently overflow into unsafe access” must hold for “Bounds and arithmetic review”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M09.06-C033-T04 · Transition coverage:** Map the “Bounds and arithmetic review” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M09.06-C033-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Bounds and arithmetic review”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M09.06-C033-T06 · Satisfying fixture:** Create a concrete “Bounds and arithmetic review” case that satisfies “Untrusted sizes cannot silently overflow into unsafe access”; record its expected observation before running the assertion or review.
- [ ] **UC-M09.06-C033-T07 · Violating fixture:** Create the source counterexample “A malformed image triggers a wrapped allocation calculation” for “Bounds and arithmetic review”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M09.06-C033-T08 · Enforcement evidence:** Exercise the “Bounds and arithmetic review” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M09.06-C033-T09 · Regression linkage:** Link the “Bounds and arithmetic review” property to changes in actual native targets, instrumented builds and reproducible adversarial corpora; record which dependency or contract changes require rerunning it.
- [ ] **UC-M09.06-C033-T10 · Property disposition:** Compare the satisfying and violating “Bounds and arithmetic review” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M09.06-C034 · Integration

**Original checklist item:** Integrate bounds and arithmetic review with actual native targets, instrumented builds and reproducible adversarial corpora; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M09.06-C034-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Bounds and arithmetic review” across actual native targets, instrumented builds and reproducible adversarial corpora; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M09.06-C034-T02 · Field mapping:** Map every “Bounds and arithmetic review” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M09.06-C034-T03 · Prerequisite identities:** Record the actual prerequisites for “Bounds and arithmetic review” (source dependency list: UC-M02.08, UC-M03.02); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M09.06-C034-T04 · Ownership agreement:** Specify who owns “Bounds and arithmetic review” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M09.06-C034-T05 · Handoff implementation:** Connect “Bounds and arithmetic review” through the mapped seam using the real adapter or explicit specification reference; preserve “Untrusted sizes cannot silently overflow into unsafe access” across the handoff.
- [ ] **UC-M09.06-C034-T06 · Absent-input case:** Omit one required “Bounds and arithmetic review” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M09.06-C034-T07 · Stale-input case:** Supply an outdated “Bounds and arithmetic review” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M09.06-C034-T08 · Incompatible-input case:** Supply an incompatible “Bounds and arithmetic review” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M09.06-C034-T09 · Valid integration trace:** Run a valid “Bounds and arithmetic review” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M09.06-C034-T10 · Seam review:** Reconcile the “Bounds and arithmetic review” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M09.06-C035 · Valid-case test

**Original checklist item:** Run a known-valid control for bounds and arithmetic review; verify that the harness reaches its intended target and compare observed measurements or verdicts with predeclared expectations.

- [ ] **UC-M09.06-C035-T01 · Valid fixture choice:** Choose a known-valid control for “Bounds and arithmetic review”; document why it should pass and how it proves the harness reaches the intended target.
- [ ] **UC-M09.06-C035-T02 · Expected-result oracle:** Specify the “Bounds and arithmetic review” expected result independently of the implementation output; include the property “Untrusted sizes cannot silently overflow into unsafe access” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M09.06-C035-T03 · Fixture material:** Create the concrete “Bounds and arithmetic review” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M09.06-C035-T04 · Target preparation:** Prepare the “Bounds and arithmetic review” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M09.06-C035-T05 · Initial-state record:** Record the initial “Bounds and arithmetic review” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M09.06-C035-T06 · Valid-path execution:** Run the “Bounds and arithmetic review” known-valid control on the identified target; retain enough observations to prove the correct target was exercised.
- [ ] **UC-M09.06-C035-T07 · Outcome comparison:** Compare every declared “Bounds and arithmetic review” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M09.06-C035-T08 · State and bounds check:** Inspect the “Bounds and arithmetic review” ownership/state effects and actual use of “Reviewed functions and integer boundary cases”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M09.06-C035-T09 · Repeatability check:** Repeat the same “Bounds and arithmetic review” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M09.06-C035-T10 · Positive evidence:** Attach the “Bounds and arithmetic review” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M09.06-C036 · Negative test

**Original checklist item:** Negative case: A malformed image triggers a wrapped allocation calculation. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M09.06-C036-T01 · Adverse-case definition:** Create a test record for the exact “Bounds and arithmetic review” source counterexample: “A malformed image triggers a wrapped allocation calculation”; state which precondition or invariant it challenges.
- [ ] **UC-M09.06-C036-T02 · Safe fixture boundary:** Define the contained test boundary for “Bounds and arithmetic review”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M09.06-C036-T03 · Valid control:** Construct a valid “Bounds and arithmetic review” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M09.06-C036-T04 · Minimal adverse input:** Derive the “Bounds and arithmetic review” adverse fixture from the control with the smallest documented change needed to reproduce “A malformed image triggers a wrapped allocation calculation”; retain that change as reproducible data.
- [ ] **UC-M09.06-C036-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Bounds and arithmetic review”; require “Untrusted sizes cannot silently overflow into unsafe access” and forbid a false-success verdict.
- [ ] **UC-M09.06-C036-T06 · Adverse execution:** Exercise the “Bounds and arithmetic review” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M09.06-C036-T07 · Effect inspection:** Inspect “Bounds and arithmetic review” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M09.06-C036-T08 · Refusal versus failure:** Confirm the “Bounds and arithmetic review” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M09.06-C036-T09 · Reset and retention:** Restore only the disposable “Bounds and arithmetic review” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M09.06-C036-T10 · Negative regression:** Register the “Bounds and arithmetic review” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M09.06-C037 · Change / failure test

**Original checklist item:** Exercise bounds and arithmetic review when a native runtime update changes code previously covered by a clean campaign; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M09.06-C037-T01 · Scenario record:** Write the “Bounds and arithmetic review” change/failure scenario exactly as supplied: a native runtime update changes code previously covered by a clean campaign; identify the property that must remain true: “Untrusted sizes cannot silently overflow into unsafe access”.
- [ ] **UC-M09.06-C037-T02 · Baseline capture:** Create a known-valid “Bounds and arithmetic review” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M09.06-C037-T03 · Injection map:** Locate the “Bounds and arithmetic review” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M09.06-C037-T04 · Disposition oracle:** Define the legal intermediate and final “Bounds and arithmetic review” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M09.06-C037-T05 · Controlled trigger:** Introduce the controlled “Bounds and arithmetic review” scenario in the disposable fixture: a native runtime update changes code previously covered by a clean campaign; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M09.06-C037-T06 · Intermediate inspection:** Inspect the “Bounds and arithmetic review” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M09.06-C037-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Bounds and arithmetic review”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M09.06-C037-T08 · Stale-evidence cleanup:** Invalidate superseded “Bounds and arithmetic review” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M09.06-C037-T09 · Repeat and compare:** Repeat the selected “Bounds and arithmetic review” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M09.06-C037-T10 · Failure evidence:** Publish the “Bounds and arithmetic review” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M09.06-C038 · Bounds

**Original checklist item:** Set a documented campaign budget for reviewed functions and integer boundary cases; record actual consumption, incomplete coverage and the disposition when the budget is exhausted.

- [ ] **UC-M09.06-C038-T01 · Quantity inventory:** Create a measurement inventory for “Bounds and arithmetic review”: “Reviewed functions and integer boundary cases”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M09.06-C038-T02 · Measurement method:** Choose how to observe each “Bounds and arithmetic review” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M09.06-C038-T03 · Budget decision:** Select justified campaign and target-resource budgets for “Bounds and arithmetic review”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M09.06-C038-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Bounds and arithmetic review” cases for “Reviewed functions and integer boundary cases”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M09.06-C038-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Bounds and arithmetic review” limit; preserve “Untrusted sizes cannot silently overflow into unsafe access”.
- [ ] **UC-M09.06-C038-T06 · Normal measurement:** Run or review the normal “Bounds and arithmetic review” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M09.06-C038-T07 · At-limit measurement:** Exercise the “Bounds and arithmetic review” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M09.06-C038-T08 · Over-limit measurement:** Exercise the “Bounds and arithmetic review” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M09.06-C038-T09 · Uncovered-scope report:** List the “Bounds and arithmetic review” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M09.06-C038-T10 · Limit evidence:** Publish the selected “Bounds and arithmetic review” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M09.06-C039 · Diagnostics / review

**Original checklist item:** Report bounds and arithmetic review results with executed, failed, skipped and unavailable cases separated; preserve the underlying observations and do not manufacture missing measurements.

- [ ] **UC-M09.06-C039-T01 · Result inventory:** Enumerate the required “Bounds and arithmetic review” qualification cases and intended targets before aggregating results; keep the planned denominator visible.
- [ ] **UC-M09.06-C039-T02 · Verdict schema:** Define separate executed-pass, executed-fail, skipped, unavailable and untested outcomes for “Bounds and arithmetic review”; document how incomplete cases block relevant claims.
- [ ] **UC-M09.06-C039-T03 · Identity fields:** Attach the actual target, fixture, configuration and revision identifiers to each “Bounds and arithmetic review” result; do not attribute host-only evidence to a guest or another OS.
- [ ] **UC-M09.06-C039-T04 · Observation capture:** Capture bounded raw “Bounds and arithmetic review” observations and harness errors; retain enough information to verify the reported oracle comparison.
- [ ] **UC-M09.06-C039-T05 · Aggregation rules:** Implement the “Bounds and arithmetic review” count/reduction rule so failures and missing measurements cannot disappear; preserve “Untrusted sizes cannot silently overflow into unsafe access”.
- [ ] **UC-M09.06-C039-T06 · Failure visibility:** Feed a failing “Bounds and arithmetic review” control through the report path; assert the exact failed case and underlying observation remain visible.
- [ ] **UC-M09.06-C039-T07 · Missing-result visibility:** Withhold a required “Bounds and arithmetic review” measurement or target; verify the report uses unavailable/untested rather than a fabricated zero or passing value.
- [ ] **UC-M09.06-C039-T08 · Bounds and redaction:** Check “Bounds and arithmetic review” report size and retention against “Reviewed functions and integer boundary cases”; remove secrets while retaining fixture and subject references.
- [ ] **UC-M09.06-C039-T09 · Report reconciliation:** Reconcile the “Bounds and arithmetic review” summary with every underlying case record; account for the full planned denominator and all omitted scope.
- [ ] **UC-M09.06-C039-T10 · Qualification handoff:** Publish the “Bounds and arithmetic review” report with measured observations, coverage limits and blockers; state which actual targets remain unqualified.

### UC-M09.06-C040 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for bounds and arithmetic review; label unexecuted checks as untested.

- [ ] **UC-M09.06-C040-T01 · Evidence inventory:** List the “Bounds and arithmetic review” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M09.06-C040-T02 · Artifact references:** Record the exact “Bounds and arithmetic review” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M09.06-C040-T03 · Fixture references:** Attach the “Bounds and arithmetic review” fixture IDs, input identities and oracle definition; preserve the source counterexample “A malformed image triggers a wrapped allocation calculation” as a distinct evidence case.
- [ ] **UC-M09.06-C040-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Bounds and arithmetic review”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M09.06-C040-T05 · Environment record:** Record the actual “Bounds and arithmetic review” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M09.06-C040-T06 · Expected versus observed:** Pair every “Bounds and arithmetic review” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M09.06-C040-T07 · Failure and limit records:** Attach “Bounds and arithmetic review” change/failure and bounds evidence where required; include uncovered “Reviewed functions and integer boundary cases” and unresolved violations of “Untrusted sizes cannot silently overflow into unsafe access”.
- [ ] **UC-M09.06-C040-T08 · Evidence hygiene:** Check the “Bounds and arithmetic review” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M09.06-C040-T09 · Reproduction review:** Have the “Bounds and arithmetic review” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M09.06-C040-T10 · Acceptance linkage:** Link the “Bounds and arithmetic review” evidence to its parent and UC-M09.06 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 05. Memory ownership review

**Source delivery:** Check allocation ownership, release paths and error cleanup in native runtimes.

**Source invariant:** A failure path cannot leak or reuse invalid ownership silently.

**Source negative case:** A parser error frees a buffer that another path still uses.

**Source bounded quantities:** Ownership sites and review scope.

### UC-M09.06-C041 · Contract

**Original checklist item:** Define the qualification objective for memory ownership review, including the actual target implementation, prerequisites, observable oracle and explicit exclusions.

- [ ] **UC-M09.06-C041-T01 · Scope statement:** Write the qualification question for “Memory ownership review”; identify the actual target, claimed capability and observations that can answer that question.
- [ ] **UC-M09.06-C041-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Memory ownership review”; record each producer, representation and missing-value meaning.
- [ ] **UC-M09.06-C041-T03 · Output inventory:** List the outputs of “Memory ownership review” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M09.06-C041-T04 · Field dictionary:** Create a field-and-term dictionary for “Memory ownership review”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M09.06-C041-T05 · Prerequisite contract:** Map “Memory ownership review” to the source component prerequisites (UC-M02.08, UC-M03.02); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M09.06-C041-T06 · Authority map:** Identify who may produce, change and consume “Memory ownership review”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M09.06-C041-T07 · Invariant clause:** Add a normative clause for “Memory ownership review” that preserves “A failure path cannot leak or reuse invalid ownership silently”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M09.06-C041-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Memory ownership review”; include the source counterexample “A parser error frees a buffer that another path still uses” and the intended safe disposition.
- [ ] **UC-M09.06-C041-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Ownership sites and review scope” in the “Memory ownership review” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M09.06-C041-T10 · Contract review:** Review the “Memory ownership review” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M09.06-C042 · Delivery

**Original checklist item:** Check allocation ownership, release paths and error cleanup in native runtimes.

- [ ] **UC-M09.06-C042-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Memory ownership review”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M09.06-C042-T02 · Change plan:** Break the source delivery for “Memory ownership review” into concrete edit targets and reviewable outputs; keep the UC-M09.06 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M09.06-C042-T03 · Core artifact:** Create the “Memory ownership review” fixture or harness for this source instruction: Check allocation ownership, release paths and error cleanup in native runtimes.
- [ ] **UC-M09.06-C042-T04 · Concrete realization:** Connect the “Memory ownership review” harness to its actual intended target, set the expected oracle before running it, and distinguish a mock/control run from a target run.
- [ ] **UC-M09.06-C042-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Memory ownership review” needed to preserve “A failure path cannot leak or reuse invalid ownership silently”; record an enforcement gap where only a model exists.
- [ ] **UC-M09.06-C042-T06 · Dependency connection:** Connect the “Memory ownership review” qualification artifact to actual native targets, instrumented builds and reproducible adversarial corpora; record the target identity and what the harness actually exercises.
- [ ] **UC-M09.06-C042-T07 · Resource behavior:** Account for “Ownership sites and review scope” in “Memory ownership review”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M09.06-C042-T08 · Delivery check:** Run a known-valid control and a deliberately failing control for “Memory ownership review”; confirm the harness distinguishes their observed outcomes.
- [ ] **UC-M09.06-C042-T09 · Patch review:** Review the “Memory ownership review” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M09.06-C042-T10 · Delivery handoff:** Publish the “Memory ownership review” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M09.06-C043 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: A failure path cannot leak or reuse invalid ownership silently. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M09.06-C043-T01 · Named property:** Create a stable property/check name under this parent for “Memory ownership review”; copy its required invariant exactly: “A failure path cannot leak or reuse invalid ownership silently”.
- [ ] **UC-M09.06-C043-T02 · Observable terms:** Define each term in the “Memory ownership review” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M09.06-C043-T03 · Precondition set:** List the preconditions under which “A failure path cannot leak or reuse invalid ownership silently” must hold for “Memory ownership review”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M09.06-C043-T04 · Transition coverage:** Map the “Memory ownership review” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M09.06-C043-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Memory ownership review”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M09.06-C043-T06 · Satisfying fixture:** Create a concrete “Memory ownership review” case that satisfies “A failure path cannot leak or reuse invalid ownership silently”; record its expected observation before running the assertion or review.
- [ ] **UC-M09.06-C043-T07 · Violating fixture:** Create the source counterexample “A parser error frees a buffer that another path still uses” for “Memory ownership review”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M09.06-C043-T08 · Enforcement evidence:** Exercise the “Memory ownership review” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M09.06-C043-T09 · Regression linkage:** Link the “Memory ownership review” property to changes in actual native targets, instrumented builds and reproducible adversarial corpora; record which dependency or contract changes require rerunning it.
- [ ] **UC-M09.06-C043-T10 · Property disposition:** Compare the satisfying and violating “Memory ownership review” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M09.06-C044 · Integration

**Original checklist item:** Integrate memory ownership review with actual native targets, instrumented builds and reproducible adversarial corpora; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M09.06-C044-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Memory ownership review” across actual native targets, instrumented builds and reproducible adversarial corpora; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M09.06-C044-T02 · Field mapping:** Map every “Memory ownership review” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M09.06-C044-T03 · Prerequisite identities:** Record the actual prerequisites for “Memory ownership review” (source dependency list: UC-M02.08, UC-M03.02); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M09.06-C044-T04 · Ownership agreement:** Specify who owns “Memory ownership review” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M09.06-C044-T05 · Handoff implementation:** Connect “Memory ownership review” through the mapped seam using the real adapter or explicit specification reference; preserve “A failure path cannot leak or reuse invalid ownership silently” across the handoff.
- [ ] **UC-M09.06-C044-T06 · Absent-input case:** Omit one required “Memory ownership review” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M09.06-C044-T07 · Stale-input case:** Supply an outdated “Memory ownership review” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M09.06-C044-T08 · Incompatible-input case:** Supply an incompatible “Memory ownership review” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M09.06-C044-T09 · Valid integration trace:** Run a valid “Memory ownership review” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M09.06-C044-T10 · Seam review:** Reconcile the “Memory ownership review” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M09.06-C045 · Valid-case test

**Original checklist item:** Run a known-valid control for memory ownership review; verify that the harness reaches its intended target and compare observed measurements or verdicts with predeclared expectations.

- [ ] **UC-M09.06-C045-T01 · Valid fixture choice:** Choose a known-valid control for “Memory ownership review”; document why it should pass and how it proves the harness reaches the intended target.
- [ ] **UC-M09.06-C045-T02 · Expected-result oracle:** Specify the “Memory ownership review” expected result independently of the implementation output; include the property “A failure path cannot leak or reuse invalid ownership silently” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M09.06-C045-T03 · Fixture material:** Create the concrete “Memory ownership review” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M09.06-C045-T04 · Target preparation:** Prepare the “Memory ownership review” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M09.06-C045-T05 · Initial-state record:** Record the initial “Memory ownership review” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M09.06-C045-T06 · Valid-path execution:** Run the “Memory ownership review” known-valid control on the identified target; retain enough observations to prove the correct target was exercised.
- [ ] **UC-M09.06-C045-T07 · Outcome comparison:** Compare every declared “Memory ownership review” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M09.06-C045-T08 · State and bounds check:** Inspect the “Memory ownership review” ownership/state effects and actual use of “Ownership sites and review scope”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M09.06-C045-T09 · Repeatability check:** Repeat the same “Memory ownership review” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M09.06-C045-T10 · Positive evidence:** Attach the “Memory ownership review” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M09.06-C046 · Negative test

**Original checklist item:** Negative case: A parser error frees a buffer that another path still uses. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M09.06-C046-T01 · Adverse-case definition:** Create a test record for the exact “Memory ownership review” source counterexample: “A parser error frees a buffer that another path still uses”; state which precondition or invariant it challenges.
- [ ] **UC-M09.06-C046-T02 · Safe fixture boundary:** Define the contained test boundary for “Memory ownership review”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M09.06-C046-T03 · Valid control:** Construct a valid “Memory ownership review” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M09.06-C046-T04 · Minimal adverse input:** Derive the “Memory ownership review” adverse fixture from the control with the smallest documented change needed to reproduce “A parser error frees a buffer that another path still uses”; retain that change as reproducible data.
- [ ] **UC-M09.06-C046-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Memory ownership review”; require “A failure path cannot leak or reuse invalid ownership silently” and forbid a false-success verdict.
- [ ] **UC-M09.06-C046-T06 · Adverse execution:** Exercise the “Memory ownership review” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M09.06-C046-T07 · Effect inspection:** Inspect “Memory ownership review” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M09.06-C046-T08 · Refusal versus failure:** Confirm the “Memory ownership review” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M09.06-C046-T09 · Reset and retention:** Restore only the disposable “Memory ownership review” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M09.06-C046-T10 · Negative regression:** Register the “Memory ownership review” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M09.06-C047 · Change / failure test

**Original checklist item:** Exercise memory ownership review when a native runtime update changes code previously covered by a clean campaign; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M09.06-C047-T01 · Scenario record:** Write the “Memory ownership review” change/failure scenario exactly as supplied: a native runtime update changes code previously covered by a clean campaign; identify the property that must remain true: “A failure path cannot leak or reuse invalid ownership silently”.
- [ ] **UC-M09.06-C047-T02 · Baseline capture:** Create a known-valid “Memory ownership review” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M09.06-C047-T03 · Injection map:** Locate the “Memory ownership review” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M09.06-C047-T04 · Disposition oracle:** Define the legal intermediate and final “Memory ownership review” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M09.06-C047-T05 · Controlled trigger:** Introduce the controlled “Memory ownership review” scenario in the disposable fixture: a native runtime update changes code previously covered by a clean campaign; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M09.06-C047-T06 · Intermediate inspection:** Inspect the “Memory ownership review” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M09.06-C047-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Memory ownership review”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M09.06-C047-T08 · Stale-evidence cleanup:** Invalidate superseded “Memory ownership review” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M09.06-C047-T09 · Repeat and compare:** Repeat the selected “Memory ownership review” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M09.06-C047-T10 · Failure evidence:** Publish the “Memory ownership review” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M09.06-C048 · Bounds

**Original checklist item:** Set a documented campaign budget for ownership sites and review scope; record actual consumption, incomplete coverage and the disposition when the budget is exhausted.

- [ ] **UC-M09.06-C048-T01 · Quantity inventory:** Create a measurement inventory for “Memory ownership review”: “Ownership sites and review scope”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M09.06-C048-T02 · Measurement method:** Choose how to observe each “Memory ownership review” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M09.06-C048-T03 · Budget decision:** Select justified campaign and target-resource budgets for “Memory ownership review”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M09.06-C048-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Memory ownership review” cases for “Ownership sites and review scope”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M09.06-C048-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Memory ownership review” limit; preserve “A failure path cannot leak or reuse invalid ownership silently”.
- [ ] **UC-M09.06-C048-T06 · Normal measurement:** Run or review the normal “Memory ownership review” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M09.06-C048-T07 · At-limit measurement:** Exercise the “Memory ownership review” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M09.06-C048-T08 · Over-limit measurement:** Exercise the “Memory ownership review” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M09.06-C048-T09 · Uncovered-scope report:** List the “Memory ownership review” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M09.06-C048-T10 · Limit evidence:** Publish the selected “Memory ownership review” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M09.06-C049 · Diagnostics / review

**Original checklist item:** Report memory ownership review results with executed, failed, skipped and unavailable cases separated; preserve the underlying observations and do not manufacture missing measurements.

- [ ] **UC-M09.06-C049-T01 · Result inventory:** Enumerate the required “Memory ownership review” qualification cases and intended targets before aggregating results; keep the planned denominator visible.
- [ ] **UC-M09.06-C049-T02 · Verdict schema:** Define separate executed-pass, executed-fail, skipped, unavailable and untested outcomes for “Memory ownership review”; document how incomplete cases block relevant claims.
- [ ] **UC-M09.06-C049-T03 · Identity fields:** Attach the actual target, fixture, configuration and revision identifiers to each “Memory ownership review” result; do not attribute host-only evidence to a guest or another OS.
- [ ] **UC-M09.06-C049-T04 · Observation capture:** Capture bounded raw “Memory ownership review” observations and harness errors; retain enough information to verify the reported oracle comparison.
- [ ] **UC-M09.06-C049-T05 · Aggregation rules:** Implement the “Memory ownership review” count/reduction rule so failures and missing measurements cannot disappear; preserve “A failure path cannot leak or reuse invalid ownership silently”.
- [ ] **UC-M09.06-C049-T06 · Failure visibility:** Feed a failing “Memory ownership review” control through the report path; assert the exact failed case and underlying observation remain visible.
- [ ] **UC-M09.06-C049-T07 · Missing-result visibility:** Withhold a required “Memory ownership review” measurement or target; verify the report uses unavailable/untested rather than a fabricated zero or passing value.
- [ ] **UC-M09.06-C049-T08 · Bounds and redaction:** Check “Memory ownership review” report size and retention against “Ownership sites and review scope”; remove secrets while retaining fixture and subject references.
- [ ] **UC-M09.06-C049-T09 · Report reconciliation:** Reconcile the “Memory ownership review” summary with every underlying case record; account for the full planned denominator and all omitted scope.
- [ ] **UC-M09.06-C049-T10 · Qualification handoff:** Publish the “Memory ownership review” report with measured observations, coverage limits and blockers; state which actual targets remain unqualified.

### UC-M09.06-C050 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for memory ownership review; label unexecuted checks as untested.

- [ ] **UC-M09.06-C050-T01 · Evidence inventory:** List the “Memory ownership review” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M09.06-C050-T02 · Artifact references:** Record the exact “Memory ownership review” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M09.06-C050-T03 · Fixture references:** Attach the “Memory ownership review” fixture IDs, input identities and oracle definition; preserve the source counterexample “A parser error frees a buffer that another path still uses” as a distinct evidence case.
- [ ] **UC-M09.06-C050-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Memory ownership review”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M09.06-C050-T05 · Environment record:** Record the actual “Memory ownership review” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M09.06-C050-T06 · Expected versus observed:** Pair every “Memory ownership review” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M09.06-C050-T07 · Failure and limit records:** Attach “Memory ownership review” change/failure and bounds evidence where required; include uncovered “Ownership sites and review scope” and unresolved violations of “A failure path cannot leak or reuse invalid ownership silently”.
- [ ] **UC-M09.06-C050-T08 · Evidence hygiene:** Check the “Memory ownership review” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M09.06-C050-T09 · Reproduction review:** Have the “Memory ownership review” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M09.06-C050-T10 · Acceptance linkage:** Link the “Memory ownership review” evidence to its parent and UC-M09.06 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 06. Native parser harnesses

**Source delivery:** Build isolated harnesses around actual image and bytecode parsing interfaces.

**Source invariant:** Harnesses exercise production parser logic rather than unrelated substitutes.

**Source negative case:** A harness validates headers but never calls the real loader.

**Source bounded quantities:** Harness count and input bytes.

### UC-M09.06-C051 · Contract

**Original checklist item:** Define the qualification objective for native parser harnesses, including the actual target implementation, prerequisites, observable oracle and explicit exclusions.

- [ ] **UC-M09.06-C051-T01 · Scope statement:** Write the qualification question for “Native parser harnesses”; identify the actual target, claimed capability and observations that can answer that question.
- [ ] **UC-M09.06-C051-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Native parser harnesses”; record each producer, representation and missing-value meaning.
- [ ] **UC-M09.06-C051-T03 · Output inventory:** List the outputs of “Native parser harnesses” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M09.06-C051-T04 · Field dictionary:** Create a field-and-term dictionary for “Native parser harnesses”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M09.06-C051-T05 · Prerequisite contract:** Map “Native parser harnesses” to the source component prerequisites (UC-M02.08, UC-M03.02); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M09.06-C051-T06 · Authority map:** Identify who may produce, change and consume “Native parser harnesses”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M09.06-C051-T07 · Invariant clause:** Add a normative clause for “Native parser harnesses” that preserves “Harnesses exercise production parser logic rather than unrelated substitutes”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M09.06-C051-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Native parser harnesses”; include the source counterexample “A harness validates headers but never calls the real loader” and the intended safe disposition.
- [ ] **UC-M09.06-C051-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Harness count and input bytes” in the “Native parser harnesses” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M09.06-C051-T10 · Contract review:** Review the “Native parser harnesses” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M09.06-C052 · Delivery

**Original checklist item:** Build isolated harnesses around actual image and bytecode parsing interfaces.

- [ ] **UC-M09.06-C052-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Native parser harnesses”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M09.06-C052-T02 · Change plan:** Break the source delivery for “Native parser harnesses” into concrete edit targets and reviewable outputs; keep the UC-M09.06 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M09.06-C052-T03 · Core artifact:** Implement the smallest selected-profile change for “Native parser harnesses” that realizes this source instruction: Build isolated harnesses around actual image and bytecode parsing interfaces.
- [ ] **UC-M09.06-C052-T04 · Concrete realization:** Trace “Native parser harnesses” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M09.06-C052-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Native parser harnesses” needed to preserve “Harnesses exercise production parser logic rather than unrelated substitutes”; record an enforcement gap where only a model exists.
- [ ] **UC-M09.06-C052-T06 · Dependency connection:** Connect the “Native parser harnesses” qualification artifact to actual native targets, instrumented builds and reproducible adversarial corpora; record the target identity and what the harness actually exercises.
- [ ] **UC-M09.06-C052-T07 · Resource behavior:** Account for “Harness count and input bytes” in “Native parser harnesses”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M09.06-C052-T08 · Delivery check:** Run a known-valid control and a deliberately failing control for “Native parser harnesses”; confirm the harness distinguishes their observed outcomes.
- [ ] **UC-M09.06-C052-T09 · Patch review:** Review the “Native parser harnesses” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M09.06-C052-T10 · Delivery handoff:** Publish the “Native parser harnesses” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M09.06-C053 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Harnesses exercise production parser logic rather than unrelated substitutes. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M09.06-C053-T01 · Named property:** Create a stable property/check name under this parent for “Native parser harnesses”; copy its required invariant exactly: “Harnesses exercise production parser logic rather than unrelated substitutes”.
- [ ] **UC-M09.06-C053-T02 · Observable terms:** Define each term in the “Native parser harnesses” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M09.06-C053-T03 · Precondition set:** List the preconditions under which “Harnesses exercise production parser logic rather than unrelated substitutes” must hold for “Native parser harnesses”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M09.06-C053-T04 · Transition coverage:** Map the “Native parser harnesses” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M09.06-C053-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Native parser harnesses”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M09.06-C053-T06 · Satisfying fixture:** Create a concrete “Native parser harnesses” case that satisfies “Harnesses exercise production parser logic rather than unrelated substitutes”; record its expected observation before running the assertion or review.
- [ ] **UC-M09.06-C053-T07 · Violating fixture:** Create the source counterexample “A harness validates headers but never calls the real loader” for “Native parser harnesses”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M09.06-C053-T08 · Enforcement evidence:** Exercise the “Native parser harnesses” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M09.06-C053-T09 · Regression linkage:** Link the “Native parser harnesses” property to changes in actual native targets, instrumented builds and reproducible adversarial corpora; record which dependency or contract changes require rerunning it.
- [ ] **UC-M09.06-C053-T10 · Property disposition:** Compare the satisfying and violating “Native parser harnesses” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M09.06-C054 · Integration

**Original checklist item:** Integrate native parser harnesses with actual native targets, instrumented builds and reproducible adversarial corpora; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M09.06-C054-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Native parser harnesses” across actual native targets, instrumented builds and reproducible adversarial corpora; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M09.06-C054-T02 · Field mapping:** Map every “Native parser harnesses” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M09.06-C054-T03 · Prerequisite identities:** Record the actual prerequisites for “Native parser harnesses” (source dependency list: UC-M02.08, UC-M03.02); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M09.06-C054-T04 · Ownership agreement:** Specify who owns “Native parser harnesses” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M09.06-C054-T05 · Handoff implementation:** Connect “Native parser harnesses” through the mapped seam using the real adapter or explicit specification reference; preserve “Harnesses exercise production parser logic rather than unrelated substitutes” across the handoff.
- [ ] **UC-M09.06-C054-T06 · Absent-input case:** Omit one required “Native parser harnesses” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M09.06-C054-T07 · Stale-input case:** Supply an outdated “Native parser harnesses” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M09.06-C054-T08 · Incompatible-input case:** Supply an incompatible “Native parser harnesses” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M09.06-C054-T09 · Valid integration trace:** Run a valid “Native parser harnesses” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M09.06-C054-T10 · Seam review:** Reconcile the “Native parser harnesses” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M09.06-C055 · Valid-case test

**Original checklist item:** Run a known-valid control for native parser harnesses; verify that the harness reaches its intended target and compare observed measurements or verdicts with predeclared expectations.

- [ ] **UC-M09.06-C055-T01 · Valid fixture choice:** Choose a known-valid control for “Native parser harnesses”; document why it should pass and how it proves the harness reaches the intended target.
- [ ] **UC-M09.06-C055-T02 · Expected-result oracle:** Specify the “Native parser harnesses” expected result independently of the implementation output; include the property “Harnesses exercise production parser logic rather than unrelated substitutes” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M09.06-C055-T03 · Fixture material:** Create the concrete “Native parser harnesses” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M09.06-C055-T04 · Target preparation:** Prepare the “Native parser harnesses” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M09.06-C055-T05 · Initial-state record:** Record the initial “Native parser harnesses” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M09.06-C055-T06 · Valid-path execution:** Run the “Native parser harnesses” known-valid control on the identified target; retain enough observations to prove the correct target was exercised.
- [ ] **UC-M09.06-C055-T07 · Outcome comparison:** Compare every declared “Native parser harnesses” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M09.06-C055-T08 · State and bounds check:** Inspect the “Native parser harnesses” ownership/state effects and actual use of “Harness count and input bytes”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M09.06-C055-T09 · Repeatability check:** Repeat the same “Native parser harnesses” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M09.06-C055-T10 · Positive evidence:** Attach the “Native parser harnesses” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M09.06-C056 · Negative test

**Original checklist item:** Negative case: A harness validates headers but never calls the real loader. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M09.06-C056-T01 · Adverse-case definition:** Create a test record for the exact “Native parser harnesses” source counterexample: “A harness validates headers but never calls the real loader”; state which precondition or invariant it challenges.
- [ ] **UC-M09.06-C056-T02 · Safe fixture boundary:** Define the contained test boundary for “Native parser harnesses”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M09.06-C056-T03 · Valid control:** Construct a valid “Native parser harnesses” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M09.06-C056-T04 · Minimal adverse input:** Derive the “Native parser harnesses” adverse fixture from the control with the smallest documented change needed to reproduce “A harness validates headers but never calls the real loader”; retain that change as reproducible data.
- [ ] **UC-M09.06-C056-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Native parser harnesses”; require “Harnesses exercise production parser logic rather than unrelated substitutes” and forbid a false-success verdict.
- [ ] **UC-M09.06-C056-T06 · Adverse execution:** Exercise the “Native parser harnesses” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M09.06-C056-T07 · Effect inspection:** Inspect “Native parser harnesses” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M09.06-C056-T08 · Refusal versus failure:** Confirm the “Native parser harnesses” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M09.06-C056-T09 · Reset and retention:** Restore only the disposable “Native parser harnesses” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M09.06-C056-T10 · Negative regression:** Register the “Native parser harnesses” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M09.06-C057 · Change / failure test

**Original checklist item:** Exercise native parser harnesses when a native runtime update changes code previously covered by a clean campaign; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M09.06-C057-T01 · Scenario record:** Write the “Native parser harnesses” change/failure scenario exactly as supplied: a native runtime update changes code previously covered by a clean campaign; identify the property that must remain true: “Harnesses exercise production parser logic rather than unrelated substitutes”.
- [ ] **UC-M09.06-C057-T02 · Baseline capture:** Create a known-valid “Native parser harnesses” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M09.06-C057-T03 · Injection map:** Locate the “Native parser harnesses” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M09.06-C057-T04 · Disposition oracle:** Define the legal intermediate and final “Native parser harnesses” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M09.06-C057-T05 · Controlled trigger:** Introduce the controlled “Native parser harnesses” scenario in the disposable fixture: a native runtime update changes code previously covered by a clean campaign; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M09.06-C057-T06 · Intermediate inspection:** Inspect the “Native parser harnesses” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M09.06-C057-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Native parser harnesses”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M09.06-C057-T08 · Stale-evidence cleanup:** Invalidate superseded “Native parser harnesses” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M09.06-C057-T09 · Repeat and compare:** Repeat the selected “Native parser harnesses” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M09.06-C057-T10 · Failure evidence:** Publish the “Native parser harnesses” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M09.06-C058 · Bounds

**Original checklist item:** Set a documented campaign budget for harness count and input bytes; record actual consumption, incomplete coverage and the disposition when the budget is exhausted.

- [ ] **UC-M09.06-C058-T01 · Quantity inventory:** Create a measurement inventory for “Native parser harnesses”: “Harness count and input bytes”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M09.06-C058-T02 · Measurement method:** Choose how to observe each “Native parser harnesses” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M09.06-C058-T03 · Budget decision:** Select justified campaign and target-resource budgets for “Native parser harnesses”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M09.06-C058-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Native parser harnesses” cases for “Harness count and input bytes”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M09.06-C058-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Native parser harnesses” limit; preserve “Harnesses exercise production parser logic rather than unrelated substitutes”.
- [ ] **UC-M09.06-C058-T06 · Normal measurement:** Run or review the normal “Native parser harnesses” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M09.06-C058-T07 · At-limit measurement:** Exercise the “Native parser harnesses” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M09.06-C058-T08 · Over-limit measurement:** Exercise the “Native parser harnesses” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M09.06-C058-T09 · Uncovered-scope report:** List the “Native parser harnesses” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M09.06-C058-T10 · Limit evidence:** Publish the selected “Native parser harnesses” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M09.06-C059 · Diagnostics / review

**Original checklist item:** Report native parser harnesses results with executed, failed, skipped and unavailable cases separated; preserve the underlying observations and do not manufacture missing measurements.

- [ ] **UC-M09.06-C059-T01 · Result inventory:** Enumerate the required “Native parser harnesses” qualification cases and intended targets before aggregating results; keep the planned denominator visible.
- [ ] **UC-M09.06-C059-T02 · Verdict schema:** Define separate executed-pass, executed-fail, skipped, unavailable and untested outcomes for “Native parser harnesses”; document how incomplete cases block relevant claims.
- [ ] **UC-M09.06-C059-T03 · Identity fields:** Attach the actual target, fixture, configuration and revision identifiers to each “Native parser harnesses” result; do not attribute host-only evidence to a guest or another OS.
- [ ] **UC-M09.06-C059-T04 · Observation capture:** Capture bounded raw “Native parser harnesses” observations and harness errors; retain enough information to verify the reported oracle comparison.
- [ ] **UC-M09.06-C059-T05 · Aggregation rules:** Implement the “Native parser harnesses” count/reduction rule so failures and missing measurements cannot disappear; preserve “Harnesses exercise production parser logic rather than unrelated substitutes”.
- [ ] **UC-M09.06-C059-T06 · Failure visibility:** Feed a failing “Native parser harnesses” control through the report path; assert the exact failed case and underlying observation remain visible.
- [ ] **UC-M09.06-C059-T07 · Missing-result visibility:** Withhold a required “Native parser harnesses” measurement or target; verify the report uses unavailable/untested rather than a fabricated zero or passing value.
- [ ] **UC-M09.06-C059-T08 · Bounds and redaction:** Check “Native parser harnesses” report size and retention against “Harness count and input bytes”; remove secrets while retaining fixture and subject references.
- [ ] **UC-M09.06-C059-T09 · Report reconciliation:** Reconcile the “Native parser harnesses” summary with every underlying case record; account for the full planned denominator and all omitted scope.
- [ ] **UC-M09.06-C059-T10 · Qualification handoff:** Publish the “Native parser harnesses” report with measured observations, coverage limits and blockers; state which actual targets remain unqualified.

### UC-M09.06-C060 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for native parser harnesses; label unexecuted checks as untested.

- [ ] **UC-M09.06-C060-T01 · Evidence inventory:** List the “Native parser harnesses” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M09.06-C060-T02 · Artifact references:** Record the exact “Native parser harnesses” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M09.06-C060-T03 · Fixture references:** Attach the “Native parser harnesses” fixture IDs, input identities and oracle definition; preserve the source counterexample “A harness validates headers but never calls the real loader” as a distinct evidence case.
- [ ] **UC-M09.06-C060-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Native parser harnesses”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M09.06-C060-T05 · Environment record:** Record the actual “Native parser harnesses” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M09.06-C060-T06 · Expected versus observed:** Pair every “Native parser harnesses” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M09.06-C060-T07 · Failure and limit records:** Attach “Native parser harnesses” change/failure and bounds evidence where required; include uncovered “Harness count and input bytes” and unresolved violations of “Harnesses exercise production parser logic rather than unrelated substitutes”.
- [ ] **UC-M09.06-C060-T08 · Evidence hygiene:** Check the “Native parser harnesses” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M09.06-C060-T09 · Reproduction review:** Have the “Native parser harnesses” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M09.06-C060-T10 · Acceptance linkage:** Link the “Native parser harnesses” evidence to its parent and UC-M09.06 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 07. Adversarial corpus

**Source delivery:** Retain representative malformed image, bytecode and descriptor fixtures.

**Source invariant:** Known findings remain reproducible across future builds.

**Source negative case:** A crashing input is discarded without a regression fixture.

**Source bounded quantities:** Corpus bytes and minimization budget.

### UC-M09.06-C061 · Contract

**Original checklist item:** Define the qualification objective for adversarial corpus, including the actual target implementation, prerequisites, observable oracle and explicit exclusions.

- [ ] **UC-M09.06-C061-T01 · Scope statement:** Write the qualification question for “Adversarial corpus”; identify the actual target, claimed capability and observations that can answer that question.
- [ ] **UC-M09.06-C061-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Adversarial corpus”; record each producer, representation and missing-value meaning.
- [ ] **UC-M09.06-C061-T03 · Output inventory:** List the outputs of “Adversarial corpus” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M09.06-C061-T04 · Field dictionary:** Create a field-and-term dictionary for “Adversarial corpus”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M09.06-C061-T05 · Prerequisite contract:** Map “Adversarial corpus” to the source component prerequisites (UC-M02.08, UC-M03.02); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M09.06-C061-T06 · Authority map:** Identify who may produce, change and consume “Adversarial corpus”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M09.06-C061-T07 · Invariant clause:** Add a normative clause for “Adversarial corpus” that preserves “Known findings remain reproducible across future builds”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M09.06-C061-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Adversarial corpus”; include the source counterexample “A crashing input is discarded without a regression fixture” and the intended safe disposition.
- [ ] **UC-M09.06-C061-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Corpus bytes and minimization budget” in the “Adversarial corpus” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M09.06-C061-T10 · Contract review:** Review the “Adversarial corpus” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M09.06-C062 · Delivery

**Original checklist item:** Retain representative malformed image, bytecode and descriptor fixtures.

- [ ] **UC-M09.06-C062-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Adversarial corpus”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M09.06-C062-T02 · Change plan:** Break the source delivery for “Adversarial corpus” into concrete edit targets and reviewable outputs; keep the UC-M09.06 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M09.06-C062-T03 · Core artifact:** Implement the smallest selected-profile change for “Adversarial corpus” that realizes this source instruction: Retain representative malformed image, bytecode and descriptor fixtures.
- [ ] **UC-M09.06-C062-T04 · Concrete realization:** Trace “Adversarial corpus” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M09.06-C062-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Adversarial corpus” needed to preserve “Known findings remain reproducible across future builds”; record an enforcement gap where only a model exists.
- [ ] **UC-M09.06-C062-T06 · Dependency connection:** Connect the “Adversarial corpus” qualification artifact to actual native targets, instrumented builds and reproducible adversarial corpora; record the target identity and what the harness actually exercises.
- [ ] **UC-M09.06-C062-T07 · Resource behavior:** Account for “Corpus bytes and minimization budget” in “Adversarial corpus”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M09.06-C062-T08 · Delivery check:** Run a known-valid control and a deliberately failing control for “Adversarial corpus”; confirm the harness distinguishes their observed outcomes.
- [ ] **UC-M09.06-C062-T09 · Patch review:** Review the “Adversarial corpus” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M09.06-C062-T10 · Delivery handoff:** Publish the “Adversarial corpus” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M09.06-C063 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Known findings remain reproducible across future builds. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M09.06-C063-T01 · Named property:** Create a stable property/check name under this parent for “Adversarial corpus”; copy its required invariant exactly: “Known findings remain reproducible across future builds”.
- [ ] **UC-M09.06-C063-T02 · Observable terms:** Define each term in the “Adversarial corpus” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M09.06-C063-T03 · Precondition set:** List the preconditions under which “Known findings remain reproducible across future builds” must hold for “Adversarial corpus”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M09.06-C063-T04 · Transition coverage:** Map the “Adversarial corpus” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M09.06-C063-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Adversarial corpus”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M09.06-C063-T06 · Satisfying fixture:** Create a concrete “Adversarial corpus” case that satisfies “Known findings remain reproducible across future builds”; record its expected observation before running the assertion or review.
- [ ] **UC-M09.06-C063-T07 · Violating fixture:** Create the source counterexample “A crashing input is discarded without a regression fixture” for “Adversarial corpus”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M09.06-C063-T08 · Enforcement evidence:** Exercise the “Adversarial corpus” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M09.06-C063-T09 · Regression linkage:** Link the “Adversarial corpus” property to changes in actual native targets, instrumented builds and reproducible adversarial corpora; record which dependency or contract changes require rerunning it.
- [ ] **UC-M09.06-C063-T10 · Property disposition:** Compare the satisfying and violating “Adversarial corpus” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M09.06-C064 · Integration

**Original checklist item:** Integrate adversarial corpus with actual native targets, instrumented builds and reproducible adversarial corpora; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M09.06-C064-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Adversarial corpus” across actual native targets, instrumented builds and reproducible adversarial corpora; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M09.06-C064-T02 · Field mapping:** Map every “Adversarial corpus” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M09.06-C064-T03 · Prerequisite identities:** Record the actual prerequisites for “Adversarial corpus” (source dependency list: UC-M02.08, UC-M03.02); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M09.06-C064-T04 · Ownership agreement:** Specify who owns “Adversarial corpus” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M09.06-C064-T05 · Handoff implementation:** Connect “Adversarial corpus” through the mapped seam using the real adapter or explicit specification reference; preserve “Known findings remain reproducible across future builds” across the handoff.
- [ ] **UC-M09.06-C064-T06 · Absent-input case:** Omit one required “Adversarial corpus” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M09.06-C064-T07 · Stale-input case:** Supply an outdated “Adversarial corpus” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M09.06-C064-T08 · Incompatible-input case:** Supply an incompatible “Adversarial corpus” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M09.06-C064-T09 · Valid integration trace:** Run a valid “Adversarial corpus” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M09.06-C064-T10 · Seam review:** Reconcile the “Adversarial corpus” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M09.06-C065 · Valid-case test

**Original checklist item:** Run a known-valid control for adversarial corpus; verify that the harness reaches its intended target and compare observed measurements or verdicts with predeclared expectations.

- [ ] **UC-M09.06-C065-T01 · Valid fixture choice:** Choose a known-valid control for “Adversarial corpus”; document why it should pass and how it proves the harness reaches the intended target.
- [ ] **UC-M09.06-C065-T02 · Expected-result oracle:** Specify the “Adversarial corpus” expected result independently of the implementation output; include the property “Known findings remain reproducible across future builds” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M09.06-C065-T03 · Fixture material:** Create the concrete “Adversarial corpus” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M09.06-C065-T04 · Target preparation:** Prepare the “Adversarial corpus” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M09.06-C065-T05 · Initial-state record:** Record the initial “Adversarial corpus” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M09.06-C065-T06 · Valid-path execution:** Run the “Adversarial corpus” known-valid control on the identified target; retain enough observations to prove the correct target was exercised.
- [ ] **UC-M09.06-C065-T07 · Outcome comparison:** Compare every declared “Adversarial corpus” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M09.06-C065-T08 · State and bounds check:** Inspect the “Adversarial corpus” ownership/state effects and actual use of “Corpus bytes and minimization budget”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M09.06-C065-T09 · Repeatability check:** Repeat the same “Adversarial corpus” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M09.06-C065-T10 · Positive evidence:** Attach the “Adversarial corpus” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M09.06-C066 · Negative test

**Original checklist item:** Negative case: A crashing input is discarded without a regression fixture. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M09.06-C066-T01 · Adverse-case definition:** Create a test record for the exact “Adversarial corpus” source counterexample: “A crashing input is discarded without a regression fixture”; state which precondition or invariant it challenges.
- [ ] **UC-M09.06-C066-T02 · Safe fixture boundary:** Define the contained test boundary for “Adversarial corpus”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M09.06-C066-T03 · Valid control:** Construct a valid “Adversarial corpus” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M09.06-C066-T04 · Minimal adverse input:** Derive the “Adversarial corpus” adverse fixture from the control with the smallest documented change needed to reproduce “A crashing input is discarded without a regression fixture”; retain that change as reproducible data.
- [ ] **UC-M09.06-C066-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Adversarial corpus”; require “Known findings remain reproducible across future builds” and forbid a false-success verdict.
- [ ] **UC-M09.06-C066-T06 · Adverse execution:** Exercise the “Adversarial corpus” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M09.06-C066-T07 · Effect inspection:** Inspect “Adversarial corpus” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M09.06-C066-T08 · Refusal versus failure:** Confirm the “Adversarial corpus” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M09.06-C066-T09 · Reset and retention:** Restore only the disposable “Adversarial corpus” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M09.06-C066-T10 · Negative regression:** Register the “Adversarial corpus” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M09.06-C067 · Change / failure test

**Original checklist item:** Exercise adversarial corpus when a native runtime update changes code previously covered by a clean campaign; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M09.06-C067-T01 · Scenario record:** Write the “Adversarial corpus” change/failure scenario exactly as supplied: a native runtime update changes code previously covered by a clean campaign; identify the property that must remain true: “Known findings remain reproducible across future builds”.
- [ ] **UC-M09.06-C067-T02 · Baseline capture:** Create a known-valid “Adversarial corpus” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M09.06-C067-T03 · Injection map:** Locate the “Adversarial corpus” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M09.06-C067-T04 · Disposition oracle:** Define the legal intermediate and final “Adversarial corpus” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M09.06-C067-T05 · Controlled trigger:** Introduce the controlled “Adversarial corpus” scenario in the disposable fixture: a native runtime update changes code previously covered by a clean campaign; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M09.06-C067-T06 · Intermediate inspection:** Inspect the “Adversarial corpus” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M09.06-C067-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Adversarial corpus”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M09.06-C067-T08 · Stale-evidence cleanup:** Invalidate superseded “Adversarial corpus” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M09.06-C067-T09 · Repeat and compare:** Repeat the selected “Adversarial corpus” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M09.06-C067-T10 · Failure evidence:** Publish the “Adversarial corpus” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M09.06-C068 · Bounds

**Original checklist item:** Set a documented campaign budget for corpus bytes and minimization budget; record actual consumption, incomplete coverage and the disposition when the budget is exhausted.

- [ ] **UC-M09.06-C068-T01 · Quantity inventory:** Create a measurement inventory for “Adversarial corpus”: “Corpus bytes and minimization budget”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M09.06-C068-T02 · Measurement method:** Choose how to observe each “Adversarial corpus” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M09.06-C068-T03 · Budget decision:** Select justified campaign and target-resource budgets for “Adversarial corpus”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M09.06-C068-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Adversarial corpus” cases for “Corpus bytes and minimization budget”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M09.06-C068-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Adversarial corpus” limit; preserve “Known findings remain reproducible across future builds”.
- [ ] **UC-M09.06-C068-T06 · Normal measurement:** Run or review the normal “Adversarial corpus” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M09.06-C068-T07 · At-limit measurement:** Exercise the “Adversarial corpus” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M09.06-C068-T08 · Over-limit measurement:** Exercise the “Adversarial corpus” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M09.06-C068-T09 · Uncovered-scope report:** List the “Adversarial corpus” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M09.06-C068-T10 · Limit evidence:** Publish the selected “Adversarial corpus” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M09.06-C069 · Diagnostics / review

**Original checklist item:** Report adversarial corpus results with executed, failed, skipped and unavailable cases separated; preserve the underlying observations and do not manufacture missing measurements.

- [ ] **UC-M09.06-C069-T01 · Result inventory:** Enumerate the required “Adversarial corpus” qualification cases and intended targets before aggregating results; keep the planned denominator visible.
- [ ] **UC-M09.06-C069-T02 · Verdict schema:** Define separate executed-pass, executed-fail, skipped, unavailable and untested outcomes for “Adversarial corpus”; document how incomplete cases block relevant claims.
- [ ] **UC-M09.06-C069-T03 · Identity fields:** Attach the actual target, fixture, configuration and revision identifiers to each “Adversarial corpus” result; do not attribute host-only evidence to a guest or another OS.
- [ ] **UC-M09.06-C069-T04 · Observation capture:** Capture bounded raw “Adversarial corpus” observations and harness errors; retain enough information to verify the reported oracle comparison.
- [ ] **UC-M09.06-C069-T05 · Aggregation rules:** Implement the “Adversarial corpus” count/reduction rule so failures and missing measurements cannot disappear; preserve “Known findings remain reproducible across future builds”.
- [ ] **UC-M09.06-C069-T06 · Failure visibility:** Feed a failing “Adversarial corpus” control through the report path; assert the exact failed case and underlying observation remain visible.
- [ ] **UC-M09.06-C069-T07 · Missing-result visibility:** Withhold a required “Adversarial corpus” measurement or target; verify the report uses unavailable/untested rather than a fabricated zero or passing value.
- [ ] **UC-M09.06-C069-T08 · Bounds and redaction:** Check “Adversarial corpus” report size and retention against “Corpus bytes and minimization budget”; remove secrets while retaining fixture and subject references.
- [ ] **UC-M09.06-C069-T09 · Report reconciliation:** Reconcile the “Adversarial corpus” summary with every underlying case record; account for the full planned denominator and all omitted scope.
- [ ] **UC-M09.06-C069-T10 · Qualification handoff:** Publish the “Adversarial corpus” report with measured observations, coverage limits and blockers; state which actual targets remain unqualified.

### UC-M09.06-C070 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for adversarial corpus; label unexecuted checks as untested.

- [ ] **UC-M09.06-C070-T01 · Evidence inventory:** List the “Adversarial corpus” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M09.06-C070-T02 · Artifact references:** Record the exact “Adversarial corpus” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M09.06-C070-T03 · Fixture references:** Attach the “Adversarial corpus” fixture IDs, input identities and oracle definition; preserve the source counterexample “A crashing input is discarded without a regression fixture” as a distinct evidence case.
- [ ] **UC-M09.06-C070-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Adversarial corpus”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M09.06-C070-T05 · Environment record:** Record the actual “Adversarial corpus” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M09.06-C070-T06 · Expected versus observed:** Pair every “Adversarial corpus” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M09.06-C070-T07 · Failure and limit records:** Attach “Adversarial corpus” change/failure and bounds evidence where required; include uncovered “Corpus bytes and minimization budget” and unresolved violations of “Known findings remain reproducible across future builds”.
- [ ] **UC-M09.06-C070-T08 · Evidence hygiene:** Check the “Adversarial corpus” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M09.06-C070-T09 · Reproduction review:** Have the “Adversarial corpus” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M09.06-C070-T10 · Acceptance linkage:** Link the “Adversarial corpus” evidence to its parent and UC-M09.06 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 08. Finding triage

**Source delivery:** Record each sanitizer or native fault with reproduction, affected code and disposition.

**Source invariant:** Unresolved findings remain explicit blockers for the relevant claim.

**Source negative case:** A sanitizer finding is ignored because the process exits successfully.

**Source bounded quantities:** Open findings and triage backlog.

### UC-M09.06-C071 · Contract

**Original checklist item:** Define the qualification objective for finding triage, including the actual target implementation, prerequisites, observable oracle and explicit exclusions.

- [ ] **UC-M09.06-C071-T01 · Scope statement:** Write the qualification question for “Finding triage”; identify the actual target, claimed capability and observations that can answer that question.
- [ ] **UC-M09.06-C071-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Finding triage”; record each producer, representation and missing-value meaning.
- [ ] **UC-M09.06-C071-T03 · Output inventory:** List the outputs of “Finding triage” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M09.06-C071-T04 · Field dictionary:** Create a field-and-term dictionary for “Finding triage”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M09.06-C071-T05 · Prerequisite contract:** Map “Finding triage” to the source component prerequisites (UC-M02.08, UC-M03.02); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M09.06-C071-T06 · Authority map:** Identify who may produce, change and consume “Finding triage”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M09.06-C071-T07 · Invariant clause:** Add a normative clause for “Finding triage” that preserves “Unresolved findings remain explicit blockers for the relevant claim”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M09.06-C071-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Finding triage”; include the source counterexample “A sanitizer finding is ignored because the process exits successfully” and the intended safe disposition.
- [ ] **UC-M09.06-C071-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Open findings and triage backlog” in the “Finding triage” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M09.06-C071-T10 · Contract review:** Review the “Finding triage” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M09.06-C072 · Delivery

**Original checklist item:** Record each sanitizer or native fault with reproduction, affected code and disposition.

- [ ] **UC-M09.06-C072-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Finding triage”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M09.06-C072-T02 · Change plan:** Break the source delivery for “Finding triage” into concrete edit targets and reviewable outputs; keep the UC-M09.06 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M09.06-C072-T03 · Core artifact:** Create the “Finding triage” model, schema or inventory that realizes this source instruction: Record each sanitizer or native fault with reproduction, affected code and disposition.
- [ ] **UC-M09.06-C072-T04 · Concrete realization:** Populate “Finding triage” with one concrete worked case; map every required entity or field to its source and flag any unmapped entry.
- [ ] **UC-M09.06-C072-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Finding triage” needed to preserve “Unresolved findings remain explicit blockers for the relevant claim”; record an enforcement gap where only a model exists.
- [ ] **UC-M09.06-C072-T06 · Dependency connection:** Connect the “Finding triage” qualification artifact to actual native targets, instrumented builds and reproducible adversarial corpora; record the target identity and what the harness actually exercises.
- [ ] **UC-M09.06-C072-T07 · Resource behavior:** Account for “Open findings and triage backlog” in “Finding triage”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M09.06-C072-T08 · Delivery check:** Run a known-valid control and a deliberately failing control for “Finding triage”; confirm the harness distinguishes their observed outcomes.
- [ ] **UC-M09.06-C072-T09 · Patch review:** Review the “Finding triage” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M09.06-C072-T10 · Delivery handoff:** Publish the “Finding triage” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M09.06-C073 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Unresolved findings remain explicit blockers for the relevant claim. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M09.06-C073-T01 · Named property:** Create a stable property/check name under this parent for “Finding triage”; copy its required invariant exactly: “Unresolved findings remain explicit blockers for the relevant claim”.
- [ ] **UC-M09.06-C073-T02 · Observable terms:** Define each term in the “Finding triage” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M09.06-C073-T03 · Precondition set:** List the preconditions under which “Unresolved findings remain explicit blockers for the relevant claim” must hold for “Finding triage”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M09.06-C073-T04 · Transition coverage:** Map the “Finding triage” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M09.06-C073-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Finding triage”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M09.06-C073-T06 · Satisfying fixture:** Create a concrete “Finding triage” case that satisfies “Unresolved findings remain explicit blockers for the relevant claim”; record its expected observation before running the assertion or review.
- [ ] **UC-M09.06-C073-T07 · Violating fixture:** Create the source counterexample “A sanitizer finding is ignored because the process exits successfully” for “Finding triage”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M09.06-C073-T08 · Enforcement evidence:** Exercise the “Finding triage” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M09.06-C073-T09 · Regression linkage:** Link the “Finding triage” property to changes in actual native targets, instrumented builds and reproducible adversarial corpora; record which dependency or contract changes require rerunning it.
- [ ] **UC-M09.06-C073-T10 · Property disposition:** Compare the satisfying and violating “Finding triage” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M09.06-C074 · Integration

**Original checklist item:** Integrate finding triage with actual native targets, instrumented builds and reproducible adversarial corpora; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M09.06-C074-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Finding triage” across actual native targets, instrumented builds and reproducible adversarial corpora; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M09.06-C074-T02 · Field mapping:** Map every “Finding triage” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M09.06-C074-T03 · Prerequisite identities:** Record the actual prerequisites for “Finding triage” (source dependency list: UC-M02.08, UC-M03.02); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M09.06-C074-T04 · Ownership agreement:** Specify who owns “Finding triage” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M09.06-C074-T05 · Handoff implementation:** Connect “Finding triage” through the mapped seam using the real adapter or explicit specification reference; preserve “Unresolved findings remain explicit blockers for the relevant claim” across the handoff.
- [ ] **UC-M09.06-C074-T06 · Absent-input case:** Omit one required “Finding triage” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M09.06-C074-T07 · Stale-input case:** Supply an outdated “Finding triage” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M09.06-C074-T08 · Incompatible-input case:** Supply an incompatible “Finding triage” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M09.06-C074-T09 · Valid integration trace:** Run a valid “Finding triage” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M09.06-C074-T10 · Seam review:** Reconcile the “Finding triage” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M09.06-C075 · Valid-case test

**Original checklist item:** Run a known-valid control for finding triage; verify that the harness reaches its intended target and compare observed measurements or verdicts with predeclared expectations.

- [ ] **UC-M09.06-C075-T01 · Valid fixture choice:** Choose a known-valid control for “Finding triage”; document why it should pass and how it proves the harness reaches the intended target.
- [ ] **UC-M09.06-C075-T02 · Expected-result oracle:** Specify the “Finding triage” expected result independently of the implementation output; include the property “Unresolved findings remain explicit blockers for the relevant claim” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M09.06-C075-T03 · Fixture material:** Create the concrete “Finding triage” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M09.06-C075-T04 · Target preparation:** Prepare the “Finding triage” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M09.06-C075-T05 · Initial-state record:** Record the initial “Finding triage” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M09.06-C075-T06 · Valid-path execution:** Run the “Finding triage” known-valid control on the identified target; retain enough observations to prove the correct target was exercised.
- [ ] **UC-M09.06-C075-T07 · Outcome comparison:** Compare every declared “Finding triage” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M09.06-C075-T08 · State and bounds check:** Inspect the “Finding triage” ownership/state effects and actual use of “Open findings and triage backlog”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M09.06-C075-T09 · Repeatability check:** Repeat the same “Finding triage” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M09.06-C075-T10 · Positive evidence:** Attach the “Finding triage” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M09.06-C076 · Negative test

**Original checklist item:** Negative case: A sanitizer finding is ignored because the process exits successfully. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M09.06-C076-T01 · Adverse-case definition:** Create a test record for the exact “Finding triage” source counterexample: “A sanitizer finding is ignored because the process exits successfully”; state which precondition or invariant it challenges.
- [ ] **UC-M09.06-C076-T02 · Safe fixture boundary:** Define the contained test boundary for “Finding triage”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M09.06-C076-T03 · Valid control:** Construct a valid “Finding triage” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M09.06-C076-T04 · Minimal adverse input:** Derive the “Finding triage” adverse fixture from the control with the smallest documented change needed to reproduce “A sanitizer finding is ignored because the process exits successfully”; retain that change as reproducible data.
- [ ] **UC-M09.06-C076-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Finding triage”; require “Unresolved findings remain explicit blockers for the relevant claim” and forbid a false-success verdict.
- [ ] **UC-M09.06-C076-T06 · Adverse execution:** Exercise the “Finding triage” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M09.06-C076-T07 · Effect inspection:** Inspect “Finding triage” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M09.06-C076-T08 · Refusal versus failure:** Confirm the “Finding triage” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M09.06-C076-T09 · Reset and retention:** Restore only the disposable “Finding triage” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M09.06-C076-T10 · Negative regression:** Register the “Finding triage” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M09.06-C077 · Change / failure test

**Original checklist item:** Exercise finding triage when a native runtime update changes code previously covered by a clean campaign; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M09.06-C077-T01 · Scenario record:** Write the “Finding triage” change/failure scenario exactly as supplied: a native runtime update changes code previously covered by a clean campaign; identify the property that must remain true: “Unresolved findings remain explicit blockers for the relevant claim”.
- [ ] **UC-M09.06-C077-T02 · Baseline capture:** Create a known-valid “Finding triage” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M09.06-C077-T03 · Injection map:** Locate the “Finding triage” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M09.06-C077-T04 · Disposition oracle:** Define the legal intermediate and final “Finding triage” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M09.06-C077-T05 · Controlled trigger:** Introduce the controlled “Finding triage” scenario in the disposable fixture: a native runtime update changes code previously covered by a clean campaign; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M09.06-C077-T06 · Intermediate inspection:** Inspect the “Finding triage” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M09.06-C077-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Finding triage”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M09.06-C077-T08 · Stale-evidence cleanup:** Invalidate superseded “Finding triage” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M09.06-C077-T09 · Repeat and compare:** Repeat the selected “Finding triage” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M09.06-C077-T10 · Failure evidence:** Publish the “Finding triage” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M09.06-C078 · Bounds

**Original checklist item:** Set a documented campaign budget for open findings and triage backlog; record actual consumption, incomplete coverage and the disposition when the budget is exhausted.

- [ ] **UC-M09.06-C078-T01 · Quantity inventory:** Create a measurement inventory for “Finding triage”: “Open findings and triage backlog”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M09.06-C078-T02 · Measurement method:** Choose how to observe each “Finding triage” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M09.06-C078-T03 · Budget decision:** Select justified campaign and target-resource budgets for “Finding triage”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M09.06-C078-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Finding triage” cases for “Open findings and triage backlog”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M09.06-C078-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Finding triage” limit; preserve “Unresolved findings remain explicit blockers for the relevant claim”.
- [ ] **UC-M09.06-C078-T06 · Normal measurement:** Run or review the normal “Finding triage” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M09.06-C078-T07 · At-limit measurement:** Exercise the “Finding triage” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M09.06-C078-T08 · Over-limit measurement:** Exercise the “Finding triage” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M09.06-C078-T09 · Uncovered-scope report:** List the “Finding triage” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M09.06-C078-T10 · Limit evidence:** Publish the selected “Finding triage” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M09.06-C079 · Diagnostics / review

**Original checklist item:** Report finding triage results with executed, failed, skipped and unavailable cases separated; preserve the underlying observations and do not manufacture missing measurements.

- [ ] **UC-M09.06-C079-T01 · Result inventory:** Enumerate the required “Finding triage” qualification cases and intended targets before aggregating results; keep the planned denominator visible.
- [ ] **UC-M09.06-C079-T02 · Verdict schema:** Define separate executed-pass, executed-fail, skipped, unavailable and untested outcomes for “Finding triage”; document how incomplete cases block relevant claims.
- [ ] **UC-M09.06-C079-T03 · Identity fields:** Attach the actual target, fixture, configuration and revision identifiers to each “Finding triage” result; do not attribute host-only evidence to a guest or another OS.
- [ ] **UC-M09.06-C079-T04 · Observation capture:** Capture bounded raw “Finding triage” observations and harness errors; retain enough information to verify the reported oracle comparison.
- [ ] **UC-M09.06-C079-T05 · Aggregation rules:** Implement the “Finding triage” count/reduction rule so failures and missing measurements cannot disappear; preserve “Unresolved findings remain explicit blockers for the relevant claim”.
- [ ] **UC-M09.06-C079-T06 · Failure visibility:** Feed a failing “Finding triage” control through the report path; assert the exact failed case and underlying observation remain visible.
- [ ] **UC-M09.06-C079-T07 · Missing-result visibility:** Withhold a required “Finding triage” measurement or target; verify the report uses unavailable/untested rather than a fabricated zero or passing value.
- [ ] **UC-M09.06-C079-T08 · Bounds and redaction:** Check “Finding triage” report size and retention against “Open findings and triage backlog”; remove secrets while retaining fixture and subject references.
- [ ] **UC-M09.06-C079-T09 · Report reconciliation:** Reconcile the “Finding triage” summary with every underlying case record; account for the full planned denominator and all omitted scope.
- [ ] **UC-M09.06-C079-T10 · Qualification handoff:** Publish the “Finding triage” report with measured observations, coverage limits and blockers; state which actual targets remain unqualified.

### UC-M09.06-C080 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for finding triage; label unexecuted checks as untested.

- [ ] **UC-M09.06-C080-T01 · Evidence inventory:** List the “Finding triage” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M09.06-C080-T02 · Artifact references:** Record the exact “Finding triage” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M09.06-C080-T03 · Fixture references:** Attach the “Finding triage” fixture IDs, input identities and oracle definition; preserve the source counterexample “A sanitizer finding is ignored because the process exits successfully” as a distinct evidence case.
- [ ] **UC-M09.06-C080-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Finding triage”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M09.06-C080-T05 · Environment record:** Record the actual “Finding triage” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M09.06-C080-T06 · Expected versus observed:** Pair every “Finding triage” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M09.06-C080-T07 · Failure and limit records:** Attach “Finding triage” change/failure and bounds evidence where required; include uncovered “Open findings and triage backlog” and unresolved violations of “Unresolved findings remain explicit blockers for the relevant claim”.
- [ ] **UC-M09.06-C080-T08 · Evidence hygiene:** Check the “Finding triage” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M09.06-C080-T09 · Reproduction review:** Have the “Finding triage” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M09.06-C080-T10 · Acceptance linkage:** Link the “Finding triage” evidence to its parent and UC-M09.06 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 09. Fix regression qualification

**Source delivery:** Retest repaired cases and adjacent boundary variations on the actual targets.

**Source invariant:** A claimed fix has observed regression evidence.

**Source negative case:** A patch is marked complete without replaying the triggering input.

**Source bounded quantities:** Regression cases and target matrix.

### UC-M09.06-C081 · Contract

**Original checklist item:** Define the qualification objective for fix regression qualification, including the actual target implementation, prerequisites, observable oracle and explicit exclusions.

- [ ] **UC-M09.06-C081-T01 · Scope statement:** Write the qualification question for “Fix regression qualification”; identify the actual target, claimed capability and observations that can answer that question.
- [ ] **UC-M09.06-C081-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Fix regression qualification”; record each producer, representation and missing-value meaning.
- [ ] **UC-M09.06-C081-T03 · Output inventory:** List the outputs of “Fix regression qualification” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M09.06-C081-T04 · Field dictionary:** Create a field-and-term dictionary for “Fix regression qualification”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M09.06-C081-T05 · Prerequisite contract:** Map “Fix regression qualification” to the source component prerequisites (UC-M02.08, UC-M03.02); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M09.06-C081-T06 · Authority map:** Identify who may produce, change and consume “Fix regression qualification”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M09.06-C081-T07 · Invariant clause:** Add a normative clause for “Fix regression qualification” that preserves “A claimed fix has observed regression evidence”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M09.06-C081-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Fix regression qualification”; include the source counterexample “A patch is marked complete without replaying the triggering input” and the intended safe disposition.
- [ ] **UC-M09.06-C081-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Regression cases and target matrix” in the “Fix regression qualification” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M09.06-C081-T10 · Contract review:** Review the “Fix regression qualification” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M09.06-C082 · Delivery

**Original checklist item:** Retest repaired cases and adjacent boundary variations on the actual targets.

- [ ] **UC-M09.06-C082-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Fix regression qualification”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M09.06-C082-T02 · Change plan:** Break the source delivery for “Fix regression qualification” into concrete edit targets and reviewable outputs; keep the UC-M09.06 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M09.06-C082-T03 · Core artifact:** Create the “Fix regression qualification” fixture or harness for this source instruction: Retest repaired cases and adjacent boundary variations on the actual targets.
- [ ] **UC-M09.06-C082-T04 · Concrete realization:** Connect the “Fix regression qualification” harness to its actual intended target, set the expected oracle before running it, and distinguish a mock/control run from a target run.
- [ ] **UC-M09.06-C082-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Fix regression qualification” needed to preserve “A claimed fix has observed regression evidence”; record an enforcement gap where only a model exists.
- [ ] **UC-M09.06-C082-T06 · Dependency connection:** Connect the “Fix regression qualification” qualification artifact to actual native targets, instrumented builds and reproducible adversarial corpora; record the target identity and what the harness actually exercises.
- [ ] **UC-M09.06-C082-T07 · Resource behavior:** Account for “Regression cases and target matrix” in “Fix regression qualification”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M09.06-C082-T08 · Delivery check:** Run a known-valid control and a deliberately failing control for “Fix regression qualification”; confirm the harness distinguishes their observed outcomes.
- [ ] **UC-M09.06-C082-T09 · Patch review:** Review the “Fix regression qualification” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M09.06-C082-T10 · Delivery handoff:** Publish the “Fix regression qualification” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M09.06-C083 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: A claimed fix has observed regression evidence. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M09.06-C083-T01 · Named property:** Create a stable property/check name under this parent for “Fix regression qualification”; copy its required invariant exactly: “A claimed fix has observed regression evidence”.
- [ ] **UC-M09.06-C083-T02 · Observable terms:** Define each term in the “Fix regression qualification” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M09.06-C083-T03 · Precondition set:** List the preconditions under which “A claimed fix has observed regression evidence” must hold for “Fix regression qualification”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M09.06-C083-T04 · Transition coverage:** Map the “Fix regression qualification” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M09.06-C083-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Fix regression qualification”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M09.06-C083-T06 · Satisfying fixture:** Create a concrete “Fix regression qualification” case that satisfies “A claimed fix has observed regression evidence”; record its expected observation before running the assertion or review.
- [ ] **UC-M09.06-C083-T07 · Violating fixture:** Create the source counterexample “A patch is marked complete without replaying the triggering input” for “Fix regression qualification”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M09.06-C083-T08 · Enforcement evidence:** Exercise the “Fix regression qualification” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M09.06-C083-T09 · Regression linkage:** Link the “Fix regression qualification” property to changes in actual native targets, instrumented builds and reproducible adversarial corpora; record which dependency or contract changes require rerunning it.
- [ ] **UC-M09.06-C083-T10 · Property disposition:** Compare the satisfying and violating “Fix regression qualification” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M09.06-C084 · Integration

**Original checklist item:** Integrate fix regression qualification with actual native targets, instrumented builds and reproducible adversarial corpora; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M09.06-C084-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Fix regression qualification” across actual native targets, instrumented builds and reproducible adversarial corpora; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M09.06-C084-T02 · Field mapping:** Map every “Fix regression qualification” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M09.06-C084-T03 · Prerequisite identities:** Record the actual prerequisites for “Fix regression qualification” (source dependency list: UC-M02.08, UC-M03.02); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M09.06-C084-T04 · Ownership agreement:** Specify who owns “Fix regression qualification” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M09.06-C084-T05 · Handoff implementation:** Connect “Fix regression qualification” through the mapped seam using the real adapter or explicit specification reference; preserve “A claimed fix has observed regression evidence” across the handoff.
- [ ] **UC-M09.06-C084-T06 · Absent-input case:** Omit one required “Fix regression qualification” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M09.06-C084-T07 · Stale-input case:** Supply an outdated “Fix regression qualification” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M09.06-C084-T08 · Incompatible-input case:** Supply an incompatible “Fix regression qualification” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M09.06-C084-T09 · Valid integration trace:** Run a valid “Fix regression qualification” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M09.06-C084-T10 · Seam review:** Reconcile the “Fix regression qualification” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M09.06-C085 · Valid-case test

**Original checklist item:** Run a known-valid control for fix regression qualification; verify that the harness reaches its intended target and compare observed measurements or verdicts with predeclared expectations.

- [ ] **UC-M09.06-C085-T01 · Valid fixture choice:** Choose a known-valid control for “Fix regression qualification”; document why it should pass and how it proves the harness reaches the intended target.
- [ ] **UC-M09.06-C085-T02 · Expected-result oracle:** Specify the “Fix regression qualification” expected result independently of the implementation output; include the property “A claimed fix has observed regression evidence” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M09.06-C085-T03 · Fixture material:** Create the concrete “Fix regression qualification” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M09.06-C085-T04 · Target preparation:** Prepare the “Fix regression qualification” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M09.06-C085-T05 · Initial-state record:** Record the initial “Fix regression qualification” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M09.06-C085-T06 · Valid-path execution:** Run the “Fix regression qualification” known-valid control on the identified target; retain enough observations to prove the correct target was exercised.
- [ ] **UC-M09.06-C085-T07 · Outcome comparison:** Compare every declared “Fix regression qualification” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M09.06-C085-T08 · State and bounds check:** Inspect the “Fix regression qualification” ownership/state effects and actual use of “Regression cases and target matrix”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M09.06-C085-T09 · Repeatability check:** Repeat the same “Fix regression qualification” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M09.06-C085-T10 · Positive evidence:** Attach the “Fix regression qualification” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M09.06-C086 · Negative test

**Original checklist item:** Negative case: A patch is marked complete without replaying the triggering input. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M09.06-C086-T01 · Adverse-case definition:** Create a test record for the exact “Fix regression qualification” source counterexample: “A patch is marked complete without replaying the triggering input”; state which precondition or invariant it challenges.
- [ ] **UC-M09.06-C086-T02 · Safe fixture boundary:** Define the contained test boundary for “Fix regression qualification”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M09.06-C086-T03 · Valid control:** Construct a valid “Fix regression qualification” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M09.06-C086-T04 · Minimal adverse input:** Derive the “Fix regression qualification” adverse fixture from the control with the smallest documented change needed to reproduce “A patch is marked complete without replaying the triggering input”; retain that change as reproducible data.
- [ ] **UC-M09.06-C086-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Fix regression qualification”; require “A claimed fix has observed regression evidence” and forbid a false-success verdict.
- [ ] **UC-M09.06-C086-T06 · Adverse execution:** Exercise the “Fix regression qualification” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M09.06-C086-T07 · Effect inspection:** Inspect “Fix regression qualification” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M09.06-C086-T08 · Refusal versus failure:** Confirm the “Fix regression qualification” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M09.06-C086-T09 · Reset and retention:** Restore only the disposable “Fix regression qualification” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M09.06-C086-T10 · Negative regression:** Register the “Fix regression qualification” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M09.06-C087 · Change / failure test

**Original checklist item:** Exercise fix regression qualification when a native runtime update changes code previously covered by a clean campaign; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M09.06-C087-T01 · Scenario record:** Write the “Fix regression qualification” change/failure scenario exactly as supplied: a native runtime update changes code previously covered by a clean campaign; identify the property that must remain true: “A claimed fix has observed regression evidence”.
- [ ] **UC-M09.06-C087-T02 · Baseline capture:** Create a known-valid “Fix regression qualification” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M09.06-C087-T03 · Injection map:** Locate the “Fix regression qualification” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M09.06-C087-T04 · Disposition oracle:** Define the legal intermediate and final “Fix regression qualification” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M09.06-C087-T05 · Controlled trigger:** Introduce the controlled “Fix regression qualification” scenario in the disposable fixture: a native runtime update changes code previously covered by a clean campaign; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M09.06-C087-T06 · Intermediate inspection:** Inspect the “Fix regression qualification” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M09.06-C087-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Fix regression qualification”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M09.06-C087-T08 · Stale-evidence cleanup:** Invalidate superseded “Fix regression qualification” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M09.06-C087-T09 · Repeat and compare:** Repeat the selected “Fix regression qualification” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M09.06-C087-T10 · Failure evidence:** Publish the “Fix regression qualification” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M09.06-C088 · Bounds

**Original checklist item:** Set a documented campaign budget for regression cases and target matrix; record actual consumption, incomplete coverage and the disposition when the budget is exhausted.

- [ ] **UC-M09.06-C088-T01 · Quantity inventory:** Create a measurement inventory for “Fix regression qualification”: “Regression cases and target matrix”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M09.06-C088-T02 · Measurement method:** Choose how to observe each “Fix regression qualification” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M09.06-C088-T03 · Budget decision:** Select justified campaign and target-resource budgets for “Fix regression qualification”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M09.06-C088-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Fix regression qualification” cases for “Regression cases and target matrix”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M09.06-C088-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Fix regression qualification” limit; preserve “A claimed fix has observed regression evidence”.
- [ ] **UC-M09.06-C088-T06 · Normal measurement:** Run or review the normal “Fix regression qualification” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M09.06-C088-T07 · At-limit measurement:** Exercise the “Fix regression qualification” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M09.06-C088-T08 · Over-limit measurement:** Exercise the “Fix regression qualification” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M09.06-C088-T09 · Uncovered-scope report:** List the “Fix regression qualification” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M09.06-C088-T10 · Limit evidence:** Publish the selected “Fix regression qualification” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M09.06-C089 · Diagnostics / review

**Original checklist item:** Report fix regression qualification results with executed, failed, skipped and unavailable cases separated; preserve the underlying observations and do not manufacture missing measurements.

- [ ] **UC-M09.06-C089-T01 · Result inventory:** Enumerate the required “Fix regression qualification” qualification cases and intended targets before aggregating results; keep the planned denominator visible.
- [ ] **UC-M09.06-C089-T02 · Verdict schema:** Define separate executed-pass, executed-fail, skipped, unavailable and untested outcomes for “Fix regression qualification”; document how incomplete cases block relevant claims.
- [ ] **UC-M09.06-C089-T03 · Identity fields:** Attach the actual target, fixture, configuration and revision identifiers to each “Fix regression qualification” result; do not attribute host-only evidence to a guest or another OS.
- [ ] **UC-M09.06-C089-T04 · Observation capture:** Capture bounded raw “Fix regression qualification” observations and harness errors; retain enough information to verify the reported oracle comparison.
- [ ] **UC-M09.06-C089-T05 · Aggregation rules:** Implement the “Fix regression qualification” count/reduction rule so failures and missing measurements cannot disappear; preserve “A claimed fix has observed regression evidence”.
- [ ] **UC-M09.06-C089-T06 · Failure visibility:** Feed a failing “Fix regression qualification” control through the report path; assert the exact failed case and underlying observation remain visible.
- [ ] **UC-M09.06-C089-T07 · Missing-result visibility:** Withhold a required “Fix regression qualification” measurement or target; verify the report uses unavailable/untested rather than a fabricated zero or passing value.
- [ ] **UC-M09.06-C089-T08 · Bounds and redaction:** Check “Fix regression qualification” report size and retention against “Regression cases and target matrix”; remove secrets while retaining fixture and subject references.
- [ ] **UC-M09.06-C089-T09 · Report reconciliation:** Reconcile the “Fix regression qualification” summary with every underlying case record; account for the full planned denominator and all omitted scope.
- [ ] **UC-M09.06-C089-T10 · Qualification handoff:** Publish the “Fix regression qualification” report with measured observations, coverage limits and blockers; state which actual targets remain unqualified.

### UC-M09.06-C090 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for fix regression qualification; label unexecuted checks as untested.

- [ ] **UC-M09.06-C090-T01 · Evidence inventory:** List the “Fix regression qualification” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M09.06-C090-T02 · Artifact references:** Record the exact “Fix regression qualification” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M09.06-C090-T03 · Fixture references:** Attach the “Fix regression qualification” fixture IDs, input identities and oracle definition; preserve the source counterexample “A patch is marked complete without replaying the triggering input” as a distinct evidence case.
- [ ] **UC-M09.06-C090-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Fix regression qualification”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M09.06-C090-T05 · Environment record:** Record the actual “Fix regression qualification” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M09.06-C090-T06 · Expected versus observed:** Pair every “Fix regression qualification” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M09.06-C090-T07 · Failure and limit records:** Attach “Fix regression qualification” change/failure and bounds evidence where required; include uncovered “Regression cases and target matrix” and unresolved violations of “A claimed fix has observed regression evidence”.
- [ ] **UC-M09.06-C090-T08 · Evidence hygiene:** Check the “Fix regression qualification” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M09.06-C090-T09 · Reproduction review:** Have the “Fix regression qualification” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M09.06-C090-T10 · Acceptance linkage:** Link the “Fix regression qualification” evidence to its parent and UC-M09.06 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 10. Native safety gate

**Source delivery:** Run the budgeted corpus and require no unexplained diagnostic findings.

**Source invariant:** A clean run is scoped evidence rather than proof of universal memory safety.

**Source negative case:** A skipped instrumented target is counted as a passing target.

**Source bounded quantities:** Campaign duration and required target coverage.

### UC-M09.06-C091 · Contract

**Original checklist item:** Define the qualification objective for native safety gate, including the actual target implementation, prerequisites, observable oracle and explicit exclusions.

- [ ] **UC-M09.06-C091-T01 · Scope statement:** Write the qualification question for “Native safety gate”; identify the actual target, claimed capability and observations that can answer that question.
- [ ] **UC-M09.06-C091-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Native safety gate”; record each producer, representation and missing-value meaning.
- [ ] **UC-M09.06-C091-T03 · Output inventory:** List the outputs of “Native safety gate” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M09.06-C091-T04 · Field dictionary:** Create a field-and-term dictionary for “Native safety gate”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M09.06-C091-T05 · Prerequisite contract:** Map “Native safety gate” to the source component prerequisites (UC-M02.08, UC-M03.02); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M09.06-C091-T06 · Authority map:** Identify who may produce, change and consume “Native safety gate”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M09.06-C091-T07 · Invariant clause:** Add a normative clause for “Native safety gate” that preserves “A clean run is scoped evidence rather than proof of universal memory safety”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M09.06-C091-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Native safety gate”; include the source counterexample “A skipped instrumented target is counted as a passing target” and the intended safe disposition.
- [ ] **UC-M09.06-C091-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Campaign duration and required target coverage” in the “Native safety gate” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M09.06-C091-T10 · Contract review:** Review the “Native safety gate” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M09.06-C092 · Delivery

**Original checklist item:** Run the budgeted corpus and require no unexplained diagnostic findings.

- [ ] **UC-M09.06-C092-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Native safety gate”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M09.06-C092-T02 · Change plan:** Break the source delivery for “Native safety gate” into concrete edit targets and reviewable outputs; keep the UC-M09.06 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M09.06-C092-T03 · Core artifact:** Create the “Native safety gate” fixture or harness for this source instruction: Run the budgeted corpus and require no unexplained diagnostic findings.
- [ ] **UC-M09.06-C092-T04 · Concrete realization:** Connect the “Native safety gate” harness to its actual intended target, set the expected oracle before running it, and distinguish a mock/control run from a target run.
- [ ] **UC-M09.06-C092-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Native safety gate” needed to preserve “A clean run is scoped evidence rather than proof of universal memory safety”; record an enforcement gap where only a model exists.
- [ ] **UC-M09.06-C092-T06 · Dependency connection:** Connect the “Native safety gate” qualification artifact to actual native targets, instrumented builds and reproducible adversarial corpora; record the target identity and what the harness actually exercises.
- [ ] **UC-M09.06-C092-T07 · Resource behavior:** Account for “Campaign duration and required target coverage” in “Native safety gate”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M09.06-C092-T08 · Delivery check:** Run a known-valid control and a deliberately failing control for “Native safety gate”; confirm the harness distinguishes their observed outcomes.
- [ ] **UC-M09.06-C092-T09 · Patch review:** Review the “Native safety gate” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M09.06-C092-T10 · Delivery handoff:** Publish the “Native safety gate” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M09.06-C093 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: A clean run is scoped evidence rather than proof of universal memory safety. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M09.06-C093-T01 · Named property:** Create a stable property/check name under this parent for “Native safety gate”; copy its required invariant exactly: “A clean run is scoped evidence rather than proof of universal memory safety”.
- [ ] **UC-M09.06-C093-T02 · Observable terms:** Define each term in the “Native safety gate” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M09.06-C093-T03 · Precondition set:** List the preconditions under which “A clean run is scoped evidence rather than proof of universal memory safety” must hold for “Native safety gate”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M09.06-C093-T04 · Transition coverage:** Map the “Native safety gate” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M09.06-C093-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Native safety gate”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M09.06-C093-T06 · Satisfying fixture:** Create a concrete “Native safety gate” case that satisfies “A clean run is scoped evidence rather than proof of universal memory safety”; record its expected observation before running the assertion or review.
- [ ] **UC-M09.06-C093-T07 · Violating fixture:** Create the source counterexample “A skipped instrumented target is counted as a passing target” for “Native safety gate”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M09.06-C093-T08 · Enforcement evidence:** Exercise the “Native safety gate” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M09.06-C093-T09 · Regression linkage:** Link the “Native safety gate” property to changes in actual native targets, instrumented builds and reproducible adversarial corpora; record which dependency or contract changes require rerunning it.
- [ ] **UC-M09.06-C093-T10 · Property disposition:** Compare the satisfying and violating “Native safety gate” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M09.06-C094 · Integration

**Original checklist item:** Integrate native safety gate with actual native targets, instrumented builds and reproducible adversarial corpora; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M09.06-C094-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Native safety gate” across actual native targets, instrumented builds and reproducible adversarial corpora; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M09.06-C094-T02 · Field mapping:** Map every “Native safety gate” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M09.06-C094-T03 · Prerequisite identities:** Record the actual prerequisites for “Native safety gate” (source dependency list: UC-M02.08, UC-M03.02); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M09.06-C094-T04 · Ownership agreement:** Specify who owns “Native safety gate” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M09.06-C094-T05 · Handoff implementation:** Connect “Native safety gate” through the mapped seam using the real adapter or explicit specification reference; preserve “A clean run is scoped evidence rather than proof of universal memory safety” across the handoff.
- [ ] **UC-M09.06-C094-T06 · Absent-input case:** Omit one required “Native safety gate” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M09.06-C094-T07 · Stale-input case:** Supply an outdated “Native safety gate” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M09.06-C094-T08 · Incompatible-input case:** Supply an incompatible “Native safety gate” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M09.06-C094-T09 · Valid integration trace:** Run a valid “Native safety gate” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M09.06-C094-T10 · Seam review:** Reconcile the “Native safety gate” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M09.06-C095 · Valid-case test

**Original checklist item:** Run a known-valid control for native safety gate; verify that the harness reaches its intended target and compare observed measurements or verdicts with predeclared expectations.

- [ ] **UC-M09.06-C095-T01 · Valid fixture choice:** Choose a known-valid control for “Native safety gate”; document why it should pass and how it proves the harness reaches the intended target.
- [ ] **UC-M09.06-C095-T02 · Expected-result oracle:** Specify the “Native safety gate” expected result independently of the implementation output; include the property “A clean run is scoped evidence rather than proof of universal memory safety” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M09.06-C095-T03 · Fixture material:** Create the concrete “Native safety gate” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M09.06-C095-T04 · Target preparation:** Prepare the “Native safety gate” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M09.06-C095-T05 · Initial-state record:** Record the initial “Native safety gate” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M09.06-C095-T06 · Valid-path execution:** Run the “Native safety gate” known-valid control on the identified target; retain enough observations to prove the correct target was exercised.
- [ ] **UC-M09.06-C095-T07 · Outcome comparison:** Compare every declared “Native safety gate” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M09.06-C095-T08 · State and bounds check:** Inspect the “Native safety gate” ownership/state effects and actual use of “Campaign duration and required target coverage”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M09.06-C095-T09 · Repeatability check:** Repeat the same “Native safety gate” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M09.06-C095-T10 · Positive evidence:** Attach the “Native safety gate” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M09.06-C096 · Negative test

**Original checklist item:** Negative case: A skipped instrumented target is counted as a passing target. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M09.06-C096-T01 · Adverse-case definition:** Create a test record for the exact “Native safety gate” source counterexample: “A skipped instrumented target is counted as a passing target”; state which precondition or invariant it challenges.
- [ ] **UC-M09.06-C096-T02 · Safe fixture boundary:** Define the contained test boundary for “Native safety gate”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M09.06-C096-T03 · Valid control:** Construct a valid “Native safety gate” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M09.06-C096-T04 · Minimal adverse input:** Derive the “Native safety gate” adverse fixture from the control with the smallest documented change needed to reproduce “A skipped instrumented target is counted as a passing target”; retain that change as reproducible data.
- [ ] **UC-M09.06-C096-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Native safety gate”; require “A clean run is scoped evidence rather than proof of universal memory safety” and forbid a false-success verdict.
- [ ] **UC-M09.06-C096-T06 · Adverse execution:** Exercise the “Native safety gate” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M09.06-C096-T07 · Effect inspection:** Inspect “Native safety gate” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M09.06-C096-T08 · Refusal versus failure:** Confirm the “Native safety gate” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M09.06-C096-T09 · Reset and retention:** Restore only the disposable “Native safety gate” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M09.06-C096-T10 · Negative regression:** Register the “Native safety gate” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M09.06-C097 · Change / failure test

**Original checklist item:** Exercise native safety gate when a native runtime update changes code previously covered by a clean campaign; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M09.06-C097-T01 · Scenario record:** Write the “Native safety gate” change/failure scenario exactly as supplied: a native runtime update changes code previously covered by a clean campaign; identify the property that must remain true: “A clean run is scoped evidence rather than proof of universal memory safety”.
- [ ] **UC-M09.06-C097-T02 · Baseline capture:** Create a known-valid “Native safety gate” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M09.06-C097-T03 · Injection map:** Locate the “Native safety gate” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M09.06-C097-T04 · Disposition oracle:** Define the legal intermediate and final “Native safety gate” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M09.06-C097-T05 · Controlled trigger:** Introduce the controlled “Native safety gate” scenario in the disposable fixture: a native runtime update changes code previously covered by a clean campaign; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M09.06-C097-T06 · Intermediate inspection:** Inspect the “Native safety gate” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M09.06-C097-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Native safety gate”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M09.06-C097-T08 · Stale-evidence cleanup:** Invalidate superseded “Native safety gate” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M09.06-C097-T09 · Repeat and compare:** Repeat the selected “Native safety gate” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M09.06-C097-T10 · Failure evidence:** Publish the “Native safety gate” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M09.06-C098 · Bounds

**Original checklist item:** Set a documented campaign budget for campaign duration and required target coverage; record actual consumption, incomplete coverage and the disposition when the budget is exhausted.

- [ ] **UC-M09.06-C098-T01 · Quantity inventory:** Create a measurement inventory for “Native safety gate”: “Campaign duration and required target coverage”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M09.06-C098-T02 · Measurement method:** Choose how to observe each “Native safety gate” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M09.06-C098-T03 · Budget decision:** Select justified campaign and target-resource budgets for “Native safety gate”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M09.06-C098-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Native safety gate” cases for “Campaign duration and required target coverage”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M09.06-C098-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Native safety gate” limit; preserve “A clean run is scoped evidence rather than proof of universal memory safety”.
- [ ] **UC-M09.06-C098-T06 · Normal measurement:** Run or review the normal “Native safety gate” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M09.06-C098-T07 · At-limit measurement:** Exercise the “Native safety gate” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M09.06-C098-T08 · Over-limit measurement:** Exercise the “Native safety gate” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M09.06-C098-T09 · Uncovered-scope report:** List the “Native safety gate” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M09.06-C098-T10 · Limit evidence:** Publish the selected “Native safety gate” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M09.06-C099 · Diagnostics / review

**Original checklist item:** Report native safety gate results with executed, failed, skipped and unavailable cases separated; preserve the underlying observations and do not manufacture missing measurements.

- [ ] **UC-M09.06-C099-T01 · Result inventory:** Enumerate the required “Native safety gate” qualification cases and intended targets before aggregating results; keep the planned denominator visible.
- [ ] **UC-M09.06-C099-T02 · Verdict schema:** Define separate executed-pass, executed-fail, skipped, unavailable and untested outcomes for “Native safety gate”; document how incomplete cases block relevant claims.
- [ ] **UC-M09.06-C099-T03 · Identity fields:** Attach the actual target, fixture, configuration and revision identifiers to each “Native safety gate” result; do not attribute host-only evidence to a guest or another OS.
- [ ] **UC-M09.06-C099-T04 · Observation capture:** Capture bounded raw “Native safety gate” observations and harness errors; retain enough information to verify the reported oracle comparison.
- [ ] **UC-M09.06-C099-T05 · Aggregation rules:** Implement the “Native safety gate” count/reduction rule so failures and missing measurements cannot disappear; preserve “A clean run is scoped evidence rather than proof of universal memory safety”.
- [ ] **UC-M09.06-C099-T06 · Failure visibility:** Feed a failing “Native safety gate” control through the report path; assert the exact failed case and underlying observation remain visible.
- [ ] **UC-M09.06-C099-T07 · Missing-result visibility:** Withhold a required “Native safety gate” measurement or target; verify the report uses unavailable/untested rather than a fabricated zero or passing value.
- [ ] **UC-M09.06-C099-T08 · Bounds and redaction:** Check “Native safety gate” report size and retention against “Campaign duration and required target coverage”; remove secrets while retaining fixture and subject references.
- [ ] **UC-M09.06-C099-T09 · Report reconciliation:** Reconcile the “Native safety gate” summary with every underlying case record; account for the full planned denominator and all omitted scope.
- [ ] **UC-M09.06-C099-T10 · Qualification handoff:** Publish the “Native safety gate” report with measured observations, coverage limits and blockers; state which actual targets remain unqualified.

### UC-M09.06-C100 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for native safety gate; label unexecuted checks as untested.

- [ ] **UC-M09.06-C100-T01 · Evidence inventory:** List the “Native safety gate” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M09.06-C100-T02 · Artifact references:** Record the exact “Native safety gate” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M09.06-C100-T03 · Fixture references:** Attach the “Native safety gate” fixture IDs, input identities and oracle definition; preserve the source counterexample “A skipped instrumented target is counted as a passing target” as a distinct evidence case.
- [ ] **UC-M09.06-C100-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Native safety gate”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M09.06-C100-T05 · Environment record:** Record the actual “Native safety gate” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M09.06-C100-T06 · Expected versus observed:** Pair every “Native safety gate” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M09.06-C100-T07 · Failure and limit records:** Attach “Native safety gate” change/failure and bounds evidence where required; include uncovered “Campaign duration and required target coverage” and unresolved violations of “A clean run is scoped evidence rather than proof of universal memory safety”.
- [ ] **UC-M09.06-C100-T08 · Evidence hygiene:** Check the “Native safety gate” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M09.06-C100-T09 · Reproduction review:** Have the “Native safety gate” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M09.06-C100-T10 · Acceptance linkage:** Link the “Native safety gate” evidence to its parent and UC-M09.06 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

