# UC-M09.01 — Independent key lifecycle

**To-Do Pack 2.0.0 · Baseline UC-2.2.0 · 100 parent checks × 10 subtasks = 1,000 to-dos**

[Master index](../../INDEX.md) · [Workstream index](../../w/09.md)

| Field | Preserved source value |
|---|---|
| Workstream | 09. Trust, integrity and adversarial security |
| Milestone | C |
| Priority | P0 |
| Source assessment | MISSING |
| Scope | core or selected profile |
| Dependencies | [UC-M04.08](../04/UC-M04.08.md), [UC-M06.03](../06/UC-M06.03.md) |
| Source checklist pack | 1.0.0 |
| Original reference labels | [S4], [S7], [S8]. |

## Original requirement

Separate development, build, release and operator trust keys; support rotation, revocation, offline roots and scoped enrollment.

**Original acceptance criterion:** A revoked signer cannot admit new images; one compromised online role cannot mint a new trusted root.

**Source trace:** Original checklist `UC100/c/09/UC-M09.01.md` inside [s/checklists.zip](../../s/checklists.zip); exact parent records in [data/parents.jsonl](../../data/parents.jsonl). Original roadmap lines 809–819 are preserved in [s/roadmap.md](../../s/roadmap.md).

## How to use these lists

Every parent statement below is preserved verbatim. Its ten child tasks are proposed decomposition, not implemented capabilities or executed tests. Child IDs append `-T01` through `-T10` to the original parent ID. All begin unchecked / `TODO`. Design/review evidence does not establish runtime enforcement; observe the actual selected target where the parent requires it.

The source dependency graph and selected release profile determine applicability. The numbered child sequence is a local working order, not an added hard dependency graph. An unselected optional feature needs a recorded not-applicable rationale; missing prerequisites for selected work remain blockers. Numerical budgets, backends and trust mechanisms remain decisions unless fixed by the source. Test hostile cases only with synthetic inputs in authorized disposable environments.

## 01. Trust role separation

**Source delivery:** Define distinct development, build, release and operator trust roles.

**Source invariant:** Compromise of one online role cannot create a new trusted root.

**Source negative case:** A build signer attempts to enroll itself as operator authority.

**Source bounded quantities:** Role count and permitted delegation edges.

### UC-M09.01-C001 · Contract

**Original checklist item:** Specify trust role separation inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M09.01-C001-T01 · Scope statement:** Draft the operation boundary for “Trust role separation” within Independent key lifecycle; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M09.01-C001-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Trust role separation”; record each producer, representation and missing-value meaning.
- [ ] **UC-M09.01-C001-T03 · Output inventory:** List the outputs of “Trust role separation” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M09.01-C001-T04 · Field dictionary:** Create a field-and-term dictionary for “Trust role separation”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M09.01-C001-T05 · Prerequisite contract:** Map “Trust role separation” to the source component prerequisites (UC-M04.08, UC-M06.03); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M09.01-C001-T06 · Authority map:** Identify who may produce, change and consume “Trust role separation”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M09.01-C001-T07 · Invariant clause:** Add a normative clause for “Trust role separation” that preserves “Compromise of one online role cannot create a new trusted root”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M09.01-C001-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Trust role separation”; include the source counterexample “A build signer attempts to enroll itself as operator authority” and the intended safe disposition.
- [ ] **UC-M09.01-C001-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Role count and permitted delegation edges” in the “Trust role separation” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M09.01-C001-T10 · Contract review:** Review the “Trust role separation” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M09.01-C002 · Delivery

**Original checklist item:** Define distinct development, build, release and operator trust roles.

- [ ] **UC-M09.01-C002-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Trust role separation”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M09.01-C002-T02 · Change plan:** Break the source delivery for “Trust role separation” into concrete edit targets and reviewable outputs; keep the UC-M09.01 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M09.01-C002-T03 · Core artifact:** Create the “Trust role separation” model, schema or inventory that realizes this source instruction: Define distinct development, build, release and operator trust roles.
- [ ] **UC-M09.01-C002-T04 · Concrete realization:** Populate “Trust role separation” with one concrete worked case; map every required entity or field to its source and flag any unmapped entry.
- [ ] **UC-M09.01-C002-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Trust role separation” needed to preserve “Compromise of one online role cannot create a new trusted root”; record an enforcement gap where only a model exists.
- [ ] **UC-M09.01-C002-T06 · Dependency connection:** Connect the “Trust role separation” implementation to operator trust roots, signer roles and image-admission decisions; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M09.01-C002-T07 · Resource behavior:** Account for “Role count and permitted delegation edges” in “Trust role separation”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M09.01-C002-T08 · Delivery check:** Run the smallest real “Trust role separation” path and its adverse fixture “A build signer attempts to enroll itself as operator authority”; retain actual output, state effects and final disposition.
- [ ] **UC-M09.01-C002-T09 · Patch review:** Review the “Trust role separation” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M09.01-C002-T10 · Delivery handoff:** Publish the “Trust role separation” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M09.01-C003 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Compromise of one online role cannot create a new trusted root. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M09.01-C003-T01 · Named property:** Create a stable property/check name under this parent for “Trust role separation”; copy its required invariant exactly: “Compromise of one online role cannot create a new trusted root”.
- [ ] **UC-M09.01-C003-T02 · Observable terms:** Define each term in the “Trust role separation” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M09.01-C003-T03 · Precondition set:** List the preconditions under which “Compromise of one online role cannot create a new trusted root” must hold for “Trust role separation”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M09.01-C003-T04 · Transition coverage:** Map the “Trust role separation” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M09.01-C003-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Trust role separation”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M09.01-C003-T06 · Satisfying fixture:** Create a concrete “Trust role separation” case that satisfies “Compromise of one online role cannot create a new trusted root”; record its expected observation before running the assertion or review.
- [ ] **UC-M09.01-C003-T07 · Violating fixture:** Create the source counterexample “A build signer attempts to enroll itself as operator authority” for “Trust role separation”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M09.01-C003-T08 · Enforcement evidence:** Exercise the “Trust role separation” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M09.01-C003-T09 · Regression linkage:** Link the “Trust role separation” property to changes in operator trust roots, signer roles and image-admission decisions; record which dependency or contract changes require rerunning it.
- [ ] **UC-M09.01-C003-T10 · Property disposition:** Compare the satisfying and violating “Trust role separation” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M09.01-C004 · Integration

**Original checklist item:** Integrate trust role separation with operator trust roots, signer roles and image-admission decisions; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M09.01-C004-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Trust role separation” across operator trust roots, signer roles and image-admission decisions; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M09.01-C004-T02 · Field mapping:** Map every “Trust role separation” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M09.01-C004-T03 · Prerequisite identities:** Record the actual prerequisites for “Trust role separation” (source dependency list: UC-M04.08, UC-M06.03); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M09.01-C004-T04 · Ownership agreement:** Specify who owns “Trust role separation” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M09.01-C004-T05 · Handoff implementation:** Connect “Trust role separation” through the mapped seam using the real adapter or explicit specification reference; preserve “Compromise of one online role cannot create a new trusted root” across the handoff.
- [ ] **UC-M09.01-C004-T06 · Absent-input case:** Omit one required “Trust role separation” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M09.01-C004-T07 · Stale-input case:** Supply an outdated “Trust role separation” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M09.01-C004-T08 · Incompatible-input case:** Supply an incompatible “Trust role separation” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M09.01-C004-T09 · Valid integration trace:** Run a valid “Trust role separation” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M09.01-C004-T10 · Seam review:** Reconcile the “Trust role separation” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M09.01-C005 · Valid-case test

**Original checklist item:** Run a valid-path fixture for trust role separation; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M09.01-C005-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Trust role separation” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M09.01-C005-T02 · Expected-result oracle:** Specify the “Trust role separation” expected result independently of the implementation output; include the property “Compromise of one online role cannot create a new trusted root” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M09.01-C005-T03 · Fixture material:** Create the concrete “Trust role separation” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M09.01-C005-T04 · Target preparation:** Prepare the “Trust role separation” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M09.01-C005-T05 · Initial-state record:** Record the initial “Trust role separation” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M09.01-C005-T06 · Valid-path execution:** Execute the “Trust role separation” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M09.01-C005-T07 · Outcome comparison:** Compare every declared “Trust role separation” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M09.01-C005-T08 · State and bounds check:** Inspect the “Trust role separation” ownership/state effects and actual use of “Role count and permitted delegation edges”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M09.01-C005-T09 · Repeatability check:** Repeat the same “Trust role separation” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M09.01-C005-T10 · Positive evidence:** Attach the “Trust role separation” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M09.01-C006 · Negative test

**Original checklist item:** Negative case: A build signer attempts to enroll itself as operator authority. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M09.01-C006-T01 · Adverse-case definition:** Create a test record for the exact “Trust role separation” source counterexample: “A build signer attempts to enroll itself as operator authority”; state which precondition or invariant it challenges.
- [ ] **UC-M09.01-C006-T02 · Safe fixture boundary:** Define the contained test boundary for “Trust role separation”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M09.01-C006-T03 · Valid control:** Construct a valid “Trust role separation” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M09.01-C006-T04 · Minimal adverse input:** Derive the “Trust role separation” adverse fixture from the control with the smallest documented change needed to reproduce “A build signer attempts to enroll itself as operator authority”; retain that change as reproducible data.
- [ ] **UC-M09.01-C006-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Trust role separation”; require “Compromise of one online role cannot create a new trusted root” and forbid a false-success verdict.
- [ ] **UC-M09.01-C006-T06 · Adverse execution:** Exercise the “Trust role separation” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M09.01-C006-T07 · Effect inspection:** Inspect “Trust role separation” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M09.01-C006-T08 · Refusal versus failure:** Confirm the “Trust role separation” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M09.01-C006-T09 · Reset and retention:** Restore only the disposable “Trust role separation” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M09.01-C006-T10 · Negative regression:** Register the “Trust role separation” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M09.01-C007 · Change / failure test

**Original checklist item:** Exercise trust role separation when an online key is rotated or revoked while old credentials remain cached; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M09.01-C007-T01 · Scenario record:** Write the “Trust role separation” change/failure scenario exactly as supplied: an online key is rotated or revoked while old credentials remain cached; identify the property that must remain true: “Compromise of one online role cannot create a new trusted root”.
- [ ] **UC-M09.01-C007-T02 · Baseline capture:** Create a known-valid “Trust role separation” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M09.01-C007-T03 · Injection map:** Locate the “Trust role separation” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M09.01-C007-T04 · Disposition oracle:** Define the legal intermediate and final “Trust role separation” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M09.01-C007-T05 · Controlled trigger:** Introduce the controlled “Trust role separation” scenario in the disposable fixture: an online key is rotated or revoked while old credentials remain cached; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M09.01-C007-T06 · Intermediate inspection:** Inspect the “Trust role separation” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M09.01-C007-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Trust role separation”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M09.01-C007-T08 · Stale-evidence cleanup:** Invalidate superseded “Trust role separation” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M09.01-C007-T09 · Repeat and compare:** Repeat the selected “Trust role separation” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M09.01-C007-T10 · Failure evidence:** Publish the “Trust role separation” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M09.01-C008 · Bounds

**Original checklist item:** Choose, document and test limits for role count and permitted delegation edges; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M09.01-C008-T01 · Quantity inventory:** Create a measurement inventory for “Trust role separation”: “Role count and permitted delegation edges”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M09.01-C008-T02 · Measurement method:** Choose how to observe each “Trust role separation” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M09.01-C008-T03 · Budget decision:** Select justified resource and input limits for “Trust role separation”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M09.01-C008-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Trust role separation” cases for “Role count and permitted delegation edges”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M09.01-C008-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Trust role separation” limit; preserve “Compromise of one online role cannot create a new trusted root”.
- [ ] **UC-M09.01-C008-T06 · Normal measurement:** Run or review the normal “Trust role separation” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M09.01-C008-T07 · At-limit measurement:** Exercise the “Trust role separation” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M09.01-C008-T08 · Over-limit measurement:** Exercise the “Trust role separation” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M09.01-C008-T09 · Uncovered-scope report:** List the “Trust role separation” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M09.01-C008-T10 · Limit evidence:** Publish the selected “Trust role separation” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M09.01-C009 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for trust role separation with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M09.01-C009-T01 · Event inventory:** List the “Trust role separation” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M09.01-C009-T02 · Diagnostic schema:** Define nonsecret fields for “Trust role separation” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M09.01-C009-T03 · Failure mapping:** Map each documented “Trust role separation” refusal or error to a diagnostic outcome; include “A build signer attempts to enroll itself as operator authority” and prohibit conversion into a success message.
- [ ] **UC-M09.01-C009-T04 · Emission path:** Add the “Trust role separation” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M09.01-C009-T05 · Redaction check:** Test “Trust role separation” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M09.01-C009-T06 · Output budget:** Set and exercise bounded “Trust role separation” message size, rate and retention compatible with “Role count and permitted delegation edges”; define truncation behavior that preserves the final reason.
- [ ] **UC-M09.01-C009-T07 · Success/refusal fixtures:** Capture “Trust role separation” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M09.01-C009-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Trust role separation” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M09.01-C009-T09 · Operator review:** Read the “Trust role separation” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M09.01-C009-T10 · Diagnostic evidence:** Publish redacted “Trust role separation” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M09.01-C010 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for trust role separation; label unexecuted checks as untested.

- [ ] **UC-M09.01-C010-T01 · Evidence inventory:** List the “Trust role separation” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M09.01-C010-T02 · Artifact references:** Record the exact “Trust role separation” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M09.01-C010-T03 · Fixture references:** Attach the “Trust role separation” fixture IDs, input identities and oracle definition; preserve the source counterexample “A build signer attempts to enroll itself as operator authority” as a distinct evidence case.
- [ ] **UC-M09.01-C010-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Trust role separation”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M09.01-C010-T05 · Environment record:** Record the actual “Trust role separation” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M09.01-C010-T06 · Expected versus observed:** Pair every “Trust role separation” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M09.01-C010-T07 · Failure and limit records:** Attach “Trust role separation” change/failure and bounds evidence where required; include uncovered “Role count and permitted delegation edges” and unresolved violations of “Compromise of one online role cannot create a new trusted root”.
- [ ] **UC-M09.01-C010-T08 · Evidence hygiene:** Check the “Trust role separation” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M09.01-C010-T09 · Reproduction review:** Have the “Trust role separation” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M09.01-C010-T10 · Acceptance linkage:** Link the “Trust role separation” evidence to its parent and UC-M09.01 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 02. Offline root custody

**Source delivery:** Specify operator-controlled offline root storage and authorized use procedures.

**Source invariant:** Online workloads cannot access root signing authority.

**Source negative case:** A root key is packaged in a build worker's workspace.

**Source bounded quantities:** Root copies and authorized access events.

### UC-M09.01-C011 · Contract

**Original checklist item:** Specify offline root custody inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M09.01-C011-T01 · Scope statement:** Draft the operation boundary for “Offline root custody” within Independent key lifecycle; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M09.01-C011-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Offline root custody”; record each producer, representation and missing-value meaning.
- [ ] **UC-M09.01-C011-T03 · Output inventory:** List the outputs of “Offline root custody” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M09.01-C011-T04 · Field dictionary:** Create a field-and-term dictionary for “Offline root custody”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M09.01-C011-T05 · Prerequisite contract:** Map “Offline root custody” to the source component prerequisites (UC-M04.08, UC-M06.03); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M09.01-C011-T06 · Authority map:** Identify who may produce, change and consume “Offline root custody”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M09.01-C011-T07 · Invariant clause:** Add a normative clause for “Offline root custody” that preserves “Online workloads cannot access root signing authority”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M09.01-C011-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Offline root custody”; include the source counterexample “A root key is packaged in a build worker's workspace” and the intended safe disposition.
- [ ] **UC-M09.01-C011-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Root copies and authorized access events” in the “Offline root custody” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M09.01-C011-T10 · Contract review:** Review the “Offline root custody” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M09.01-C012 · Delivery

**Original checklist item:** Specify operator-controlled offline root storage and authorized use procedures.

- [ ] **UC-M09.01-C012-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Offline root custody”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M09.01-C012-T02 · Change plan:** Break the source delivery for “Offline root custody” into concrete edit targets and reviewable outputs; keep the UC-M09.01 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M09.01-C012-T03 · Core artifact:** Create the “Offline root custody” model, schema or inventory that realizes this source instruction: Specify operator-controlled offline root storage and authorized use procedures.
- [ ] **UC-M09.01-C012-T04 · Concrete realization:** Populate “Offline root custody” with one concrete worked case; map every required entity or field to its source and flag any unmapped entry.
- [ ] **UC-M09.01-C012-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Offline root custody” needed to preserve “Online workloads cannot access root signing authority”; record an enforcement gap where only a model exists.
- [ ] **UC-M09.01-C012-T06 · Dependency connection:** Connect the “Offline root custody” implementation to operator trust roots, signer roles and image-admission decisions; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M09.01-C012-T07 · Resource behavior:** Account for “Root copies and authorized access events” in “Offline root custody”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M09.01-C012-T08 · Delivery check:** Run the smallest real “Offline root custody” path and its adverse fixture “A root key is packaged in a build worker's workspace”; retain actual output, state effects and final disposition.
- [ ] **UC-M09.01-C012-T09 · Patch review:** Review the “Offline root custody” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M09.01-C012-T10 · Delivery handoff:** Publish the “Offline root custody” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M09.01-C013 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Online workloads cannot access root signing authority. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M09.01-C013-T01 · Named property:** Create a stable property/check name under this parent for “Offline root custody”; copy its required invariant exactly: “Online workloads cannot access root signing authority”.
- [ ] **UC-M09.01-C013-T02 · Observable terms:** Define each term in the “Offline root custody” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M09.01-C013-T03 · Precondition set:** List the preconditions under which “Online workloads cannot access root signing authority” must hold for “Offline root custody”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M09.01-C013-T04 · Transition coverage:** Map the “Offline root custody” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M09.01-C013-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Offline root custody”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M09.01-C013-T06 · Satisfying fixture:** Create a concrete “Offline root custody” case that satisfies “Online workloads cannot access root signing authority”; record its expected observation before running the assertion or review.
- [ ] **UC-M09.01-C013-T07 · Violating fixture:** Create the source counterexample “A root key is packaged in a build worker's workspace” for “Offline root custody”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M09.01-C013-T08 · Enforcement evidence:** Exercise the “Offline root custody” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M09.01-C013-T09 · Regression linkage:** Link the “Offline root custody” property to changes in operator trust roots, signer roles and image-admission decisions; record which dependency or contract changes require rerunning it.
- [ ] **UC-M09.01-C013-T10 · Property disposition:** Compare the satisfying and violating “Offline root custody” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M09.01-C014 · Integration

**Original checklist item:** Integrate offline root custody with operator trust roots, signer roles and image-admission decisions; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M09.01-C014-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Offline root custody” across operator trust roots, signer roles and image-admission decisions; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M09.01-C014-T02 · Field mapping:** Map every “Offline root custody” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M09.01-C014-T03 · Prerequisite identities:** Record the actual prerequisites for “Offline root custody” (source dependency list: UC-M04.08, UC-M06.03); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M09.01-C014-T04 · Ownership agreement:** Specify who owns “Offline root custody” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M09.01-C014-T05 · Handoff implementation:** Connect “Offline root custody” through the mapped seam using the real adapter or explicit specification reference; preserve “Online workloads cannot access root signing authority” across the handoff.
- [ ] **UC-M09.01-C014-T06 · Absent-input case:** Omit one required “Offline root custody” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M09.01-C014-T07 · Stale-input case:** Supply an outdated “Offline root custody” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M09.01-C014-T08 · Incompatible-input case:** Supply an incompatible “Offline root custody” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M09.01-C014-T09 · Valid integration trace:** Run a valid “Offline root custody” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M09.01-C014-T10 · Seam review:** Reconcile the “Offline root custody” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M09.01-C015 · Valid-case test

**Original checklist item:** Run a valid-path fixture for offline root custody; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M09.01-C015-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Offline root custody” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M09.01-C015-T02 · Expected-result oracle:** Specify the “Offline root custody” expected result independently of the implementation output; include the property “Online workloads cannot access root signing authority” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M09.01-C015-T03 · Fixture material:** Create the concrete “Offline root custody” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M09.01-C015-T04 · Target preparation:** Prepare the “Offline root custody” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M09.01-C015-T05 · Initial-state record:** Record the initial “Offline root custody” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M09.01-C015-T06 · Valid-path execution:** Execute the “Offline root custody” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M09.01-C015-T07 · Outcome comparison:** Compare every declared “Offline root custody” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M09.01-C015-T08 · State and bounds check:** Inspect the “Offline root custody” ownership/state effects and actual use of “Root copies and authorized access events”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M09.01-C015-T09 · Repeatability check:** Repeat the same “Offline root custody” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M09.01-C015-T10 · Positive evidence:** Attach the “Offline root custody” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M09.01-C016 · Negative test

**Original checklist item:** Negative case: A root key is packaged in a build worker's workspace. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M09.01-C016-T01 · Adverse-case definition:** Create a test record for the exact “Offline root custody” source counterexample: “A root key is packaged in a build worker's workspace”; state which precondition or invariant it challenges.
- [ ] **UC-M09.01-C016-T02 · Safe fixture boundary:** Define the contained test boundary for “Offline root custody”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M09.01-C016-T03 · Valid control:** Construct a valid “Offline root custody” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M09.01-C016-T04 · Minimal adverse input:** Derive the “Offline root custody” adverse fixture from the control with the smallest documented change needed to reproduce “A root key is packaged in a build worker's workspace”; retain that change as reproducible data.
- [ ] **UC-M09.01-C016-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Offline root custody”; require “Online workloads cannot access root signing authority” and forbid a false-success verdict.
- [ ] **UC-M09.01-C016-T06 · Adverse execution:** Exercise the “Offline root custody” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M09.01-C016-T07 · Effect inspection:** Inspect “Offline root custody” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M09.01-C016-T08 · Refusal versus failure:** Confirm the “Offline root custody” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M09.01-C016-T09 · Reset and retention:** Restore only the disposable “Offline root custody” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M09.01-C016-T10 · Negative regression:** Register the “Offline root custody” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M09.01-C017 · Change / failure test

**Original checklist item:** Exercise offline root custody when an online key is rotated or revoked while old credentials remain cached; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M09.01-C017-T01 · Scenario record:** Write the “Offline root custody” change/failure scenario exactly as supplied: an online key is rotated or revoked while old credentials remain cached; identify the property that must remain true: “Online workloads cannot access root signing authority”.
- [ ] **UC-M09.01-C017-T02 · Baseline capture:** Create a known-valid “Offline root custody” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M09.01-C017-T03 · Injection map:** Locate the “Offline root custody” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M09.01-C017-T04 · Disposition oracle:** Define the legal intermediate and final “Offline root custody” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M09.01-C017-T05 · Controlled trigger:** Introduce the controlled “Offline root custody” scenario in the disposable fixture: an online key is rotated or revoked while old credentials remain cached; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M09.01-C017-T06 · Intermediate inspection:** Inspect the “Offline root custody” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M09.01-C017-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Offline root custody”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M09.01-C017-T08 · Stale-evidence cleanup:** Invalidate superseded “Offline root custody” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M09.01-C017-T09 · Repeat and compare:** Repeat the selected “Offline root custody” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M09.01-C017-T10 · Failure evidence:** Publish the “Offline root custody” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M09.01-C018 · Bounds

**Original checklist item:** Choose, document and test limits for root copies and authorized access events; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M09.01-C018-T01 · Quantity inventory:** Create a measurement inventory for “Offline root custody”: “Root copies and authorized access events”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M09.01-C018-T02 · Measurement method:** Choose how to observe each “Offline root custody” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M09.01-C018-T03 · Budget decision:** Select justified resource and input limits for “Offline root custody”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M09.01-C018-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Offline root custody” cases for “Root copies and authorized access events”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M09.01-C018-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Offline root custody” limit; preserve “Online workloads cannot access root signing authority”.
- [ ] **UC-M09.01-C018-T06 · Normal measurement:** Run or review the normal “Offline root custody” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M09.01-C018-T07 · At-limit measurement:** Exercise the “Offline root custody” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M09.01-C018-T08 · Over-limit measurement:** Exercise the “Offline root custody” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M09.01-C018-T09 · Uncovered-scope report:** List the “Offline root custody” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M09.01-C018-T10 · Limit evidence:** Publish the selected “Offline root custody” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M09.01-C019 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for offline root custody with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M09.01-C019-T01 · Event inventory:** List the “Offline root custody” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M09.01-C019-T02 · Diagnostic schema:** Define nonsecret fields for “Offline root custody” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M09.01-C019-T03 · Failure mapping:** Map each documented “Offline root custody” refusal or error to a diagnostic outcome; include “A root key is packaged in a build worker's workspace” and prohibit conversion into a success message.
- [ ] **UC-M09.01-C019-T04 · Emission path:** Add the “Offline root custody” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M09.01-C019-T05 · Redaction check:** Test “Offline root custody” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M09.01-C019-T06 · Output budget:** Set and exercise bounded “Offline root custody” message size, rate and retention compatible with “Root copies and authorized access events”; define truncation behavior that preserves the final reason.
- [ ] **UC-M09.01-C019-T07 · Success/refusal fixtures:** Capture “Offline root custody” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M09.01-C019-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Offline root custody” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M09.01-C019-T09 · Operator review:** Read the “Offline root custody” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M09.01-C019-T10 · Diagnostic evidence:** Publish redacted “Offline root custody” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M09.01-C020 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for offline root custody; label unexecuted checks as untested.

- [ ] **UC-M09.01-C020-T01 · Evidence inventory:** List the “Offline root custody” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M09.01-C020-T02 · Artifact references:** Record the exact “Offline root custody” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M09.01-C020-T03 · Fixture references:** Attach the “Offline root custody” fixture IDs, input identities and oracle definition; preserve the source counterexample “A root key is packaged in a build worker's workspace” as a distinct evidence case.
- [ ] **UC-M09.01-C020-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Offline root custody”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M09.01-C020-T05 · Environment record:** Record the actual “Offline root custody” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M09.01-C020-T06 · Expected versus observed:** Pair every “Offline root custody” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M09.01-C020-T07 · Failure and limit records:** Attach “Offline root custody” change/failure and bounds evidence where required; include uncovered “Root copies and authorized access events” and unresolved violations of “Online workloads cannot access root signing authority”.
- [ ] **UC-M09.01-C020-T08 · Evidence hygiene:** Check the “Offline root custody” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M09.01-C020-T09 · Reproduction review:** Have the “Offline root custody” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M09.01-C020-T10 · Acceptance linkage:** Link the “Offline root custody” evidence to its parent and UC-M09.01 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 03. Key generation policy

**Source delivery:** Define approved key creation and origin evidence for each selected trust role.

**Source invariant:** Keys are generated from appropriate nondeterministic security inputs.

**Source negative case:** A release key derives from a deterministic witness seed.

**Source bounded quantities:** Key count and generation verification steps.

### UC-M09.01-C021 · Contract

**Original checklist item:** Specify key generation policy inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M09.01-C021-T01 · Scope statement:** Draft the operation boundary for “Key generation policy” within Independent key lifecycle; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M09.01-C021-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Key generation policy”; record each producer, representation and missing-value meaning.
- [ ] **UC-M09.01-C021-T03 · Output inventory:** List the outputs of “Key generation policy” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M09.01-C021-T04 · Field dictionary:** Create a field-and-term dictionary for “Key generation policy”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M09.01-C021-T05 · Prerequisite contract:** Map “Key generation policy” to the source component prerequisites (UC-M04.08, UC-M06.03); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M09.01-C021-T06 · Authority map:** Identify who may produce, change and consume “Key generation policy”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M09.01-C021-T07 · Invariant clause:** Add a normative clause for “Key generation policy” that preserves “Keys are generated from appropriate nondeterministic security inputs”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M09.01-C021-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Key generation policy”; include the source counterexample “A release key derives from a deterministic witness seed” and the intended safe disposition.
- [ ] **UC-M09.01-C021-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Key count and generation verification steps” in the “Key generation policy” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M09.01-C021-T10 · Contract review:** Review the “Key generation policy” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M09.01-C022 · Delivery

**Original checklist item:** Define approved key creation and origin evidence for each selected trust role.

- [ ] **UC-M09.01-C022-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Key generation policy”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M09.01-C022-T02 · Change plan:** Break the source delivery for “Key generation policy” into concrete edit targets and reviewable outputs; keep the UC-M09.01 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M09.01-C022-T03 · Core artifact:** Create the “Key generation policy” model, schema or inventory that realizes this source instruction: Define approved key creation and origin evidence for each selected trust role.
- [ ] **UC-M09.01-C022-T04 · Concrete realization:** Populate “Key generation policy” with one concrete worked case; map every required entity or field to its source and flag any unmapped entry.
- [ ] **UC-M09.01-C022-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Key generation policy” needed to preserve “Keys are generated from appropriate nondeterministic security inputs”; record an enforcement gap where only a model exists.
- [ ] **UC-M09.01-C022-T06 · Dependency connection:** Connect the “Key generation policy” implementation to operator trust roots, signer roles and image-admission decisions; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M09.01-C022-T07 · Resource behavior:** Account for “Key count and generation verification steps” in “Key generation policy”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M09.01-C022-T08 · Delivery check:** Run the smallest real “Key generation policy” path and its adverse fixture “A release key derives from a deterministic witness seed”; retain actual output, state effects and final disposition.
- [ ] **UC-M09.01-C022-T09 · Patch review:** Review the “Key generation policy” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M09.01-C022-T10 · Delivery handoff:** Publish the “Key generation policy” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M09.01-C023 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Keys are generated from appropriate nondeterministic security inputs. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M09.01-C023-T01 · Named property:** Create a stable property/check name under this parent for “Key generation policy”; copy its required invariant exactly: “Keys are generated from appropriate nondeterministic security inputs”.
- [ ] **UC-M09.01-C023-T02 · Observable terms:** Define each term in the “Key generation policy” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M09.01-C023-T03 · Precondition set:** List the preconditions under which “Keys are generated from appropriate nondeterministic security inputs” must hold for “Key generation policy”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M09.01-C023-T04 · Transition coverage:** Map the “Key generation policy” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M09.01-C023-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Key generation policy”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M09.01-C023-T06 · Satisfying fixture:** Create a concrete “Key generation policy” case that satisfies “Keys are generated from appropriate nondeterministic security inputs”; record its expected observation before running the assertion or review.
- [ ] **UC-M09.01-C023-T07 · Violating fixture:** Create the source counterexample “A release key derives from a deterministic witness seed” for “Key generation policy”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M09.01-C023-T08 · Enforcement evidence:** Exercise the “Key generation policy” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M09.01-C023-T09 · Regression linkage:** Link the “Key generation policy” property to changes in operator trust roots, signer roles and image-admission decisions; record which dependency or contract changes require rerunning it.
- [ ] **UC-M09.01-C023-T10 · Property disposition:** Compare the satisfying and violating “Key generation policy” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M09.01-C024 · Integration

**Original checklist item:** Integrate key generation policy with operator trust roots, signer roles and image-admission decisions; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M09.01-C024-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Key generation policy” across operator trust roots, signer roles and image-admission decisions; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M09.01-C024-T02 · Field mapping:** Map every “Key generation policy” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M09.01-C024-T03 · Prerequisite identities:** Record the actual prerequisites for “Key generation policy” (source dependency list: UC-M04.08, UC-M06.03); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M09.01-C024-T04 · Ownership agreement:** Specify who owns “Key generation policy” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M09.01-C024-T05 · Handoff implementation:** Connect “Key generation policy” through the mapped seam using the real adapter or explicit specification reference; preserve “Keys are generated from appropriate nondeterministic security inputs” across the handoff.
- [ ] **UC-M09.01-C024-T06 · Absent-input case:** Omit one required “Key generation policy” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M09.01-C024-T07 · Stale-input case:** Supply an outdated “Key generation policy” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M09.01-C024-T08 · Incompatible-input case:** Supply an incompatible “Key generation policy” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M09.01-C024-T09 · Valid integration trace:** Run a valid “Key generation policy” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M09.01-C024-T10 · Seam review:** Reconcile the “Key generation policy” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M09.01-C025 · Valid-case test

**Original checklist item:** Run a valid-path fixture for key generation policy; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M09.01-C025-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Key generation policy” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M09.01-C025-T02 · Expected-result oracle:** Specify the “Key generation policy” expected result independently of the implementation output; include the property “Keys are generated from appropriate nondeterministic security inputs” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M09.01-C025-T03 · Fixture material:** Create the concrete “Key generation policy” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M09.01-C025-T04 · Target preparation:** Prepare the “Key generation policy” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M09.01-C025-T05 · Initial-state record:** Record the initial “Key generation policy” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M09.01-C025-T06 · Valid-path execution:** Execute the “Key generation policy” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M09.01-C025-T07 · Outcome comparison:** Compare every declared “Key generation policy” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M09.01-C025-T08 · State and bounds check:** Inspect the “Key generation policy” ownership/state effects and actual use of “Key count and generation verification steps”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M09.01-C025-T09 · Repeatability check:** Repeat the same “Key generation policy” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M09.01-C025-T10 · Positive evidence:** Attach the “Key generation policy” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M09.01-C026 · Negative test

**Original checklist item:** Negative case: A release key derives from a deterministic witness seed. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M09.01-C026-T01 · Adverse-case definition:** Create a test record for the exact “Key generation policy” source counterexample: “A release key derives from a deterministic witness seed”; state which precondition or invariant it challenges.
- [ ] **UC-M09.01-C026-T02 · Safe fixture boundary:** Define the contained test boundary for “Key generation policy”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M09.01-C026-T03 · Valid control:** Construct a valid “Key generation policy” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M09.01-C026-T04 · Minimal adverse input:** Derive the “Key generation policy” adverse fixture from the control with the smallest documented change needed to reproduce “A release key derives from a deterministic witness seed”; retain that change as reproducible data.
- [ ] **UC-M09.01-C026-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Key generation policy”; require “Keys are generated from appropriate nondeterministic security inputs” and forbid a false-success verdict.
- [ ] **UC-M09.01-C026-T06 · Adverse execution:** Exercise the “Key generation policy” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M09.01-C026-T07 · Effect inspection:** Inspect “Key generation policy” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M09.01-C026-T08 · Refusal versus failure:** Confirm the “Key generation policy” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M09.01-C026-T09 · Reset and retention:** Restore only the disposable “Key generation policy” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M09.01-C026-T10 · Negative regression:** Register the “Key generation policy” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M09.01-C027 · Change / failure test

**Original checklist item:** Exercise key generation policy when an online key is rotated or revoked while old credentials remain cached; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M09.01-C027-T01 · Scenario record:** Write the “Key generation policy” change/failure scenario exactly as supplied: an online key is rotated or revoked while old credentials remain cached; identify the property that must remain true: “Keys are generated from appropriate nondeterministic security inputs”.
- [ ] **UC-M09.01-C027-T02 · Baseline capture:** Create a known-valid “Key generation policy” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M09.01-C027-T03 · Injection map:** Locate the “Key generation policy” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M09.01-C027-T04 · Disposition oracle:** Define the legal intermediate and final “Key generation policy” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M09.01-C027-T05 · Controlled trigger:** Introduce the controlled “Key generation policy” scenario in the disposable fixture: an online key is rotated or revoked while old credentials remain cached; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M09.01-C027-T06 · Intermediate inspection:** Inspect the “Key generation policy” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M09.01-C027-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Key generation policy”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M09.01-C027-T08 · Stale-evidence cleanup:** Invalidate superseded “Key generation policy” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M09.01-C027-T09 · Repeat and compare:** Repeat the selected “Key generation policy” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M09.01-C027-T10 · Failure evidence:** Publish the “Key generation policy” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M09.01-C028 · Bounds

**Original checklist item:** Choose, document and test limits for key count and generation verification steps; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M09.01-C028-T01 · Quantity inventory:** Create a measurement inventory for “Key generation policy”: “Key count and generation verification steps”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M09.01-C028-T02 · Measurement method:** Choose how to observe each “Key generation policy” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M09.01-C028-T03 · Budget decision:** Select justified resource and input limits for “Key generation policy”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M09.01-C028-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Key generation policy” cases for “Key count and generation verification steps”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M09.01-C028-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Key generation policy” limit; preserve “Keys are generated from appropriate nondeterministic security inputs”.
- [ ] **UC-M09.01-C028-T06 · Normal measurement:** Run or review the normal “Key generation policy” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M09.01-C028-T07 · At-limit measurement:** Exercise the “Key generation policy” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M09.01-C028-T08 · Over-limit measurement:** Exercise the “Key generation policy” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M09.01-C028-T09 · Uncovered-scope report:** List the “Key generation policy” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M09.01-C028-T10 · Limit evidence:** Publish the selected “Key generation policy” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M09.01-C029 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for key generation policy with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M09.01-C029-T01 · Event inventory:** List the “Key generation policy” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M09.01-C029-T02 · Diagnostic schema:** Define nonsecret fields for “Key generation policy” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M09.01-C029-T03 · Failure mapping:** Map each documented “Key generation policy” refusal or error to a diagnostic outcome; include “A release key derives from a deterministic witness seed” and prohibit conversion into a success message.
- [ ] **UC-M09.01-C029-T04 · Emission path:** Add the “Key generation policy” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M09.01-C029-T05 · Redaction check:** Test “Key generation policy” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M09.01-C029-T06 · Output budget:** Set and exercise bounded “Key generation policy” message size, rate and retention compatible with “Key count and generation verification steps”; define truncation behavior that preserves the final reason.
- [ ] **UC-M09.01-C029-T07 · Success/refusal fixtures:** Capture “Key generation policy” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M09.01-C029-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Key generation policy” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M09.01-C029-T09 · Operator review:** Read the “Key generation policy” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M09.01-C029-T10 · Diagnostic evidence:** Publish redacted “Key generation policy” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M09.01-C030 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for key generation policy; label unexecuted checks as untested.

- [ ] **UC-M09.01-C030-T01 · Evidence inventory:** List the “Key generation policy” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M09.01-C030-T02 · Artifact references:** Record the exact “Key generation policy” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M09.01-C030-T03 · Fixture references:** Attach the “Key generation policy” fixture IDs, input identities and oracle definition; preserve the source counterexample “A release key derives from a deterministic witness seed” as a distinct evidence case.
- [ ] **UC-M09.01-C030-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Key generation policy”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M09.01-C030-T05 · Environment record:** Record the actual “Key generation policy” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M09.01-C030-T06 · Expected versus observed:** Pair every “Key generation policy” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M09.01-C030-T07 · Failure and limit records:** Attach “Key generation policy” change/failure and bounds evidence where required; include uncovered “Key count and generation verification steps” and unresolved violations of “Keys are generated from appropriate nondeterministic security inputs”.
- [ ] **UC-M09.01-C030-T08 · Evidence hygiene:** Check the “Key generation policy” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M09.01-C030-T09 · Reproduction review:** Have the “Key generation policy” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M09.01-C030-T10 · Acceptance linkage:** Link the “Key generation policy” evidence to its parent and UC-M09.01 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 04. Scoped enrollment

**Source delivery:** Require explicit authenticated approval of a key's role and resource scope.

**Source invariant:** An enrolled narrow signer cannot approve unrelated releases.

**Source negative case:** A development key is enrolled with implicit universal authority.

**Source bounded quantities:** Enrollment records and scope rules.

### UC-M09.01-C031 · Contract

**Original checklist item:** Specify scoped enrollment inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M09.01-C031-T01 · Scope statement:** Draft the operation boundary for “Scoped enrollment” within Independent key lifecycle; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M09.01-C031-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Scoped enrollment”; record each producer, representation and missing-value meaning.
- [ ] **UC-M09.01-C031-T03 · Output inventory:** List the outputs of “Scoped enrollment” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M09.01-C031-T04 · Field dictionary:** Create a field-and-term dictionary for “Scoped enrollment”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M09.01-C031-T05 · Prerequisite contract:** Map “Scoped enrollment” to the source component prerequisites (UC-M04.08, UC-M06.03); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M09.01-C031-T06 · Authority map:** Identify who may produce, change and consume “Scoped enrollment”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M09.01-C031-T07 · Invariant clause:** Add a normative clause for “Scoped enrollment” that preserves “An enrolled narrow signer cannot approve unrelated releases”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M09.01-C031-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Scoped enrollment”; include the source counterexample “A development key is enrolled with implicit universal authority” and the intended safe disposition.
- [ ] **UC-M09.01-C031-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Enrollment records and scope rules” in the “Scoped enrollment” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M09.01-C031-T10 · Contract review:** Review the “Scoped enrollment” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M09.01-C032 · Delivery

**Original checklist item:** Require explicit authenticated approval of a key's role and resource scope.

- [ ] **UC-M09.01-C032-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Scoped enrollment”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M09.01-C032-T02 · Change plan:** Break the source delivery for “Scoped enrollment” into concrete edit targets and reviewable outputs; keep the UC-M09.01 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M09.01-C032-T03 · Core artifact:** Implement the smallest selected-profile change for “Scoped enrollment” that realizes this source instruction: Require explicit authenticated approval of a key's role and resource scope.
- [ ] **UC-M09.01-C032-T04 · Concrete realization:** Trace “Scoped enrollment” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M09.01-C032-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Scoped enrollment” needed to preserve “An enrolled narrow signer cannot approve unrelated releases”; record an enforcement gap where only a model exists.
- [ ] **UC-M09.01-C032-T06 · Dependency connection:** Connect the “Scoped enrollment” implementation to operator trust roots, signer roles and image-admission decisions; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M09.01-C032-T07 · Resource behavior:** Account for “Enrollment records and scope rules” in “Scoped enrollment”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M09.01-C032-T08 · Delivery check:** Run the smallest real “Scoped enrollment” path and its adverse fixture “A development key is enrolled with implicit universal authority”; retain actual output, state effects and final disposition.
- [ ] **UC-M09.01-C032-T09 · Patch review:** Review the “Scoped enrollment” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M09.01-C032-T10 · Delivery handoff:** Publish the “Scoped enrollment” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M09.01-C033 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: An enrolled narrow signer cannot approve unrelated releases. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M09.01-C033-T01 · Named property:** Create a stable property/check name under this parent for “Scoped enrollment”; copy its required invariant exactly: “An enrolled narrow signer cannot approve unrelated releases”.
- [ ] **UC-M09.01-C033-T02 · Observable terms:** Define each term in the “Scoped enrollment” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M09.01-C033-T03 · Precondition set:** List the preconditions under which “An enrolled narrow signer cannot approve unrelated releases” must hold for “Scoped enrollment”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M09.01-C033-T04 · Transition coverage:** Map the “Scoped enrollment” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M09.01-C033-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Scoped enrollment”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M09.01-C033-T06 · Satisfying fixture:** Create a concrete “Scoped enrollment” case that satisfies “An enrolled narrow signer cannot approve unrelated releases”; record its expected observation before running the assertion or review.
- [ ] **UC-M09.01-C033-T07 · Violating fixture:** Create the source counterexample “A development key is enrolled with implicit universal authority” for “Scoped enrollment”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M09.01-C033-T08 · Enforcement evidence:** Exercise the “Scoped enrollment” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M09.01-C033-T09 · Regression linkage:** Link the “Scoped enrollment” property to changes in operator trust roots, signer roles and image-admission decisions; record which dependency or contract changes require rerunning it.
- [ ] **UC-M09.01-C033-T10 · Property disposition:** Compare the satisfying and violating “Scoped enrollment” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M09.01-C034 · Integration

**Original checklist item:** Integrate scoped enrollment with operator trust roots, signer roles and image-admission decisions; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M09.01-C034-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Scoped enrollment” across operator trust roots, signer roles and image-admission decisions; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M09.01-C034-T02 · Field mapping:** Map every “Scoped enrollment” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M09.01-C034-T03 · Prerequisite identities:** Record the actual prerequisites for “Scoped enrollment” (source dependency list: UC-M04.08, UC-M06.03); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M09.01-C034-T04 · Ownership agreement:** Specify who owns “Scoped enrollment” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M09.01-C034-T05 · Handoff implementation:** Connect “Scoped enrollment” through the mapped seam using the real adapter or explicit specification reference; preserve “An enrolled narrow signer cannot approve unrelated releases” across the handoff.
- [ ] **UC-M09.01-C034-T06 · Absent-input case:** Omit one required “Scoped enrollment” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M09.01-C034-T07 · Stale-input case:** Supply an outdated “Scoped enrollment” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M09.01-C034-T08 · Incompatible-input case:** Supply an incompatible “Scoped enrollment” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M09.01-C034-T09 · Valid integration trace:** Run a valid “Scoped enrollment” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M09.01-C034-T10 · Seam review:** Reconcile the “Scoped enrollment” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M09.01-C035 · Valid-case test

**Original checklist item:** Run a valid-path fixture for scoped enrollment; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M09.01-C035-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Scoped enrollment” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M09.01-C035-T02 · Expected-result oracle:** Specify the “Scoped enrollment” expected result independently of the implementation output; include the property “An enrolled narrow signer cannot approve unrelated releases” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M09.01-C035-T03 · Fixture material:** Create the concrete “Scoped enrollment” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M09.01-C035-T04 · Target preparation:** Prepare the “Scoped enrollment” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M09.01-C035-T05 · Initial-state record:** Record the initial “Scoped enrollment” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M09.01-C035-T06 · Valid-path execution:** Execute the “Scoped enrollment” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M09.01-C035-T07 · Outcome comparison:** Compare every declared “Scoped enrollment” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M09.01-C035-T08 · State and bounds check:** Inspect the “Scoped enrollment” ownership/state effects and actual use of “Enrollment records and scope rules”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M09.01-C035-T09 · Repeatability check:** Repeat the same “Scoped enrollment” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M09.01-C035-T10 · Positive evidence:** Attach the “Scoped enrollment” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M09.01-C036 · Negative test

**Original checklist item:** Negative case: A development key is enrolled with implicit universal authority. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M09.01-C036-T01 · Adverse-case definition:** Create a test record for the exact “Scoped enrollment” source counterexample: “A development key is enrolled with implicit universal authority”; state which precondition or invariant it challenges.
- [ ] **UC-M09.01-C036-T02 · Safe fixture boundary:** Define the contained test boundary for “Scoped enrollment”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M09.01-C036-T03 · Valid control:** Construct a valid “Scoped enrollment” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M09.01-C036-T04 · Minimal adverse input:** Derive the “Scoped enrollment” adverse fixture from the control with the smallest documented change needed to reproduce “A development key is enrolled with implicit universal authority”; retain that change as reproducible data.
- [ ] **UC-M09.01-C036-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Scoped enrollment”; require “An enrolled narrow signer cannot approve unrelated releases” and forbid a false-success verdict.
- [ ] **UC-M09.01-C036-T06 · Adverse execution:** Exercise the “Scoped enrollment” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M09.01-C036-T07 · Effect inspection:** Inspect “Scoped enrollment” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M09.01-C036-T08 · Refusal versus failure:** Confirm the “Scoped enrollment” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M09.01-C036-T09 · Reset and retention:** Restore only the disposable “Scoped enrollment” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M09.01-C036-T10 · Negative regression:** Register the “Scoped enrollment” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M09.01-C037 · Change / failure test

**Original checklist item:** Exercise scoped enrollment when an online key is rotated or revoked while old credentials remain cached; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M09.01-C037-T01 · Scenario record:** Write the “Scoped enrollment” change/failure scenario exactly as supplied: an online key is rotated or revoked while old credentials remain cached; identify the property that must remain true: “An enrolled narrow signer cannot approve unrelated releases”.
- [ ] **UC-M09.01-C037-T02 · Baseline capture:** Create a known-valid “Scoped enrollment” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M09.01-C037-T03 · Injection map:** Locate the “Scoped enrollment” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M09.01-C037-T04 · Disposition oracle:** Define the legal intermediate and final “Scoped enrollment” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M09.01-C037-T05 · Controlled trigger:** Introduce the controlled “Scoped enrollment” scenario in the disposable fixture: an online key is rotated or revoked while old credentials remain cached; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M09.01-C037-T06 · Intermediate inspection:** Inspect the “Scoped enrollment” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M09.01-C037-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Scoped enrollment”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M09.01-C037-T08 · Stale-evidence cleanup:** Invalidate superseded “Scoped enrollment” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M09.01-C037-T09 · Repeat and compare:** Repeat the selected “Scoped enrollment” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M09.01-C037-T10 · Failure evidence:** Publish the “Scoped enrollment” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M09.01-C038 · Bounds

**Original checklist item:** Choose, document and test limits for enrollment records and scope rules; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M09.01-C038-T01 · Quantity inventory:** Create a measurement inventory for “Scoped enrollment”: “Enrollment records and scope rules”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M09.01-C038-T02 · Measurement method:** Choose how to observe each “Scoped enrollment” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M09.01-C038-T03 · Budget decision:** Select justified resource and input limits for “Scoped enrollment”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M09.01-C038-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Scoped enrollment” cases for “Enrollment records and scope rules”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M09.01-C038-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Scoped enrollment” limit; preserve “An enrolled narrow signer cannot approve unrelated releases”.
- [ ] **UC-M09.01-C038-T06 · Normal measurement:** Run or review the normal “Scoped enrollment” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M09.01-C038-T07 · At-limit measurement:** Exercise the “Scoped enrollment” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M09.01-C038-T08 · Over-limit measurement:** Exercise the “Scoped enrollment” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M09.01-C038-T09 · Uncovered-scope report:** List the “Scoped enrollment” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M09.01-C038-T10 · Limit evidence:** Publish the selected “Scoped enrollment” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M09.01-C039 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for scoped enrollment with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M09.01-C039-T01 · Event inventory:** List the “Scoped enrollment” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M09.01-C039-T02 · Diagnostic schema:** Define nonsecret fields for “Scoped enrollment” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M09.01-C039-T03 · Failure mapping:** Map each documented “Scoped enrollment” refusal or error to a diagnostic outcome; include “A development key is enrolled with implicit universal authority” and prohibit conversion into a success message.
- [ ] **UC-M09.01-C039-T04 · Emission path:** Add the “Scoped enrollment” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M09.01-C039-T05 · Redaction check:** Test “Scoped enrollment” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M09.01-C039-T06 · Output budget:** Set and exercise bounded “Scoped enrollment” message size, rate and retention compatible with “Enrollment records and scope rules”; define truncation behavior that preserves the final reason.
- [ ] **UC-M09.01-C039-T07 · Success/refusal fixtures:** Capture “Scoped enrollment” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M09.01-C039-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Scoped enrollment” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M09.01-C039-T09 · Operator review:** Read the “Scoped enrollment” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M09.01-C039-T10 · Diagnostic evidence:** Publish redacted “Scoped enrollment” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M09.01-C040 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for scoped enrollment; label unexecuted checks as untested.

- [ ] **UC-M09.01-C040-T01 · Evidence inventory:** List the “Scoped enrollment” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M09.01-C040-T02 · Artifact references:** Record the exact “Scoped enrollment” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M09.01-C040-T03 · Fixture references:** Attach the “Scoped enrollment” fixture IDs, input identities and oracle definition; preserve the source counterexample “A development key is enrolled with implicit universal authority” as a distinct evidence case.
- [ ] **UC-M09.01-C040-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Scoped enrollment”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M09.01-C040-T05 · Environment record:** Record the actual “Scoped enrollment” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M09.01-C040-T06 · Expected versus observed:** Pair every “Scoped enrollment” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M09.01-C040-T07 · Failure and limit records:** Attach “Scoped enrollment” change/failure and bounds evidence where required; include uncovered “Enrollment records and scope rules” and unresolved violations of “An enrolled narrow signer cannot approve unrelated releases”.
- [ ] **UC-M09.01-C040-T08 · Evidence hygiene:** Check the “Scoped enrollment” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M09.01-C040-T09 · Reproduction review:** Have the “Scoped enrollment” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M09.01-C040-T10 · Acceptance linkage:** Link the “Scoped enrollment” evidence to its parent and UC-M09.01 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 05. Key rotation

**Source delivery:** Support controlled introduction and retirement of replacement keys.

**Source invariant:** Rotation preserves a verifiable authorized trust transition.

**Source negative case:** A new key replaces the old one without an approved transition record.

**Source bounded quantities:** Overlap period and retained metadata versions.

### UC-M09.01-C041 · Contract

**Original checklist item:** Specify key rotation inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M09.01-C041-T01 · Scope statement:** Draft the operation boundary for “Key rotation” within Independent key lifecycle; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M09.01-C041-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Key rotation”; record each producer, representation and missing-value meaning.
- [ ] **UC-M09.01-C041-T03 · Output inventory:** List the outputs of “Key rotation” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M09.01-C041-T04 · Field dictionary:** Create a field-and-term dictionary for “Key rotation”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M09.01-C041-T05 · Prerequisite contract:** Map “Key rotation” to the source component prerequisites (UC-M04.08, UC-M06.03); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M09.01-C041-T06 · Authority map:** Identify who may produce, change and consume “Key rotation”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M09.01-C041-T07 · Invariant clause:** Add a normative clause for “Key rotation” that preserves “Rotation preserves a verifiable authorized trust transition”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M09.01-C041-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Key rotation”; include the source counterexample “A new key replaces the old one without an approved transition record” and the intended safe disposition.
- [ ] **UC-M09.01-C041-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Overlap period and retained metadata versions” in the “Key rotation” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M09.01-C041-T10 · Contract review:** Review the “Key rotation” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M09.01-C042 · Delivery

**Original checklist item:** Support controlled introduction and retirement of replacement keys.

- [ ] **UC-M09.01-C042-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Key rotation”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M09.01-C042-T02 · Change plan:** Break the source delivery for “Key rotation” into concrete edit targets and reviewable outputs; keep the UC-M09.01 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M09.01-C042-T03 · Core artifact:** Implement the smallest selected-profile change for “Key rotation” that realizes this source instruction: Support controlled introduction and retirement of replacement keys.
- [ ] **UC-M09.01-C042-T04 · Concrete realization:** Trace “Key rotation” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M09.01-C042-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Key rotation” needed to preserve “Rotation preserves a verifiable authorized trust transition”; record an enforcement gap where only a model exists.
- [ ] **UC-M09.01-C042-T06 · Dependency connection:** Connect the “Key rotation” implementation to operator trust roots, signer roles and image-admission decisions; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M09.01-C042-T07 · Resource behavior:** Account for “Overlap period and retained metadata versions” in “Key rotation”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M09.01-C042-T08 · Delivery check:** Run the smallest real “Key rotation” path and its adverse fixture “A new key replaces the old one without an approved transition record”; retain actual output, state effects and final disposition.
- [ ] **UC-M09.01-C042-T09 · Patch review:** Review the “Key rotation” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M09.01-C042-T10 · Delivery handoff:** Publish the “Key rotation” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M09.01-C043 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Rotation preserves a verifiable authorized trust transition. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M09.01-C043-T01 · Named property:** Create a stable property/check name under this parent for “Key rotation”; copy its required invariant exactly: “Rotation preserves a verifiable authorized trust transition”.
- [ ] **UC-M09.01-C043-T02 · Observable terms:** Define each term in the “Key rotation” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M09.01-C043-T03 · Precondition set:** List the preconditions under which “Rotation preserves a verifiable authorized trust transition” must hold for “Key rotation”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M09.01-C043-T04 · Transition coverage:** Map the “Key rotation” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M09.01-C043-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Key rotation”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M09.01-C043-T06 · Satisfying fixture:** Create a concrete “Key rotation” case that satisfies “Rotation preserves a verifiable authorized trust transition”; record its expected observation before running the assertion or review.
- [ ] **UC-M09.01-C043-T07 · Violating fixture:** Create the source counterexample “A new key replaces the old one without an approved transition record” for “Key rotation”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M09.01-C043-T08 · Enforcement evidence:** Exercise the “Key rotation” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M09.01-C043-T09 · Regression linkage:** Link the “Key rotation” property to changes in operator trust roots, signer roles and image-admission decisions; record which dependency or contract changes require rerunning it.
- [ ] **UC-M09.01-C043-T10 · Property disposition:** Compare the satisfying and violating “Key rotation” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M09.01-C044 · Integration

**Original checklist item:** Integrate key rotation with operator trust roots, signer roles and image-admission decisions; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M09.01-C044-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Key rotation” across operator trust roots, signer roles and image-admission decisions; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M09.01-C044-T02 · Field mapping:** Map every “Key rotation” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M09.01-C044-T03 · Prerequisite identities:** Record the actual prerequisites for “Key rotation” (source dependency list: UC-M04.08, UC-M06.03); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M09.01-C044-T04 · Ownership agreement:** Specify who owns “Key rotation” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M09.01-C044-T05 · Handoff implementation:** Connect “Key rotation” through the mapped seam using the real adapter or explicit specification reference; preserve “Rotation preserves a verifiable authorized trust transition” across the handoff.
- [ ] **UC-M09.01-C044-T06 · Absent-input case:** Omit one required “Key rotation” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M09.01-C044-T07 · Stale-input case:** Supply an outdated “Key rotation” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M09.01-C044-T08 · Incompatible-input case:** Supply an incompatible “Key rotation” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M09.01-C044-T09 · Valid integration trace:** Run a valid “Key rotation” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M09.01-C044-T10 · Seam review:** Reconcile the “Key rotation” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M09.01-C045 · Valid-case test

**Original checklist item:** Run a valid-path fixture for key rotation; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M09.01-C045-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Key rotation” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M09.01-C045-T02 · Expected-result oracle:** Specify the “Key rotation” expected result independently of the implementation output; include the property “Rotation preserves a verifiable authorized trust transition” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M09.01-C045-T03 · Fixture material:** Create the concrete “Key rotation” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M09.01-C045-T04 · Target preparation:** Prepare the “Key rotation” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M09.01-C045-T05 · Initial-state record:** Record the initial “Key rotation” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M09.01-C045-T06 · Valid-path execution:** Execute the “Key rotation” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M09.01-C045-T07 · Outcome comparison:** Compare every declared “Key rotation” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M09.01-C045-T08 · State and bounds check:** Inspect the “Key rotation” ownership/state effects and actual use of “Overlap period and retained metadata versions”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M09.01-C045-T09 · Repeatability check:** Repeat the same “Key rotation” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M09.01-C045-T10 · Positive evidence:** Attach the “Key rotation” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M09.01-C046 · Negative test

**Original checklist item:** Negative case: A new key replaces the old one without an approved transition record. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M09.01-C046-T01 · Adverse-case definition:** Create a test record for the exact “Key rotation” source counterexample: “A new key replaces the old one without an approved transition record”; state which precondition or invariant it challenges.
- [ ] **UC-M09.01-C046-T02 · Safe fixture boundary:** Define the contained test boundary for “Key rotation”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M09.01-C046-T03 · Valid control:** Construct a valid “Key rotation” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M09.01-C046-T04 · Minimal adverse input:** Derive the “Key rotation” adverse fixture from the control with the smallest documented change needed to reproduce “A new key replaces the old one without an approved transition record”; retain that change as reproducible data.
- [ ] **UC-M09.01-C046-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Key rotation”; require “Rotation preserves a verifiable authorized trust transition” and forbid a false-success verdict.
- [ ] **UC-M09.01-C046-T06 · Adverse execution:** Exercise the “Key rotation” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M09.01-C046-T07 · Effect inspection:** Inspect “Key rotation” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M09.01-C046-T08 · Refusal versus failure:** Confirm the “Key rotation” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M09.01-C046-T09 · Reset and retention:** Restore only the disposable “Key rotation” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M09.01-C046-T10 · Negative regression:** Register the “Key rotation” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M09.01-C047 · Change / failure test

**Original checklist item:** Exercise key rotation when an online key is rotated or revoked while old credentials remain cached; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M09.01-C047-T01 · Scenario record:** Write the “Key rotation” change/failure scenario exactly as supplied: an online key is rotated or revoked while old credentials remain cached; identify the property that must remain true: “Rotation preserves a verifiable authorized trust transition”.
- [ ] **UC-M09.01-C047-T02 · Baseline capture:** Create a known-valid “Key rotation” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M09.01-C047-T03 · Injection map:** Locate the “Key rotation” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M09.01-C047-T04 · Disposition oracle:** Define the legal intermediate and final “Key rotation” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M09.01-C047-T05 · Controlled trigger:** Introduce the controlled “Key rotation” scenario in the disposable fixture: an online key is rotated or revoked while old credentials remain cached; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M09.01-C047-T06 · Intermediate inspection:** Inspect the “Key rotation” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M09.01-C047-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Key rotation”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M09.01-C047-T08 · Stale-evidence cleanup:** Invalidate superseded “Key rotation” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M09.01-C047-T09 · Repeat and compare:** Repeat the selected “Key rotation” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M09.01-C047-T10 · Failure evidence:** Publish the “Key rotation” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M09.01-C048 · Bounds

**Original checklist item:** Choose, document and test limits for overlap period and retained metadata versions; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M09.01-C048-T01 · Quantity inventory:** Create a measurement inventory for “Key rotation”: “Overlap period and retained metadata versions”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M09.01-C048-T02 · Measurement method:** Choose how to observe each “Key rotation” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M09.01-C048-T03 · Budget decision:** Select justified resource and input limits for “Key rotation”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M09.01-C048-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Key rotation” cases for “Overlap period and retained metadata versions”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M09.01-C048-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Key rotation” limit; preserve “Rotation preserves a verifiable authorized trust transition”.
- [ ] **UC-M09.01-C048-T06 · Normal measurement:** Run or review the normal “Key rotation” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M09.01-C048-T07 · At-limit measurement:** Exercise the “Key rotation” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M09.01-C048-T08 · Over-limit measurement:** Exercise the “Key rotation” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M09.01-C048-T09 · Uncovered-scope report:** List the “Key rotation” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M09.01-C048-T10 · Limit evidence:** Publish the selected “Key rotation” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M09.01-C049 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for key rotation with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M09.01-C049-T01 · Event inventory:** List the “Key rotation” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M09.01-C049-T02 · Diagnostic schema:** Define nonsecret fields for “Key rotation” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M09.01-C049-T03 · Failure mapping:** Map each documented “Key rotation” refusal or error to a diagnostic outcome; include “A new key replaces the old one without an approved transition record” and prohibit conversion into a success message.
- [ ] **UC-M09.01-C049-T04 · Emission path:** Add the “Key rotation” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M09.01-C049-T05 · Redaction check:** Test “Key rotation” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M09.01-C049-T06 · Output budget:** Set and exercise bounded “Key rotation” message size, rate and retention compatible with “Overlap period and retained metadata versions”; define truncation behavior that preserves the final reason.
- [ ] **UC-M09.01-C049-T07 · Success/refusal fixtures:** Capture “Key rotation” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M09.01-C049-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Key rotation” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M09.01-C049-T09 · Operator review:** Read the “Key rotation” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M09.01-C049-T10 · Diagnostic evidence:** Publish redacted “Key rotation” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M09.01-C050 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for key rotation; label unexecuted checks as untested.

- [ ] **UC-M09.01-C050-T01 · Evidence inventory:** List the “Key rotation” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M09.01-C050-T02 · Artifact references:** Record the exact “Key rotation” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M09.01-C050-T03 · Fixture references:** Attach the “Key rotation” fixture IDs, input identities and oracle definition; preserve the source counterexample “A new key replaces the old one without an approved transition record” as a distinct evidence case.
- [ ] **UC-M09.01-C050-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Key rotation”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M09.01-C050-T05 · Environment record:** Record the actual “Key rotation” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M09.01-C050-T06 · Expected versus observed:** Pair every “Key rotation” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M09.01-C050-T07 · Failure and limit records:** Attach “Key rotation” change/failure and bounds evidence where required; include uncovered “Overlap period and retained metadata versions” and unresolved violations of “Rotation preserves a verifiable authorized trust transition”.
- [ ] **UC-M09.01-C050-T08 · Evidence hygiene:** Check the “Key rotation” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M09.01-C050-T09 · Reproduction review:** Have the “Key rotation” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M09.01-C050-T10 · Acceptance linkage:** Link the “Key rotation” evidence to its parent and UC-M09.01 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 06. Revocation distribution

**Source delivery:** Publish and apply authenticated revocations to future admissions.

**Source invariant:** A revoked signer cannot admit new images.

**Source negative case:** An admission cache continues accepting a revoked release key.

**Source bounded quantities:** Revocation propagation time and cache entries.

### UC-M09.01-C051 · Contract

**Original checklist item:** Specify revocation distribution inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M09.01-C051-T01 · Scope statement:** Draft the operation boundary for “Revocation distribution” within Independent key lifecycle; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M09.01-C051-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Revocation distribution”; record each producer, representation and missing-value meaning.
- [ ] **UC-M09.01-C051-T03 · Output inventory:** List the outputs of “Revocation distribution” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M09.01-C051-T04 · Field dictionary:** Create a field-and-term dictionary for “Revocation distribution”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M09.01-C051-T05 · Prerequisite contract:** Map “Revocation distribution” to the source component prerequisites (UC-M04.08, UC-M06.03); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M09.01-C051-T06 · Authority map:** Identify who may produce, change and consume “Revocation distribution”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M09.01-C051-T07 · Invariant clause:** Add a normative clause for “Revocation distribution” that preserves “A revoked signer cannot admit new images”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M09.01-C051-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Revocation distribution”; include the source counterexample “An admission cache continues accepting a revoked release key” and the intended safe disposition.
- [ ] **UC-M09.01-C051-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Revocation propagation time and cache entries” in the “Revocation distribution” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M09.01-C051-T10 · Contract review:** Review the “Revocation distribution” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M09.01-C052 · Delivery

**Original checklist item:** Publish and apply authenticated revocations to future admissions.

- [ ] **UC-M09.01-C052-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Revocation distribution”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M09.01-C052-T02 · Change plan:** Break the source delivery for “Revocation distribution” into concrete edit targets and reviewable outputs; keep the UC-M09.01 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M09.01-C052-T03 · Core artifact:** Create the “Revocation distribution” output artifact for this source instruction: Publish and apply authenticated revocations to future admissions.
- [ ] **UC-M09.01-C052-T04 · Concrete realization:** Populate the “Revocation distribution” artifact from identified observations; keep unknown, failed and unexecuted results distinct and exclude unapproved sensitive material.
- [ ] **UC-M09.01-C052-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Revocation distribution” needed to preserve “A revoked signer cannot admit new images”; record an enforcement gap where only a model exists.
- [ ] **UC-M09.01-C052-T06 · Dependency connection:** Connect the “Revocation distribution” implementation to operator trust roots, signer roles and image-admission decisions; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M09.01-C052-T07 · Resource behavior:** Account for “Revocation propagation time and cache entries” in “Revocation distribution”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M09.01-C052-T08 · Delivery check:** Run the smallest real “Revocation distribution” path and its adverse fixture “An admission cache continues accepting a revoked release key”; retain actual output, state effects and final disposition.
- [ ] **UC-M09.01-C052-T09 · Patch review:** Review the “Revocation distribution” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M09.01-C052-T10 · Delivery handoff:** Publish the “Revocation distribution” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M09.01-C053 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: A revoked signer cannot admit new images. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M09.01-C053-T01 · Named property:** Create a stable property/check name under this parent for “Revocation distribution”; copy its required invariant exactly: “A revoked signer cannot admit new images”.
- [ ] **UC-M09.01-C053-T02 · Observable terms:** Define each term in the “Revocation distribution” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M09.01-C053-T03 · Precondition set:** List the preconditions under which “A revoked signer cannot admit new images” must hold for “Revocation distribution”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M09.01-C053-T04 · Transition coverage:** Map the “Revocation distribution” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M09.01-C053-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Revocation distribution”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M09.01-C053-T06 · Satisfying fixture:** Create a concrete “Revocation distribution” case that satisfies “A revoked signer cannot admit new images”; record its expected observation before running the assertion or review.
- [ ] **UC-M09.01-C053-T07 · Violating fixture:** Create the source counterexample “An admission cache continues accepting a revoked release key” for “Revocation distribution”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M09.01-C053-T08 · Enforcement evidence:** Exercise the “Revocation distribution” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M09.01-C053-T09 · Regression linkage:** Link the “Revocation distribution” property to changes in operator trust roots, signer roles and image-admission decisions; record which dependency or contract changes require rerunning it.
- [ ] **UC-M09.01-C053-T10 · Property disposition:** Compare the satisfying and violating “Revocation distribution” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M09.01-C054 · Integration

**Original checklist item:** Integrate revocation distribution with operator trust roots, signer roles and image-admission decisions; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M09.01-C054-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Revocation distribution” across operator trust roots, signer roles and image-admission decisions; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M09.01-C054-T02 · Field mapping:** Map every “Revocation distribution” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M09.01-C054-T03 · Prerequisite identities:** Record the actual prerequisites for “Revocation distribution” (source dependency list: UC-M04.08, UC-M06.03); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M09.01-C054-T04 · Ownership agreement:** Specify who owns “Revocation distribution” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M09.01-C054-T05 · Handoff implementation:** Connect “Revocation distribution” through the mapped seam using the real adapter or explicit specification reference; preserve “A revoked signer cannot admit new images” across the handoff.
- [ ] **UC-M09.01-C054-T06 · Absent-input case:** Omit one required “Revocation distribution” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M09.01-C054-T07 · Stale-input case:** Supply an outdated “Revocation distribution” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M09.01-C054-T08 · Incompatible-input case:** Supply an incompatible “Revocation distribution” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M09.01-C054-T09 · Valid integration trace:** Run a valid “Revocation distribution” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M09.01-C054-T10 · Seam review:** Reconcile the “Revocation distribution” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M09.01-C055 · Valid-case test

**Original checklist item:** Run a valid-path fixture for revocation distribution; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M09.01-C055-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Revocation distribution” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M09.01-C055-T02 · Expected-result oracle:** Specify the “Revocation distribution” expected result independently of the implementation output; include the property “A revoked signer cannot admit new images” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M09.01-C055-T03 · Fixture material:** Create the concrete “Revocation distribution” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M09.01-C055-T04 · Target preparation:** Prepare the “Revocation distribution” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M09.01-C055-T05 · Initial-state record:** Record the initial “Revocation distribution” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M09.01-C055-T06 · Valid-path execution:** Execute the “Revocation distribution” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M09.01-C055-T07 · Outcome comparison:** Compare every declared “Revocation distribution” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M09.01-C055-T08 · State and bounds check:** Inspect the “Revocation distribution” ownership/state effects and actual use of “Revocation propagation time and cache entries”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M09.01-C055-T09 · Repeatability check:** Repeat the same “Revocation distribution” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M09.01-C055-T10 · Positive evidence:** Attach the “Revocation distribution” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M09.01-C056 · Negative test

**Original checklist item:** Negative case: An admission cache continues accepting a revoked release key. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M09.01-C056-T01 · Adverse-case definition:** Create a test record for the exact “Revocation distribution” source counterexample: “An admission cache continues accepting a revoked release key”; state which precondition or invariant it challenges.
- [ ] **UC-M09.01-C056-T02 · Safe fixture boundary:** Define the contained test boundary for “Revocation distribution”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M09.01-C056-T03 · Valid control:** Construct a valid “Revocation distribution” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M09.01-C056-T04 · Minimal adverse input:** Derive the “Revocation distribution” adverse fixture from the control with the smallest documented change needed to reproduce “An admission cache continues accepting a revoked release key”; retain that change as reproducible data.
- [ ] **UC-M09.01-C056-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Revocation distribution”; require “A revoked signer cannot admit new images” and forbid a false-success verdict.
- [ ] **UC-M09.01-C056-T06 · Adverse execution:** Exercise the “Revocation distribution” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M09.01-C056-T07 · Effect inspection:** Inspect “Revocation distribution” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M09.01-C056-T08 · Refusal versus failure:** Confirm the “Revocation distribution” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M09.01-C056-T09 · Reset and retention:** Restore only the disposable “Revocation distribution” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M09.01-C056-T10 · Negative regression:** Register the “Revocation distribution” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M09.01-C057 · Change / failure test

**Original checklist item:** Exercise revocation distribution when an online key is rotated or revoked while old credentials remain cached; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M09.01-C057-T01 · Scenario record:** Write the “Revocation distribution” change/failure scenario exactly as supplied: an online key is rotated or revoked while old credentials remain cached; identify the property that must remain true: “A revoked signer cannot admit new images”.
- [ ] **UC-M09.01-C057-T02 · Baseline capture:** Create a known-valid “Revocation distribution” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M09.01-C057-T03 · Injection map:** Locate the “Revocation distribution” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M09.01-C057-T04 · Disposition oracle:** Define the legal intermediate and final “Revocation distribution” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M09.01-C057-T05 · Controlled trigger:** Introduce the controlled “Revocation distribution” scenario in the disposable fixture: an online key is rotated or revoked while old credentials remain cached; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M09.01-C057-T06 · Intermediate inspection:** Inspect the “Revocation distribution” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M09.01-C057-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Revocation distribution”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M09.01-C057-T08 · Stale-evidence cleanup:** Invalidate superseded “Revocation distribution” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M09.01-C057-T09 · Repeat and compare:** Repeat the selected “Revocation distribution” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M09.01-C057-T10 · Failure evidence:** Publish the “Revocation distribution” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M09.01-C058 · Bounds

**Original checklist item:** Choose, document and test limits for revocation propagation time and cache entries; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M09.01-C058-T01 · Quantity inventory:** Create a measurement inventory for “Revocation distribution”: “Revocation propagation time and cache entries”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M09.01-C058-T02 · Measurement method:** Choose how to observe each “Revocation distribution” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M09.01-C058-T03 · Budget decision:** Select justified resource and input limits for “Revocation distribution”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M09.01-C058-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Revocation distribution” cases for “Revocation propagation time and cache entries”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M09.01-C058-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Revocation distribution” limit; preserve “A revoked signer cannot admit new images”.
- [ ] **UC-M09.01-C058-T06 · Normal measurement:** Run or review the normal “Revocation distribution” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M09.01-C058-T07 · At-limit measurement:** Exercise the “Revocation distribution” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M09.01-C058-T08 · Over-limit measurement:** Exercise the “Revocation distribution” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M09.01-C058-T09 · Uncovered-scope report:** List the “Revocation distribution” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M09.01-C058-T10 · Limit evidence:** Publish the selected “Revocation distribution” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M09.01-C059 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for revocation distribution with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M09.01-C059-T01 · Event inventory:** List the “Revocation distribution” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M09.01-C059-T02 · Diagnostic schema:** Define nonsecret fields for “Revocation distribution” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M09.01-C059-T03 · Failure mapping:** Map each documented “Revocation distribution” refusal or error to a diagnostic outcome; include “An admission cache continues accepting a revoked release key” and prohibit conversion into a success message.
- [ ] **UC-M09.01-C059-T04 · Emission path:** Add the “Revocation distribution” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M09.01-C059-T05 · Redaction check:** Test “Revocation distribution” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M09.01-C059-T06 · Output budget:** Set and exercise bounded “Revocation distribution” message size, rate and retention compatible with “Revocation propagation time and cache entries”; define truncation behavior that preserves the final reason.
- [ ] **UC-M09.01-C059-T07 · Success/refusal fixtures:** Capture “Revocation distribution” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M09.01-C059-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Revocation distribution” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M09.01-C059-T09 · Operator review:** Read the “Revocation distribution” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M09.01-C059-T10 · Diagnostic evidence:** Publish redacted “Revocation distribution” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M09.01-C060 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for revocation distribution; label unexecuted checks as untested.

- [ ] **UC-M09.01-C060-T01 · Evidence inventory:** List the “Revocation distribution” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M09.01-C060-T02 · Artifact references:** Record the exact “Revocation distribution” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M09.01-C060-T03 · Fixture references:** Attach the “Revocation distribution” fixture IDs, input identities and oracle definition; preserve the source counterexample “An admission cache continues accepting a revoked release key” as a distinct evidence case.
- [ ] **UC-M09.01-C060-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Revocation distribution”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M09.01-C060-T05 · Environment record:** Record the actual “Revocation distribution” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M09.01-C060-T06 · Expected versus observed:** Pair every “Revocation distribution” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M09.01-C060-T07 · Failure and limit records:** Attach “Revocation distribution” change/failure and bounds evidence where required; include uncovered “Revocation propagation time and cache entries” and unresolved violations of “A revoked signer cannot admit new images”.
- [ ] **UC-M09.01-C060-T08 · Evidence hygiene:** Check the “Revocation distribution” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M09.01-C060-T09 · Reproduction review:** Have the “Revocation distribution” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M09.01-C060-T10 · Acceptance linkage:** Link the “Revocation distribution” evidence to its parent and UC-M09.01 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 07. Trust storage integrity

**Source delivery:** Protect operator trust configuration separately from mutable cargo state.

**Source invariant:** Cargo modification cannot rewrite its own admission authority.

**Source negative case:** An archive overwrites the trust-root configuration path.

**Source bounded quantities:** Trust files and authorized update paths.

### UC-M09.01-C061 · Contract

**Original checklist item:** Specify trust storage integrity inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M09.01-C061-T01 · Scope statement:** Draft the operation boundary for “Trust storage integrity” within Independent key lifecycle; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M09.01-C061-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Trust storage integrity”; record each producer, representation and missing-value meaning.
- [ ] **UC-M09.01-C061-T03 · Output inventory:** List the outputs of “Trust storage integrity” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M09.01-C061-T04 · Field dictionary:** Create a field-and-term dictionary for “Trust storage integrity”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M09.01-C061-T05 · Prerequisite contract:** Map “Trust storage integrity” to the source component prerequisites (UC-M04.08, UC-M06.03); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M09.01-C061-T06 · Authority map:** Identify who may produce, change and consume “Trust storage integrity”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M09.01-C061-T07 · Invariant clause:** Add a normative clause for “Trust storage integrity” that preserves “Cargo modification cannot rewrite its own admission authority”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M09.01-C061-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Trust storage integrity”; include the source counterexample “An archive overwrites the trust-root configuration path” and the intended safe disposition.
- [ ] **UC-M09.01-C061-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Trust files and authorized update paths” in the “Trust storage integrity” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M09.01-C061-T10 · Contract review:** Review the “Trust storage integrity” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M09.01-C062 · Delivery

**Original checklist item:** Protect operator trust configuration separately from mutable cargo state.

- [ ] **UC-M09.01-C062-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Trust storage integrity”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M09.01-C062-T02 · Change plan:** Break the source delivery for “Trust storage integrity” into concrete edit targets and reviewable outputs; keep the UC-M09.01 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M09.01-C062-T03 · Core artifact:** Implement the smallest selected-profile change for “Trust storage integrity” that realizes this source instruction: Protect operator trust configuration separately from mutable cargo state.
- [ ] **UC-M09.01-C062-T04 · Concrete realization:** Trace “Trust storage integrity” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M09.01-C062-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Trust storage integrity” needed to preserve “Cargo modification cannot rewrite its own admission authority”; record an enforcement gap where only a model exists.
- [ ] **UC-M09.01-C062-T06 · Dependency connection:** Connect the “Trust storage integrity” implementation to operator trust roots, signer roles and image-admission decisions; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M09.01-C062-T07 · Resource behavior:** Account for “Trust files and authorized update paths” in “Trust storage integrity”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M09.01-C062-T08 · Delivery check:** Run the smallest real “Trust storage integrity” path and its adverse fixture “An archive overwrites the trust-root configuration path”; retain actual output, state effects and final disposition.
- [ ] **UC-M09.01-C062-T09 · Patch review:** Review the “Trust storage integrity” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M09.01-C062-T10 · Delivery handoff:** Publish the “Trust storage integrity” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M09.01-C063 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Cargo modification cannot rewrite its own admission authority. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M09.01-C063-T01 · Named property:** Create a stable property/check name under this parent for “Trust storage integrity”; copy its required invariant exactly: “Cargo modification cannot rewrite its own admission authority”.
- [ ] **UC-M09.01-C063-T02 · Observable terms:** Define each term in the “Trust storage integrity” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M09.01-C063-T03 · Precondition set:** List the preconditions under which “Cargo modification cannot rewrite its own admission authority” must hold for “Trust storage integrity”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M09.01-C063-T04 · Transition coverage:** Map the “Trust storage integrity” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M09.01-C063-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Trust storage integrity”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M09.01-C063-T06 · Satisfying fixture:** Create a concrete “Trust storage integrity” case that satisfies “Cargo modification cannot rewrite its own admission authority”; record its expected observation before running the assertion or review.
- [ ] **UC-M09.01-C063-T07 · Violating fixture:** Create the source counterexample “An archive overwrites the trust-root configuration path” for “Trust storage integrity”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M09.01-C063-T08 · Enforcement evidence:** Exercise the “Trust storage integrity” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M09.01-C063-T09 · Regression linkage:** Link the “Trust storage integrity” property to changes in operator trust roots, signer roles and image-admission decisions; record which dependency or contract changes require rerunning it.
- [ ] **UC-M09.01-C063-T10 · Property disposition:** Compare the satisfying and violating “Trust storage integrity” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M09.01-C064 · Integration

**Original checklist item:** Integrate trust storage integrity with operator trust roots, signer roles and image-admission decisions; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M09.01-C064-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Trust storage integrity” across operator trust roots, signer roles and image-admission decisions; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M09.01-C064-T02 · Field mapping:** Map every “Trust storage integrity” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M09.01-C064-T03 · Prerequisite identities:** Record the actual prerequisites for “Trust storage integrity” (source dependency list: UC-M04.08, UC-M06.03); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M09.01-C064-T04 · Ownership agreement:** Specify who owns “Trust storage integrity” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M09.01-C064-T05 · Handoff implementation:** Connect “Trust storage integrity” through the mapped seam using the real adapter or explicit specification reference; preserve “Cargo modification cannot rewrite its own admission authority” across the handoff.
- [ ] **UC-M09.01-C064-T06 · Absent-input case:** Omit one required “Trust storage integrity” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M09.01-C064-T07 · Stale-input case:** Supply an outdated “Trust storage integrity” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M09.01-C064-T08 · Incompatible-input case:** Supply an incompatible “Trust storage integrity” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M09.01-C064-T09 · Valid integration trace:** Run a valid “Trust storage integrity” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M09.01-C064-T10 · Seam review:** Reconcile the “Trust storage integrity” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M09.01-C065 · Valid-case test

**Original checklist item:** Run a valid-path fixture for trust storage integrity; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M09.01-C065-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Trust storage integrity” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M09.01-C065-T02 · Expected-result oracle:** Specify the “Trust storage integrity” expected result independently of the implementation output; include the property “Cargo modification cannot rewrite its own admission authority” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M09.01-C065-T03 · Fixture material:** Create the concrete “Trust storage integrity” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M09.01-C065-T04 · Target preparation:** Prepare the “Trust storage integrity” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M09.01-C065-T05 · Initial-state record:** Record the initial “Trust storage integrity” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M09.01-C065-T06 · Valid-path execution:** Execute the “Trust storage integrity” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M09.01-C065-T07 · Outcome comparison:** Compare every declared “Trust storage integrity” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M09.01-C065-T08 · State and bounds check:** Inspect the “Trust storage integrity” ownership/state effects and actual use of “Trust files and authorized update paths”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M09.01-C065-T09 · Repeatability check:** Repeat the same “Trust storage integrity” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M09.01-C065-T10 · Positive evidence:** Attach the “Trust storage integrity” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M09.01-C066 · Negative test

**Original checklist item:** Negative case: An archive overwrites the trust-root configuration path. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M09.01-C066-T01 · Adverse-case definition:** Create a test record for the exact “Trust storage integrity” source counterexample: “An archive overwrites the trust-root configuration path”; state which precondition or invariant it challenges.
- [ ] **UC-M09.01-C066-T02 · Safe fixture boundary:** Define the contained test boundary for “Trust storage integrity”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M09.01-C066-T03 · Valid control:** Construct a valid “Trust storage integrity” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M09.01-C066-T04 · Minimal adverse input:** Derive the “Trust storage integrity” adverse fixture from the control with the smallest documented change needed to reproduce “An archive overwrites the trust-root configuration path”; retain that change as reproducible data.
- [ ] **UC-M09.01-C066-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Trust storage integrity”; require “Cargo modification cannot rewrite its own admission authority” and forbid a false-success verdict.
- [ ] **UC-M09.01-C066-T06 · Adverse execution:** Exercise the “Trust storage integrity” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M09.01-C066-T07 · Effect inspection:** Inspect “Trust storage integrity” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M09.01-C066-T08 · Refusal versus failure:** Confirm the “Trust storage integrity” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M09.01-C066-T09 · Reset and retention:** Restore only the disposable “Trust storage integrity” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M09.01-C066-T10 · Negative regression:** Register the “Trust storage integrity” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M09.01-C067 · Change / failure test

**Original checklist item:** Exercise trust storage integrity when an online key is rotated or revoked while old credentials remain cached; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M09.01-C067-T01 · Scenario record:** Write the “Trust storage integrity” change/failure scenario exactly as supplied: an online key is rotated or revoked while old credentials remain cached; identify the property that must remain true: “Cargo modification cannot rewrite its own admission authority”.
- [ ] **UC-M09.01-C067-T02 · Baseline capture:** Create a known-valid “Trust storage integrity” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M09.01-C067-T03 · Injection map:** Locate the “Trust storage integrity” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M09.01-C067-T04 · Disposition oracle:** Define the legal intermediate and final “Trust storage integrity” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M09.01-C067-T05 · Controlled trigger:** Introduce the controlled “Trust storage integrity” scenario in the disposable fixture: an online key is rotated or revoked while old credentials remain cached; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M09.01-C067-T06 · Intermediate inspection:** Inspect the “Trust storage integrity” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M09.01-C067-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Trust storage integrity”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M09.01-C067-T08 · Stale-evidence cleanup:** Invalidate superseded “Trust storage integrity” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M09.01-C067-T09 · Repeat and compare:** Repeat the selected “Trust storage integrity” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M09.01-C067-T10 · Failure evidence:** Publish the “Trust storage integrity” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M09.01-C068 · Bounds

**Original checklist item:** Choose, document and test limits for trust files and authorized update paths; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M09.01-C068-T01 · Quantity inventory:** Create a measurement inventory for “Trust storage integrity”: “Trust files and authorized update paths”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M09.01-C068-T02 · Measurement method:** Choose how to observe each “Trust storage integrity” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M09.01-C068-T03 · Budget decision:** Select justified resource and input limits for “Trust storage integrity”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M09.01-C068-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Trust storage integrity” cases for “Trust files and authorized update paths”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M09.01-C068-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Trust storage integrity” limit; preserve “Cargo modification cannot rewrite its own admission authority”.
- [ ] **UC-M09.01-C068-T06 · Normal measurement:** Run or review the normal “Trust storage integrity” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M09.01-C068-T07 · At-limit measurement:** Exercise the “Trust storage integrity” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M09.01-C068-T08 · Over-limit measurement:** Exercise the “Trust storage integrity” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M09.01-C068-T09 · Uncovered-scope report:** List the “Trust storage integrity” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M09.01-C068-T10 · Limit evidence:** Publish the selected “Trust storage integrity” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M09.01-C069 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for trust storage integrity with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M09.01-C069-T01 · Event inventory:** List the “Trust storage integrity” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M09.01-C069-T02 · Diagnostic schema:** Define nonsecret fields for “Trust storage integrity” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M09.01-C069-T03 · Failure mapping:** Map each documented “Trust storage integrity” refusal or error to a diagnostic outcome; include “An archive overwrites the trust-root configuration path” and prohibit conversion into a success message.
- [ ] **UC-M09.01-C069-T04 · Emission path:** Add the “Trust storage integrity” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M09.01-C069-T05 · Redaction check:** Test “Trust storage integrity” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M09.01-C069-T06 · Output budget:** Set and exercise bounded “Trust storage integrity” message size, rate and retention compatible with “Trust files and authorized update paths”; define truncation behavior that preserves the final reason.
- [ ] **UC-M09.01-C069-T07 · Success/refusal fixtures:** Capture “Trust storage integrity” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M09.01-C069-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Trust storage integrity” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M09.01-C069-T09 · Operator review:** Read the “Trust storage integrity” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M09.01-C069-T10 · Diagnostic evidence:** Publish redacted “Trust storage integrity” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M09.01-C070 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for trust storage integrity; label unexecuted checks as untested.

- [ ] **UC-M09.01-C070-T01 · Evidence inventory:** List the “Trust storage integrity” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M09.01-C070-T02 · Artifact references:** Record the exact “Trust storage integrity” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M09.01-C070-T03 · Fixture references:** Attach the “Trust storage integrity” fixture IDs, input identities and oracle definition; preserve the source counterexample “An archive overwrites the trust-root configuration path” as a distinct evidence case.
- [ ] **UC-M09.01-C070-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Trust storage integrity”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M09.01-C070-T05 · Environment record:** Record the actual “Trust storage integrity” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M09.01-C070-T06 · Expected versus observed:** Pair every “Trust storage integrity” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M09.01-C070-T07 · Failure and limit records:** Attach “Trust storage integrity” change/failure and bounds evidence where required; include uncovered “Trust files and authorized update paths” and unresolved violations of “Cargo modification cannot rewrite its own admission authority”.
- [ ] **UC-M09.01-C070-T08 · Evidence hygiene:** Check the “Trust storage integrity” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M09.01-C070-T09 · Reproduction review:** Have the “Trust storage integrity” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M09.01-C070-T10 · Acceptance linkage:** Link the “Trust storage integrity” evidence to its parent and UC-M09.01 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 08. Role compromise response

**Source delivery:** Define containment actions for compromised online build or release keys.

**Source invariant:** One role's compromise does not automatically authorize all trust changes.

**Source negative case:** A compromised release key attempts root replacement.

**Source bounded quantities:** Affected keys and response operations.

### UC-M09.01-C071 · Contract

**Original checklist item:** Specify role compromise response inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M09.01-C071-T01 · Scope statement:** Draft the operation boundary for “Role compromise response” within Independent key lifecycle; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M09.01-C071-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Role compromise response”; record each producer, representation and missing-value meaning.
- [ ] **UC-M09.01-C071-T03 · Output inventory:** List the outputs of “Role compromise response” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M09.01-C071-T04 · Field dictionary:** Create a field-and-term dictionary for “Role compromise response”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M09.01-C071-T05 · Prerequisite contract:** Map “Role compromise response” to the source component prerequisites (UC-M04.08, UC-M06.03); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M09.01-C071-T06 · Authority map:** Identify who may produce, change and consume “Role compromise response”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M09.01-C071-T07 · Invariant clause:** Add a normative clause for “Role compromise response” that preserves “One role's compromise does not automatically authorize all trust changes”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M09.01-C071-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Role compromise response”; include the source counterexample “A compromised release key attempts root replacement” and the intended safe disposition.
- [ ] **UC-M09.01-C071-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Affected keys and response operations” in the “Role compromise response” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M09.01-C071-T10 · Contract review:** Review the “Role compromise response” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M09.01-C072 · Delivery

**Original checklist item:** Define containment actions for compromised online build or release keys.

- [ ] **UC-M09.01-C072-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Role compromise response”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M09.01-C072-T02 · Change plan:** Break the source delivery for “Role compromise response” into concrete edit targets and reviewable outputs; keep the UC-M09.01 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M09.01-C072-T03 · Core artifact:** Create the “Role compromise response” model, schema or inventory that realizes this source instruction: Define containment actions for compromised online build or release keys.
- [ ] **UC-M09.01-C072-T04 · Concrete realization:** Populate “Role compromise response” with one concrete worked case; map every required entity or field to its source and flag any unmapped entry.
- [ ] **UC-M09.01-C072-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Role compromise response” needed to preserve “One role's compromise does not automatically authorize all trust changes”; record an enforcement gap where only a model exists.
- [ ] **UC-M09.01-C072-T06 · Dependency connection:** Connect the “Role compromise response” implementation to operator trust roots, signer roles and image-admission decisions; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M09.01-C072-T07 · Resource behavior:** Account for “Affected keys and response operations” in “Role compromise response”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M09.01-C072-T08 · Delivery check:** Run the smallest real “Role compromise response” path and its adverse fixture “A compromised release key attempts root replacement”; retain actual output, state effects and final disposition.
- [ ] **UC-M09.01-C072-T09 · Patch review:** Review the “Role compromise response” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M09.01-C072-T10 · Delivery handoff:** Publish the “Role compromise response” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M09.01-C073 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: One role's compromise does not automatically authorize all trust changes. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M09.01-C073-T01 · Named property:** Create a stable property/check name under this parent for “Role compromise response”; copy its required invariant exactly: “One role's compromise does not automatically authorize all trust changes”.
- [ ] **UC-M09.01-C073-T02 · Observable terms:** Define each term in the “Role compromise response” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M09.01-C073-T03 · Precondition set:** List the preconditions under which “One role's compromise does not automatically authorize all trust changes” must hold for “Role compromise response”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M09.01-C073-T04 · Transition coverage:** Map the “Role compromise response” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M09.01-C073-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Role compromise response”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M09.01-C073-T06 · Satisfying fixture:** Create a concrete “Role compromise response” case that satisfies “One role's compromise does not automatically authorize all trust changes”; record its expected observation before running the assertion or review.
- [ ] **UC-M09.01-C073-T07 · Violating fixture:** Create the source counterexample “A compromised release key attempts root replacement” for “Role compromise response”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M09.01-C073-T08 · Enforcement evidence:** Exercise the “Role compromise response” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M09.01-C073-T09 · Regression linkage:** Link the “Role compromise response” property to changes in operator trust roots, signer roles and image-admission decisions; record which dependency or contract changes require rerunning it.
- [ ] **UC-M09.01-C073-T10 · Property disposition:** Compare the satisfying and violating “Role compromise response” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M09.01-C074 · Integration

**Original checklist item:** Integrate role compromise response with operator trust roots, signer roles and image-admission decisions; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M09.01-C074-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Role compromise response” across operator trust roots, signer roles and image-admission decisions; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M09.01-C074-T02 · Field mapping:** Map every “Role compromise response” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M09.01-C074-T03 · Prerequisite identities:** Record the actual prerequisites for “Role compromise response” (source dependency list: UC-M04.08, UC-M06.03); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M09.01-C074-T04 · Ownership agreement:** Specify who owns “Role compromise response” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M09.01-C074-T05 · Handoff implementation:** Connect “Role compromise response” through the mapped seam using the real adapter or explicit specification reference; preserve “One role's compromise does not automatically authorize all trust changes” across the handoff.
- [ ] **UC-M09.01-C074-T06 · Absent-input case:** Omit one required “Role compromise response” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M09.01-C074-T07 · Stale-input case:** Supply an outdated “Role compromise response” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M09.01-C074-T08 · Incompatible-input case:** Supply an incompatible “Role compromise response” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M09.01-C074-T09 · Valid integration trace:** Run a valid “Role compromise response” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M09.01-C074-T10 · Seam review:** Reconcile the “Role compromise response” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M09.01-C075 · Valid-case test

**Original checklist item:** Run a valid-path fixture for role compromise response; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M09.01-C075-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Role compromise response” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M09.01-C075-T02 · Expected-result oracle:** Specify the “Role compromise response” expected result independently of the implementation output; include the property “One role's compromise does not automatically authorize all trust changes” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M09.01-C075-T03 · Fixture material:** Create the concrete “Role compromise response” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M09.01-C075-T04 · Target preparation:** Prepare the “Role compromise response” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M09.01-C075-T05 · Initial-state record:** Record the initial “Role compromise response” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M09.01-C075-T06 · Valid-path execution:** Execute the “Role compromise response” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M09.01-C075-T07 · Outcome comparison:** Compare every declared “Role compromise response” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M09.01-C075-T08 · State and bounds check:** Inspect the “Role compromise response” ownership/state effects and actual use of “Affected keys and response operations”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M09.01-C075-T09 · Repeatability check:** Repeat the same “Role compromise response” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M09.01-C075-T10 · Positive evidence:** Attach the “Role compromise response” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M09.01-C076 · Negative test

**Original checklist item:** Negative case: A compromised release key attempts root replacement. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M09.01-C076-T01 · Adverse-case definition:** Create a test record for the exact “Role compromise response” source counterexample: “A compromised release key attempts root replacement”; state which precondition or invariant it challenges.
- [ ] **UC-M09.01-C076-T02 · Safe fixture boundary:** Define the contained test boundary for “Role compromise response”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M09.01-C076-T03 · Valid control:** Construct a valid “Role compromise response” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M09.01-C076-T04 · Minimal adverse input:** Derive the “Role compromise response” adverse fixture from the control with the smallest documented change needed to reproduce “A compromised release key attempts root replacement”; retain that change as reproducible data.
- [ ] **UC-M09.01-C076-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Role compromise response”; require “One role's compromise does not automatically authorize all trust changes” and forbid a false-success verdict.
- [ ] **UC-M09.01-C076-T06 · Adverse execution:** Exercise the “Role compromise response” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M09.01-C076-T07 · Effect inspection:** Inspect “Role compromise response” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M09.01-C076-T08 · Refusal versus failure:** Confirm the “Role compromise response” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M09.01-C076-T09 · Reset and retention:** Restore only the disposable “Role compromise response” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M09.01-C076-T10 · Negative regression:** Register the “Role compromise response” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M09.01-C077 · Change / failure test

**Original checklist item:** Exercise role compromise response when an online key is rotated or revoked while old credentials remain cached; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M09.01-C077-T01 · Scenario record:** Write the “Role compromise response” change/failure scenario exactly as supplied: an online key is rotated or revoked while old credentials remain cached; identify the property that must remain true: “One role's compromise does not automatically authorize all trust changes”.
- [ ] **UC-M09.01-C077-T02 · Baseline capture:** Create a known-valid “Role compromise response” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M09.01-C077-T03 · Injection map:** Locate the “Role compromise response” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M09.01-C077-T04 · Disposition oracle:** Define the legal intermediate and final “Role compromise response” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M09.01-C077-T05 · Controlled trigger:** Introduce the controlled “Role compromise response” scenario in the disposable fixture: an online key is rotated or revoked while old credentials remain cached; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M09.01-C077-T06 · Intermediate inspection:** Inspect the “Role compromise response” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M09.01-C077-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Role compromise response”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M09.01-C077-T08 · Stale-evidence cleanup:** Invalidate superseded “Role compromise response” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M09.01-C077-T09 · Repeat and compare:** Repeat the selected “Role compromise response” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M09.01-C077-T10 · Failure evidence:** Publish the “Role compromise response” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M09.01-C078 · Bounds

**Original checklist item:** Choose, document and test limits for affected keys and response operations; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M09.01-C078-T01 · Quantity inventory:** Create a measurement inventory for “Role compromise response”: “Affected keys and response operations”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M09.01-C078-T02 · Measurement method:** Choose how to observe each “Role compromise response” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M09.01-C078-T03 · Budget decision:** Select justified resource and input limits for “Role compromise response”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M09.01-C078-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Role compromise response” cases for “Affected keys and response operations”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M09.01-C078-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Role compromise response” limit; preserve “One role's compromise does not automatically authorize all trust changes”.
- [ ] **UC-M09.01-C078-T06 · Normal measurement:** Run or review the normal “Role compromise response” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M09.01-C078-T07 · At-limit measurement:** Exercise the “Role compromise response” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M09.01-C078-T08 · Over-limit measurement:** Exercise the “Role compromise response” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M09.01-C078-T09 · Uncovered-scope report:** List the “Role compromise response” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M09.01-C078-T10 · Limit evidence:** Publish the selected “Role compromise response” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M09.01-C079 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for role compromise response with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M09.01-C079-T01 · Event inventory:** List the “Role compromise response” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M09.01-C079-T02 · Diagnostic schema:** Define nonsecret fields for “Role compromise response” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M09.01-C079-T03 · Failure mapping:** Map each documented “Role compromise response” refusal or error to a diagnostic outcome; include “A compromised release key attempts root replacement” and prohibit conversion into a success message.
- [ ] **UC-M09.01-C079-T04 · Emission path:** Add the “Role compromise response” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M09.01-C079-T05 · Redaction check:** Test “Role compromise response” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M09.01-C079-T06 · Output budget:** Set and exercise bounded “Role compromise response” message size, rate and retention compatible with “Affected keys and response operations”; define truncation behavior that preserves the final reason.
- [ ] **UC-M09.01-C079-T07 · Success/refusal fixtures:** Capture “Role compromise response” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M09.01-C079-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Role compromise response” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M09.01-C079-T09 · Operator review:** Read the “Role compromise response” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M09.01-C079-T10 · Diagnostic evidence:** Publish redacted “Role compromise response” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M09.01-C080 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for role compromise response; label unexecuted checks as untested.

- [ ] **UC-M09.01-C080-T01 · Evidence inventory:** List the “Role compromise response” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M09.01-C080-T02 · Artifact references:** Record the exact “Role compromise response” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M09.01-C080-T03 · Fixture references:** Attach the “Role compromise response” fixture IDs, input identities and oracle definition; preserve the source counterexample “A compromised release key attempts root replacement” as a distinct evidence case.
- [ ] **UC-M09.01-C080-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Role compromise response”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M09.01-C080-T05 · Environment record:** Record the actual “Role compromise response” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M09.01-C080-T06 · Expected versus observed:** Pair every “Role compromise response” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M09.01-C080-T07 · Failure and limit records:** Attach “Role compromise response” change/failure and bounds evidence where required; include uncovered “Affected keys and response operations” and unresolved violations of “One role's compromise does not automatically authorize all trust changes”.
- [ ] **UC-M09.01-C080-T08 · Evidence hygiene:** Check the “Role compromise response” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M09.01-C080-T09 · Reproduction review:** Have the “Role compromise response” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M09.01-C080-T10 · Acceptance linkage:** Link the “Role compromise response” evidence to its parent and UC-M09.01 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 09. Offline verification behavior

**Source delivery:** Define how disconnected operators validate current enough approved trust state.

**Source invariant:** Offline mode does not silently ignore required revocation or validity rules.

**Source negative case:** A stale removable package carries an already revoked signer.

**Source bounded quantities:** Offline metadata age and retained approvals.

### UC-M09.01-C081 · Contract

**Original checklist item:** Specify offline verification behavior inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M09.01-C081-T01 · Scope statement:** Draft the operation boundary for “Offline verification behavior” within Independent key lifecycle; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M09.01-C081-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Offline verification behavior”; record each producer, representation and missing-value meaning.
- [ ] **UC-M09.01-C081-T03 · Output inventory:** List the outputs of “Offline verification behavior” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M09.01-C081-T04 · Field dictionary:** Create a field-and-term dictionary for “Offline verification behavior”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M09.01-C081-T05 · Prerequisite contract:** Map “Offline verification behavior” to the source component prerequisites (UC-M04.08, UC-M06.03); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M09.01-C081-T06 · Authority map:** Identify who may produce, change and consume “Offline verification behavior”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M09.01-C081-T07 · Invariant clause:** Add a normative clause for “Offline verification behavior” that preserves “Offline mode does not silently ignore required revocation or validity rules”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M09.01-C081-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Offline verification behavior”; include the source counterexample “A stale removable package carries an already revoked signer” and the intended safe disposition.
- [ ] **UC-M09.01-C081-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Offline metadata age and retained approvals” in the “Offline verification behavior” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M09.01-C081-T10 · Contract review:** Review the “Offline verification behavior” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M09.01-C082 · Delivery

**Original checklist item:** Define how disconnected operators validate current enough approved trust state.

- [ ] **UC-M09.01-C082-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Offline verification behavior”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M09.01-C082-T02 · Change plan:** Break the source delivery for “Offline verification behavior” into concrete edit targets and reviewable outputs; keep the UC-M09.01 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M09.01-C082-T03 · Core artifact:** Create the “Offline verification behavior” model, schema or inventory that realizes this source instruction: Define how disconnected operators validate current enough approved trust state.
- [ ] **UC-M09.01-C082-T04 · Concrete realization:** Populate “Offline verification behavior” with one concrete worked case; map every required entity or field to its source and flag any unmapped entry.
- [ ] **UC-M09.01-C082-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Offline verification behavior” needed to preserve “Offline mode does not silently ignore required revocation or validity rules”; record an enforcement gap where only a model exists.
- [ ] **UC-M09.01-C082-T06 · Dependency connection:** Connect the “Offline verification behavior” implementation to operator trust roots, signer roles and image-admission decisions; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M09.01-C082-T07 · Resource behavior:** Account for “Offline metadata age and retained approvals” in “Offline verification behavior”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M09.01-C082-T08 · Delivery check:** Run the smallest real “Offline verification behavior” path and its adverse fixture “A stale removable package carries an already revoked signer”; retain actual output, state effects and final disposition.
- [ ] **UC-M09.01-C082-T09 · Patch review:** Review the “Offline verification behavior” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M09.01-C082-T10 · Delivery handoff:** Publish the “Offline verification behavior” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M09.01-C083 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Offline mode does not silently ignore required revocation or validity rules. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M09.01-C083-T01 · Named property:** Create a stable property/check name under this parent for “Offline verification behavior”; copy its required invariant exactly: “Offline mode does not silently ignore required revocation or validity rules”.
- [ ] **UC-M09.01-C083-T02 · Observable terms:** Define each term in the “Offline verification behavior” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M09.01-C083-T03 · Precondition set:** List the preconditions under which “Offline mode does not silently ignore required revocation or validity rules” must hold for “Offline verification behavior”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M09.01-C083-T04 · Transition coverage:** Map the “Offline verification behavior” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M09.01-C083-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Offline verification behavior”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M09.01-C083-T06 · Satisfying fixture:** Create a concrete “Offline verification behavior” case that satisfies “Offline mode does not silently ignore required revocation or validity rules”; record its expected observation before running the assertion or review.
- [ ] **UC-M09.01-C083-T07 · Violating fixture:** Create the source counterexample “A stale removable package carries an already revoked signer” for “Offline verification behavior”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M09.01-C083-T08 · Enforcement evidence:** Exercise the “Offline verification behavior” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M09.01-C083-T09 · Regression linkage:** Link the “Offline verification behavior” property to changes in operator trust roots, signer roles and image-admission decisions; record which dependency or contract changes require rerunning it.
- [ ] **UC-M09.01-C083-T10 · Property disposition:** Compare the satisfying and violating “Offline verification behavior” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M09.01-C084 · Integration

**Original checklist item:** Integrate offline verification behavior with operator trust roots, signer roles and image-admission decisions; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M09.01-C084-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Offline verification behavior” across operator trust roots, signer roles and image-admission decisions; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M09.01-C084-T02 · Field mapping:** Map every “Offline verification behavior” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M09.01-C084-T03 · Prerequisite identities:** Record the actual prerequisites for “Offline verification behavior” (source dependency list: UC-M04.08, UC-M06.03); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M09.01-C084-T04 · Ownership agreement:** Specify who owns “Offline verification behavior” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M09.01-C084-T05 · Handoff implementation:** Connect “Offline verification behavior” through the mapped seam using the real adapter or explicit specification reference; preserve “Offline mode does not silently ignore required revocation or validity rules” across the handoff.
- [ ] **UC-M09.01-C084-T06 · Absent-input case:** Omit one required “Offline verification behavior” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M09.01-C084-T07 · Stale-input case:** Supply an outdated “Offline verification behavior” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M09.01-C084-T08 · Incompatible-input case:** Supply an incompatible “Offline verification behavior” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M09.01-C084-T09 · Valid integration trace:** Run a valid “Offline verification behavior” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M09.01-C084-T10 · Seam review:** Reconcile the “Offline verification behavior” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M09.01-C085 · Valid-case test

**Original checklist item:** Run a valid-path fixture for offline verification behavior; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M09.01-C085-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Offline verification behavior” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M09.01-C085-T02 · Expected-result oracle:** Specify the “Offline verification behavior” expected result independently of the implementation output; include the property “Offline mode does not silently ignore required revocation or validity rules” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M09.01-C085-T03 · Fixture material:** Create the concrete “Offline verification behavior” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M09.01-C085-T04 · Target preparation:** Prepare the “Offline verification behavior” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M09.01-C085-T05 · Initial-state record:** Record the initial “Offline verification behavior” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M09.01-C085-T06 · Valid-path execution:** Execute the “Offline verification behavior” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M09.01-C085-T07 · Outcome comparison:** Compare every declared “Offline verification behavior” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M09.01-C085-T08 · State and bounds check:** Inspect the “Offline verification behavior” ownership/state effects and actual use of “Offline metadata age and retained approvals”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M09.01-C085-T09 · Repeatability check:** Repeat the same “Offline verification behavior” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M09.01-C085-T10 · Positive evidence:** Attach the “Offline verification behavior” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M09.01-C086 · Negative test

**Original checklist item:** Negative case: A stale removable package carries an already revoked signer. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M09.01-C086-T01 · Adverse-case definition:** Create a test record for the exact “Offline verification behavior” source counterexample: “A stale removable package carries an already revoked signer”; state which precondition or invariant it challenges.
- [ ] **UC-M09.01-C086-T02 · Safe fixture boundary:** Define the contained test boundary for “Offline verification behavior”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M09.01-C086-T03 · Valid control:** Construct a valid “Offline verification behavior” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M09.01-C086-T04 · Minimal adverse input:** Derive the “Offline verification behavior” adverse fixture from the control with the smallest documented change needed to reproduce “A stale removable package carries an already revoked signer”; retain that change as reproducible data.
- [ ] **UC-M09.01-C086-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Offline verification behavior”; require “Offline mode does not silently ignore required revocation or validity rules” and forbid a false-success verdict.
- [ ] **UC-M09.01-C086-T06 · Adverse execution:** Exercise the “Offline verification behavior” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M09.01-C086-T07 · Effect inspection:** Inspect “Offline verification behavior” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M09.01-C086-T08 · Refusal versus failure:** Confirm the “Offline verification behavior” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M09.01-C086-T09 · Reset and retention:** Restore only the disposable “Offline verification behavior” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M09.01-C086-T10 · Negative regression:** Register the “Offline verification behavior” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M09.01-C087 · Change / failure test

**Original checklist item:** Exercise offline verification behavior when an online key is rotated or revoked while old credentials remain cached; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M09.01-C087-T01 · Scenario record:** Write the “Offline verification behavior” change/failure scenario exactly as supplied: an online key is rotated or revoked while old credentials remain cached; identify the property that must remain true: “Offline mode does not silently ignore required revocation or validity rules”.
- [ ] **UC-M09.01-C087-T02 · Baseline capture:** Create a known-valid “Offline verification behavior” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M09.01-C087-T03 · Injection map:** Locate the “Offline verification behavior” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M09.01-C087-T04 · Disposition oracle:** Define the legal intermediate and final “Offline verification behavior” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M09.01-C087-T05 · Controlled trigger:** Introduce the controlled “Offline verification behavior” scenario in the disposable fixture: an online key is rotated or revoked while old credentials remain cached; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M09.01-C087-T06 · Intermediate inspection:** Inspect the “Offline verification behavior” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M09.01-C087-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Offline verification behavior”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M09.01-C087-T08 · Stale-evidence cleanup:** Invalidate superseded “Offline verification behavior” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M09.01-C087-T09 · Repeat and compare:** Repeat the selected “Offline verification behavior” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M09.01-C087-T10 · Failure evidence:** Publish the “Offline verification behavior” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M09.01-C088 · Bounds

**Original checklist item:** Choose, document and test limits for offline metadata age and retained approvals; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M09.01-C088-T01 · Quantity inventory:** Create a measurement inventory for “Offline verification behavior”: “Offline metadata age and retained approvals”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M09.01-C088-T02 · Measurement method:** Choose how to observe each “Offline verification behavior” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M09.01-C088-T03 · Budget decision:** Select justified resource and input limits for “Offline verification behavior”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M09.01-C088-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Offline verification behavior” cases for “Offline metadata age and retained approvals”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M09.01-C088-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Offline verification behavior” limit; preserve “Offline mode does not silently ignore required revocation or validity rules”.
- [ ] **UC-M09.01-C088-T06 · Normal measurement:** Run or review the normal “Offline verification behavior” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M09.01-C088-T07 · At-limit measurement:** Exercise the “Offline verification behavior” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M09.01-C088-T08 · Over-limit measurement:** Exercise the “Offline verification behavior” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M09.01-C088-T09 · Uncovered-scope report:** List the “Offline verification behavior” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M09.01-C088-T10 · Limit evidence:** Publish the selected “Offline verification behavior” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M09.01-C089 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for offline verification behavior with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M09.01-C089-T01 · Event inventory:** List the “Offline verification behavior” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M09.01-C089-T02 · Diagnostic schema:** Define nonsecret fields for “Offline verification behavior” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M09.01-C089-T03 · Failure mapping:** Map each documented “Offline verification behavior” refusal or error to a diagnostic outcome; include “A stale removable package carries an already revoked signer” and prohibit conversion into a success message.
- [ ] **UC-M09.01-C089-T04 · Emission path:** Add the “Offline verification behavior” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M09.01-C089-T05 · Redaction check:** Test “Offline verification behavior” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M09.01-C089-T06 · Output budget:** Set and exercise bounded “Offline verification behavior” message size, rate and retention compatible with “Offline metadata age and retained approvals”; define truncation behavior that preserves the final reason.
- [ ] **UC-M09.01-C089-T07 · Success/refusal fixtures:** Capture “Offline verification behavior” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M09.01-C089-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Offline verification behavior” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M09.01-C089-T09 · Operator review:** Read the “Offline verification behavior” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M09.01-C089-T10 · Diagnostic evidence:** Publish redacted “Offline verification behavior” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M09.01-C090 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for offline verification behavior; label unexecuted checks as untested.

- [ ] **UC-M09.01-C090-T01 · Evidence inventory:** List the “Offline verification behavior” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M09.01-C090-T02 · Artifact references:** Record the exact “Offline verification behavior” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M09.01-C090-T03 · Fixture references:** Attach the “Offline verification behavior” fixture IDs, input identities and oracle definition; preserve the source counterexample “A stale removable package carries an already revoked signer” as a distinct evidence case.
- [ ] **UC-M09.01-C090-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Offline verification behavior”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M09.01-C090-T05 · Environment record:** Record the actual “Offline verification behavior” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M09.01-C090-T06 · Expected versus observed:** Pair every “Offline verification behavior” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M09.01-C090-T07 · Failure and limit records:** Attach “Offline verification behavior” change/failure and bounds evidence where required; include uncovered “Offline metadata age and retained approvals” and unresolved violations of “Offline mode does not silently ignore required revocation or validity rules”.
- [ ] **UC-M09.01-C090-T08 · Evidence hygiene:** Check the “Offline verification behavior” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M09.01-C090-T09 · Reproduction review:** Have the “Offline verification behavior” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M09.01-C090-T10 · Acceptance linkage:** Link the “Offline verification behavior” evidence to its parent and UC-M09.01 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 10. Key lifecycle qualification

**Source delivery:** Test scoped enrollment, rotation and revocation against independent verification.

**Source invariant:** Valid signatures from revoked or wrong-role keys remain refused.

**Source negative case:** A cryptographically valid revoked signature passes admission.

**Source bounded quantities:** Lifecycle scenarios and verifier runtime.

### UC-M09.01-C091 · Contract

**Original checklist item:** Specify key lifecycle qualification inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M09.01-C091-T01 · Scope statement:** Draft the operation boundary for “Key lifecycle qualification” within Independent key lifecycle; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M09.01-C091-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Key lifecycle qualification”; record each producer, representation and missing-value meaning.
- [ ] **UC-M09.01-C091-T03 · Output inventory:** List the outputs of “Key lifecycle qualification” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M09.01-C091-T04 · Field dictionary:** Create a field-and-term dictionary for “Key lifecycle qualification”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M09.01-C091-T05 · Prerequisite contract:** Map “Key lifecycle qualification” to the source component prerequisites (UC-M04.08, UC-M06.03); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M09.01-C091-T06 · Authority map:** Identify who may produce, change and consume “Key lifecycle qualification”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M09.01-C091-T07 · Invariant clause:** Add a normative clause for “Key lifecycle qualification” that preserves “Valid signatures from revoked or wrong-role keys remain refused”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M09.01-C091-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Key lifecycle qualification”; include the source counterexample “A cryptographically valid revoked signature passes admission” and the intended safe disposition.
- [ ] **UC-M09.01-C091-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Lifecycle scenarios and verifier runtime” in the “Key lifecycle qualification” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M09.01-C091-T10 · Contract review:** Review the “Key lifecycle qualification” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M09.01-C092 · Delivery

**Original checklist item:** Test scoped enrollment, rotation and revocation against independent verification.

- [ ] **UC-M09.01-C092-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Key lifecycle qualification”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M09.01-C092-T02 · Change plan:** Break the source delivery for “Key lifecycle qualification” into concrete edit targets and reviewable outputs; keep the UC-M09.01 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M09.01-C092-T03 · Core artifact:** Create the “Key lifecycle qualification” fixture or harness for this source instruction: Test scoped enrollment, rotation and revocation against independent verification.
- [ ] **UC-M09.01-C092-T04 · Concrete realization:** Connect the “Key lifecycle qualification” harness to its actual intended target, set the expected oracle before running it, and distinguish a mock/control run from a target run.
- [ ] **UC-M09.01-C092-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Key lifecycle qualification” needed to preserve “Valid signatures from revoked or wrong-role keys remain refused”; record an enforcement gap where only a model exists.
- [ ] **UC-M09.01-C092-T06 · Dependency connection:** Connect the “Key lifecycle qualification” implementation to operator trust roots, signer roles and image-admission decisions; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M09.01-C092-T07 · Resource behavior:** Account for “Lifecycle scenarios and verifier runtime” in “Key lifecycle qualification”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M09.01-C092-T08 · Delivery check:** Run the smallest real “Key lifecycle qualification” path and its adverse fixture “A cryptographically valid revoked signature passes admission”; retain actual output, state effects and final disposition.
- [ ] **UC-M09.01-C092-T09 · Patch review:** Review the “Key lifecycle qualification” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M09.01-C092-T10 · Delivery handoff:** Publish the “Key lifecycle qualification” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M09.01-C093 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Valid signatures from revoked or wrong-role keys remain refused. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M09.01-C093-T01 · Named property:** Create a stable property/check name under this parent for “Key lifecycle qualification”; copy its required invariant exactly: “Valid signatures from revoked or wrong-role keys remain refused”.
- [ ] **UC-M09.01-C093-T02 · Observable terms:** Define each term in the “Key lifecycle qualification” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M09.01-C093-T03 · Precondition set:** List the preconditions under which “Valid signatures from revoked or wrong-role keys remain refused” must hold for “Key lifecycle qualification”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M09.01-C093-T04 · Transition coverage:** Map the “Key lifecycle qualification” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M09.01-C093-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Key lifecycle qualification”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M09.01-C093-T06 · Satisfying fixture:** Create a concrete “Key lifecycle qualification” case that satisfies “Valid signatures from revoked or wrong-role keys remain refused”; record its expected observation before running the assertion or review.
- [ ] **UC-M09.01-C093-T07 · Violating fixture:** Create the source counterexample “A cryptographically valid revoked signature passes admission” for “Key lifecycle qualification”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M09.01-C093-T08 · Enforcement evidence:** Exercise the “Key lifecycle qualification” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M09.01-C093-T09 · Regression linkage:** Link the “Key lifecycle qualification” property to changes in operator trust roots, signer roles and image-admission decisions; record which dependency or contract changes require rerunning it.
- [ ] **UC-M09.01-C093-T10 · Property disposition:** Compare the satisfying and violating “Key lifecycle qualification” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M09.01-C094 · Integration

**Original checklist item:** Integrate key lifecycle qualification with operator trust roots, signer roles and image-admission decisions; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M09.01-C094-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Key lifecycle qualification” across operator trust roots, signer roles and image-admission decisions; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M09.01-C094-T02 · Field mapping:** Map every “Key lifecycle qualification” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M09.01-C094-T03 · Prerequisite identities:** Record the actual prerequisites for “Key lifecycle qualification” (source dependency list: UC-M04.08, UC-M06.03); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M09.01-C094-T04 · Ownership agreement:** Specify who owns “Key lifecycle qualification” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M09.01-C094-T05 · Handoff implementation:** Connect “Key lifecycle qualification” through the mapped seam using the real adapter or explicit specification reference; preserve “Valid signatures from revoked or wrong-role keys remain refused” across the handoff.
- [ ] **UC-M09.01-C094-T06 · Absent-input case:** Omit one required “Key lifecycle qualification” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M09.01-C094-T07 · Stale-input case:** Supply an outdated “Key lifecycle qualification” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M09.01-C094-T08 · Incompatible-input case:** Supply an incompatible “Key lifecycle qualification” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M09.01-C094-T09 · Valid integration trace:** Run a valid “Key lifecycle qualification” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M09.01-C094-T10 · Seam review:** Reconcile the “Key lifecycle qualification” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M09.01-C095 · Valid-case test

**Original checklist item:** Run a valid-path fixture for key lifecycle qualification; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M09.01-C095-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Key lifecycle qualification” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M09.01-C095-T02 · Expected-result oracle:** Specify the “Key lifecycle qualification” expected result independently of the implementation output; include the property “Valid signatures from revoked or wrong-role keys remain refused” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M09.01-C095-T03 · Fixture material:** Create the concrete “Key lifecycle qualification” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M09.01-C095-T04 · Target preparation:** Prepare the “Key lifecycle qualification” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M09.01-C095-T05 · Initial-state record:** Record the initial “Key lifecycle qualification” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M09.01-C095-T06 · Valid-path execution:** Execute the “Key lifecycle qualification” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M09.01-C095-T07 · Outcome comparison:** Compare every declared “Key lifecycle qualification” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M09.01-C095-T08 · State and bounds check:** Inspect the “Key lifecycle qualification” ownership/state effects and actual use of “Lifecycle scenarios and verifier runtime”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M09.01-C095-T09 · Repeatability check:** Repeat the same “Key lifecycle qualification” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M09.01-C095-T10 · Positive evidence:** Attach the “Key lifecycle qualification” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M09.01-C096 · Negative test

**Original checklist item:** Negative case: A cryptographically valid revoked signature passes admission. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M09.01-C096-T01 · Adverse-case definition:** Create a test record for the exact “Key lifecycle qualification” source counterexample: “A cryptographically valid revoked signature passes admission”; state which precondition or invariant it challenges.
- [ ] **UC-M09.01-C096-T02 · Safe fixture boundary:** Define the contained test boundary for “Key lifecycle qualification”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M09.01-C096-T03 · Valid control:** Construct a valid “Key lifecycle qualification” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M09.01-C096-T04 · Minimal adverse input:** Derive the “Key lifecycle qualification” adverse fixture from the control with the smallest documented change needed to reproduce “A cryptographically valid revoked signature passes admission”; retain that change as reproducible data.
- [ ] **UC-M09.01-C096-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Key lifecycle qualification”; require “Valid signatures from revoked or wrong-role keys remain refused” and forbid a false-success verdict.
- [ ] **UC-M09.01-C096-T06 · Adverse execution:** Exercise the “Key lifecycle qualification” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M09.01-C096-T07 · Effect inspection:** Inspect “Key lifecycle qualification” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M09.01-C096-T08 · Refusal versus failure:** Confirm the “Key lifecycle qualification” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M09.01-C096-T09 · Reset and retention:** Restore only the disposable “Key lifecycle qualification” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M09.01-C096-T10 · Negative regression:** Register the “Key lifecycle qualification” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M09.01-C097 · Change / failure test

**Original checklist item:** Exercise key lifecycle qualification when an online key is rotated or revoked while old credentials remain cached; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M09.01-C097-T01 · Scenario record:** Write the “Key lifecycle qualification” change/failure scenario exactly as supplied: an online key is rotated or revoked while old credentials remain cached; identify the property that must remain true: “Valid signatures from revoked or wrong-role keys remain refused”.
- [ ] **UC-M09.01-C097-T02 · Baseline capture:** Create a known-valid “Key lifecycle qualification” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M09.01-C097-T03 · Injection map:** Locate the “Key lifecycle qualification” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M09.01-C097-T04 · Disposition oracle:** Define the legal intermediate and final “Key lifecycle qualification” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M09.01-C097-T05 · Controlled trigger:** Introduce the controlled “Key lifecycle qualification” scenario in the disposable fixture: an online key is rotated or revoked while old credentials remain cached; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M09.01-C097-T06 · Intermediate inspection:** Inspect the “Key lifecycle qualification” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M09.01-C097-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Key lifecycle qualification”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M09.01-C097-T08 · Stale-evidence cleanup:** Invalidate superseded “Key lifecycle qualification” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M09.01-C097-T09 · Repeat and compare:** Repeat the selected “Key lifecycle qualification” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M09.01-C097-T10 · Failure evidence:** Publish the “Key lifecycle qualification” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M09.01-C098 · Bounds

**Original checklist item:** Choose, document and test limits for lifecycle scenarios and verifier runtime; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M09.01-C098-T01 · Quantity inventory:** Create a measurement inventory for “Key lifecycle qualification”: “Lifecycle scenarios and verifier runtime”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M09.01-C098-T02 · Measurement method:** Choose how to observe each “Key lifecycle qualification” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M09.01-C098-T03 · Budget decision:** Select justified resource and input limits for “Key lifecycle qualification”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M09.01-C098-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Key lifecycle qualification” cases for “Lifecycle scenarios and verifier runtime”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M09.01-C098-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Key lifecycle qualification” limit; preserve “Valid signatures from revoked or wrong-role keys remain refused”.
- [ ] **UC-M09.01-C098-T06 · Normal measurement:** Run or review the normal “Key lifecycle qualification” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M09.01-C098-T07 · At-limit measurement:** Exercise the “Key lifecycle qualification” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M09.01-C098-T08 · Over-limit measurement:** Exercise the “Key lifecycle qualification” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M09.01-C098-T09 · Uncovered-scope report:** List the “Key lifecycle qualification” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M09.01-C098-T10 · Limit evidence:** Publish the selected “Key lifecycle qualification” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M09.01-C099 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for key lifecycle qualification with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M09.01-C099-T01 · Event inventory:** List the “Key lifecycle qualification” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M09.01-C099-T02 · Diagnostic schema:** Define nonsecret fields for “Key lifecycle qualification” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M09.01-C099-T03 · Failure mapping:** Map each documented “Key lifecycle qualification” refusal or error to a diagnostic outcome; include “A cryptographically valid revoked signature passes admission” and prohibit conversion into a success message.
- [ ] **UC-M09.01-C099-T04 · Emission path:** Add the “Key lifecycle qualification” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M09.01-C099-T05 · Redaction check:** Test “Key lifecycle qualification” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M09.01-C099-T06 · Output budget:** Set and exercise bounded “Key lifecycle qualification” message size, rate and retention compatible with “Lifecycle scenarios and verifier runtime”; define truncation behavior that preserves the final reason.
- [ ] **UC-M09.01-C099-T07 · Success/refusal fixtures:** Capture “Key lifecycle qualification” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M09.01-C099-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Key lifecycle qualification” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M09.01-C099-T09 · Operator review:** Read the “Key lifecycle qualification” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M09.01-C099-T10 · Diagnostic evidence:** Publish redacted “Key lifecycle qualification” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M09.01-C100 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for key lifecycle qualification; label unexecuted checks as untested.

- [ ] **UC-M09.01-C100-T01 · Evidence inventory:** List the “Key lifecycle qualification” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M09.01-C100-T02 · Artifact references:** Record the exact “Key lifecycle qualification” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M09.01-C100-T03 · Fixture references:** Attach the “Key lifecycle qualification” fixture IDs, input identities and oracle definition; preserve the source counterexample “A cryptographically valid revoked signature passes admission” as a distinct evidence case.
- [ ] **UC-M09.01-C100-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Key lifecycle qualification”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M09.01-C100-T05 · Environment record:** Record the actual “Key lifecycle qualification” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M09.01-C100-T06 · Expected versus observed:** Pair every “Key lifecycle qualification” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M09.01-C100-T07 · Failure and limit records:** Attach “Key lifecycle qualification” change/failure and bounds evidence where required; include uncovered “Lifecycle scenarios and verifier runtime” and unresolved violations of “Valid signatures from revoked or wrong-role keys remain refused”.
- [ ] **UC-M09.01-C100-T08 · Evidence hygiene:** Check the “Key lifecycle qualification” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M09.01-C100-T09 · Reproduction review:** Have the “Key lifecycle qualification” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M09.01-C100-T10 · Acceptance linkage:** Link the “Key lifecycle qualification” evidence to its parent and UC-M09.01 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

