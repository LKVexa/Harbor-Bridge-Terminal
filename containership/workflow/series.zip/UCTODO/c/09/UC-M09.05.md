# UC-M09.05 — Proof and digest assurance hierarchy

**To-Do Pack 2.0.0 · Baseline UC-2.2.0 · 100 parent checks × 10 subtasks = 1,000 to-dos**

[Master index](../../INDEX.md) · [Workstream index](../../w/09.md)

| Field | Preserved source value |
|---|---|
| Workstream | 09. Trust, integrity and adversarial security |
| Milestone | C |
| Priority | P0 |
| Source assessment | PARTIAL |
| Scope | core or selected profile |
| Dependencies | [UC-M01.07](../01/UC-M01.07.md), [UC-M04.04](../04/UC-M04.04.md), [UC-M06.05](../06/UC-M06.05.md) |
| Source checklist pack | 1.0.0 |
| Original reference labels | [S4], [S7], [S8]. |

## Original requirement

Label byte integrity, signature authenticity, witness agreement, semantic correctness and isolation evidence separately.

**Original acceptance criterion:** No promotion rule treats a deterministic hash witness as proof of arbitrary program correctness or authority.

**Source trace:** Original checklist `UC100/c/09/UC-M09.05.md` inside [s/checklists.zip](../../s/checklists.zip); exact parent records in [data/parents.jsonl](../../data/parents.jsonl). Original roadmap lines 853–863 are preserved in [s/roadmap.md](../../s/roadmap.md).

## How to use these lists

Every parent statement below is preserved verbatim. Its ten child tasks are proposed decomposition, not implemented capabilities or executed tests. Child IDs append `-T01` through `-T10` to the original parent ID. All begin unchecked / `TODO`. Design/review evidence does not establish runtime enforcement; observe the actual selected target where the parent requires it.

The source dependency graph and selected release profile determine applicability. The numbered child sequence is a local working order, not an added hard dependency graph. An unselected optional feature needs a recorded not-applicable rationale; missing prerequisites for selected work remain blockers. Numerical budgets, backends and trust mechanisms remain decisions unless fixed by the source. Test hostile cases only with synthetic inputs in authorized disposable environments.

## 01. Assurance vocabulary

**Source delivery:** Define separate byte-integrity, authenticity, witness, semantic and isolation verdicts.

**Source invariant:** One assurance class cannot silently substitute for another.

**Source negative case:** A checksum PASS is shown as program correctness PASS.

**Source bounded quantities:** Verdict types and schema fields.

### UC-M09.05-C001 · Contract

**Original checklist item:** Specify the scope and representation of assurance vocabulary; identify its producer, consumer, authority assumptions and explicitly unsupported cases.

- [ ] **UC-M09.05-C001-T01 · Scope statement:** Draft a scope note for “Assurance vocabulary” within Proof and digest assurance hierarchy; separate required model statements, explicit exclusions and unresolved design decisions.
- [ ] **UC-M09.05-C001-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Assurance vocabulary”; record each producer, representation and missing-value meaning.
- [ ] **UC-M09.05-C001-T03 · Output inventory:** List the outputs of “Assurance vocabulary” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M09.05-C001-T04 · Field dictionary:** Create a field-and-term dictionary for “Assurance vocabulary”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M09.05-C001-T05 · Prerequisite contract:** Map “Assurance vocabulary” to the source component prerequisites (UC-M01.07, UC-M04.04, UC-M06.05); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M09.05-C001-T06 · Authority map:** Identify who may produce, change and consume “Assurance vocabulary”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M09.05-C001-T07 · Invariant clause:** Add a normative clause for “Assurance vocabulary” that preserves “One assurance class cannot silently substitute for another”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M09.05-C001-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Assurance vocabulary”; include the source counterexample “A checksum PASS is shown as program correctness PASS” and the intended safe disposition.
- [ ] **UC-M09.05-C001-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Verdict types and schema fields” in the “Assurance vocabulary” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M09.05-C001-T10 · Contract review:** Review the “Assurance vocabulary” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M09.05-C002 · Delivery

**Original checklist item:** Define separate byte-integrity, authenticity, witness, semantic and isolation verdicts.

- [ ] **UC-M09.05-C002-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Assurance vocabulary”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M09.05-C002-T02 · Change plan:** Break the source delivery for “Assurance vocabulary” into concrete edit targets and reviewable outputs; keep the UC-M09.05 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M09.05-C002-T03 · Core artifact:** Create the “Assurance vocabulary” model, schema or inventory that realizes this source instruction: Define separate byte-integrity, authenticity, witness, semantic and isolation verdicts.
- [ ] **UC-M09.05-C002-T04 · Concrete realization:** Populate “Assurance vocabulary” with one concrete worked case; map every required entity or field to its source and flag any unmapped entry.
- [ ] **UC-M09.05-C002-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Assurance vocabulary” needed to preserve “One assurance class cannot silently substitute for another”; record an enforcement gap where only a model exists.
- [ ] **UC-M09.05-C002-T06 · Dependency connection:** Connect the “Assurance vocabulary” specification to independent assurance verdicts and profile-specific release promotion rules; record code coverage separately where the design is not yet enforced.
- [ ] **UC-M09.05-C002-T07 · Resource behavior:** Account for “Verdict types and schema fields” in “Assurance vocabulary”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M09.05-C002-T08 · Delivery check:** Walk the populated “Assurance vocabulary” model through a valid example and the source counterexample “A checksum PASS is shown as program correctness PASS”; record corrections and unresolved enforcement gaps.
- [ ] **UC-M09.05-C002-T09 · Patch review:** Review the “Assurance vocabulary” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M09.05-C002-T10 · Delivery handoff:** Publish the “Assurance vocabulary” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M09.05-C003 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: One assurance class cannot silently substitute for another. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M09.05-C003-T01 · Named property:** Create a stable property/check name under this parent for “Assurance vocabulary”; copy its required invariant exactly: “One assurance class cannot silently substitute for another”.
- [ ] **UC-M09.05-C003-T02 · Observable terms:** Define each term in the “Assurance vocabulary” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M09.05-C003-T03 · Precondition set:** List the preconditions under which “One assurance class cannot silently substitute for another” must hold for “Assurance vocabulary”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M09.05-C003-T04 · Transition coverage:** Map the “Assurance vocabulary” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M09.05-C003-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Assurance vocabulary”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M09.05-C003-T06 · Satisfying fixture:** Create a concrete “Assurance vocabulary” case that satisfies “One assurance class cannot silently substitute for another”; record its expected observation before running the assertion or review.
- [ ] **UC-M09.05-C003-T07 · Violating fixture:** Create the source counterexample “A checksum PASS is shown as program correctness PASS” for “Assurance vocabulary”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M09.05-C003-T08 · Enforcement evidence:** Exercise the “Assurance vocabulary” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M09.05-C003-T09 · Regression linkage:** Link the “Assurance vocabulary” property to changes in independent assurance verdicts and profile-specific release promotion rules; record which dependency or contract changes require rerunning it.
- [ ] **UC-M09.05-C003-T10 · Property disposition:** Compare the satisfying and violating “Assurance vocabulary” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M09.05-C004 · Integration

**Original checklist item:** Integrate assurance vocabulary with independent assurance verdicts and profile-specific release promotion rules; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M09.05-C004-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Assurance vocabulary” across independent assurance verdicts and profile-specific release promotion rules; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M09.05-C004-T02 · Field mapping:** Map every “Assurance vocabulary” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M09.05-C004-T03 · Prerequisite identities:** Record the actual prerequisites for “Assurance vocabulary” (source dependency list: UC-M01.07, UC-M04.04, UC-M06.05); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M09.05-C004-T04 · Ownership agreement:** Specify who owns “Assurance vocabulary” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M09.05-C004-T05 · Handoff implementation:** Connect “Assurance vocabulary” through the mapped seam using the real adapter or explicit specification reference; preserve “One assurance class cannot silently substitute for another” across the handoff.
- [ ] **UC-M09.05-C004-T06 · Absent-input case:** Omit one required “Assurance vocabulary” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M09.05-C004-T07 · Stale-input case:** Supply an outdated “Assurance vocabulary” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M09.05-C004-T08 · Incompatible-input case:** Supply an incompatible “Assurance vocabulary” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M09.05-C004-T09 · Valid integration trace:** Run a valid “Assurance vocabulary” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M09.05-C004-T10 · Seam review:** Reconcile the “Assurance vocabulary” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M09.05-C005 · Valid-case test

**Original checklist item:** Construct a valid worked example for assurance vocabulary; evaluate it against predeclared expected decisions and, where enforcement exists, run the corresponding conformance fixture.

- [ ] **UC-M09.05-C005-T01 · Valid fixture choice:** Select one concrete valid worked example for “Assurance vocabulary”; enumerate the model inputs and the expected review decision before evaluating it.
- [ ] **UC-M09.05-C005-T02 · Expected-result oracle:** Specify the “Assurance vocabulary” expected result independently of the implementation output; include the property “One assurance class cannot silently substitute for another” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M09.05-C005-T03 · Fixture material:** Create the concrete “Assurance vocabulary” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M09.05-C005-T04 · Target preparation:** Prepare the “Assurance vocabulary” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M09.05-C005-T05 · Initial-state record:** Record the initial “Assurance vocabulary” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M09.05-C005-T06 · Valid-path execution:** Evaluate the “Assurance vocabulary” example against the reviewed model; where a runtime mechanism exists, run its corresponding fixture and label those observations separately.
- [ ] **UC-M09.05-C005-T07 · Outcome comparison:** Compare every declared “Assurance vocabulary” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M09.05-C005-T08 · State and bounds check:** Inspect the “Assurance vocabulary” ownership/state effects and actual use of “Verdict types and schema fields”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M09.05-C005-T09 · Repeatability check:** Repeat the same “Assurance vocabulary” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M09.05-C005-T10 · Positive evidence:** Attach the “Assurance vocabulary” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M09.05-C006 · Negative test

**Original checklist item:** Negative case: A checksum PASS is shown as program correctness PASS. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M09.05-C006-T01 · Adverse-case definition:** Create a test record for the exact “Assurance vocabulary” source counterexample: “A checksum PASS is shown as program correctness PASS”; state which precondition or invariant it challenges.
- [ ] **UC-M09.05-C006-T02 · Safe fixture boundary:** Define the contained test boundary for “Assurance vocabulary”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M09.05-C006-T03 · Valid control:** Construct a valid “Assurance vocabulary” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M09.05-C006-T04 · Minimal adverse input:** Derive the “Assurance vocabulary” adverse fixture from the control with the smallest documented change needed to reproduce “A checksum PASS is shown as program correctness PASS”; retain that change as reproducible data.
- [ ] **UC-M09.05-C006-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Assurance vocabulary”; require “One assurance class cannot silently substitute for another” and forbid a false-success verdict.
- [ ] **UC-M09.05-C006-T06 · Adverse execution:** Evaluate the “Assurance vocabulary” adverse case through the actual review/contract gate; where implemented, also observe the runtime refusal and keep the two evidence classes separate.
- [ ] **UC-M09.05-C006-T07 · Effect inspection:** Inspect “Assurance vocabulary” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M09.05-C006-T08 · Refusal versus failure:** Confirm the “Assurance vocabulary” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M09.05-C006-T09 · Reset and retention:** Restore only the disposable “Assurance vocabulary” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M09.05-C006-T10 · Negative regression:** Register the “Assurance vocabulary” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M09.05-C007 · Change / failure test

**Original checklist item:** Exercise assurance vocabulary when one assurance class passes while another required class fails or becomes stale; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M09.05-C007-T01 · Scenario record:** Write the “Assurance vocabulary” change/failure scenario exactly as supplied: one assurance class passes while another required class fails or becomes stale; identify the property that must remain true: “One assurance class cannot silently substitute for another”.
- [ ] **UC-M09.05-C007-T02 · Baseline capture:** Create a known-valid “Assurance vocabulary” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M09.05-C007-T03 · Injection map:** Locate the “Assurance vocabulary” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M09.05-C007-T04 · Disposition oracle:** Define the legal intermediate and final “Assurance vocabulary” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M09.05-C007-T05 · Controlled trigger:** Apply the controlled model-change scenario for “Assurance vocabulary”: one assurance class passes while another required class fails or becomes stale; retain the exact before/after declarations. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M09.05-C007-T06 · Intermediate inspection:** Review which “Assurance vocabulary” claims, approvals and evidence references become stale after the change; keep unresolved enforcement gaps visible.
- [ ] **UC-M09.05-C007-T07 · Recovery path:** Revise or explicitly refuse the changed “Assurance vocabulary” model under the documented compatibility policy; re-review affected claims before restoring their approval.
- [ ] **UC-M09.05-C007-T08 · Stale-evidence cleanup:** Invalidate superseded “Assurance vocabulary” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M09.05-C007-T09 · Repeat and compare:** Repeat the selected “Assurance vocabulary” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M09.05-C007-T10 · Failure evidence:** Publish the “Assurance vocabulary” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M09.05-C008 · Bounds

**Original checklist item:** Define completeness and scaling criteria for verdict types and schema fields; exercise larger inventories or fixture sets, and report uncovered scope instead of silently excluding it.

- [ ] **UC-M09.05-C008-T01 · Quantity inventory:** Create a measurement inventory for “Assurance vocabulary”: “Verdict types and schema fields”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M09.05-C008-T02 · Measurement method:** Choose how to observe each “Assurance vocabulary” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M09.05-C008-T03 · Budget decision:** Select justified coverage and completeness limits for “Assurance vocabulary”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M09.05-C008-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Assurance vocabulary” cases for “Verdict types and schema fields”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M09.05-C008-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Assurance vocabulary” limit; preserve “One assurance class cannot silently substitute for another”.
- [ ] **UC-M09.05-C008-T06 · Normal measurement:** Run or review the normal “Assurance vocabulary” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M09.05-C008-T07 · At-limit measurement:** Exercise the “Assurance vocabulary” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M09.05-C008-T08 · Over-limit measurement:** Exercise the “Assurance vocabulary” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M09.05-C008-T09 · Uncovered-scope report:** List the “Assurance vocabulary” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M09.05-C008-T10 · Limit evidence:** Publish the selected “Assurance vocabulary” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M09.05-C009 · Diagnostics / review

**Original checklist item:** Record the rationale, unresolved assumptions, enforcement gaps and re-review triggers for assurance vocabulary; make design-only claims visibly distinct from observed behavior.

- [ ] **UC-M09.05-C009-T01 · Review inventory:** List the “Assurance vocabulary” decisions and claims requiring review; distinguish source requirements, implementation observations and engineering assumptions.
- [ ] **UC-M09.05-C009-T02 · Rationale record:** Write the rationale for the selected “Assurance vocabulary” representation or policy; link each choice to the requirement rather than an unexplained preference.
- [ ] **UC-M09.05-C009-T03 · Assumption ledger:** Record unresolved “Assurance vocabulary” assumptions, their owner and what observation or decision would resolve them; do not treat unknowns as approvals.
- [ ] **UC-M09.05-C009-T04 · Boundary map:** Map each “Assurance vocabulary” claim to an actual guard or explicit design/review gate; flag gaps against “One assurance class cannot silently substitute for another”.
- [ ] **UC-M09.05-C009-T05 · Counterexample review:** Walk reviewers through the “Assurance vocabulary” counterexample “A checksum PASS is shown as program correctness PASS”; record whether the model detects it and whether any runtime guard was actually exercised.
- [ ] **UC-M09.05-C009-T06 · Review outcome vocabulary:** Define approved, blocked, superseded and untested review outcomes for “Assurance vocabulary”; ensure the wording cannot be read as runtime enforcement evidence.
- [ ] **UC-M09.05-C009-T07 · Re-review triggers:** List “Assurance vocabulary” invalidation triggers, including the source change scenario: one assurance class passes while another required class fails or becomes stale; identify the affected claims and evidence.
- [ ] **UC-M09.05-C009-T08 · Sensitive-data review:** Inspect the “Assurance vocabulary” review record for secrets and unrelated user content; retain nonsecret references sufficient for reproducibility.
- [ ] **UC-M09.05-C009-T09 · Independent reading:** Have the “Assurance vocabulary” record read against the original acceptance criterion and independent assurance verdicts and profile-specific release promotion rules; record misunderstandings or missing evidence as corrections.
- [ ] **UC-M09.05-C009-T10 · Review disposition:** Publish the “Assurance vocabulary” rationale, versioned review outcome, unresolved gaps and explicit next decision; keep blockers open until supported evidence resolves them.

### UC-M09.05-C010 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for assurance vocabulary; label unexecuted checks as untested.

- [ ] **UC-M09.05-C010-T01 · Evidence inventory:** List the “Assurance vocabulary” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M09.05-C010-T02 · Artifact references:** Record the exact “Assurance vocabulary” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M09.05-C010-T03 · Fixture references:** Attach the “Assurance vocabulary” fixture IDs, input identities and oracle definition; preserve the source counterexample “A checksum PASS is shown as program correctness PASS” as a distinct evidence case.
- [ ] **UC-M09.05-C010-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Assurance vocabulary”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M09.05-C010-T05 · Environment record:** Record the actual “Assurance vocabulary” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M09.05-C010-T06 · Expected versus observed:** Pair every “Assurance vocabulary” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M09.05-C010-T07 · Failure and limit records:** Attach “Assurance vocabulary” change/failure and bounds evidence where required; include uncovered “Verdict types and schema fields” and unresolved violations of “One assurance class cannot silently substitute for another”.
- [ ] **UC-M09.05-C010-T08 · Evidence hygiene:** Check the “Assurance vocabulary” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M09.05-C010-T09 · Reproduction review:** Have the “Assurance vocabulary” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M09.05-C010-T10 · Acceptance linkage:** Link the “Assurance vocabulary” evidence to its parent and UC-M09.05 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 02. Byte-integrity semantics

**Source delivery:** Describe digest evidence as a binding to observed bytes.

**Source invariant:** A digest does not establish who authorized those bytes.

**Source negative case:** A self-resealed malicious image is accepted as trusted.

**Source bounded quantities:** Hashed objects and evidence bytes.

### UC-M09.05-C011 · Contract

**Original checklist item:** Specify the scope and representation of byte-integrity semantics; identify its producer, consumer, authority assumptions and explicitly unsupported cases.

- [ ] **UC-M09.05-C011-T01 · Scope statement:** Draft a scope note for “Byte-integrity semantics” within Proof and digest assurance hierarchy; separate required model statements, explicit exclusions and unresolved design decisions.
- [ ] **UC-M09.05-C011-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Byte-integrity semantics”; record each producer, representation and missing-value meaning.
- [ ] **UC-M09.05-C011-T03 · Output inventory:** List the outputs of “Byte-integrity semantics” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M09.05-C011-T04 · Field dictionary:** Create a field-and-term dictionary for “Byte-integrity semantics”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M09.05-C011-T05 · Prerequisite contract:** Map “Byte-integrity semantics” to the source component prerequisites (UC-M01.07, UC-M04.04, UC-M06.05); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M09.05-C011-T06 · Authority map:** Identify who may produce, change and consume “Byte-integrity semantics”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M09.05-C011-T07 · Invariant clause:** Add a normative clause for “Byte-integrity semantics” that preserves “A digest does not establish who authorized those bytes”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M09.05-C011-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Byte-integrity semantics”; include the source counterexample “A self-resealed malicious image is accepted as trusted” and the intended safe disposition.
- [ ] **UC-M09.05-C011-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Hashed objects and evidence bytes” in the “Byte-integrity semantics” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M09.05-C011-T10 · Contract review:** Review the “Byte-integrity semantics” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M09.05-C012 · Delivery

**Original checklist item:** Describe digest evidence as a binding to observed bytes.

- [ ] **UC-M09.05-C012-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Byte-integrity semantics”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M09.05-C012-T02 · Change plan:** Break the source delivery for “Byte-integrity semantics” into concrete edit targets and reviewable outputs; keep the UC-M09.05 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M09.05-C012-T03 · Core artifact:** Create the “Byte-integrity semantics” model, schema or inventory that realizes this source instruction: Describe digest evidence as a binding to observed bytes.
- [ ] **UC-M09.05-C012-T04 · Concrete realization:** Populate “Byte-integrity semantics” with one concrete worked case; map every required entity or field to its source and flag any unmapped entry.
- [ ] **UC-M09.05-C012-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Byte-integrity semantics” needed to preserve “A digest does not establish who authorized those bytes”; record an enforcement gap where only a model exists.
- [ ] **UC-M09.05-C012-T06 · Dependency connection:** Connect the “Byte-integrity semantics” specification to independent assurance verdicts and profile-specific release promotion rules; record code coverage separately where the design is not yet enforced.
- [ ] **UC-M09.05-C012-T07 · Resource behavior:** Account for “Hashed objects and evidence bytes” in “Byte-integrity semantics”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M09.05-C012-T08 · Delivery check:** Walk the populated “Byte-integrity semantics” model through a valid example and the source counterexample “A self-resealed malicious image is accepted as trusted”; record corrections and unresolved enforcement gaps.
- [ ] **UC-M09.05-C012-T09 · Patch review:** Review the “Byte-integrity semantics” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M09.05-C012-T10 · Delivery handoff:** Publish the “Byte-integrity semantics” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M09.05-C013 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: A digest does not establish who authorized those bytes. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M09.05-C013-T01 · Named property:** Create a stable property/check name under this parent for “Byte-integrity semantics”; copy its required invariant exactly: “A digest does not establish who authorized those bytes”.
- [ ] **UC-M09.05-C013-T02 · Observable terms:** Define each term in the “Byte-integrity semantics” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M09.05-C013-T03 · Precondition set:** List the preconditions under which “A digest does not establish who authorized those bytes” must hold for “Byte-integrity semantics”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M09.05-C013-T04 · Transition coverage:** Map the “Byte-integrity semantics” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M09.05-C013-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Byte-integrity semantics”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M09.05-C013-T06 · Satisfying fixture:** Create a concrete “Byte-integrity semantics” case that satisfies “A digest does not establish who authorized those bytes”; record its expected observation before running the assertion or review.
- [ ] **UC-M09.05-C013-T07 · Violating fixture:** Create the source counterexample “A self-resealed malicious image is accepted as trusted” for “Byte-integrity semantics”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M09.05-C013-T08 · Enforcement evidence:** Exercise the “Byte-integrity semantics” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M09.05-C013-T09 · Regression linkage:** Link the “Byte-integrity semantics” property to changes in independent assurance verdicts and profile-specific release promotion rules; record which dependency or contract changes require rerunning it.
- [ ] **UC-M09.05-C013-T10 · Property disposition:** Compare the satisfying and violating “Byte-integrity semantics” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M09.05-C014 · Integration

**Original checklist item:** Integrate byte-integrity semantics with independent assurance verdicts and profile-specific release promotion rules; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M09.05-C014-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Byte-integrity semantics” across independent assurance verdicts and profile-specific release promotion rules; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M09.05-C014-T02 · Field mapping:** Map every “Byte-integrity semantics” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M09.05-C014-T03 · Prerequisite identities:** Record the actual prerequisites for “Byte-integrity semantics” (source dependency list: UC-M01.07, UC-M04.04, UC-M06.05); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M09.05-C014-T04 · Ownership agreement:** Specify who owns “Byte-integrity semantics” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M09.05-C014-T05 · Handoff implementation:** Connect “Byte-integrity semantics” through the mapped seam using the real adapter or explicit specification reference; preserve “A digest does not establish who authorized those bytes” across the handoff.
- [ ] **UC-M09.05-C014-T06 · Absent-input case:** Omit one required “Byte-integrity semantics” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M09.05-C014-T07 · Stale-input case:** Supply an outdated “Byte-integrity semantics” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M09.05-C014-T08 · Incompatible-input case:** Supply an incompatible “Byte-integrity semantics” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M09.05-C014-T09 · Valid integration trace:** Run a valid “Byte-integrity semantics” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M09.05-C014-T10 · Seam review:** Reconcile the “Byte-integrity semantics” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M09.05-C015 · Valid-case test

**Original checklist item:** Construct a valid worked example for byte-integrity semantics; evaluate it against predeclared expected decisions and, where enforcement exists, run the corresponding conformance fixture.

- [ ] **UC-M09.05-C015-T01 · Valid fixture choice:** Select one concrete valid worked example for “Byte-integrity semantics”; enumerate the model inputs and the expected review decision before evaluating it.
- [ ] **UC-M09.05-C015-T02 · Expected-result oracle:** Specify the “Byte-integrity semantics” expected result independently of the implementation output; include the property “A digest does not establish who authorized those bytes” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M09.05-C015-T03 · Fixture material:** Create the concrete “Byte-integrity semantics” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M09.05-C015-T04 · Target preparation:** Prepare the “Byte-integrity semantics” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M09.05-C015-T05 · Initial-state record:** Record the initial “Byte-integrity semantics” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M09.05-C015-T06 · Valid-path execution:** Evaluate the “Byte-integrity semantics” example against the reviewed model; where a runtime mechanism exists, run its corresponding fixture and label those observations separately.
- [ ] **UC-M09.05-C015-T07 · Outcome comparison:** Compare every declared “Byte-integrity semantics” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M09.05-C015-T08 · State and bounds check:** Inspect the “Byte-integrity semantics” ownership/state effects and actual use of “Hashed objects and evidence bytes”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M09.05-C015-T09 · Repeatability check:** Repeat the same “Byte-integrity semantics” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M09.05-C015-T10 · Positive evidence:** Attach the “Byte-integrity semantics” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M09.05-C016 · Negative test

**Original checklist item:** Negative case: A self-resealed malicious image is accepted as trusted. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M09.05-C016-T01 · Adverse-case definition:** Create a test record for the exact “Byte-integrity semantics” source counterexample: “A self-resealed malicious image is accepted as trusted”; state which precondition or invariant it challenges.
- [ ] **UC-M09.05-C016-T02 · Safe fixture boundary:** Define the contained test boundary for “Byte-integrity semantics”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M09.05-C016-T03 · Valid control:** Construct a valid “Byte-integrity semantics” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M09.05-C016-T04 · Minimal adverse input:** Derive the “Byte-integrity semantics” adverse fixture from the control with the smallest documented change needed to reproduce “A self-resealed malicious image is accepted as trusted”; retain that change as reproducible data.
- [ ] **UC-M09.05-C016-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Byte-integrity semantics”; require “A digest does not establish who authorized those bytes” and forbid a false-success verdict.
- [ ] **UC-M09.05-C016-T06 · Adverse execution:** Evaluate the “Byte-integrity semantics” adverse case through the actual review/contract gate; where implemented, also observe the runtime refusal and keep the two evidence classes separate.
- [ ] **UC-M09.05-C016-T07 · Effect inspection:** Inspect “Byte-integrity semantics” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M09.05-C016-T08 · Refusal versus failure:** Confirm the “Byte-integrity semantics” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M09.05-C016-T09 · Reset and retention:** Restore only the disposable “Byte-integrity semantics” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M09.05-C016-T10 · Negative regression:** Register the “Byte-integrity semantics” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M09.05-C017 · Change / failure test

**Original checklist item:** Exercise byte-integrity semantics when one assurance class passes while another required class fails or becomes stale; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M09.05-C017-T01 · Scenario record:** Write the “Byte-integrity semantics” change/failure scenario exactly as supplied: one assurance class passes while another required class fails or becomes stale; identify the property that must remain true: “A digest does not establish who authorized those bytes”.
- [ ] **UC-M09.05-C017-T02 · Baseline capture:** Create a known-valid “Byte-integrity semantics” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M09.05-C017-T03 · Injection map:** Locate the “Byte-integrity semantics” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M09.05-C017-T04 · Disposition oracle:** Define the legal intermediate and final “Byte-integrity semantics” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M09.05-C017-T05 · Controlled trigger:** Apply the controlled model-change scenario for “Byte-integrity semantics”: one assurance class passes while another required class fails or becomes stale; retain the exact before/after declarations. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M09.05-C017-T06 · Intermediate inspection:** Review which “Byte-integrity semantics” claims, approvals and evidence references become stale after the change; keep unresolved enforcement gaps visible.
- [ ] **UC-M09.05-C017-T07 · Recovery path:** Revise or explicitly refuse the changed “Byte-integrity semantics” model under the documented compatibility policy; re-review affected claims before restoring their approval.
- [ ] **UC-M09.05-C017-T08 · Stale-evidence cleanup:** Invalidate superseded “Byte-integrity semantics” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M09.05-C017-T09 · Repeat and compare:** Repeat the selected “Byte-integrity semantics” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M09.05-C017-T10 · Failure evidence:** Publish the “Byte-integrity semantics” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M09.05-C018 · Bounds

**Original checklist item:** Define completeness and scaling criteria for hashed objects and evidence bytes; exercise larger inventories or fixture sets, and report uncovered scope instead of silently excluding it.

- [ ] **UC-M09.05-C018-T01 · Quantity inventory:** Create a measurement inventory for “Byte-integrity semantics”: “Hashed objects and evidence bytes”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M09.05-C018-T02 · Measurement method:** Choose how to observe each “Byte-integrity semantics” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M09.05-C018-T03 · Budget decision:** Select justified coverage and completeness limits for “Byte-integrity semantics”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M09.05-C018-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Byte-integrity semantics” cases for “Hashed objects and evidence bytes”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M09.05-C018-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Byte-integrity semantics” limit; preserve “A digest does not establish who authorized those bytes”.
- [ ] **UC-M09.05-C018-T06 · Normal measurement:** Run or review the normal “Byte-integrity semantics” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M09.05-C018-T07 · At-limit measurement:** Exercise the “Byte-integrity semantics” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M09.05-C018-T08 · Over-limit measurement:** Exercise the “Byte-integrity semantics” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M09.05-C018-T09 · Uncovered-scope report:** List the “Byte-integrity semantics” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M09.05-C018-T10 · Limit evidence:** Publish the selected “Byte-integrity semantics” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M09.05-C019 · Diagnostics / review

**Original checklist item:** Record the rationale, unresolved assumptions, enforcement gaps and re-review triggers for byte-integrity semantics; make design-only claims visibly distinct from observed behavior.

- [ ] **UC-M09.05-C019-T01 · Review inventory:** List the “Byte-integrity semantics” decisions and claims requiring review; distinguish source requirements, implementation observations and engineering assumptions.
- [ ] **UC-M09.05-C019-T02 · Rationale record:** Write the rationale for the selected “Byte-integrity semantics” representation or policy; link each choice to the requirement rather than an unexplained preference.
- [ ] **UC-M09.05-C019-T03 · Assumption ledger:** Record unresolved “Byte-integrity semantics” assumptions, their owner and what observation or decision would resolve them; do not treat unknowns as approvals.
- [ ] **UC-M09.05-C019-T04 · Boundary map:** Map each “Byte-integrity semantics” claim to an actual guard or explicit design/review gate; flag gaps against “A digest does not establish who authorized those bytes”.
- [ ] **UC-M09.05-C019-T05 · Counterexample review:** Walk reviewers through the “Byte-integrity semantics” counterexample “A self-resealed malicious image is accepted as trusted”; record whether the model detects it and whether any runtime guard was actually exercised.
- [ ] **UC-M09.05-C019-T06 · Review outcome vocabulary:** Define approved, blocked, superseded and untested review outcomes for “Byte-integrity semantics”; ensure the wording cannot be read as runtime enforcement evidence.
- [ ] **UC-M09.05-C019-T07 · Re-review triggers:** List “Byte-integrity semantics” invalidation triggers, including the source change scenario: one assurance class passes while another required class fails or becomes stale; identify the affected claims and evidence.
- [ ] **UC-M09.05-C019-T08 · Sensitive-data review:** Inspect the “Byte-integrity semantics” review record for secrets and unrelated user content; retain nonsecret references sufficient for reproducibility.
- [ ] **UC-M09.05-C019-T09 · Independent reading:** Have the “Byte-integrity semantics” record read against the original acceptance criterion and independent assurance verdicts and profile-specific release promotion rules; record misunderstandings or missing evidence as corrections.
- [ ] **UC-M09.05-C019-T10 · Review disposition:** Publish the “Byte-integrity semantics” rationale, versioned review outcome, unresolved gaps and explicit next decision; keep blockers open until supported evidence resolves them.

### UC-M09.05-C020 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for byte-integrity semantics; label unexecuted checks as untested.

- [ ] **UC-M09.05-C020-T01 · Evidence inventory:** List the “Byte-integrity semantics” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M09.05-C020-T02 · Artifact references:** Record the exact “Byte-integrity semantics” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M09.05-C020-T03 · Fixture references:** Attach the “Byte-integrity semantics” fixture IDs, input identities and oracle definition; preserve the source counterexample “A self-resealed malicious image is accepted as trusted” as a distinct evidence case.
- [ ] **UC-M09.05-C020-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Byte-integrity semantics”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M09.05-C020-T05 · Environment record:** Record the actual “Byte-integrity semantics” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M09.05-C020-T06 · Expected versus observed:** Pair every “Byte-integrity semantics” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M09.05-C020-T07 · Failure and limit records:** Attach “Byte-integrity semantics” change/failure and bounds evidence where required; include uncovered “Hashed objects and evidence bytes” and unresolved violations of “A digest does not establish who authorized those bytes”.
- [ ] **UC-M09.05-C020-T08 · Evidence hygiene:** Check the “Byte-integrity semantics” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M09.05-C020-T09 · Reproduction review:** Have the “Byte-integrity semantics” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M09.05-C020-T10 · Acceptance linkage:** Link the “Byte-integrity semantics” evidence to its parent and UC-M09.05 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 03. Signature authenticity semantics

**Source delivery:** State which identity and authority policy a signature verification establishes.

**Source invariant:** A valid signature does not prove semantic correctness.

**Source negative case:** A signed program with wrong output passes the correctness gate.

**Source bounded quantities:** Signer policies and verified subjects.

### UC-M09.05-C021 · Contract

**Original checklist item:** Specify the scope and representation of signature authenticity semantics; identify its producer, consumer, authority assumptions and explicitly unsupported cases.

- [ ] **UC-M09.05-C021-T01 · Scope statement:** Draft a scope note for “Signature authenticity semantics” within Proof and digest assurance hierarchy; separate required model statements, explicit exclusions and unresolved design decisions.
- [ ] **UC-M09.05-C021-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Signature authenticity semantics”; record each producer, representation and missing-value meaning.
- [ ] **UC-M09.05-C021-T03 · Output inventory:** List the outputs of “Signature authenticity semantics” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M09.05-C021-T04 · Field dictionary:** Create a field-and-term dictionary for “Signature authenticity semantics”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M09.05-C021-T05 · Prerequisite contract:** Map “Signature authenticity semantics” to the source component prerequisites (UC-M01.07, UC-M04.04, UC-M06.05); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M09.05-C021-T06 · Authority map:** Identify who may produce, change and consume “Signature authenticity semantics”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M09.05-C021-T07 · Invariant clause:** Add a normative clause for “Signature authenticity semantics” that preserves “A valid signature does not prove semantic correctness”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M09.05-C021-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Signature authenticity semantics”; include the source counterexample “A signed program with wrong output passes the correctness gate” and the intended safe disposition.
- [ ] **UC-M09.05-C021-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Signer policies and verified subjects” in the “Signature authenticity semantics” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M09.05-C021-T10 · Contract review:** Review the “Signature authenticity semantics” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M09.05-C022 · Delivery

**Original checklist item:** State which identity and authority policy a signature verification establishes.

- [ ] **UC-M09.05-C022-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Signature authenticity semantics”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M09.05-C022-T02 · Change plan:** Break the source delivery for “Signature authenticity semantics” into concrete edit targets and reviewable outputs; keep the UC-M09.05 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M09.05-C022-T03 · Core artifact:** Create the “Signature authenticity semantics” model, schema or inventory that realizes this source instruction: State which identity and authority policy a signature verification establishes.
- [ ] **UC-M09.05-C022-T04 · Concrete realization:** Populate “Signature authenticity semantics” with one concrete worked case; map every required entity or field to its source and flag any unmapped entry.
- [ ] **UC-M09.05-C022-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Signature authenticity semantics” needed to preserve “A valid signature does not prove semantic correctness”; record an enforcement gap where only a model exists.
- [ ] **UC-M09.05-C022-T06 · Dependency connection:** Connect the “Signature authenticity semantics” specification to independent assurance verdicts and profile-specific release promotion rules; record code coverage separately where the design is not yet enforced.
- [ ] **UC-M09.05-C022-T07 · Resource behavior:** Account for “Signer policies and verified subjects” in “Signature authenticity semantics”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M09.05-C022-T08 · Delivery check:** Walk the populated “Signature authenticity semantics” model through a valid example and the source counterexample “A signed program with wrong output passes the correctness gate”; record corrections and unresolved enforcement gaps.
- [ ] **UC-M09.05-C022-T09 · Patch review:** Review the “Signature authenticity semantics” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M09.05-C022-T10 · Delivery handoff:** Publish the “Signature authenticity semantics” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M09.05-C023 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: A valid signature does not prove semantic correctness. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M09.05-C023-T01 · Named property:** Create a stable property/check name under this parent for “Signature authenticity semantics”; copy its required invariant exactly: “A valid signature does not prove semantic correctness”.
- [ ] **UC-M09.05-C023-T02 · Observable terms:** Define each term in the “Signature authenticity semantics” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M09.05-C023-T03 · Precondition set:** List the preconditions under which “A valid signature does not prove semantic correctness” must hold for “Signature authenticity semantics”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M09.05-C023-T04 · Transition coverage:** Map the “Signature authenticity semantics” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M09.05-C023-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Signature authenticity semantics”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M09.05-C023-T06 · Satisfying fixture:** Create a concrete “Signature authenticity semantics” case that satisfies “A valid signature does not prove semantic correctness”; record its expected observation before running the assertion or review.
- [ ] **UC-M09.05-C023-T07 · Violating fixture:** Create the source counterexample “A signed program with wrong output passes the correctness gate” for “Signature authenticity semantics”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M09.05-C023-T08 · Enforcement evidence:** Exercise the “Signature authenticity semantics” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M09.05-C023-T09 · Regression linkage:** Link the “Signature authenticity semantics” property to changes in independent assurance verdicts and profile-specific release promotion rules; record which dependency or contract changes require rerunning it.
- [ ] **UC-M09.05-C023-T10 · Property disposition:** Compare the satisfying and violating “Signature authenticity semantics” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M09.05-C024 · Integration

**Original checklist item:** Integrate signature authenticity semantics with independent assurance verdicts and profile-specific release promotion rules; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M09.05-C024-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Signature authenticity semantics” across independent assurance verdicts and profile-specific release promotion rules; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M09.05-C024-T02 · Field mapping:** Map every “Signature authenticity semantics” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M09.05-C024-T03 · Prerequisite identities:** Record the actual prerequisites for “Signature authenticity semantics” (source dependency list: UC-M01.07, UC-M04.04, UC-M06.05); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M09.05-C024-T04 · Ownership agreement:** Specify who owns “Signature authenticity semantics” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M09.05-C024-T05 · Handoff implementation:** Connect “Signature authenticity semantics” through the mapped seam using the real adapter or explicit specification reference; preserve “A valid signature does not prove semantic correctness” across the handoff.
- [ ] **UC-M09.05-C024-T06 · Absent-input case:** Omit one required “Signature authenticity semantics” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M09.05-C024-T07 · Stale-input case:** Supply an outdated “Signature authenticity semantics” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M09.05-C024-T08 · Incompatible-input case:** Supply an incompatible “Signature authenticity semantics” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M09.05-C024-T09 · Valid integration trace:** Run a valid “Signature authenticity semantics” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M09.05-C024-T10 · Seam review:** Reconcile the “Signature authenticity semantics” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M09.05-C025 · Valid-case test

**Original checklist item:** Construct a valid worked example for signature authenticity semantics; evaluate it against predeclared expected decisions and, where enforcement exists, run the corresponding conformance fixture.

- [ ] **UC-M09.05-C025-T01 · Valid fixture choice:** Select one concrete valid worked example for “Signature authenticity semantics”; enumerate the model inputs and the expected review decision before evaluating it.
- [ ] **UC-M09.05-C025-T02 · Expected-result oracle:** Specify the “Signature authenticity semantics” expected result independently of the implementation output; include the property “A valid signature does not prove semantic correctness” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M09.05-C025-T03 · Fixture material:** Create the concrete “Signature authenticity semantics” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M09.05-C025-T04 · Target preparation:** Prepare the “Signature authenticity semantics” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M09.05-C025-T05 · Initial-state record:** Record the initial “Signature authenticity semantics” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M09.05-C025-T06 · Valid-path execution:** Evaluate the “Signature authenticity semantics” example against the reviewed model; where a runtime mechanism exists, run its corresponding fixture and label those observations separately.
- [ ] **UC-M09.05-C025-T07 · Outcome comparison:** Compare every declared “Signature authenticity semantics” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M09.05-C025-T08 · State and bounds check:** Inspect the “Signature authenticity semantics” ownership/state effects and actual use of “Signer policies and verified subjects”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M09.05-C025-T09 · Repeatability check:** Repeat the same “Signature authenticity semantics” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M09.05-C025-T10 · Positive evidence:** Attach the “Signature authenticity semantics” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M09.05-C026 · Negative test

**Original checklist item:** Negative case: A signed program with wrong output passes the correctness gate. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M09.05-C026-T01 · Adverse-case definition:** Create a test record for the exact “Signature authenticity semantics” source counterexample: “A signed program with wrong output passes the correctness gate”; state which precondition or invariant it challenges.
- [ ] **UC-M09.05-C026-T02 · Safe fixture boundary:** Define the contained test boundary for “Signature authenticity semantics”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M09.05-C026-T03 · Valid control:** Construct a valid “Signature authenticity semantics” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M09.05-C026-T04 · Minimal adverse input:** Derive the “Signature authenticity semantics” adverse fixture from the control with the smallest documented change needed to reproduce “A signed program with wrong output passes the correctness gate”; retain that change as reproducible data.
- [ ] **UC-M09.05-C026-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Signature authenticity semantics”; require “A valid signature does not prove semantic correctness” and forbid a false-success verdict.
- [ ] **UC-M09.05-C026-T06 · Adverse execution:** Evaluate the “Signature authenticity semantics” adverse case through the actual review/contract gate; where implemented, also observe the runtime refusal and keep the two evidence classes separate.
- [ ] **UC-M09.05-C026-T07 · Effect inspection:** Inspect “Signature authenticity semantics” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M09.05-C026-T08 · Refusal versus failure:** Confirm the “Signature authenticity semantics” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M09.05-C026-T09 · Reset and retention:** Restore only the disposable “Signature authenticity semantics” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M09.05-C026-T10 · Negative regression:** Register the “Signature authenticity semantics” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M09.05-C027 · Change / failure test

**Original checklist item:** Exercise signature authenticity semantics when one assurance class passes while another required class fails or becomes stale; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M09.05-C027-T01 · Scenario record:** Write the “Signature authenticity semantics” change/failure scenario exactly as supplied: one assurance class passes while another required class fails or becomes stale; identify the property that must remain true: “A valid signature does not prove semantic correctness”.
- [ ] **UC-M09.05-C027-T02 · Baseline capture:** Create a known-valid “Signature authenticity semantics” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M09.05-C027-T03 · Injection map:** Locate the “Signature authenticity semantics” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M09.05-C027-T04 · Disposition oracle:** Define the legal intermediate and final “Signature authenticity semantics” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M09.05-C027-T05 · Controlled trigger:** Apply the controlled model-change scenario for “Signature authenticity semantics”: one assurance class passes while another required class fails or becomes stale; retain the exact before/after declarations. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M09.05-C027-T06 · Intermediate inspection:** Review which “Signature authenticity semantics” claims, approvals and evidence references become stale after the change; keep unresolved enforcement gaps visible.
- [ ] **UC-M09.05-C027-T07 · Recovery path:** Revise or explicitly refuse the changed “Signature authenticity semantics” model under the documented compatibility policy; re-review affected claims before restoring their approval.
- [ ] **UC-M09.05-C027-T08 · Stale-evidence cleanup:** Invalidate superseded “Signature authenticity semantics” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M09.05-C027-T09 · Repeat and compare:** Repeat the selected “Signature authenticity semantics” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M09.05-C027-T10 · Failure evidence:** Publish the “Signature authenticity semantics” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M09.05-C028 · Bounds

**Original checklist item:** Define completeness and scaling criteria for signer policies and verified subjects; exercise larger inventories or fixture sets, and report uncovered scope instead of silently excluding it.

- [ ] **UC-M09.05-C028-T01 · Quantity inventory:** Create a measurement inventory for “Signature authenticity semantics”: “Signer policies and verified subjects”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M09.05-C028-T02 · Measurement method:** Choose how to observe each “Signature authenticity semantics” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M09.05-C028-T03 · Budget decision:** Select justified coverage and completeness limits for “Signature authenticity semantics”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M09.05-C028-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Signature authenticity semantics” cases for “Signer policies and verified subjects”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M09.05-C028-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Signature authenticity semantics” limit; preserve “A valid signature does not prove semantic correctness”.
- [ ] **UC-M09.05-C028-T06 · Normal measurement:** Run or review the normal “Signature authenticity semantics” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M09.05-C028-T07 · At-limit measurement:** Exercise the “Signature authenticity semantics” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M09.05-C028-T08 · Over-limit measurement:** Exercise the “Signature authenticity semantics” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M09.05-C028-T09 · Uncovered-scope report:** List the “Signature authenticity semantics” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M09.05-C028-T10 · Limit evidence:** Publish the selected “Signature authenticity semantics” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M09.05-C029 · Diagnostics / review

**Original checklist item:** Record the rationale, unresolved assumptions, enforcement gaps and re-review triggers for signature authenticity semantics; make design-only claims visibly distinct from observed behavior.

- [ ] **UC-M09.05-C029-T01 · Review inventory:** List the “Signature authenticity semantics” decisions and claims requiring review; distinguish source requirements, implementation observations and engineering assumptions.
- [ ] **UC-M09.05-C029-T02 · Rationale record:** Write the rationale for the selected “Signature authenticity semantics” representation or policy; link each choice to the requirement rather than an unexplained preference.
- [ ] **UC-M09.05-C029-T03 · Assumption ledger:** Record unresolved “Signature authenticity semantics” assumptions, their owner and what observation or decision would resolve them; do not treat unknowns as approvals.
- [ ] **UC-M09.05-C029-T04 · Boundary map:** Map each “Signature authenticity semantics” claim to an actual guard or explicit design/review gate; flag gaps against “A valid signature does not prove semantic correctness”.
- [ ] **UC-M09.05-C029-T05 · Counterexample review:** Walk reviewers through the “Signature authenticity semantics” counterexample “A signed program with wrong output passes the correctness gate”; record whether the model detects it and whether any runtime guard was actually exercised.
- [ ] **UC-M09.05-C029-T06 · Review outcome vocabulary:** Define approved, blocked, superseded and untested review outcomes for “Signature authenticity semantics”; ensure the wording cannot be read as runtime enforcement evidence.
- [ ] **UC-M09.05-C029-T07 · Re-review triggers:** List “Signature authenticity semantics” invalidation triggers, including the source change scenario: one assurance class passes while another required class fails or becomes stale; identify the affected claims and evidence.
- [ ] **UC-M09.05-C029-T08 · Sensitive-data review:** Inspect the “Signature authenticity semantics” review record for secrets and unrelated user content; retain nonsecret references sufficient for reproducibility.
- [ ] **UC-M09.05-C029-T09 · Independent reading:** Have the “Signature authenticity semantics” record read against the original acceptance criterion and independent assurance verdicts and profile-specific release promotion rules; record misunderstandings or missing evidence as corrections.
- [ ] **UC-M09.05-C029-T10 · Review disposition:** Publish the “Signature authenticity semantics” rationale, versioned review outcome, unresolved gaps and explicit next decision; keep blockers open until supported evidence resolves them.

### UC-M09.05-C030 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for signature authenticity semantics; label unexecuted checks as untested.

- [ ] **UC-M09.05-C030-T01 · Evidence inventory:** List the “Signature authenticity semantics” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M09.05-C030-T02 · Artifact references:** Record the exact “Signature authenticity semantics” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M09.05-C030-T03 · Fixture references:** Attach the “Signature authenticity semantics” fixture IDs, input identities and oracle definition; preserve the source counterexample “A signed program with wrong output passes the correctness gate” as a distinct evidence case.
- [ ] **UC-M09.05-C030-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Signature authenticity semantics”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M09.05-C030-T05 · Environment record:** Record the actual “Signature authenticity semantics” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M09.05-C030-T06 · Expected versus observed:** Pair every “Signature authenticity semantics” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M09.05-C030-T07 · Failure and limit records:** Attach “Signature authenticity semantics” change/failure and bounds evidence where required; include uncovered “Signer policies and verified subjects” and unresolved violations of “A valid signature does not prove semantic correctness”.
- [ ] **UC-M09.05-C030-T08 · Evidence hygiene:** Check the “Signature authenticity semantics” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M09.05-C030-T09 · Reproduction review:** Have the “Signature authenticity semantics” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M09.05-C030-T10 · Acceptance linkage:** Link the “Signature authenticity semantics” evidence to its parent and UC-M09.05 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 04. Witness semantics

**Source delivery:** Specify the exact inputs and deterministic relation checked by a witness.

**Source invariant:** A witness proves no broader relation than its defined contract.

**Source negative case:** A row-sequence hash is claimed to prove arbitrary program behavior.

**Source bounded quantities:** Witness inputs and relation complexity.

### UC-M09.05-C031 · Contract

**Original checklist item:** Specify the scope and representation of witness semantics; identify its producer, consumer, authority assumptions and explicitly unsupported cases.

- [ ] **UC-M09.05-C031-T01 · Scope statement:** Draft a scope note for “Witness semantics” within Proof and digest assurance hierarchy; separate required model statements, explicit exclusions and unresolved design decisions.
- [ ] **UC-M09.05-C031-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Witness semantics”; record each producer, representation and missing-value meaning.
- [ ] **UC-M09.05-C031-T03 · Output inventory:** List the outputs of “Witness semantics” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M09.05-C031-T04 · Field dictionary:** Create a field-and-term dictionary for “Witness semantics”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M09.05-C031-T05 · Prerequisite contract:** Map “Witness semantics” to the source component prerequisites (UC-M01.07, UC-M04.04, UC-M06.05); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M09.05-C031-T06 · Authority map:** Identify who may produce, change and consume “Witness semantics”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M09.05-C031-T07 · Invariant clause:** Add a normative clause for “Witness semantics” that preserves “A witness proves no broader relation than its defined contract”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M09.05-C031-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Witness semantics”; include the source counterexample “A row-sequence hash is claimed to prove arbitrary program behavior” and the intended safe disposition.
- [ ] **UC-M09.05-C031-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Witness inputs and relation complexity” in the “Witness semantics” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M09.05-C031-T10 · Contract review:** Review the “Witness semantics” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M09.05-C032 · Delivery

**Original checklist item:** Specify the exact inputs and deterministic relation checked by a witness.

- [ ] **UC-M09.05-C032-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Witness semantics”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M09.05-C032-T02 · Change plan:** Break the source delivery for “Witness semantics” into concrete edit targets and reviewable outputs; keep the UC-M09.05 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M09.05-C032-T03 · Core artifact:** Create the “Witness semantics” model, schema or inventory that realizes this source instruction: Specify the exact inputs and deterministic relation checked by a witness.
- [ ] **UC-M09.05-C032-T04 · Concrete realization:** Populate “Witness semantics” with one concrete worked case; map every required entity or field to its source and flag any unmapped entry.
- [ ] **UC-M09.05-C032-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Witness semantics” needed to preserve “A witness proves no broader relation than its defined contract”; record an enforcement gap where only a model exists.
- [ ] **UC-M09.05-C032-T06 · Dependency connection:** Connect the “Witness semantics” specification to independent assurance verdicts and profile-specific release promotion rules; record code coverage separately where the design is not yet enforced.
- [ ] **UC-M09.05-C032-T07 · Resource behavior:** Account for “Witness inputs and relation complexity” in “Witness semantics”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M09.05-C032-T08 · Delivery check:** Walk the populated “Witness semantics” model through a valid example and the source counterexample “A row-sequence hash is claimed to prove arbitrary program behavior”; record corrections and unresolved enforcement gaps.
- [ ] **UC-M09.05-C032-T09 · Patch review:** Review the “Witness semantics” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M09.05-C032-T10 · Delivery handoff:** Publish the “Witness semantics” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M09.05-C033 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: A witness proves no broader relation than its defined contract. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M09.05-C033-T01 · Named property:** Create a stable property/check name under this parent for “Witness semantics”; copy its required invariant exactly: “A witness proves no broader relation than its defined contract”.
- [ ] **UC-M09.05-C033-T02 · Observable terms:** Define each term in the “Witness semantics” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M09.05-C033-T03 · Precondition set:** List the preconditions under which “A witness proves no broader relation than its defined contract” must hold for “Witness semantics”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M09.05-C033-T04 · Transition coverage:** Map the “Witness semantics” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M09.05-C033-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Witness semantics”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M09.05-C033-T06 · Satisfying fixture:** Create a concrete “Witness semantics” case that satisfies “A witness proves no broader relation than its defined contract”; record its expected observation before running the assertion or review.
- [ ] **UC-M09.05-C033-T07 · Violating fixture:** Create the source counterexample “A row-sequence hash is claimed to prove arbitrary program behavior” for “Witness semantics”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M09.05-C033-T08 · Enforcement evidence:** Exercise the “Witness semantics” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M09.05-C033-T09 · Regression linkage:** Link the “Witness semantics” property to changes in independent assurance verdicts and profile-specific release promotion rules; record which dependency or contract changes require rerunning it.
- [ ] **UC-M09.05-C033-T10 · Property disposition:** Compare the satisfying and violating “Witness semantics” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M09.05-C034 · Integration

**Original checklist item:** Integrate witness semantics with independent assurance verdicts and profile-specific release promotion rules; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M09.05-C034-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Witness semantics” across independent assurance verdicts and profile-specific release promotion rules; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M09.05-C034-T02 · Field mapping:** Map every “Witness semantics” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M09.05-C034-T03 · Prerequisite identities:** Record the actual prerequisites for “Witness semantics” (source dependency list: UC-M01.07, UC-M04.04, UC-M06.05); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M09.05-C034-T04 · Ownership agreement:** Specify who owns “Witness semantics” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M09.05-C034-T05 · Handoff implementation:** Connect “Witness semantics” through the mapped seam using the real adapter or explicit specification reference; preserve “A witness proves no broader relation than its defined contract” across the handoff.
- [ ] **UC-M09.05-C034-T06 · Absent-input case:** Omit one required “Witness semantics” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M09.05-C034-T07 · Stale-input case:** Supply an outdated “Witness semantics” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M09.05-C034-T08 · Incompatible-input case:** Supply an incompatible “Witness semantics” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M09.05-C034-T09 · Valid integration trace:** Run a valid “Witness semantics” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M09.05-C034-T10 · Seam review:** Reconcile the “Witness semantics” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M09.05-C035 · Valid-case test

**Original checklist item:** Construct a valid worked example for witness semantics; evaluate it against predeclared expected decisions and, where enforcement exists, run the corresponding conformance fixture.

- [ ] **UC-M09.05-C035-T01 · Valid fixture choice:** Select one concrete valid worked example for “Witness semantics”; enumerate the model inputs and the expected review decision before evaluating it.
- [ ] **UC-M09.05-C035-T02 · Expected-result oracle:** Specify the “Witness semantics” expected result independently of the implementation output; include the property “A witness proves no broader relation than its defined contract” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M09.05-C035-T03 · Fixture material:** Create the concrete “Witness semantics” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M09.05-C035-T04 · Target preparation:** Prepare the “Witness semantics” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M09.05-C035-T05 · Initial-state record:** Record the initial “Witness semantics” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M09.05-C035-T06 · Valid-path execution:** Evaluate the “Witness semantics” example against the reviewed model; where a runtime mechanism exists, run its corresponding fixture and label those observations separately.
- [ ] **UC-M09.05-C035-T07 · Outcome comparison:** Compare every declared “Witness semantics” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M09.05-C035-T08 · State and bounds check:** Inspect the “Witness semantics” ownership/state effects and actual use of “Witness inputs and relation complexity”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M09.05-C035-T09 · Repeatability check:** Repeat the same “Witness semantics” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M09.05-C035-T10 · Positive evidence:** Attach the “Witness semantics” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M09.05-C036 · Negative test

**Original checklist item:** Negative case: A row-sequence hash is claimed to prove arbitrary program behavior. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M09.05-C036-T01 · Adverse-case definition:** Create a test record for the exact “Witness semantics” source counterexample: “A row-sequence hash is claimed to prove arbitrary program behavior”; state which precondition or invariant it challenges.
- [ ] **UC-M09.05-C036-T02 · Safe fixture boundary:** Define the contained test boundary for “Witness semantics”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M09.05-C036-T03 · Valid control:** Construct a valid “Witness semantics” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M09.05-C036-T04 · Minimal adverse input:** Derive the “Witness semantics” adverse fixture from the control with the smallest documented change needed to reproduce “A row-sequence hash is claimed to prove arbitrary program behavior”; retain that change as reproducible data.
- [ ] **UC-M09.05-C036-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Witness semantics”; require “A witness proves no broader relation than its defined contract” and forbid a false-success verdict.
- [ ] **UC-M09.05-C036-T06 · Adverse execution:** Evaluate the “Witness semantics” adverse case through the actual review/contract gate; where implemented, also observe the runtime refusal and keep the two evidence classes separate.
- [ ] **UC-M09.05-C036-T07 · Effect inspection:** Inspect “Witness semantics” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M09.05-C036-T08 · Refusal versus failure:** Confirm the “Witness semantics” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M09.05-C036-T09 · Reset and retention:** Restore only the disposable “Witness semantics” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M09.05-C036-T10 · Negative regression:** Register the “Witness semantics” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M09.05-C037 · Change / failure test

**Original checklist item:** Exercise witness semantics when one assurance class passes while another required class fails or becomes stale; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M09.05-C037-T01 · Scenario record:** Write the “Witness semantics” change/failure scenario exactly as supplied: one assurance class passes while another required class fails or becomes stale; identify the property that must remain true: “A witness proves no broader relation than its defined contract”.
- [ ] **UC-M09.05-C037-T02 · Baseline capture:** Create a known-valid “Witness semantics” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M09.05-C037-T03 · Injection map:** Locate the “Witness semantics” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M09.05-C037-T04 · Disposition oracle:** Define the legal intermediate and final “Witness semantics” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M09.05-C037-T05 · Controlled trigger:** Apply the controlled model-change scenario for “Witness semantics”: one assurance class passes while another required class fails or becomes stale; retain the exact before/after declarations. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M09.05-C037-T06 · Intermediate inspection:** Review which “Witness semantics” claims, approvals and evidence references become stale after the change; keep unresolved enforcement gaps visible.
- [ ] **UC-M09.05-C037-T07 · Recovery path:** Revise or explicitly refuse the changed “Witness semantics” model under the documented compatibility policy; re-review affected claims before restoring their approval.
- [ ] **UC-M09.05-C037-T08 · Stale-evidence cleanup:** Invalidate superseded “Witness semantics” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M09.05-C037-T09 · Repeat and compare:** Repeat the selected “Witness semantics” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M09.05-C037-T10 · Failure evidence:** Publish the “Witness semantics” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M09.05-C038 · Bounds

**Original checklist item:** Define completeness and scaling criteria for witness inputs and relation complexity; exercise larger inventories or fixture sets, and report uncovered scope instead of silently excluding it.

- [ ] **UC-M09.05-C038-T01 · Quantity inventory:** Create a measurement inventory for “Witness semantics”: “Witness inputs and relation complexity”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M09.05-C038-T02 · Measurement method:** Choose how to observe each “Witness semantics” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M09.05-C038-T03 · Budget decision:** Select justified coverage and completeness limits for “Witness semantics”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M09.05-C038-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Witness semantics” cases for “Witness inputs and relation complexity”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M09.05-C038-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Witness semantics” limit; preserve “A witness proves no broader relation than its defined contract”.
- [ ] **UC-M09.05-C038-T06 · Normal measurement:** Run or review the normal “Witness semantics” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M09.05-C038-T07 · At-limit measurement:** Exercise the “Witness semantics” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M09.05-C038-T08 · Over-limit measurement:** Exercise the “Witness semantics” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M09.05-C038-T09 · Uncovered-scope report:** List the “Witness semantics” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M09.05-C038-T10 · Limit evidence:** Publish the selected “Witness semantics” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M09.05-C039 · Diagnostics / review

**Original checklist item:** Record the rationale, unresolved assumptions, enforcement gaps and re-review triggers for witness semantics; make design-only claims visibly distinct from observed behavior.

- [ ] **UC-M09.05-C039-T01 · Review inventory:** List the “Witness semantics” decisions and claims requiring review; distinguish source requirements, implementation observations and engineering assumptions.
- [ ] **UC-M09.05-C039-T02 · Rationale record:** Write the rationale for the selected “Witness semantics” representation or policy; link each choice to the requirement rather than an unexplained preference.
- [ ] **UC-M09.05-C039-T03 · Assumption ledger:** Record unresolved “Witness semantics” assumptions, their owner and what observation or decision would resolve them; do not treat unknowns as approvals.
- [ ] **UC-M09.05-C039-T04 · Boundary map:** Map each “Witness semantics” claim to an actual guard or explicit design/review gate; flag gaps against “A witness proves no broader relation than its defined contract”.
- [ ] **UC-M09.05-C039-T05 · Counterexample review:** Walk reviewers through the “Witness semantics” counterexample “A row-sequence hash is claimed to prove arbitrary program behavior”; record whether the model detects it and whether any runtime guard was actually exercised.
- [ ] **UC-M09.05-C039-T06 · Review outcome vocabulary:** Define approved, blocked, superseded and untested review outcomes for “Witness semantics”; ensure the wording cannot be read as runtime enforcement evidence.
- [ ] **UC-M09.05-C039-T07 · Re-review triggers:** List “Witness semantics” invalidation triggers, including the source change scenario: one assurance class passes while another required class fails or becomes stale; identify the affected claims and evidence.
- [ ] **UC-M09.05-C039-T08 · Sensitive-data review:** Inspect the “Witness semantics” review record for secrets and unrelated user content; retain nonsecret references sufficient for reproducibility.
- [ ] **UC-M09.05-C039-T09 · Independent reading:** Have the “Witness semantics” record read against the original acceptance criterion and independent assurance verdicts and profile-specific release promotion rules; record misunderstandings or missing evidence as corrections.
- [ ] **UC-M09.05-C039-T10 · Review disposition:** Publish the “Witness semantics” rationale, versioned review outcome, unresolved gaps and explicit next decision; keep blockers open until supported evidence resolves them.

### UC-M09.05-C040 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for witness semantics; label unexecuted checks as untested.

- [ ] **UC-M09.05-C040-T01 · Evidence inventory:** List the “Witness semantics” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M09.05-C040-T02 · Artifact references:** Record the exact “Witness semantics” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M09.05-C040-T03 · Fixture references:** Attach the “Witness semantics” fixture IDs, input identities and oracle definition; preserve the source counterexample “A row-sequence hash is claimed to prove arbitrary program behavior” as a distinct evidence case.
- [ ] **UC-M09.05-C040-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Witness semantics”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M09.05-C040-T05 · Environment record:** Record the actual “Witness semantics” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M09.05-C040-T06 · Expected versus observed:** Pair every “Witness semantics” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M09.05-C040-T07 · Failure and limit records:** Attach “Witness semantics” change/failure and bounds evidence where required; include uncovered “Witness inputs and relation complexity” and unresolved violations of “A witness proves no broader relation than its defined contract”.
- [ ] **UC-M09.05-C040-T08 · Evidence hygiene:** Check the “Witness semantics” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M09.05-C040-T09 · Reproduction review:** Have the “Witness semantics” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M09.05-C040-T10 · Acceptance linkage:** Link the “Witness semantics” evidence to its parent and UC-M09.05 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 05. Semantic correctness verdict

**Source delivery:** Bind semantic results to application, input domain, target and oracle.

**Source invariant:** Correctness claims stay within the exercised semantics and supported scope.

**Source negative case:** A small fixture suite is described as proof for every possible program.

**Source bounded quantities:** Input domain and test coverage scope.

### UC-M09.05-C041 · Contract

**Original checklist item:** Specify the scope and representation of semantic correctness verdict; identify its producer, consumer, authority assumptions and explicitly unsupported cases.

- [ ] **UC-M09.05-C041-T01 · Scope statement:** Draft a scope note for “Semantic correctness verdict” within Proof and digest assurance hierarchy; separate required model statements, explicit exclusions and unresolved design decisions.
- [ ] **UC-M09.05-C041-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Semantic correctness verdict”; record each producer, representation and missing-value meaning.
- [ ] **UC-M09.05-C041-T03 · Output inventory:** List the outputs of “Semantic correctness verdict” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M09.05-C041-T04 · Field dictionary:** Create a field-and-term dictionary for “Semantic correctness verdict”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M09.05-C041-T05 · Prerequisite contract:** Map “Semantic correctness verdict” to the source component prerequisites (UC-M01.07, UC-M04.04, UC-M06.05); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M09.05-C041-T06 · Authority map:** Identify who may produce, change and consume “Semantic correctness verdict”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M09.05-C041-T07 · Invariant clause:** Add a normative clause for “Semantic correctness verdict” that preserves “Correctness claims stay within the exercised semantics and supported scope”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M09.05-C041-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Semantic correctness verdict”; include the source counterexample “A small fixture suite is described as proof for every possible program” and the intended safe disposition.
- [ ] **UC-M09.05-C041-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Input domain and test coverage scope” in the “Semantic correctness verdict” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M09.05-C041-T10 · Contract review:** Review the “Semantic correctness verdict” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M09.05-C042 · Delivery

**Original checklist item:** Bind semantic results to application, input domain, target and oracle.

- [ ] **UC-M09.05-C042-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Semantic correctness verdict”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M09.05-C042-T02 · Change plan:** Break the source delivery for “Semantic correctness verdict” into concrete edit targets and reviewable outputs; keep the UC-M09.05 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M09.05-C042-T03 · Core artifact:** Implement the smallest selected-profile change for “Semantic correctness verdict” that realizes this source instruction: Bind semantic results to application, input domain, target and oracle.
- [ ] **UC-M09.05-C042-T04 · Concrete realization:** Trace “Semantic correctness verdict” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M09.05-C042-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Semantic correctness verdict” needed to preserve “Correctness claims stay within the exercised semantics and supported scope”; record an enforcement gap where only a model exists.
- [ ] **UC-M09.05-C042-T06 · Dependency connection:** Connect the “Semantic correctness verdict” specification to independent assurance verdicts and profile-specific release promotion rules; record code coverage separately where the design is not yet enforced.
- [ ] **UC-M09.05-C042-T07 · Resource behavior:** Account for “Input domain and test coverage scope” in “Semantic correctness verdict”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M09.05-C042-T08 · Delivery check:** Walk the populated “Semantic correctness verdict” model through a valid example and the source counterexample “A small fixture suite is described as proof for every possible program”; record corrections and unresolved enforcement gaps.
- [ ] **UC-M09.05-C042-T09 · Patch review:** Review the “Semantic correctness verdict” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M09.05-C042-T10 · Delivery handoff:** Publish the “Semantic correctness verdict” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M09.05-C043 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Correctness claims stay within the exercised semantics and supported scope. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M09.05-C043-T01 · Named property:** Create a stable property/check name under this parent for “Semantic correctness verdict”; copy its required invariant exactly: “Correctness claims stay within the exercised semantics and supported scope”.
- [ ] **UC-M09.05-C043-T02 · Observable terms:** Define each term in the “Semantic correctness verdict” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M09.05-C043-T03 · Precondition set:** List the preconditions under which “Correctness claims stay within the exercised semantics and supported scope” must hold for “Semantic correctness verdict”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M09.05-C043-T04 · Transition coverage:** Map the “Semantic correctness verdict” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M09.05-C043-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Semantic correctness verdict”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M09.05-C043-T06 · Satisfying fixture:** Create a concrete “Semantic correctness verdict” case that satisfies “Correctness claims stay within the exercised semantics and supported scope”; record its expected observation before running the assertion or review.
- [ ] **UC-M09.05-C043-T07 · Violating fixture:** Create the source counterexample “A small fixture suite is described as proof for every possible program” for “Semantic correctness verdict”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M09.05-C043-T08 · Enforcement evidence:** Exercise the “Semantic correctness verdict” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M09.05-C043-T09 · Regression linkage:** Link the “Semantic correctness verdict” property to changes in independent assurance verdicts and profile-specific release promotion rules; record which dependency or contract changes require rerunning it.
- [ ] **UC-M09.05-C043-T10 · Property disposition:** Compare the satisfying and violating “Semantic correctness verdict” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M09.05-C044 · Integration

**Original checklist item:** Integrate semantic correctness verdict with independent assurance verdicts and profile-specific release promotion rules; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M09.05-C044-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Semantic correctness verdict” across independent assurance verdicts and profile-specific release promotion rules; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M09.05-C044-T02 · Field mapping:** Map every “Semantic correctness verdict” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M09.05-C044-T03 · Prerequisite identities:** Record the actual prerequisites for “Semantic correctness verdict” (source dependency list: UC-M01.07, UC-M04.04, UC-M06.05); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M09.05-C044-T04 · Ownership agreement:** Specify who owns “Semantic correctness verdict” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M09.05-C044-T05 · Handoff implementation:** Connect “Semantic correctness verdict” through the mapped seam using the real adapter or explicit specification reference; preserve “Correctness claims stay within the exercised semantics and supported scope” across the handoff.
- [ ] **UC-M09.05-C044-T06 · Absent-input case:** Omit one required “Semantic correctness verdict” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M09.05-C044-T07 · Stale-input case:** Supply an outdated “Semantic correctness verdict” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M09.05-C044-T08 · Incompatible-input case:** Supply an incompatible “Semantic correctness verdict” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M09.05-C044-T09 · Valid integration trace:** Run a valid “Semantic correctness verdict” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M09.05-C044-T10 · Seam review:** Reconcile the “Semantic correctness verdict” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M09.05-C045 · Valid-case test

**Original checklist item:** Construct a valid worked example for semantic correctness verdict; evaluate it against predeclared expected decisions and, where enforcement exists, run the corresponding conformance fixture.

- [ ] **UC-M09.05-C045-T01 · Valid fixture choice:** Select one concrete valid worked example for “Semantic correctness verdict”; enumerate the model inputs and the expected review decision before evaluating it.
- [ ] **UC-M09.05-C045-T02 · Expected-result oracle:** Specify the “Semantic correctness verdict” expected result independently of the implementation output; include the property “Correctness claims stay within the exercised semantics and supported scope” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M09.05-C045-T03 · Fixture material:** Create the concrete “Semantic correctness verdict” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M09.05-C045-T04 · Target preparation:** Prepare the “Semantic correctness verdict” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M09.05-C045-T05 · Initial-state record:** Record the initial “Semantic correctness verdict” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M09.05-C045-T06 · Valid-path execution:** Evaluate the “Semantic correctness verdict” example against the reviewed model; where a runtime mechanism exists, run its corresponding fixture and label those observations separately.
- [ ] **UC-M09.05-C045-T07 · Outcome comparison:** Compare every declared “Semantic correctness verdict” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M09.05-C045-T08 · State and bounds check:** Inspect the “Semantic correctness verdict” ownership/state effects and actual use of “Input domain and test coverage scope”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M09.05-C045-T09 · Repeatability check:** Repeat the same “Semantic correctness verdict” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M09.05-C045-T10 · Positive evidence:** Attach the “Semantic correctness verdict” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M09.05-C046 · Negative test

**Original checklist item:** Negative case: A small fixture suite is described as proof for every possible program. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M09.05-C046-T01 · Adverse-case definition:** Create a test record for the exact “Semantic correctness verdict” source counterexample: “A small fixture suite is described as proof for every possible program”; state which precondition or invariant it challenges.
- [ ] **UC-M09.05-C046-T02 · Safe fixture boundary:** Define the contained test boundary for “Semantic correctness verdict”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M09.05-C046-T03 · Valid control:** Construct a valid “Semantic correctness verdict” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M09.05-C046-T04 · Minimal adverse input:** Derive the “Semantic correctness verdict” adverse fixture from the control with the smallest documented change needed to reproduce “A small fixture suite is described as proof for every possible program”; retain that change as reproducible data.
- [ ] **UC-M09.05-C046-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Semantic correctness verdict”; require “Correctness claims stay within the exercised semantics and supported scope” and forbid a false-success verdict.
- [ ] **UC-M09.05-C046-T06 · Adverse execution:** Evaluate the “Semantic correctness verdict” adverse case through the actual review/contract gate; where implemented, also observe the runtime refusal and keep the two evidence classes separate.
- [ ] **UC-M09.05-C046-T07 · Effect inspection:** Inspect “Semantic correctness verdict” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M09.05-C046-T08 · Refusal versus failure:** Confirm the “Semantic correctness verdict” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M09.05-C046-T09 · Reset and retention:** Restore only the disposable “Semantic correctness verdict” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M09.05-C046-T10 · Negative regression:** Register the “Semantic correctness verdict” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M09.05-C047 · Change / failure test

**Original checklist item:** Exercise semantic correctness verdict when one assurance class passes while another required class fails or becomes stale; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M09.05-C047-T01 · Scenario record:** Write the “Semantic correctness verdict” change/failure scenario exactly as supplied: one assurance class passes while another required class fails or becomes stale; identify the property that must remain true: “Correctness claims stay within the exercised semantics and supported scope”.
- [ ] **UC-M09.05-C047-T02 · Baseline capture:** Create a known-valid “Semantic correctness verdict” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M09.05-C047-T03 · Injection map:** Locate the “Semantic correctness verdict” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M09.05-C047-T04 · Disposition oracle:** Define the legal intermediate and final “Semantic correctness verdict” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M09.05-C047-T05 · Controlled trigger:** Apply the controlled model-change scenario for “Semantic correctness verdict”: one assurance class passes while another required class fails or becomes stale; retain the exact before/after declarations. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M09.05-C047-T06 · Intermediate inspection:** Review which “Semantic correctness verdict” claims, approvals and evidence references become stale after the change; keep unresolved enforcement gaps visible.
- [ ] **UC-M09.05-C047-T07 · Recovery path:** Revise or explicitly refuse the changed “Semantic correctness verdict” model under the documented compatibility policy; re-review affected claims before restoring their approval.
- [ ] **UC-M09.05-C047-T08 · Stale-evidence cleanup:** Invalidate superseded “Semantic correctness verdict” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M09.05-C047-T09 · Repeat and compare:** Repeat the selected “Semantic correctness verdict” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M09.05-C047-T10 · Failure evidence:** Publish the “Semantic correctness verdict” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M09.05-C048 · Bounds

**Original checklist item:** Define completeness and scaling criteria for input domain and test coverage scope; exercise larger inventories or fixture sets, and report uncovered scope instead of silently excluding it.

- [ ] **UC-M09.05-C048-T01 · Quantity inventory:** Create a measurement inventory for “Semantic correctness verdict”: “Input domain and test coverage scope”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M09.05-C048-T02 · Measurement method:** Choose how to observe each “Semantic correctness verdict” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M09.05-C048-T03 · Budget decision:** Select justified coverage and completeness limits for “Semantic correctness verdict”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M09.05-C048-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Semantic correctness verdict” cases for “Input domain and test coverage scope”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M09.05-C048-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Semantic correctness verdict” limit; preserve “Correctness claims stay within the exercised semantics and supported scope”.
- [ ] **UC-M09.05-C048-T06 · Normal measurement:** Run or review the normal “Semantic correctness verdict” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M09.05-C048-T07 · At-limit measurement:** Exercise the “Semantic correctness verdict” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M09.05-C048-T08 · Over-limit measurement:** Exercise the “Semantic correctness verdict” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M09.05-C048-T09 · Uncovered-scope report:** List the “Semantic correctness verdict” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M09.05-C048-T10 · Limit evidence:** Publish the selected “Semantic correctness verdict” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M09.05-C049 · Diagnostics / review

**Original checklist item:** Record the rationale, unresolved assumptions, enforcement gaps and re-review triggers for semantic correctness verdict; make design-only claims visibly distinct from observed behavior.

- [ ] **UC-M09.05-C049-T01 · Review inventory:** List the “Semantic correctness verdict” decisions and claims requiring review; distinguish source requirements, implementation observations and engineering assumptions.
- [ ] **UC-M09.05-C049-T02 · Rationale record:** Write the rationale for the selected “Semantic correctness verdict” representation or policy; link each choice to the requirement rather than an unexplained preference.
- [ ] **UC-M09.05-C049-T03 · Assumption ledger:** Record unresolved “Semantic correctness verdict” assumptions, their owner and what observation or decision would resolve them; do not treat unknowns as approvals.
- [ ] **UC-M09.05-C049-T04 · Boundary map:** Map each “Semantic correctness verdict” claim to an actual guard or explicit design/review gate; flag gaps against “Correctness claims stay within the exercised semantics and supported scope”.
- [ ] **UC-M09.05-C049-T05 · Counterexample review:** Walk reviewers through the “Semantic correctness verdict” counterexample “A small fixture suite is described as proof for every possible program”; record whether the model detects it and whether any runtime guard was actually exercised.
- [ ] **UC-M09.05-C049-T06 · Review outcome vocabulary:** Define approved, blocked, superseded and untested review outcomes for “Semantic correctness verdict”; ensure the wording cannot be read as runtime enforcement evidence.
- [ ] **UC-M09.05-C049-T07 · Re-review triggers:** List “Semantic correctness verdict” invalidation triggers, including the source change scenario: one assurance class passes while another required class fails or becomes stale; identify the affected claims and evidence.
- [ ] **UC-M09.05-C049-T08 · Sensitive-data review:** Inspect the “Semantic correctness verdict” review record for secrets and unrelated user content; retain nonsecret references sufficient for reproducibility.
- [ ] **UC-M09.05-C049-T09 · Independent reading:** Have the “Semantic correctness verdict” record read against the original acceptance criterion and independent assurance verdicts and profile-specific release promotion rules; record misunderstandings or missing evidence as corrections.
- [ ] **UC-M09.05-C049-T10 · Review disposition:** Publish the “Semantic correctness verdict” rationale, versioned review outcome, unresolved gaps and explicit next decision; keep blockers open until supported evidence resolves them.

### UC-M09.05-C050 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for semantic correctness verdict; label unexecuted checks as untested.

- [ ] **UC-M09.05-C050-T01 · Evidence inventory:** List the “Semantic correctness verdict” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M09.05-C050-T02 · Artifact references:** Record the exact “Semantic correctness verdict” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M09.05-C050-T03 · Fixture references:** Attach the “Semantic correctness verdict” fixture IDs, input identities and oracle definition; preserve the source counterexample “A small fixture suite is described as proof for every possible program” as a distinct evidence case.
- [ ] **UC-M09.05-C050-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Semantic correctness verdict”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M09.05-C050-T05 · Environment record:** Record the actual “Semantic correctness verdict” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M09.05-C050-T06 · Expected versus observed:** Pair every “Semantic correctness verdict” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M09.05-C050-T07 · Failure and limit records:** Attach “Semantic correctness verdict” change/failure and bounds evidence where required; include uncovered “Input domain and test coverage scope” and unresolved violations of “Correctness claims stay within the exercised semantics and supported scope”.
- [ ] **UC-M09.05-C050-T08 · Evidence hygiene:** Check the “Semantic correctness verdict” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M09.05-C050-T09 · Reproduction review:** Have the “Semantic correctness verdict” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M09.05-C050-T10 · Acceptance linkage:** Link the “Semantic correctness verdict” evidence to its parent and UC-M09.05 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 06. Isolation evidence verdict

**Source delivery:** Record actual backend and host constraints supporting the isolation claim.

**Source invariant:** A manifest isolation label alone is not isolation evidence.

**Source negative case:** An ordinary process run is promoted as hypervisor-isolated.

**Source bounded quantities:** Host probes and supported threat assumptions.

### UC-M09.05-C051 · Contract

**Original checklist item:** Specify the scope and representation of isolation evidence verdict; identify its producer, consumer, authority assumptions and explicitly unsupported cases.

- [ ] **UC-M09.05-C051-T01 · Scope statement:** Draft a scope note for “Isolation evidence verdict” within Proof and digest assurance hierarchy; separate required model statements, explicit exclusions and unresolved design decisions.
- [ ] **UC-M09.05-C051-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Isolation evidence verdict”; record each producer, representation and missing-value meaning.
- [ ] **UC-M09.05-C051-T03 · Output inventory:** List the outputs of “Isolation evidence verdict” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M09.05-C051-T04 · Field dictionary:** Create a field-and-term dictionary for “Isolation evidence verdict”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M09.05-C051-T05 · Prerequisite contract:** Map “Isolation evidence verdict” to the source component prerequisites (UC-M01.07, UC-M04.04, UC-M06.05); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M09.05-C051-T06 · Authority map:** Identify who may produce, change and consume “Isolation evidence verdict”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M09.05-C051-T07 · Invariant clause:** Add a normative clause for “Isolation evidence verdict” that preserves “A manifest isolation label alone is not isolation evidence”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M09.05-C051-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Isolation evidence verdict”; include the source counterexample “An ordinary process run is promoted as hypervisor-isolated” and the intended safe disposition.
- [ ] **UC-M09.05-C051-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Host probes and supported threat assumptions” in the “Isolation evidence verdict” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M09.05-C051-T10 · Contract review:** Review the “Isolation evidence verdict” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M09.05-C052 · Delivery

**Original checklist item:** Record actual backend and host constraints supporting the isolation claim.

- [ ] **UC-M09.05-C052-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Isolation evidence verdict”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M09.05-C052-T02 · Change plan:** Break the source delivery for “Isolation evidence verdict” into concrete edit targets and reviewable outputs; keep the UC-M09.05 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M09.05-C052-T03 · Core artifact:** Create the “Isolation evidence verdict” model, schema or inventory that realizes this source instruction: Record actual backend and host constraints supporting the isolation claim.
- [ ] **UC-M09.05-C052-T04 · Concrete realization:** Populate “Isolation evidence verdict” with one concrete worked case; map every required entity or field to its source and flag any unmapped entry.
- [ ] **UC-M09.05-C052-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Isolation evidence verdict” needed to preserve “A manifest isolation label alone is not isolation evidence”; record an enforcement gap where only a model exists.
- [ ] **UC-M09.05-C052-T06 · Dependency connection:** Connect the “Isolation evidence verdict” specification to independent assurance verdicts and profile-specific release promotion rules; record code coverage separately where the design is not yet enforced.
- [ ] **UC-M09.05-C052-T07 · Resource behavior:** Account for “Host probes and supported threat assumptions” in “Isolation evidence verdict”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M09.05-C052-T08 · Delivery check:** Walk the populated “Isolation evidence verdict” model through a valid example and the source counterexample “An ordinary process run is promoted as hypervisor-isolated”; record corrections and unresolved enforcement gaps.
- [ ] **UC-M09.05-C052-T09 · Patch review:** Review the “Isolation evidence verdict” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M09.05-C052-T10 · Delivery handoff:** Publish the “Isolation evidence verdict” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M09.05-C053 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: A manifest isolation label alone is not isolation evidence. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M09.05-C053-T01 · Named property:** Create a stable property/check name under this parent for “Isolation evidence verdict”; copy its required invariant exactly: “A manifest isolation label alone is not isolation evidence”.
- [ ] **UC-M09.05-C053-T02 · Observable terms:** Define each term in the “Isolation evidence verdict” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M09.05-C053-T03 · Precondition set:** List the preconditions under which “A manifest isolation label alone is not isolation evidence” must hold for “Isolation evidence verdict”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M09.05-C053-T04 · Transition coverage:** Map the “Isolation evidence verdict” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M09.05-C053-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Isolation evidence verdict”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M09.05-C053-T06 · Satisfying fixture:** Create a concrete “Isolation evidence verdict” case that satisfies “A manifest isolation label alone is not isolation evidence”; record its expected observation before running the assertion or review.
- [ ] **UC-M09.05-C053-T07 · Violating fixture:** Create the source counterexample “An ordinary process run is promoted as hypervisor-isolated” for “Isolation evidence verdict”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M09.05-C053-T08 · Enforcement evidence:** Exercise the “Isolation evidence verdict” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M09.05-C053-T09 · Regression linkage:** Link the “Isolation evidence verdict” property to changes in independent assurance verdicts and profile-specific release promotion rules; record which dependency or contract changes require rerunning it.
- [ ] **UC-M09.05-C053-T10 · Property disposition:** Compare the satisfying and violating “Isolation evidence verdict” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M09.05-C054 · Integration

**Original checklist item:** Integrate isolation evidence verdict with independent assurance verdicts and profile-specific release promotion rules; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M09.05-C054-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Isolation evidence verdict” across independent assurance verdicts and profile-specific release promotion rules; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M09.05-C054-T02 · Field mapping:** Map every “Isolation evidence verdict” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M09.05-C054-T03 · Prerequisite identities:** Record the actual prerequisites for “Isolation evidence verdict” (source dependency list: UC-M01.07, UC-M04.04, UC-M06.05); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M09.05-C054-T04 · Ownership agreement:** Specify who owns “Isolation evidence verdict” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M09.05-C054-T05 · Handoff implementation:** Connect “Isolation evidence verdict” through the mapped seam using the real adapter or explicit specification reference; preserve “A manifest isolation label alone is not isolation evidence” across the handoff.
- [ ] **UC-M09.05-C054-T06 · Absent-input case:** Omit one required “Isolation evidence verdict” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M09.05-C054-T07 · Stale-input case:** Supply an outdated “Isolation evidence verdict” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M09.05-C054-T08 · Incompatible-input case:** Supply an incompatible “Isolation evidence verdict” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M09.05-C054-T09 · Valid integration trace:** Run a valid “Isolation evidence verdict” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M09.05-C054-T10 · Seam review:** Reconcile the “Isolation evidence verdict” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M09.05-C055 · Valid-case test

**Original checklist item:** Construct a valid worked example for isolation evidence verdict; evaluate it against predeclared expected decisions and, where enforcement exists, run the corresponding conformance fixture.

- [ ] **UC-M09.05-C055-T01 · Valid fixture choice:** Select one concrete valid worked example for “Isolation evidence verdict”; enumerate the model inputs and the expected review decision before evaluating it.
- [ ] **UC-M09.05-C055-T02 · Expected-result oracle:** Specify the “Isolation evidence verdict” expected result independently of the implementation output; include the property “A manifest isolation label alone is not isolation evidence” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M09.05-C055-T03 · Fixture material:** Create the concrete “Isolation evidence verdict” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M09.05-C055-T04 · Target preparation:** Prepare the “Isolation evidence verdict” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M09.05-C055-T05 · Initial-state record:** Record the initial “Isolation evidence verdict” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M09.05-C055-T06 · Valid-path execution:** Evaluate the “Isolation evidence verdict” example against the reviewed model; where a runtime mechanism exists, run its corresponding fixture and label those observations separately.
- [ ] **UC-M09.05-C055-T07 · Outcome comparison:** Compare every declared “Isolation evidence verdict” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M09.05-C055-T08 · State and bounds check:** Inspect the “Isolation evidence verdict” ownership/state effects and actual use of “Host probes and supported threat assumptions”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M09.05-C055-T09 · Repeatability check:** Repeat the same “Isolation evidence verdict” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M09.05-C055-T10 · Positive evidence:** Attach the “Isolation evidence verdict” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M09.05-C056 · Negative test

**Original checklist item:** Negative case: An ordinary process run is promoted as hypervisor-isolated. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M09.05-C056-T01 · Adverse-case definition:** Create a test record for the exact “Isolation evidence verdict” source counterexample: “An ordinary process run is promoted as hypervisor-isolated”; state which precondition or invariant it challenges.
- [ ] **UC-M09.05-C056-T02 · Safe fixture boundary:** Define the contained test boundary for “Isolation evidence verdict”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M09.05-C056-T03 · Valid control:** Construct a valid “Isolation evidence verdict” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M09.05-C056-T04 · Minimal adverse input:** Derive the “Isolation evidence verdict” adverse fixture from the control with the smallest documented change needed to reproduce “An ordinary process run is promoted as hypervisor-isolated”; retain that change as reproducible data.
- [ ] **UC-M09.05-C056-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Isolation evidence verdict”; require “A manifest isolation label alone is not isolation evidence” and forbid a false-success verdict.
- [ ] **UC-M09.05-C056-T06 · Adverse execution:** Evaluate the “Isolation evidence verdict” adverse case through the actual review/contract gate; where implemented, also observe the runtime refusal and keep the two evidence classes separate.
- [ ] **UC-M09.05-C056-T07 · Effect inspection:** Inspect “Isolation evidence verdict” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M09.05-C056-T08 · Refusal versus failure:** Confirm the “Isolation evidence verdict” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M09.05-C056-T09 · Reset and retention:** Restore only the disposable “Isolation evidence verdict” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M09.05-C056-T10 · Negative regression:** Register the “Isolation evidence verdict” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M09.05-C057 · Change / failure test

**Original checklist item:** Exercise isolation evidence verdict when one assurance class passes while another required class fails or becomes stale; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M09.05-C057-T01 · Scenario record:** Write the “Isolation evidence verdict” change/failure scenario exactly as supplied: one assurance class passes while another required class fails or becomes stale; identify the property that must remain true: “A manifest isolation label alone is not isolation evidence”.
- [ ] **UC-M09.05-C057-T02 · Baseline capture:** Create a known-valid “Isolation evidence verdict” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M09.05-C057-T03 · Injection map:** Locate the “Isolation evidence verdict” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M09.05-C057-T04 · Disposition oracle:** Define the legal intermediate and final “Isolation evidence verdict” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M09.05-C057-T05 · Controlled trigger:** Apply the controlled model-change scenario for “Isolation evidence verdict”: one assurance class passes while another required class fails or becomes stale; retain the exact before/after declarations. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M09.05-C057-T06 · Intermediate inspection:** Review which “Isolation evidence verdict” claims, approvals and evidence references become stale after the change; keep unresolved enforcement gaps visible.
- [ ] **UC-M09.05-C057-T07 · Recovery path:** Revise or explicitly refuse the changed “Isolation evidence verdict” model under the documented compatibility policy; re-review affected claims before restoring their approval.
- [ ] **UC-M09.05-C057-T08 · Stale-evidence cleanup:** Invalidate superseded “Isolation evidence verdict” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M09.05-C057-T09 · Repeat and compare:** Repeat the selected “Isolation evidence verdict” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M09.05-C057-T10 · Failure evidence:** Publish the “Isolation evidence verdict” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M09.05-C058 · Bounds

**Original checklist item:** Define completeness and scaling criteria for host probes and supported threat assumptions; exercise larger inventories or fixture sets, and report uncovered scope instead of silently excluding it.

- [ ] **UC-M09.05-C058-T01 · Quantity inventory:** Create a measurement inventory for “Isolation evidence verdict”: “Host probes and supported threat assumptions”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M09.05-C058-T02 · Measurement method:** Choose how to observe each “Isolation evidence verdict” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M09.05-C058-T03 · Budget decision:** Select justified coverage and completeness limits for “Isolation evidence verdict”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M09.05-C058-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Isolation evidence verdict” cases for “Host probes and supported threat assumptions”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M09.05-C058-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Isolation evidence verdict” limit; preserve “A manifest isolation label alone is not isolation evidence”.
- [ ] **UC-M09.05-C058-T06 · Normal measurement:** Run or review the normal “Isolation evidence verdict” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M09.05-C058-T07 · At-limit measurement:** Exercise the “Isolation evidence verdict” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M09.05-C058-T08 · Over-limit measurement:** Exercise the “Isolation evidence verdict” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M09.05-C058-T09 · Uncovered-scope report:** List the “Isolation evidence verdict” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M09.05-C058-T10 · Limit evidence:** Publish the selected “Isolation evidence verdict” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M09.05-C059 · Diagnostics / review

**Original checklist item:** Record the rationale, unresolved assumptions, enforcement gaps and re-review triggers for isolation evidence verdict; make design-only claims visibly distinct from observed behavior.

- [ ] **UC-M09.05-C059-T01 · Review inventory:** List the “Isolation evidence verdict” decisions and claims requiring review; distinguish source requirements, implementation observations and engineering assumptions.
- [ ] **UC-M09.05-C059-T02 · Rationale record:** Write the rationale for the selected “Isolation evidence verdict” representation or policy; link each choice to the requirement rather than an unexplained preference.
- [ ] **UC-M09.05-C059-T03 · Assumption ledger:** Record unresolved “Isolation evidence verdict” assumptions, their owner and what observation or decision would resolve them; do not treat unknowns as approvals.
- [ ] **UC-M09.05-C059-T04 · Boundary map:** Map each “Isolation evidence verdict” claim to an actual guard or explicit design/review gate; flag gaps against “A manifest isolation label alone is not isolation evidence”.
- [ ] **UC-M09.05-C059-T05 · Counterexample review:** Walk reviewers through the “Isolation evidence verdict” counterexample “An ordinary process run is promoted as hypervisor-isolated”; record whether the model detects it and whether any runtime guard was actually exercised.
- [ ] **UC-M09.05-C059-T06 · Review outcome vocabulary:** Define approved, blocked, superseded and untested review outcomes for “Isolation evidence verdict”; ensure the wording cannot be read as runtime enforcement evidence.
- [ ] **UC-M09.05-C059-T07 · Re-review triggers:** List “Isolation evidence verdict” invalidation triggers, including the source change scenario: one assurance class passes while another required class fails or becomes stale; identify the affected claims and evidence.
- [ ] **UC-M09.05-C059-T08 · Sensitive-data review:** Inspect the “Isolation evidence verdict” review record for secrets and unrelated user content; retain nonsecret references sufficient for reproducibility.
- [ ] **UC-M09.05-C059-T09 · Independent reading:** Have the “Isolation evidence verdict” record read against the original acceptance criterion and independent assurance verdicts and profile-specific release promotion rules; record misunderstandings or missing evidence as corrections.
- [ ] **UC-M09.05-C059-T10 · Review disposition:** Publish the “Isolation evidence verdict” rationale, versioned review outcome, unresolved gaps and explicit next decision; keep blockers open until supported evidence resolves them.

### UC-M09.05-C060 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for isolation evidence verdict; label unexecuted checks as untested.

- [ ] **UC-M09.05-C060-T01 · Evidence inventory:** List the “Isolation evidence verdict” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M09.05-C060-T02 · Artifact references:** Record the exact “Isolation evidence verdict” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M09.05-C060-T03 · Fixture references:** Attach the “Isolation evidence verdict” fixture IDs, input identities and oracle definition; preserve the source counterexample “An ordinary process run is promoted as hypervisor-isolated” as a distinct evidence case.
- [ ] **UC-M09.05-C060-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Isolation evidence verdict”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M09.05-C060-T05 · Environment record:** Record the actual “Isolation evidence verdict” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M09.05-C060-T06 · Expected versus observed:** Pair every “Isolation evidence verdict” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M09.05-C060-T07 · Failure and limit records:** Attach “Isolation evidence verdict” change/failure and bounds evidence where required; include uncovered “Host probes and supported threat assumptions” and unresolved violations of “A manifest isolation label alone is not isolation evidence”.
- [ ] **UC-M09.05-C060-T08 · Evidence hygiene:** Check the “Isolation evidence verdict” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M09.05-C060-T09 · Reproduction review:** Have the “Isolation evidence verdict” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M09.05-C060-T10 · Acceptance linkage:** Link the “Isolation evidence verdict” evidence to its parent and UC-M09.05 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 07. Verdict independence

**Source delivery:** Keep the five assurance results separately visible in APIs and reports.

**Source invariant:** One passing verdict cannot hide a failed required different verdict.

**Source negative case:** A passing signature turns the combined report green despite failed semantics.

**Source bounded quantities:** Verdict combinations and report fields.

### UC-M09.05-C061 · Contract

**Original checklist item:** Specify the scope and representation of verdict independence; identify its producer, consumer, authority assumptions and explicitly unsupported cases.

- [ ] **UC-M09.05-C061-T01 · Scope statement:** Draft a scope note for “Verdict independence” within Proof and digest assurance hierarchy; separate required model statements, explicit exclusions and unresolved design decisions.
- [ ] **UC-M09.05-C061-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Verdict independence”; record each producer, representation and missing-value meaning.
- [ ] **UC-M09.05-C061-T03 · Output inventory:** List the outputs of “Verdict independence” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M09.05-C061-T04 · Field dictionary:** Create a field-and-term dictionary for “Verdict independence”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M09.05-C061-T05 · Prerequisite contract:** Map “Verdict independence” to the source component prerequisites (UC-M01.07, UC-M04.04, UC-M06.05); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M09.05-C061-T06 · Authority map:** Identify who may produce, change and consume “Verdict independence”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M09.05-C061-T07 · Invariant clause:** Add a normative clause for “Verdict independence” that preserves “One passing verdict cannot hide a failed required different verdict”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M09.05-C061-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Verdict independence”; include the source counterexample “A passing signature turns the combined report green despite failed semantics” and the intended safe disposition.
- [ ] **UC-M09.05-C061-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Verdict combinations and report fields” in the “Verdict independence” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M09.05-C061-T10 · Contract review:** Review the “Verdict independence” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M09.05-C062 · Delivery

**Original checklist item:** Keep the five assurance results separately visible in APIs and reports.

- [ ] **UC-M09.05-C062-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Verdict independence”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M09.05-C062-T02 · Change plan:** Break the source delivery for “Verdict independence” into concrete edit targets and reviewable outputs; keep the UC-M09.05 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M09.05-C062-T03 · Core artifact:** Implement the smallest selected-profile change for “Verdict independence” that realizes this source instruction: Keep the five assurance results separately visible in APIs and reports.
- [ ] **UC-M09.05-C062-T04 · Concrete realization:** Trace “Verdict independence” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M09.05-C062-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Verdict independence” needed to preserve “One passing verdict cannot hide a failed required different verdict”; record an enforcement gap where only a model exists.
- [ ] **UC-M09.05-C062-T06 · Dependency connection:** Connect the “Verdict independence” specification to independent assurance verdicts and profile-specific release promotion rules; record code coverage separately where the design is not yet enforced.
- [ ] **UC-M09.05-C062-T07 · Resource behavior:** Account for “Verdict combinations and report fields” in “Verdict independence”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M09.05-C062-T08 · Delivery check:** Walk the populated “Verdict independence” model through a valid example and the source counterexample “A passing signature turns the combined report green despite failed semantics”; record corrections and unresolved enforcement gaps.
- [ ] **UC-M09.05-C062-T09 · Patch review:** Review the “Verdict independence” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M09.05-C062-T10 · Delivery handoff:** Publish the “Verdict independence” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M09.05-C063 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: One passing verdict cannot hide a failed required different verdict. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M09.05-C063-T01 · Named property:** Create a stable property/check name under this parent for “Verdict independence”; copy its required invariant exactly: “One passing verdict cannot hide a failed required different verdict”.
- [ ] **UC-M09.05-C063-T02 · Observable terms:** Define each term in the “Verdict independence” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M09.05-C063-T03 · Precondition set:** List the preconditions under which “One passing verdict cannot hide a failed required different verdict” must hold for “Verdict independence”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M09.05-C063-T04 · Transition coverage:** Map the “Verdict independence” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M09.05-C063-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Verdict independence”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M09.05-C063-T06 · Satisfying fixture:** Create a concrete “Verdict independence” case that satisfies “One passing verdict cannot hide a failed required different verdict”; record its expected observation before running the assertion or review.
- [ ] **UC-M09.05-C063-T07 · Violating fixture:** Create the source counterexample “A passing signature turns the combined report green despite failed semantics” for “Verdict independence”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M09.05-C063-T08 · Enforcement evidence:** Exercise the “Verdict independence” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M09.05-C063-T09 · Regression linkage:** Link the “Verdict independence” property to changes in independent assurance verdicts and profile-specific release promotion rules; record which dependency or contract changes require rerunning it.
- [ ] **UC-M09.05-C063-T10 · Property disposition:** Compare the satisfying and violating “Verdict independence” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M09.05-C064 · Integration

**Original checklist item:** Integrate verdict independence with independent assurance verdicts and profile-specific release promotion rules; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M09.05-C064-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Verdict independence” across independent assurance verdicts and profile-specific release promotion rules; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M09.05-C064-T02 · Field mapping:** Map every “Verdict independence” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M09.05-C064-T03 · Prerequisite identities:** Record the actual prerequisites for “Verdict independence” (source dependency list: UC-M01.07, UC-M04.04, UC-M06.05); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M09.05-C064-T04 · Ownership agreement:** Specify who owns “Verdict independence” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M09.05-C064-T05 · Handoff implementation:** Connect “Verdict independence” through the mapped seam using the real adapter or explicit specification reference; preserve “One passing verdict cannot hide a failed required different verdict” across the handoff.
- [ ] **UC-M09.05-C064-T06 · Absent-input case:** Omit one required “Verdict independence” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M09.05-C064-T07 · Stale-input case:** Supply an outdated “Verdict independence” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M09.05-C064-T08 · Incompatible-input case:** Supply an incompatible “Verdict independence” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M09.05-C064-T09 · Valid integration trace:** Run a valid “Verdict independence” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M09.05-C064-T10 · Seam review:** Reconcile the “Verdict independence” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M09.05-C065 · Valid-case test

**Original checklist item:** Construct a valid worked example for verdict independence; evaluate it against predeclared expected decisions and, where enforcement exists, run the corresponding conformance fixture.

- [ ] **UC-M09.05-C065-T01 · Valid fixture choice:** Select one concrete valid worked example for “Verdict independence”; enumerate the model inputs and the expected review decision before evaluating it.
- [ ] **UC-M09.05-C065-T02 · Expected-result oracle:** Specify the “Verdict independence” expected result independently of the implementation output; include the property “One passing verdict cannot hide a failed required different verdict” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M09.05-C065-T03 · Fixture material:** Create the concrete “Verdict independence” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M09.05-C065-T04 · Target preparation:** Prepare the “Verdict independence” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M09.05-C065-T05 · Initial-state record:** Record the initial “Verdict independence” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M09.05-C065-T06 · Valid-path execution:** Evaluate the “Verdict independence” example against the reviewed model; where a runtime mechanism exists, run its corresponding fixture and label those observations separately.
- [ ] **UC-M09.05-C065-T07 · Outcome comparison:** Compare every declared “Verdict independence” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M09.05-C065-T08 · State and bounds check:** Inspect the “Verdict independence” ownership/state effects and actual use of “Verdict combinations and report fields”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M09.05-C065-T09 · Repeatability check:** Repeat the same “Verdict independence” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M09.05-C065-T10 · Positive evidence:** Attach the “Verdict independence” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M09.05-C066 · Negative test

**Original checklist item:** Negative case: A passing signature turns the combined report green despite failed semantics. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M09.05-C066-T01 · Adverse-case definition:** Create a test record for the exact “Verdict independence” source counterexample: “A passing signature turns the combined report green despite failed semantics”; state which precondition or invariant it challenges.
- [ ] **UC-M09.05-C066-T02 · Safe fixture boundary:** Define the contained test boundary for “Verdict independence”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M09.05-C066-T03 · Valid control:** Construct a valid “Verdict independence” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M09.05-C066-T04 · Minimal adverse input:** Derive the “Verdict independence” adverse fixture from the control with the smallest documented change needed to reproduce “A passing signature turns the combined report green despite failed semantics”; retain that change as reproducible data.
- [ ] **UC-M09.05-C066-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Verdict independence”; require “One passing verdict cannot hide a failed required different verdict” and forbid a false-success verdict.
- [ ] **UC-M09.05-C066-T06 · Adverse execution:** Evaluate the “Verdict independence” adverse case through the actual review/contract gate; where implemented, also observe the runtime refusal and keep the two evidence classes separate.
- [ ] **UC-M09.05-C066-T07 · Effect inspection:** Inspect “Verdict independence” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M09.05-C066-T08 · Refusal versus failure:** Confirm the “Verdict independence” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M09.05-C066-T09 · Reset and retention:** Restore only the disposable “Verdict independence” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M09.05-C066-T10 · Negative regression:** Register the “Verdict independence” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M09.05-C067 · Change / failure test

**Original checklist item:** Exercise verdict independence when one assurance class passes while another required class fails or becomes stale; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M09.05-C067-T01 · Scenario record:** Write the “Verdict independence” change/failure scenario exactly as supplied: one assurance class passes while another required class fails or becomes stale; identify the property that must remain true: “One passing verdict cannot hide a failed required different verdict”.
- [ ] **UC-M09.05-C067-T02 · Baseline capture:** Create a known-valid “Verdict independence” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M09.05-C067-T03 · Injection map:** Locate the “Verdict independence” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M09.05-C067-T04 · Disposition oracle:** Define the legal intermediate and final “Verdict independence” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M09.05-C067-T05 · Controlled trigger:** Apply the controlled model-change scenario for “Verdict independence”: one assurance class passes while another required class fails or becomes stale; retain the exact before/after declarations. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M09.05-C067-T06 · Intermediate inspection:** Review which “Verdict independence” claims, approvals and evidence references become stale after the change; keep unresolved enforcement gaps visible.
- [ ] **UC-M09.05-C067-T07 · Recovery path:** Revise or explicitly refuse the changed “Verdict independence” model under the documented compatibility policy; re-review affected claims before restoring their approval.
- [ ] **UC-M09.05-C067-T08 · Stale-evidence cleanup:** Invalidate superseded “Verdict independence” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M09.05-C067-T09 · Repeat and compare:** Repeat the selected “Verdict independence” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M09.05-C067-T10 · Failure evidence:** Publish the “Verdict independence” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M09.05-C068 · Bounds

**Original checklist item:** Define completeness and scaling criteria for verdict combinations and report fields; exercise larger inventories or fixture sets, and report uncovered scope instead of silently excluding it.

- [ ] **UC-M09.05-C068-T01 · Quantity inventory:** Create a measurement inventory for “Verdict independence”: “Verdict combinations and report fields”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M09.05-C068-T02 · Measurement method:** Choose how to observe each “Verdict independence” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M09.05-C068-T03 · Budget decision:** Select justified coverage and completeness limits for “Verdict independence”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M09.05-C068-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Verdict independence” cases for “Verdict combinations and report fields”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M09.05-C068-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Verdict independence” limit; preserve “One passing verdict cannot hide a failed required different verdict”.
- [ ] **UC-M09.05-C068-T06 · Normal measurement:** Run or review the normal “Verdict independence” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M09.05-C068-T07 · At-limit measurement:** Exercise the “Verdict independence” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M09.05-C068-T08 · Over-limit measurement:** Exercise the “Verdict independence” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M09.05-C068-T09 · Uncovered-scope report:** List the “Verdict independence” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M09.05-C068-T10 · Limit evidence:** Publish the selected “Verdict independence” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M09.05-C069 · Diagnostics / review

**Original checklist item:** Record the rationale, unresolved assumptions, enforcement gaps and re-review triggers for verdict independence; make design-only claims visibly distinct from observed behavior.

- [ ] **UC-M09.05-C069-T01 · Review inventory:** List the “Verdict independence” decisions and claims requiring review; distinguish source requirements, implementation observations and engineering assumptions.
- [ ] **UC-M09.05-C069-T02 · Rationale record:** Write the rationale for the selected “Verdict independence” representation or policy; link each choice to the requirement rather than an unexplained preference.
- [ ] **UC-M09.05-C069-T03 · Assumption ledger:** Record unresolved “Verdict independence” assumptions, their owner and what observation or decision would resolve them; do not treat unknowns as approvals.
- [ ] **UC-M09.05-C069-T04 · Boundary map:** Map each “Verdict independence” claim to an actual guard or explicit design/review gate; flag gaps against “One passing verdict cannot hide a failed required different verdict”.
- [ ] **UC-M09.05-C069-T05 · Counterexample review:** Walk reviewers through the “Verdict independence” counterexample “A passing signature turns the combined report green despite failed semantics”; record whether the model detects it and whether any runtime guard was actually exercised.
- [ ] **UC-M09.05-C069-T06 · Review outcome vocabulary:** Define approved, blocked, superseded and untested review outcomes for “Verdict independence”; ensure the wording cannot be read as runtime enforcement evidence.
- [ ] **UC-M09.05-C069-T07 · Re-review triggers:** List “Verdict independence” invalidation triggers, including the source change scenario: one assurance class passes while another required class fails or becomes stale; identify the affected claims and evidence.
- [ ] **UC-M09.05-C069-T08 · Sensitive-data review:** Inspect the “Verdict independence” review record for secrets and unrelated user content; retain nonsecret references sufficient for reproducibility.
- [ ] **UC-M09.05-C069-T09 · Independent reading:** Have the “Verdict independence” record read against the original acceptance criterion and independent assurance verdicts and profile-specific release promotion rules; record misunderstandings or missing evidence as corrections.
- [ ] **UC-M09.05-C069-T10 · Review disposition:** Publish the “Verdict independence” rationale, versioned review outcome, unresolved gaps and explicit next decision; keep blockers open until supported evidence resolves them.

### UC-M09.05-C070 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for verdict independence; label unexecuted checks as untested.

- [ ] **UC-M09.05-C070-T01 · Evidence inventory:** List the “Verdict independence” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M09.05-C070-T02 · Artifact references:** Record the exact “Verdict independence” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M09.05-C070-T03 · Fixture references:** Attach the “Verdict independence” fixture IDs, input identities and oracle definition; preserve the source counterexample “A passing signature turns the combined report green despite failed semantics” as a distinct evidence case.
- [ ] **UC-M09.05-C070-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Verdict independence”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M09.05-C070-T05 · Environment record:** Record the actual “Verdict independence” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M09.05-C070-T06 · Expected versus observed:** Pair every “Verdict independence” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M09.05-C070-T07 · Failure and limit records:** Attach “Verdict independence” change/failure and bounds evidence where required; include uncovered “Verdict combinations and report fields” and unresolved violations of “One passing verdict cannot hide a failed required different verdict”.
- [ ] **UC-M09.05-C070-T08 · Evidence hygiene:** Check the “Verdict independence” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M09.05-C070-T09 · Reproduction review:** Have the “Verdict independence” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M09.05-C070-T10 · Acceptance linkage:** Link the “Verdict independence” evidence to its parent and UC-M09.05 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 08. Promotion rule mapping

**Source delivery:** Map each release/profile requirement to its required assurance class and evidence.

**Source invariant:** Required semantics or isolation cannot be satisfied by witness agreement.

**Source negative case:** A release gate accepts any available PASS regardless of class.

**Source bounded quantities:** Promotion rules and profile count.

### UC-M09.05-C071 · Contract

**Original checklist item:** Specify the scope and representation of promotion rule mapping; identify its producer, consumer, authority assumptions and explicitly unsupported cases.

- [ ] **UC-M09.05-C071-T01 · Scope statement:** Draft a scope note for “Promotion rule mapping” within Proof and digest assurance hierarchy; separate required model statements, explicit exclusions and unresolved design decisions.
- [ ] **UC-M09.05-C071-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Promotion rule mapping”; record each producer, representation and missing-value meaning.
- [ ] **UC-M09.05-C071-T03 · Output inventory:** List the outputs of “Promotion rule mapping” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M09.05-C071-T04 · Field dictionary:** Create a field-and-term dictionary for “Promotion rule mapping”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M09.05-C071-T05 · Prerequisite contract:** Map “Promotion rule mapping” to the source component prerequisites (UC-M01.07, UC-M04.04, UC-M06.05); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M09.05-C071-T06 · Authority map:** Identify who may produce, change and consume “Promotion rule mapping”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M09.05-C071-T07 · Invariant clause:** Add a normative clause for “Promotion rule mapping” that preserves “Required semantics or isolation cannot be satisfied by witness agreement”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M09.05-C071-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Promotion rule mapping”; include the source counterexample “A release gate accepts any available PASS regardless of class” and the intended safe disposition.
- [ ] **UC-M09.05-C071-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Promotion rules and profile count” in the “Promotion rule mapping” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M09.05-C071-T10 · Contract review:** Review the “Promotion rule mapping” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M09.05-C072 · Delivery

**Original checklist item:** Map each release/profile requirement to its required assurance class and evidence.

- [ ] **UC-M09.05-C072-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Promotion rule mapping”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M09.05-C072-T02 · Change plan:** Break the source delivery for “Promotion rule mapping” into concrete edit targets and reviewable outputs; keep the UC-M09.05 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M09.05-C072-T03 · Core artifact:** Create the “Promotion rule mapping” model, schema or inventory that realizes this source instruction: Map each release/profile requirement to its required assurance class and evidence.
- [ ] **UC-M09.05-C072-T04 · Concrete realization:** Populate “Promotion rule mapping” with one concrete worked case; map every required entity or field to its source and flag any unmapped entry.
- [ ] **UC-M09.05-C072-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Promotion rule mapping” needed to preserve “Required semantics or isolation cannot be satisfied by witness agreement”; record an enforcement gap where only a model exists.
- [ ] **UC-M09.05-C072-T06 · Dependency connection:** Connect the “Promotion rule mapping” specification to independent assurance verdicts and profile-specific release promotion rules; record code coverage separately where the design is not yet enforced.
- [ ] **UC-M09.05-C072-T07 · Resource behavior:** Account for “Promotion rules and profile count” in “Promotion rule mapping”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M09.05-C072-T08 · Delivery check:** Walk the populated “Promotion rule mapping” model through a valid example and the source counterexample “A release gate accepts any available PASS regardless of class”; record corrections and unresolved enforcement gaps.
- [ ] **UC-M09.05-C072-T09 · Patch review:** Review the “Promotion rule mapping” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M09.05-C072-T10 · Delivery handoff:** Publish the “Promotion rule mapping” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M09.05-C073 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Required semantics or isolation cannot be satisfied by witness agreement. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M09.05-C073-T01 · Named property:** Create a stable property/check name under this parent for “Promotion rule mapping”; copy its required invariant exactly: “Required semantics or isolation cannot be satisfied by witness agreement”.
- [ ] **UC-M09.05-C073-T02 · Observable terms:** Define each term in the “Promotion rule mapping” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M09.05-C073-T03 · Precondition set:** List the preconditions under which “Required semantics or isolation cannot be satisfied by witness agreement” must hold for “Promotion rule mapping”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M09.05-C073-T04 · Transition coverage:** Map the “Promotion rule mapping” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M09.05-C073-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Promotion rule mapping”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M09.05-C073-T06 · Satisfying fixture:** Create a concrete “Promotion rule mapping” case that satisfies “Required semantics or isolation cannot be satisfied by witness agreement”; record its expected observation before running the assertion or review.
- [ ] **UC-M09.05-C073-T07 · Violating fixture:** Create the source counterexample “A release gate accepts any available PASS regardless of class” for “Promotion rule mapping”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M09.05-C073-T08 · Enforcement evidence:** Exercise the “Promotion rule mapping” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M09.05-C073-T09 · Regression linkage:** Link the “Promotion rule mapping” property to changes in independent assurance verdicts and profile-specific release promotion rules; record which dependency or contract changes require rerunning it.
- [ ] **UC-M09.05-C073-T10 · Property disposition:** Compare the satisfying and violating “Promotion rule mapping” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M09.05-C074 · Integration

**Original checklist item:** Integrate promotion rule mapping with independent assurance verdicts and profile-specific release promotion rules; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M09.05-C074-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Promotion rule mapping” across independent assurance verdicts and profile-specific release promotion rules; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M09.05-C074-T02 · Field mapping:** Map every “Promotion rule mapping” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M09.05-C074-T03 · Prerequisite identities:** Record the actual prerequisites for “Promotion rule mapping” (source dependency list: UC-M01.07, UC-M04.04, UC-M06.05); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M09.05-C074-T04 · Ownership agreement:** Specify who owns “Promotion rule mapping” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M09.05-C074-T05 · Handoff implementation:** Connect “Promotion rule mapping” through the mapped seam using the real adapter or explicit specification reference; preserve “Required semantics or isolation cannot be satisfied by witness agreement” across the handoff.
- [ ] **UC-M09.05-C074-T06 · Absent-input case:** Omit one required “Promotion rule mapping” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M09.05-C074-T07 · Stale-input case:** Supply an outdated “Promotion rule mapping” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M09.05-C074-T08 · Incompatible-input case:** Supply an incompatible “Promotion rule mapping” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M09.05-C074-T09 · Valid integration trace:** Run a valid “Promotion rule mapping” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M09.05-C074-T10 · Seam review:** Reconcile the “Promotion rule mapping” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M09.05-C075 · Valid-case test

**Original checklist item:** Construct a valid worked example for promotion rule mapping; evaluate it against predeclared expected decisions and, where enforcement exists, run the corresponding conformance fixture.

- [ ] **UC-M09.05-C075-T01 · Valid fixture choice:** Select one concrete valid worked example for “Promotion rule mapping”; enumerate the model inputs and the expected review decision before evaluating it.
- [ ] **UC-M09.05-C075-T02 · Expected-result oracle:** Specify the “Promotion rule mapping” expected result independently of the implementation output; include the property “Required semantics or isolation cannot be satisfied by witness agreement” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M09.05-C075-T03 · Fixture material:** Create the concrete “Promotion rule mapping” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M09.05-C075-T04 · Target preparation:** Prepare the “Promotion rule mapping” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M09.05-C075-T05 · Initial-state record:** Record the initial “Promotion rule mapping” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M09.05-C075-T06 · Valid-path execution:** Evaluate the “Promotion rule mapping” example against the reviewed model; where a runtime mechanism exists, run its corresponding fixture and label those observations separately.
- [ ] **UC-M09.05-C075-T07 · Outcome comparison:** Compare every declared “Promotion rule mapping” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M09.05-C075-T08 · State and bounds check:** Inspect the “Promotion rule mapping” ownership/state effects and actual use of “Promotion rules and profile count”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M09.05-C075-T09 · Repeatability check:** Repeat the same “Promotion rule mapping” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M09.05-C075-T10 · Positive evidence:** Attach the “Promotion rule mapping” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M09.05-C076 · Negative test

**Original checklist item:** Negative case: A release gate accepts any available PASS regardless of class. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M09.05-C076-T01 · Adverse-case definition:** Create a test record for the exact “Promotion rule mapping” source counterexample: “A release gate accepts any available PASS regardless of class”; state which precondition or invariant it challenges.
- [ ] **UC-M09.05-C076-T02 · Safe fixture boundary:** Define the contained test boundary for “Promotion rule mapping”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M09.05-C076-T03 · Valid control:** Construct a valid “Promotion rule mapping” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M09.05-C076-T04 · Minimal adverse input:** Derive the “Promotion rule mapping” adverse fixture from the control with the smallest documented change needed to reproduce “A release gate accepts any available PASS regardless of class”; retain that change as reproducible data.
- [ ] **UC-M09.05-C076-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Promotion rule mapping”; require “Required semantics or isolation cannot be satisfied by witness agreement” and forbid a false-success verdict.
- [ ] **UC-M09.05-C076-T06 · Adverse execution:** Evaluate the “Promotion rule mapping” adverse case through the actual review/contract gate; where implemented, also observe the runtime refusal and keep the two evidence classes separate.
- [ ] **UC-M09.05-C076-T07 · Effect inspection:** Inspect “Promotion rule mapping” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M09.05-C076-T08 · Refusal versus failure:** Confirm the “Promotion rule mapping” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M09.05-C076-T09 · Reset and retention:** Restore only the disposable “Promotion rule mapping” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M09.05-C076-T10 · Negative regression:** Register the “Promotion rule mapping” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M09.05-C077 · Change / failure test

**Original checklist item:** Exercise promotion rule mapping when one assurance class passes while another required class fails or becomes stale; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M09.05-C077-T01 · Scenario record:** Write the “Promotion rule mapping” change/failure scenario exactly as supplied: one assurance class passes while another required class fails or becomes stale; identify the property that must remain true: “Required semantics or isolation cannot be satisfied by witness agreement”.
- [ ] **UC-M09.05-C077-T02 · Baseline capture:** Create a known-valid “Promotion rule mapping” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M09.05-C077-T03 · Injection map:** Locate the “Promotion rule mapping” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M09.05-C077-T04 · Disposition oracle:** Define the legal intermediate and final “Promotion rule mapping” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M09.05-C077-T05 · Controlled trigger:** Apply the controlled model-change scenario for “Promotion rule mapping”: one assurance class passes while another required class fails or becomes stale; retain the exact before/after declarations. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M09.05-C077-T06 · Intermediate inspection:** Review which “Promotion rule mapping” claims, approvals and evidence references become stale after the change; keep unresolved enforcement gaps visible.
- [ ] **UC-M09.05-C077-T07 · Recovery path:** Revise or explicitly refuse the changed “Promotion rule mapping” model under the documented compatibility policy; re-review affected claims before restoring their approval.
- [ ] **UC-M09.05-C077-T08 · Stale-evidence cleanup:** Invalidate superseded “Promotion rule mapping” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M09.05-C077-T09 · Repeat and compare:** Repeat the selected “Promotion rule mapping” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M09.05-C077-T10 · Failure evidence:** Publish the “Promotion rule mapping” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M09.05-C078 · Bounds

**Original checklist item:** Define completeness and scaling criteria for promotion rules and profile count; exercise larger inventories or fixture sets, and report uncovered scope instead of silently excluding it.

- [ ] **UC-M09.05-C078-T01 · Quantity inventory:** Create a measurement inventory for “Promotion rule mapping”: “Promotion rules and profile count”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M09.05-C078-T02 · Measurement method:** Choose how to observe each “Promotion rule mapping” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M09.05-C078-T03 · Budget decision:** Select justified coverage and completeness limits for “Promotion rule mapping”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M09.05-C078-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Promotion rule mapping” cases for “Promotion rules and profile count”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M09.05-C078-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Promotion rule mapping” limit; preserve “Required semantics or isolation cannot be satisfied by witness agreement”.
- [ ] **UC-M09.05-C078-T06 · Normal measurement:** Run or review the normal “Promotion rule mapping” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M09.05-C078-T07 · At-limit measurement:** Exercise the “Promotion rule mapping” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M09.05-C078-T08 · Over-limit measurement:** Exercise the “Promotion rule mapping” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M09.05-C078-T09 · Uncovered-scope report:** List the “Promotion rule mapping” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M09.05-C078-T10 · Limit evidence:** Publish the selected “Promotion rule mapping” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M09.05-C079 · Diagnostics / review

**Original checklist item:** Record the rationale, unresolved assumptions, enforcement gaps and re-review triggers for promotion rule mapping; make design-only claims visibly distinct from observed behavior.

- [ ] **UC-M09.05-C079-T01 · Review inventory:** List the “Promotion rule mapping” decisions and claims requiring review; distinguish source requirements, implementation observations and engineering assumptions.
- [ ] **UC-M09.05-C079-T02 · Rationale record:** Write the rationale for the selected “Promotion rule mapping” representation or policy; link each choice to the requirement rather than an unexplained preference.
- [ ] **UC-M09.05-C079-T03 · Assumption ledger:** Record unresolved “Promotion rule mapping” assumptions, their owner and what observation or decision would resolve them; do not treat unknowns as approvals.
- [ ] **UC-M09.05-C079-T04 · Boundary map:** Map each “Promotion rule mapping” claim to an actual guard or explicit design/review gate; flag gaps against “Required semantics or isolation cannot be satisfied by witness agreement”.
- [ ] **UC-M09.05-C079-T05 · Counterexample review:** Walk reviewers through the “Promotion rule mapping” counterexample “A release gate accepts any available PASS regardless of class”; record whether the model detects it and whether any runtime guard was actually exercised.
- [ ] **UC-M09.05-C079-T06 · Review outcome vocabulary:** Define approved, blocked, superseded and untested review outcomes for “Promotion rule mapping”; ensure the wording cannot be read as runtime enforcement evidence.
- [ ] **UC-M09.05-C079-T07 · Re-review triggers:** List “Promotion rule mapping” invalidation triggers, including the source change scenario: one assurance class passes while another required class fails or becomes stale; identify the affected claims and evidence.
- [ ] **UC-M09.05-C079-T08 · Sensitive-data review:** Inspect the “Promotion rule mapping” review record for secrets and unrelated user content; retain nonsecret references sufficient for reproducibility.
- [ ] **UC-M09.05-C079-T09 · Independent reading:** Have the “Promotion rule mapping” record read against the original acceptance criterion and independent assurance verdicts and profile-specific release promotion rules; record misunderstandings or missing evidence as corrections.
- [ ] **UC-M09.05-C079-T10 · Review disposition:** Publish the “Promotion rule mapping” rationale, versioned review outcome, unresolved gaps and explicit next decision; keep blockers open until supported evidence resolves them.

### UC-M09.05-C080 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for promotion rule mapping; label unexecuted checks as untested.

- [ ] **UC-M09.05-C080-T01 · Evidence inventory:** List the “Promotion rule mapping” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M09.05-C080-T02 · Artifact references:** Record the exact “Promotion rule mapping” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M09.05-C080-T03 · Fixture references:** Attach the “Promotion rule mapping” fixture IDs, input identities and oracle definition; preserve the source counterexample “A release gate accepts any available PASS regardless of class” as a distinct evidence case.
- [ ] **UC-M09.05-C080-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Promotion rule mapping”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M09.05-C080-T05 · Environment record:** Record the actual “Promotion rule mapping” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M09.05-C080-T06 · Expected versus observed:** Pair every “Promotion rule mapping” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M09.05-C080-T07 · Failure and limit records:** Attach “Promotion rule mapping” change/failure and bounds evidence where required; include uncovered “Promotion rules and profile count” and unresolved violations of “Required semantics or isolation cannot be satisfied by witness agreement”.
- [ ] **UC-M09.05-C080-T08 · Evidence hygiene:** Check the “Promotion rule mapping” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M09.05-C080-T09 · Reproduction review:** Have the “Promotion rule mapping” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M09.05-C080-T10 · Acceptance linkage:** Link the “Promotion rule mapping” evidence to its parent and UC-M09.05 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 09. Evidence freshness

**Source delivery:** Bind each verdict to exact subjects, versions and observation scope.

**Source invariant:** Changed subjects invalidate the assurance evidence that depended on them.

**Source negative case:** A new image reuses old isolation and semantic verdicts.

**Source bounded quantities:** Evidence dependencies and invalidation time.

### UC-M09.05-C081 · Contract

**Original checklist item:** Specify the scope and representation of evidence freshness; identify its producer, consumer, authority assumptions and explicitly unsupported cases.

- [ ] **UC-M09.05-C081-T01 · Scope statement:** Draft a scope note for “Evidence freshness” within Proof and digest assurance hierarchy; separate required model statements, explicit exclusions and unresolved design decisions.
- [ ] **UC-M09.05-C081-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Evidence freshness”; record each producer, representation and missing-value meaning.
- [ ] **UC-M09.05-C081-T03 · Output inventory:** List the outputs of “Evidence freshness” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M09.05-C081-T04 · Field dictionary:** Create a field-and-term dictionary for “Evidence freshness”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M09.05-C081-T05 · Prerequisite contract:** Map “Evidence freshness” to the source component prerequisites (UC-M01.07, UC-M04.04, UC-M06.05); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M09.05-C081-T06 · Authority map:** Identify who may produce, change and consume “Evidence freshness”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M09.05-C081-T07 · Invariant clause:** Add a normative clause for “Evidence freshness” that preserves “Changed subjects invalidate the assurance evidence that depended on them”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M09.05-C081-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Evidence freshness”; include the source counterexample “A new image reuses old isolation and semantic verdicts” and the intended safe disposition.
- [ ] **UC-M09.05-C081-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Evidence dependencies and invalidation time” in the “Evidence freshness” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M09.05-C081-T10 · Contract review:** Review the “Evidence freshness” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M09.05-C082 · Delivery

**Original checklist item:** Bind each verdict to exact subjects, versions and observation scope.

- [ ] **UC-M09.05-C082-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Evidence freshness”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M09.05-C082-T02 · Change plan:** Break the source delivery for “Evidence freshness” into concrete edit targets and reviewable outputs; keep the UC-M09.05 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M09.05-C082-T03 · Core artifact:** Implement the smallest selected-profile change for “Evidence freshness” that realizes this source instruction: Bind each verdict to exact subjects, versions and observation scope.
- [ ] **UC-M09.05-C082-T04 · Concrete realization:** Trace “Evidence freshness” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M09.05-C082-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Evidence freshness” needed to preserve “Changed subjects invalidate the assurance evidence that depended on them”; record an enforcement gap where only a model exists.
- [ ] **UC-M09.05-C082-T06 · Dependency connection:** Connect the “Evidence freshness” specification to independent assurance verdicts and profile-specific release promotion rules; record code coverage separately where the design is not yet enforced.
- [ ] **UC-M09.05-C082-T07 · Resource behavior:** Account for “Evidence dependencies and invalidation time” in “Evidence freshness”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M09.05-C082-T08 · Delivery check:** Walk the populated “Evidence freshness” model through a valid example and the source counterexample “A new image reuses old isolation and semantic verdicts”; record corrections and unresolved enforcement gaps.
- [ ] **UC-M09.05-C082-T09 · Patch review:** Review the “Evidence freshness” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M09.05-C082-T10 · Delivery handoff:** Publish the “Evidence freshness” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M09.05-C083 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Changed subjects invalidate the assurance evidence that depended on them. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M09.05-C083-T01 · Named property:** Create a stable property/check name under this parent for “Evidence freshness”; copy its required invariant exactly: “Changed subjects invalidate the assurance evidence that depended on them”.
- [ ] **UC-M09.05-C083-T02 · Observable terms:** Define each term in the “Evidence freshness” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M09.05-C083-T03 · Precondition set:** List the preconditions under which “Changed subjects invalidate the assurance evidence that depended on them” must hold for “Evidence freshness”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M09.05-C083-T04 · Transition coverage:** Map the “Evidence freshness” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M09.05-C083-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Evidence freshness”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M09.05-C083-T06 · Satisfying fixture:** Create a concrete “Evidence freshness” case that satisfies “Changed subjects invalidate the assurance evidence that depended on them”; record its expected observation before running the assertion or review.
- [ ] **UC-M09.05-C083-T07 · Violating fixture:** Create the source counterexample “A new image reuses old isolation and semantic verdicts” for “Evidence freshness”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M09.05-C083-T08 · Enforcement evidence:** Exercise the “Evidence freshness” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M09.05-C083-T09 · Regression linkage:** Link the “Evidence freshness” property to changes in independent assurance verdicts and profile-specific release promotion rules; record which dependency or contract changes require rerunning it.
- [ ] **UC-M09.05-C083-T10 · Property disposition:** Compare the satisfying and violating “Evidence freshness” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M09.05-C084 · Integration

**Original checklist item:** Integrate evidence freshness with independent assurance verdicts and profile-specific release promotion rules; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M09.05-C084-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Evidence freshness” across independent assurance verdicts and profile-specific release promotion rules; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M09.05-C084-T02 · Field mapping:** Map every “Evidence freshness” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M09.05-C084-T03 · Prerequisite identities:** Record the actual prerequisites for “Evidence freshness” (source dependency list: UC-M01.07, UC-M04.04, UC-M06.05); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M09.05-C084-T04 · Ownership agreement:** Specify who owns “Evidence freshness” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M09.05-C084-T05 · Handoff implementation:** Connect “Evidence freshness” through the mapped seam using the real adapter or explicit specification reference; preserve “Changed subjects invalidate the assurance evidence that depended on them” across the handoff.
- [ ] **UC-M09.05-C084-T06 · Absent-input case:** Omit one required “Evidence freshness” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M09.05-C084-T07 · Stale-input case:** Supply an outdated “Evidence freshness” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M09.05-C084-T08 · Incompatible-input case:** Supply an incompatible “Evidence freshness” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M09.05-C084-T09 · Valid integration trace:** Run a valid “Evidence freshness” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M09.05-C084-T10 · Seam review:** Reconcile the “Evidence freshness” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M09.05-C085 · Valid-case test

**Original checklist item:** Construct a valid worked example for evidence freshness; evaluate it against predeclared expected decisions and, where enforcement exists, run the corresponding conformance fixture.

- [ ] **UC-M09.05-C085-T01 · Valid fixture choice:** Select one concrete valid worked example for “Evidence freshness”; enumerate the model inputs and the expected review decision before evaluating it.
- [ ] **UC-M09.05-C085-T02 · Expected-result oracle:** Specify the “Evidence freshness” expected result independently of the implementation output; include the property “Changed subjects invalidate the assurance evidence that depended on them” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M09.05-C085-T03 · Fixture material:** Create the concrete “Evidence freshness” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M09.05-C085-T04 · Target preparation:** Prepare the “Evidence freshness” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M09.05-C085-T05 · Initial-state record:** Record the initial “Evidence freshness” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M09.05-C085-T06 · Valid-path execution:** Evaluate the “Evidence freshness” example against the reviewed model; where a runtime mechanism exists, run its corresponding fixture and label those observations separately.
- [ ] **UC-M09.05-C085-T07 · Outcome comparison:** Compare every declared “Evidence freshness” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M09.05-C085-T08 · State and bounds check:** Inspect the “Evidence freshness” ownership/state effects and actual use of “Evidence dependencies and invalidation time”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M09.05-C085-T09 · Repeatability check:** Repeat the same “Evidence freshness” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M09.05-C085-T10 · Positive evidence:** Attach the “Evidence freshness” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M09.05-C086 · Negative test

**Original checklist item:** Negative case: A new image reuses old isolation and semantic verdicts. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M09.05-C086-T01 · Adverse-case definition:** Create a test record for the exact “Evidence freshness” source counterexample: “A new image reuses old isolation and semantic verdicts”; state which precondition or invariant it challenges.
- [ ] **UC-M09.05-C086-T02 · Safe fixture boundary:** Define the contained test boundary for “Evidence freshness”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M09.05-C086-T03 · Valid control:** Construct a valid “Evidence freshness” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M09.05-C086-T04 · Minimal adverse input:** Derive the “Evidence freshness” adverse fixture from the control with the smallest documented change needed to reproduce “A new image reuses old isolation and semantic verdicts”; retain that change as reproducible data.
- [ ] **UC-M09.05-C086-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Evidence freshness”; require “Changed subjects invalidate the assurance evidence that depended on them” and forbid a false-success verdict.
- [ ] **UC-M09.05-C086-T06 · Adverse execution:** Evaluate the “Evidence freshness” adverse case through the actual review/contract gate; where implemented, also observe the runtime refusal and keep the two evidence classes separate.
- [ ] **UC-M09.05-C086-T07 · Effect inspection:** Inspect “Evidence freshness” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M09.05-C086-T08 · Refusal versus failure:** Confirm the “Evidence freshness” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M09.05-C086-T09 · Reset and retention:** Restore only the disposable “Evidence freshness” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M09.05-C086-T10 · Negative regression:** Register the “Evidence freshness” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M09.05-C087 · Change / failure test

**Original checklist item:** Exercise evidence freshness when one assurance class passes while another required class fails or becomes stale; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M09.05-C087-T01 · Scenario record:** Write the “Evidence freshness” change/failure scenario exactly as supplied: one assurance class passes while another required class fails or becomes stale; identify the property that must remain true: “Changed subjects invalidate the assurance evidence that depended on them”.
- [ ] **UC-M09.05-C087-T02 · Baseline capture:** Create a known-valid “Evidence freshness” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M09.05-C087-T03 · Injection map:** Locate the “Evidence freshness” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M09.05-C087-T04 · Disposition oracle:** Define the legal intermediate and final “Evidence freshness” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M09.05-C087-T05 · Controlled trigger:** Apply the controlled model-change scenario for “Evidence freshness”: one assurance class passes while another required class fails or becomes stale; retain the exact before/after declarations. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M09.05-C087-T06 · Intermediate inspection:** Review which “Evidence freshness” claims, approvals and evidence references become stale after the change; keep unresolved enforcement gaps visible.
- [ ] **UC-M09.05-C087-T07 · Recovery path:** Revise or explicitly refuse the changed “Evidence freshness” model under the documented compatibility policy; re-review affected claims before restoring their approval.
- [ ] **UC-M09.05-C087-T08 · Stale-evidence cleanup:** Invalidate superseded “Evidence freshness” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M09.05-C087-T09 · Repeat and compare:** Repeat the selected “Evidence freshness” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M09.05-C087-T10 · Failure evidence:** Publish the “Evidence freshness” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M09.05-C088 · Bounds

**Original checklist item:** Define completeness and scaling criteria for evidence dependencies and invalidation time; exercise larger inventories or fixture sets, and report uncovered scope instead of silently excluding it.

- [ ] **UC-M09.05-C088-T01 · Quantity inventory:** Create a measurement inventory for “Evidence freshness”: “Evidence dependencies and invalidation time”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M09.05-C088-T02 · Measurement method:** Choose how to observe each “Evidence freshness” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M09.05-C088-T03 · Budget decision:** Select justified coverage and completeness limits for “Evidence freshness”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M09.05-C088-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Evidence freshness” cases for “Evidence dependencies and invalidation time”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M09.05-C088-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Evidence freshness” limit; preserve “Changed subjects invalidate the assurance evidence that depended on them”.
- [ ] **UC-M09.05-C088-T06 · Normal measurement:** Run or review the normal “Evidence freshness” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M09.05-C088-T07 · At-limit measurement:** Exercise the “Evidence freshness” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M09.05-C088-T08 · Over-limit measurement:** Exercise the “Evidence freshness” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M09.05-C088-T09 · Uncovered-scope report:** List the “Evidence freshness” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M09.05-C088-T10 · Limit evidence:** Publish the selected “Evidence freshness” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M09.05-C089 · Diagnostics / review

**Original checklist item:** Record the rationale, unresolved assumptions, enforcement gaps and re-review triggers for evidence freshness; make design-only claims visibly distinct from observed behavior.

- [ ] **UC-M09.05-C089-T01 · Review inventory:** List the “Evidence freshness” decisions and claims requiring review; distinguish source requirements, implementation observations and engineering assumptions.
- [ ] **UC-M09.05-C089-T02 · Rationale record:** Write the rationale for the selected “Evidence freshness” representation or policy; link each choice to the requirement rather than an unexplained preference.
- [ ] **UC-M09.05-C089-T03 · Assumption ledger:** Record unresolved “Evidence freshness” assumptions, their owner and what observation or decision would resolve them; do not treat unknowns as approvals.
- [ ] **UC-M09.05-C089-T04 · Boundary map:** Map each “Evidence freshness” claim to an actual guard or explicit design/review gate; flag gaps against “Changed subjects invalidate the assurance evidence that depended on them”.
- [ ] **UC-M09.05-C089-T05 · Counterexample review:** Walk reviewers through the “Evidence freshness” counterexample “A new image reuses old isolation and semantic verdicts”; record whether the model detects it and whether any runtime guard was actually exercised.
- [ ] **UC-M09.05-C089-T06 · Review outcome vocabulary:** Define approved, blocked, superseded and untested review outcomes for “Evidence freshness”; ensure the wording cannot be read as runtime enforcement evidence.
- [ ] **UC-M09.05-C089-T07 · Re-review triggers:** List “Evidence freshness” invalidation triggers, including the source change scenario: one assurance class passes while another required class fails or becomes stale; identify the affected claims and evidence.
- [ ] **UC-M09.05-C089-T08 · Sensitive-data review:** Inspect the “Evidence freshness” review record for secrets and unrelated user content; retain nonsecret references sufficient for reproducibility.
- [ ] **UC-M09.05-C089-T09 · Independent reading:** Have the “Evidence freshness” record read against the original acceptance criterion and independent assurance verdicts and profile-specific release promotion rules; record misunderstandings or missing evidence as corrections.
- [ ] **UC-M09.05-C089-T10 · Review disposition:** Publish the “Evidence freshness” rationale, versioned review outcome, unresolved gaps and explicit next decision; keep blockers open until supported evidence resolves them.

### UC-M09.05-C090 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for evidence freshness; label unexecuted checks as untested.

- [ ] **UC-M09.05-C090-T01 · Evidence inventory:** List the “Evidence freshness” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M09.05-C090-T02 · Artifact references:** Record the exact “Evidence freshness” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M09.05-C090-T03 · Fixture references:** Attach the “Evidence freshness” fixture IDs, input identities and oracle definition; preserve the source counterexample “A new image reuses old isolation and semantic verdicts” as a distinct evidence case.
- [ ] **UC-M09.05-C090-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Evidence freshness”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M09.05-C090-T05 · Environment record:** Record the actual “Evidence freshness” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M09.05-C090-T06 · Expected versus observed:** Pair every “Evidence freshness” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M09.05-C090-T07 · Failure and limit records:** Attach “Evidence freshness” change/failure and bounds evidence where required; include uncovered “Evidence dependencies and invalidation time” and unresolved violations of “Changed subjects invalidate the assurance evidence that depended on them”.
- [ ] **UC-M09.05-C090-T08 · Evidence hygiene:** Check the “Evidence freshness” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M09.05-C090-T09 · Reproduction review:** Have the “Evidence freshness” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M09.05-C090-T10 · Acceptance linkage:** Link the “Evidence freshness” evidence to its parent and UC-M09.05 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 10. Assurance confusion tests

**Source delivery:** Create fixtures with deliberately mixed pass/fail assurance classes.

**Source invariant:** Promotion refuses every combination missing a required assurance class.

**Source negative case:** An authentic but semantically wrong image is promoted.

**Source bounded quantities:** Verdict combinations and acceptance fixtures.

### UC-M09.05-C091 · Contract

**Original checklist item:** Specify the scope and representation of assurance confusion tests; identify its producer, consumer, authority assumptions and explicitly unsupported cases.

- [ ] **UC-M09.05-C091-T01 · Scope statement:** Draft a scope note for “Assurance confusion tests” within Proof and digest assurance hierarchy; separate required model statements, explicit exclusions and unresolved design decisions.
- [ ] **UC-M09.05-C091-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Assurance confusion tests”; record each producer, representation and missing-value meaning.
- [ ] **UC-M09.05-C091-T03 · Output inventory:** List the outputs of “Assurance confusion tests” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M09.05-C091-T04 · Field dictionary:** Create a field-and-term dictionary for “Assurance confusion tests”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M09.05-C091-T05 · Prerequisite contract:** Map “Assurance confusion tests” to the source component prerequisites (UC-M01.07, UC-M04.04, UC-M06.05); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M09.05-C091-T06 · Authority map:** Identify who may produce, change and consume “Assurance confusion tests”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M09.05-C091-T07 · Invariant clause:** Add a normative clause for “Assurance confusion tests” that preserves “Promotion refuses every combination missing a required assurance class”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M09.05-C091-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Assurance confusion tests”; include the source counterexample “An authentic but semantically wrong image is promoted” and the intended safe disposition.
- [ ] **UC-M09.05-C091-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Verdict combinations and acceptance fixtures” in the “Assurance confusion tests” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M09.05-C091-T10 · Contract review:** Review the “Assurance confusion tests” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M09.05-C092 · Delivery

**Original checklist item:** Create fixtures with deliberately mixed pass/fail assurance classes.

- [ ] **UC-M09.05-C092-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Assurance confusion tests”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M09.05-C092-T02 · Change plan:** Break the source delivery for “Assurance confusion tests” into concrete edit targets and reviewable outputs; keep the UC-M09.05 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M09.05-C092-T03 · Core artifact:** Implement the smallest selected-profile change for “Assurance confusion tests” that realizes this source instruction: Create fixtures with deliberately mixed pass/fail assurance classes.
- [ ] **UC-M09.05-C092-T04 · Concrete realization:** Trace “Assurance confusion tests” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M09.05-C092-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Assurance confusion tests” needed to preserve “Promotion refuses every combination missing a required assurance class”; record an enforcement gap where only a model exists.
- [ ] **UC-M09.05-C092-T06 · Dependency connection:** Connect the “Assurance confusion tests” specification to independent assurance verdicts and profile-specific release promotion rules; record code coverage separately where the design is not yet enforced.
- [ ] **UC-M09.05-C092-T07 · Resource behavior:** Account for “Verdict combinations and acceptance fixtures” in “Assurance confusion tests”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M09.05-C092-T08 · Delivery check:** Walk the populated “Assurance confusion tests” model through a valid example and the source counterexample “An authentic but semantically wrong image is promoted”; record corrections and unresolved enforcement gaps.
- [ ] **UC-M09.05-C092-T09 · Patch review:** Review the “Assurance confusion tests” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M09.05-C092-T10 · Delivery handoff:** Publish the “Assurance confusion tests” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M09.05-C093 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Promotion refuses every combination missing a required assurance class. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M09.05-C093-T01 · Named property:** Create a stable property/check name under this parent for “Assurance confusion tests”; copy its required invariant exactly: “Promotion refuses every combination missing a required assurance class”.
- [ ] **UC-M09.05-C093-T02 · Observable terms:** Define each term in the “Assurance confusion tests” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M09.05-C093-T03 · Precondition set:** List the preconditions under which “Promotion refuses every combination missing a required assurance class” must hold for “Assurance confusion tests”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M09.05-C093-T04 · Transition coverage:** Map the “Assurance confusion tests” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M09.05-C093-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Assurance confusion tests”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M09.05-C093-T06 · Satisfying fixture:** Create a concrete “Assurance confusion tests” case that satisfies “Promotion refuses every combination missing a required assurance class”; record its expected observation before running the assertion or review.
- [ ] **UC-M09.05-C093-T07 · Violating fixture:** Create the source counterexample “An authentic but semantically wrong image is promoted” for “Assurance confusion tests”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M09.05-C093-T08 · Enforcement evidence:** Exercise the “Assurance confusion tests” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M09.05-C093-T09 · Regression linkage:** Link the “Assurance confusion tests” property to changes in independent assurance verdicts and profile-specific release promotion rules; record which dependency or contract changes require rerunning it.
- [ ] **UC-M09.05-C093-T10 · Property disposition:** Compare the satisfying and violating “Assurance confusion tests” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M09.05-C094 · Integration

**Original checklist item:** Integrate assurance confusion tests with independent assurance verdicts and profile-specific release promotion rules; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M09.05-C094-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Assurance confusion tests” across independent assurance verdicts and profile-specific release promotion rules; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M09.05-C094-T02 · Field mapping:** Map every “Assurance confusion tests” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M09.05-C094-T03 · Prerequisite identities:** Record the actual prerequisites for “Assurance confusion tests” (source dependency list: UC-M01.07, UC-M04.04, UC-M06.05); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M09.05-C094-T04 · Ownership agreement:** Specify who owns “Assurance confusion tests” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M09.05-C094-T05 · Handoff implementation:** Connect “Assurance confusion tests” through the mapped seam using the real adapter or explicit specification reference; preserve “Promotion refuses every combination missing a required assurance class” across the handoff.
- [ ] **UC-M09.05-C094-T06 · Absent-input case:** Omit one required “Assurance confusion tests” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M09.05-C094-T07 · Stale-input case:** Supply an outdated “Assurance confusion tests” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M09.05-C094-T08 · Incompatible-input case:** Supply an incompatible “Assurance confusion tests” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M09.05-C094-T09 · Valid integration trace:** Run a valid “Assurance confusion tests” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M09.05-C094-T10 · Seam review:** Reconcile the “Assurance confusion tests” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M09.05-C095 · Valid-case test

**Original checklist item:** Construct a valid worked example for assurance confusion tests; evaluate it against predeclared expected decisions and, where enforcement exists, run the corresponding conformance fixture.

- [ ] **UC-M09.05-C095-T01 · Valid fixture choice:** Select one concrete valid worked example for “Assurance confusion tests”; enumerate the model inputs and the expected review decision before evaluating it.
- [ ] **UC-M09.05-C095-T02 · Expected-result oracle:** Specify the “Assurance confusion tests” expected result independently of the implementation output; include the property “Promotion refuses every combination missing a required assurance class” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M09.05-C095-T03 · Fixture material:** Create the concrete “Assurance confusion tests” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M09.05-C095-T04 · Target preparation:** Prepare the “Assurance confusion tests” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M09.05-C095-T05 · Initial-state record:** Record the initial “Assurance confusion tests” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M09.05-C095-T06 · Valid-path execution:** Evaluate the “Assurance confusion tests” example against the reviewed model; where a runtime mechanism exists, run its corresponding fixture and label those observations separately.
- [ ] **UC-M09.05-C095-T07 · Outcome comparison:** Compare every declared “Assurance confusion tests” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M09.05-C095-T08 · State and bounds check:** Inspect the “Assurance confusion tests” ownership/state effects and actual use of “Verdict combinations and acceptance fixtures”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M09.05-C095-T09 · Repeatability check:** Repeat the same “Assurance confusion tests” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M09.05-C095-T10 · Positive evidence:** Attach the “Assurance confusion tests” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M09.05-C096 · Negative test

**Original checklist item:** Negative case: An authentic but semantically wrong image is promoted. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M09.05-C096-T01 · Adverse-case definition:** Create a test record for the exact “Assurance confusion tests” source counterexample: “An authentic but semantically wrong image is promoted”; state which precondition or invariant it challenges.
- [ ] **UC-M09.05-C096-T02 · Safe fixture boundary:** Define the contained test boundary for “Assurance confusion tests”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M09.05-C096-T03 · Valid control:** Construct a valid “Assurance confusion tests” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M09.05-C096-T04 · Minimal adverse input:** Derive the “Assurance confusion tests” adverse fixture from the control with the smallest documented change needed to reproduce “An authentic but semantically wrong image is promoted”; retain that change as reproducible data.
- [ ] **UC-M09.05-C096-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Assurance confusion tests”; require “Promotion refuses every combination missing a required assurance class” and forbid a false-success verdict.
- [ ] **UC-M09.05-C096-T06 · Adverse execution:** Evaluate the “Assurance confusion tests” adverse case through the actual review/contract gate; where implemented, also observe the runtime refusal and keep the two evidence classes separate.
- [ ] **UC-M09.05-C096-T07 · Effect inspection:** Inspect “Assurance confusion tests” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M09.05-C096-T08 · Refusal versus failure:** Confirm the “Assurance confusion tests” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M09.05-C096-T09 · Reset and retention:** Restore only the disposable “Assurance confusion tests” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M09.05-C096-T10 · Negative regression:** Register the “Assurance confusion tests” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M09.05-C097 · Change / failure test

**Original checklist item:** Exercise assurance confusion tests when one assurance class passes while another required class fails or becomes stale; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M09.05-C097-T01 · Scenario record:** Write the “Assurance confusion tests” change/failure scenario exactly as supplied: one assurance class passes while another required class fails or becomes stale; identify the property that must remain true: “Promotion refuses every combination missing a required assurance class”.
- [ ] **UC-M09.05-C097-T02 · Baseline capture:** Create a known-valid “Assurance confusion tests” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M09.05-C097-T03 · Injection map:** Locate the “Assurance confusion tests” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M09.05-C097-T04 · Disposition oracle:** Define the legal intermediate and final “Assurance confusion tests” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M09.05-C097-T05 · Controlled trigger:** Apply the controlled model-change scenario for “Assurance confusion tests”: one assurance class passes while another required class fails or becomes stale; retain the exact before/after declarations. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M09.05-C097-T06 · Intermediate inspection:** Review which “Assurance confusion tests” claims, approvals and evidence references become stale after the change; keep unresolved enforcement gaps visible.
- [ ] **UC-M09.05-C097-T07 · Recovery path:** Revise or explicitly refuse the changed “Assurance confusion tests” model under the documented compatibility policy; re-review affected claims before restoring their approval.
- [ ] **UC-M09.05-C097-T08 · Stale-evidence cleanup:** Invalidate superseded “Assurance confusion tests” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M09.05-C097-T09 · Repeat and compare:** Repeat the selected “Assurance confusion tests” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M09.05-C097-T10 · Failure evidence:** Publish the “Assurance confusion tests” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M09.05-C098 · Bounds

**Original checklist item:** Define completeness and scaling criteria for verdict combinations and acceptance fixtures; exercise larger inventories or fixture sets, and report uncovered scope instead of silently excluding it.

- [ ] **UC-M09.05-C098-T01 · Quantity inventory:** Create a measurement inventory for “Assurance confusion tests”: “Verdict combinations and acceptance fixtures”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M09.05-C098-T02 · Measurement method:** Choose how to observe each “Assurance confusion tests” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M09.05-C098-T03 · Budget decision:** Select justified coverage and completeness limits for “Assurance confusion tests”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M09.05-C098-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Assurance confusion tests” cases for “Verdict combinations and acceptance fixtures”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M09.05-C098-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Assurance confusion tests” limit; preserve “Promotion refuses every combination missing a required assurance class”.
- [ ] **UC-M09.05-C098-T06 · Normal measurement:** Run or review the normal “Assurance confusion tests” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M09.05-C098-T07 · At-limit measurement:** Exercise the “Assurance confusion tests” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M09.05-C098-T08 · Over-limit measurement:** Exercise the “Assurance confusion tests” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M09.05-C098-T09 · Uncovered-scope report:** List the “Assurance confusion tests” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M09.05-C098-T10 · Limit evidence:** Publish the selected “Assurance confusion tests” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M09.05-C099 · Diagnostics / review

**Original checklist item:** Record the rationale, unresolved assumptions, enforcement gaps and re-review triggers for assurance confusion tests; make design-only claims visibly distinct from observed behavior.

- [ ] **UC-M09.05-C099-T01 · Review inventory:** List the “Assurance confusion tests” decisions and claims requiring review; distinguish source requirements, implementation observations and engineering assumptions.
- [ ] **UC-M09.05-C099-T02 · Rationale record:** Write the rationale for the selected “Assurance confusion tests” representation or policy; link each choice to the requirement rather than an unexplained preference.
- [ ] **UC-M09.05-C099-T03 · Assumption ledger:** Record unresolved “Assurance confusion tests” assumptions, their owner and what observation or decision would resolve them; do not treat unknowns as approvals.
- [ ] **UC-M09.05-C099-T04 · Boundary map:** Map each “Assurance confusion tests” claim to an actual guard or explicit design/review gate; flag gaps against “Promotion refuses every combination missing a required assurance class”.
- [ ] **UC-M09.05-C099-T05 · Counterexample review:** Walk reviewers through the “Assurance confusion tests” counterexample “An authentic but semantically wrong image is promoted”; record whether the model detects it and whether any runtime guard was actually exercised.
- [ ] **UC-M09.05-C099-T06 · Review outcome vocabulary:** Define approved, blocked, superseded and untested review outcomes for “Assurance confusion tests”; ensure the wording cannot be read as runtime enforcement evidence.
- [ ] **UC-M09.05-C099-T07 · Re-review triggers:** List “Assurance confusion tests” invalidation triggers, including the source change scenario: one assurance class passes while another required class fails or becomes stale; identify the affected claims and evidence.
- [ ] **UC-M09.05-C099-T08 · Sensitive-data review:** Inspect the “Assurance confusion tests” review record for secrets and unrelated user content; retain nonsecret references sufficient for reproducibility.
- [ ] **UC-M09.05-C099-T09 · Independent reading:** Have the “Assurance confusion tests” record read against the original acceptance criterion and independent assurance verdicts and profile-specific release promotion rules; record misunderstandings or missing evidence as corrections.
- [ ] **UC-M09.05-C099-T10 · Review disposition:** Publish the “Assurance confusion tests” rationale, versioned review outcome, unresolved gaps and explicit next decision; keep blockers open until supported evidence resolves them.

### UC-M09.05-C100 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for assurance confusion tests; label unexecuted checks as untested.

- [ ] **UC-M09.05-C100-T01 · Evidence inventory:** List the “Assurance confusion tests” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M09.05-C100-T02 · Artifact references:** Record the exact “Assurance confusion tests” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M09.05-C100-T03 · Fixture references:** Attach the “Assurance confusion tests” fixture IDs, input identities and oracle definition; preserve the source counterexample “An authentic but semantically wrong image is promoted” as a distinct evidence case.
- [ ] **UC-M09.05-C100-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Assurance confusion tests”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M09.05-C100-T05 · Environment record:** Record the actual “Assurance confusion tests” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M09.05-C100-T06 · Expected versus observed:** Pair every “Assurance confusion tests” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M09.05-C100-T07 · Failure and limit records:** Attach “Assurance confusion tests” change/failure and bounds evidence where required; include uncovered “Verdict combinations and acceptance fixtures” and unresolved violations of “Promotion refuses every combination missing a required assurance class”.
- [ ] **UC-M09.05-C100-T08 · Evidence hygiene:** Check the “Assurance confusion tests” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M09.05-C100-T09 · Reproduction review:** Have the “Assurance confusion tests” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M09.05-C100-T10 · Acceptance linkage:** Link the “Assurance confusion tests” evidence to its parent and UC-M09.05 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

