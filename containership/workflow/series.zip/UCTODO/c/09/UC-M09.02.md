# UC-M09.02 — Anti-rollback update metadata

**To-Do Pack 2.0.0 · Baseline UC-2.2.0 · 100 parent checks × 10 subtasks = 1,000 to-dos**

[Master index](../../INDEX.md) · [Workstream index](../../w/09.md)

| Field | Preserved source value |
|---|---|
| Workstream | 09. Trust, integrity and adversarial security |
| Milestone | C |
| Priority | P0 |
| Source assessment | MISSING |
| Scope | core or selected profile |
| Dependencies | [UC-M09.01](../09/UC-M09.01.md) |
| Source checklist pack | 1.0.0 |
| Original reference labels | [S4], [S7], [S8]. |

## Original requirement

Use authenticated versioned update metadata and a trustworthy expiry/version policy suitable for offline distribution.

**Original acceptance criterion:** Older, expired or inconsistent metadata cannot silently replace a newer approved release.

**Source trace:** Original checklist `UC100/c/09/UC-M09.02.md` inside [s/checklists.zip](../../s/checklists.zip); exact parent records in [data/parents.jsonl](../../data/parents.jsonl). Original roadmap lines 820–830 are preserved in [s/roadmap.md](../../s/roadmap.md).

## How to use these lists

Every parent statement below is preserved verbatim. Its ten child tasks are proposed decomposition, not implemented capabilities or executed tests. Child IDs append `-T01` through `-T10` to the original parent ID. All begin unchecked / `TODO`. Design/review evidence does not establish runtime enforcement; observe the actual selected target where the parent requires it.

The source dependency graph and selected release profile determine applicability. The numbered child sequence is a local working order, not an added hard dependency graph. An unselected optional feature needs a recorded not-applicable rationale; missing prerequisites for selected work remain blockers. Numerical budgets, backends and trust mechanisms remain decisions unless fixed by the source. Test hostile cases only with synthetic inputs in authorized disposable environments.

## 01. Update metadata roles

**Source delivery:** Define authenticated metadata roles and the relationships they authorize.

**Source invariant:** An update artifact cannot define its own trusted authority.

**Source negative case:** A payload includes self-declared root metadata that is auto-enrolled.

**Source bounded quantities:** Role count and metadata bytes.

### UC-M09.02-C001 · Contract

**Original checklist item:** Specify update metadata roles inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M09.02-C001-T01 · Scope statement:** Draft the operation boundary for “Update metadata roles” within Anti-rollback update metadata; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M09.02-C001-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Update metadata roles”; record each producer, representation and missing-value meaning.
- [ ] **UC-M09.02-C001-T03 · Output inventory:** List the outputs of “Update metadata roles” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M09.02-C001-T04 · Field dictionary:** Create a field-and-term dictionary for “Update metadata roles”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M09.02-C001-T05 · Prerequisite contract:** Map “Update metadata roles” to the source component prerequisites (UC-M09.01); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M09.02-C001-T06 · Authority map:** Identify who may produce, change and consume “Update metadata roles”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M09.02-C001-T07 · Invariant clause:** Add a normative clause for “Update metadata roles” that preserves “An update artifact cannot define its own trusted authority”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M09.02-C001-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Update metadata roles”; include the source counterexample “A payload includes self-declared root metadata that is auto-enrolled” and the intended safe disposition.
- [ ] **UC-M09.02-C001-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Role count and metadata bytes” in the “Update metadata roles” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M09.02-C001-T10 · Contract review:** Review the “Update metadata roles” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M09.02-C002 · Delivery

**Original checklist item:** Define authenticated metadata roles and the relationships they authorize.

- [ ] **UC-M09.02-C002-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Update metadata roles”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M09.02-C002-T02 · Change plan:** Break the source delivery for “Update metadata roles” into concrete edit targets and reviewable outputs; keep the UC-M09.02 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M09.02-C002-T03 · Core artifact:** Create the “Update metadata roles” model, schema or inventory that realizes this source instruction: Define authenticated metadata roles and the relationships they authorize.
- [ ] **UC-M09.02-C002-T04 · Concrete realization:** Populate “Update metadata roles” with one concrete worked case; map every required entity or field to its source and flag any unmapped entry.
- [ ] **UC-M09.02-C002-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Update metadata roles” needed to preserve “An update artifact cannot define its own trusted authority”; record an enforcement gap where only a model exists.
- [ ] **UC-M09.02-C002-T06 · Dependency connection:** Connect the “Update metadata roles” implementation to authenticated update metadata, persisted approved versions and installer staging; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M09.02-C002-T07 · Resource behavior:** Account for “Role count and metadata bytes” in “Update metadata roles”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M09.02-C002-T08 · Delivery check:** Run the smallest real “Update metadata roles” path and its adverse fixture “A payload includes self-declared root metadata that is auto-enrolled”; retain actual output, state effects and final disposition.
- [ ] **UC-M09.02-C002-T09 · Patch review:** Review the “Update metadata roles” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M09.02-C002-T10 · Delivery handoff:** Publish the “Update metadata roles” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M09.02-C003 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: An update artifact cannot define its own trusted authority. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M09.02-C003-T01 · Named property:** Create a stable property/check name under this parent for “Update metadata roles”; copy its required invariant exactly: “An update artifact cannot define its own trusted authority”.
- [ ] **UC-M09.02-C003-T02 · Observable terms:** Define each term in the “Update metadata roles” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M09.02-C003-T03 · Precondition set:** List the preconditions under which “An update artifact cannot define its own trusted authority” must hold for “Update metadata roles”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M09.02-C003-T04 · Transition coverage:** Map the “Update metadata roles” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M09.02-C003-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Update metadata roles”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M09.02-C003-T06 · Satisfying fixture:** Create a concrete “Update metadata roles” case that satisfies “An update artifact cannot define its own trusted authority”; record its expected observation before running the assertion or review.
- [ ] **UC-M09.02-C003-T07 · Violating fixture:** Create the source counterexample “A payload includes self-declared root metadata that is auto-enrolled” for “Update metadata roles”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M09.02-C003-T08 · Enforcement evidence:** Exercise the “Update metadata roles” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M09.02-C003-T09 · Regression linkage:** Link the “Update metadata roles” property to changes in authenticated update metadata, persisted approved versions and installer staging; record which dependency or contract changes require rerunning it.
- [ ] **UC-M09.02-C003-T10 · Property disposition:** Compare the satisfying and violating “Update metadata roles” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M09.02-C004 · Integration

**Original checklist item:** Integrate update metadata roles with authenticated update metadata, persisted approved versions and installer staging; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M09.02-C004-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Update metadata roles” across authenticated update metadata, persisted approved versions and installer staging; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M09.02-C004-T02 · Field mapping:** Map every “Update metadata roles” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M09.02-C004-T03 · Prerequisite identities:** Record the actual prerequisites for “Update metadata roles” (source dependency list: UC-M09.01); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M09.02-C004-T04 · Ownership agreement:** Specify who owns “Update metadata roles” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M09.02-C004-T05 · Handoff implementation:** Connect “Update metadata roles” through the mapped seam using the real adapter or explicit specification reference; preserve “An update artifact cannot define its own trusted authority” across the handoff.
- [ ] **UC-M09.02-C004-T06 · Absent-input case:** Omit one required “Update metadata roles” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M09.02-C004-T07 · Stale-input case:** Supply an outdated “Update metadata roles” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M09.02-C004-T08 · Incompatible-input case:** Supply an incompatible “Update metadata roles” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M09.02-C004-T09 · Valid integration trace:** Run a valid “Update metadata roles” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M09.02-C004-T10 · Seam review:** Reconcile the “Update metadata roles” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M09.02-C005 · Valid-case test

**Original checklist item:** Run a valid-path fixture for update metadata roles; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M09.02-C005-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Update metadata roles” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M09.02-C005-T02 · Expected-result oracle:** Specify the “Update metadata roles” expected result independently of the implementation output; include the property “An update artifact cannot define its own trusted authority” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M09.02-C005-T03 · Fixture material:** Create the concrete “Update metadata roles” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M09.02-C005-T04 · Target preparation:** Prepare the “Update metadata roles” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M09.02-C005-T05 · Initial-state record:** Record the initial “Update metadata roles” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M09.02-C005-T06 · Valid-path execution:** Execute the “Update metadata roles” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M09.02-C005-T07 · Outcome comparison:** Compare every declared “Update metadata roles” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M09.02-C005-T08 · State and bounds check:** Inspect the “Update metadata roles” ownership/state effects and actual use of “Role count and metadata bytes”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M09.02-C005-T09 · Repeatability check:** Repeat the same “Update metadata roles” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M09.02-C005-T10 · Positive evidence:** Attach the “Update metadata roles” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M09.02-C006 · Negative test

**Original checklist item:** Negative case: A payload includes self-declared root metadata that is auto-enrolled. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M09.02-C006-T01 · Adverse-case definition:** Create a test record for the exact “Update metadata roles” source counterexample: “A payload includes self-declared root metadata that is auto-enrolled”; state which precondition or invariant it challenges.
- [ ] **UC-M09.02-C006-T02 · Safe fixture boundary:** Define the contained test boundary for “Update metadata roles”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M09.02-C006-T03 · Valid control:** Construct a valid “Update metadata roles” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M09.02-C006-T04 · Minimal adverse input:** Derive the “Update metadata roles” adverse fixture from the control with the smallest documented change needed to reproduce “A payload includes self-declared root metadata that is auto-enrolled”; retain that change as reproducible data.
- [ ] **UC-M09.02-C006-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Update metadata roles”; require “An update artifact cannot define its own trusted authority” and forbid a false-success verdict.
- [ ] **UC-M09.02-C006-T06 · Adverse execution:** Exercise the “Update metadata roles” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M09.02-C006-T07 · Effect inspection:** Inspect “Update metadata roles” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M09.02-C006-T08 · Refusal versus failure:** Confirm the “Update metadata roles” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M09.02-C006-T09 · Reset and retention:** Restore only the disposable “Update metadata roles” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M09.02-C006-T10 · Negative regression:** Register the “Update metadata roles” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M09.02-C007 · Change / failure test

**Original checklist item:** Exercise update metadata roles when an offline update is interrupted and then retried with older signed metadata; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M09.02-C007-T01 · Scenario record:** Write the “Update metadata roles” change/failure scenario exactly as supplied: an offline update is interrupted and then retried with older signed metadata; identify the property that must remain true: “An update artifact cannot define its own trusted authority”.
- [ ] **UC-M09.02-C007-T02 · Baseline capture:** Create a known-valid “Update metadata roles” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M09.02-C007-T03 · Injection map:** Locate the “Update metadata roles” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M09.02-C007-T04 · Disposition oracle:** Define the legal intermediate and final “Update metadata roles” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M09.02-C007-T05 · Controlled trigger:** Introduce the controlled “Update metadata roles” scenario in the disposable fixture: an offline update is interrupted and then retried with older signed metadata; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M09.02-C007-T06 · Intermediate inspection:** Inspect the “Update metadata roles” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M09.02-C007-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Update metadata roles”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M09.02-C007-T08 · Stale-evidence cleanup:** Invalidate superseded “Update metadata roles” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M09.02-C007-T09 · Repeat and compare:** Repeat the selected “Update metadata roles” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M09.02-C007-T10 · Failure evidence:** Publish the “Update metadata roles” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M09.02-C008 · Bounds

**Original checklist item:** Choose, document and test limits for role count and metadata bytes; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M09.02-C008-T01 · Quantity inventory:** Create a measurement inventory for “Update metadata roles”: “Role count and metadata bytes”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M09.02-C008-T02 · Measurement method:** Choose how to observe each “Update metadata roles” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M09.02-C008-T03 · Budget decision:** Select justified resource and input limits for “Update metadata roles”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M09.02-C008-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Update metadata roles” cases for “Role count and metadata bytes”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M09.02-C008-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Update metadata roles” limit; preserve “An update artifact cannot define its own trusted authority”.
- [ ] **UC-M09.02-C008-T06 · Normal measurement:** Run or review the normal “Update metadata roles” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M09.02-C008-T07 · At-limit measurement:** Exercise the “Update metadata roles” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M09.02-C008-T08 · Over-limit measurement:** Exercise the “Update metadata roles” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M09.02-C008-T09 · Uncovered-scope report:** List the “Update metadata roles” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M09.02-C008-T10 · Limit evidence:** Publish the selected “Update metadata roles” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M09.02-C009 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for update metadata roles with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M09.02-C009-T01 · Event inventory:** List the “Update metadata roles” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M09.02-C009-T02 · Diagnostic schema:** Define nonsecret fields for “Update metadata roles” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M09.02-C009-T03 · Failure mapping:** Map each documented “Update metadata roles” refusal or error to a diagnostic outcome; include “A payload includes self-declared root metadata that is auto-enrolled” and prohibit conversion into a success message.
- [ ] **UC-M09.02-C009-T04 · Emission path:** Add the “Update metadata roles” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M09.02-C009-T05 · Redaction check:** Test “Update metadata roles” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M09.02-C009-T06 · Output budget:** Set and exercise bounded “Update metadata roles” message size, rate and retention compatible with “Role count and metadata bytes”; define truncation behavior that preserves the final reason.
- [ ] **UC-M09.02-C009-T07 · Success/refusal fixtures:** Capture “Update metadata roles” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M09.02-C009-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Update metadata roles” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M09.02-C009-T09 · Operator review:** Read the “Update metadata roles” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M09.02-C009-T10 · Diagnostic evidence:** Publish redacted “Update metadata roles” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M09.02-C010 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for update metadata roles; label unexecuted checks as untested.

- [ ] **UC-M09.02-C010-T01 · Evidence inventory:** List the “Update metadata roles” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M09.02-C010-T02 · Artifact references:** Record the exact “Update metadata roles” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M09.02-C010-T03 · Fixture references:** Attach the “Update metadata roles” fixture IDs, input identities and oracle definition; preserve the source counterexample “A payload includes self-declared root metadata that is auto-enrolled” as a distinct evidence case.
- [ ] **UC-M09.02-C010-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Update metadata roles”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M09.02-C010-T05 · Environment record:** Record the actual “Update metadata roles” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M09.02-C010-T06 · Expected versus observed:** Pair every “Update metadata roles” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M09.02-C010-T07 · Failure and limit records:** Attach “Update metadata roles” change/failure and bounds evidence where required; include uncovered “Role count and metadata bytes” and unresolved violations of “An update artifact cannot define its own trusted authority”.
- [ ] **UC-M09.02-C010-T08 · Evidence hygiene:** Check the “Update metadata roles” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M09.02-C010-T09 · Reproduction review:** Have the “Update metadata roles” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M09.02-C010-T10 · Acceptance linkage:** Link the “Update metadata roles” evidence to its parent and UC-M09.02 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 02. Version monotonicity

**Source delivery:** Track approved metadata versions and enforce the selected rollback policy.

**Source invariant:** Older metadata cannot silently replace newer approved metadata.

**Source negative case:** An attacker replays a correctly signed but older release manifest.

**Source bounded quantities:** Version history and comparison cost.

### UC-M09.02-C011 · Contract

**Original checklist item:** Specify version monotonicity inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M09.02-C011-T01 · Scope statement:** Draft the operation boundary for “Version monotonicity” within Anti-rollback update metadata; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M09.02-C011-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Version monotonicity”; record each producer, representation and missing-value meaning.
- [ ] **UC-M09.02-C011-T03 · Output inventory:** List the outputs of “Version monotonicity” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M09.02-C011-T04 · Field dictionary:** Create a field-and-term dictionary for “Version monotonicity”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M09.02-C011-T05 · Prerequisite contract:** Map “Version monotonicity” to the source component prerequisites (UC-M09.01); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M09.02-C011-T06 · Authority map:** Identify who may produce, change and consume “Version monotonicity”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M09.02-C011-T07 · Invariant clause:** Add a normative clause for “Version monotonicity” that preserves “Older metadata cannot silently replace newer approved metadata”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M09.02-C011-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Version monotonicity”; include the source counterexample “An attacker replays a correctly signed but older release manifest” and the intended safe disposition.
- [ ] **UC-M09.02-C011-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Version history and comparison cost” in the “Version monotonicity” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M09.02-C011-T10 · Contract review:** Review the “Version monotonicity” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M09.02-C012 · Delivery

**Original checklist item:** Track approved metadata versions and enforce the selected rollback policy.

- [ ] **UC-M09.02-C012-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Version monotonicity”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M09.02-C012-T02 · Change plan:** Break the source delivery for “Version monotonicity” into concrete edit targets and reviewable outputs; keep the UC-M09.02 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M09.02-C012-T03 · Core artifact:** Implement the smallest selected-profile change for “Version monotonicity” that realizes this source instruction: Track approved metadata versions and enforce the selected rollback policy.
- [ ] **UC-M09.02-C012-T04 · Concrete realization:** Trace “Version monotonicity” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M09.02-C012-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Version monotonicity” needed to preserve “Older metadata cannot silently replace newer approved metadata”; record an enforcement gap where only a model exists.
- [ ] **UC-M09.02-C012-T06 · Dependency connection:** Connect the “Version monotonicity” implementation to authenticated update metadata, persisted approved versions and installer staging; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M09.02-C012-T07 · Resource behavior:** Account for “Version history and comparison cost” in “Version monotonicity”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M09.02-C012-T08 · Delivery check:** Run the smallest real “Version monotonicity” path and its adverse fixture “An attacker replays a correctly signed but older release manifest”; retain actual output, state effects and final disposition.
- [ ] **UC-M09.02-C012-T09 · Patch review:** Review the “Version monotonicity” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M09.02-C012-T10 · Delivery handoff:** Publish the “Version monotonicity” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M09.02-C013 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Older metadata cannot silently replace newer approved metadata. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M09.02-C013-T01 · Named property:** Create a stable property/check name under this parent for “Version monotonicity”; copy its required invariant exactly: “Older metadata cannot silently replace newer approved metadata”.
- [ ] **UC-M09.02-C013-T02 · Observable terms:** Define each term in the “Version monotonicity” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M09.02-C013-T03 · Precondition set:** List the preconditions under which “Older metadata cannot silently replace newer approved metadata” must hold for “Version monotonicity”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M09.02-C013-T04 · Transition coverage:** Map the “Version monotonicity” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M09.02-C013-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Version monotonicity”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M09.02-C013-T06 · Satisfying fixture:** Create a concrete “Version monotonicity” case that satisfies “Older metadata cannot silently replace newer approved metadata”; record its expected observation before running the assertion or review.
- [ ] **UC-M09.02-C013-T07 · Violating fixture:** Create the source counterexample “An attacker replays a correctly signed but older release manifest” for “Version monotonicity”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M09.02-C013-T08 · Enforcement evidence:** Exercise the “Version monotonicity” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M09.02-C013-T09 · Regression linkage:** Link the “Version monotonicity” property to changes in authenticated update metadata, persisted approved versions and installer staging; record which dependency or contract changes require rerunning it.
- [ ] **UC-M09.02-C013-T10 · Property disposition:** Compare the satisfying and violating “Version monotonicity” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M09.02-C014 · Integration

**Original checklist item:** Integrate version monotonicity with authenticated update metadata, persisted approved versions and installer staging; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M09.02-C014-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Version monotonicity” across authenticated update metadata, persisted approved versions and installer staging; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M09.02-C014-T02 · Field mapping:** Map every “Version monotonicity” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M09.02-C014-T03 · Prerequisite identities:** Record the actual prerequisites for “Version monotonicity” (source dependency list: UC-M09.01); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M09.02-C014-T04 · Ownership agreement:** Specify who owns “Version monotonicity” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M09.02-C014-T05 · Handoff implementation:** Connect “Version monotonicity” through the mapped seam using the real adapter or explicit specification reference; preserve “Older metadata cannot silently replace newer approved metadata” across the handoff.
- [ ] **UC-M09.02-C014-T06 · Absent-input case:** Omit one required “Version monotonicity” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M09.02-C014-T07 · Stale-input case:** Supply an outdated “Version monotonicity” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M09.02-C014-T08 · Incompatible-input case:** Supply an incompatible “Version monotonicity” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M09.02-C014-T09 · Valid integration trace:** Run a valid “Version monotonicity” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M09.02-C014-T10 · Seam review:** Reconcile the “Version monotonicity” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M09.02-C015 · Valid-case test

**Original checklist item:** Run a valid-path fixture for version monotonicity; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M09.02-C015-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Version monotonicity” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M09.02-C015-T02 · Expected-result oracle:** Specify the “Version monotonicity” expected result independently of the implementation output; include the property “Older metadata cannot silently replace newer approved metadata” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M09.02-C015-T03 · Fixture material:** Create the concrete “Version monotonicity” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M09.02-C015-T04 · Target preparation:** Prepare the “Version monotonicity” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M09.02-C015-T05 · Initial-state record:** Record the initial “Version monotonicity” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M09.02-C015-T06 · Valid-path execution:** Execute the “Version monotonicity” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M09.02-C015-T07 · Outcome comparison:** Compare every declared “Version monotonicity” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M09.02-C015-T08 · State and bounds check:** Inspect the “Version monotonicity” ownership/state effects and actual use of “Version history and comparison cost”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M09.02-C015-T09 · Repeatability check:** Repeat the same “Version monotonicity” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M09.02-C015-T10 · Positive evidence:** Attach the “Version monotonicity” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M09.02-C016 · Negative test

**Original checklist item:** Negative case: An attacker replays a correctly signed but older release manifest. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M09.02-C016-T01 · Adverse-case definition:** Create a test record for the exact “Version monotonicity” source counterexample: “An attacker replays a correctly signed but older release manifest”; state which precondition or invariant it challenges.
- [ ] **UC-M09.02-C016-T02 · Safe fixture boundary:** Define the contained test boundary for “Version monotonicity”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M09.02-C016-T03 · Valid control:** Construct a valid “Version monotonicity” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M09.02-C016-T04 · Minimal adverse input:** Derive the “Version monotonicity” adverse fixture from the control with the smallest documented change needed to reproduce “An attacker replays a correctly signed but older release manifest”; retain that change as reproducible data.
- [ ] **UC-M09.02-C016-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Version monotonicity”; require “Older metadata cannot silently replace newer approved metadata” and forbid a false-success verdict.
- [ ] **UC-M09.02-C016-T06 · Adverse execution:** Exercise the “Version monotonicity” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M09.02-C016-T07 · Effect inspection:** Inspect “Version monotonicity” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M09.02-C016-T08 · Refusal versus failure:** Confirm the “Version monotonicity” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M09.02-C016-T09 · Reset and retention:** Restore only the disposable “Version monotonicity” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M09.02-C016-T10 · Negative regression:** Register the “Version monotonicity” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M09.02-C017 · Change / failure test

**Original checklist item:** Exercise version monotonicity when an offline update is interrupted and then retried with older signed metadata; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M09.02-C017-T01 · Scenario record:** Write the “Version monotonicity” change/failure scenario exactly as supplied: an offline update is interrupted and then retried with older signed metadata; identify the property that must remain true: “Older metadata cannot silently replace newer approved metadata”.
- [ ] **UC-M09.02-C017-T02 · Baseline capture:** Create a known-valid “Version monotonicity” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M09.02-C017-T03 · Injection map:** Locate the “Version monotonicity” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M09.02-C017-T04 · Disposition oracle:** Define the legal intermediate and final “Version monotonicity” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M09.02-C017-T05 · Controlled trigger:** Introduce the controlled “Version monotonicity” scenario in the disposable fixture: an offline update is interrupted and then retried with older signed metadata; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M09.02-C017-T06 · Intermediate inspection:** Inspect the “Version monotonicity” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M09.02-C017-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Version monotonicity”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M09.02-C017-T08 · Stale-evidence cleanup:** Invalidate superseded “Version monotonicity” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M09.02-C017-T09 · Repeat and compare:** Repeat the selected “Version monotonicity” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M09.02-C017-T10 · Failure evidence:** Publish the “Version monotonicity” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M09.02-C018 · Bounds

**Original checklist item:** Choose, document and test limits for version history and comparison cost; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M09.02-C018-T01 · Quantity inventory:** Create a measurement inventory for “Version monotonicity”: “Version history and comparison cost”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M09.02-C018-T02 · Measurement method:** Choose how to observe each “Version monotonicity” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M09.02-C018-T03 · Budget decision:** Select justified resource and input limits for “Version monotonicity”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M09.02-C018-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Version monotonicity” cases for “Version history and comparison cost”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M09.02-C018-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Version monotonicity” limit; preserve “Older metadata cannot silently replace newer approved metadata”.
- [ ] **UC-M09.02-C018-T06 · Normal measurement:** Run or review the normal “Version monotonicity” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M09.02-C018-T07 · At-limit measurement:** Exercise the “Version monotonicity” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M09.02-C018-T08 · Over-limit measurement:** Exercise the “Version monotonicity” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M09.02-C018-T09 · Uncovered-scope report:** List the “Version monotonicity” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M09.02-C018-T10 · Limit evidence:** Publish the selected “Version monotonicity” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M09.02-C019 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for version monotonicity with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M09.02-C019-T01 · Event inventory:** List the “Version monotonicity” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M09.02-C019-T02 · Diagnostic schema:** Define nonsecret fields for “Version monotonicity” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M09.02-C019-T03 · Failure mapping:** Map each documented “Version monotonicity” refusal or error to a diagnostic outcome; include “An attacker replays a correctly signed but older release manifest” and prohibit conversion into a success message.
- [ ] **UC-M09.02-C019-T04 · Emission path:** Add the “Version monotonicity” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M09.02-C019-T05 · Redaction check:** Test “Version monotonicity” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M09.02-C019-T06 · Output budget:** Set and exercise bounded “Version monotonicity” message size, rate and retention compatible with “Version history and comparison cost”; define truncation behavior that preserves the final reason.
- [ ] **UC-M09.02-C019-T07 · Success/refusal fixtures:** Capture “Version monotonicity” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M09.02-C019-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Version monotonicity” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M09.02-C019-T09 · Operator review:** Read the “Version monotonicity” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M09.02-C019-T10 · Diagnostic evidence:** Publish redacted “Version monotonicity” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M09.02-C020 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for version monotonicity; label unexecuted checks as untested.

- [ ] **UC-M09.02-C020-T01 · Evidence inventory:** List the “Version monotonicity” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M09.02-C020-T02 · Artifact references:** Record the exact “Version monotonicity” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M09.02-C020-T03 · Fixture references:** Attach the “Version monotonicity” fixture IDs, input identities and oracle definition; preserve the source counterexample “An attacker replays a correctly signed but older release manifest” as a distinct evidence case.
- [ ] **UC-M09.02-C020-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Version monotonicity”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M09.02-C020-T05 · Environment record:** Record the actual “Version monotonicity” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M09.02-C020-T06 · Expected versus observed:** Pair every “Version monotonicity” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M09.02-C020-T07 · Failure and limit records:** Attach “Version monotonicity” change/failure and bounds evidence where required; include uncovered “Version history and comparison cost” and unresolved violations of “Older metadata cannot silently replace newer approved metadata”.
- [ ] **UC-M09.02-C020-T08 · Evidence hygiene:** Check the “Version monotonicity” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M09.02-C020-T09 · Reproduction review:** Have the “Version monotonicity” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M09.02-C020-T10 · Acceptance linkage:** Link the “Version monotonicity” evidence to its parent and UC-M09.02 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 03. Expiry semantics

**Source delivery:** Define trusted expiry evaluation suitable for connected and offline profiles.

**Source invariant:** Expired metadata is not silently accepted as current.

**Source negative case:** An expired update package is installed without an explicit authorized exception.

**Source bounded quantities:** Validity periods and clock uncertainty policy.

### UC-M09.02-C021 · Contract

**Original checklist item:** Specify expiry semantics inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M09.02-C021-T01 · Scope statement:** Draft the operation boundary for “Expiry semantics” within Anti-rollback update metadata; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M09.02-C021-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Expiry semantics”; record each producer, representation and missing-value meaning.
- [ ] **UC-M09.02-C021-T03 · Output inventory:** List the outputs of “Expiry semantics” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M09.02-C021-T04 · Field dictionary:** Create a field-and-term dictionary for “Expiry semantics”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M09.02-C021-T05 · Prerequisite contract:** Map “Expiry semantics” to the source component prerequisites (UC-M09.01); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M09.02-C021-T06 · Authority map:** Identify who may produce, change and consume “Expiry semantics”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M09.02-C021-T07 · Invariant clause:** Add a normative clause for “Expiry semantics” that preserves “Expired metadata is not silently accepted as current”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M09.02-C021-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Expiry semantics”; include the source counterexample “An expired update package is installed without an explicit authorized exception” and the intended safe disposition.
- [ ] **UC-M09.02-C021-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Validity periods and clock uncertainty policy” in the “Expiry semantics” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M09.02-C021-T10 · Contract review:** Review the “Expiry semantics” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M09.02-C022 · Delivery

**Original checklist item:** Define trusted expiry evaluation suitable for connected and offline profiles.

- [ ] **UC-M09.02-C022-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Expiry semantics”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M09.02-C022-T02 · Change plan:** Break the source delivery for “Expiry semantics” into concrete edit targets and reviewable outputs; keep the UC-M09.02 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M09.02-C022-T03 · Core artifact:** Create the “Expiry semantics” model, schema or inventory that realizes this source instruction: Define trusted expiry evaluation suitable for connected and offline profiles.
- [ ] **UC-M09.02-C022-T04 · Concrete realization:** Populate “Expiry semantics” with one concrete worked case; map every required entity or field to its source and flag any unmapped entry.
- [ ] **UC-M09.02-C022-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Expiry semantics” needed to preserve “Expired metadata is not silently accepted as current”; record an enforcement gap where only a model exists.
- [ ] **UC-M09.02-C022-T06 · Dependency connection:** Connect the “Expiry semantics” implementation to authenticated update metadata, persisted approved versions and installer staging; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M09.02-C022-T07 · Resource behavior:** Account for “Validity periods and clock uncertainty policy” in “Expiry semantics”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M09.02-C022-T08 · Delivery check:** Run the smallest real “Expiry semantics” path and its adverse fixture “An expired update package is installed without an explicit authorized exception”; retain actual output, state effects and final disposition.
- [ ] **UC-M09.02-C022-T09 · Patch review:** Review the “Expiry semantics” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M09.02-C022-T10 · Delivery handoff:** Publish the “Expiry semantics” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M09.02-C023 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Expired metadata is not silently accepted as current. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M09.02-C023-T01 · Named property:** Create a stable property/check name under this parent for “Expiry semantics”; copy its required invariant exactly: “Expired metadata is not silently accepted as current”.
- [ ] **UC-M09.02-C023-T02 · Observable terms:** Define each term in the “Expiry semantics” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M09.02-C023-T03 · Precondition set:** List the preconditions under which “Expired metadata is not silently accepted as current” must hold for “Expiry semantics”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M09.02-C023-T04 · Transition coverage:** Map the “Expiry semantics” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M09.02-C023-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Expiry semantics”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M09.02-C023-T06 · Satisfying fixture:** Create a concrete “Expiry semantics” case that satisfies “Expired metadata is not silently accepted as current”; record its expected observation before running the assertion or review.
- [ ] **UC-M09.02-C023-T07 · Violating fixture:** Create the source counterexample “An expired update package is installed without an explicit authorized exception” for “Expiry semantics”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M09.02-C023-T08 · Enforcement evidence:** Exercise the “Expiry semantics” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M09.02-C023-T09 · Regression linkage:** Link the “Expiry semantics” property to changes in authenticated update metadata, persisted approved versions and installer staging; record which dependency or contract changes require rerunning it.
- [ ] **UC-M09.02-C023-T10 · Property disposition:** Compare the satisfying and violating “Expiry semantics” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M09.02-C024 · Integration

**Original checklist item:** Integrate expiry semantics with authenticated update metadata, persisted approved versions and installer staging; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M09.02-C024-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Expiry semantics” across authenticated update metadata, persisted approved versions and installer staging; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M09.02-C024-T02 · Field mapping:** Map every “Expiry semantics” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M09.02-C024-T03 · Prerequisite identities:** Record the actual prerequisites for “Expiry semantics” (source dependency list: UC-M09.01); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M09.02-C024-T04 · Ownership agreement:** Specify who owns “Expiry semantics” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M09.02-C024-T05 · Handoff implementation:** Connect “Expiry semantics” through the mapped seam using the real adapter or explicit specification reference; preserve “Expired metadata is not silently accepted as current” across the handoff.
- [ ] **UC-M09.02-C024-T06 · Absent-input case:** Omit one required “Expiry semantics” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M09.02-C024-T07 · Stale-input case:** Supply an outdated “Expiry semantics” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M09.02-C024-T08 · Incompatible-input case:** Supply an incompatible “Expiry semantics” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M09.02-C024-T09 · Valid integration trace:** Run a valid “Expiry semantics” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M09.02-C024-T10 · Seam review:** Reconcile the “Expiry semantics” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M09.02-C025 · Valid-case test

**Original checklist item:** Run a valid-path fixture for expiry semantics; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M09.02-C025-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Expiry semantics” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M09.02-C025-T02 · Expected-result oracle:** Specify the “Expiry semantics” expected result independently of the implementation output; include the property “Expired metadata is not silently accepted as current” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M09.02-C025-T03 · Fixture material:** Create the concrete “Expiry semantics” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M09.02-C025-T04 · Target preparation:** Prepare the “Expiry semantics” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M09.02-C025-T05 · Initial-state record:** Record the initial “Expiry semantics” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M09.02-C025-T06 · Valid-path execution:** Execute the “Expiry semantics” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M09.02-C025-T07 · Outcome comparison:** Compare every declared “Expiry semantics” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M09.02-C025-T08 · State and bounds check:** Inspect the “Expiry semantics” ownership/state effects and actual use of “Validity periods and clock uncertainty policy”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M09.02-C025-T09 · Repeatability check:** Repeat the same “Expiry semantics” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M09.02-C025-T10 · Positive evidence:** Attach the “Expiry semantics” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M09.02-C026 · Negative test

**Original checklist item:** Negative case: An expired update package is installed without an explicit authorized exception. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M09.02-C026-T01 · Adverse-case definition:** Create a test record for the exact “Expiry semantics” source counterexample: “An expired update package is installed without an explicit authorized exception”; state which precondition or invariant it challenges.
- [ ] **UC-M09.02-C026-T02 · Safe fixture boundary:** Define the contained test boundary for “Expiry semantics”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M09.02-C026-T03 · Valid control:** Construct a valid “Expiry semantics” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M09.02-C026-T04 · Minimal adverse input:** Derive the “Expiry semantics” adverse fixture from the control with the smallest documented change needed to reproduce “An expired update package is installed without an explicit authorized exception”; retain that change as reproducible data.
- [ ] **UC-M09.02-C026-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Expiry semantics”; require “Expired metadata is not silently accepted as current” and forbid a false-success verdict.
- [ ] **UC-M09.02-C026-T06 · Adverse execution:** Exercise the “Expiry semantics” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M09.02-C026-T07 · Effect inspection:** Inspect “Expiry semantics” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M09.02-C026-T08 · Refusal versus failure:** Confirm the “Expiry semantics” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M09.02-C026-T09 · Reset and retention:** Restore only the disposable “Expiry semantics” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M09.02-C026-T10 · Negative regression:** Register the “Expiry semantics” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M09.02-C027 · Change / failure test

**Original checklist item:** Exercise expiry semantics when an offline update is interrupted and then retried with older signed metadata; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M09.02-C027-T01 · Scenario record:** Write the “Expiry semantics” change/failure scenario exactly as supplied: an offline update is interrupted and then retried with older signed metadata; identify the property that must remain true: “Expired metadata is not silently accepted as current”.
- [ ] **UC-M09.02-C027-T02 · Baseline capture:** Create a known-valid “Expiry semantics” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M09.02-C027-T03 · Injection map:** Locate the “Expiry semantics” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M09.02-C027-T04 · Disposition oracle:** Define the legal intermediate and final “Expiry semantics” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M09.02-C027-T05 · Controlled trigger:** Introduce the controlled “Expiry semantics” scenario in the disposable fixture: an offline update is interrupted and then retried with older signed metadata; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M09.02-C027-T06 · Intermediate inspection:** Inspect the “Expiry semantics” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M09.02-C027-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Expiry semantics”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M09.02-C027-T08 · Stale-evidence cleanup:** Invalidate superseded “Expiry semantics” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M09.02-C027-T09 · Repeat and compare:** Repeat the selected “Expiry semantics” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M09.02-C027-T10 · Failure evidence:** Publish the “Expiry semantics” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M09.02-C028 · Bounds

**Original checklist item:** Choose, document and test limits for validity periods and clock uncertainty policy; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M09.02-C028-T01 · Quantity inventory:** Create a measurement inventory for “Expiry semantics”: “Validity periods and clock uncertainty policy”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M09.02-C028-T02 · Measurement method:** Choose how to observe each “Expiry semantics” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M09.02-C028-T03 · Budget decision:** Select justified resource and input limits for “Expiry semantics”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M09.02-C028-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Expiry semantics” cases for “Validity periods and clock uncertainty policy”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M09.02-C028-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Expiry semantics” limit; preserve “Expired metadata is not silently accepted as current”.
- [ ] **UC-M09.02-C028-T06 · Normal measurement:** Run or review the normal “Expiry semantics” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M09.02-C028-T07 · At-limit measurement:** Exercise the “Expiry semantics” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M09.02-C028-T08 · Over-limit measurement:** Exercise the “Expiry semantics” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M09.02-C028-T09 · Uncovered-scope report:** List the “Expiry semantics” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M09.02-C028-T10 · Limit evidence:** Publish the selected “Expiry semantics” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M09.02-C029 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for expiry semantics with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M09.02-C029-T01 · Event inventory:** List the “Expiry semantics” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M09.02-C029-T02 · Diagnostic schema:** Define nonsecret fields for “Expiry semantics” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M09.02-C029-T03 · Failure mapping:** Map each documented “Expiry semantics” refusal or error to a diagnostic outcome; include “An expired update package is installed without an explicit authorized exception” and prohibit conversion into a success message.
- [ ] **UC-M09.02-C029-T04 · Emission path:** Add the “Expiry semantics” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M09.02-C029-T05 · Redaction check:** Test “Expiry semantics” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M09.02-C029-T06 · Output budget:** Set and exercise bounded “Expiry semantics” message size, rate and retention compatible with “Validity periods and clock uncertainty policy”; define truncation behavior that preserves the final reason.
- [ ] **UC-M09.02-C029-T07 · Success/refusal fixtures:** Capture “Expiry semantics” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M09.02-C029-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Expiry semantics” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M09.02-C029-T09 · Operator review:** Read the “Expiry semantics” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M09.02-C029-T10 · Diagnostic evidence:** Publish redacted “Expiry semantics” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M09.02-C030 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for expiry semantics; label unexecuted checks as untested.

- [ ] **UC-M09.02-C030-T01 · Evidence inventory:** List the “Expiry semantics” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M09.02-C030-T02 · Artifact references:** Record the exact “Expiry semantics” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M09.02-C030-T03 · Fixture references:** Attach the “Expiry semantics” fixture IDs, input identities and oracle definition; preserve the source counterexample “An expired update package is installed without an explicit authorized exception” as a distinct evidence case.
- [ ] **UC-M09.02-C030-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Expiry semantics”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M09.02-C030-T05 · Environment record:** Record the actual “Expiry semantics” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M09.02-C030-T06 · Expected versus observed:** Pair every “Expiry semantics” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M09.02-C030-T07 · Failure and limit records:** Attach “Expiry semantics” change/failure and bounds evidence where required; include uncovered “Validity periods and clock uncertainty policy” and unresolved violations of “Expired metadata is not silently accepted as current”.
- [ ] **UC-M09.02-C030-T08 · Evidence hygiene:** Check the “Expiry semantics” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M09.02-C030-T09 · Reproduction review:** Have the “Expiry semantics” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M09.02-C030-T10 · Acceptance linkage:** Link the “Expiry semantics” evidence to its parent and UC-M09.02 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 04. Target digest binding

**Source delivery:** Bind named update targets to exact lengths and content digests.

**Source invariant:** A valid metadata signature cannot authorize altered target bytes.

**Source negative case:** The installer receives a different executable under the approved filename.

**Source bounded quantities:** Target bytes and digest verification time.

### UC-M09.02-C031 · Contract

**Original checklist item:** Specify target digest binding inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M09.02-C031-T01 · Scope statement:** Draft the operation boundary for “Target digest binding” within Anti-rollback update metadata; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M09.02-C031-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Target digest binding”; record each producer, representation and missing-value meaning.
- [ ] **UC-M09.02-C031-T03 · Output inventory:** List the outputs of “Target digest binding” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M09.02-C031-T04 · Field dictionary:** Create a field-and-term dictionary for “Target digest binding”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M09.02-C031-T05 · Prerequisite contract:** Map “Target digest binding” to the source component prerequisites (UC-M09.01); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M09.02-C031-T06 · Authority map:** Identify who may produce, change and consume “Target digest binding”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M09.02-C031-T07 · Invariant clause:** Add a normative clause for “Target digest binding” that preserves “A valid metadata signature cannot authorize altered target bytes”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M09.02-C031-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Target digest binding”; include the source counterexample “The installer receives a different executable under the approved filename” and the intended safe disposition.
- [ ] **UC-M09.02-C031-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Target bytes and digest verification time” in the “Target digest binding” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M09.02-C031-T10 · Contract review:** Review the “Target digest binding” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M09.02-C032 · Delivery

**Original checklist item:** Bind named update targets to exact lengths and content digests.

- [ ] **UC-M09.02-C032-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Target digest binding”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M09.02-C032-T02 · Change plan:** Break the source delivery for “Target digest binding” into concrete edit targets and reviewable outputs; keep the UC-M09.02 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M09.02-C032-T03 · Core artifact:** Implement the smallest selected-profile change for “Target digest binding” that realizes this source instruction: Bind named update targets to exact lengths and content digests.
- [ ] **UC-M09.02-C032-T04 · Concrete realization:** Trace “Target digest binding” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M09.02-C032-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Target digest binding” needed to preserve “A valid metadata signature cannot authorize altered target bytes”; record an enforcement gap where only a model exists.
- [ ] **UC-M09.02-C032-T06 · Dependency connection:** Connect the “Target digest binding” implementation to authenticated update metadata, persisted approved versions and installer staging; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M09.02-C032-T07 · Resource behavior:** Account for “Target bytes and digest verification time” in “Target digest binding”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M09.02-C032-T08 · Delivery check:** Run the smallest real “Target digest binding” path and its adverse fixture “The installer receives a different executable under the approved filename”; retain actual output, state effects and final disposition.
- [ ] **UC-M09.02-C032-T09 · Patch review:** Review the “Target digest binding” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M09.02-C032-T10 · Delivery handoff:** Publish the “Target digest binding” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M09.02-C033 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: A valid metadata signature cannot authorize altered target bytes. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M09.02-C033-T01 · Named property:** Create a stable property/check name under this parent for “Target digest binding”; copy its required invariant exactly: “A valid metadata signature cannot authorize altered target bytes”.
- [ ] **UC-M09.02-C033-T02 · Observable terms:** Define each term in the “Target digest binding” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M09.02-C033-T03 · Precondition set:** List the preconditions under which “A valid metadata signature cannot authorize altered target bytes” must hold for “Target digest binding”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M09.02-C033-T04 · Transition coverage:** Map the “Target digest binding” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M09.02-C033-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Target digest binding”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M09.02-C033-T06 · Satisfying fixture:** Create a concrete “Target digest binding” case that satisfies “A valid metadata signature cannot authorize altered target bytes”; record its expected observation before running the assertion or review.
- [ ] **UC-M09.02-C033-T07 · Violating fixture:** Create the source counterexample “The installer receives a different executable under the approved filename” for “Target digest binding”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M09.02-C033-T08 · Enforcement evidence:** Exercise the “Target digest binding” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M09.02-C033-T09 · Regression linkage:** Link the “Target digest binding” property to changes in authenticated update metadata, persisted approved versions and installer staging; record which dependency or contract changes require rerunning it.
- [ ] **UC-M09.02-C033-T10 · Property disposition:** Compare the satisfying and violating “Target digest binding” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M09.02-C034 · Integration

**Original checklist item:** Integrate target digest binding with authenticated update metadata, persisted approved versions and installer staging; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M09.02-C034-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Target digest binding” across authenticated update metadata, persisted approved versions and installer staging; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M09.02-C034-T02 · Field mapping:** Map every “Target digest binding” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M09.02-C034-T03 · Prerequisite identities:** Record the actual prerequisites for “Target digest binding” (source dependency list: UC-M09.01); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M09.02-C034-T04 · Ownership agreement:** Specify who owns “Target digest binding” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M09.02-C034-T05 · Handoff implementation:** Connect “Target digest binding” through the mapped seam using the real adapter or explicit specification reference; preserve “A valid metadata signature cannot authorize altered target bytes” across the handoff.
- [ ] **UC-M09.02-C034-T06 · Absent-input case:** Omit one required “Target digest binding” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M09.02-C034-T07 · Stale-input case:** Supply an outdated “Target digest binding” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M09.02-C034-T08 · Incompatible-input case:** Supply an incompatible “Target digest binding” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M09.02-C034-T09 · Valid integration trace:** Run a valid “Target digest binding” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M09.02-C034-T10 · Seam review:** Reconcile the “Target digest binding” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M09.02-C035 · Valid-case test

**Original checklist item:** Run a valid-path fixture for target digest binding; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M09.02-C035-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Target digest binding” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M09.02-C035-T02 · Expected-result oracle:** Specify the “Target digest binding” expected result independently of the implementation output; include the property “A valid metadata signature cannot authorize altered target bytes” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M09.02-C035-T03 · Fixture material:** Create the concrete “Target digest binding” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M09.02-C035-T04 · Target preparation:** Prepare the “Target digest binding” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M09.02-C035-T05 · Initial-state record:** Record the initial “Target digest binding” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M09.02-C035-T06 · Valid-path execution:** Execute the “Target digest binding” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M09.02-C035-T07 · Outcome comparison:** Compare every declared “Target digest binding” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M09.02-C035-T08 · State and bounds check:** Inspect the “Target digest binding” ownership/state effects and actual use of “Target bytes and digest verification time”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M09.02-C035-T09 · Repeatability check:** Repeat the same “Target digest binding” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M09.02-C035-T10 · Positive evidence:** Attach the “Target digest binding” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M09.02-C036 · Negative test

**Original checklist item:** Negative case: The installer receives a different executable under the approved filename. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M09.02-C036-T01 · Adverse-case definition:** Create a test record for the exact “Target digest binding” source counterexample: “The installer receives a different executable under the approved filename”; state which precondition or invariant it challenges.
- [ ] **UC-M09.02-C036-T02 · Safe fixture boundary:** Define the contained test boundary for “Target digest binding”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M09.02-C036-T03 · Valid control:** Construct a valid “Target digest binding” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M09.02-C036-T04 · Minimal adverse input:** Derive the “Target digest binding” adverse fixture from the control with the smallest documented change needed to reproduce “The installer receives a different executable under the approved filename”; retain that change as reproducible data.
- [ ] **UC-M09.02-C036-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Target digest binding”; require “A valid metadata signature cannot authorize altered target bytes” and forbid a false-success verdict.
- [ ] **UC-M09.02-C036-T06 · Adverse execution:** Exercise the “Target digest binding” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M09.02-C036-T07 · Effect inspection:** Inspect “Target digest binding” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M09.02-C036-T08 · Refusal versus failure:** Confirm the “Target digest binding” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M09.02-C036-T09 · Reset and retention:** Restore only the disposable “Target digest binding” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M09.02-C036-T10 · Negative regression:** Register the “Target digest binding” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M09.02-C037 · Change / failure test

**Original checklist item:** Exercise target digest binding when an offline update is interrupted and then retried with older signed metadata; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M09.02-C037-T01 · Scenario record:** Write the “Target digest binding” change/failure scenario exactly as supplied: an offline update is interrupted and then retried with older signed metadata; identify the property that must remain true: “A valid metadata signature cannot authorize altered target bytes”.
- [ ] **UC-M09.02-C037-T02 · Baseline capture:** Create a known-valid “Target digest binding” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M09.02-C037-T03 · Injection map:** Locate the “Target digest binding” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M09.02-C037-T04 · Disposition oracle:** Define the legal intermediate and final “Target digest binding” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M09.02-C037-T05 · Controlled trigger:** Introduce the controlled “Target digest binding” scenario in the disposable fixture: an offline update is interrupted and then retried with older signed metadata; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M09.02-C037-T06 · Intermediate inspection:** Inspect the “Target digest binding” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M09.02-C037-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Target digest binding”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M09.02-C037-T08 · Stale-evidence cleanup:** Invalidate superseded “Target digest binding” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M09.02-C037-T09 · Repeat and compare:** Repeat the selected “Target digest binding” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M09.02-C037-T10 · Failure evidence:** Publish the “Target digest binding” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M09.02-C038 · Bounds

**Original checklist item:** Choose, document and test limits for target bytes and digest verification time; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M09.02-C038-T01 · Quantity inventory:** Create a measurement inventory for “Target digest binding”: “Target bytes and digest verification time”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M09.02-C038-T02 · Measurement method:** Choose how to observe each “Target digest binding” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M09.02-C038-T03 · Budget decision:** Select justified resource and input limits for “Target digest binding”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M09.02-C038-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Target digest binding” cases for “Target bytes and digest verification time”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M09.02-C038-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Target digest binding” limit; preserve “A valid metadata signature cannot authorize altered target bytes”.
- [ ] **UC-M09.02-C038-T06 · Normal measurement:** Run or review the normal “Target digest binding” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M09.02-C038-T07 · At-limit measurement:** Exercise the “Target digest binding” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M09.02-C038-T08 · Over-limit measurement:** Exercise the “Target digest binding” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M09.02-C038-T09 · Uncovered-scope report:** List the “Target digest binding” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M09.02-C038-T10 · Limit evidence:** Publish the selected “Target digest binding” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M09.02-C039 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for target digest binding with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M09.02-C039-T01 · Event inventory:** List the “Target digest binding” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M09.02-C039-T02 · Diagnostic schema:** Define nonsecret fields for “Target digest binding” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M09.02-C039-T03 · Failure mapping:** Map each documented “Target digest binding” refusal or error to a diagnostic outcome; include “The installer receives a different executable under the approved filename” and prohibit conversion into a success message.
- [ ] **UC-M09.02-C039-T04 · Emission path:** Add the “Target digest binding” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M09.02-C039-T05 · Redaction check:** Test “Target digest binding” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M09.02-C039-T06 · Output budget:** Set and exercise bounded “Target digest binding” message size, rate and retention compatible with “Target bytes and digest verification time”; define truncation behavior that preserves the final reason.
- [ ] **UC-M09.02-C039-T07 · Success/refusal fixtures:** Capture “Target digest binding” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M09.02-C039-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Target digest binding” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M09.02-C039-T09 · Operator review:** Read the “Target digest binding” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M09.02-C039-T10 · Diagnostic evidence:** Publish redacted “Target digest binding” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M09.02-C040 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for target digest binding; label unexecuted checks as untested.

- [ ] **UC-M09.02-C040-T01 · Evidence inventory:** List the “Target digest binding” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M09.02-C040-T02 · Artifact references:** Record the exact “Target digest binding” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M09.02-C040-T03 · Fixture references:** Attach the “Target digest binding” fixture IDs, input identities and oracle definition; preserve the source counterexample “The installer receives a different executable under the approved filename” as a distinct evidence case.
- [ ] **UC-M09.02-C040-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Target digest binding”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M09.02-C040-T05 · Environment record:** Record the actual “Target digest binding” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M09.02-C040-T06 · Expected versus observed:** Pair every “Target digest binding” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M09.02-C040-T07 · Failure and limit records:** Attach “Target digest binding” change/failure and bounds evidence where required; include uncovered “Target bytes and digest verification time” and unresolved violations of “A valid metadata signature cannot authorize altered target bytes”.
- [ ] **UC-M09.02-C040-T08 · Evidence hygiene:** Check the “Target digest binding” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M09.02-C040-T09 · Reproduction review:** Have the “Target digest binding” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M09.02-C040-T10 · Acceptance linkage:** Link the “Target digest binding” evidence to its parent and UC-M09.02 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 05. Metadata consistency

**Source delivery:** Validate cross-role versions, identities and target relationships.

**Source invariant:** Individually signed but inconsistent metadata cannot form a valid update.

**Source negative case:** A current target list is paired with an older inconsistent snapshot.

**Source bounded quantities:** Metadata objects and dependency depth.

### UC-M09.02-C041 · Contract

**Original checklist item:** Specify metadata consistency inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M09.02-C041-T01 · Scope statement:** Draft the operation boundary for “Metadata consistency” within Anti-rollback update metadata; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M09.02-C041-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Metadata consistency”; record each producer, representation and missing-value meaning.
- [ ] **UC-M09.02-C041-T03 · Output inventory:** List the outputs of “Metadata consistency” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M09.02-C041-T04 · Field dictionary:** Create a field-and-term dictionary for “Metadata consistency”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M09.02-C041-T05 · Prerequisite contract:** Map “Metadata consistency” to the source component prerequisites (UC-M09.01); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M09.02-C041-T06 · Authority map:** Identify who may produce, change and consume “Metadata consistency”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M09.02-C041-T07 · Invariant clause:** Add a normative clause for “Metadata consistency” that preserves “Individually signed but inconsistent metadata cannot form a valid update”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M09.02-C041-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Metadata consistency”; include the source counterexample “A current target list is paired with an older inconsistent snapshot” and the intended safe disposition.
- [ ] **UC-M09.02-C041-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Metadata objects and dependency depth” in the “Metadata consistency” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M09.02-C041-T10 · Contract review:** Review the “Metadata consistency” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M09.02-C042 · Delivery

**Original checklist item:** Validate cross-role versions, identities and target relationships.

- [ ] **UC-M09.02-C042-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Metadata consistency”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M09.02-C042-T02 · Change plan:** Break the source delivery for “Metadata consistency” into concrete edit targets and reviewable outputs; keep the UC-M09.02 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M09.02-C042-T03 · Core artifact:** Implement the smallest selected-profile change for “Metadata consistency” that realizes this source instruction: Validate cross-role versions, identities and target relationships.
- [ ] **UC-M09.02-C042-T04 · Concrete realization:** Trace “Metadata consistency” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M09.02-C042-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Metadata consistency” needed to preserve “Individually signed but inconsistent metadata cannot form a valid update”; record an enforcement gap where only a model exists.
- [ ] **UC-M09.02-C042-T06 · Dependency connection:** Connect the “Metadata consistency” implementation to authenticated update metadata, persisted approved versions and installer staging; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M09.02-C042-T07 · Resource behavior:** Account for “Metadata objects and dependency depth” in “Metadata consistency”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M09.02-C042-T08 · Delivery check:** Run the smallest real “Metadata consistency” path and its adverse fixture “A current target list is paired with an older inconsistent snapshot”; retain actual output, state effects and final disposition.
- [ ] **UC-M09.02-C042-T09 · Patch review:** Review the “Metadata consistency” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M09.02-C042-T10 · Delivery handoff:** Publish the “Metadata consistency” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M09.02-C043 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Individually signed but inconsistent metadata cannot form a valid update. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M09.02-C043-T01 · Named property:** Create a stable property/check name under this parent for “Metadata consistency”; copy its required invariant exactly: “Individually signed but inconsistent metadata cannot form a valid update”.
- [ ] **UC-M09.02-C043-T02 · Observable terms:** Define each term in the “Metadata consistency” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M09.02-C043-T03 · Precondition set:** List the preconditions under which “Individually signed but inconsistent metadata cannot form a valid update” must hold for “Metadata consistency”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M09.02-C043-T04 · Transition coverage:** Map the “Metadata consistency” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M09.02-C043-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Metadata consistency”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M09.02-C043-T06 · Satisfying fixture:** Create a concrete “Metadata consistency” case that satisfies “Individually signed but inconsistent metadata cannot form a valid update”; record its expected observation before running the assertion or review.
- [ ] **UC-M09.02-C043-T07 · Violating fixture:** Create the source counterexample “A current target list is paired with an older inconsistent snapshot” for “Metadata consistency”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M09.02-C043-T08 · Enforcement evidence:** Exercise the “Metadata consistency” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M09.02-C043-T09 · Regression linkage:** Link the “Metadata consistency” property to changes in authenticated update metadata, persisted approved versions and installer staging; record which dependency or contract changes require rerunning it.
- [ ] **UC-M09.02-C043-T10 · Property disposition:** Compare the satisfying and violating “Metadata consistency” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M09.02-C044 · Integration

**Original checklist item:** Integrate metadata consistency with authenticated update metadata, persisted approved versions and installer staging; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M09.02-C044-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Metadata consistency” across authenticated update metadata, persisted approved versions and installer staging; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M09.02-C044-T02 · Field mapping:** Map every “Metadata consistency” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M09.02-C044-T03 · Prerequisite identities:** Record the actual prerequisites for “Metadata consistency” (source dependency list: UC-M09.01); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M09.02-C044-T04 · Ownership agreement:** Specify who owns “Metadata consistency” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M09.02-C044-T05 · Handoff implementation:** Connect “Metadata consistency” through the mapped seam using the real adapter or explicit specification reference; preserve “Individually signed but inconsistent metadata cannot form a valid update” across the handoff.
- [ ] **UC-M09.02-C044-T06 · Absent-input case:** Omit one required “Metadata consistency” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M09.02-C044-T07 · Stale-input case:** Supply an outdated “Metadata consistency” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M09.02-C044-T08 · Incompatible-input case:** Supply an incompatible “Metadata consistency” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M09.02-C044-T09 · Valid integration trace:** Run a valid “Metadata consistency” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M09.02-C044-T10 · Seam review:** Reconcile the “Metadata consistency” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M09.02-C045 · Valid-case test

**Original checklist item:** Run a valid-path fixture for metadata consistency; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M09.02-C045-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Metadata consistency” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M09.02-C045-T02 · Expected-result oracle:** Specify the “Metadata consistency” expected result independently of the implementation output; include the property “Individually signed but inconsistent metadata cannot form a valid update” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M09.02-C045-T03 · Fixture material:** Create the concrete “Metadata consistency” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M09.02-C045-T04 · Target preparation:** Prepare the “Metadata consistency” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M09.02-C045-T05 · Initial-state record:** Record the initial “Metadata consistency” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M09.02-C045-T06 · Valid-path execution:** Execute the “Metadata consistency” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M09.02-C045-T07 · Outcome comparison:** Compare every declared “Metadata consistency” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M09.02-C045-T08 · State and bounds check:** Inspect the “Metadata consistency” ownership/state effects and actual use of “Metadata objects and dependency depth”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M09.02-C045-T09 · Repeatability check:** Repeat the same “Metadata consistency” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M09.02-C045-T10 · Positive evidence:** Attach the “Metadata consistency” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M09.02-C046 · Negative test

**Original checklist item:** Negative case: A current target list is paired with an older inconsistent snapshot. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M09.02-C046-T01 · Adverse-case definition:** Create a test record for the exact “Metadata consistency” source counterexample: “A current target list is paired with an older inconsistent snapshot”; state which precondition or invariant it challenges.
- [ ] **UC-M09.02-C046-T02 · Safe fixture boundary:** Define the contained test boundary for “Metadata consistency”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M09.02-C046-T03 · Valid control:** Construct a valid “Metadata consistency” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M09.02-C046-T04 · Minimal adverse input:** Derive the “Metadata consistency” adverse fixture from the control with the smallest documented change needed to reproduce “A current target list is paired with an older inconsistent snapshot”; retain that change as reproducible data.
- [ ] **UC-M09.02-C046-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Metadata consistency”; require “Individually signed but inconsistent metadata cannot form a valid update” and forbid a false-success verdict.
- [ ] **UC-M09.02-C046-T06 · Adverse execution:** Exercise the “Metadata consistency” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M09.02-C046-T07 · Effect inspection:** Inspect “Metadata consistency” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M09.02-C046-T08 · Refusal versus failure:** Confirm the “Metadata consistency” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M09.02-C046-T09 · Reset and retention:** Restore only the disposable “Metadata consistency” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M09.02-C046-T10 · Negative regression:** Register the “Metadata consistency” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M09.02-C047 · Change / failure test

**Original checklist item:** Exercise metadata consistency when an offline update is interrupted and then retried with older signed metadata; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M09.02-C047-T01 · Scenario record:** Write the “Metadata consistency” change/failure scenario exactly as supplied: an offline update is interrupted and then retried with older signed metadata; identify the property that must remain true: “Individually signed but inconsistent metadata cannot form a valid update”.
- [ ] **UC-M09.02-C047-T02 · Baseline capture:** Create a known-valid “Metadata consistency” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M09.02-C047-T03 · Injection map:** Locate the “Metadata consistency” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M09.02-C047-T04 · Disposition oracle:** Define the legal intermediate and final “Metadata consistency” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M09.02-C047-T05 · Controlled trigger:** Introduce the controlled “Metadata consistency” scenario in the disposable fixture: an offline update is interrupted and then retried with older signed metadata; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M09.02-C047-T06 · Intermediate inspection:** Inspect the “Metadata consistency” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M09.02-C047-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Metadata consistency”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M09.02-C047-T08 · Stale-evidence cleanup:** Invalidate superseded “Metadata consistency” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M09.02-C047-T09 · Repeat and compare:** Repeat the selected “Metadata consistency” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M09.02-C047-T10 · Failure evidence:** Publish the “Metadata consistency” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M09.02-C048 · Bounds

**Original checklist item:** Choose, document and test limits for metadata objects and dependency depth; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M09.02-C048-T01 · Quantity inventory:** Create a measurement inventory for “Metadata consistency”: “Metadata objects and dependency depth”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M09.02-C048-T02 · Measurement method:** Choose how to observe each “Metadata consistency” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M09.02-C048-T03 · Budget decision:** Select justified resource and input limits for “Metadata consistency”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M09.02-C048-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Metadata consistency” cases for “Metadata objects and dependency depth”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M09.02-C048-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Metadata consistency” limit; preserve “Individually signed but inconsistent metadata cannot form a valid update”.
- [ ] **UC-M09.02-C048-T06 · Normal measurement:** Run or review the normal “Metadata consistency” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M09.02-C048-T07 · At-limit measurement:** Exercise the “Metadata consistency” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M09.02-C048-T08 · Over-limit measurement:** Exercise the “Metadata consistency” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M09.02-C048-T09 · Uncovered-scope report:** List the “Metadata consistency” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M09.02-C048-T10 · Limit evidence:** Publish the selected “Metadata consistency” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M09.02-C049 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for metadata consistency with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M09.02-C049-T01 · Event inventory:** List the “Metadata consistency” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M09.02-C049-T02 · Diagnostic schema:** Define nonsecret fields for “Metadata consistency” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M09.02-C049-T03 · Failure mapping:** Map each documented “Metadata consistency” refusal or error to a diagnostic outcome; include “A current target list is paired with an older inconsistent snapshot” and prohibit conversion into a success message.
- [ ] **UC-M09.02-C049-T04 · Emission path:** Add the “Metadata consistency” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M09.02-C049-T05 · Redaction check:** Test “Metadata consistency” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M09.02-C049-T06 · Output budget:** Set and exercise bounded “Metadata consistency” message size, rate and retention compatible with “Metadata objects and dependency depth”; define truncation behavior that preserves the final reason.
- [ ] **UC-M09.02-C049-T07 · Success/refusal fixtures:** Capture “Metadata consistency” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M09.02-C049-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Metadata consistency” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M09.02-C049-T09 · Operator review:** Read the “Metadata consistency” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M09.02-C049-T10 · Diagnostic evidence:** Publish redacted “Metadata consistency” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M09.02-C050 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for metadata consistency; label unexecuted checks as untested.

- [ ] **UC-M09.02-C050-T01 · Evidence inventory:** List the “Metadata consistency” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M09.02-C050-T02 · Artifact references:** Record the exact “Metadata consistency” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M09.02-C050-T03 · Fixture references:** Attach the “Metadata consistency” fixture IDs, input identities and oracle definition; preserve the source counterexample “A current target list is paired with an older inconsistent snapshot” as a distinct evidence case.
- [ ] **UC-M09.02-C050-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Metadata consistency”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M09.02-C050-T05 · Environment record:** Record the actual “Metadata consistency” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M09.02-C050-T06 · Expected versus observed:** Pair every “Metadata consistency” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M09.02-C050-T07 · Failure and limit records:** Attach “Metadata consistency” change/failure and bounds evidence where required; include uncovered “Metadata objects and dependency depth” and unresolved violations of “Individually signed but inconsistent metadata cannot form a valid update”.
- [ ] **UC-M09.02-C050-T08 · Evidence hygiene:** Check the “Metadata consistency” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M09.02-C050-T09 · Reproduction review:** Have the “Metadata consistency” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M09.02-C050-T10 · Acceptance linkage:** Link the “Metadata consistency” evidence to its parent and UC-M09.02 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 06. Offline distribution package

**Source delivery:** Package all required authenticated metadata for explicit offline verification.

**Source invariant:** Offline installation performs no implicit trust enrollment or unsigned substitution.

**Source negative case:** A removable update omits required authority metadata.

**Source bounded quantities:** Package bytes and verification prerequisites.

### UC-M09.02-C051 · Contract

**Original checklist item:** Specify offline distribution package inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M09.02-C051-T01 · Scope statement:** Draft the operation boundary for “Offline distribution package” within Anti-rollback update metadata; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M09.02-C051-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Offline distribution package”; record each producer, representation and missing-value meaning.
- [ ] **UC-M09.02-C051-T03 · Output inventory:** List the outputs of “Offline distribution package” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M09.02-C051-T04 · Field dictionary:** Create a field-and-term dictionary for “Offline distribution package”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M09.02-C051-T05 · Prerequisite contract:** Map “Offline distribution package” to the source component prerequisites (UC-M09.01); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M09.02-C051-T06 · Authority map:** Identify who may produce, change and consume “Offline distribution package”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M09.02-C051-T07 · Invariant clause:** Add a normative clause for “Offline distribution package” that preserves “Offline installation performs no implicit trust enrollment or unsigned substitution”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M09.02-C051-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Offline distribution package”; include the source counterexample “A removable update omits required authority metadata” and the intended safe disposition.
- [ ] **UC-M09.02-C051-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Package bytes and verification prerequisites” in the “Offline distribution package” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M09.02-C051-T10 · Contract review:** Review the “Offline distribution package” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M09.02-C052 · Delivery

**Original checklist item:** Package all required authenticated metadata for explicit offline verification.

- [ ] **UC-M09.02-C052-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Offline distribution package”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M09.02-C052-T02 · Change plan:** Break the source delivery for “Offline distribution package” into concrete edit targets and reviewable outputs; keep the UC-M09.02 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M09.02-C052-T03 · Core artifact:** Create the “Offline distribution package” output artifact for this source instruction: Package all required authenticated metadata for explicit offline verification.
- [ ] **UC-M09.02-C052-T04 · Concrete realization:** Populate the “Offline distribution package” artifact from identified observations; keep unknown, failed and unexecuted results distinct and exclude unapproved sensitive material.
- [ ] **UC-M09.02-C052-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Offline distribution package” needed to preserve “Offline installation performs no implicit trust enrollment or unsigned substitution”; record an enforcement gap where only a model exists.
- [ ] **UC-M09.02-C052-T06 · Dependency connection:** Connect the “Offline distribution package” implementation to authenticated update metadata, persisted approved versions and installer staging; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M09.02-C052-T07 · Resource behavior:** Account for “Package bytes and verification prerequisites” in “Offline distribution package”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M09.02-C052-T08 · Delivery check:** Run the smallest real “Offline distribution package” path and its adverse fixture “A removable update omits required authority metadata”; retain actual output, state effects and final disposition.
- [ ] **UC-M09.02-C052-T09 · Patch review:** Review the “Offline distribution package” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M09.02-C052-T10 · Delivery handoff:** Publish the “Offline distribution package” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M09.02-C053 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Offline installation performs no implicit trust enrollment or unsigned substitution. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M09.02-C053-T01 · Named property:** Create a stable property/check name under this parent for “Offline distribution package”; copy its required invariant exactly: “Offline installation performs no implicit trust enrollment or unsigned substitution”.
- [ ] **UC-M09.02-C053-T02 · Observable terms:** Define each term in the “Offline distribution package” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M09.02-C053-T03 · Precondition set:** List the preconditions under which “Offline installation performs no implicit trust enrollment or unsigned substitution” must hold for “Offline distribution package”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M09.02-C053-T04 · Transition coverage:** Map the “Offline distribution package” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M09.02-C053-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Offline distribution package”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M09.02-C053-T06 · Satisfying fixture:** Create a concrete “Offline distribution package” case that satisfies “Offline installation performs no implicit trust enrollment or unsigned substitution”; record its expected observation before running the assertion or review.
- [ ] **UC-M09.02-C053-T07 · Violating fixture:** Create the source counterexample “A removable update omits required authority metadata” for “Offline distribution package”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M09.02-C053-T08 · Enforcement evidence:** Exercise the “Offline distribution package” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M09.02-C053-T09 · Regression linkage:** Link the “Offline distribution package” property to changes in authenticated update metadata, persisted approved versions and installer staging; record which dependency or contract changes require rerunning it.
- [ ] **UC-M09.02-C053-T10 · Property disposition:** Compare the satisfying and violating “Offline distribution package” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M09.02-C054 · Integration

**Original checklist item:** Integrate offline distribution package with authenticated update metadata, persisted approved versions and installer staging; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M09.02-C054-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Offline distribution package” across authenticated update metadata, persisted approved versions and installer staging; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M09.02-C054-T02 · Field mapping:** Map every “Offline distribution package” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M09.02-C054-T03 · Prerequisite identities:** Record the actual prerequisites for “Offline distribution package” (source dependency list: UC-M09.01); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M09.02-C054-T04 · Ownership agreement:** Specify who owns “Offline distribution package” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M09.02-C054-T05 · Handoff implementation:** Connect “Offline distribution package” through the mapped seam using the real adapter or explicit specification reference; preserve “Offline installation performs no implicit trust enrollment or unsigned substitution” across the handoff.
- [ ] **UC-M09.02-C054-T06 · Absent-input case:** Omit one required “Offline distribution package” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M09.02-C054-T07 · Stale-input case:** Supply an outdated “Offline distribution package” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M09.02-C054-T08 · Incompatible-input case:** Supply an incompatible “Offline distribution package” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M09.02-C054-T09 · Valid integration trace:** Run a valid “Offline distribution package” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M09.02-C054-T10 · Seam review:** Reconcile the “Offline distribution package” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M09.02-C055 · Valid-case test

**Original checklist item:** Run a valid-path fixture for offline distribution package; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M09.02-C055-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Offline distribution package” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M09.02-C055-T02 · Expected-result oracle:** Specify the “Offline distribution package” expected result independently of the implementation output; include the property “Offline installation performs no implicit trust enrollment or unsigned substitution” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M09.02-C055-T03 · Fixture material:** Create the concrete “Offline distribution package” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M09.02-C055-T04 · Target preparation:** Prepare the “Offline distribution package” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M09.02-C055-T05 · Initial-state record:** Record the initial “Offline distribution package” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M09.02-C055-T06 · Valid-path execution:** Execute the “Offline distribution package” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M09.02-C055-T07 · Outcome comparison:** Compare every declared “Offline distribution package” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M09.02-C055-T08 · State and bounds check:** Inspect the “Offline distribution package” ownership/state effects and actual use of “Package bytes and verification prerequisites”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M09.02-C055-T09 · Repeatability check:** Repeat the same “Offline distribution package” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M09.02-C055-T10 · Positive evidence:** Attach the “Offline distribution package” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M09.02-C056 · Negative test

**Original checklist item:** Negative case: A removable update omits required authority metadata. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M09.02-C056-T01 · Adverse-case definition:** Create a test record for the exact “Offline distribution package” source counterexample: “A removable update omits required authority metadata”; state which precondition or invariant it challenges.
- [ ] **UC-M09.02-C056-T02 · Safe fixture boundary:** Define the contained test boundary for “Offline distribution package”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M09.02-C056-T03 · Valid control:** Construct a valid “Offline distribution package” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M09.02-C056-T04 · Minimal adverse input:** Derive the “Offline distribution package” adverse fixture from the control with the smallest documented change needed to reproduce “A removable update omits required authority metadata”; retain that change as reproducible data.
- [ ] **UC-M09.02-C056-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Offline distribution package”; require “Offline installation performs no implicit trust enrollment or unsigned substitution” and forbid a false-success verdict.
- [ ] **UC-M09.02-C056-T06 · Adverse execution:** Exercise the “Offline distribution package” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M09.02-C056-T07 · Effect inspection:** Inspect “Offline distribution package” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M09.02-C056-T08 · Refusal versus failure:** Confirm the “Offline distribution package” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M09.02-C056-T09 · Reset and retention:** Restore only the disposable “Offline distribution package” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M09.02-C056-T10 · Negative regression:** Register the “Offline distribution package” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M09.02-C057 · Change / failure test

**Original checklist item:** Exercise offline distribution package when an offline update is interrupted and then retried with older signed metadata; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M09.02-C057-T01 · Scenario record:** Write the “Offline distribution package” change/failure scenario exactly as supplied: an offline update is interrupted and then retried with older signed metadata; identify the property that must remain true: “Offline installation performs no implicit trust enrollment or unsigned substitution”.
- [ ] **UC-M09.02-C057-T02 · Baseline capture:** Create a known-valid “Offline distribution package” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M09.02-C057-T03 · Injection map:** Locate the “Offline distribution package” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M09.02-C057-T04 · Disposition oracle:** Define the legal intermediate and final “Offline distribution package” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M09.02-C057-T05 · Controlled trigger:** Introduce the controlled “Offline distribution package” scenario in the disposable fixture: an offline update is interrupted and then retried with older signed metadata; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M09.02-C057-T06 · Intermediate inspection:** Inspect the “Offline distribution package” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M09.02-C057-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Offline distribution package”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M09.02-C057-T08 · Stale-evidence cleanup:** Invalidate superseded “Offline distribution package” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M09.02-C057-T09 · Repeat and compare:** Repeat the selected “Offline distribution package” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M09.02-C057-T10 · Failure evidence:** Publish the “Offline distribution package” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M09.02-C058 · Bounds

**Original checklist item:** Choose, document and test limits for package bytes and verification prerequisites; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M09.02-C058-T01 · Quantity inventory:** Create a measurement inventory for “Offline distribution package”: “Package bytes and verification prerequisites”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M09.02-C058-T02 · Measurement method:** Choose how to observe each “Offline distribution package” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M09.02-C058-T03 · Budget decision:** Select justified resource and input limits for “Offline distribution package”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M09.02-C058-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Offline distribution package” cases for “Package bytes and verification prerequisites”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M09.02-C058-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Offline distribution package” limit; preserve “Offline installation performs no implicit trust enrollment or unsigned substitution”.
- [ ] **UC-M09.02-C058-T06 · Normal measurement:** Run or review the normal “Offline distribution package” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M09.02-C058-T07 · At-limit measurement:** Exercise the “Offline distribution package” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M09.02-C058-T08 · Over-limit measurement:** Exercise the “Offline distribution package” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M09.02-C058-T09 · Uncovered-scope report:** List the “Offline distribution package” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M09.02-C058-T10 · Limit evidence:** Publish the selected “Offline distribution package” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M09.02-C059 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for offline distribution package with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M09.02-C059-T01 · Event inventory:** List the “Offline distribution package” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M09.02-C059-T02 · Diagnostic schema:** Define nonsecret fields for “Offline distribution package” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M09.02-C059-T03 · Failure mapping:** Map each documented “Offline distribution package” refusal or error to a diagnostic outcome; include “A removable update omits required authority metadata” and prohibit conversion into a success message.
- [ ] **UC-M09.02-C059-T04 · Emission path:** Add the “Offline distribution package” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M09.02-C059-T05 · Redaction check:** Test “Offline distribution package” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M09.02-C059-T06 · Output budget:** Set and exercise bounded “Offline distribution package” message size, rate and retention compatible with “Package bytes and verification prerequisites”; define truncation behavior that preserves the final reason.
- [ ] **UC-M09.02-C059-T07 · Success/refusal fixtures:** Capture “Offline distribution package” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M09.02-C059-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Offline distribution package” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M09.02-C059-T09 · Operator review:** Read the “Offline distribution package” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M09.02-C059-T10 · Diagnostic evidence:** Publish redacted “Offline distribution package” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M09.02-C060 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for offline distribution package; label unexecuted checks as untested.

- [ ] **UC-M09.02-C060-T01 · Evidence inventory:** List the “Offline distribution package” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M09.02-C060-T02 · Artifact references:** Record the exact “Offline distribution package” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M09.02-C060-T03 · Fixture references:** Attach the “Offline distribution package” fixture IDs, input identities and oracle definition; preserve the source counterexample “A removable update omits required authority metadata” as a distinct evidence case.
- [ ] **UC-M09.02-C060-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Offline distribution package”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M09.02-C060-T05 · Environment record:** Record the actual “Offline distribution package” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M09.02-C060-T06 · Expected versus observed:** Pair every “Offline distribution package” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M09.02-C060-T07 · Failure and limit records:** Attach “Offline distribution package” change/failure and bounds evidence where required; include uncovered “Package bytes and verification prerequisites” and unresolved violations of “Offline installation performs no implicit trust enrollment or unsigned substitution”.
- [ ] **UC-M09.02-C060-T08 · Evidence hygiene:** Check the “Offline distribution package” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M09.02-C060-T09 · Reproduction review:** Have the “Offline distribution package” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M09.02-C060-T10 · Acceptance linkage:** Link the “Offline distribution package” evidence to its parent and UC-M09.02 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 07. Trusted state persistence

**Source delivery:** Persist the last approved version and trust state across installer restarts.

**Source invariant:** Restart cannot reset anti-rollback memory accidentally.

**Source negative case:** An interrupted update loses its stored highest approved version.

**Source bounded quantities:** State records and durable-write latency.

### UC-M09.02-C061 · Contract

**Original checklist item:** Specify trusted state persistence inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M09.02-C061-T01 · Scope statement:** Draft the operation boundary for “Trusted state persistence” within Anti-rollback update metadata; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M09.02-C061-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Trusted state persistence”; record each producer, representation and missing-value meaning.
- [ ] **UC-M09.02-C061-T03 · Output inventory:** List the outputs of “Trusted state persistence” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M09.02-C061-T04 · Field dictionary:** Create a field-and-term dictionary for “Trusted state persistence”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M09.02-C061-T05 · Prerequisite contract:** Map “Trusted state persistence” to the source component prerequisites (UC-M09.01); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M09.02-C061-T06 · Authority map:** Identify who may produce, change and consume “Trusted state persistence”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M09.02-C061-T07 · Invariant clause:** Add a normative clause for “Trusted state persistence” that preserves “Restart cannot reset anti-rollback memory accidentally”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M09.02-C061-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Trusted state persistence”; include the source counterexample “An interrupted update loses its stored highest approved version” and the intended safe disposition.
- [ ] **UC-M09.02-C061-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “State records and durable-write latency” in the “Trusted state persistence” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M09.02-C061-T10 · Contract review:** Review the “Trusted state persistence” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M09.02-C062 · Delivery

**Original checklist item:** Persist the last approved version and trust state across installer restarts.

- [ ] **UC-M09.02-C062-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Trusted state persistence”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M09.02-C062-T02 · Change plan:** Break the source delivery for “Trusted state persistence” into concrete edit targets and reviewable outputs; keep the UC-M09.02 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M09.02-C062-T03 · Core artifact:** Implement the smallest selected-profile change for “Trusted state persistence” that realizes this source instruction: Persist the last approved version and trust state across installer restarts.
- [ ] **UC-M09.02-C062-T04 · Concrete realization:** Trace “Trusted state persistence” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M09.02-C062-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Trusted state persistence” needed to preserve “Restart cannot reset anti-rollback memory accidentally”; record an enforcement gap where only a model exists.
- [ ] **UC-M09.02-C062-T06 · Dependency connection:** Connect the “Trusted state persistence” implementation to authenticated update metadata, persisted approved versions and installer staging; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M09.02-C062-T07 · Resource behavior:** Account for “State records and durable-write latency” in “Trusted state persistence”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M09.02-C062-T08 · Delivery check:** Run the smallest real “Trusted state persistence” path and its adverse fixture “An interrupted update loses its stored highest approved version”; retain actual output, state effects and final disposition.
- [ ] **UC-M09.02-C062-T09 · Patch review:** Review the “Trusted state persistence” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M09.02-C062-T10 · Delivery handoff:** Publish the “Trusted state persistence” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M09.02-C063 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Restart cannot reset anti-rollback memory accidentally. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M09.02-C063-T01 · Named property:** Create a stable property/check name under this parent for “Trusted state persistence”; copy its required invariant exactly: “Restart cannot reset anti-rollback memory accidentally”.
- [ ] **UC-M09.02-C063-T02 · Observable terms:** Define each term in the “Trusted state persistence” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M09.02-C063-T03 · Precondition set:** List the preconditions under which “Restart cannot reset anti-rollback memory accidentally” must hold for “Trusted state persistence”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M09.02-C063-T04 · Transition coverage:** Map the “Trusted state persistence” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M09.02-C063-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Trusted state persistence”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M09.02-C063-T06 · Satisfying fixture:** Create a concrete “Trusted state persistence” case that satisfies “Restart cannot reset anti-rollback memory accidentally”; record its expected observation before running the assertion or review.
- [ ] **UC-M09.02-C063-T07 · Violating fixture:** Create the source counterexample “An interrupted update loses its stored highest approved version” for “Trusted state persistence”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M09.02-C063-T08 · Enforcement evidence:** Exercise the “Trusted state persistence” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M09.02-C063-T09 · Regression linkage:** Link the “Trusted state persistence” property to changes in authenticated update metadata, persisted approved versions and installer staging; record which dependency or contract changes require rerunning it.
- [ ] **UC-M09.02-C063-T10 · Property disposition:** Compare the satisfying and violating “Trusted state persistence” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M09.02-C064 · Integration

**Original checklist item:** Integrate trusted state persistence with authenticated update metadata, persisted approved versions and installer staging; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M09.02-C064-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Trusted state persistence” across authenticated update metadata, persisted approved versions and installer staging; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M09.02-C064-T02 · Field mapping:** Map every “Trusted state persistence” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M09.02-C064-T03 · Prerequisite identities:** Record the actual prerequisites for “Trusted state persistence” (source dependency list: UC-M09.01); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M09.02-C064-T04 · Ownership agreement:** Specify who owns “Trusted state persistence” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M09.02-C064-T05 · Handoff implementation:** Connect “Trusted state persistence” through the mapped seam using the real adapter or explicit specification reference; preserve “Restart cannot reset anti-rollback memory accidentally” across the handoff.
- [ ] **UC-M09.02-C064-T06 · Absent-input case:** Omit one required “Trusted state persistence” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M09.02-C064-T07 · Stale-input case:** Supply an outdated “Trusted state persistence” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M09.02-C064-T08 · Incompatible-input case:** Supply an incompatible “Trusted state persistence” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M09.02-C064-T09 · Valid integration trace:** Run a valid “Trusted state persistence” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M09.02-C064-T10 · Seam review:** Reconcile the “Trusted state persistence” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M09.02-C065 · Valid-case test

**Original checklist item:** Run a valid-path fixture for trusted state persistence; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M09.02-C065-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Trusted state persistence” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M09.02-C065-T02 · Expected-result oracle:** Specify the “Trusted state persistence” expected result independently of the implementation output; include the property “Restart cannot reset anti-rollback memory accidentally” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M09.02-C065-T03 · Fixture material:** Create the concrete “Trusted state persistence” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M09.02-C065-T04 · Target preparation:** Prepare the “Trusted state persistence” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M09.02-C065-T05 · Initial-state record:** Record the initial “Trusted state persistence” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M09.02-C065-T06 · Valid-path execution:** Execute the “Trusted state persistence” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M09.02-C065-T07 · Outcome comparison:** Compare every declared “Trusted state persistence” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M09.02-C065-T08 · State and bounds check:** Inspect the “Trusted state persistence” ownership/state effects and actual use of “State records and durable-write latency”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M09.02-C065-T09 · Repeatability check:** Repeat the same “Trusted state persistence” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M09.02-C065-T10 · Positive evidence:** Attach the “Trusted state persistence” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M09.02-C066 · Negative test

**Original checklist item:** Negative case: An interrupted update loses its stored highest approved version. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M09.02-C066-T01 · Adverse-case definition:** Create a test record for the exact “Trusted state persistence” source counterexample: “An interrupted update loses its stored highest approved version”; state which precondition or invariant it challenges.
- [ ] **UC-M09.02-C066-T02 · Safe fixture boundary:** Define the contained test boundary for “Trusted state persistence”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M09.02-C066-T03 · Valid control:** Construct a valid “Trusted state persistence” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M09.02-C066-T04 · Minimal adverse input:** Derive the “Trusted state persistence” adverse fixture from the control with the smallest documented change needed to reproduce “An interrupted update loses its stored highest approved version”; retain that change as reproducible data.
- [ ] **UC-M09.02-C066-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Trusted state persistence”; require “Restart cannot reset anti-rollback memory accidentally” and forbid a false-success verdict.
- [ ] **UC-M09.02-C066-T06 · Adverse execution:** Exercise the “Trusted state persistence” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M09.02-C066-T07 · Effect inspection:** Inspect “Trusted state persistence” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M09.02-C066-T08 · Refusal versus failure:** Confirm the “Trusted state persistence” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M09.02-C066-T09 · Reset and retention:** Restore only the disposable “Trusted state persistence” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M09.02-C066-T10 · Negative regression:** Register the “Trusted state persistence” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M09.02-C067 · Change / failure test

**Original checklist item:** Exercise trusted state persistence when an offline update is interrupted and then retried with older signed metadata; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M09.02-C067-T01 · Scenario record:** Write the “Trusted state persistence” change/failure scenario exactly as supplied: an offline update is interrupted and then retried with older signed metadata; identify the property that must remain true: “Restart cannot reset anti-rollback memory accidentally”.
- [ ] **UC-M09.02-C067-T02 · Baseline capture:** Create a known-valid “Trusted state persistence” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M09.02-C067-T03 · Injection map:** Locate the “Trusted state persistence” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M09.02-C067-T04 · Disposition oracle:** Define the legal intermediate and final “Trusted state persistence” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M09.02-C067-T05 · Controlled trigger:** Introduce the controlled “Trusted state persistence” scenario in the disposable fixture: an offline update is interrupted and then retried with older signed metadata; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M09.02-C067-T06 · Intermediate inspection:** Inspect the “Trusted state persistence” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M09.02-C067-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Trusted state persistence”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M09.02-C067-T08 · Stale-evidence cleanup:** Invalidate superseded “Trusted state persistence” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M09.02-C067-T09 · Repeat and compare:** Repeat the selected “Trusted state persistence” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M09.02-C067-T10 · Failure evidence:** Publish the “Trusted state persistence” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M09.02-C068 · Bounds

**Original checklist item:** Choose, document and test limits for state records and durable-write latency; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M09.02-C068-T01 · Quantity inventory:** Create a measurement inventory for “Trusted state persistence”: “State records and durable-write latency”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M09.02-C068-T02 · Measurement method:** Choose how to observe each “Trusted state persistence” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M09.02-C068-T03 · Budget decision:** Select justified resource and input limits for “Trusted state persistence”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M09.02-C068-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Trusted state persistence” cases for “State records and durable-write latency”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M09.02-C068-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Trusted state persistence” limit; preserve “Restart cannot reset anti-rollback memory accidentally”.
- [ ] **UC-M09.02-C068-T06 · Normal measurement:** Run or review the normal “Trusted state persistence” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M09.02-C068-T07 · At-limit measurement:** Exercise the “Trusted state persistence” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M09.02-C068-T08 · Over-limit measurement:** Exercise the “Trusted state persistence” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M09.02-C068-T09 · Uncovered-scope report:** List the “Trusted state persistence” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M09.02-C068-T10 · Limit evidence:** Publish the selected “Trusted state persistence” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M09.02-C069 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for trusted state persistence with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M09.02-C069-T01 · Event inventory:** List the “Trusted state persistence” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M09.02-C069-T02 · Diagnostic schema:** Define nonsecret fields for “Trusted state persistence” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M09.02-C069-T03 · Failure mapping:** Map each documented “Trusted state persistence” refusal or error to a diagnostic outcome; include “An interrupted update loses its stored highest approved version” and prohibit conversion into a success message.
- [ ] **UC-M09.02-C069-T04 · Emission path:** Add the “Trusted state persistence” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M09.02-C069-T05 · Redaction check:** Test “Trusted state persistence” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M09.02-C069-T06 · Output budget:** Set and exercise bounded “Trusted state persistence” message size, rate and retention compatible with “State records and durable-write latency”; define truncation behavior that preserves the final reason.
- [ ] **UC-M09.02-C069-T07 · Success/refusal fixtures:** Capture “Trusted state persistence” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M09.02-C069-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Trusted state persistence” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M09.02-C069-T09 · Operator review:** Read the “Trusted state persistence” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M09.02-C069-T10 · Diagnostic evidence:** Publish redacted “Trusted state persistence” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M09.02-C070 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for trusted state persistence; label unexecuted checks as untested.

- [ ] **UC-M09.02-C070-T01 · Evidence inventory:** List the “Trusted state persistence” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M09.02-C070-T02 · Artifact references:** Record the exact “Trusted state persistence” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M09.02-C070-T03 · Fixture references:** Attach the “Trusted state persistence” fixture IDs, input identities and oracle definition; preserve the source counterexample “An interrupted update loses its stored highest approved version” as a distinct evidence case.
- [ ] **UC-M09.02-C070-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Trusted state persistence”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M09.02-C070-T05 · Environment record:** Record the actual “Trusted state persistence” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M09.02-C070-T06 · Expected versus observed:** Pair every “Trusted state persistence” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M09.02-C070-T07 · Failure and limit records:** Attach “Trusted state persistence” change/failure and bounds evidence where required; include uncovered “State records and durable-write latency” and unresolved violations of “Restart cannot reset anti-rollback memory accidentally”.
- [ ] **UC-M09.02-C070-T08 · Evidence hygiene:** Check the “Trusted state persistence” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M09.02-C070-T09 · Reproduction review:** Have the “Trusted state persistence” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M09.02-C070-T10 · Acceptance linkage:** Link the “Trusted state persistence” evidence to its parent and UC-M09.02 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 08. Clock uncertainty disposition

**Source delivery:** Define refusal or explicit operator handling when expiry cannot be evaluated reliably.

**Source invariant:** Unknown time cannot be treated silently as proof of freshness.

**Source negative case:** A host with an invalid clock accepts expired metadata as fresh.

**Source bounded quantities:** Uncertainty range and operator exception records.

### UC-M09.02-C071 · Contract

**Original checklist item:** Specify clock uncertainty disposition inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M09.02-C071-T01 · Scope statement:** Draft the operation boundary for “Clock uncertainty disposition” within Anti-rollback update metadata; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M09.02-C071-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Clock uncertainty disposition”; record each producer, representation and missing-value meaning.
- [ ] **UC-M09.02-C071-T03 · Output inventory:** List the outputs of “Clock uncertainty disposition” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M09.02-C071-T04 · Field dictionary:** Create a field-and-term dictionary for “Clock uncertainty disposition”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M09.02-C071-T05 · Prerequisite contract:** Map “Clock uncertainty disposition” to the source component prerequisites (UC-M09.01); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M09.02-C071-T06 · Authority map:** Identify who may produce, change and consume “Clock uncertainty disposition”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M09.02-C071-T07 · Invariant clause:** Add a normative clause for “Clock uncertainty disposition” that preserves “Unknown time cannot be treated silently as proof of freshness”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M09.02-C071-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Clock uncertainty disposition”; include the source counterexample “A host with an invalid clock accepts expired metadata as fresh” and the intended safe disposition.
- [ ] **UC-M09.02-C071-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Uncertainty range and operator exception records” in the “Clock uncertainty disposition” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M09.02-C071-T10 · Contract review:** Review the “Clock uncertainty disposition” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M09.02-C072 · Delivery

**Original checklist item:** Define refusal or explicit operator handling when expiry cannot be evaluated reliably.

- [ ] **UC-M09.02-C072-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Clock uncertainty disposition”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M09.02-C072-T02 · Change plan:** Break the source delivery for “Clock uncertainty disposition” into concrete edit targets and reviewable outputs; keep the UC-M09.02 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M09.02-C072-T03 · Core artifact:** Create the “Clock uncertainty disposition” model, schema or inventory that realizes this source instruction: Define refusal or explicit operator handling when expiry cannot be evaluated reliably.
- [ ] **UC-M09.02-C072-T04 · Concrete realization:** Populate “Clock uncertainty disposition” with one concrete worked case; map every required entity or field to its source and flag any unmapped entry.
- [ ] **UC-M09.02-C072-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Clock uncertainty disposition” needed to preserve “Unknown time cannot be treated silently as proof of freshness”; record an enforcement gap where only a model exists.
- [ ] **UC-M09.02-C072-T06 · Dependency connection:** Connect the “Clock uncertainty disposition” implementation to authenticated update metadata, persisted approved versions and installer staging; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M09.02-C072-T07 · Resource behavior:** Account for “Uncertainty range and operator exception records” in “Clock uncertainty disposition”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M09.02-C072-T08 · Delivery check:** Run the smallest real “Clock uncertainty disposition” path and its adverse fixture “A host with an invalid clock accepts expired metadata as fresh”; retain actual output, state effects and final disposition.
- [ ] **UC-M09.02-C072-T09 · Patch review:** Review the “Clock uncertainty disposition” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M09.02-C072-T10 · Delivery handoff:** Publish the “Clock uncertainty disposition” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M09.02-C073 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Unknown time cannot be treated silently as proof of freshness. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M09.02-C073-T01 · Named property:** Create a stable property/check name under this parent for “Clock uncertainty disposition”; copy its required invariant exactly: “Unknown time cannot be treated silently as proof of freshness”.
- [ ] **UC-M09.02-C073-T02 · Observable terms:** Define each term in the “Clock uncertainty disposition” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M09.02-C073-T03 · Precondition set:** List the preconditions under which “Unknown time cannot be treated silently as proof of freshness” must hold for “Clock uncertainty disposition”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M09.02-C073-T04 · Transition coverage:** Map the “Clock uncertainty disposition” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M09.02-C073-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Clock uncertainty disposition”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M09.02-C073-T06 · Satisfying fixture:** Create a concrete “Clock uncertainty disposition” case that satisfies “Unknown time cannot be treated silently as proof of freshness”; record its expected observation before running the assertion or review.
- [ ] **UC-M09.02-C073-T07 · Violating fixture:** Create the source counterexample “A host with an invalid clock accepts expired metadata as fresh” for “Clock uncertainty disposition”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M09.02-C073-T08 · Enforcement evidence:** Exercise the “Clock uncertainty disposition” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M09.02-C073-T09 · Regression linkage:** Link the “Clock uncertainty disposition” property to changes in authenticated update metadata, persisted approved versions and installer staging; record which dependency or contract changes require rerunning it.
- [ ] **UC-M09.02-C073-T10 · Property disposition:** Compare the satisfying and violating “Clock uncertainty disposition” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M09.02-C074 · Integration

**Original checklist item:** Integrate clock uncertainty disposition with authenticated update metadata, persisted approved versions and installer staging; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M09.02-C074-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Clock uncertainty disposition” across authenticated update metadata, persisted approved versions and installer staging; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M09.02-C074-T02 · Field mapping:** Map every “Clock uncertainty disposition” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M09.02-C074-T03 · Prerequisite identities:** Record the actual prerequisites for “Clock uncertainty disposition” (source dependency list: UC-M09.01); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M09.02-C074-T04 · Ownership agreement:** Specify who owns “Clock uncertainty disposition” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M09.02-C074-T05 · Handoff implementation:** Connect “Clock uncertainty disposition” through the mapped seam using the real adapter or explicit specification reference; preserve “Unknown time cannot be treated silently as proof of freshness” across the handoff.
- [ ] **UC-M09.02-C074-T06 · Absent-input case:** Omit one required “Clock uncertainty disposition” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M09.02-C074-T07 · Stale-input case:** Supply an outdated “Clock uncertainty disposition” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M09.02-C074-T08 · Incompatible-input case:** Supply an incompatible “Clock uncertainty disposition” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M09.02-C074-T09 · Valid integration trace:** Run a valid “Clock uncertainty disposition” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M09.02-C074-T10 · Seam review:** Reconcile the “Clock uncertainty disposition” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M09.02-C075 · Valid-case test

**Original checklist item:** Run a valid-path fixture for clock uncertainty disposition; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M09.02-C075-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Clock uncertainty disposition” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M09.02-C075-T02 · Expected-result oracle:** Specify the “Clock uncertainty disposition” expected result independently of the implementation output; include the property “Unknown time cannot be treated silently as proof of freshness” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M09.02-C075-T03 · Fixture material:** Create the concrete “Clock uncertainty disposition” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M09.02-C075-T04 · Target preparation:** Prepare the “Clock uncertainty disposition” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M09.02-C075-T05 · Initial-state record:** Record the initial “Clock uncertainty disposition” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M09.02-C075-T06 · Valid-path execution:** Execute the “Clock uncertainty disposition” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M09.02-C075-T07 · Outcome comparison:** Compare every declared “Clock uncertainty disposition” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M09.02-C075-T08 · State and bounds check:** Inspect the “Clock uncertainty disposition” ownership/state effects and actual use of “Uncertainty range and operator exception records”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M09.02-C075-T09 · Repeatability check:** Repeat the same “Clock uncertainty disposition” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M09.02-C075-T10 · Positive evidence:** Attach the “Clock uncertainty disposition” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M09.02-C076 · Negative test

**Original checklist item:** Negative case: A host with an invalid clock accepts expired metadata as fresh. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M09.02-C076-T01 · Adverse-case definition:** Create a test record for the exact “Clock uncertainty disposition” source counterexample: “A host with an invalid clock accepts expired metadata as fresh”; state which precondition or invariant it challenges.
- [ ] **UC-M09.02-C076-T02 · Safe fixture boundary:** Define the contained test boundary for “Clock uncertainty disposition”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M09.02-C076-T03 · Valid control:** Construct a valid “Clock uncertainty disposition” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M09.02-C076-T04 · Minimal adverse input:** Derive the “Clock uncertainty disposition” adverse fixture from the control with the smallest documented change needed to reproduce “A host with an invalid clock accepts expired metadata as fresh”; retain that change as reproducible data.
- [ ] **UC-M09.02-C076-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Clock uncertainty disposition”; require “Unknown time cannot be treated silently as proof of freshness” and forbid a false-success verdict.
- [ ] **UC-M09.02-C076-T06 · Adverse execution:** Exercise the “Clock uncertainty disposition” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M09.02-C076-T07 · Effect inspection:** Inspect “Clock uncertainty disposition” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M09.02-C076-T08 · Refusal versus failure:** Confirm the “Clock uncertainty disposition” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M09.02-C076-T09 · Reset and retention:** Restore only the disposable “Clock uncertainty disposition” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M09.02-C076-T10 · Negative regression:** Register the “Clock uncertainty disposition” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M09.02-C077 · Change / failure test

**Original checklist item:** Exercise clock uncertainty disposition when an offline update is interrupted and then retried with older signed metadata; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M09.02-C077-T01 · Scenario record:** Write the “Clock uncertainty disposition” change/failure scenario exactly as supplied: an offline update is interrupted and then retried with older signed metadata; identify the property that must remain true: “Unknown time cannot be treated silently as proof of freshness”.
- [ ] **UC-M09.02-C077-T02 · Baseline capture:** Create a known-valid “Clock uncertainty disposition” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M09.02-C077-T03 · Injection map:** Locate the “Clock uncertainty disposition” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M09.02-C077-T04 · Disposition oracle:** Define the legal intermediate and final “Clock uncertainty disposition” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M09.02-C077-T05 · Controlled trigger:** Introduce the controlled “Clock uncertainty disposition” scenario in the disposable fixture: an offline update is interrupted and then retried with older signed metadata; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M09.02-C077-T06 · Intermediate inspection:** Inspect the “Clock uncertainty disposition” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M09.02-C077-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Clock uncertainty disposition”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M09.02-C077-T08 · Stale-evidence cleanup:** Invalidate superseded “Clock uncertainty disposition” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M09.02-C077-T09 · Repeat and compare:** Repeat the selected “Clock uncertainty disposition” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M09.02-C077-T10 · Failure evidence:** Publish the “Clock uncertainty disposition” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M09.02-C078 · Bounds

**Original checklist item:** Choose, document and test limits for uncertainty range and operator exception records; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M09.02-C078-T01 · Quantity inventory:** Create a measurement inventory for “Clock uncertainty disposition”: “Uncertainty range and operator exception records”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M09.02-C078-T02 · Measurement method:** Choose how to observe each “Clock uncertainty disposition” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M09.02-C078-T03 · Budget decision:** Select justified resource and input limits for “Clock uncertainty disposition”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M09.02-C078-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Clock uncertainty disposition” cases for “Uncertainty range and operator exception records”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M09.02-C078-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Clock uncertainty disposition” limit; preserve “Unknown time cannot be treated silently as proof of freshness”.
- [ ] **UC-M09.02-C078-T06 · Normal measurement:** Run or review the normal “Clock uncertainty disposition” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M09.02-C078-T07 · At-limit measurement:** Exercise the “Clock uncertainty disposition” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M09.02-C078-T08 · Over-limit measurement:** Exercise the “Clock uncertainty disposition” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M09.02-C078-T09 · Uncovered-scope report:** List the “Clock uncertainty disposition” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M09.02-C078-T10 · Limit evidence:** Publish the selected “Clock uncertainty disposition” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M09.02-C079 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for clock uncertainty disposition with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M09.02-C079-T01 · Event inventory:** List the “Clock uncertainty disposition” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M09.02-C079-T02 · Diagnostic schema:** Define nonsecret fields for “Clock uncertainty disposition” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M09.02-C079-T03 · Failure mapping:** Map each documented “Clock uncertainty disposition” refusal or error to a diagnostic outcome; include “A host with an invalid clock accepts expired metadata as fresh” and prohibit conversion into a success message.
- [ ] **UC-M09.02-C079-T04 · Emission path:** Add the “Clock uncertainty disposition” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M09.02-C079-T05 · Redaction check:** Test “Clock uncertainty disposition” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M09.02-C079-T06 · Output budget:** Set and exercise bounded “Clock uncertainty disposition” message size, rate and retention compatible with “Uncertainty range and operator exception records”; define truncation behavior that preserves the final reason.
- [ ] **UC-M09.02-C079-T07 · Success/refusal fixtures:** Capture “Clock uncertainty disposition” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M09.02-C079-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Clock uncertainty disposition” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M09.02-C079-T09 · Operator review:** Read the “Clock uncertainty disposition” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M09.02-C079-T10 · Diagnostic evidence:** Publish redacted “Clock uncertainty disposition” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M09.02-C080 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for clock uncertainty disposition; label unexecuted checks as untested.

- [ ] **UC-M09.02-C080-T01 · Evidence inventory:** List the “Clock uncertainty disposition” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M09.02-C080-T02 · Artifact references:** Record the exact “Clock uncertainty disposition” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M09.02-C080-T03 · Fixture references:** Attach the “Clock uncertainty disposition” fixture IDs, input identities and oracle definition; preserve the source counterexample “A host with an invalid clock accepts expired metadata as fresh” as a distinct evidence case.
- [ ] **UC-M09.02-C080-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Clock uncertainty disposition”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M09.02-C080-T05 · Environment record:** Record the actual “Clock uncertainty disposition” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M09.02-C080-T06 · Expected versus observed:** Pair every “Clock uncertainty disposition” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M09.02-C080-T07 · Failure and limit records:** Attach “Clock uncertainty disposition” change/failure and bounds evidence where required; include uncovered “Uncertainty range and operator exception records” and unresolved violations of “Unknown time cannot be treated silently as proof of freshness”.
- [ ] **UC-M09.02-C080-T08 · Evidence hygiene:** Check the “Clock uncertainty disposition” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M09.02-C080-T09 · Reproduction review:** Have the “Clock uncertainty disposition” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M09.02-C080-T10 · Acceptance linkage:** Link the “Clock uncertainty disposition” evidence to its parent and UC-M09.02 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 09. Metadata failure recovery

**Source delivery:** Preserve the current approved release when new metadata is invalid or incomplete.

**Source invariant:** Invalid updates cannot damage a working approved installation.

**Source negative case:** Metadata verification fails after replacing live program files.

**Source bounded quantities:** Staging bytes and rollback deadline.

### UC-M09.02-C081 · Contract

**Original checklist item:** Specify metadata failure recovery inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M09.02-C081-T01 · Scope statement:** Draft the operation boundary for “Metadata failure recovery” within Anti-rollback update metadata; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M09.02-C081-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Metadata failure recovery”; record each producer, representation and missing-value meaning.
- [ ] **UC-M09.02-C081-T03 · Output inventory:** List the outputs of “Metadata failure recovery” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M09.02-C081-T04 · Field dictionary:** Create a field-and-term dictionary for “Metadata failure recovery”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M09.02-C081-T05 · Prerequisite contract:** Map “Metadata failure recovery” to the source component prerequisites (UC-M09.01); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M09.02-C081-T06 · Authority map:** Identify who may produce, change and consume “Metadata failure recovery”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M09.02-C081-T07 · Invariant clause:** Add a normative clause for “Metadata failure recovery” that preserves “Invalid updates cannot damage a working approved installation”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M09.02-C081-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Metadata failure recovery”; include the source counterexample “Metadata verification fails after replacing live program files” and the intended safe disposition.
- [ ] **UC-M09.02-C081-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Staging bytes and rollback deadline” in the “Metadata failure recovery” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M09.02-C081-T10 · Contract review:** Review the “Metadata failure recovery” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M09.02-C082 · Delivery

**Original checklist item:** Preserve the current approved release when new metadata is invalid or incomplete.

- [ ] **UC-M09.02-C082-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Metadata failure recovery”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M09.02-C082-T02 · Change plan:** Break the source delivery for “Metadata failure recovery” into concrete edit targets and reviewable outputs; keep the UC-M09.02 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M09.02-C082-T03 · Core artifact:** Implement the smallest selected-profile change for “Metadata failure recovery” that realizes this source instruction: Preserve the current approved release when new metadata is invalid or incomplete.
- [ ] **UC-M09.02-C082-T04 · Concrete realization:** Trace “Metadata failure recovery” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M09.02-C082-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Metadata failure recovery” needed to preserve “Invalid updates cannot damage a working approved installation”; record an enforcement gap where only a model exists.
- [ ] **UC-M09.02-C082-T06 · Dependency connection:** Connect the “Metadata failure recovery” implementation to authenticated update metadata, persisted approved versions and installer staging; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M09.02-C082-T07 · Resource behavior:** Account for “Staging bytes and rollback deadline” in “Metadata failure recovery”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M09.02-C082-T08 · Delivery check:** Run the smallest real “Metadata failure recovery” path and its adverse fixture “Metadata verification fails after replacing live program files”; retain actual output, state effects and final disposition.
- [ ] **UC-M09.02-C082-T09 · Patch review:** Review the “Metadata failure recovery” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M09.02-C082-T10 · Delivery handoff:** Publish the “Metadata failure recovery” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M09.02-C083 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Invalid updates cannot damage a working approved installation. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M09.02-C083-T01 · Named property:** Create a stable property/check name under this parent for “Metadata failure recovery”; copy its required invariant exactly: “Invalid updates cannot damage a working approved installation”.
- [ ] **UC-M09.02-C083-T02 · Observable terms:** Define each term in the “Metadata failure recovery” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M09.02-C083-T03 · Precondition set:** List the preconditions under which “Invalid updates cannot damage a working approved installation” must hold for “Metadata failure recovery”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M09.02-C083-T04 · Transition coverage:** Map the “Metadata failure recovery” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M09.02-C083-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Metadata failure recovery”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M09.02-C083-T06 · Satisfying fixture:** Create a concrete “Metadata failure recovery” case that satisfies “Invalid updates cannot damage a working approved installation”; record its expected observation before running the assertion or review.
- [ ] **UC-M09.02-C083-T07 · Violating fixture:** Create the source counterexample “Metadata verification fails after replacing live program files” for “Metadata failure recovery”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M09.02-C083-T08 · Enforcement evidence:** Exercise the “Metadata failure recovery” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M09.02-C083-T09 · Regression linkage:** Link the “Metadata failure recovery” property to changes in authenticated update metadata, persisted approved versions and installer staging; record which dependency or contract changes require rerunning it.
- [ ] **UC-M09.02-C083-T10 · Property disposition:** Compare the satisfying and violating “Metadata failure recovery” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M09.02-C084 · Integration

**Original checklist item:** Integrate metadata failure recovery with authenticated update metadata, persisted approved versions and installer staging; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M09.02-C084-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Metadata failure recovery” across authenticated update metadata, persisted approved versions and installer staging; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M09.02-C084-T02 · Field mapping:** Map every “Metadata failure recovery” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M09.02-C084-T03 · Prerequisite identities:** Record the actual prerequisites for “Metadata failure recovery” (source dependency list: UC-M09.01); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M09.02-C084-T04 · Ownership agreement:** Specify who owns “Metadata failure recovery” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M09.02-C084-T05 · Handoff implementation:** Connect “Metadata failure recovery” through the mapped seam using the real adapter or explicit specification reference; preserve “Invalid updates cannot damage a working approved installation” across the handoff.
- [ ] **UC-M09.02-C084-T06 · Absent-input case:** Omit one required “Metadata failure recovery” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M09.02-C084-T07 · Stale-input case:** Supply an outdated “Metadata failure recovery” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M09.02-C084-T08 · Incompatible-input case:** Supply an incompatible “Metadata failure recovery” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M09.02-C084-T09 · Valid integration trace:** Run a valid “Metadata failure recovery” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M09.02-C084-T10 · Seam review:** Reconcile the “Metadata failure recovery” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M09.02-C085 · Valid-case test

**Original checklist item:** Run a valid-path fixture for metadata failure recovery; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M09.02-C085-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Metadata failure recovery” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M09.02-C085-T02 · Expected-result oracle:** Specify the “Metadata failure recovery” expected result independently of the implementation output; include the property “Invalid updates cannot damage a working approved installation” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M09.02-C085-T03 · Fixture material:** Create the concrete “Metadata failure recovery” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M09.02-C085-T04 · Target preparation:** Prepare the “Metadata failure recovery” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M09.02-C085-T05 · Initial-state record:** Record the initial “Metadata failure recovery” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M09.02-C085-T06 · Valid-path execution:** Execute the “Metadata failure recovery” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M09.02-C085-T07 · Outcome comparison:** Compare every declared “Metadata failure recovery” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M09.02-C085-T08 · State and bounds check:** Inspect the “Metadata failure recovery” ownership/state effects and actual use of “Staging bytes and rollback deadline”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M09.02-C085-T09 · Repeatability check:** Repeat the same “Metadata failure recovery” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M09.02-C085-T10 · Positive evidence:** Attach the “Metadata failure recovery” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M09.02-C086 · Negative test

**Original checklist item:** Negative case: Metadata verification fails after replacing live program files. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M09.02-C086-T01 · Adverse-case definition:** Create a test record for the exact “Metadata failure recovery” source counterexample: “Metadata verification fails after replacing live program files”; state which precondition or invariant it challenges.
- [ ] **UC-M09.02-C086-T02 · Safe fixture boundary:** Define the contained test boundary for “Metadata failure recovery”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M09.02-C086-T03 · Valid control:** Construct a valid “Metadata failure recovery” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M09.02-C086-T04 · Minimal adverse input:** Derive the “Metadata failure recovery” adverse fixture from the control with the smallest documented change needed to reproduce “Metadata verification fails after replacing live program files”; retain that change as reproducible data.
- [ ] **UC-M09.02-C086-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Metadata failure recovery”; require “Invalid updates cannot damage a working approved installation” and forbid a false-success verdict.
- [ ] **UC-M09.02-C086-T06 · Adverse execution:** Exercise the “Metadata failure recovery” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M09.02-C086-T07 · Effect inspection:** Inspect “Metadata failure recovery” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M09.02-C086-T08 · Refusal versus failure:** Confirm the “Metadata failure recovery” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M09.02-C086-T09 · Reset and retention:** Restore only the disposable “Metadata failure recovery” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M09.02-C086-T10 · Negative regression:** Register the “Metadata failure recovery” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M09.02-C087 · Change / failure test

**Original checklist item:** Exercise metadata failure recovery when an offline update is interrupted and then retried with older signed metadata; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M09.02-C087-T01 · Scenario record:** Write the “Metadata failure recovery” change/failure scenario exactly as supplied: an offline update is interrupted and then retried with older signed metadata; identify the property that must remain true: “Invalid updates cannot damage a working approved installation”.
- [ ] **UC-M09.02-C087-T02 · Baseline capture:** Create a known-valid “Metadata failure recovery” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M09.02-C087-T03 · Injection map:** Locate the “Metadata failure recovery” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M09.02-C087-T04 · Disposition oracle:** Define the legal intermediate and final “Metadata failure recovery” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M09.02-C087-T05 · Controlled trigger:** Introduce the controlled “Metadata failure recovery” scenario in the disposable fixture: an offline update is interrupted and then retried with older signed metadata; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M09.02-C087-T06 · Intermediate inspection:** Inspect the “Metadata failure recovery” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M09.02-C087-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Metadata failure recovery”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M09.02-C087-T08 · Stale-evidence cleanup:** Invalidate superseded “Metadata failure recovery” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M09.02-C087-T09 · Repeat and compare:** Repeat the selected “Metadata failure recovery” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M09.02-C087-T10 · Failure evidence:** Publish the “Metadata failure recovery” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M09.02-C088 · Bounds

**Original checklist item:** Choose, document and test limits for staging bytes and rollback deadline; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M09.02-C088-T01 · Quantity inventory:** Create a measurement inventory for “Metadata failure recovery”: “Staging bytes and rollback deadline”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M09.02-C088-T02 · Measurement method:** Choose how to observe each “Metadata failure recovery” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M09.02-C088-T03 · Budget decision:** Select justified resource and input limits for “Metadata failure recovery”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M09.02-C088-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Metadata failure recovery” cases for “Staging bytes and rollback deadline”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M09.02-C088-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Metadata failure recovery” limit; preserve “Invalid updates cannot damage a working approved installation”.
- [ ] **UC-M09.02-C088-T06 · Normal measurement:** Run or review the normal “Metadata failure recovery” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M09.02-C088-T07 · At-limit measurement:** Exercise the “Metadata failure recovery” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M09.02-C088-T08 · Over-limit measurement:** Exercise the “Metadata failure recovery” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M09.02-C088-T09 · Uncovered-scope report:** List the “Metadata failure recovery” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M09.02-C088-T10 · Limit evidence:** Publish the selected “Metadata failure recovery” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M09.02-C089 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for metadata failure recovery with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M09.02-C089-T01 · Event inventory:** List the “Metadata failure recovery” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M09.02-C089-T02 · Diagnostic schema:** Define nonsecret fields for “Metadata failure recovery” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M09.02-C089-T03 · Failure mapping:** Map each documented “Metadata failure recovery” refusal or error to a diagnostic outcome; include “Metadata verification fails after replacing live program files” and prohibit conversion into a success message.
- [ ] **UC-M09.02-C089-T04 · Emission path:** Add the “Metadata failure recovery” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M09.02-C089-T05 · Redaction check:** Test “Metadata failure recovery” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M09.02-C089-T06 · Output budget:** Set and exercise bounded “Metadata failure recovery” message size, rate and retention compatible with “Staging bytes and rollback deadline”; define truncation behavior that preserves the final reason.
- [ ] **UC-M09.02-C089-T07 · Success/refusal fixtures:** Capture “Metadata failure recovery” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M09.02-C089-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Metadata failure recovery” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M09.02-C089-T09 · Operator review:** Read the “Metadata failure recovery” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M09.02-C089-T10 · Diagnostic evidence:** Publish redacted “Metadata failure recovery” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M09.02-C090 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for metadata failure recovery; label unexecuted checks as untested.

- [ ] **UC-M09.02-C090-T01 · Evidence inventory:** List the “Metadata failure recovery” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M09.02-C090-T02 · Artifact references:** Record the exact “Metadata failure recovery” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M09.02-C090-T03 · Fixture references:** Attach the “Metadata failure recovery” fixture IDs, input identities and oracle definition; preserve the source counterexample “Metadata verification fails after replacing live program files” as a distinct evidence case.
- [ ] **UC-M09.02-C090-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Metadata failure recovery”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M09.02-C090-T05 · Environment record:** Record the actual “Metadata failure recovery” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M09.02-C090-T06 · Expected versus observed:** Pair every “Metadata failure recovery” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M09.02-C090-T07 · Failure and limit records:** Attach “Metadata failure recovery” change/failure and bounds evidence where required; include uncovered “Staging bytes and rollback deadline” and unresolved violations of “Invalid updates cannot damage a working approved installation”.
- [ ] **UC-M09.02-C090-T08 · Evidence hygiene:** Check the “Metadata failure recovery” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M09.02-C090-T09 · Reproduction review:** Have the “Metadata failure recovery” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M09.02-C090-T10 · Acceptance linkage:** Link the “Metadata failure recovery” evidence to its parent and UC-M09.02 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 10. Rollback attack fixtures

**Source delivery:** Exercise old, expired, inconsistent and altered update packages.

**Source invariant:** Each fixture is refused or follows the explicitly authorized exception policy.

**Source negative case:** An old signed package overwrites a newer approved release.

**Source bounded quantities:** Fixture count and installer test duration.

### UC-M09.02-C091 · Contract

**Original checklist item:** Specify rollback attack fixtures inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M09.02-C091-T01 · Scope statement:** Draft the operation boundary for “Rollback attack fixtures” within Anti-rollback update metadata; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M09.02-C091-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Rollback attack fixtures”; record each producer, representation and missing-value meaning.
- [ ] **UC-M09.02-C091-T03 · Output inventory:** List the outputs of “Rollback attack fixtures” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M09.02-C091-T04 · Field dictionary:** Create a field-and-term dictionary for “Rollback attack fixtures”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M09.02-C091-T05 · Prerequisite contract:** Map “Rollback attack fixtures” to the source component prerequisites (UC-M09.01); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M09.02-C091-T06 · Authority map:** Identify who may produce, change and consume “Rollback attack fixtures”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M09.02-C091-T07 · Invariant clause:** Add a normative clause for “Rollback attack fixtures” that preserves “Each fixture is refused or follows the explicitly authorized exception policy”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M09.02-C091-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Rollback attack fixtures”; include the source counterexample “An old signed package overwrites a newer approved release” and the intended safe disposition.
- [ ] **UC-M09.02-C091-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Fixture count and installer test duration” in the “Rollback attack fixtures” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M09.02-C091-T10 · Contract review:** Review the “Rollback attack fixtures” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M09.02-C092 · Delivery

**Original checklist item:** Exercise old, expired, inconsistent and altered update packages.

- [ ] **UC-M09.02-C092-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Rollback attack fixtures”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M09.02-C092-T02 · Change plan:** Break the source delivery for “Rollback attack fixtures” into concrete edit targets and reviewable outputs; keep the UC-M09.02 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M09.02-C092-T03 · Core artifact:** Create the “Rollback attack fixtures” fixture or harness for this source instruction: Exercise old, expired, inconsistent and altered update packages.
- [ ] **UC-M09.02-C092-T04 · Concrete realization:** Connect the “Rollback attack fixtures” harness to its actual intended target, set the expected oracle before running it, and distinguish a mock/control run from a target run.
- [ ] **UC-M09.02-C092-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Rollback attack fixtures” needed to preserve “Each fixture is refused or follows the explicitly authorized exception policy”; record an enforcement gap where only a model exists.
- [ ] **UC-M09.02-C092-T06 · Dependency connection:** Connect the “Rollback attack fixtures” implementation to authenticated update metadata, persisted approved versions and installer staging; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M09.02-C092-T07 · Resource behavior:** Account for “Fixture count and installer test duration” in “Rollback attack fixtures”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M09.02-C092-T08 · Delivery check:** Run the smallest real “Rollback attack fixtures” path and its adverse fixture “An old signed package overwrites a newer approved release”; retain actual output, state effects and final disposition.
- [ ] **UC-M09.02-C092-T09 · Patch review:** Review the “Rollback attack fixtures” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M09.02-C092-T10 · Delivery handoff:** Publish the “Rollback attack fixtures” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M09.02-C093 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Each fixture is refused or follows the explicitly authorized exception policy. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M09.02-C093-T01 · Named property:** Create a stable property/check name under this parent for “Rollback attack fixtures”; copy its required invariant exactly: “Each fixture is refused or follows the explicitly authorized exception policy”.
- [ ] **UC-M09.02-C093-T02 · Observable terms:** Define each term in the “Rollback attack fixtures” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M09.02-C093-T03 · Precondition set:** List the preconditions under which “Each fixture is refused or follows the explicitly authorized exception policy” must hold for “Rollback attack fixtures”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M09.02-C093-T04 · Transition coverage:** Map the “Rollback attack fixtures” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M09.02-C093-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Rollback attack fixtures”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M09.02-C093-T06 · Satisfying fixture:** Create a concrete “Rollback attack fixtures” case that satisfies “Each fixture is refused or follows the explicitly authorized exception policy”; record its expected observation before running the assertion or review.
- [ ] **UC-M09.02-C093-T07 · Violating fixture:** Create the source counterexample “An old signed package overwrites a newer approved release” for “Rollback attack fixtures”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M09.02-C093-T08 · Enforcement evidence:** Exercise the “Rollback attack fixtures” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M09.02-C093-T09 · Regression linkage:** Link the “Rollback attack fixtures” property to changes in authenticated update metadata, persisted approved versions and installer staging; record which dependency or contract changes require rerunning it.
- [ ] **UC-M09.02-C093-T10 · Property disposition:** Compare the satisfying and violating “Rollback attack fixtures” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M09.02-C094 · Integration

**Original checklist item:** Integrate rollback attack fixtures with authenticated update metadata, persisted approved versions and installer staging; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M09.02-C094-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Rollback attack fixtures” across authenticated update metadata, persisted approved versions and installer staging; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M09.02-C094-T02 · Field mapping:** Map every “Rollback attack fixtures” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M09.02-C094-T03 · Prerequisite identities:** Record the actual prerequisites for “Rollback attack fixtures” (source dependency list: UC-M09.01); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M09.02-C094-T04 · Ownership agreement:** Specify who owns “Rollback attack fixtures” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M09.02-C094-T05 · Handoff implementation:** Connect “Rollback attack fixtures” through the mapped seam using the real adapter or explicit specification reference; preserve “Each fixture is refused or follows the explicitly authorized exception policy” across the handoff.
- [ ] **UC-M09.02-C094-T06 · Absent-input case:** Omit one required “Rollback attack fixtures” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M09.02-C094-T07 · Stale-input case:** Supply an outdated “Rollback attack fixtures” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M09.02-C094-T08 · Incompatible-input case:** Supply an incompatible “Rollback attack fixtures” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M09.02-C094-T09 · Valid integration trace:** Run a valid “Rollback attack fixtures” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M09.02-C094-T10 · Seam review:** Reconcile the “Rollback attack fixtures” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M09.02-C095 · Valid-case test

**Original checklist item:** Run a valid-path fixture for rollback attack fixtures; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M09.02-C095-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Rollback attack fixtures” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M09.02-C095-T02 · Expected-result oracle:** Specify the “Rollback attack fixtures” expected result independently of the implementation output; include the property “Each fixture is refused or follows the explicitly authorized exception policy” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M09.02-C095-T03 · Fixture material:** Create the concrete “Rollback attack fixtures” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M09.02-C095-T04 · Target preparation:** Prepare the “Rollback attack fixtures” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M09.02-C095-T05 · Initial-state record:** Record the initial “Rollback attack fixtures” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M09.02-C095-T06 · Valid-path execution:** Execute the “Rollback attack fixtures” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M09.02-C095-T07 · Outcome comparison:** Compare every declared “Rollback attack fixtures” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M09.02-C095-T08 · State and bounds check:** Inspect the “Rollback attack fixtures” ownership/state effects and actual use of “Fixture count and installer test duration”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M09.02-C095-T09 · Repeatability check:** Repeat the same “Rollback attack fixtures” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M09.02-C095-T10 · Positive evidence:** Attach the “Rollback attack fixtures” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M09.02-C096 · Negative test

**Original checklist item:** Negative case: An old signed package overwrites a newer approved release. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M09.02-C096-T01 · Adverse-case definition:** Create a test record for the exact “Rollback attack fixtures” source counterexample: “An old signed package overwrites a newer approved release”; state which precondition or invariant it challenges.
- [ ] **UC-M09.02-C096-T02 · Safe fixture boundary:** Define the contained test boundary for “Rollback attack fixtures”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M09.02-C096-T03 · Valid control:** Construct a valid “Rollback attack fixtures” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M09.02-C096-T04 · Minimal adverse input:** Derive the “Rollback attack fixtures” adverse fixture from the control with the smallest documented change needed to reproduce “An old signed package overwrites a newer approved release”; retain that change as reproducible data.
- [ ] **UC-M09.02-C096-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Rollback attack fixtures”; require “Each fixture is refused or follows the explicitly authorized exception policy” and forbid a false-success verdict.
- [ ] **UC-M09.02-C096-T06 · Adverse execution:** Exercise the “Rollback attack fixtures” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M09.02-C096-T07 · Effect inspection:** Inspect “Rollback attack fixtures” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M09.02-C096-T08 · Refusal versus failure:** Confirm the “Rollback attack fixtures” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M09.02-C096-T09 · Reset and retention:** Restore only the disposable “Rollback attack fixtures” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M09.02-C096-T10 · Negative regression:** Register the “Rollback attack fixtures” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M09.02-C097 · Change / failure test

**Original checklist item:** Exercise rollback attack fixtures when an offline update is interrupted and then retried with older signed metadata; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M09.02-C097-T01 · Scenario record:** Write the “Rollback attack fixtures” change/failure scenario exactly as supplied: an offline update is interrupted and then retried with older signed metadata; identify the property that must remain true: “Each fixture is refused or follows the explicitly authorized exception policy”.
- [ ] **UC-M09.02-C097-T02 · Baseline capture:** Create a known-valid “Rollback attack fixtures” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M09.02-C097-T03 · Injection map:** Locate the “Rollback attack fixtures” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M09.02-C097-T04 · Disposition oracle:** Define the legal intermediate and final “Rollback attack fixtures” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M09.02-C097-T05 · Controlled trigger:** Introduce the controlled “Rollback attack fixtures” scenario in the disposable fixture: an offline update is interrupted and then retried with older signed metadata; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M09.02-C097-T06 · Intermediate inspection:** Inspect the “Rollback attack fixtures” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M09.02-C097-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Rollback attack fixtures”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M09.02-C097-T08 · Stale-evidence cleanup:** Invalidate superseded “Rollback attack fixtures” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M09.02-C097-T09 · Repeat and compare:** Repeat the selected “Rollback attack fixtures” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M09.02-C097-T10 · Failure evidence:** Publish the “Rollback attack fixtures” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M09.02-C098 · Bounds

**Original checklist item:** Choose, document and test limits for fixture count and installer test duration; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M09.02-C098-T01 · Quantity inventory:** Create a measurement inventory for “Rollback attack fixtures”: “Fixture count and installer test duration”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M09.02-C098-T02 · Measurement method:** Choose how to observe each “Rollback attack fixtures” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M09.02-C098-T03 · Budget decision:** Select justified resource and input limits for “Rollback attack fixtures”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M09.02-C098-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Rollback attack fixtures” cases for “Fixture count and installer test duration”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M09.02-C098-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Rollback attack fixtures” limit; preserve “Each fixture is refused or follows the explicitly authorized exception policy”.
- [ ] **UC-M09.02-C098-T06 · Normal measurement:** Run or review the normal “Rollback attack fixtures” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M09.02-C098-T07 · At-limit measurement:** Exercise the “Rollback attack fixtures” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M09.02-C098-T08 · Over-limit measurement:** Exercise the “Rollback attack fixtures” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M09.02-C098-T09 · Uncovered-scope report:** List the “Rollback attack fixtures” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M09.02-C098-T10 · Limit evidence:** Publish the selected “Rollback attack fixtures” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M09.02-C099 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for rollback attack fixtures with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M09.02-C099-T01 · Event inventory:** List the “Rollback attack fixtures” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M09.02-C099-T02 · Diagnostic schema:** Define nonsecret fields for “Rollback attack fixtures” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M09.02-C099-T03 · Failure mapping:** Map each documented “Rollback attack fixtures” refusal or error to a diagnostic outcome; include “An old signed package overwrites a newer approved release” and prohibit conversion into a success message.
- [ ] **UC-M09.02-C099-T04 · Emission path:** Add the “Rollback attack fixtures” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M09.02-C099-T05 · Redaction check:** Test “Rollback attack fixtures” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M09.02-C099-T06 · Output budget:** Set and exercise bounded “Rollback attack fixtures” message size, rate and retention compatible with “Fixture count and installer test duration”; define truncation behavior that preserves the final reason.
- [ ] **UC-M09.02-C099-T07 · Success/refusal fixtures:** Capture “Rollback attack fixtures” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M09.02-C099-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Rollback attack fixtures” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M09.02-C099-T09 · Operator review:** Read the “Rollback attack fixtures” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M09.02-C099-T10 · Diagnostic evidence:** Publish redacted “Rollback attack fixtures” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M09.02-C100 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for rollback attack fixtures; label unexecuted checks as untested.

- [ ] **UC-M09.02-C100-T01 · Evidence inventory:** List the “Rollback attack fixtures” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M09.02-C100-T02 · Artifact references:** Record the exact “Rollback attack fixtures” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M09.02-C100-T03 · Fixture references:** Attach the “Rollback attack fixtures” fixture IDs, input identities and oracle definition; preserve the source counterexample “An old signed package overwrites a newer approved release” as a distinct evidence case.
- [ ] **UC-M09.02-C100-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Rollback attack fixtures”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M09.02-C100-T05 · Environment record:** Record the actual “Rollback attack fixtures” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M09.02-C100-T06 · Expected versus observed:** Pair every “Rollback attack fixtures” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M09.02-C100-T07 · Failure and limit records:** Attach “Rollback attack fixtures” change/failure and bounds evidence where required; include uncovered “Fixture count and installer test duration” and unresolved violations of “Each fixture is refused or follows the explicitly authorized exception policy”.
- [ ] **UC-M09.02-C100-T08 · Evidence hygiene:** Check the “Rollback attack fixtures” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M09.02-C100-T09 · Reproduction review:** Have the “Rollback attack fixtures” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M09.02-C100-T10 · Acceptance linkage:** Link the “Rollback attack fixtures” evidence to its parent and UC-M09.02 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

