# UC-M09.07 — Guest escape and side-channel assessment

**To-Do Pack 2.0.0 · Baseline UC-2.2.0 · 100 parent checks × 10 subtasks = 1,000 to-dos**

[Master index](../../INDEX.md) · [Workstream index](../../w/09.md)

| Field | Preserved source value |
|---|---|
| Workstream | 09. Trust, integrity and adversarial security |
| Milestone | C |
| Priority | P0 |
| Source assessment | MISSING |
| Scope | core or selected profile |
| Dependencies | [UC-M03.03](../03/UC-M03.03.md), [UC-M03.04](../03/UC-M03.04.md), [UC-M03.05](../03/UC-M03.05.md), [UC-M09.06](../09/UC-M09.06.md) |
| Source checklist pack | 1.0.0 |
| Original reference labels | [S4], [S7], [S8]. |

## Original requirement

Exercise host boundary attacks and document the chosen hardware/shared-resource threat model rather than asserting absolute isolation.

**Original acceptance criterion:** Independent tests and host configuration evidence support the declared tenant boundary; unsupported threats are clearly excluded.

**Source trace:** Original checklist `UC100/c/09/UC-M09.07.md` inside [s/checklists.zip](../../s/checklists.zip); exact parent records in [data/parents.jsonl](../../data/parents.jsonl). Original roadmap lines 875–885 are preserved in [s/roadmap.md](../../s/roadmap.md).

## How to use these lists

Every parent statement below is preserved verbatim. Its ten child tasks are proposed decomposition, not implemented capabilities or executed tests. Child IDs append `-T01` through `-T10` to the original parent ID. All begin unchecked / `TODO`. Design/review evidence does not establish runtime enforcement; observe the actual selected target where the parent requires it.

The source dependency graph and selected release profile determine applicability. The numbered child sequence is a local working order, not an added hard dependency graph. An unselected optional feature needs a recorded not-applicable rationale; missing prerequisites for selected work remain blockers. Numerical budgets, backends and trust mechanisms remain decisions unless fixed by the source. Test hostile cases only with synthetic inputs in authorized disposable environments.

## 01. Assessment scope

**Source delivery:** Define the selected hardware, VMM/tender, host configuration and tenant threat assumptions.

**Source invariant:** Isolation assessment claims do not exceed the evaluated configuration.

**Source negative case:** A result from one host profile is generalized to every deployment.

**Source bounded quantities:** Host profiles and tested threat classes.

### UC-M09.07-C001 · Contract

**Original checklist item:** Define the qualification objective for assessment scope, including the actual target implementation, prerequisites, observable oracle and explicit exclusions.

- [ ] **UC-M09.07-C001-T01 · Scope statement:** Write the qualification question for “Assessment scope”; identify the actual target, claimed capability and observations that can answer that question.
- [ ] **UC-M09.07-C001-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Assessment scope”; record each producer, representation and missing-value meaning.
- [ ] **UC-M09.07-C001-T03 · Output inventory:** List the outputs of “Assessment scope” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M09.07-C001-T04 · Field dictionary:** Create a field-and-term dictionary for “Assessment scope”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M09.07-C001-T05 · Prerequisite contract:** Map “Assessment scope” to the source component prerequisites (UC-M03.03, UC-M03.04, UC-M03.05, UC-M09.06); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M09.07-C001-T06 · Authority map:** Identify who may produce, change and consume “Assessment scope”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M09.07-C001-T07 · Invariant clause:** Add a normative clause for “Assessment scope” that preserves “Isolation assessment claims do not exceed the evaluated configuration”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M09.07-C001-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Assessment scope”; include the source counterexample “A result from one host profile is generalized to every deployment” and the intended safe disposition.
- [ ] **UC-M09.07-C001-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Host profiles and tested threat classes” in the “Assessment scope” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M09.07-C001-T10 · Contract review:** Review the “Assessment scope” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M09.07-C002 · Delivery

**Original checklist item:** Define the selected hardware, VMM/tender, host configuration and tenant threat assumptions.

- [ ] **UC-M09.07-C002-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Assessment scope”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M09.07-C002-T02 · Change plan:** Break the source delivery for “Assessment scope” into concrete edit targets and reviewable outputs; keep the UC-M09.07 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M09.07-C002-T03 · Core artifact:** Create the “Assessment scope” model, schema or inventory that realizes this source instruction: Define the selected hardware, VMM/tender, host configuration and tenant threat assumptions.
- [ ] **UC-M09.07-C002-T04 · Concrete realization:** Populate “Assessment scope” with one concrete worked case; map every required entity or field to its source and flag any unmapped entry.
- [ ] **UC-M09.07-C002-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Assessment scope” needed to preserve “Isolation assessment claims do not exceed the evaluated configuration”; record an enforcement gap where only a model exists.
- [ ] **UC-M09.07-C002-T06 · Dependency connection:** Connect the “Assessment scope” qualification artifact to guest-controlled interfaces, effective host policies and declared tenant threat assumptions; record the target identity and what the harness actually exercises.
- [ ] **UC-M09.07-C002-T07 · Resource behavior:** Account for “Host profiles and tested threat classes” in “Assessment scope”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M09.07-C002-T08 · Delivery check:** Run a known-valid control and a deliberately failing control for “Assessment scope”; confirm the harness distinguishes their observed outcomes.
- [ ] **UC-M09.07-C002-T09 · Patch review:** Review the “Assessment scope” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M09.07-C002-T10 · Delivery handoff:** Publish the “Assessment scope” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M09.07-C003 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Isolation assessment claims do not exceed the evaluated configuration. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M09.07-C003-T01 · Named property:** Create a stable property/check name under this parent for “Assessment scope”; copy its required invariant exactly: “Isolation assessment claims do not exceed the evaluated configuration”.
- [ ] **UC-M09.07-C003-T02 · Observable terms:** Define each term in the “Assessment scope” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M09.07-C003-T03 · Precondition set:** List the preconditions under which “Isolation assessment claims do not exceed the evaluated configuration” must hold for “Assessment scope”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M09.07-C003-T04 · Transition coverage:** Map the “Assessment scope” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M09.07-C003-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Assessment scope”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M09.07-C003-T06 · Satisfying fixture:** Create a concrete “Assessment scope” case that satisfies “Isolation assessment claims do not exceed the evaluated configuration”; record its expected observation before running the assertion or review.
- [ ] **UC-M09.07-C003-T07 · Violating fixture:** Create the source counterexample “A result from one host profile is generalized to every deployment” for “Assessment scope”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M09.07-C003-T08 · Enforcement evidence:** Exercise the “Assessment scope” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M09.07-C003-T09 · Regression linkage:** Link the “Assessment scope” property to changes in guest-controlled interfaces, effective host policies and declared tenant threat assumptions; record which dependency or contract changes require rerunning it.
- [ ] **UC-M09.07-C003-T10 · Property disposition:** Compare the satisfying and violating “Assessment scope” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M09.07-C004 · Integration

**Original checklist item:** Integrate assessment scope with guest-controlled interfaces, effective host policies and declared tenant threat assumptions; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M09.07-C004-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Assessment scope” across guest-controlled interfaces, effective host policies and declared tenant threat assumptions; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M09.07-C004-T02 · Field mapping:** Map every “Assessment scope” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M09.07-C004-T03 · Prerequisite identities:** Record the actual prerequisites for “Assessment scope” (source dependency list: UC-M03.03, UC-M03.04, UC-M03.05, UC-M09.06); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M09.07-C004-T04 · Ownership agreement:** Specify who owns “Assessment scope” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M09.07-C004-T05 · Handoff implementation:** Connect “Assessment scope” through the mapped seam using the real adapter or explicit specification reference; preserve “Isolation assessment claims do not exceed the evaluated configuration” across the handoff.
- [ ] **UC-M09.07-C004-T06 · Absent-input case:** Omit one required “Assessment scope” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M09.07-C004-T07 · Stale-input case:** Supply an outdated “Assessment scope” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M09.07-C004-T08 · Incompatible-input case:** Supply an incompatible “Assessment scope” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M09.07-C004-T09 · Valid integration trace:** Run a valid “Assessment scope” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M09.07-C004-T10 · Seam review:** Reconcile the “Assessment scope” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M09.07-C005 · Valid-case test

**Original checklist item:** Run a known-valid control for assessment scope; verify that the harness reaches its intended target and compare observed measurements or verdicts with predeclared expectations.

- [ ] **UC-M09.07-C005-T01 · Valid fixture choice:** Choose a known-valid control for “Assessment scope”; document why it should pass and how it proves the harness reaches the intended target.
- [ ] **UC-M09.07-C005-T02 · Expected-result oracle:** Specify the “Assessment scope” expected result independently of the implementation output; include the property “Isolation assessment claims do not exceed the evaluated configuration” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M09.07-C005-T03 · Fixture material:** Create the concrete “Assessment scope” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M09.07-C005-T04 · Target preparation:** Prepare the “Assessment scope” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M09.07-C005-T05 · Initial-state record:** Record the initial “Assessment scope” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M09.07-C005-T06 · Valid-path execution:** Run the “Assessment scope” known-valid control on the identified target; retain enough observations to prove the correct target was exercised.
- [ ] **UC-M09.07-C005-T07 · Outcome comparison:** Compare every declared “Assessment scope” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M09.07-C005-T08 · State and bounds check:** Inspect the “Assessment scope” ownership/state effects and actual use of “Host profiles and tested threat classes”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M09.07-C005-T09 · Repeatability check:** Repeat the same “Assessment scope” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M09.07-C005-T10 · Positive evidence:** Attach the “Assessment scope” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M09.07-C006 · Negative test

**Original checklist item:** Negative case: A result from one host profile is generalized to every deployment. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M09.07-C006-T01 · Adverse-case definition:** Create a test record for the exact “Assessment scope” source counterexample: “A result from one host profile is generalized to every deployment”; state which precondition or invariant it challenges.
- [ ] **UC-M09.07-C006-T02 · Safe fixture boundary:** Define the contained test boundary for “Assessment scope”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M09.07-C006-T03 · Valid control:** Construct a valid “Assessment scope” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M09.07-C006-T04 · Minimal adverse input:** Derive the “Assessment scope” adverse fixture from the control with the smallest documented change needed to reproduce “A result from one host profile is generalized to every deployment”; retain that change as reproducible data.
- [ ] **UC-M09.07-C006-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Assessment scope”; require “Isolation assessment claims do not exceed the evaluated configuration” and forbid a false-success verdict.
- [ ] **UC-M09.07-C006-T06 · Adverse execution:** Exercise the “Assessment scope” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M09.07-C006-T07 · Effect inspection:** Inspect “Assessment scope” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M09.07-C006-T08 · Refusal versus failure:** Confirm the “Assessment scope” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M09.07-C006-T09 · Reset and retention:** Restore only the disposable “Assessment scope” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M09.07-C006-T10 · Negative regression:** Register the “Assessment scope” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M09.07-C007 · Change / failure test

**Original checklist item:** Exercise assessment scope when the backend, host configuration or shared-resource assumption changes after assessment; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M09.07-C007-T01 · Scenario record:** Write the “Assessment scope” change/failure scenario exactly as supplied: the backend, host configuration or shared-resource assumption changes after assessment; identify the property that must remain true: “Isolation assessment claims do not exceed the evaluated configuration”.
- [ ] **UC-M09.07-C007-T02 · Baseline capture:** Create a known-valid “Assessment scope” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M09.07-C007-T03 · Injection map:** Locate the “Assessment scope” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M09.07-C007-T04 · Disposition oracle:** Define the legal intermediate and final “Assessment scope” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M09.07-C007-T05 · Controlled trigger:** Introduce the controlled “Assessment scope” scenario in the disposable fixture: the backend, host configuration or shared-resource assumption changes after assessment; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M09.07-C007-T06 · Intermediate inspection:** Inspect the “Assessment scope” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M09.07-C007-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Assessment scope”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M09.07-C007-T08 · Stale-evidence cleanup:** Invalidate superseded “Assessment scope” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M09.07-C007-T09 · Repeat and compare:** Repeat the selected “Assessment scope” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M09.07-C007-T10 · Failure evidence:** Publish the “Assessment scope” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M09.07-C008 · Bounds

**Original checklist item:** Set a documented campaign budget for host profiles and tested threat classes; record actual consumption, incomplete coverage and the disposition when the budget is exhausted.

- [ ] **UC-M09.07-C008-T01 · Quantity inventory:** Create a measurement inventory for “Assessment scope”: “Host profiles and tested threat classes”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M09.07-C008-T02 · Measurement method:** Choose how to observe each “Assessment scope” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M09.07-C008-T03 · Budget decision:** Select justified campaign and target-resource budgets for “Assessment scope”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M09.07-C008-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Assessment scope” cases for “Host profiles and tested threat classes”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M09.07-C008-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Assessment scope” limit; preserve “Isolation assessment claims do not exceed the evaluated configuration”.
- [ ] **UC-M09.07-C008-T06 · Normal measurement:** Run or review the normal “Assessment scope” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M09.07-C008-T07 · At-limit measurement:** Exercise the “Assessment scope” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M09.07-C008-T08 · Over-limit measurement:** Exercise the “Assessment scope” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M09.07-C008-T09 · Uncovered-scope report:** List the “Assessment scope” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M09.07-C008-T10 · Limit evidence:** Publish the selected “Assessment scope” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M09.07-C009 · Diagnostics / review

**Original checklist item:** Report assessment scope results with executed, failed, skipped and unavailable cases separated; preserve the underlying observations and do not manufacture missing measurements.

- [ ] **UC-M09.07-C009-T01 · Result inventory:** Enumerate the required “Assessment scope” qualification cases and intended targets before aggregating results; keep the planned denominator visible.
- [ ] **UC-M09.07-C009-T02 · Verdict schema:** Define separate executed-pass, executed-fail, skipped, unavailable and untested outcomes for “Assessment scope”; document how incomplete cases block relevant claims.
- [ ] **UC-M09.07-C009-T03 · Identity fields:** Attach the actual target, fixture, configuration and revision identifiers to each “Assessment scope” result; do not attribute host-only evidence to a guest or another OS.
- [ ] **UC-M09.07-C009-T04 · Observation capture:** Capture bounded raw “Assessment scope” observations and harness errors; retain enough information to verify the reported oracle comparison.
- [ ] **UC-M09.07-C009-T05 · Aggregation rules:** Implement the “Assessment scope” count/reduction rule so failures and missing measurements cannot disappear; preserve “Isolation assessment claims do not exceed the evaluated configuration”.
- [ ] **UC-M09.07-C009-T06 · Failure visibility:** Feed a failing “Assessment scope” control through the report path; assert the exact failed case and underlying observation remain visible.
- [ ] **UC-M09.07-C009-T07 · Missing-result visibility:** Withhold a required “Assessment scope” measurement or target; verify the report uses unavailable/untested rather than a fabricated zero or passing value.
- [ ] **UC-M09.07-C009-T08 · Bounds and redaction:** Check “Assessment scope” report size and retention against “Host profiles and tested threat classes”; remove secrets while retaining fixture and subject references.
- [ ] **UC-M09.07-C009-T09 · Report reconciliation:** Reconcile the “Assessment scope” summary with every underlying case record; account for the full planned denominator and all omitted scope.
- [ ] **UC-M09.07-C009-T10 · Qualification handoff:** Publish the “Assessment scope” report with measured observations, coverage limits and blockers; state which actual targets remain unqualified.

### UC-M09.07-C010 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for assessment scope; label unexecuted checks as untested.

- [ ] **UC-M09.07-C010-T01 · Evidence inventory:** List the “Assessment scope” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M09.07-C010-T02 · Artifact references:** Record the exact “Assessment scope” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M09.07-C010-T03 · Fixture references:** Attach the “Assessment scope” fixture IDs, input identities and oracle definition; preserve the source counterexample “A result from one host profile is generalized to every deployment” as a distinct evidence case.
- [ ] **UC-M09.07-C010-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Assessment scope”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M09.07-C010-T05 · Environment record:** Record the actual “Assessment scope” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M09.07-C010-T06 · Expected versus observed:** Pair every “Assessment scope” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M09.07-C010-T07 · Failure and limit records:** Attach “Assessment scope” change/failure and bounds evidence where required; include uncovered “Host profiles and tested threat classes” and unresolved violations of “Isolation assessment claims do not exceed the evaluated configuration”.
- [ ] **UC-M09.07-C010-T08 · Evidence hygiene:** Check the “Assessment scope” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M09.07-C010-T09 · Reproduction review:** Have the “Assessment scope” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M09.07-C010-T10 · Acceptance linkage:** Link the “Assessment scope” evidence to its parent and UC-M09.07 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 02. Boundary mapping

**Source delivery:** Map guest-controlled interfaces to host resources and privileges.

**Source invariant:** Every exposed path has an identified host enforcement boundary.

**Source negative case:** A helper path is omitted from the escape assessment.

**Source bounded quantities:** Interfaces and privileged transitions.

### UC-M09.07-C011 · Contract

**Original checklist item:** Define the qualification objective for boundary mapping, including the actual target implementation, prerequisites, observable oracle and explicit exclusions.

- [ ] **UC-M09.07-C011-T01 · Scope statement:** Write the qualification question for “Boundary mapping”; identify the actual target, claimed capability and observations that can answer that question.
- [ ] **UC-M09.07-C011-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Boundary mapping”; record each producer, representation and missing-value meaning.
- [ ] **UC-M09.07-C011-T03 · Output inventory:** List the outputs of “Boundary mapping” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M09.07-C011-T04 · Field dictionary:** Create a field-and-term dictionary for “Boundary mapping”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M09.07-C011-T05 · Prerequisite contract:** Map “Boundary mapping” to the source component prerequisites (UC-M03.03, UC-M03.04, UC-M03.05, UC-M09.06); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M09.07-C011-T06 · Authority map:** Identify who may produce, change and consume “Boundary mapping”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M09.07-C011-T07 · Invariant clause:** Add a normative clause for “Boundary mapping” that preserves “Every exposed path has an identified host enforcement boundary”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M09.07-C011-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Boundary mapping”; include the source counterexample “A helper path is omitted from the escape assessment” and the intended safe disposition.
- [ ] **UC-M09.07-C011-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Interfaces and privileged transitions” in the “Boundary mapping” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M09.07-C011-T10 · Contract review:** Review the “Boundary mapping” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M09.07-C012 · Delivery

**Original checklist item:** Map guest-controlled interfaces to host resources and privileges.

- [ ] **UC-M09.07-C012-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Boundary mapping”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M09.07-C012-T02 · Change plan:** Break the source delivery for “Boundary mapping” into concrete edit targets and reviewable outputs; keep the UC-M09.07 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M09.07-C012-T03 · Core artifact:** Create the “Boundary mapping” model, schema or inventory that realizes this source instruction: Map guest-controlled interfaces to host resources and privileges.
- [ ] **UC-M09.07-C012-T04 · Concrete realization:** Populate “Boundary mapping” with one concrete worked case; map every required entity or field to its source and flag any unmapped entry.
- [ ] **UC-M09.07-C012-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Boundary mapping” needed to preserve “Every exposed path has an identified host enforcement boundary”; record an enforcement gap where only a model exists.
- [ ] **UC-M09.07-C012-T06 · Dependency connection:** Connect the “Boundary mapping” qualification artifact to guest-controlled interfaces, effective host policies and declared tenant threat assumptions; record the target identity and what the harness actually exercises.
- [ ] **UC-M09.07-C012-T07 · Resource behavior:** Account for “Interfaces and privileged transitions” in “Boundary mapping”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M09.07-C012-T08 · Delivery check:** Run a known-valid control and a deliberately failing control for “Boundary mapping”; confirm the harness distinguishes their observed outcomes.
- [ ] **UC-M09.07-C012-T09 · Patch review:** Review the “Boundary mapping” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M09.07-C012-T10 · Delivery handoff:** Publish the “Boundary mapping” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M09.07-C013 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Every exposed path has an identified host enforcement boundary. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M09.07-C013-T01 · Named property:** Create a stable property/check name under this parent for “Boundary mapping”; copy its required invariant exactly: “Every exposed path has an identified host enforcement boundary”.
- [ ] **UC-M09.07-C013-T02 · Observable terms:** Define each term in the “Boundary mapping” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M09.07-C013-T03 · Precondition set:** List the preconditions under which “Every exposed path has an identified host enforcement boundary” must hold for “Boundary mapping”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M09.07-C013-T04 · Transition coverage:** Map the “Boundary mapping” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M09.07-C013-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Boundary mapping”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M09.07-C013-T06 · Satisfying fixture:** Create a concrete “Boundary mapping” case that satisfies “Every exposed path has an identified host enforcement boundary”; record its expected observation before running the assertion or review.
- [ ] **UC-M09.07-C013-T07 · Violating fixture:** Create the source counterexample “A helper path is omitted from the escape assessment” for “Boundary mapping”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M09.07-C013-T08 · Enforcement evidence:** Exercise the “Boundary mapping” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M09.07-C013-T09 · Regression linkage:** Link the “Boundary mapping” property to changes in guest-controlled interfaces, effective host policies and declared tenant threat assumptions; record which dependency or contract changes require rerunning it.
- [ ] **UC-M09.07-C013-T10 · Property disposition:** Compare the satisfying and violating “Boundary mapping” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M09.07-C014 · Integration

**Original checklist item:** Integrate boundary mapping with guest-controlled interfaces, effective host policies and declared tenant threat assumptions; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M09.07-C014-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Boundary mapping” across guest-controlled interfaces, effective host policies and declared tenant threat assumptions; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M09.07-C014-T02 · Field mapping:** Map every “Boundary mapping” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M09.07-C014-T03 · Prerequisite identities:** Record the actual prerequisites for “Boundary mapping” (source dependency list: UC-M03.03, UC-M03.04, UC-M03.05, UC-M09.06); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M09.07-C014-T04 · Ownership agreement:** Specify who owns “Boundary mapping” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M09.07-C014-T05 · Handoff implementation:** Connect “Boundary mapping” through the mapped seam using the real adapter or explicit specification reference; preserve “Every exposed path has an identified host enforcement boundary” across the handoff.
- [ ] **UC-M09.07-C014-T06 · Absent-input case:** Omit one required “Boundary mapping” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M09.07-C014-T07 · Stale-input case:** Supply an outdated “Boundary mapping” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M09.07-C014-T08 · Incompatible-input case:** Supply an incompatible “Boundary mapping” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M09.07-C014-T09 · Valid integration trace:** Run a valid “Boundary mapping” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M09.07-C014-T10 · Seam review:** Reconcile the “Boundary mapping” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M09.07-C015 · Valid-case test

**Original checklist item:** Run a known-valid control for boundary mapping; verify that the harness reaches its intended target and compare observed measurements or verdicts with predeclared expectations.

- [ ] **UC-M09.07-C015-T01 · Valid fixture choice:** Choose a known-valid control for “Boundary mapping”; document why it should pass and how it proves the harness reaches the intended target.
- [ ] **UC-M09.07-C015-T02 · Expected-result oracle:** Specify the “Boundary mapping” expected result independently of the implementation output; include the property “Every exposed path has an identified host enforcement boundary” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M09.07-C015-T03 · Fixture material:** Create the concrete “Boundary mapping” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M09.07-C015-T04 · Target preparation:** Prepare the “Boundary mapping” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M09.07-C015-T05 · Initial-state record:** Record the initial “Boundary mapping” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M09.07-C015-T06 · Valid-path execution:** Run the “Boundary mapping” known-valid control on the identified target; retain enough observations to prove the correct target was exercised.
- [ ] **UC-M09.07-C015-T07 · Outcome comparison:** Compare every declared “Boundary mapping” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M09.07-C015-T08 · State and bounds check:** Inspect the “Boundary mapping” ownership/state effects and actual use of “Interfaces and privileged transitions”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M09.07-C015-T09 · Repeatability check:** Repeat the same “Boundary mapping” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M09.07-C015-T10 · Positive evidence:** Attach the “Boundary mapping” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M09.07-C016 · Negative test

**Original checklist item:** Negative case: A helper path is omitted from the escape assessment. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M09.07-C016-T01 · Adverse-case definition:** Create a test record for the exact “Boundary mapping” source counterexample: “A helper path is omitted from the escape assessment”; state which precondition or invariant it challenges.
- [ ] **UC-M09.07-C016-T02 · Safe fixture boundary:** Define the contained test boundary for “Boundary mapping”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M09.07-C016-T03 · Valid control:** Construct a valid “Boundary mapping” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M09.07-C016-T04 · Minimal adverse input:** Derive the “Boundary mapping” adverse fixture from the control with the smallest documented change needed to reproduce “A helper path is omitted from the escape assessment”; retain that change as reproducible data.
- [ ] **UC-M09.07-C016-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Boundary mapping”; require “Every exposed path has an identified host enforcement boundary” and forbid a false-success verdict.
- [ ] **UC-M09.07-C016-T06 · Adverse execution:** Exercise the “Boundary mapping” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M09.07-C016-T07 · Effect inspection:** Inspect “Boundary mapping” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M09.07-C016-T08 · Refusal versus failure:** Confirm the “Boundary mapping” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M09.07-C016-T09 · Reset and retention:** Restore only the disposable “Boundary mapping” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M09.07-C016-T10 · Negative regression:** Register the “Boundary mapping” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M09.07-C017 · Change / failure test

**Original checklist item:** Exercise boundary mapping when the backend, host configuration or shared-resource assumption changes after assessment; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M09.07-C017-T01 · Scenario record:** Write the “Boundary mapping” change/failure scenario exactly as supplied: the backend, host configuration or shared-resource assumption changes after assessment; identify the property that must remain true: “Every exposed path has an identified host enforcement boundary”.
- [ ] **UC-M09.07-C017-T02 · Baseline capture:** Create a known-valid “Boundary mapping” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M09.07-C017-T03 · Injection map:** Locate the “Boundary mapping” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M09.07-C017-T04 · Disposition oracle:** Define the legal intermediate and final “Boundary mapping” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M09.07-C017-T05 · Controlled trigger:** Introduce the controlled “Boundary mapping” scenario in the disposable fixture: the backend, host configuration or shared-resource assumption changes after assessment; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M09.07-C017-T06 · Intermediate inspection:** Inspect the “Boundary mapping” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M09.07-C017-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Boundary mapping”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M09.07-C017-T08 · Stale-evidence cleanup:** Invalidate superseded “Boundary mapping” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M09.07-C017-T09 · Repeat and compare:** Repeat the selected “Boundary mapping” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M09.07-C017-T10 · Failure evidence:** Publish the “Boundary mapping” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M09.07-C018 · Bounds

**Original checklist item:** Set a documented campaign budget for interfaces and privileged transitions; record actual consumption, incomplete coverage and the disposition when the budget is exhausted.

- [ ] **UC-M09.07-C018-T01 · Quantity inventory:** Create a measurement inventory for “Boundary mapping”: “Interfaces and privileged transitions”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M09.07-C018-T02 · Measurement method:** Choose how to observe each “Boundary mapping” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M09.07-C018-T03 · Budget decision:** Select justified campaign and target-resource budgets for “Boundary mapping”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M09.07-C018-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Boundary mapping” cases for “Interfaces and privileged transitions”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M09.07-C018-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Boundary mapping” limit; preserve “Every exposed path has an identified host enforcement boundary”.
- [ ] **UC-M09.07-C018-T06 · Normal measurement:** Run or review the normal “Boundary mapping” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M09.07-C018-T07 · At-limit measurement:** Exercise the “Boundary mapping” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M09.07-C018-T08 · Over-limit measurement:** Exercise the “Boundary mapping” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M09.07-C018-T09 · Uncovered-scope report:** List the “Boundary mapping” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M09.07-C018-T10 · Limit evidence:** Publish the selected “Boundary mapping” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M09.07-C019 · Diagnostics / review

**Original checklist item:** Report boundary mapping results with executed, failed, skipped and unavailable cases separated; preserve the underlying observations and do not manufacture missing measurements.

- [ ] **UC-M09.07-C019-T01 · Result inventory:** Enumerate the required “Boundary mapping” qualification cases and intended targets before aggregating results; keep the planned denominator visible.
- [ ] **UC-M09.07-C019-T02 · Verdict schema:** Define separate executed-pass, executed-fail, skipped, unavailable and untested outcomes for “Boundary mapping”; document how incomplete cases block relevant claims.
- [ ] **UC-M09.07-C019-T03 · Identity fields:** Attach the actual target, fixture, configuration and revision identifiers to each “Boundary mapping” result; do not attribute host-only evidence to a guest or another OS.
- [ ] **UC-M09.07-C019-T04 · Observation capture:** Capture bounded raw “Boundary mapping” observations and harness errors; retain enough information to verify the reported oracle comparison.
- [ ] **UC-M09.07-C019-T05 · Aggregation rules:** Implement the “Boundary mapping” count/reduction rule so failures and missing measurements cannot disappear; preserve “Every exposed path has an identified host enforcement boundary”.
- [ ] **UC-M09.07-C019-T06 · Failure visibility:** Feed a failing “Boundary mapping” control through the report path; assert the exact failed case and underlying observation remain visible.
- [ ] **UC-M09.07-C019-T07 · Missing-result visibility:** Withhold a required “Boundary mapping” measurement or target; verify the report uses unavailable/untested rather than a fabricated zero or passing value.
- [ ] **UC-M09.07-C019-T08 · Bounds and redaction:** Check “Boundary mapping” report size and retention against “Interfaces and privileged transitions”; remove secrets while retaining fixture and subject references.
- [ ] **UC-M09.07-C019-T09 · Report reconciliation:** Reconcile the “Boundary mapping” summary with every underlying case record; account for the full planned denominator and all omitted scope.
- [ ] **UC-M09.07-C019-T10 · Qualification handoff:** Publish the “Boundary mapping” report with measured observations, coverage limits and blockers; state which actual targets remain unqualified.

### UC-M09.07-C020 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for boundary mapping; label unexecuted checks as untested.

- [ ] **UC-M09.07-C020-T01 · Evidence inventory:** List the “Boundary mapping” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M09.07-C020-T02 · Artifact references:** Record the exact “Boundary mapping” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M09.07-C020-T03 · Fixture references:** Attach the “Boundary mapping” fixture IDs, input identities and oracle definition; preserve the source counterexample “A helper path is omitted from the escape assessment” as a distinct evidence case.
- [ ] **UC-M09.07-C020-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Boundary mapping”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M09.07-C020-T05 · Environment record:** Record the actual “Boundary mapping” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M09.07-C020-T06 · Expected versus observed:** Pair every “Boundary mapping” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M09.07-C020-T07 · Failure and limit records:** Attach “Boundary mapping” change/failure and bounds evidence where required; include uncovered “Interfaces and privileged transitions” and unresolved violations of “Every exposed path has an identified host enforcement boundary”.
- [ ] **UC-M09.07-C020-T08 · Evidence hygiene:** Check the “Boundary mapping” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M09.07-C020-T09 · Reproduction review:** Have the “Boundary mapping” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M09.07-C020-T10 · Acceptance linkage:** Link the “Boundary mapping” evidence to its parent and UC-M09.07 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 03. Controlled test environment

**Source delivery:** Run adversarial boundary tests in isolated authorized disposable environments.

**Source invariant:** Tests do not expose unrelated user systems or production secrets.

**Source negative case:** A test is configured to target an unrelated live host.

**Source bounded quantities:** Test hosts and fixture data scope.

### UC-M09.07-C021 · Contract

**Original checklist item:** Define the qualification objective for controlled test environment, including the actual target implementation, prerequisites, observable oracle and explicit exclusions.

- [ ] **UC-M09.07-C021-T01 · Scope statement:** Write the qualification question for “Controlled test environment”; identify the actual target, claimed capability and observations that can answer that question.
- [ ] **UC-M09.07-C021-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Controlled test environment”; record each producer, representation and missing-value meaning.
- [ ] **UC-M09.07-C021-T03 · Output inventory:** List the outputs of “Controlled test environment” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M09.07-C021-T04 · Field dictionary:** Create a field-and-term dictionary for “Controlled test environment”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M09.07-C021-T05 · Prerequisite contract:** Map “Controlled test environment” to the source component prerequisites (UC-M03.03, UC-M03.04, UC-M03.05, UC-M09.06); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M09.07-C021-T06 · Authority map:** Identify who may produce, change and consume “Controlled test environment”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M09.07-C021-T07 · Invariant clause:** Add a normative clause for “Controlled test environment” that preserves “Tests do not expose unrelated user systems or production secrets”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M09.07-C021-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Controlled test environment”; include the source counterexample “A test is configured to target an unrelated live host” and the intended safe disposition.
- [ ] **UC-M09.07-C021-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Test hosts and fixture data scope” in the “Controlled test environment” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M09.07-C021-T10 · Contract review:** Review the “Controlled test environment” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M09.07-C022 · Delivery

**Original checklist item:** Run adversarial boundary tests in isolated authorized disposable environments.

- [ ] **UC-M09.07-C022-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Controlled test environment”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M09.07-C022-T02 · Change plan:** Break the source delivery for “Controlled test environment” into concrete edit targets and reviewable outputs; keep the UC-M09.07 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M09.07-C022-T03 · Core artifact:** Create the “Controlled test environment” fixture or harness for this source instruction: Run adversarial boundary tests in isolated authorized disposable environments.
- [ ] **UC-M09.07-C022-T04 · Concrete realization:** Connect the “Controlled test environment” harness to its actual intended target, set the expected oracle before running it, and distinguish a mock/control run from a target run.
- [ ] **UC-M09.07-C022-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Controlled test environment” needed to preserve “Tests do not expose unrelated user systems or production secrets”; record an enforcement gap where only a model exists.
- [ ] **UC-M09.07-C022-T06 · Dependency connection:** Connect the “Controlled test environment” qualification artifact to guest-controlled interfaces, effective host policies and declared tenant threat assumptions; record the target identity and what the harness actually exercises.
- [ ] **UC-M09.07-C022-T07 · Resource behavior:** Account for “Test hosts and fixture data scope” in “Controlled test environment”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M09.07-C022-T08 · Delivery check:** Run a known-valid control and a deliberately failing control for “Controlled test environment”; confirm the harness distinguishes their observed outcomes.
- [ ] **UC-M09.07-C022-T09 · Patch review:** Review the “Controlled test environment” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M09.07-C022-T10 · Delivery handoff:** Publish the “Controlled test environment” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M09.07-C023 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Tests do not expose unrelated user systems or production secrets. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M09.07-C023-T01 · Named property:** Create a stable property/check name under this parent for “Controlled test environment”; copy its required invariant exactly: “Tests do not expose unrelated user systems or production secrets”.
- [ ] **UC-M09.07-C023-T02 · Observable terms:** Define each term in the “Controlled test environment” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M09.07-C023-T03 · Precondition set:** List the preconditions under which “Tests do not expose unrelated user systems or production secrets” must hold for “Controlled test environment”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M09.07-C023-T04 · Transition coverage:** Map the “Controlled test environment” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M09.07-C023-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Controlled test environment”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M09.07-C023-T06 · Satisfying fixture:** Create a concrete “Controlled test environment” case that satisfies “Tests do not expose unrelated user systems or production secrets”; record its expected observation before running the assertion or review.
- [ ] **UC-M09.07-C023-T07 · Violating fixture:** Create the source counterexample “A test is configured to target an unrelated live host” for “Controlled test environment”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M09.07-C023-T08 · Enforcement evidence:** Exercise the “Controlled test environment” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M09.07-C023-T09 · Regression linkage:** Link the “Controlled test environment” property to changes in guest-controlled interfaces, effective host policies and declared tenant threat assumptions; record which dependency or contract changes require rerunning it.
- [ ] **UC-M09.07-C023-T10 · Property disposition:** Compare the satisfying and violating “Controlled test environment” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M09.07-C024 · Integration

**Original checklist item:** Integrate controlled test environment with guest-controlled interfaces, effective host policies and declared tenant threat assumptions; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M09.07-C024-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Controlled test environment” across guest-controlled interfaces, effective host policies and declared tenant threat assumptions; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M09.07-C024-T02 · Field mapping:** Map every “Controlled test environment” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M09.07-C024-T03 · Prerequisite identities:** Record the actual prerequisites for “Controlled test environment” (source dependency list: UC-M03.03, UC-M03.04, UC-M03.05, UC-M09.06); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M09.07-C024-T04 · Ownership agreement:** Specify who owns “Controlled test environment” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M09.07-C024-T05 · Handoff implementation:** Connect “Controlled test environment” through the mapped seam using the real adapter or explicit specification reference; preserve “Tests do not expose unrelated user systems or production secrets” across the handoff.
- [ ] **UC-M09.07-C024-T06 · Absent-input case:** Omit one required “Controlled test environment” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M09.07-C024-T07 · Stale-input case:** Supply an outdated “Controlled test environment” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M09.07-C024-T08 · Incompatible-input case:** Supply an incompatible “Controlled test environment” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M09.07-C024-T09 · Valid integration trace:** Run a valid “Controlled test environment” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M09.07-C024-T10 · Seam review:** Reconcile the “Controlled test environment” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M09.07-C025 · Valid-case test

**Original checklist item:** Run a known-valid control for controlled test environment; verify that the harness reaches its intended target and compare observed measurements or verdicts with predeclared expectations.

- [ ] **UC-M09.07-C025-T01 · Valid fixture choice:** Choose a known-valid control for “Controlled test environment”; document why it should pass and how it proves the harness reaches the intended target.
- [ ] **UC-M09.07-C025-T02 · Expected-result oracle:** Specify the “Controlled test environment” expected result independently of the implementation output; include the property “Tests do not expose unrelated user systems or production secrets” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M09.07-C025-T03 · Fixture material:** Create the concrete “Controlled test environment” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M09.07-C025-T04 · Target preparation:** Prepare the “Controlled test environment” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M09.07-C025-T05 · Initial-state record:** Record the initial “Controlled test environment” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M09.07-C025-T06 · Valid-path execution:** Run the “Controlled test environment” known-valid control on the identified target; retain enough observations to prove the correct target was exercised.
- [ ] **UC-M09.07-C025-T07 · Outcome comparison:** Compare every declared “Controlled test environment” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M09.07-C025-T08 · State and bounds check:** Inspect the “Controlled test environment” ownership/state effects and actual use of “Test hosts and fixture data scope”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M09.07-C025-T09 · Repeatability check:** Repeat the same “Controlled test environment” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M09.07-C025-T10 · Positive evidence:** Attach the “Controlled test environment” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M09.07-C026 · Negative test

**Original checklist item:** Negative case: A test is configured to target an unrelated live host. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M09.07-C026-T01 · Adverse-case definition:** Create a test record for the exact “Controlled test environment” source counterexample: “A test is configured to target an unrelated live host”; state which precondition or invariant it challenges.
- [ ] **UC-M09.07-C026-T02 · Safe fixture boundary:** Define the contained test boundary for “Controlled test environment”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M09.07-C026-T03 · Valid control:** Construct a valid “Controlled test environment” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M09.07-C026-T04 · Minimal adverse input:** Derive the “Controlled test environment” adverse fixture from the control with the smallest documented change needed to reproduce “A test is configured to target an unrelated live host”; retain that change as reproducible data.
- [ ] **UC-M09.07-C026-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Controlled test environment”; require “Tests do not expose unrelated user systems or production secrets” and forbid a false-success verdict.
- [ ] **UC-M09.07-C026-T06 · Adverse execution:** Exercise the “Controlled test environment” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M09.07-C026-T07 · Effect inspection:** Inspect “Controlled test environment” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M09.07-C026-T08 · Refusal versus failure:** Confirm the “Controlled test environment” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M09.07-C026-T09 · Reset and retention:** Restore only the disposable “Controlled test environment” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M09.07-C026-T10 · Negative regression:** Register the “Controlled test environment” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M09.07-C027 · Change / failure test

**Original checklist item:** Exercise controlled test environment when the backend, host configuration or shared-resource assumption changes after assessment; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M09.07-C027-T01 · Scenario record:** Write the “Controlled test environment” change/failure scenario exactly as supplied: the backend, host configuration or shared-resource assumption changes after assessment; identify the property that must remain true: “Tests do not expose unrelated user systems or production secrets”.
- [ ] **UC-M09.07-C027-T02 · Baseline capture:** Create a known-valid “Controlled test environment” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M09.07-C027-T03 · Injection map:** Locate the “Controlled test environment” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M09.07-C027-T04 · Disposition oracle:** Define the legal intermediate and final “Controlled test environment” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M09.07-C027-T05 · Controlled trigger:** Introduce the controlled “Controlled test environment” scenario in the disposable fixture: the backend, host configuration or shared-resource assumption changes after assessment; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M09.07-C027-T06 · Intermediate inspection:** Inspect the “Controlled test environment” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M09.07-C027-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Controlled test environment”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M09.07-C027-T08 · Stale-evidence cleanup:** Invalidate superseded “Controlled test environment” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M09.07-C027-T09 · Repeat and compare:** Repeat the selected “Controlled test environment” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M09.07-C027-T10 · Failure evidence:** Publish the “Controlled test environment” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M09.07-C028 · Bounds

**Original checklist item:** Set a documented campaign budget for test hosts and fixture data scope; record actual consumption, incomplete coverage and the disposition when the budget is exhausted.

- [ ] **UC-M09.07-C028-T01 · Quantity inventory:** Create a measurement inventory for “Controlled test environment”: “Test hosts and fixture data scope”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M09.07-C028-T02 · Measurement method:** Choose how to observe each “Controlled test environment” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M09.07-C028-T03 · Budget decision:** Select justified campaign and target-resource budgets for “Controlled test environment”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M09.07-C028-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Controlled test environment” cases for “Test hosts and fixture data scope”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M09.07-C028-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Controlled test environment” limit; preserve “Tests do not expose unrelated user systems or production secrets”.
- [ ] **UC-M09.07-C028-T06 · Normal measurement:** Run or review the normal “Controlled test environment” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M09.07-C028-T07 · At-limit measurement:** Exercise the “Controlled test environment” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M09.07-C028-T08 · Over-limit measurement:** Exercise the “Controlled test environment” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M09.07-C028-T09 · Uncovered-scope report:** List the “Controlled test environment” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M09.07-C028-T10 · Limit evidence:** Publish the selected “Controlled test environment” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M09.07-C029 · Diagnostics / review

**Original checklist item:** Report controlled test environment results with executed, failed, skipped and unavailable cases separated; preserve the underlying observations and do not manufacture missing measurements.

- [ ] **UC-M09.07-C029-T01 · Result inventory:** Enumerate the required “Controlled test environment” qualification cases and intended targets before aggregating results; keep the planned denominator visible.
- [ ] **UC-M09.07-C029-T02 · Verdict schema:** Define separate executed-pass, executed-fail, skipped, unavailable and untested outcomes for “Controlled test environment”; document how incomplete cases block relevant claims.
- [ ] **UC-M09.07-C029-T03 · Identity fields:** Attach the actual target, fixture, configuration and revision identifiers to each “Controlled test environment” result; do not attribute host-only evidence to a guest or another OS.
- [ ] **UC-M09.07-C029-T04 · Observation capture:** Capture bounded raw “Controlled test environment” observations and harness errors; retain enough information to verify the reported oracle comparison.
- [ ] **UC-M09.07-C029-T05 · Aggregation rules:** Implement the “Controlled test environment” count/reduction rule so failures and missing measurements cannot disappear; preserve “Tests do not expose unrelated user systems or production secrets”.
- [ ] **UC-M09.07-C029-T06 · Failure visibility:** Feed a failing “Controlled test environment” control through the report path; assert the exact failed case and underlying observation remain visible.
- [ ] **UC-M09.07-C029-T07 · Missing-result visibility:** Withhold a required “Controlled test environment” measurement or target; verify the report uses unavailable/untested rather than a fabricated zero or passing value.
- [ ] **UC-M09.07-C029-T08 · Bounds and redaction:** Check “Controlled test environment” report size and retention against “Test hosts and fixture data scope”; remove secrets while retaining fixture and subject references.
- [ ] **UC-M09.07-C029-T09 · Report reconciliation:** Reconcile the “Controlled test environment” summary with every underlying case record; account for the full planned denominator and all omitted scope.
- [ ] **UC-M09.07-C029-T10 · Qualification handoff:** Publish the “Controlled test environment” report with measured observations, coverage limits and blockers; state which actual targets remain unqualified.

### UC-M09.07-C030 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for controlled test environment; label unexecuted checks as untested.

- [ ] **UC-M09.07-C030-T01 · Evidence inventory:** List the “Controlled test environment” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M09.07-C030-T02 · Artifact references:** Record the exact “Controlled test environment” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M09.07-C030-T03 · Fixture references:** Attach the “Controlled test environment” fixture IDs, input identities and oracle definition; preserve the source counterexample “A test is configured to target an unrelated live host” as a distinct evidence case.
- [ ] **UC-M09.07-C030-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Controlled test environment”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M09.07-C030-T05 · Environment record:** Record the actual “Controlled test environment” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M09.07-C030-T06 · Expected versus observed:** Pair every “Controlled test environment” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M09.07-C030-T07 · Failure and limit records:** Attach “Controlled test environment” change/failure and bounds evidence where required; include uncovered “Test hosts and fixture data scope” and unresolved violations of “Tests do not expose unrelated user systems or production secrets”.
- [ ] **UC-M09.07-C030-T08 · Evidence hygiene:** Check the “Controlled test environment” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M09.07-C030-T09 · Reproduction review:** Have the “Controlled test environment” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M09.07-C030-T10 · Acceptance linkage:** Link the “Controlled test environment” evidence to its parent and UC-M09.07 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 04. Filesystem boundary probes

**Source delivery:** Exercise guest attempts to access unauthorized host and peer files.

**Source invariant:** The declared tenant file boundary has observed refusal evidence.

**Source negative case:** A guest-controlled descriptor opens an unrelated host file.

**Source bounded quantities:** Probe count and accessible fixture paths.

### UC-M09.07-C031 · Contract

**Original checklist item:** Define the qualification objective for filesystem boundary probes, including the actual target implementation, prerequisites, observable oracle and explicit exclusions.

- [ ] **UC-M09.07-C031-T01 · Scope statement:** Write the qualification question for “Filesystem boundary probes”; identify the actual target, claimed capability and observations that can answer that question.
- [ ] **UC-M09.07-C031-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Filesystem boundary probes”; record each producer, representation and missing-value meaning.
- [ ] **UC-M09.07-C031-T03 · Output inventory:** List the outputs of “Filesystem boundary probes” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M09.07-C031-T04 · Field dictionary:** Create a field-and-term dictionary for “Filesystem boundary probes”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M09.07-C031-T05 · Prerequisite contract:** Map “Filesystem boundary probes” to the source component prerequisites (UC-M03.03, UC-M03.04, UC-M03.05, UC-M09.06); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M09.07-C031-T06 · Authority map:** Identify who may produce, change and consume “Filesystem boundary probes”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M09.07-C031-T07 · Invariant clause:** Add a normative clause for “Filesystem boundary probes” that preserves “The declared tenant file boundary has observed refusal evidence”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M09.07-C031-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Filesystem boundary probes”; include the source counterexample “A guest-controlled descriptor opens an unrelated host file” and the intended safe disposition.
- [ ] **UC-M09.07-C031-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Probe count and accessible fixture paths” in the “Filesystem boundary probes” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M09.07-C031-T10 · Contract review:** Review the “Filesystem boundary probes” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M09.07-C032 · Delivery

**Original checklist item:** Exercise guest attempts to access unauthorized host and peer files.

- [ ] **UC-M09.07-C032-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Filesystem boundary probes”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M09.07-C032-T02 · Change plan:** Break the source delivery for “Filesystem boundary probes” into concrete edit targets and reviewable outputs; keep the UC-M09.07 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M09.07-C032-T03 · Core artifact:** Create the “Filesystem boundary probes” fixture or harness for this source instruction: Exercise guest attempts to access unauthorized host and peer files.
- [ ] **UC-M09.07-C032-T04 · Concrete realization:** Connect the “Filesystem boundary probes” harness to its actual intended target, set the expected oracle before running it, and distinguish a mock/control run from a target run.
- [ ] **UC-M09.07-C032-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Filesystem boundary probes” needed to preserve “The declared tenant file boundary has observed refusal evidence”; record an enforcement gap where only a model exists.
- [ ] **UC-M09.07-C032-T06 · Dependency connection:** Connect the “Filesystem boundary probes” qualification artifact to guest-controlled interfaces, effective host policies and declared tenant threat assumptions; record the target identity and what the harness actually exercises.
- [ ] **UC-M09.07-C032-T07 · Resource behavior:** Account for “Probe count and accessible fixture paths” in “Filesystem boundary probes”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M09.07-C032-T08 · Delivery check:** Run a known-valid control and a deliberately failing control for “Filesystem boundary probes”; confirm the harness distinguishes their observed outcomes.
- [ ] **UC-M09.07-C032-T09 · Patch review:** Review the “Filesystem boundary probes” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M09.07-C032-T10 · Delivery handoff:** Publish the “Filesystem boundary probes” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M09.07-C033 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: The declared tenant file boundary has observed refusal evidence. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M09.07-C033-T01 · Named property:** Create a stable property/check name under this parent for “Filesystem boundary probes”; copy its required invariant exactly: “The declared tenant file boundary has observed refusal evidence”.
- [ ] **UC-M09.07-C033-T02 · Observable terms:** Define each term in the “Filesystem boundary probes” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M09.07-C033-T03 · Precondition set:** List the preconditions under which “The declared tenant file boundary has observed refusal evidence” must hold for “Filesystem boundary probes”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M09.07-C033-T04 · Transition coverage:** Map the “Filesystem boundary probes” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M09.07-C033-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Filesystem boundary probes”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M09.07-C033-T06 · Satisfying fixture:** Create a concrete “Filesystem boundary probes” case that satisfies “The declared tenant file boundary has observed refusal evidence”; record its expected observation before running the assertion or review.
- [ ] **UC-M09.07-C033-T07 · Violating fixture:** Create the source counterexample “A guest-controlled descriptor opens an unrelated host file” for “Filesystem boundary probes”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M09.07-C033-T08 · Enforcement evidence:** Exercise the “Filesystem boundary probes” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M09.07-C033-T09 · Regression linkage:** Link the “Filesystem boundary probes” property to changes in guest-controlled interfaces, effective host policies and declared tenant threat assumptions; record which dependency or contract changes require rerunning it.
- [ ] **UC-M09.07-C033-T10 · Property disposition:** Compare the satisfying and violating “Filesystem boundary probes” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M09.07-C034 · Integration

**Original checklist item:** Integrate filesystem boundary probes with guest-controlled interfaces, effective host policies and declared tenant threat assumptions; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M09.07-C034-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Filesystem boundary probes” across guest-controlled interfaces, effective host policies and declared tenant threat assumptions; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M09.07-C034-T02 · Field mapping:** Map every “Filesystem boundary probes” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M09.07-C034-T03 · Prerequisite identities:** Record the actual prerequisites for “Filesystem boundary probes” (source dependency list: UC-M03.03, UC-M03.04, UC-M03.05, UC-M09.06); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M09.07-C034-T04 · Ownership agreement:** Specify who owns “Filesystem boundary probes” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M09.07-C034-T05 · Handoff implementation:** Connect “Filesystem boundary probes” through the mapped seam using the real adapter or explicit specification reference; preserve “The declared tenant file boundary has observed refusal evidence” across the handoff.
- [ ] **UC-M09.07-C034-T06 · Absent-input case:** Omit one required “Filesystem boundary probes” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M09.07-C034-T07 · Stale-input case:** Supply an outdated “Filesystem boundary probes” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M09.07-C034-T08 · Incompatible-input case:** Supply an incompatible “Filesystem boundary probes” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M09.07-C034-T09 · Valid integration trace:** Run a valid “Filesystem boundary probes” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M09.07-C034-T10 · Seam review:** Reconcile the “Filesystem boundary probes” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M09.07-C035 · Valid-case test

**Original checklist item:** Run a known-valid control for filesystem boundary probes; verify that the harness reaches its intended target and compare observed measurements or verdicts with predeclared expectations.

- [ ] **UC-M09.07-C035-T01 · Valid fixture choice:** Choose a known-valid control for “Filesystem boundary probes”; document why it should pass and how it proves the harness reaches the intended target.
- [ ] **UC-M09.07-C035-T02 · Expected-result oracle:** Specify the “Filesystem boundary probes” expected result independently of the implementation output; include the property “The declared tenant file boundary has observed refusal evidence” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M09.07-C035-T03 · Fixture material:** Create the concrete “Filesystem boundary probes” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M09.07-C035-T04 · Target preparation:** Prepare the “Filesystem boundary probes” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M09.07-C035-T05 · Initial-state record:** Record the initial “Filesystem boundary probes” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M09.07-C035-T06 · Valid-path execution:** Run the “Filesystem boundary probes” known-valid control on the identified target; retain enough observations to prove the correct target was exercised.
- [ ] **UC-M09.07-C035-T07 · Outcome comparison:** Compare every declared “Filesystem boundary probes” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M09.07-C035-T08 · State and bounds check:** Inspect the “Filesystem boundary probes” ownership/state effects and actual use of “Probe count and accessible fixture paths”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M09.07-C035-T09 · Repeatability check:** Repeat the same “Filesystem boundary probes” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M09.07-C035-T10 · Positive evidence:** Attach the “Filesystem boundary probes” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M09.07-C036 · Negative test

**Original checklist item:** Negative case: A guest-controlled descriptor opens an unrelated host file. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M09.07-C036-T01 · Adverse-case definition:** Create a test record for the exact “Filesystem boundary probes” source counterexample: “A guest-controlled descriptor opens an unrelated host file”; state which precondition or invariant it challenges.
- [ ] **UC-M09.07-C036-T02 · Safe fixture boundary:** Define the contained test boundary for “Filesystem boundary probes”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M09.07-C036-T03 · Valid control:** Construct a valid “Filesystem boundary probes” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M09.07-C036-T04 · Minimal adverse input:** Derive the “Filesystem boundary probes” adverse fixture from the control with the smallest documented change needed to reproduce “A guest-controlled descriptor opens an unrelated host file”; retain that change as reproducible data.
- [ ] **UC-M09.07-C036-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Filesystem boundary probes”; require “The declared tenant file boundary has observed refusal evidence” and forbid a false-success verdict.
- [ ] **UC-M09.07-C036-T06 · Adverse execution:** Exercise the “Filesystem boundary probes” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M09.07-C036-T07 · Effect inspection:** Inspect “Filesystem boundary probes” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M09.07-C036-T08 · Refusal versus failure:** Confirm the “Filesystem boundary probes” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M09.07-C036-T09 · Reset and retention:** Restore only the disposable “Filesystem boundary probes” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M09.07-C036-T10 · Negative regression:** Register the “Filesystem boundary probes” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M09.07-C037 · Change / failure test

**Original checklist item:** Exercise filesystem boundary probes when the backend, host configuration or shared-resource assumption changes after assessment; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M09.07-C037-T01 · Scenario record:** Write the “Filesystem boundary probes” change/failure scenario exactly as supplied: the backend, host configuration or shared-resource assumption changes after assessment; identify the property that must remain true: “The declared tenant file boundary has observed refusal evidence”.
- [ ] **UC-M09.07-C037-T02 · Baseline capture:** Create a known-valid “Filesystem boundary probes” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M09.07-C037-T03 · Injection map:** Locate the “Filesystem boundary probes” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M09.07-C037-T04 · Disposition oracle:** Define the legal intermediate and final “Filesystem boundary probes” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M09.07-C037-T05 · Controlled trigger:** Introduce the controlled “Filesystem boundary probes” scenario in the disposable fixture: the backend, host configuration or shared-resource assumption changes after assessment; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M09.07-C037-T06 · Intermediate inspection:** Inspect the “Filesystem boundary probes” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M09.07-C037-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Filesystem boundary probes”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M09.07-C037-T08 · Stale-evidence cleanup:** Invalidate superseded “Filesystem boundary probes” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M09.07-C037-T09 · Repeat and compare:** Repeat the selected “Filesystem boundary probes” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M09.07-C037-T10 · Failure evidence:** Publish the “Filesystem boundary probes” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M09.07-C038 · Bounds

**Original checklist item:** Set a documented campaign budget for probe count and accessible fixture paths; record actual consumption, incomplete coverage and the disposition when the budget is exhausted.

- [ ] **UC-M09.07-C038-T01 · Quantity inventory:** Create a measurement inventory for “Filesystem boundary probes”: “Probe count and accessible fixture paths”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M09.07-C038-T02 · Measurement method:** Choose how to observe each “Filesystem boundary probes” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M09.07-C038-T03 · Budget decision:** Select justified campaign and target-resource budgets for “Filesystem boundary probes”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M09.07-C038-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Filesystem boundary probes” cases for “Probe count and accessible fixture paths”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M09.07-C038-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Filesystem boundary probes” limit; preserve “The declared tenant file boundary has observed refusal evidence”.
- [ ] **UC-M09.07-C038-T06 · Normal measurement:** Run or review the normal “Filesystem boundary probes” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M09.07-C038-T07 · At-limit measurement:** Exercise the “Filesystem boundary probes” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M09.07-C038-T08 · Over-limit measurement:** Exercise the “Filesystem boundary probes” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M09.07-C038-T09 · Uncovered-scope report:** List the “Filesystem boundary probes” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M09.07-C038-T10 · Limit evidence:** Publish the selected “Filesystem boundary probes” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M09.07-C039 · Diagnostics / review

**Original checklist item:** Report filesystem boundary probes results with executed, failed, skipped and unavailable cases separated; preserve the underlying observations and do not manufacture missing measurements.

- [ ] **UC-M09.07-C039-T01 · Result inventory:** Enumerate the required “Filesystem boundary probes” qualification cases and intended targets before aggregating results; keep the planned denominator visible.
- [ ] **UC-M09.07-C039-T02 · Verdict schema:** Define separate executed-pass, executed-fail, skipped, unavailable and untested outcomes for “Filesystem boundary probes”; document how incomplete cases block relevant claims.
- [ ] **UC-M09.07-C039-T03 · Identity fields:** Attach the actual target, fixture, configuration and revision identifiers to each “Filesystem boundary probes” result; do not attribute host-only evidence to a guest or another OS.
- [ ] **UC-M09.07-C039-T04 · Observation capture:** Capture bounded raw “Filesystem boundary probes” observations and harness errors; retain enough information to verify the reported oracle comparison.
- [ ] **UC-M09.07-C039-T05 · Aggregation rules:** Implement the “Filesystem boundary probes” count/reduction rule so failures and missing measurements cannot disappear; preserve “The declared tenant file boundary has observed refusal evidence”.
- [ ] **UC-M09.07-C039-T06 · Failure visibility:** Feed a failing “Filesystem boundary probes” control through the report path; assert the exact failed case and underlying observation remain visible.
- [ ] **UC-M09.07-C039-T07 · Missing-result visibility:** Withhold a required “Filesystem boundary probes” measurement or target; verify the report uses unavailable/untested rather than a fabricated zero or passing value.
- [ ] **UC-M09.07-C039-T08 · Bounds and redaction:** Check “Filesystem boundary probes” report size and retention against “Probe count and accessible fixture paths”; remove secrets while retaining fixture and subject references.
- [ ] **UC-M09.07-C039-T09 · Report reconciliation:** Reconcile the “Filesystem boundary probes” summary with every underlying case record; account for the full planned denominator and all omitted scope.
- [ ] **UC-M09.07-C039-T10 · Qualification handoff:** Publish the “Filesystem boundary probes” report with measured observations, coverage limits and blockers; state which actual targets remain unqualified.

### UC-M09.07-C040 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for filesystem boundary probes; label unexecuted checks as untested.

- [ ] **UC-M09.07-C040-T01 · Evidence inventory:** List the “Filesystem boundary probes” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M09.07-C040-T02 · Artifact references:** Record the exact “Filesystem boundary probes” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M09.07-C040-T03 · Fixture references:** Attach the “Filesystem boundary probes” fixture IDs, input identities and oracle definition; preserve the source counterexample “A guest-controlled descriptor opens an unrelated host file” as a distinct evidence case.
- [ ] **UC-M09.07-C040-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Filesystem boundary probes”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M09.07-C040-T05 · Environment record:** Record the actual “Filesystem boundary probes” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M09.07-C040-T06 · Expected versus observed:** Pair every “Filesystem boundary probes” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M09.07-C040-T07 · Failure and limit records:** Attach “Filesystem boundary probes” change/failure and bounds evidence where required; include uncovered “Probe count and accessible fixture paths” and unresolved violations of “The declared tenant file boundary has observed refusal evidence”.
- [ ] **UC-M09.07-C040-T08 · Evidence hygiene:** Check the “Filesystem boundary probes” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M09.07-C040-T09 · Reproduction review:** Have the “Filesystem boundary probes” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M09.07-C040-T10 · Acceptance linkage:** Link the “Filesystem boundary probes” evidence to its parent and UC-M09.07 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 05. Device and operation probes

**Source delivery:** Test exposed device handlers and host operations against allowed capabilities.

**Source invariant:** Guest input cannot invoke forbidden host operations through a device.

**Source negative case:** A malformed device request bypasses broker authorization.

**Source bounded quantities:** Device surfaces and per-probe resource limit.

### UC-M09.07-C041 · Contract

**Original checklist item:** Define the qualification objective for device and operation probes, including the actual target implementation, prerequisites, observable oracle and explicit exclusions.

- [ ] **UC-M09.07-C041-T01 · Scope statement:** Write the qualification question for “Device and operation probes”; identify the actual target, claimed capability and observations that can answer that question.
- [ ] **UC-M09.07-C041-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Device and operation probes”; record each producer, representation and missing-value meaning.
- [ ] **UC-M09.07-C041-T03 · Output inventory:** List the outputs of “Device and operation probes” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M09.07-C041-T04 · Field dictionary:** Create a field-and-term dictionary for “Device and operation probes”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M09.07-C041-T05 · Prerequisite contract:** Map “Device and operation probes” to the source component prerequisites (UC-M03.03, UC-M03.04, UC-M03.05, UC-M09.06); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M09.07-C041-T06 · Authority map:** Identify who may produce, change and consume “Device and operation probes”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M09.07-C041-T07 · Invariant clause:** Add a normative clause for “Device and operation probes” that preserves “Guest input cannot invoke forbidden host operations through a device”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M09.07-C041-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Device and operation probes”; include the source counterexample “A malformed device request bypasses broker authorization” and the intended safe disposition.
- [ ] **UC-M09.07-C041-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Device surfaces and per-probe resource limit” in the “Device and operation probes” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M09.07-C041-T10 · Contract review:** Review the “Device and operation probes” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M09.07-C042 · Delivery

**Original checklist item:** Test exposed device handlers and host operations against allowed capabilities.

- [ ] **UC-M09.07-C042-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Device and operation probes”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M09.07-C042-T02 · Change plan:** Break the source delivery for “Device and operation probes” into concrete edit targets and reviewable outputs; keep the UC-M09.07 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M09.07-C042-T03 · Core artifact:** Create the “Device and operation probes” fixture or harness for this source instruction: Test exposed device handlers and host operations against allowed capabilities.
- [ ] **UC-M09.07-C042-T04 · Concrete realization:** Connect the “Device and operation probes” harness to its actual intended target, set the expected oracle before running it, and distinguish a mock/control run from a target run.
- [ ] **UC-M09.07-C042-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Device and operation probes” needed to preserve “Guest input cannot invoke forbidden host operations through a device”; record an enforcement gap where only a model exists.
- [ ] **UC-M09.07-C042-T06 · Dependency connection:** Connect the “Device and operation probes” qualification artifact to guest-controlled interfaces, effective host policies and declared tenant threat assumptions; record the target identity and what the harness actually exercises.
- [ ] **UC-M09.07-C042-T07 · Resource behavior:** Account for “Device surfaces and per-probe resource limit” in “Device and operation probes”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M09.07-C042-T08 · Delivery check:** Run a known-valid control and a deliberately failing control for “Device and operation probes”; confirm the harness distinguishes their observed outcomes.
- [ ] **UC-M09.07-C042-T09 · Patch review:** Review the “Device and operation probes” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M09.07-C042-T10 · Delivery handoff:** Publish the “Device and operation probes” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M09.07-C043 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Guest input cannot invoke forbidden host operations through a device. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M09.07-C043-T01 · Named property:** Create a stable property/check name under this parent for “Device and operation probes”; copy its required invariant exactly: “Guest input cannot invoke forbidden host operations through a device”.
- [ ] **UC-M09.07-C043-T02 · Observable terms:** Define each term in the “Device and operation probes” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M09.07-C043-T03 · Precondition set:** List the preconditions under which “Guest input cannot invoke forbidden host operations through a device” must hold for “Device and operation probes”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M09.07-C043-T04 · Transition coverage:** Map the “Device and operation probes” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M09.07-C043-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Device and operation probes”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M09.07-C043-T06 · Satisfying fixture:** Create a concrete “Device and operation probes” case that satisfies “Guest input cannot invoke forbidden host operations through a device”; record its expected observation before running the assertion or review.
- [ ] **UC-M09.07-C043-T07 · Violating fixture:** Create the source counterexample “A malformed device request bypasses broker authorization” for “Device and operation probes”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M09.07-C043-T08 · Enforcement evidence:** Exercise the “Device and operation probes” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M09.07-C043-T09 · Regression linkage:** Link the “Device and operation probes” property to changes in guest-controlled interfaces, effective host policies and declared tenant threat assumptions; record which dependency or contract changes require rerunning it.
- [ ] **UC-M09.07-C043-T10 · Property disposition:** Compare the satisfying and violating “Device and operation probes” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M09.07-C044 · Integration

**Original checklist item:** Integrate device and operation probes with guest-controlled interfaces, effective host policies and declared tenant threat assumptions; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M09.07-C044-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Device and operation probes” across guest-controlled interfaces, effective host policies and declared tenant threat assumptions; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M09.07-C044-T02 · Field mapping:** Map every “Device and operation probes” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M09.07-C044-T03 · Prerequisite identities:** Record the actual prerequisites for “Device and operation probes” (source dependency list: UC-M03.03, UC-M03.04, UC-M03.05, UC-M09.06); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M09.07-C044-T04 · Ownership agreement:** Specify who owns “Device and operation probes” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M09.07-C044-T05 · Handoff implementation:** Connect “Device and operation probes” through the mapped seam using the real adapter or explicit specification reference; preserve “Guest input cannot invoke forbidden host operations through a device” across the handoff.
- [ ] **UC-M09.07-C044-T06 · Absent-input case:** Omit one required “Device and operation probes” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M09.07-C044-T07 · Stale-input case:** Supply an outdated “Device and operation probes” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M09.07-C044-T08 · Incompatible-input case:** Supply an incompatible “Device and operation probes” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M09.07-C044-T09 · Valid integration trace:** Run a valid “Device and operation probes” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M09.07-C044-T10 · Seam review:** Reconcile the “Device and operation probes” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M09.07-C045 · Valid-case test

**Original checklist item:** Run a known-valid control for device and operation probes; verify that the harness reaches its intended target and compare observed measurements or verdicts with predeclared expectations.

- [ ] **UC-M09.07-C045-T01 · Valid fixture choice:** Choose a known-valid control for “Device and operation probes”; document why it should pass and how it proves the harness reaches the intended target.
- [ ] **UC-M09.07-C045-T02 · Expected-result oracle:** Specify the “Device and operation probes” expected result independently of the implementation output; include the property “Guest input cannot invoke forbidden host operations through a device” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M09.07-C045-T03 · Fixture material:** Create the concrete “Device and operation probes” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M09.07-C045-T04 · Target preparation:** Prepare the “Device and operation probes” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M09.07-C045-T05 · Initial-state record:** Record the initial “Device and operation probes” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M09.07-C045-T06 · Valid-path execution:** Run the “Device and operation probes” known-valid control on the identified target; retain enough observations to prove the correct target was exercised.
- [ ] **UC-M09.07-C045-T07 · Outcome comparison:** Compare every declared “Device and operation probes” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M09.07-C045-T08 · State and bounds check:** Inspect the “Device and operation probes” ownership/state effects and actual use of “Device surfaces and per-probe resource limit”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M09.07-C045-T09 · Repeatability check:** Repeat the same “Device and operation probes” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M09.07-C045-T10 · Positive evidence:** Attach the “Device and operation probes” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M09.07-C046 · Negative test

**Original checklist item:** Negative case: A malformed device request bypasses broker authorization. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M09.07-C046-T01 · Adverse-case definition:** Create a test record for the exact “Device and operation probes” source counterexample: “A malformed device request bypasses broker authorization”; state which precondition or invariant it challenges.
- [ ] **UC-M09.07-C046-T02 · Safe fixture boundary:** Define the contained test boundary for “Device and operation probes”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M09.07-C046-T03 · Valid control:** Construct a valid “Device and operation probes” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M09.07-C046-T04 · Minimal adverse input:** Derive the “Device and operation probes” adverse fixture from the control with the smallest documented change needed to reproduce “A malformed device request bypasses broker authorization”; retain that change as reproducible data.
- [ ] **UC-M09.07-C046-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Device and operation probes”; require “Guest input cannot invoke forbidden host operations through a device” and forbid a false-success verdict.
- [ ] **UC-M09.07-C046-T06 · Adverse execution:** Exercise the “Device and operation probes” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M09.07-C046-T07 · Effect inspection:** Inspect “Device and operation probes” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M09.07-C046-T08 · Refusal versus failure:** Confirm the “Device and operation probes” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M09.07-C046-T09 · Reset and retention:** Restore only the disposable “Device and operation probes” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M09.07-C046-T10 · Negative regression:** Register the “Device and operation probes” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M09.07-C047 · Change / failure test

**Original checklist item:** Exercise device and operation probes when the backend, host configuration or shared-resource assumption changes after assessment; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M09.07-C047-T01 · Scenario record:** Write the “Device and operation probes” change/failure scenario exactly as supplied: the backend, host configuration or shared-resource assumption changes after assessment; identify the property that must remain true: “Guest input cannot invoke forbidden host operations through a device”.
- [ ] **UC-M09.07-C047-T02 · Baseline capture:** Create a known-valid “Device and operation probes” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M09.07-C047-T03 · Injection map:** Locate the “Device and operation probes” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M09.07-C047-T04 · Disposition oracle:** Define the legal intermediate and final “Device and operation probes” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M09.07-C047-T05 · Controlled trigger:** Introduce the controlled “Device and operation probes” scenario in the disposable fixture: the backend, host configuration or shared-resource assumption changes after assessment; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M09.07-C047-T06 · Intermediate inspection:** Inspect the “Device and operation probes” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M09.07-C047-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Device and operation probes”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M09.07-C047-T08 · Stale-evidence cleanup:** Invalidate superseded “Device and operation probes” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M09.07-C047-T09 · Repeat and compare:** Repeat the selected “Device and operation probes” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M09.07-C047-T10 · Failure evidence:** Publish the “Device and operation probes” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M09.07-C048 · Bounds

**Original checklist item:** Set a documented campaign budget for device surfaces and per-probe resource limit; record actual consumption, incomplete coverage and the disposition when the budget is exhausted.

- [ ] **UC-M09.07-C048-T01 · Quantity inventory:** Create a measurement inventory for “Device and operation probes”: “Device surfaces and per-probe resource limit”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M09.07-C048-T02 · Measurement method:** Choose how to observe each “Device and operation probes” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M09.07-C048-T03 · Budget decision:** Select justified campaign and target-resource budgets for “Device and operation probes”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M09.07-C048-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Device and operation probes” cases for “Device surfaces and per-probe resource limit”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M09.07-C048-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Device and operation probes” limit; preserve “Guest input cannot invoke forbidden host operations through a device”.
- [ ] **UC-M09.07-C048-T06 · Normal measurement:** Run or review the normal “Device and operation probes” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M09.07-C048-T07 · At-limit measurement:** Exercise the “Device and operation probes” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M09.07-C048-T08 · Over-limit measurement:** Exercise the “Device and operation probes” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M09.07-C048-T09 · Uncovered-scope report:** List the “Device and operation probes” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M09.07-C048-T10 · Limit evidence:** Publish the selected “Device and operation probes” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M09.07-C049 · Diagnostics / review

**Original checklist item:** Report device and operation probes results with executed, failed, skipped and unavailable cases separated; preserve the underlying observations and do not manufacture missing measurements.

- [ ] **UC-M09.07-C049-T01 · Result inventory:** Enumerate the required “Device and operation probes” qualification cases and intended targets before aggregating results; keep the planned denominator visible.
- [ ] **UC-M09.07-C049-T02 · Verdict schema:** Define separate executed-pass, executed-fail, skipped, unavailable and untested outcomes for “Device and operation probes”; document how incomplete cases block relevant claims.
- [ ] **UC-M09.07-C049-T03 · Identity fields:** Attach the actual target, fixture, configuration and revision identifiers to each “Device and operation probes” result; do not attribute host-only evidence to a guest or another OS.
- [ ] **UC-M09.07-C049-T04 · Observation capture:** Capture bounded raw “Device and operation probes” observations and harness errors; retain enough information to verify the reported oracle comparison.
- [ ] **UC-M09.07-C049-T05 · Aggregation rules:** Implement the “Device and operation probes” count/reduction rule so failures and missing measurements cannot disappear; preserve “Guest input cannot invoke forbidden host operations through a device”.
- [ ] **UC-M09.07-C049-T06 · Failure visibility:** Feed a failing “Device and operation probes” control through the report path; assert the exact failed case and underlying observation remain visible.
- [ ] **UC-M09.07-C049-T07 · Missing-result visibility:** Withhold a required “Device and operation probes” measurement or target; verify the report uses unavailable/untested rather than a fabricated zero or passing value.
- [ ] **UC-M09.07-C049-T08 · Bounds and redaction:** Check “Device and operation probes” report size and retention against “Device surfaces and per-probe resource limit”; remove secrets while retaining fixture and subject references.
- [ ] **UC-M09.07-C049-T09 · Report reconciliation:** Reconcile the “Device and operation probes” summary with every underlying case record; account for the full planned denominator and all omitted scope.
- [ ] **UC-M09.07-C049-T10 · Qualification handoff:** Publish the “Device and operation probes” report with measured observations, coverage limits and blockers; state which actual targets remain unqualified.

### UC-M09.07-C050 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for device and operation probes; label unexecuted checks as untested.

- [ ] **UC-M09.07-C050-T01 · Evidence inventory:** List the “Device and operation probes” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M09.07-C050-T02 · Artifact references:** Record the exact “Device and operation probes” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M09.07-C050-T03 · Fixture references:** Attach the “Device and operation probes” fixture IDs, input identities and oracle definition; preserve the source counterexample “A malformed device request bypasses broker authorization” as a distinct evidence case.
- [ ] **UC-M09.07-C050-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Device and operation probes”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M09.07-C050-T05 · Environment record:** Record the actual “Device and operation probes” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M09.07-C050-T06 · Expected versus observed:** Pair every “Device and operation probes” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M09.07-C050-T07 · Failure and limit records:** Attach “Device and operation probes” change/failure and bounds evidence where required; include uncovered “Device surfaces and per-probe resource limit” and unresolved violations of “Guest input cannot invoke forbidden host operations through a device”.
- [ ] **UC-M09.07-C050-T08 · Evidence hygiene:** Check the “Device and operation probes” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M09.07-C050-T09 · Reproduction review:** Have the “Device and operation probes” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M09.07-C050-T10 · Acceptance linkage:** Link the “Device and operation probes” evidence to its parent and UC-M09.07 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 06. Network boundary probes

**Source delivery:** Exercise egress, lateral and host management endpoint restrictions.

**Source invariant:** Observed traffic restrictions match the declared profile.

**Source negative case:** An offline guest reaches a host control endpoint.

**Source bounded quantities:** Traffic probes and observation duration.

### UC-M09.07-C051 · Contract

**Original checklist item:** Define the qualification objective for network boundary probes, including the actual target implementation, prerequisites, observable oracle and explicit exclusions.

- [ ] **UC-M09.07-C051-T01 · Scope statement:** Write the qualification question for “Network boundary probes”; identify the actual target, claimed capability and observations that can answer that question.
- [ ] **UC-M09.07-C051-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Network boundary probes”; record each producer, representation and missing-value meaning.
- [ ] **UC-M09.07-C051-T03 · Output inventory:** List the outputs of “Network boundary probes” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M09.07-C051-T04 · Field dictionary:** Create a field-and-term dictionary for “Network boundary probes”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M09.07-C051-T05 · Prerequisite contract:** Map “Network boundary probes” to the source component prerequisites (UC-M03.03, UC-M03.04, UC-M03.05, UC-M09.06); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M09.07-C051-T06 · Authority map:** Identify who may produce, change and consume “Network boundary probes”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M09.07-C051-T07 · Invariant clause:** Add a normative clause for “Network boundary probes” that preserves “Observed traffic restrictions match the declared profile”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M09.07-C051-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Network boundary probes”; include the source counterexample “An offline guest reaches a host control endpoint” and the intended safe disposition.
- [ ] **UC-M09.07-C051-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Traffic probes and observation duration” in the “Network boundary probes” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M09.07-C051-T10 · Contract review:** Review the “Network boundary probes” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M09.07-C052 · Delivery

**Original checklist item:** Exercise egress, lateral and host management endpoint restrictions.

- [ ] **UC-M09.07-C052-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Network boundary probes”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M09.07-C052-T02 · Change plan:** Break the source delivery for “Network boundary probes” into concrete edit targets and reviewable outputs; keep the UC-M09.07 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M09.07-C052-T03 · Core artifact:** Create the “Network boundary probes” fixture or harness for this source instruction: Exercise egress, lateral and host management endpoint restrictions.
- [ ] **UC-M09.07-C052-T04 · Concrete realization:** Connect the “Network boundary probes” harness to its actual intended target, set the expected oracle before running it, and distinguish a mock/control run from a target run.
- [ ] **UC-M09.07-C052-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Network boundary probes” needed to preserve “Observed traffic restrictions match the declared profile”; record an enforcement gap where only a model exists.
- [ ] **UC-M09.07-C052-T06 · Dependency connection:** Connect the “Network boundary probes” qualification artifact to guest-controlled interfaces, effective host policies and declared tenant threat assumptions; record the target identity and what the harness actually exercises.
- [ ] **UC-M09.07-C052-T07 · Resource behavior:** Account for “Traffic probes and observation duration” in “Network boundary probes”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M09.07-C052-T08 · Delivery check:** Run a known-valid control and a deliberately failing control for “Network boundary probes”; confirm the harness distinguishes their observed outcomes.
- [ ] **UC-M09.07-C052-T09 · Patch review:** Review the “Network boundary probes” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M09.07-C052-T10 · Delivery handoff:** Publish the “Network boundary probes” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M09.07-C053 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Observed traffic restrictions match the declared profile. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M09.07-C053-T01 · Named property:** Create a stable property/check name under this parent for “Network boundary probes”; copy its required invariant exactly: “Observed traffic restrictions match the declared profile”.
- [ ] **UC-M09.07-C053-T02 · Observable terms:** Define each term in the “Network boundary probes” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M09.07-C053-T03 · Precondition set:** List the preconditions under which “Observed traffic restrictions match the declared profile” must hold for “Network boundary probes”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M09.07-C053-T04 · Transition coverage:** Map the “Network boundary probes” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M09.07-C053-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Network boundary probes”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M09.07-C053-T06 · Satisfying fixture:** Create a concrete “Network boundary probes” case that satisfies “Observed traffic restrictions match the declared profile”; record its expected observation before running the assertion or review.
- [ ] **UC-M09.07-C053-T07 · Violating fixture:** Create the source counterexample “An offline guest reaches a host control endpoint” for “Network boundary probes”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M09.07-C053-T08 · Enforcement evidence:** Exercise the “Network boundary probes” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M09.07-C053-T09 · Regression linkage:** Link the “Network boundary probes” property to changes in guest-controlled interfaces, effective host policies and declared tenant threat assumptions; record which dependency or contract changes require rerunning it.
- [ ] **UC-M09.07-C053-T10 · Property disposition:** Compare the satisfying and violating “Network boundary probes” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M09.07-C054 · Integration

**Original checklist item:** Integrate network boundary probes with guest-controlled interfaces, effective host policies and declared tenant threat assumptions; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M09.07-C054-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Network boundary probes” across guest-controlled interfaces, effective host policies and declared tenant threat assumptions; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M09.07-C054-T02 · Field mapping:** Map every “Network boundary probes” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M09.07-C054-T03 · Prerequisite identities:** Record the actual prerequisites for “Network boundary probes” (source dependency list: UC-M03.03, UC-M03.04, UC-M03.05, UC-M09.06); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M09.07-C054-T04 · Ownership agreement:** Specify who owns “Network boundary probes” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M09.07-C054-T05 · Handoff implementation:** Connect “Network boundary probes” through the mapped seam using the real adapter or explicit specification reference; preserve “Observed traffic restrictions match the declared profile” across the handoff.
- [ ] **UC-M09.07-C054-T06 · Absent-input case:** Omit one required “Network boundary probes” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M09.07-C054-T07 · Stale-input case:** Supply an outdated “Network boundary probes” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M09.07-C054-T08 · Incompatible-input case:** Supply an incompatible “Network boundary probes” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M09.07-C054-T09 · Valid integration trace:** Run a valid “Network boundary probes” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M09.07-C054-T10 · Seam review:** Reconcile the “Network boundary probes” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M09.07-C055 · Valid-case test

**Original checklist item:** Run a known-valid control for network boundary probes; verify that the harness reaches its intended target and compare observed measurements or verdicts with predeclared expectations.

- [ ] **UC-M09.07-C055-T01 · Valid fixture choice:** Choose a known-valid control for “Network boundary probes”; document why it should pass and how it proves the harness reaches the intended target.
- [ ] **UC-M09.07-C055-T02 · Expected-result oracle:** Specify the “Network boundary probes” expected result independently of the implementation output; include the property “Observed traffic restrictions match the declared profile” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M09.07-C055-T03 · Fixture material:** Create the concrete “Network boundary probes” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M09.07-C055-T04 · Target preparation:** Prepare the “Network boundary probes” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M09.07-C055-T05 · Initial-state record:** Record the initial “Network boundary probes” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M09.07-C055-T06 · Valid-path execution:** Run the “Network boundary probes” known-valid control on the identified target; retain enough observations to prove the correct target was exercised.
- [ ] **UC-M09.07-C055-T07 · Outcome comparison:** Compare every declared “Network boundary probes” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M09.07-C055-T08 · State and bounds check:** Inspect the “Network boundary probes” ownership/state effects and actual use of “Traffic probes and observation duration”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M09.07-C055-T09 · Repeatability check:** Repeat the same “Network boundary probes” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M09.07-C055-T10 · Positive evidence:** Attach the “Network boundary probes” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M09.07-C056 · Negative test

**Original checklist item:** Negative case: An offline guest reaches a host control endpoint. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M09.07-C056-T01 · Adverse-case definition:** Create a test record for the exact “Network boundary probes” source counterexample: “An offline guest reaches a host control endpoint”; state which precondition or invariant it challenges.
- [ ] **UC-M09.07-C056-T02 · Safe fixture boundary:** Define the contained test boundary for “Network boundary probes”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M09.07-C056-T03 · Valid control:** Construct a valid “Network boundary probes” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M09.07-C056-T04 · Minimal adverse input:** Derive the “Network boundary probes” adverse fixture from the control with the smallest documented change needed to reproduce “An offline guest reaches a host control endpoint”; retain that change as reproducible data.
- [ ] **UC-M09.07-C056-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Network boundary probes”; require “Observed traffic restrictions match the declared profile” and forbid a false-success verdict.
- [ ] **UC-M09.07-C056-T06 · Adverse execution:** Exercise the “Network boundary probes” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M09.07-C056-T07 · Effect inspection:** Inspect “Network boundary probes” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M09.07-C056-T08 · Refusal versus failure:** Confirm the “Network boundary probes” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M09.07-C056-T09 · Reset and retention:** Restore only the disposable “Network boundary probes” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M09.07-C056-T10 · Negative regression:** Register the “Network boundary probes” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M09.07-C057 · Change / failure test

**Original checklist item:** Exercise network boundary probes when the backend, host configuration or shared-resource assumption changes after assessment; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M09.07-C057-T01 · Scenario record:** Write the “Network boundary probes” change/failure scenario exactly as supplied: the backend, host configuration or shared-resource assumption changes after assessment; identify the property that must remain true: “Observed traffic restrictions match the declared profile”.
- [ ] **UC-M09.07-C057-T02 · Baseline capture:** Create a known-valid “Network boundary probes” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M09.07-C057-T03 · Injection map:** Locate the “Network boundary probes” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M09.07-C057-T04 · Disposition oracle:** Define the legal intermediate and final “Network boundary probes” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M09.07-C057-T05 · Controlled trigger:** Introduce the controlled “Network boundary probes” scenario in the disposable fixture: the backend, host configuration or shared-resource assumption changes after assessment; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M09.07-C057-T06 · Intermediate inspection:** Inspect the “Network boundary probes” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M09.07-C057-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Network boundary probes”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M09.07-C057-T08 · Stale-evidence cleanup:** Invalidate superseded “Network boundary probes” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M09.07-C057-T09 · Repeat and compare:** Repeat the selected “Network boundary probes” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M09.07-C057-T10 · Failure evidence:** Publish the “Network boundary probes” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M09.07-C058 · Bounds

**Original checklist item:** Set a documented campaign budget for traffic probes and observation duration; record actual consumption, incomplete coverage and the disposition when the budget is exhausted.

- [ ] **UC-M09.07-C058-T01 · Quantity inventory:** Create a measurement inventory for “Network boundary probes”: “Traffic probes and observation duration”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M09.07-C058-T02 · Measurement method:** Choose how to observe each “Network boundary probes” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M09.07-C058-T03 · Budget decision:** Select justified campaign and target-resource budgets for “Network boundary probes”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M09.07-C058-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Network boundary probes” cases for “Traffic probes and observation duration”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M09.07-C058-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Network boundary probes” limit; preserve “Observed traffic restrictions match the declared profile”.
- [ ] **UC-M09.07-C058-T06 · Normal measurement:** Run or review the normal “Network boundary probes” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M09.07-C058-T07 · At-limit measurement:** Exercise the “Network boundary probes” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M09.07-C058-T08 · Over-limit measurement:** Exercise the “Network boundary probes” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M09.07-C058-T09 · Uncovered-scope report:** List the “Network boundary probes” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M09.07-C058-T10 · Limit evidence:** Publish the selected “Network boundary probes” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M09.07-C059 · Diagnostics / review

**Original checklist item:** Report network boundary probes results with executed, failed, skipped and unavailable cases separated; preserve the underlying observations and do not manufacture missing measurements.

- [ ] **UC-M09.07-C059-T01 · Result inventory:** Enumerate the required “Network boundary probes” qualification cases and intended targets before aggregating results; keep the planned denominator visible.
- [ ] **UC-M09.07-C059-T02 · Verdict schema:** Define separate executed-pass, executed-fail, skipped, unavailable and untested outcomes for “Network boundary probes”; document how incomplete cases block relevant claims.
- [ ] **UC-M09.07-C059-T03 · Identity fields:** Attach the actual target, fixture, configuration and revision identifiers to each “Network boundary probes” result; do not attribute host-only evidence to a guest or another OS.
- [ ] **UC-M09.07-C059-T04 · Observation capture:** Capture bounded raw “Network boundary probes” observations and harness errors; retain enough information to verify the reported oracle comparison.
- [ ] **UC-M09.07-C059-T05 · Aggregation rules:** Implement the “Network boundary probes” count/reduction rule so failures and missing measurements cannot disappear; preserve “Observed traffic restrictions match the declared profile”.
- [ ] **UC-M09.07-C059-T06 · Failure visibility:** Feed a failing “Network boundary probes” control through the report path; assert the exact failed case and underlying observation remain visible.
- [ ] **UC-M09.07-C059-T07 · Missing-result visibility:** Withhold a required “Network boundary probes” measurement or target; verify the report uses unavailable/untested rather than a fabricated zero or passing value.
- [ ] **UC-M09.07-C059-T08 · Bounds and redaction:** Check “Network boundary probes” report size and retention against “Traffic probes and observation duration”; remove secrets while retaining fixture and subject references.
- [ ] **UC-M09.07-C059-T09 · Report reconciliation:** Reconcile the “Network boundary probes” summary with every underlying case record; account for the full planned denominator and all omitted scope.
- [ ] **UC-M09.07-C059-T10 · Qualification handoff:** Publish the “Network boundary probes” report with measured observations, coverage limits and blockers; state which actual targets remain unqualified.

### UC-M09.07-C060 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for network boundary probes; label unexecuted checks as untested.

- [ ] **UC-M09.07-C060-T01 · Evidence inventory:** List the “Network boundary probes” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M09.07-C060-T02 · Artifact references:** Record the exact “Network boundary probes” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M09.07-C060-T03 · Fixture references:** Attach the “Network boundary probes” fixture IDs, input identities and oracle definition; preserve the source counterexample “An offline guest reaches a host control endpoint” as a distinct evidence case.
- [ ] **UC-M09.07-C060-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Network boundary probes”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M09.07-C060-T05 · Environment record:** Record the actual “Network boundary probes” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M09.07-C060-T06 · Expected versus observed:** Pair every “Network boundary probes” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M09.07-C060-T07 · Failure and limit records:** Attach “Network boundary probes” change/failure and bounds evidence where required; include uncovered “Traffic probes and observation duration” and unresolved violations of “Observed traffic restrictions match the declared profile”.
- [ ] **UC-M09.07-C060-T08 · Evidence hygiene:** Check the “Network boundary probes” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M09.07-C060-T09 · Reproduction review:** Have the “Network boundary probes” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M09.07-C060-T10 · Acceptance linkage:** Link the “Network boundary probes” evidence to its parent and UC-M09.07 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 07. Resource isolation probes

**Source delivery:** Assess shared CPU, memory and I/O effects within the selected threat model.

**Source invariant:** Resource-isolation claims match measured interference and enforced limits.

**Source negative case:** One guest's flood violates another guest's promised boundary.

**Source bounded quantities:** Co-running guests and pressure duration.

### UC-M09.07-C061 · Contract

**Original checklist item:** Define the qualification objective for resource isolation probes, including the actual target implementation, prerequisites, observable oracle and explicit exclusions.

- [ ] **UC-M09.07-C061-T01 · Scope statement:** Write the qualification question for “Resource isolation probes”; identify the actual target, claimed capability and observations that can answer that question.
- [ ] **UC-M09.07-C061-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Resource isolation probes”; record each producer, representation and missing-value meaning.
- [ ] **UC-M09.07-C061-T03 · Output inventory:** List the outputs of “Resource isolation probes” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M09.07-C061-T04 · Field dictionary:** Create a field-and-term dictionary for “Resource isolation probes”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M09.07-C061-T05 · Prerequisite contract:** Map “Resource isolation probes” to the source component prerequisites (UC-M03.03, UC-M03.04, UC-M03.05, UC-M09.06); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M09.07-C061-T06 · Authority map:** Identify who may produce, change and consume “Resource isolation probes”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M09.07-C061-T07 · Invariant clause:** Add a normative clause for “Resource isolation probes” that preserves “Resource-isolation claims match measured interference and enforced limits”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M09.07-C061-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Resource isolation probes”; include the source counterexample “One guest's flood violates another guest's promised boundary” and the intended safe disposition.
- [ ] **UC-M09.07-C061-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Co-running guests and pressure duration” in the “Resource isolation probes” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M09.07-C061-T10 · Contract review:** Review the “Resource isolation probes” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M09.07-C062 · Delivery

**Original checklist item:** Assess shared CPU, memory and I/O effects within the selected threat model.

- [ ] **UC-M09.07-C062-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Resource isolation probes”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M09.07-C062-T02 · Change plan:** Break the source delivery for “Resource isolation probes” into concrete edit targets and reviewable outputs; keep the UC-M09.07 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M09.07-C062-T03 · Core artifact:** Create the “Resource isolation probes” fixture or harness for this source instruction: Assess shared CPU, memory and I/O effects within the selected threat model.
- [ ] **UC-M09.07-C062-T04 · Concrete realization:** Connect the “Resource isolation probes” harness to its actual intended target, set the expected oracle before running it, and distinguish a mock/control run from a target run.
- [ ] **UC-M09.07-C062-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Resource isolation probes” needed to preserve “Resource-isolation claims match measured interference and enforced limits”; record an enforcement gap where only a model exists.
- [ ] **UC-M09.07-C062-T06 · Dependency connection:** Connect the “Resource isolation probes” qualification artifact to guest-controlled interfaces, effective host policies and declared tenant threat assumptions; record the target identity and what the harness actually exercises.
- [ ] **UC-M09.07-C062-T07 · Resource behavior:** Account for “Co-running guests and pressure duration” in “Resource isolation probes”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M09.07-C062-T08 · Delivery check:** Run a known-valid control and a deliberately failing control for “Resource isolation probes”; confirm the harness distinguishes their observed outcomes.
- [ ] **UC-M09.07-C062-T09 · Patch review:** Review the “Resource isolation probes” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M09.07-C062-T10 · Delivery handoff:** Publish the “Resource isolation probes” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M09.07-C063 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Resource-isolation claims match measured interference and enforced limits. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M09.07-C063-T01 · Named property:** Create a stable property/check name under this parent for “Resource isolation probes”; copy its required invariant exactly: “Resource-isolation claims match measured interference and enforced limits”.
- [ ] **UC-M09.07-C063-T02 · Observable terms:** Define each term in the “Resource isolation probes” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M09.07-C063-T03 · Precondition set:** List the preconditions under which “Resource-isolation claims match measured interference and enforced limits” must hold for “Resource isolation probes”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M09.07-C063-T04 · Transition coverage:** Map the “Resource isolation probes” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M09.07-C063-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Resource isolation probes”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M09.07-C063-T06 · Satisfying fixture:** Create a concrete “Resource isolation probes” case that satisfies “Resource-isolation claims match measured interference and enforced limits”; record its expected observation before running the assertion or review.
- [ ] **UC-M09.07-C063-T07 · Violating fixture:** Create the source counterexample “One guest's flood violates another guest's promised boundary” for “Resource isolation probes”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M09.07-C063-T08 · Enforcement evidence:** Exercise the “Resource isolation probes” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M09.07-C063-T09 · Regression linkage:** Link the “Resource isolation probes” property to changes in guest-controlled interfaces, effective host policies and declared tenant threat assumptions; record which dependency or contract changes require rerunning it.
- [ ] **UC-M09.07-C063-T10 · Property disposition:** Compare the satisfying and violating “Resource isolation probes” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M09.07-C064 · Integration

**Original checklist item:** Integrate resource isolation probes with guest-controlled interfaces, effective host policies and declared tenant threat assumptions; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M09.07-C064-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Resource isolation probes” across guest-controlled interfaces, effective host policies and declared tenant threat assumptions; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M09.07-C064-T02 · Field mapping:** Map every “Resource isolation probes” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M09.07-C064-T03 · Prerequisite identities:** Record the actual prerequisites for “Resource isolation probes” (source dependency list: UC-M03.03, UC-M03.04, UC-M03.05, UC-M09.06); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M09.07-C064-T04 · Ownership agreement:** Specify who owns “Resource isolation probes” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M09.07-C064-T05 · Handoff implementation:** Connect “Resource isolation probes” through the mapped seam using the real adapter or explicit specification reference; preserve “Resource-isolation claims match measured interference and enforced limits” across the handoff.
- [ ] **UC-M09.07-C064-T06 · Absent-input case:** Omit one required “Resource isolation probes” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M09.07-C064-T07 · Stale-input case:** Supply an outdated “Resource isolation probes” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M09.07-C064-T08 · Incompatible-input case:** Supply an incompatible “Resource isolation probes” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M09.07-C064-T09 · Valid integration trace:** Run a valid “Resource isolation probes” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M09.07-C064-T10 · Seam review:** Reconcile the “Resource isolation probes” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M09.07-C065 · Valid-case test

**Original checklist item:** Run a known-valid control for resource isolation probes; verify that the harness reaches its intended target and compare observed measurements or verdicts with predeclared expectations.

- [ ] **UC-M09.07-C065-T01 · Valid fixture choice:** Choose a known-valid control for “Resource isolation probes”; document why it should pass and how it proves the harness reaches the intended target.
- [ ] **UC-M09.07-C065-T02 · Expected-result oracle:** Specify the “Resource isolation probes” expected result independently of the implementation output; include the property “Resource-isolation claims match measured interference and enforced limits” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M09.07-C065-T03 · Fixture material:** Create the concrete “Resource isolation probes” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M09.07-C065-T04 · Target preparation:** Prepare the “Resource isolation probes” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M09.07-C065-T05 · Initial-state record:** Record the initial “Resource isolation probes” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M09.07-C065-T06 · Valid-path execution:** Run the “Resource isolation probes” known-valid control on the identified target; retain enough observations to prove the correct target was exercised.
- [ ] **UC-M09.07-C065-T07 · Outcome comparison:** Compare every declared “Resource isolation probes” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M09.07-C065-T08 · State and bounds check:** Inspect the “Resource isolation probes” ownership/state effects and actual use of “Co-running guests and pressure duration”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M09.07-C065-T09 · Repeatability check:** Repeat the same “Resource isolation probes” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M09.07-C065-T10 · Positive evidence:** Attach the “Resource isolation probes” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M09.07-C066 · Negative test

**Original checklist item:** Negative case: One guest's flood violates another guest's promised boundary. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M09.07-C066-T01 · Adverse-case definition:** Create a test record for the exact “Resource isolation probes” source counterexample: “One guest's flood violates another guest's promised boundary”; state which precondition or invariant it challenges.
- [ ] **UC-M09.07-C066-T02 · Safe fixture boundary:** Define the contained test boundary for “Resource isolation probes”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M09.07-C066-T03 · Valid control:** Construct a valid “Resource isolation probes” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M09.07-C066-T04 · Minimal adverse input:** Derive the “Resource isolation probes” adverse fixture from the control with the smallest documented change needed to reproduce “One guest's flood violates another guest's promised boundary”; retain that change as reproducible data.
- [ ] **UC-M09.07-C066-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Resource isolation probes”; require “Resource-isolation claims match measured interference and enforced limits” and forbid a false-success verdict.
- [ ] **UC-M09.07-C066-T06 · Adverse execution:** Exercise the “Resource isolation probes” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M09.07-C066-T07 · Effect inspection:** Inspect “Resource isolation probes” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M09.07-C066-T08 · Refusal versus failure:** Confirm the “Resource isolation probes” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M09.07-C066-T09 · Reset and retention:** Restore only the disposable “Resource isolation probes” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M09.07-C066-T10 · Negative regression:** Register the “Resource isolation probes” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M09.07-C067 · Change / failure test

**Original checklist item:** Exercise resource isolation probes when the backend, host configuration or shared-resource assumption changes after assessment; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M09.07-C067-T01 · Scenario record:** Write the “Resource isolation probes” change/failure scenario exactly as supplied: the backend, host configuration or shared-resource assumption changes after assessment; identify the property that must remain true: “Resource-isolation claims match measured interference and enforced limits”.
- [ ] **UC-M09.07-C067-T02 · Baseline capture:** Create a known-valid “Resource isolation probes” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M09.07-C067-T03 · Injection map:** Locate the “Resource isolation probes” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M09.07-C067-T04 · Disposition oracle:** Define the legal intermediate and final “Resource isolation probes” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M09.07-C067-T05 · Controlled trigger:** Introduce the controlled “Resource isolation probes” scenario in the disposable fixture: the backend, host configuration or shared-resource assumption changes after assessment; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M09.07-C067-T06 · Intermediate inspection:** Inspect the “Resource isolation probes” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M09.07-C067-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Resource isolation probes”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M09.07-C067-T08 · Stale-evidence cleanup:** Invalidate superseded “Resource isolation probes” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M09.07-C067-T09 · Repeat and compare:** Repeat the selected “Resource isolation probes” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M09.07-C067-T10 · Failure evidence:** Publish the “Resource isolation probes” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M09.07-C068 · Bounds

**Original checklist item:** Set a documented campaign budget for co-running guests and pressure duration; record actual consumption, incomplete coverage and the disposition when the budget is exhausted.

- [ ] **UC-M09.07-C068-T01 · Quantity inventory:** Create a measurement inventory for “Resource isolation probes”: “Co-running guests and pressure duration”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M09.07-C068-T02 · Measurement method:** Choose how to observe each “Resource isolation probes” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M09.07-C068-T03 · Budget decision:** Select justified campaign and target-resource budgets for “Resource isolation probes”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M09.07-C068-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Resource isolation probes” cases for “Co-running guests and pressure duration”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M09.07-C068-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Resource isolation probes” limit; preserve “Resource-isolation claims match measured interference and enforced limits”.
- [ ] **UC-M09.07-C068-T06 · Normal measurement:** Run or review the normal “Resource isolation probes” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M09.07-C068-T07 · At-limit measurement:** Exercise the “Resource isolation probes” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M09.07-C068-T08 · Over-limit measurement:** Exercise the “Resource isolation probes” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M09.07-C068-T09 · Uncovered-scope report:** List the “Resource isolation probes” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M09.07-C068-T10 · Limit evidence:** Publish the selected “Resource isolation probes” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M09.07-C069 · Diagnostics / review

**Original checklist item:** Report resource isolation probes results with executed, failed, skipped and unavailable cases separated; preserve the underlying observations and do not manufacture missing measurements.

- [ ] **UC-M09.07-C069-T01 · Result inventory:** Enumerate the required “Resource isolation probes” qualification cases and intended targets before aggregating results; keep the planned denominator visible.
- [ ] **UC-M09.07-C069-T02 · Verdict schema:** Define separate executed-pass, executed-fail, skipped, unavailable and untested outcomes for “Resource isolation probes”; document how incomplete cases block relevant claims.
- [ ] **UC-M09.07-C069-T03 · Identity fields:** Attach the actual target, fixture, configuration and revision identifiers to each “Resource isolation probes” result; do not attribute host-only evidence to a guest or another OS.
- [ ] **UC-M09.07-C069-T04 · Observation capture:** Capture bounded raw “Resource isolation probes” observations and harness errors; retain enough information to verify the reported oracle comparison.
- [ ] **UC-M09.07-C069-T05 · Aggregation rules:** Implement the “Resource isolation probes” count/reduction rule so failures and missing measurements cannot disappear; preserve “Resource-isolation claims match measured interference and enforced limits”.
- [ ] **UC-M09.07-C069-T06 · Failure visibility:** Feed a failing “Resource isolation probes” control through the report path; assert the exact failed case and underlying observation remain visible.
- [ ] **UC-M09.07-C069-T07 · Missing-result visibility:** Withhold a required “Resource isolation probes” measurement or target; verify the report uses unavailable/untested rather than a fabricated zero or passing value.
- [ ] **UC-M09.07-C069-T08 · Bounds and redaction:** Check “Resource isolation probes” report size and retention against “Co-running guests and pressure duration”; remove secrets while retaining fixture and subject references.
- [ ] **UC-M09.07-C069-T09 · Report reconciliation:** Reconcile the “Resource isolation probes” summary with every underlying case record; account for the full planned denominator and all omitted scope.
- [ ] **UC-M09.07-C069-T10 · Qualification handoff:** Publish the “Resource isolation probes” report with measured observations, coverage limits and blockers; state which actual targets remain unqualified.

### UC-M09.07-C070 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for resource isolation probes; label unexecuted checks as untested.

- [ ] **UC-M09.07-C070-T01 · Evidence inventory:** List the “Resource isolation probes” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M09.07-C070-T02 · Artifact references:** Record the exact “Resource isolation probes” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M09.07-C070-T03 · Fixture references:** Attach the “Resource isolation probes” fixture IDs, input identities and oracle definition; preserve the source counterexample “One guest's flood violates another guest's promised boundary” as a distinct evidence case.
- [ ] **UC-M09.07-C070-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Resource isolation probes”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M09.07-C070-T05 · Environment record:** Record the actual “Resource isolation probes” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M09.07-C070-T06 · Expected versus observed:** Pair every “Resource isolation probes” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M09.07-C070-T07 · Failure and limit records:** Attach “Resource isolation probes” change/failure and bounds evidence where required; include uncovered “Co-running guests and pressure duration” and unresolved violations of “Resource-isolation claims match measured interference and enforced limits”.
- [ ] **UC-M09.07-C070-T08 · Evidence hygiene:** Check the “Resource isolation probes” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M09.07-C070-T09 · Reproduction review:** Have the “Resource isolation probes” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M09.07-C070-T10 · Acceptance linkage:** Link the “Resource isolation probes” evidence to its parent and UC-M09.07 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 08. Side-channel assumptions

**Source delivery:** Document shared-resource and hardware threats included or excluded from assessment.

**Source invariant:** Unsupported side-channel threats remain explicit exclusions.

**Source negative case:** A report claims absolute isolation without examining shared-resource assumptions.

**Source bounded quantities:** Threat scenarios and evidence-review scope.

### UC-M09.07-C071 · Contract

**Original checklist item:** Define the qualification objective for side-channel assumptions, including the actual target implementation, prerequisites, observable oracle and explicit exclusions.

- [ ] **UC-M09.07-C071-T01 · Scope statement:** Write the qualification question for “Side-channel assumptions”; identify the actual target, claimed capability and observations that can answer that question.
- [ ] **UC-M09.07-C071-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Side-channel assumptions”; record each producer, representation and missing-value meaning.
- [ ] **UC-M09.07-C071-T03 · Output inventory:** List the outputs of “Side-channel assumptions” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M09.07-C071-T04 · Field dictionary:** Create a field-and-term dictionary for “Side-channel assumptions”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M09.07-C071-T05 · Prerequisite contract:** Map “Side-channel assumptions” to the source component prerequisites (UC-M03.03, UC-M03.04, UC-M03.05, UC-M09.06); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M09.07-C071-T06 · Authority map:** Identify who may produce, change and consume “Side-channel assumptions”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M09.07-C071-T07 · Invariant clause:** Add a normative clause for “Side-channel assumptions” that preserves “Unsupported side-channel threats remain explicit exclusions”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M09.07-C071-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Side-channel assumptions”; include the source counterexample “A report claims absolute isolation without examining shared-resource assumptions” and the intended safe disposition.
- [ ] **UC-M09.07-C071-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Threat scenarios and evidence-review scope” in the “Side-channel assumptions” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M09.07-C071-T10 · Contract review:** Review the “Side-channel assumptions” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M09.07-C072 · Delivery

**Original checklist item:** Document shared-resource and hardware threats included or excluded from assessment.

- [ ] **UC-M09.07-C072-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Side-channel assumptions”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M09.07-C072-T02 · Change plan:** Break the source delivery for “Side-channel assumptions” into concrete edit targets and reviewable outputs; keep the UC-M09.07 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M09.07-C072-T03 · Core artifact:** Create the “Side-channel assumptions” model, schema or inventory that realizes this source instruction: Document shared-resource and hardware threats included or excluded from assessment.
- [ ] **UC-M09.07-C072-T04 · Concrete realization:** Populate “Side-channel assumptions” with one concrete worked case; map every required entity or field to its source and flag any unmapped entry.
- [ ] **UC-M09.07-C072-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Side-channel assumptions” needed to preserve “Unsupported side-channel threats remain explicit exclusions”; record an enforcement gap where only a model exists.
- [ ] **UC-M09.07-C072-T06 · Dependency connection:** Connect the “Side-channel assumptions” qualification artifact to guest-controlled interfaces, effective host policies and declared tenant threat assumptions; record the target identity and what the harness actually exercises.
- [ ] **UC-M09.07-C072-T07 · Resource behavior:** Account for “Threat scenarios and evidence-review scope” in “Side-channel assumptions”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M09.07-C072-T08 · Delivery check:** Run a known-valid control and a deliberately failing control for “Side-channel assumptions”; confirm the harness distinguishes their observed outcomes.
- [ ] **UC-M09.07-C072-T09 · Patch review:** Review the “Side-channel assumptions” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M09.07-C072-T10 · Delivery handoff:** Publish the “Side-channel assumptions” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M09.07-C073 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Unsupported side-channel threats remain explicit exclusions. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M09.07-C073-T01 · Named property:** Create a stable property/check name under this parent for “Side-channel assumptions”; copy its required invariant exactly: “Unsupported side-channel threats remain explicit exclusions”.
- [ ] **UC-M09.07-C073-T02 · Observable terms:** Define each term in the “Side-channel assumptions” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M09.07-C073-T03 · Precondition set:** List the preconditions under which “Unsupported side-channel threats remain explicit exclusions” must hold for “Side-channel assumptions”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M09.07-C073-T04 · Transition coverage:** Map the “Side-channel assumptions” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M09.07-C073-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Side-channel assumptions”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M09.07-C073-T06 · Satisfying fixture:** Create a concrete “Side-channel assumptions” case that satisfies “Unsupported side-channel threats remain explicit exclusions”; record its expected observation before running the assertion or review.
- [ ] **UC-M09.07-C073-T07 · Violating fixture:** Create the source counterexample “A report claims absolute isolation without examining shared-resource assumptions” for “Side-channel assumptions”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M09.07-C073-T08 · Enforcement evidence:** Exercise the “Side-channel assumptions” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M09.07-C073-T09 · Regression linkage:** Link the “Side-channel assumptions” property to changes in guest-controlled interfaces, effective host policies and declared tenant threat assumptions; record which dependency or contract changes require rerunning it.
- [ ] **UC-M09.07-C073-T10 · Property disposition:** Compare the satisfying and violating “Side-channel assumptions” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M09.07-C074 · Integration

**Original checklist item:** Integrate side-channel assumptions with guest-controlled interfaces, effective host policies and declared tenant threat assumptions; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M09.07-C074-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Side-channel assumptions” across guest-controlled interfaces, effective host policies and declared tenant threat assumptions; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M09.07-C074-T02 · Field mapping:** Map every “Side-channel assumptions” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M09.07-C074-T03 · Prerequisite identities:** Record the actual prerequisites for “Side-channel assumptions” (source dependency list: UC-M03.03, UC-M03.04, UC-M03.05, UC-M09.06); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M09.07-C074-T04 · Ownership agreement:** Specify who owns “Side-channel assumptions” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M09.07-C074-T05 · Handoff implementation:** Connect “Side-channel assumptions” through the mapped seam using the real adapter or explicit specification reference; preserve “Unsupported side-channel threats remain explicit exclusions” across the handoff.
- [ ] **UC-M09.07-C074-T06 · Absent-input case:** Omit one required “Side-channel assumptions” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M09.07-C074-T07 · Stale-input case:** Supply an outdated “Side-channel assumptions” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M09.07-C074-T08 · Incompatible-input case:** Supply an incompatible “Side-channel assumptions” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M09.07-C074-T09 · Valid integration trace:** Run a valid “Side-channel assumptions” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M09.07-C074-T10 · Seam review:** Reconcile the “Side-channel assumptions” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M09.07-C075 · Valid-case test

**Original checklist item:** Run a known-valid control for side-channel assumptions; verify that the harness reaches its intended target and compare observed measurements or verdicts with predeclared expectations.

- [ ] **UC-M09.07-C075-T01 · Valid fixture choice:** Choose a known-valid control for “Side-channel assumptions”; document why it should pass and how it proves the harness reaches the intended target.
- [ ] **UC-M09.07-C075-T02 · Expected-result oracle:** Specify the “Side-channel assumptions” expected result independently of the implementation output; include the property “Unsupported side-channel threats remain explicit exclusions” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M09.07-C075-T03 · Fixture material:** Create the concrete “Side-channel assumptions” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M09.07-C075-T04 · Target preparation:** Prepare the “Side-channel assumptions” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M09.07-C075-T05 · Initial-state record:** Record the initial “Side-channel assumptions” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M09.07-C075-T06 · Valid-path execution:** Run the “Side-channel assumptions” known-valid control on the identified target; retain enough observations to prove the correct target was exercised.
- [ ] **UC-M09.07-C075-T07 · Outcome comparison:** Compare every declared “Side-channel assumptions” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M09.07-C075-T08 · State and bounds check:** Inspect the “Side-channel assumptions” ownership/state effects and actual use of “Threat scenarios and evidence-review scope”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M09.07-C075-T09 · Repeatability check:** Repeat the same “Side-channel assumptions” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M09.07-C075-T10 · Positive evidence:** Attach the “Side-channel assumptions” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M09.07-C076 · Negative test

**Original checklist item:** Negative case: A report claims absolute isolation without examining shared-resource assumptions. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M09.07-C076-T01 · Adverse-case definition:** Create a test record for the exact “Side-channel assumptions” source counterexample: “A report claims absolute isolation without examining shared-resource assumptions”; state which precondition or invariant it challenges.
- [ ] **UC-M09.07-C076-T02 · Safe fixture boundary:** Define the contained test boundary for “Side-channel assumptions”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M09.07-C076-T03 · Valid control:** Construct a valid “Side-channel assumptions” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M09.07-C076-T04 · Minimal adverse input:** Derive the “Side-channel assumptions” adverse fixture from the control with the smallest documented change needed to reproduce “A report claims absolute isolation without examining shared-resource assumptions”; retain that change as reproducible data.
- [ ] **UC-M09.07-C076-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Side-channel assumptions”; require “Unsupported side-channel threats remain explicit exclusions” and forbid a false-success verdict.
- [ ] **UC-M09.07-C076-T06 · Adverse execution:** Exercise the “Side-channel assumptions” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M09.07-C076-T07 · Effect inspection:** Inspect “Side-channel assumptions” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M09.07-C076-T08 · Refusal versus failure:** Confirm the “Side-channel assumptions” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M09.07-C076-T09 · Reset and retention:** Restore only the disposable “Side-channel assumptions” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M09.07-C076-T10 · Negative regression:** Register the “Side-channel assumptions” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M09.07-C077 · Change / failure test

**Original checklist item:** Exercise side-channel assumptions when the backend, host configuration or shared-resource assumption changes after assessment; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M09.07-C077-T01 · Scenario record:** Write the “Side-channel assumptions” change/failure scenario exactly as supplied: the backend, host configuration or shared-resource assumption changes after assessment; identify the property that must remain true: “Unsupported side-channel threats remain explicit exclusions”.
- [ ] **UC-M09.07-C077-T02 · Baseline capture:** Create a known-valid “Side-channel assumptions” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M09.07-C077-T03 · Injection map:** Locate the “Side-channel assumptions” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M09.07-C077-T04 · Disposition oracle:** Define the legal intermediate and final “Side-channel assumptions” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M09.07-C077-T05 · Controlled trigger:** Introduce the controlled “Side-channel assumptions” scenario in the disposable fixture: the backend, host configuration or shared-resource assumption changes after assessment; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M09.07-C077-T06 · Intermediate inspection:** Inspect the “Side-channel assumptions” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M09.07-C077-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Side-channel assumptions”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M09.07-C077-T08 · Stale-evidence cleanup:** Invalidate superseded “Side-channel assumptions” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M09.07-C077-T09 · Repeat and compare:** Repeat the selected “Side-channel assumptions” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M09.07-C077-T10 · Failure evidence:** Publish the “Side-channel assumptions” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M09.07-C078 · Bounds

**Original checklist item:** Set a documented campaign budget for threat scenarios and evidence-review scope; record actual consumption, incomplete coverage and the disposition when the budget is exhausted.

- [ ] **UC-M09.07-C078-T01 · Quantity inventory:** Create a measurement inventory for “Side-channel assumptions”: “Threat scenarios and evidence-review scope”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M09.07-C078-T02 · Measurement method:** Choose how to observe each “Side-channel assumptions” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M09.07-C078-T03 · Budget decision:** Select justified campaign and target-resource budgets for “Side-channel assumptions”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M09.07-C078-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Side-channel assumptions” cases for “Threat scenarios and evidence-review scope”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M09.07-C078-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Side-channel assumptions” limit; preserve “Unsupported side-channel threats remain explicit exclusions”.
- [ ] **UC-M09.07-C078-T06 · Normal measurement:** Run or review the normal “Side-channel assumptions” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M09.07-C078-T07 · At-limit measurement:** Exercise the “Side-channel assumptions” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M09.07-C078-T08 · Over-limit measurement:** Exercise the “Side-channel assumptions” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M09.07-C078-T09 · Uncovered-scope report:** List the “Side-channel assumptions” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M09.07-C078-T10 · Limit evidence:** Publish the selected “Side-channel assumptions” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M09.07-C079 · Diagnostics / review

**Original checklist item:** Report side-channel assumptions results with executed, failed, skipped and unavailable cases separated; preserve the underlying observations and do not manufacture missing measurements.

- [ ] **UC-M09.07-C079-T01 · Result inventory:** Enumerate the required “Side-channel assumptions” qualification cases and intended targets before aggregating results; keep the planned denominator visible.
- [ ] **UC-M09.07-C079-T02 · Verdict schema:** Define separate executed-pass, executed-fail, skipped, unavailable and untested outcomes for “Side-channel assumptions”; document how incomplete cases block relevant claims.
- [ ] **UC-M09.07-C079-T03 · Identity fields:** Attach the actual target, fixture, configuration and revision identifiers to each “Side-channel assumptions” result; do not attribute host-only evidence to a guest or another OS.
- [ ] **UC-M09.07-C079-T04 · Observation capture:** Capture bounded raw “Side-channel assumptions” observations and harness errors; retain enough information to verify the reported oracle comparison.
- [ ] **UC-M09.07-C079-T05 · Aggregation rules:** Implement the “Side-channel assumptions” count/reduction rule so failures and missing measurements cannot disappear; preserve “Unsupported side-channel threats remain explicit exclusions”.
- [ ] **UC-M09.07-C079-T06 · Failure visibility:** Feed a failing “Side-channel assumptions” control through the report path; assert the exact failed case and underlying observation remain visible.
- [ ] **UC-M09.07-C079-T07 · Missing-result visibility:** Withhold a required “Side-channel assumptions” measurement or target; verify the report uses unavailable/untested rather than a fabricated zero or passing value.
- [ ] **UC-M09.07-C079-T08 · Bounds and redaction:** Check “Side-channel assumptions” report size and retention against “Threat scenarios and evidence-review scope”; remove secrets while retaining fixture and subject references.
- [ ] **UC-M09.07-C079-T09 · Report reconciliation:** Reconcile the “Side-channel assumptions” summary with every underlying case record; account for the full planned denominator and all omitted scope.
- [ ] **UC-M09.07-C079-T10 · Qualification handoff:** Publish the “Side-channel assumptions” report with measured observations, coverage limits and blockers; state which actual targets remain unqualified.

### UC-M09.07-C080 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for side-channel assumptions; label unexecuted checks as untested.

- [ ] **UC-M09.07-C080-T01 · Evidence inventory:** List the “Side-channel assumptions” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M09.07-C080-T02 · Artifact references:** Record the exact “Side-channel assumptions” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M09.07-C080-T03 · Fixture references:** Attach the “Side-channel assumptions” fixture IDs, input identities and oracle definition; preserve the source counterexample “A report claims absolute isolation without examining shared-resource assumptions” as a distinct evidence case.
- [ ] **UC-M09.07-C080-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Side-channel assumptions”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M09.07-C080-T05 · Environment record:** Record the actual “Side-channel assumptions” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M09.07-C080-T06 · Expected versus observed:** Pair every “Side-channel assumptions” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M09.07-C080-T07 · Failure and limit records:** Attach “Side-channel assumptions” change/failure and bounds evidence where required; include uncovered “Threat scenarios and evidence-review scope” and unresolved violations of “Unsupported side-channel threats remain explicit exclusions”.
- [ ] **UC-M09.07-C080-T08 · Evidence hygiene:** Check the “Side-channel assumptions” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M09.07-C080-T09 · Reproduction review:** Have the “Side-channel assumptions” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M09.07-C080-T10 · Acceptance linkage:** Link the “Side-channel assumptions” evidence to its parent and UC-M09.07 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 09. Independent assessment evidence

**Source delivery:** Retain independently reviewable test procedures, observations and configuration identities.

**Source invariant:** The platform's own success declaration is not sufficient independent evidence.

**Source negative case:** Only the ship-generated isolation label is submitted for review.

**Source bounded quantities:** Evidence bytes and reviewer coverage.

### UC-M09.07-C081 · Contract

**Original checklist item:** Define the qualification objective for independent assessment evidence, including the actual target implementation, prerequisites, observable oracle and explicit exclusions.

- [ ] **UC-M09.07-C081-T01 · Scope statement:** Write the qualification question for “Independent assessment evidence”; identify the actual target, claimed capability and observations that can answer that question.
- [ ] **UC-M09.07-C081-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Independent assessment evidence”; record each producer, representation and missing-value meaning.
- [ ] **UC-M09.07-C081-T03 · Output inventory:** List the outputs of “Independent assessment evidence” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M09.07-C081-T04 · Field dictionary:** Create a field-and-term dictionary for “Independent assessment evidence”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M09.07-C081-T05 · Prerequisite contract:** Map “Independent assessment evidence” to the source component prerequisites (UC-M03.03, UC-M03.04, UC-M03.05, UC-M09.06); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M09.07-C081-T06 · Authority map:** Identify who may produce, change and consume “Independent assessment evidence”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M09.07-C081-T07 · Invariant clause:** Add a normative clause for “Independent assessment evidence” that preserves “The platform's own success declaration is not sufficient independent evidence”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M09.07-C081-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Independent assessment evidence”; include the source counterexample “Only the ship-generated isolation label is submitted for review” and the intended safe disposition.
- [ ] **UC-M09.07-C081-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Evidence bytes and reviewer coverage” in the “Independent assessment evidence” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M09.07-C081-T10 · Contract review:** Review the “Independent assessment evidence” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M09.07-C082 · Delivery

**Original checklist item:** Retain independently reviewable test procedures, observations and configuration identities.

- [ ] **UC-M09.07-C082-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Independent assessment evidence”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M09.07-C082-T02 · Change plan:** Break the source delivery for “Independent assessment evidence” into concrete edit targets and reviewable outputs; keep the UC-M09.07 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M09.07-C082-T03 · Core artifact:** Implement the smallest selected-profile change for “Independent assessment evidence” that realizes this source instruction: Retain independently reviewable test procedures, observations and configuration identities.
- [ ] **UC-M09.07-C082-T04 · Concrete realization:** Trace “Independent assessment evidence” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M09.07-C082-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Independent assessment evidence” needed to preserve “The platform's own success declaration is not sufficient independent evidence”; record an enforcement gap where only a model exists.
- [ ] **UC-M09.07-C082-T06 · Dependency connection:** Connect the “Independent assessment evidence” qualification artifact to guest-controlled interfaces, effective host policies and declared tenant threat assumptions; record the target identity and what the harness actually exercises.
- [ ] **UC-M09.07-C082-T07 · Resource behavior:** Account for “Evidence bytes and reviewer coverage” in “Independent assessment evidence”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M09.07-C082-T08 · Delivery check:** Run a known-valid control and a deliberately failing control for “Independent assessment evidence”; confirm the harness distinguishes their observed outcomes.
- [ ] **UC-M09.07-C082-T09 · Patch review:** Review the “Independent assessment evidence” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M09.07-C082-T10 · Delivery handoff:** Publish the “Independent assessment evidence” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M09.07-C083 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: The platform's own success declaration is not sufficient independent evidence. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M09.07-C083-T01 · Named property:** Create a stable property/check name under this parent for “Independent assessment evidence”; copy its required invariant exactly: “The platform's own success declaration is not sufficient independent evidence”.
- [ ] **UC-M09.07-C083-T02 · Observable terms:** Define each term in the “Independent assessment evidence” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M09.07-C083-T03 · Precondition set:** List the preconditions under which “The platform's own success declaration is not sufficient independent evidence” must hold for “Independent assessment evidence”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M09.07-C083-T04 · Transition coverage:** Map the “Independent assessment evidence” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M09.07-C083-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Independent assessment evidence”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M09.07-C083-T06 · Satisfying fixture:** Create a concrete “Independent assessment evidence” case that satisfies “The platform's own success declaration is not sufficient independent evidence”; record its expected observation before running the assertion or review.
- [ ] **UC-M09.07-C083-T07 · Violating fixture:** Create the source counterexample “Only the ship-generated isolation label is submitted for review” for “Independent assessment evidence”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M09.07-C083-T08 · Enforcement evidence:** Exercise the “Independent assessment evidence” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M09.07-C083-T09 · Regression linkage:** Link the “Independent assessment evidence” property to changes in guest-controlled interfaces, effective host policies and declared tenant threat assumptions; record which dependency or contract changes require rerunning it.
- [ ] **UC-M09.07-C083-T10 · Property disposition:** Compare the satisfying and violating “Independent assessment evidence” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M09.07-C084 · Integration

**Original checklist item:** Integrate independent assessment evidence with guest-controlled interfaces, effective host policies and declared tenant threat assumptions; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M09.07-C084-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Independent assessment evidence” across guest-controlled interfaces, effective host policies and declared tenant threat assumptions; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M09.07-C084-T02 · Field mapping:** Map every “Independent assessment evidence” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M09.07-C084-T03 · Prerequisite identities:** Record the actual prerequisites for “Independent assessment evidence” (source dependency list: UC-M03.03, UC-M03.04, UC-M03.05, UC-M09.06); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M09.07-C084-T04 · Ownership agreement:** Specify who owns “Independent assessment evidence” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M09.07-C084-T05 · Handoff implementation:** Connect “Independent assessment evidence” through the mapped seam using the real adapter or explicit specification reference; preserve “The platform's own success declaration is not sufficient independent evidence” across the handoff.
- [ ] **UC-M09.07-C084-T06 · Absent-input case:** Omit one required “Independent assessment evidence” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M09.07-C084-T07 · Stale-input case:** Supply an outdated “Independent assessment evidence” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M09.07-C084-T08 · Incompatible-input case:** Supply an incompatible “Independent assessment evidence” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M09.07-C084-T09 · Valid integration trace:** Run a valid “Independent assessment evidence” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M09.07-C084-T10 · Seam review:** Reconcile the “Independent assessment evidence” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M09.07-C085 · Valid-case test

**Original checklist item:** Run a known-valid control for independent assessment evidence; verify that the harness reaches its intended target and compare observed measurements or verdicts with predeclared expectations.

- [ ] **UC-M09.07-C085-T01 · Valid fixture choice:** Choose a known-valid control for “Independent assessment evidence”; document why it should pass and how it proves the harness reaches the intended target.
- [ ] **UC-M09.07-C085-T02 · Expected-result oracle:** Specify the “Independent assessment evidence” expected result independently of the implementation output; include the property “The platform's own success declaration is not sufficient independent evidence” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M09.07-C085-T03 · Fixture material:** Create the concrete “Independent assessment evidence” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M09.07-C085-T04 · Target preparation:** Prepare the “Independent assessment evidence” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M09.07-C085-T05 · Initial-state record:** Record the initial “Independent assessment evidence” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M09.07-C085-T06 · Valid-path execution:** Run the “Independent assessment evidence” known-valid control on the identified target; retain enough observations to prove the correct target was exercised.
- [ ] **UC-M09.07-C085-T07 · Outcome comparison:** Compare every declared “Independent assessment evidence” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M09.07-C085-T08 · State and bounds check:** Inspect the “Independent assessment evidence” ownership/state effects and actual use of “Evidence bytes and reviewer coverage”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M09.07-C085-T09 · Repeatability check:** Repeat the same “Independent assessment evidence” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M09.07-C085-T10 · Positive evidence:** Attach the “Independent assessment evidence” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M09.07-C086 · Negative test

**Original checklist item:** Negative case: Only the ship-generated isolation label is submitted for review. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M09.07-C086-T01 · Adverse-case definition:** Create a test record for the exact “Independent assessment evidence” source counterexample: “Only the ship-generated isolation label is submitted for review”; state which precondition or invariant it challenges.
- [ ] **UC-M09.07-C086-T02 · Safe fixture boundary:** Define the contained test boundary for “Independent assessment evidence”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M09.07-C086-T03 · Valid control:** Construct a valid “Independent assessment evidence” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M09.07-C086-T04 · Minimal adverse input:** Derive the “Independent assessment evidence” adverse fixture from the control with the smallest documented change needed to reproduce “Only the ship-generated isolation label is submitted for review”; retain that change as reproducible data.
- [ ] **UC-M09.07-C086-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Independent assessment evidence”; require “The platform's own success declaration is not sufficient independent evidence” and forbid a false-success verdict.
- [ ] **UC-M09.07-C086-T06 · Adverse execution:** Exercise the “Independent assessment evidence” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M09.07-C086-T07 · Effect inspection:** Inspect “Independent assessment evidence” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M09.07-C086-T08 · Refusal versus failure:** Confirm the “Independent assessment evidence” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M09.07-C086-T09 · Reset and retention:** Restore only the disposable “Independent assessment evidence” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M09.07-C086-T10 · Negative regression:** Register the “Independent assessment evidence” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M09.07-C087 · Change / failure test

**Original checklist item:** Exercise independent assessment evidence when the backend, host configuration or shared-resource assumption changes after assessment; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M09.07-C087-T01 · Scenario record:** Write the “Independent assessment evidence” change/failure scenario exactly as supplied: the backend, host configuration or shared-resource assumption changes after assessment; identify the property that must remain true: “The platform's own success declaration is not sufficient independent evidence”.
- [ ] **UC-M09.07-C087-T02 · Baseline capture:** Create a known-valid “Independent assessment evidence” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M09.07-C087-T03 · Injection map:** Locate the “Independent assessment evidence” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M09.07-C087-T04 · Disposition oracle:** Define the legal intermediate and final “Independent assessment evidence” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M09.07-C087-T05 · Controlled trigger:** Introduce the controlled “Independent assessment evidence” scenario in the disposable fixture: the backend, host configuration or shared-resource assumption changes after assessment; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M09.07-C087-T06 · Intermediate inspection:** Inspect the “Independent assessment evidence” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M09.07-C087-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Independent assessment evidence”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M09.07-C087-T08 · Stale-evidence cleanup:** Invalidate superseded “Independent assessment evidence” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M09.07-C087-T09 · Repeat and compare:** Repeat the selected “Independent assessment evidence” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M09.07-C087-T10 · Failure evidence:** Publish the “Independent assessment evidence” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M09.07-C088 · Bounds

**Original checklist item:** Set a documented campaign budget for evidence bytes and reviewer coverage; record actual consumption, incomplete coverage and the disposition when the budget is exhausted.

- [ ] **UC-M09.07-C088-T01 · Quantity inventory:** Create a measurement inventory for “Independent assessment evidence”: “Evidence bytes and reviewer coverage”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M09.07-C088-T02 · Measurement method:** Choose how to observe each “Independent assessment evidence” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M09.07-C088-T03 · Budget decision:** Select justified campaign and target-resource budgets for “Independent assessment evidence”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M09.07-C088-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Independent assessment evidence” cases for “Evidence bytes and reviewer coverage”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M09.07-C088-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Independent assessment evidence” limit; preserve “The platform's own success declaration is not sufficient independent evidence”.
- [ ] **UC-M09.07-C088-T06 · Normal measurement:** Run or review the normal “Independent assessment evidence” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M09.07-C088-T07 · At-limit measurement:** Exercise the “Independent assessment evidence” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M09.07-C088-T08 · Over-limit measurement:** Exercise the “Independent assessment evidence” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M09.07-C088-T09 · Uncovered-scope report:** List the “Independent assessment evidence” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M09.07-C088-T10 · Limit evidence:** Publish the selected “Independent assessment evidence” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M09.07-C089 · Diagnostics / review

**Original checklist item:** Report independent assessment evidence results with executed, failed, skipped and unavailable cases separated; preserve the underlying observations and do not manufacture missing measurements.

- [ ] **UC-M09.07-C089-T01 · Result inventory:** Enumerate the required “Independent assessment evidence” qualification cases and intended targets before aggregating results; keep the planned denominator visible.
- [ ] **UC-M09.07-C089-T02 · Verdict schema:** Define separate executed-pass, executed-fail, skipped, unavailable and untested outcomes for “Independent assessment evidence”; document how incomplete cases block relevant claims.
- [ ] **UC-M09.07-C089-T03 · Identity fields:** Attach the actual target, fixture, configuration and revision identifiers to each “Independent assessment evidence” result; do not attribute host-only evidence to a guest or another OS.
- [ ] **UC-M09.07-C089-T04 · Observation capture:** Capture bounded raw “Independent assessment evidence” observations and harness errors; retain enough information to verify the reported oracle comparison.
- [ ] **UC-M09.07-C089-T05 · Aggregation rules:** Implement the “Independent assessment evidence” count/reduction rule so failures and missing measurements cannot disappear; preserve “The platform's own success declaration is not sufficient independent evidence”.
- [ ] **UC-M09.07-C089-T06 · Failure visibility:** Feed a failing “Independent assessment evidence” control through the report path; assert the exact failed case and underlying observation remain visible.
- [ ] **UC-M09.07-C089-T07 · Missing-result visibility:** Withhold a required “Independent assessment evidence” measurement or target; verify the report uses unavailable/untested rather than a fabricated zero or passing value.
- [ ] **UC-M09.07-C089-T08 · Bounds and redaction:** Check “Independent assessment evidence” report size and retention against “Evidence bytes and reviewer coverage”; remove secrets while retaining fixture and subject references.
- [ ] **UC-M09.07-C089-T09 · Report reconciliation:** Reconcile the “Independent assessment evidence” summary with every underlying case record; account for the full planned denominator and all omitted scope.
- [ ] **UC-M09.07-C089-T10 · Qualification handoff:** Publish the “Independent assessment evidence” report with measured observations, coverage limits and blockers; state which actual targets remain unqualified.

### UC-M09.07-C090 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for independent assessment evidence; label unexecuted checks as untested.

- [ ] **UC-M09.07-C090-T01 · Evidence inventory:** List the “Independent assessment evidence” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M09.07-C090-T02 · Artifact references:** Record the exact “Independent assessment evidence” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M09.07-C090-T03 · Fixture references:** Attach the “Independent assessment evidence” fixture IDs, input identities and oracle definition; preserve the source counterexample “Only the ship-generated isolation label is submitted for review” as a distinct evidence case.
- [ ] **UC-M09.07-C090-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Independent assessment evidence”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M09.07-C090-T05 · Environment record:** Record the actual “Independent assessment evidence” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M09.07-C090-T06 · Expected versus observed:** Pair every “Independent assessment evidence” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M09.07-C090-T07 · Failure and limit records:** Attach “Independent assessment evidence” change/failure and bounds evidence where required; include uncovered “Evidence bytes and reviewer coverage” and unresolved violations of “The platform's own success declaration is not sufficient independent evidence”.
- [ ] **UC-M09.07-C090-T08 · Evidence hygiene:** Check the “Independent assessment evidence” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M09.07-C090-T09 · Reproduction review:** Have the “Independent assessment evidence” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M09.07-C090-T10 · Acceptance linkage:** Link the “Independent assessment evidence” evidence to its parent and UC-M09.07 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 10. Residual-risk gate

**Source delivery:** Record unresolved findings and prevent promotion beyond supported isolation scope.

**Source invariant:** Unresolved required boundary findings cannot be hidden by general PASS status.

**Source negative case:** A known guest-access issue is omitted from the release summary.

**Source bounded quantities:** Open findings and accepted-profile count.

### UC-M09.07-C091 · Contract

**Original checklist item:** Define the qualification objective for residual-risk gate, including the actual target implementation, prerequisites, observable oracle and explicit exclusions.

- [ ] **UC-M09.07-C091-T01 · Scope statement:** Write the qualification question for “Residual-risk gate”; identify the actual target, claimed capability and observations that can answer that question.
- [ ] **UC-M09.07-C091-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Residual-risk gate”; record each producer, representation and missing-value meaning.
- [ ] **UC-M09.07-C091-T03 · Output inventory:** List the outputs of “Residual-risk gate” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M09.07-C091-T04 · Field dictionary:** Create a field-and-term dictionary for “Residual-risk gate”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M09.07-C091-T05 · Prerequisite contract:** Map “Residual-risk gate” to the source component prerequisites (UC-M03.03, UC-M03.04, UC-M03.05, UC-M09.06); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M09.07-C091-T06 · Authority map:** Identify who may produce, change and consume “Residual-risk gate”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M09.07-C091-T07 · Invariant clause:** Add a normative clause for “Residual-risk gate” that preserves “Unresolved required boundary findings cannot be hidden by general PASS status”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M09.07-C091-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Residual-risk gate”; include the source counterexample “A known guest-access issue is omitted from the release summary” and the intended safe disposition.
- [ ] **UC-M09.07-C091-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Open findings and accepted-profile count” in the “Residual-risk gate” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M09.07-C091-T10 · Contract review:** Review the “Residual-risk gate” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M09.07-C092 · Delivery

**Original checklist item:** Record unresolved findings and prevent promotion beyond supported isolation scope.

- [ ] **UC-M09.07-C092-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Residual-risk gate”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M09.07-C092-T02 · Change plan:** Break the source delivery for “Residual-risk gate” into concrete edit targets and reviewable outputs; keep the UC-M09.07 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M09.07-C092-T03 · Core artifact:** Create the “Residual-risk gate” model, schema or inventory that realizes this source instruction: Record unresolved findings and prevent promotion beyond supported isolation scope.
- [ ] **UC-M09.07-C092-T04 · Concrete realization:** Populate “Residual-risk gate” with one concrete worked case; map every required entity or field to its source and flag any unmapped entry.
- [ ] **UC-M09.07-C092-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Residual-risk gate” needed to preserve “Unresolved required boundary findings cannot be hidden by general PASS status”; record an enforcement gap where only a model exists.
- [ ] **UC-M09.07-C092-T06 · Dependency connection:** Connect the “Residual-risk gate” qualification artifact to guest-controlled interfaces, effective host policies and declared tenant threat assumptions; record the target identity and what the harness actually exercises.
- [ ] **UC-M09.07-C092-T07 · Resource behavior:** Account for “Open findings and accepted-profile count” in “Residual-risk gate”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M09.07-C092-T08 · Delivery check:** Run a known-valid control and a deliberately failing control for “Residual-risk gate”; confirm the harness distinguishes their observed outcomes.
- [ ] **UC-M09.07-C092-T09 · Patch review:** Review the “Residual-risk gate” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M09.07-C092-T10 · Delivery handoff:** Publish the “Residual-risk gate” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M09.07-C093 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Unresolved required boundary findings cannot be hidden by general PASS status. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M09.07-C093-T01 · Named property:** Create a stable property/check name under this parent for “Residual-risk gate”; copy its required invariant exactly: “Unresolved required boundary findings cannot be hidden by general PASS status”.
- [ ] **UC-M09.07-C093-T02 · Observable terms:** Define each term in the “Residual-risk gate” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M09.07-C093-T03 · Precondition set:** List the preconditions under which “Unresolved required boundary findings cannot be hidden by general PASS status” must hold for “Residual-risk gate”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M09.07-C093-T04 · Transition coverage:** Map the “Residual-risk gate” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M09.07-C093-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Residual-risk gate”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M09.07-C093-T06 · Satisfying fixture:** Create a concrete “Residual-risk gate” case that satisfies “Unresolved required boundary findings cannot be hidden by general PASS status”; record its expected observation before running the assertion or review.
- [ ] **UC-M09.07-C093-T07 · Violating fixture:** Create the source counterexample “A known guest-access issue is omitted from the release summary” for “Residual-risk gate”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M09.07-C093-T08 · Enforcement evidence:** Exercise the “Residual-risk gate” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M09.07-C093-T09 · Regression linkage:** Link the “Residual-risk gate” property to changes in guest-controlled interfaces, effective host policies and declared tenant threat assumptions; record which dependency or contract changes require rerunning it.
- [ ] **UC-M09.07-C093-T10 · Property disposition:** Compare the satisfying and violating “Residual-risk gate” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M09.07-C094 · Integration

**Original checklist item:** Integrate residual-risk gate with guest-controlled interfaces, effective host policies and declared tenant threat assumptions; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M09.07-C094-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Residual-risk gate” across guest-controlled interfaces, effective host policies and declared tenant threat assumptions; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M09.07-C094-T02 · Field mapping:** Map every “Residual-risk gate” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M09.07-C094-T03 · Prerequisite identities:** Record the actual prerequisites for “Residual-risk gate” (source dependency list: UC-M03.03, UC-M03.04, UC-M03.05, UC-M09.06); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M09.07-C094-T04 · Ownership agreement:** Specify who owns “Residual-risk gate” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M09.07-C094-T05 · Handoff implementation:** Connect “Residual-risk gate” through the mapped seam using the real adapter or explicit specification reference; preserve “Unresolved required boundary findings cannot be hidden by general PASS status” across the handoff.
- [ ] **UC-M09.07-C094-T06 · Absent-input case:** Omit one required “Residual-risk gate” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M09.07-C094-T07 · Stale-input case:** Supply an outdated “Residual-risk gate” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M09.07-C094-T08 · Incompatible-input case:** Supply an incompatible “Residual-risk gate” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M09.07-C094-T09 · Valid integration trace:** Run a valid “Residual-risk gate” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M09.07-C094-T10 · Seam review:** Reconcile the “Residual-risk gate” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M09.07-C095 · Valid-case test

**Original checklist item:** Run a known-valid control for residual-risk gate; verify that the harness reaches its intended target and compare observed measurements or verdicts with predeclared expectations.

- [ ] **UC-M09.07-C095-T01 · Valid fixture choice:** Choose a known-valid control for “Residual-risk gate”; document why it should pass and how it proves the harness reaches the intended target.
- [ ] **UC-M09.07-C095-T02 · Expected-result oracle:** Specify the “Residual-risk gate” expected result independently of the implementation output; include the property “Unresolved required boundary findings cannot be hidden by general PASS status” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M09.07-C095-T03 · Fixture material:** Create the concrete “Residual-risk gate” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M09.07-C095-T04 · Target preparation:** Prepare the “Residual-risk gate” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M09.07-C095-T05 · Initial-state record:** Record the initial “Residual-risk gate” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M09.07-C095-T06 · Valid-path execution:** Run the “Residual-risk gate” known-valid control on the identified target; retain enough observations to prove the correct target was exercised.
- [ ] **UC-M09.07-C095-T07 · Outcome comparison:** Compare every declared “Residual-risk gate” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M09.07-C095-T08 · State and bounds check:** Inspect the “Residual-risk gate” ownership/state effects and actual use of “Open findings and accepted-profile count”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M09.07-C095-T09 · Repeatability check:** Repeat the same “Residual-risk gate” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M09.07-C095-T10 · Positive evidence:** Attach the “Residual-risk gate” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M09.07-C096 · Negative test

**Original checklist item:** Negative case: A known guest-access issue is omitted from the release summary. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M09.07-C096-T01 · Adverse-case definition:** Create a test record for the exact “Residual-risk gate” source counterexample: “A known guest-access issue is omitted from the release summary”; state which precondition or invariant it challenges.
- [ ] **UC-M09.07-C096-T02 · Safe fixture boundary:** Define the contained test boundary for “Residual-risk gate”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M09.07-C096-T03 · Valid control:** Construct a valid “Residual-risk gate” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M09.07-C096-T04 · Minimal adverse input:** Derive the “Residual-risk gate” adverse fixture from the control with the smallest documented change needed to reproduce “A known guest-access issue is omitted from the release summary”; retain that change as reproducible data.
- [ ] **UC-M09.07-C096-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Residual-risk gate”; require “Unresolved required boundary findings cannot be hidden by general PASS status” and forbid a false-success verdict.
- [ ] **UC-M09.07-C096-T06 · Adverse execution:** Exercise the “Residual-risk gate” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M09.07-C096-T07 · Effect inspection:** Inspect “Residual-risk gate” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M09.07-C096-T08 · Refusal versus failure:** Confirm the “Residual-risk gate” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M09.07-C096-T09 · Reset and retention:** Restore only the disposable “Residual-risk gate” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M09.07-C096-T10 · Negative regression:** Register the “Residual-risk gate” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M09.07-C097 · Change / failure test

**Original checklist item:** Exercise residual-risk gate when the backend, host configuration or shared-resource assumption changes after assessment; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M09.07-C097-T01 · Scenario record:** Write the “Residual-risk gate” change/failure scenario exactly as supplied: the backend, host configuration or shared-resource assumption changes after assessment; identify the property that must remain true: “Unresolved required boundary findings cannot be hidden by general PASS status”.
- [ ] **UC-M09.07-C097-T02 · Baseline capture:** Create a known-valid “Residual-risk gate” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M09.07-C097-T03 · Injection map:** Locate the “Residual-risk gate” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M09.07-C097-T04 · Disposition oracle:** Define the legal intermediate and final “Residual-risk gate” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M09.07-C097-T05 · Controlled trigger:** Introduce the controlled “Residual-risk gate” scenario in the disposable fixture: the backend, host configuration or shared-resource assumption changes after assessment; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M09.07-C097-T06 · Intermediate inspection:** Inspect the “Residual-risk gate” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M09.07-C097-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Residual-risk gate”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M09.07-C097-T08 · Stale-evidence cleanup:** Invalidate superseded “Residual-risk gate” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M09.07-C097-T09 · Repeat and compare:** Repeat the selected “Residual-risk gate” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M09.07-C097-T10 · Failure evidence:** Publish the “Residual-risk gate” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M09.07-C098 · Bounds

**Original checklist item:** Set a documented campaign budget for open findings and accepted-profile count; record actual consumption, incomplete coverage and the disposition when the budget is exhausted.

- [ ] **UC-M09.07-C098-T01 · Quantity inventory:** Create a measurement inventory for “Residual-risk gate”: “Open findings and accepted-profile count”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M09.07-C098-T02 · Measurement method:** Choose how to observe each “Residual-risk gate” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M09.07-C098-T03 · Budget decision:** Select justified campaign and target-resource budgets for “Residual-risk gate”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M09.07-C098-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Residual-risk gate” cases for “Open findings and accepted-profile count”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M09.07-C098-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Residual-risk gate” limit; preserve “Unresolved required boundary findings cannot be hidden by general PASS status”.
- [ ] **UC-M09.07-C098-T06 · Normal measurement:** Run or review the normal “Residual-risk gate” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M09.07-C098-T07 · At-limit measurement:** Exercise the “Residual-risk gate” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M09.07-C098-T08 · Over-limit measurement:** Exercise the “Residual-risk gate” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M09.07-C098-T09 · Uncovered-scope report:** List the “Residual-risk gate” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M09.07-C098-T10 · Limit evidence:** Publish the selected “Residual-risk gate” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M09.07-C099 · Diagnostics / review

**Original checklist item:** Report residual-risk gate results with executed, failed, skipped and unavailable cases separated; preserve the underlying observations and do not manufacture missing measurements.

- [ ] **UC-M09.07-C099-T01 · Result inventory:** Enumerate the required “Residual-risk gate” qualification cases and intended targets before aggregating results; keep the planned denominator visible.
- [ ] **UC-M09.07-C099-T02 · Verdict schema:** Define separate executed-pass, executed-fail, skipped, unavailable and untested outcomes for “Residual-risk gate”; document how incomplete cases block relevant claims.
- [ ] **UC-M09.07-C099-T03 · Identity fields:** Attach the actual target, fixture, configuration and revision identifiers to each “Residual-risk gate” result; do not attribute host-only evidence to a guest or another OS.
- [ ] **UC-M09.07-C099-T04 · Observation capture:** Capture bounded raw “Residual-risk gate” observations and harness errors; retain enough information to verify the reported oracle comparison.
- [ ] **UC-M09.07-C099-T05 · Aggregation rules:** Implement the “Residual-risk gate” count/reduction rule so failures and missing measurements cannot disappear; preserve “Unresolved required boundary findings cannot be hidden by general PASS status”.
- [ ] **UC-M09.07-C099-T06 · Failure visibility:** Feed a failing “Residual-risk gate” control through the report path; assert the exact failed case and underlying observation remain visible.
- [ ] **UC-M09.07-C099-T07 · Missing-result visibility:** Withhold a required “Residual-risk gate” measurement or target; verify the report uses unavailable/untested rather than a fabricated zero or passing value.
- [ ] **UC-M09.07-C099-T08 · Bounds and redaction:** Check “Residual-risk gate” report size and retention against “Open findings and accepted-profile count”; remove secrets while retaining fixture and subject references.
- [ ] **UC-M09.07-C099-T09 · Report reconciliation:** Reconcile the “Residual-risk gate” summary with every underlying case record; account for the full planned denominator and all omitted scope.
- [ ] **UC-M09.07-C099-T10 · Qualification handoff:** Publish the “Residual-risk gate” report with measured observations, coverage limits and blockers; state which actual targets remain unqualified.

### UC-M09.07-C100 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for residual-risk gate; label unexecuted checks as untested.

- [ ] **UC-M09.07-C100-T01 · Evidence inventory:** List the “Residual-risk gate” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M09.07-C100-T02 · Artifact references:** Record the exact “Residual-risk gate” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M09.07-C100-T03 · Fixture references:** Attach the “Residual-risk gate” fixture IDs, input identities and oracle definition; preserve the source counterexample “A known guest-access issue is omitted from the release summary” as a distinct evidence case.
- [ ] **UC-M09.07-C100-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Residual-risk gate”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M09.07-C100-T05 · Environment record:** Record the actual “Residual-risk gate” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M09.07-C100-T06 · Expected versus observed:** Pair every “Residual-risk gate” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M09.07-C100-T07 · Failure and limit records:** Attach “Residual-risk gate” change/failure and bounds evidence where required; include uncovered “Open findings and accepted-profile count” and unresolved violations of “Unresolved required boundary findings cannot be hidden by general PASS status”.
- [ ] **UC-M09.07-C100-T08 · Evidence hygiene:** Check the “Residual-risk gate” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M09.07-C100-T09 · Reproduction review:** Have the “Residual-risk gate” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M09.07-C100-T10 · Acceptance linkage:** Link the “Residual-risk gate” evidence to its parent and UC-M09.07 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

