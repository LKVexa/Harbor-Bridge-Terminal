# UC-M09.03 — Verified executable-cache reads

**To-Do Pack 2.0.0 · Baseline UC-2.2.0 · 100 parent checks × 10 subtasks = 1,000 to-dos**

[Master index](../../INDEX.md) · [Workstream index](../../w/09.md)

| Field | Preserved source value |
|---|---|
| Workstream | 09. Trust, integrity and adversarial security |
| Milestone | C |
| Priority | P0 |
| Source assessment | PARTIAL |
| Scope | core or selected profile |
| Dependencies | [UC-M04.05](../04/UC-M04.05.md), [UC-M06.05](../06/UC-M06.05.md), [UC-M09.01](../09/UC-M09.01.md) |
| Source checklist pack | 1.0.0 |
| Original reference labels | [S4], [S7], [S8]. |

## Original requirement

Verify cached engine source, libraries and executables against the approved dependency graph immediately before use; protect mutable roots.

**Original acceptance criterion:** Changing a cached adapter or native executable blocks execution even when the original hold ZIP still matches its pin.

**Source trace:** Original checklist `UC100/c/09/UC-M09.03.md` inside [s/checklists.zip](../../s/checklists.zip); exact parent records in [data/parents.jsonl](../../data/parents.jsonl). Original roadmap lines 831–841 are preserved in [s/roadmap.md](../../s/roadmap.md).

## How to use these lists

Every parent statement below is preserved verbatim. Its ten child tasks are proposed decomposition, not implemented capabilities or executed tests. Child IDs append `-T01` through `-T10` to the original parent ID. All begin unchecked / `TODO`. Design/review evidence does not establish runtime enforcement; observe the actual selected target where the parent requires it.

The source dependency graph and selected release profile determine applicability. The numbered child sequence is a local working order, not an added hard dependency graph. An unselected optional feature needs a recorded not-applicable rationale; missing prerequisites for selected work remain blockers. Numerical budgets, backends and trust mechanisms remain decisions unless fixed by the source. Test hostile cases only with synthetic inputs in authorized disposable environments.

## 01. Executable cache inventory

**Source delivery:** Enumerate cached adapters, engine sources, libraries and native executables that can affect execution.

**Source invariant:** Every executable cache input belongs to an approved dependency graph.

**Source negative case:** A cached Python adapter is absent from cache verification.

**Source bounded quantities:** Cache entries and executable surface count.

### UC-M09.03-C001 · Contract

**Original checklist item:** Specify executable cache inventory inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M09.03-C001-T01 · Scope statement:** Draft the operation boundary for “Executable cache inventory” within Verified executable-cache reads; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M09.03-C001-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Executable cache inventory”; record each producer, representation and missing-value meaning.
- [ ] **UC-M09.03-C001-T03 · Output inventory:** List the outputs of “Executable cache inventory” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M09.03-C001-T04 · Field dictionary:** Create a field-and-term dictionary for “Executable cache inventory”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M09.03-C001-T05 · Prerequisite contract:** Map “Executable cache inventory” to the source component prerequisites (UC-M04.05, UC-M06.05, UC-M09.01); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M09.03-C001-T06 · Authority map:** Identify who may produce, change and consume “Executable cache inventory”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M09.03-C001-T07 · Invariant clause:** Add a normative clause for “Executable cache inventory” that preserves “Every executable cache input belongs to an approved dependency graph”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M09.03-C001-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Executable cache inventory”; include the source counterexample “A cached Python adapter is absent from cache verification” and the intended safe disposition.
- [ ] **UC-M09.03-C001-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Cache entries and executable surface count” in the “Executable cache inventory” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M09.03-C001-T10 · Contract review:** Review the “Executable cache inventory” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M09.03-C002 · Delivery

**Original checklist item:** Enumerate cached adapters, engine sources, libraries and native executables that can affect execution.

- [ ] **UC-M09.03-C002-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Executable cache inventory”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M09.03-C002-T02 · Change plan:** Break the source delivery for “Executable cache inventory” into concrete edit targets and reviewable outputs; keep the UC-M09.03 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M09.03-C002-T03 · Core artifact:** Create the “Executable cache inventory” model, schema or inventory that realizes this source instruction: Enumerate cached adapters, engine sources, libraries and native executables that can affect execution.
- [ ] **UC-M09.03-C002-T04 · Concrete realization:** Populate “Executable cache inventory” with one concrete worked case; map every required entity or field to its source and flag any unmapped entry.
- [ ] **UC-M09.03-C002-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Executable cache inventory” needed to preserve “Every executable cache input belongs to an approved dependency graph”; record an enforcement gap where only a model exists.
- [ ] **UC-M09.03-C002-T06 · Dependency connection:** Connect the “Executable cache inventory” implementation to approved dependency identities, mutable cache roots and executable handoff; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M09.03-C002-T07 · Resource behavior:** Account for “Cache entries and executable surface count” in “Executable cache inventory”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M09.03-C002-T08 · Delivery check:** Run the smallest real “Executable cache inventory” path and its adverse fixture “A cached Python adapter is absent from cache verification”; retain actual output, state effects and final disposition.
- [ ] **UC-M09.03-C002-T09 · Patch review:** Review the “Executable cache inventory” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M09.03-C002-T10 · Delivery handoff:** Publish the “Executable cache inventory” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M09.03-C003 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Every executable cache input belongs to an approved dependency graph. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M09.03-C003-T01 · Named property:** Create a stable property/check name under this parent for “Executable cache inventory”; copy its required invariant exactly: “Every executable cache input belongs to an approved dependency graph”.
- [ ] **UC-M09.03-C003-T02 · Observable terms:** Define each term in the “Executable cache inventory” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M09.03-C003-T03 · Precondition set:** List the preconditions under which “Every executable cache input belongs to an approved dependency graph” must hold for “Executable cache inventory”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M09.03-C003-T04 · Transition coverage:** Map the “Executable cache inventory” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M09.03-C003-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Executable cache inventory”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M09.03-C003-T06 · Satisfying fixture:** Create a concrete “Executable cache inventory” case that satisfies “Every executable cache input belongs to an approved dependency graph”; record its expected observation before running the assertion or review.
- [ ] **UC-M09.03-C003-T07 · Violating fixture:** Create the source counterexample “A cached Python adapter is absent from cache verification” for “Executable cache inventory”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M09.03-C003-T08 · Enforcement evidence:** Exercise the “Executable cache inventory” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M09.03-C003-T09 · Regression linkage:** Link the “Executable cache inventory” property to changes in approved dependency identities, mutable cache roots and executable handoff; record which dependency or contract changes require rerunning it.
- [ ] **UC-M09.03-C003-T10 · Property disposition:** Compare the satisfying and violating “Executable cache inventory” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M09.03-C004 · Integration

**Original checklist item:** Integrate executable cache inventory with approved dependency identities, mutable cache roots and executable handoff; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M09.03-C004-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Executable cache inventory” across approved dependency identities, mutable cache roots and executable handoff; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M09.03-C004-T02 · Field mapping:** Map every “Executable cache inventory” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M09.03-C004-T03 · Prerequisite identities:** Record the actual prerequisites for “Executable cache inventory” (source dependency list: UC-M04.05, UC-M06.05, UC-M09.01); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M09.03-C004-T04 · Ownership agreement:** Specify who owns “Executable cache inventory” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M09.03-C004-T05 · Handoff implementation:** Connect “Executable cache inventory” through the mapped seam using the real adapter or explicit specification reference; preserve “Every executable cache input belongs to an approved dependency graph” across the handoff.
- [ ] **UC-M09.03-C004-T06 · Absent-input case:** Omit one required “Executable cache inventory” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M09.03-C004-T07 · Stale-input case:** Supply an outdated “Executable cache inventory” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M09.03-C004-T08 · Incompatible-input case:** Supply an incompatible “Executable cache inventory” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M09.03-C004-T09 · Valid integration trace:** Run a valid “Executable cache inventory” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M09.03-C004-T10 · Seam review:** Reconcile the “Executable cache inventory” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M09.03-C005 · Valid-case test

**Original checklist item:** Run a valid-path fixture for executable cache inventory; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M09.03-C005-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Executable cache inventory” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M09.03-C005-T02 · Expected-result oracle:** Specify the “Executable cache inventory” expected result independently of the implementation output; include the property “Every executable cache input belongs to an approved dependency graph” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M09.03-C005-T03 · Fixture material:** Create the concrete “Executable cache inventory” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M09.03-C005-T04 · Target preparation:** Prepare the “Executable cache inventory” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M09.03-C005-T05 · Initial-state record:** Record the initial “Executable cache inventory” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M09.03-C005-T06 · Valid-path execution:** Execute the “Executable cache inventory” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M09.03-C005-T07 · Outcome comparison:** Compare every declared “Executable cache inventory” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M09.03-C005-T08 · State and bounds check:** Inspect the “Executable cache inventory” ownership/state effects and actual use of “Cache entries and executable surface count”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M09.03-C005-T09 · Repeatability check:** Repeat the same “Executable cache inventory” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M09.03-C005-T10 · Positive evidence:** Attach the “Executable cache inventory” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M09.03-C006 · Negative test

**Original checklist item:** Negative case: A cached Python adapter is absent from cache verification. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M09.03-C006-T01 · Adverse-case definition:** Create a test record for the exact “Executable cache inventory” source counterexample: “A cached Python adapter is absent from cache verification”; state which precondition or invariant it challenges.
- [ ] **UC-M09.03-C006-T02 · Safe fixture boundary:** Define the contained test boundary for “Executable cache inventory”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M09.03-C006-T03 · Valid control:** Construct a valid “Executable cache inventory” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M09.03-C006-T04 · Minimal adverse input:** Derive the “Executable cache inventory” adverse fixture from the control with the smallest documented change needed to reproduce “A cached Python adapter is absent from cache verification”; retain that change as reproducible data.
- [ ] **UC-M09.03-C006-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Executable cache inventory”; require “Every executable cache input belongs to an approved dependency graph” and forbid a false-success verdict.
- [ ] **UC-M09.03-C006-T06 · Adverse execution:** Exercise the “Executable cache inventory” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M09.03-C006-T07 · Effect inspection:** Inspect “Executable cache inventory” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M09.03-C006-T08 · Refusal versus failure:** Confirm the “Executable cache inventory” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M09.03-C006-T09 · Reset and retention:** Restore only the disposable “Executable cache inventory” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M09.03-C006-T10 · Negative regression:** Register the “Executable cache inventory” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M09.03-C007 · Change / failure test

**Original checklist item:** Exercise executable cache inventory when a cached executable changes while its original hold archive remains intact; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M09.03-C007-T01 · Scenario record:** Write the “Executable cache inventory” change/failure scenario exactly as supplied: a cached executable changes while its original hold archive remains intact; identify the property that must remain true: “Every executable cache input belongs to an approved dependency graph”.
- [ ] **UC-M09.03-C007-T02 · Baseline capture:** Create a known-valid “Executable cache inventory” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M09.03-C007-T03 · Injection map:** Locate the “Executable cache inventory” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M09.03-C007-T04 · Disposition oracle:** Define the legal intermediate and final “Executable cache inventory” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M09.03-C007-T05 · Controlled trigger:** Introduce the controlled “Executable cache inventory” scenario in the disposable fixture: a cached executable changes while its original hold archive remains intact; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M09.03-C007-T06 · Intermediate inspection:** Inspect the “Executable cache inventory” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M09.03-C007-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Executable cache inventory”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M09.03-C007-T08 · Stale-evidence cleanup:** Invalidate superseded “Executable cache inventory” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M09.03-C007-T09 · Repeat and compare:** Repeat the selected “Executable cache inventory” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M09.03-C007-T10 · Failure evidence:** Publish the “Executable cache inventory” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M09.03-C008 · Bounds

**Original checklist item:** Choose, document and test limits for cache entries and executable surface count; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M09.03-C008-T01 · Quantity inventory:** Create a measurement inventory for “Executable cache inventory”: “Cache entries and executable surface count”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M09.03-C008-T02 · Measurement method:** Choose how to observe each “Executable cache inventory” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M09.03-C008-T03 · Budget decision:** Select justified resource and input limits for “Executable cache inventory”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M09.03-C008-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Executable cache inventory” cases for “Cache entries and executable surface count”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M09.03-C008-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Executable cache inventory” limit; preserve “Every executable cache input belongs to an approved dependency graph”.
- [ ] **UC-M09.03-C008-T06 · Normal measurement:** Run or review the normal “Executable cache inventory” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M09.03-C008-T07 · At-limit measurement:** Exercise the “Executable cache inventory” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M09.03-C008-T08 · Over-limit measurement:** Exercise the “Executable cache inventory” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M09.03-C008-T09 · Uncovered-scope report:** List the “Executable cache inventory” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M09.03-C008-T10 · Limit evidence:** Publish the selected “Executable cache inventory” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M09.03-C009 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for executable cache inventory with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M09.03-C009-T01 · Event inventory:** List the “Executable cache inventory” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M09.03-C009-T02 · Diagnostic schema:** Define nonsecret fields for “Executable cache inventory” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M09.03-C009-T03 · Failure mapping:** Map each documented “Executable cache inventory” refusal or error to a diagnostic outcome; include “A cached Python adapter is absent from cache verification” and prohibit conversion into a success message.
- [ ] **UC-M09.03-C009-T04 · Emission path:** Add the “Executable cache inventory” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M09.03-C009-T05 · Redaction check:** Test “Executable cache inventory” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M09.03-C009-T06 · Output budget:** Set and exercise bounded “Executable cache inventory” message size, rate and retention compatible with “Cache entries and executable surface count”; define truncation behavior that preserves the final reason.
- [ ] **UC-M09.03-C009-T07 · Success/refusal fixtures:** Capture “Executable cache inventory” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M09.03-C009-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Executable cache inventory” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M09.03-C009-T09 · Operator review:** Read the “Executable cache inventory” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M09.03-C009-T10 · Diagnostic evidence:** Publish redacted “Executable cache inventory” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M09.03-C010 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for executable cache inventory; label unexecuted checks as untested.

- [ ] **UC-M09.03-C010-T01 · Evidence inventory:** List the “Executable cache inventory” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M09.03-C010-T02 · Artifact references:** Record the exact “Executable cache inventory” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M09.03-C010-T03 · Fixture references:** Attach the “Executable cache inventory” fixture IDs, input identities and oracle definition; preserve the source counterexample “A cached Python adapter is absent from cache verification” as a distinct evidence case.
- [ ] **UC-M09.03-C010-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Executable cache inventory”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M09.03-C010-T05 · Environment record:** Record the actual “Executable cache inventory” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M09.03-C010-T06 · Expected versus observed:** Pair every “Executable cache inventory” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M09.03-C010-T07 · Failure and limit records:** Attach “Executable cache inventory” change/failure and bounds evidence where required; include uncovered “Cache entries and executable surface count” and unresolved violations of “Every executable cache input belongs to an approved dependency graph”.
- [ ] **UC-M09.03-C010-T08 · Evidence hygiene:** Check the “Executable cache inventory” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M09.03-C010-T09 · Reproduction review:** Have the “Executable cache inventory” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M09.03-C010-T10 · Acceptance linkage:** Link the “Executable cache inventory” evidence to its parent and UC-M09.03 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 02. Approved identity lookup

**Source delivery:** Resolve expected cache digests from approved graph and policy state.

**Source invariant:** The cache cannot nominate its own expected digest.

**Source negative case:** A modified executable updates its adjacent local checksum file.

**Source bounded quantities:** Graph lookups and verification metadata bytes.

### UC-M09.03-C011 · Contract

**Original checklist item:** Specify approved identity lookup inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M09.03-C011-T01 · Scope statement:** Draft the operation boundary for “Approved identity lookup” within Verified executable-cache reads; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M09.03-C011-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Approved identity lookup”; record each producer, representation and missing-value meaning.
- [ ] **UC-M09.03-C011-T03 · Output inventory:** List the outputs of “Approved identity lookup” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M09.03-C011-T04 · Field dictionary:** Create a field-and-term dictionary for “Approved identity lookup”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M09.03-C011-T05 · Prerequisite contract:** Map “Approved identity lookup” to the source component prerequisites (UC-M04.05, UC-M06.05, UC-M09.01); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M09.03-C011-T06 · Authority map:** Identify who may produce, change and consume “Approved identity lookup”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M09.03-C011-T07 · Invariant clause:** Add a normative clause for “Approved identity lookup” that preserves “The cache cannot nominate its own expected digest”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M09.03-C011-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Approved identity lookup”; include the source counterexample “A modified executable updates its adjacent local checksum file” and the intended safe disposition.
- [ ] **UC-M09.03-C011-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Graph lookups and verification metadata bytes” in the “Approved identity lookup” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M09.03-C011-T10 · Contract review:** Review the “Approved identity lookup” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M09.03-C012 · Delivery

**Original checklist item:** Resolve expected cache digests from approved graph and policy state.

- [ ] **UC-M09.03-C012-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Approved identity lookup”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M09.03-C012-T02 · Change plan:** Break the source delivery for “Approved identity lookup” into concrete edit targets and reviewable outputs; keep the UC-M09.03 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M09.03-C012-T03 · Core artifact:** Implement the smallest selected-profile change for “Approved identity lookup” that realizes this source instruction: Resolve expected cache digests from approved graph and policy state.
- [ ] **UC-M09.03-C012-T04 · Concrete realization:** Trace “Approved identity lookup” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M09.03-C012-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Approved identity lookup” needed to preserve “The cache cannot nominate its own expected digest”; record an enforcement gap where only a model exists.
- [ ] **UC-M09.03-C012-T06 · Dependency connection:** Connect the “Approved identity lookup” implementation to approved dependency identities, mutable cache roots and executable handoff; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M09.03-C012-T07 · Resource behavior:** Account for “Graph lookups and verification metadata bytes” in “Approved identity lookup”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M09.03-C012-T08 · Delivery check:** Run the smallest real “Approved identity lookup” path and its adverse fixture “A modified executable updates its adjacent local checksum file”; retain actual output, state effects and final disposition.
- [ ] **UC-M09.03-C012-T09 · Patch review:** Review the “Approved identity lookup” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M09.03-C012-T10 · Delivery handoff:** Publish the “Approved identity lookup” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M09.03-C013 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: The cache cannot nominate its own expected digest. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M09.03-C013-T01 · Named property:** Create a stable property/check name under this parent for “Approved identity lookup”; copy its required invariant exactly: “The cache cannot nominate its own expected digest”.
- [ ] **UC-M09.03-C013-T02 · Observable terms:** Define each term in the “Approved identity lookup” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M09.03-C013-T03 · Precondition set:** List the preconditions under which “The cache cannot nominate its own expected digest” must hold for “Approved identity lookup”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M09.03-C013-T04 · Transition coverage:** Map the “Approved identity lookup” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M09.03-C013-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Approved identity lookup”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M09.03-C013-T06 · Satisfying fixture:** Create a concrete “Approved identity lookup” case that satisfies “The cache cannot nominate its own expected digest”; record its expected observation before running the assertion or review.
- [ ] **UC-M09.03-C013-T07 · Violating fixture:** Create the source counterexample “A modified executable updates its adjacent local checksum file” for “Approved identity lookup”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M09.03-C013-T08 · Enforcement evidence:** Exercise the “Approved identity lookup” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M09.03-C013-T09 · Regression linkage:** Link the “Approved identity lookup” property to changes in approved dependency identities, mutable cache roots and executable handoff; record which dependency or contract changes require rerunning it.
- [ ] **UC-M09.03-C013-T10 · Property disposition:** Compare the satisfying and violating “Approved identity lookup” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M09.03-C014 · Integration

**Original checklist item:** Integrate approved identity lookup with approved dependency identities, mutable cache roots and executable handoff; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M09.03-C014-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Approved identity lookup” across approved dependency identities, mutable cache roots and executable handoff; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M09.03-C014-T02 · Field mapping:** Map every “Approved identity lookup” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M09.03-C014-T03 · Prerequisite identities:** Record the actual prerequisites for “Approved identity lookup” (source dependency list: UC-M04.05, UC-M06.05, UC-M09.01); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M09.03-C014-T04 · Ownership agreement:** Specify who owns “Approved identity lookup” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M09.03-C014-T05 · Handoff implementation:** Connect “Approved identity lookup” through the mapped seam using the real adapter or explicit specification reference; preserve “The cache cannot nominate its own expected digest” across the handoff.
- [ ] **UC-M09.03-C014-T06 · Absent-input case:** Omit one required “Approved identity lookup” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M09.03-C014-T07 · Stale-input case:** Supply an outdated “Approved identity lookup” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M09.03-C014-T08 · Incompatible-input case:** Supply an incompatible “Approved identity lookup” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M09.03-C014-T09 · Valid integration trace:** Run a valid “Approved identity lookup” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M09.03-C014-T10 · Seam review:** Reconcile the “Approved identity lookup” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M09.03-C015 · Valid-case test

**Original checklist item:** Run a valid-path fixture for approved identity lookup; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M09.03-C015-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Approved identity lookup” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M09.03-C015-T02 · Expected-result oracle:** Specify the “Approved identity lookup” expected result independently of the implementation output; include the property “The cache cannot nominate its own expected digest” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M09.03-C015-T03 · Fixture material:** Create the concrete “Approved identity lookup” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M09.03-C015-T04 · Target preparation:** Prepare the “Approved identity lookup” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M09.03-C015-T05 · Initial-state record:** Record the initial “Approved identity lookup” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M09.03-C015-T06 · Valid-path execution:** Execute the “Approved identity lookup” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M09.03-C015-T07 · Outcome comparison:** Compare every declared “Approved identity lookup” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M09.03-C015-T08 · State and bounds check:** Inspect the “Approved identity lookup” ownership/state effects and actual use of “Graph lookups and verification metadata bytes”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M09.03-C015-T09 · Repeatability check:** Repeat the same “Approved identity lookup” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M09.03-C015-T10 · Positive evidence:** Attach the “Approved identity lookup” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M09.03-C016 · Negative test

**Original checklist item:** Negative case: A modified executable updates its adjacent local checksum file. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M09.03-C016-T01 · Adverse-case definition:** Create a test record for the exact “Approved identity lookup” source counterexample: “A modified executable updates its adjacent local checksum file”; state which precondition or invariant it challenges.
- [ ] **UC-M09.03-C016-T02 · Safe fixture boundary:** Define the contained test boundary for “Approved identity lookup”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M09.03-C016-T03 · Valid control:** Construct a valid “Approved identity lookup” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M09.03-C016-T04 · Minimal adverse input:** Derive the “Approved identity lookup” adverse fixture from the control with the smallest documented change needed to reproduce “A modified executable updates its adjacent local checksum file”; retain that change as reproducible data.
- [ ] **UC-M09.03-C016-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Approved identity lookup”; require “The cache cannot nominate its own expected digest” and forbid a false-success verdict.
- [ ] **UC-M09.03-C016-T06 · Adverse execution:** Exercise the “Approved identity lookup” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M09.03-C016-T07 · Effect inspection:** Inspect “Approved identity lookup” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M09.03-C016-T08 · Refusal versus failure:** Confirm the “Approved identity lookup” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M09.03-C016-T09 · Reset and retention:** Restore only the disposable “Approved identity lookup” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M09.03-C016-T10 · Negative regression:** Register the “Approved identity lookup” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M09.03-C017 · Change / failure test

**Original checklist item:** Exercise approved identity lookup when a cached executable changes while its original hold archive remains intact; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M09.03-C017-T01 · Scenario record:** Write the “Approved identity lookup” change/failure scenario exactly as supplied: a cached executable changes while its original hold archive remains intact; identify the property that must remain true: “The cache cannot nominate its own expected digest”.
- [ ] **UC-M09.03-C017-T02 · Baseline capture:** Create a known-valid “Approved identity lookup” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M09.03-C017-T03 · Injection map:** Locate the “Approved identity lookup” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M09.03-C017-T04 · Disposition oracle:** Define the legal intermediate and final “Approved identity lookup” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M09.03-C017-T05 · Controlled trigger:** Introduce the controlled “Approved identity lookup” scenario in the disposable fixture: a cached executable changes while its original hold archive remains intact; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M09.03-C017-T06 · Intermediate inspection:** Inspect the “Approved identity lookup” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M09.03-C017-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Approved identity lookup”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M09.03-C017-T08 · Stale-evidence cleanup:** Invalidate superseded “Approved identity lookup” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M09.03-C017-T09 · Repeat and compare:** Repeat the selected “Approved identity lookup” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M09.03-C017-T10 · Failure evidence:** Publish the “Approved identity lookup” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M09.03-C018 · Bounds

**Original checklist item:** Choose, document and test limits for graph lookups and verification metadata bytes; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M09.03-C018-T01 · Quantity inventory:** Create a measurement inventory for “Approved identity lookup”: “Graph lookups and verification metadata bytes”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M09.03-C018-T02 · Measurement method:** Choose how to observe each “Approved identity lookup” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M09.03-C018-T03 · Budget decision:** Select justified resource and input limits for “Approved identity lookup”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M09.03-C018-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Approved identity lookup” cases for “Graph lookups and verification metadata bytes”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M09.03-C018-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Approved identity lookup” limit; preserve “The cache cannot nominate its own expected digest”.
- [ ] **UC-M09.03-C018-T06 · Normal measurement:** Run or review the normal “Approved identity lookup” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M09.03-C018-T07 · At-limit measurement:** Exercise the “Approved identity lookup” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M09.03-C018-T08 · Over-limit measurement:** Exercise the “Approved identity lookup” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M09.03-C018-T09 · Uncovered-scope report:** List the “Approved identity lookup” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M09.03-C018-T10 · Limit evidence:** Publish the selected “Approved identity lookup” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M09.03-C019 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for approved identity lookup with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M09.03-C019-T01 · Event inventory:** List the “Approved identity lookup” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M09.03-C019-T02 · Diagnostic schema:** Define nonsecret fields for “Approved identity lookup” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M09.03-C019-T03 · Failure mapping:** Map each documented “Approved identity lookup” refusal or error to a diagnostic outcome; include “A modified executable updates its adjacent local checksum file” and prohibit conversion into a success message.
- [ ] **UC-M09.03-C019-T04 · Emission path:** Add the “Approved identity lookup” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M09.03-C019-T05 · Redaction check:** Test “Approved identity lookup” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M09.03-C019-T06 · Output budget:** Set and exercise bounded “Approved identity lookup” message size, rate and retention compatible with “Graph lookups and verification metadata bytes”; define truncation behavior that preserves the final reason.
- [ ] **UC-M09.03-C019-T07 · Success/refusal fixtures:** Capture “Approved identity lookup” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M09.03-C019-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Approved identity lookup” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M09.03-C019-T09 · Operator review:** Read the “Approved identity lookup” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M09.03-C019-T10 · Diagnostic evidence:** Publish redacted “Approved identity lookup” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M09.03-C020 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for approved identity lookup; label unexecuted checks as untested.

- [ ] **UC-M09.03-C020-T01 · Evidence inventory:** List the “Approved identity lookup” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M09.03-C020-T02 · Artifact references:** Record the exact “Approved identity lookup” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M09.03-C020-T03 · Fixture references:** Attach the “Approved identity lookup” fixture IDs, input identities and oracle definition; preserve the source counterexample “A modified executable updates its adjacent local checksum file” as a distinct evidence case.
- [ ] **UC-M09.03-C020-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Approved identity lookup”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M09.03-C020-T05 · Environment record:** Record the actual “Approved identity lookup” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M09.03-C020-T06 · Expected versus observed:** Pair every “Approved identity lookup” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M09.03-C020-T07 · Failure and limit records:** Attach “Approved identity lookup” change/failure and bounds evidence where required; include uncovered “Graph lookups and verification metadata bytes” and unresolved violations of “The cache cannot nominate its own expected digest”.
- [ ] **UC-M09.03-C020-T08 · Evidence hygiene:** Check the “Approved identity lookup” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M09.03-C020-T09 · Reproduction review:** Have the “Approved identity lookup” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M09.03-C020-T10 · Acceptance linkage:** Link the “Approved identity lookup” evidence to its parent and UC-M09.03 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 03. Use-time verification

**Source delivery:** Verify executable cache contents immediately before trusted use.

**Source invariant:** An intact original hold archive does not vouch for a changed extracted executable.

**Source negative case:** A native binary changes while the hold ZIP still matches its pin.

**Source bounded quantities:** Verified bytes and allowed verification latency.

### UC-M09.03-C021 · Contract

**Original checklist item:** Specify use-time verification inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M09.03-C021-T01 · Scope statement:** Draft the operation boundary for “Use-time verification” within Verified executable-cache reads; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M09.03-C021-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Use-time verification”; record each producer, representation and missing-value meaning.
- [ ] **UC-M09.03-C021-T03 · Output inventory:** List the outputs of “Use-time verification” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M09.03-C021-T04 · Field dictionary:** Create a field-and-term dictionary for “Use-time verification”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M09.03-C021-T05 · Prerequisite contract:** Map “Use-time verification” to the source component prerequisites (UC-M04.05, UC-M06.05, UC-M09.01); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M09.03-C021-T06 · Authority map:** Identify who may produce, change and consume “Use-time verification”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M09.03-C021-T07 · Invariant clause:** Add a normative clause for “Use-time verification” that preserves “An intact original hold archive does not vouch for a changed extracted executable”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M09.03-C021-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Use-time verification”; include the source counterexample “A native binary changes while the hold ZIP still matches its pin” and the intended safe disposition.
- [ ] **UC-M09.03-C021-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Verified bytes and allowed verification latency” in the “Use-time verification” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M09.03-C021-T10 · Contract review:** Review the “Use-time verification” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M09.03-C022 · Delivery

**Original checklist item:** Verify executable cache contents immediately before trusted use.

- [ ] **UC-M09.03-C022-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Use-time verification”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M09.03-C022-T02 · Change plan:** Break the source delivery for “Use-time verification” into concrete edit targets and reviewable outputs; keep the UC-M09.03 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M09.03-C022-T03 · Core artifact:** Create the “Use-time verification” fixture or harness for this source instruction: Verify executable cache contents immediately before trusted use.
- [ ] **UC-M09.03-C022-T04 · Concrete realization:** Connect the “Use-time verification” harness to its actual intended target, set the expected oracle before running it, and distinguish a mock/control run from a target run.
- [ ] **UC-M09.03-C022-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Use-time verification” needed to preserve “An intact original hold archive does not vouch for a changed extracted executable”; record an enforcement gap where only a model exists.
- [ ] **UC-M09.03-C022-T06 · Dependency connection:** Connect the “Use-time verification” implementation to approved dependency identities, mutable cache roots and executable handoff; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M09.03-C022-T07 · Resource behavior:** Account for “Verified bytes and allowed verification latency” in “Use-time verification”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M09.03-C022-T08 · Delivery check:** Run the smallest real “Use-time verification” path and its adverse fixture “A native binary changes while the hold ZIP still matches its pin”; retain actual output, state effects and final disposition.
- [ ] **UC-M09.03-C022-T09 · Patch review:** Review the “Use-time verification” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M09.03-C022-T10 · Delivery handoff:** Publish the “Use-time verification” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M09.03-C023 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: An intact original hold archive does not vouch for a changed extracted executable. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M09.03-C023-T01 · Named property:** Create a stable property/check name under this parent for “Use-time verification”; copy its required invariant exactly: “An intact original hold archive does not vouch for a changed extracted executable”.
- [ ] **UC-M09.03-C023-T02 · Observable terms:** Define each term in the “Use-time verification” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M09.03-C023-T03 · Precondition set:** List the preconditions under which “An intact original hold archive does not vouch for a changed extracted executable” must hold for “Use-time verification”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M09.03-C023-T04 · Transition coverage:** Map the “Use-time verification” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M09.03-C023-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Use-time verification”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M09.03-C023-T06 · Satisfying fixture:** Create a concrete “Use-time verification” case that satisfies “An intact original hold archive does not vouch for a changed extracted executable”; record its expected observation before running the assertion or review.
- [ ] **UC-M09.03-C023-T07 · Violating fixture:** Create the source counterexample “A native binary changes while the hold ZIP still matches its pin” for “Use-time verification”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M09.03-C023-T08 · Enforcement evidence:** Exercise the “Use-time verification” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M09.03-C023-T09 · Regression linkage:** Link the “Use-time verification” property to changes in approved dependency identities, mutable cache roots and executable handoff; record which dependency or contract changes require rerunning it.
- [ ] **UC-M09.03-C023-T10 · Property disposition:** Compare the satisfying and violating “Use-time verification” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M09.03-C024 · Integration

**Original checklist item:** Integrate use-time verification with approved dependency identities, mutable cache roots and executable handoff; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M09.03-C024-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Use-time verification” across approved dependency identities, mutable cache roots and executable handoff; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M09.03-C024-T02 · Field mapping:** Map every “Use-time verification” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M09.03-C024-T03 · Prerequisite identities:** Record the actual prerequisites for “Use-time verification” (source dependency list: UC-M04.05, UC-M06.05, UC-M09.01); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M09.03-C024-T04 · Ownership agreement:** Specify who owns “Use-time verification” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M09.03-C024-T05 · Handoff implementation:** Connect “Use-time verification” through the mapped seam using the real adapter or explicit specification reference; preserve “An intact original hold archive does not vouch for a changed extracted executable” across the handoff.
- [ ] **UC-M09.03-C024-T06 · Absent-input case:** Omit one required “Use-time verification” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M09.03-C024-T07 · Stale-input case:** Supply an outdated “Use-time verification” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M09.03-C024-T08 · Incompatible-input case:** Supply an incompatible “Use-time verification” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M09.03-C024-T09 · Valid integration trace:** Run a valid “Use-time verification” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M09.03-C024-T10 · Seam review:** Reconcile the “Use-time verification” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M09.03-C025 · Valid-case test

**Original checklist item:** Run a valid-path fixture for use-time verification; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M09.03-C025-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Use-time verification” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M09.03-C025-T02 · Expected-result oracle:** Specify the “Use-time verification” expected result independently of the implementation output; include the property “An intact original hold archive does not vouch for a changed extracted executable” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M09.03-C025-T03 · Fixture material:** Create the concrete “Use-time verification” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M09.03-C025-T04 · Target preparation:** Prepare the “Use-time verification” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M09.03-C025-T05 · Initial-state record:** Record the initial “Use-time verification” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M09.03-C025-T06 · Valid-path execution:** Execute the “Use-time verification” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M09.03-C025-T07 · Outcome comparison:** Compare every declared “Use-time verification” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M09.03-C025-T08 · State and bounds check:** Inspect the “Use-time verification” ownership/state effects and actual use of “Verified bytes and allowed verification latency”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M09.03-C025-T09 · Repeatability check:** Repeat the same “Use-time verification” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M09.03-C025-T10 · Positive evidence:** Attach the “Use-time verification” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M09.03-C026 · Negative test

**Original checklist item:** Negative case: A native binary changes while the hold ZIP still matches its pin. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M09.03-C026-T01 · Adverse-case definition:** Create a test record for the exact “Use-time verification” source counterexample: “A native binary changes while the hold ZIP still matches its pin”; state which precondition or invariant it challenges.
- [ ] **UC-M09.03-C026-T02 · Safe fixture boundary:** Define the contained test boundary for “Use-time verification”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M09.03-C026-T03 · Valid control:** Construct a valid “Use-time verification” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M09.03-C026-T04 · Minimal adverse input:** Derive the “Use-time verification” adverse fixture from the control with the smallest documented change needed to reproduce “A native binary changes while the hold ZIP still matches its pin”; retain that change as reproducible data.
- [ ] **UC-M09.03-C026-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Use-time verification”; require “An intact original hold archive does not vouch for a changed extracted executable” and forbid a false-success verdict.
- [ ] **UC-M09.03-C026-T06 · Adverse execution:** Exercise the “Use-time verification” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M09.03-C026-T07 · Effect inspection:** Inspect “Use-time verification” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M09.03-C026-T08 · Refusal versus failure:** Confirm the “Use-time verification” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M09.03-C026-T09 · Reset and retention:** Restore only the disposable “Use-time verification” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M09.03-C026-T10 · Negative regression:** Register the “Use-time verification” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M09.03-C027 · Change / failure test

**Original checklist item:** Exercise use-time verification when a cached executable changes while its original hold archive remains intact; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M09.03-C027-T01 · Scenario record:** Write the “Use-time verification” change/failure scenario exactly as supplied: a cached executable changes while its original hold archive remains intact; identify the property that must remain true: “An intact original hold archive does not vouch for a changed extracted executable”.
- [ ] **UC-M09.03-C027-T02 · Baseline capture:** Create a known-valid “Use-time verification” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M09.03-C027-T03 · Injection map:** Locate the “Use-time verification” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M09.03-C027-T04 · Disposition oracle:** Define the legal intermediate and final “Use-time verification” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M09.03-C027-T05 · Controlled trigger:** Introduce the controlled “Use-time verification” scenario in the disposable fixture: a cached executable changes while its original hold archive remains intact; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M09.03-C027-T06 · Intermediate inspection:** Inspect the “Use-time verification” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M09.03-C027-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Use-time verification”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M09.03-C027-T08 · Stale-evidence cleanup:** Invalidate superseded “Use-time verification” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M09.03-C027-T09 · Repeat and compare:** Repeat the selected “Use-time verification” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M09.03-C027-T10 · Failure evidence:** Publish the “Use-time verification” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M09.03-C028 · Bounds

**Original checklist item:** Choose, document and test limits for verified bytes and allowed verification latency; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M09.03-C028-T01 · Quantity inventory:** Create a measurement inventory for “Use-time verification”: “Verified bytes and allowed verification latency”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M09.03-C028-T02 · Measurement method:** Choose how to observe each “Use-time verification” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M09.03-C028-T03 · Budget decision:** Select justified resource and input limits for “Use-time verification”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M09.03-C028-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Use-time verification” cases for “Verified bytes and allowed verification latency”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M09.03-C028-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Use-time verification” limit; preserve “An intact original hold archive does not vouch for a changed extracted executable”.
- [ ] **UC-M09.03-C028-T06 · Normal measurement:** Run or review the normal “Use-time verification” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M09.03-C028-T07 · At-limit measurement:** Exercise the “Use-time verification” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M09.03-C028-T08 · Over-limit measurement:** Exercise the “Use-time verification” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M09.03-C028-T09 · Uncovered-scope report:** List the “Use-time verification” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M09.03-C028-T10 · Limit evidence:** Publish the selected “Use-time verification” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M09.03-C029 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for use-time verification with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M09.03-C029-T01 · Event inventory:** List the “Use-time verification” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M09.03-C029-T02 · Diagnostic schema:** Define nonsecret fields for “Use-time verification” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M09.03-C029-T03 · Failure mapping:** Map each documented “Use-time verification” refusal or error to a diagnostic outcome; include “A native binary changes while the hold ZIP still matches its pin” and prohibit conversion into a success message.
- [ ] **UC-M09.03-C029-T04 · Emission path:** Add the “Use-time verification” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M09.03-C029-T05 · Redaction check:** Test “Use-time verification” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M09.03-C029-T06 · Output budget:** Set and exercise bounded “Use-time verification” message size, rate and retention compatible with “Verified bytes and allowed verification latency”; define truncation behavior that preserves the final reason.
- [ ] **UC-M09.03-C029-T07 · Success/refusal fixtures:** Capture “Use-time verification” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M09.03-C029-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Use-time verification” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M09.03-C029-T09 · Operator review:** Read the “Use-time verification” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M09.03-C029-T10 · Diagnostic evidence:** Publish redacted “Use-time verification” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M09.03-C030 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for use-time verification; label unexecuted checks as untested.

- [ ] **UC-M09.03-C030-T01 · Evidence inventory:** List the “Use-time verification” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M09.03-C030-T02 · Artifact references:** Record the exact “Use-time verification” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M09.03-C030-T03 · Fixture references:** Attach the “Use-time verification” fixture IDs, input identities and oracle definition; preserve the source counterexample “A native binary changes while the hold ZIP still matches its pin” as a distinct evidence case.
- [ ] **UC-M09.03-C030-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Use-time verification”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M09.03-C030-T05 · Environment record:** Record the actual “Use-time verification” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M09.03-C030-T06 · Expected versus observed:** Pair every “Use-time verification” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M09.03-C030-T07 · Failure and limit records:** Attach “Use-time verification” change/failure and bounds evidence where required; include uncovered “Verified bytes and allowed verification latency” and unresolved violations of “An intact original hold archive does not vouch for a changed extracted executable”.
- [ ] **UC-M09.03-C030-T08 · Evidence hygiene:** Check the “Use-time verification” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M09.03-C030-T09 · Reproduction review:** Have the “Use-time verification” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M09.03-C030-T10 · Acceptance linkage:** Link the “Use-time verification” evidence to its parent and UC-M09.03 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 04. Source-to-binary binding

**Source delivery:** Bind cached native outputs to their source, toolchain and build recipe.

**Source invariant:** A valid source digest alone does not authorize an unrelated binary.

**Source negative case:** An old binary is retained after changing the engine source.

**Source bounded quantities:** Build relationships and dependency fan-out.

### UC-M09.03-C031 · Contract

**Original checklist item:** Specify source-to-binary binding inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M09.03-C031-T01 · Scope statement:** Draft the operation boundary for “Source-to-binary binding” within Verified executable-cache reads; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M09.03-C031-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Source-to-binary binding”; record each producer, representation and missing-value meaning.
- [ ] **UC-M09.03-C031-T03 · Output inventory:** List the outputs of “Source-to-binary binding” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M09.03-C031-T04 · Field dictionary:** Create a field-and-term dictionary for “Source-to-binary binding”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M09.03-C031-T05 · Prerequisite contract:** Map “Source-to-binary binding” to the source component prerequisites (UC-M04.05, UC-M06.05, UC-M09.01); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M09.03-C031-T06 · Authority map:** Identify who may produce, change and consume “Source-to-binary binding”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M09.03-C031-T07 · Invariant clause:** Add a normative clause for “Source-to-binary binding” that preserves “A valid source digest alone does not authorize an unrelated binary”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M09.03-C031-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Source-to-binary binding”; include the source counterexample “An old binary is retained after changing the engine source” and the intended safe disposition.
- [ ] **UC-M09.03-C031-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Build relationships and dependency fan-out” in the “Source-to-binary binding” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M09.03-C031-T10 · Contract review:** Review the “Source-to-binary binding” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M09.03-C032 · Delivery

**Original checklist item:** Bind cached native outputs to their source, toolchain and build recipe.

- [ ] **UC-M09.03-C032-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Source-to-binary binding”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M09.03-C032-T02 · Change plan:** Break the source delivery for “Source-to-binary binding” into concrete edit targets and reviewable outputs; keep the UC-M09.03 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M09.03-C032-T03 · Core artifact:** Implement the smallest selected-profile change for “Source-to-binary binding” that realizes this source instruction: Bind cached native outputs to their source, toolchain and build recipe.
- [ ] **UC-M09.03-C032-T04 · Concrete realization:** Trace “Source-to-binary binding” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M09.03-C032-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Source-to-binary binding” needed to preserve “A valid source digest alone does not authorize an unrelated binary”; record an enforcement gap where only a model exists.
- [ ] **UC-M09.03-C032-T06 · Dependency connection:** Connect the “Source-to-binary binding” implementation to approved dependency identities, mutable cache roots and executable handoff; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M09.03-C032-T07 · Resource behavior:** Account for “Build relationships and dependency fan-out” in “Source-to-binary binding”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M09.03-C032-T08 · Delivery check:** Run the smallest real “Source-to-binary binding” path and its adverse fixture “An old binary is retained after changing the engine source”; retain actual output, state effects and final disposition.
- [ ] **UC-M09.03-C032-T09 · Patch review:** Review the “Source-to-binary binding” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M09.03-C032-T10 · Delivery handoff:** Publish the “Source-to-binary binding” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M09.03-C033 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: A valid source digest alone does not authorize an unrelated binary. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M09.03-C033-T01 · Named property:** Create a stable property/check name under this parent for “Source-to-binary binding”; copy its required invariant exactly: “A valid source digest alone does not authorize an unrelated binary”.
- [ ] **UC-M09.03-C033-T02 · Observable terms:** Define each term in the “Source-to-binary binding” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M09.03-C033-T03 · Precondition set:** List the preconditions under which “A valid source digest alone does not authorize an unrelated binary” must hold for “Source-to-binary binding”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M09.03-C033-T04 · Transition coverage:** Map the “Source-to-binary binding” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M09.03-C033-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Source-to-binary binding”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M09.03-C033-T06 · Satisfying fixture:** Create a concrete “Source-to-binary binding” case that satisfies “A valid source digest alone does not authorize an unrelated binary”; record its expected observation before running the assertion or review.
- [ ] **UC-M09.03-C033-T07 · Violating fixture:** Create the source counterexample “An old binary is retained after changing the engine source” for “Source-to-binary binding”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M09.03-C033-T08 · Enforcement evidence:** Exercise the “Source-to-binary binding” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M09.03-C033-T09 · Regression linkage:** Link the “Source-to-binary binding” property to changes in approved dependency identities, mutable cache roots and executable handoff; record which dependency or contract changes require rerunning it.
- [ ] **UC-M09.03-C033-T10 · Property disposition:** Compare the satisfying and violating “Source-to-binary binding” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M09.03-C034 · Integration

**Original checklist item:** Integrate source-to-binary binding with approved dependency identities, mutable cache roots and executable handoff; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M09.03-C034-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Source-to-binary binding” across approved dependency identities, mutable cache roots and executable handoff; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M09.03-C034-T02 · Field mapping:** Map every “Source-to-binary binding” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M09.03-C034-T03 · Prerequisite identities:** Record the actual prerequisites for “Source-to-binary binding” (source dependency list: UC-M04.05, UC-M06.05, UC-M09.01); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M09.03-C034-T04 · Ownership agreement:** Specify who owns “Source-to-binary binding” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M09.03-C034-T05 · Handoff implementation:** Connect “Source-to-binary binding” through the mapped seam using the real adapter or explicit specification reference; preserve “A valid source digest alone does not authorize an unrelated binary” across the handoff.
- [ ] **UC-M09.03-C034-T06 · Absent-input case:** Omit one required “Source-to-binary binding” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M09.03-C034-T07 · Stale-input case:** Supply an outdated “Source-to-binary binding” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M09.03-C034-T08 · Incompatible-input case:** Supply an incompatible “Source-to-binary binding” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M09.03-C034-T09 · Valid integration trace:** Run a valid “Source-to-binary binding” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M09.03-C034-T10 · Seam review:** Reconcile the “Source-to-binary binding” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M09.03-C035 · Valid-case test

**Original checklist item:** Run a valid-path fixture for source-to-binary binding; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M09.03-C035-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Source-to-binary binding” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M09.03-C035-T02 · Expected-result oracle:** Specify the “Source-to-binary binding” expected result independently of the implementation output; include the property “A valid source digest alone does not authorize an unrelated binary” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M09.03-C035-T03 · Fixture material:** Create the concrete “Source-to-binary binding” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M09.03-C035-T04 · Target preparation:** Prepare the “Source-to-binary binding” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M09.03-C035-T05 · Initial-state record:** Record the initial “Source-to-binary binding” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M09.03-C035-T06 · Valid-path execution:** Execute the “Source-to-binary binding” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M09.03-C035-T07 · Outcome comparison:** Compare every declared “Source-to-binary binding” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M09.03-C035-T08 · State and bounds check:** Inspect the “Source-to-binary binding” ownership/state effects and actual use of “Build relationships and dependency fan-out”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M09.03-C035-T09 · Repeatability check:** Repeat the same “Source-to-binary binding” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M09.03-C035-T10 · Positive evidence:** Attach the “Source-to-binary binding” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M09.03-C036 · Negative test

**Original checklist item:** Negative case: An old binary is retained after changing the engine source. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M09.03-C036-T01 · Adverse-case definition:** Create a test record for the exact “Source-to-binary binding” source counterexample: “An old binary is retained after changing the engine source”; state which precondition or invariant it challenges.
- [ ] **UC-M09.03-C036-T02 · Safe fixture boundary:** Define the contained test boundary for “Source-to-binary binding”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M09.03-C036-T03 · Valid control:** Construct a valid “Source-to-binary binding” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M09.03-C036-T04 · Minimal adverse input:** Derive the “Source-to-binary binding” adverse fixture from the control with the smallest documented change needed to reproduce “An old binary is retained after changing the engine source”; retain that change as reproducible data.
- [ ] **UC-M09.03-C036-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Source-to-binary binding”; require “A valid source digest alone does not authorize an unrelated binary” and forbid a false-success verdict.
- [ ] **UC-M09.03-C036-T06 · Adverse execution:** Exercise the “Source-to-binary binding” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M09.03-C036-T07 · Effect inspection:** Inspect “Source-to-binary binding” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M09.03-C036-T08 · Refusal versus failure:** Confirm the “Source-to-binary binding” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M09.03-C036-T09 · Reset and retention:** Restore only the disposable “Source-to-binary binding” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M09.03-C036-T10 · Negative regression:** Register the “Source-to-binary binding” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M09.03-C037 · Change / failure test

**Original checklist item:** Exercise source-to-binary binding when a cached executable changes while its original hold archive remains intact; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M09.03-C037-T01 · Scenario record:** Write the “Source-to-binary binding” change/failure scenario exactly as supplied: a cached executable changes while its original hold archive remains intact; identify the property that must remain true: “A valid source digest alone does not authorize an unrelated binary”.
- [ ] **UC-M09.03-C037-T02 · Baseline capture:** Create a known-valid “Source-to-binary binding” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M09.03-C037-T03 · Injection map:** Locate the “Source-to-binary binding” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M09.03-C037-T04 · Disposition oracle:** Define the legal intermediate and final “Source-to-binary binding” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M09.03-C037-T05 · Controlled trigger:** Introduce the controlled “Source-to-binary binding” scenario in the disposable fixture: a cached executable changes while its original hold archive remains intact; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M09.03-C037-T06 · Intermediate inspection:** Inspect the “Source-to-binary binding” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M09.03-C037-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Source-to-binary binding”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M09.03-C037-T08 · Stale-evidence cleanup:** Invalidate superseded “Source-to-binary binding” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M09.03-C037-T09 · Repeat and compare:** Repeat the selected “Source-to-binary binding” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M09.03-C037-T10 · Failure evidence:** Publish the “Source-to-binary binding” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M09.03-C038 · Bounds

**Original checklist item:** Choose, document and test limits for build relationships and dependency fan-out; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M09.03-C038-T01 · Quantity inventory:** Create a measurement inventory for “Source-to-binary binding”: “Build relationships and dependency fan-out”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M09.03-C038-T02 · Measurement method:** Choose how to observe each “Source-to-binary binding” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M09.03-C038-T03 · Budget decision:** Select justified resource and input limits for “Source-to-binary binding”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M09.03-C038-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Source-to-binary binding” cases for “Build relationships and dependency fan-out”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M09.03-C038-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Source-to-binary binding” limit; preserve “A valid source digest alone does not authorize an unrelated binary”.
- [ ] **UC-M09.03-C038-T06 · Normal measurement:** Run or review the normal “Source-to-binary binding” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M09.03-C038-T07 · At-limit measurement:** Exercise the “Source-to-binary binding” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M09.03-C038-T08 · Over-limit measurement:** Exercise the “Source-to-binary binding” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M09.03-C038-T09 · Uncovered-scope report:** List the “Source-to-binary binding” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M09.03-C038-T10 · Limit evidence:** Publish the selected “Source-to-binary binding” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M09.03-C039 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for source-to-binary binding with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M09.03-C039-T01 · Event inventory:** List the “Source-to-binary binding” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M09.03-C039-T02 · Diagnostic schema:** Define nonsecret fields for “Source-to-binary binding” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M09.03-C039-T03 · Failure mapping:** Map each documented “Source-to-binary binding” refusal or error to a diagnostic outcome; include “An old binary is retained after changing the engine source” and prohibit conversion into a success message.
- [ ] **UC-M09.03-C039-T04 · Emission path:** Add the “Source-to-binary binding” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M09.03-C039-T05 · Redaction check:** Test “Source-to-binary binding” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M09.03-C039-T06 · Output budget:** Set and exercise bounded “Source-to-binary binding” message size, rate and retention compatible with “Build relationships and dependency fan-out”; define truncation behavior that preserves the final reason.
- [ ] **UC-M09.03-C039-T07 · Success/refusal fixtures:** Capture “Source-to-binary binding” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M09.03-C039-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Source-to-binary binding” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M09.03-C039-T09 · Operator review:** Read the “Source-to-binary binding” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M09.03-C039-T10 · Diagnostic evidence:** Publish redacted “Source-to-binary binding” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M09.03-C040 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for source-to-binary binding; label unexecuted checks as untested.

- [ ] **UC-M09.03-C040-T01 · Evidence inventory:** List the “Source-to-binary binding” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M09.03-C040-T02 · Artifact references:** Record the exact “Source-to-binary binding” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M09.03-C040-T03 · Fixture references:** Attach the “Source-to-binary binding” fixture IDs, input identities and oracle definition; preserve the source counterexample “An old binary is retained after changing the engine source” as a distinct evidence case.
- [ ] **UC-M09.03-C040-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Source-to-binary binding”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M09.03-C040-T05 · Environment record:** Record the actual “Source-to-binary binding” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M09.03-C040-T06 · Expected versus observed:** Pair every “Source-to-binary binding” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M09.03-C040-T07 · Failure and limit records:** Attach “Source-to-binary binding” change/failure and bounds evidence where required; include uncovered “Build relationships and dependency fan-out” and unresolved violations of “A valid source digest alone does not authorize an unrelated binary”.
- [ ] **UC-M09.03-C040-T08 · Evidence hygiene:** Check the “Source-to-binary binding” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M09.03-C040-T09 · Reproduction review:** Have the “Source-to-binary binding” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M09.03-C040-T10 · Acceptance linkage:** Link the “Source-to-binary binding” evidence to its parent and UC-M09.03 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 05. Adapter verification

**Source delivery:** Include launch adapters and helper scripts in executable trust decisions.

**Source invariant:** A trusted image cannot be redirected by a tampered helper.

**Source negative case:** A modified adapter bypasses the selected backend and runs host code.

**Source bounded quantities:** Adapter count and script bytes.

### UC-M09.03-C041 · Contract

**Original checklist item:** Specify adapter verification inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M09.03-C041-T01 · Scope statement:** Draft the operation boundary for “Adapter verification” within Verified executable-cache reads; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M09.03-C041-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Adapter verification”; record each producer, representation and missing-value meaning.
- [ ] **UC-M09.03-C041-T03 · Output inventory:** List the outputs of “Adapter verification” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M09.03-C041-T04 · Field dictionary:** Create a field-and-term dictionary for “Adapter verification”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M09.03-C041-T05 · Prerequisite contract:** Map “Adapter verification” to the source component prerequisites (UC-M04.05, UC-M06.05, UC-M09.01); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M09.03-C041-T06 · Authority map:** Identify who may produce, change and consume “Adapter verification”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M09.03-C041-T07 · Invariant clause:** Add a normative clause for “Adapter verification” that preserves “A trusted image cannot be redirected by a tampered helper”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M09.03-C041-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Adapter verification”; include the source counterexample “A modified adapter bypasses the selected backend and runs host code” and the intended safe disposition.
- [ ] **UC-M09.03-C041-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Adapter count and script bytes” in the “Adapter verification” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M09.03-C041-T10 · Contract review:** Review the “Adapter verification” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M09.03-C042 · Delivery

**Original checklist item:** Include launch adapters and helper scripts in executable trust decisions.

- [ ] **UC-M09.03-C042-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Adapter verification”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M09.03-C042-T02 · Change plan:** Break the source delivery for “Adapter verification” into concrete edit targets and reviewable outputs; keep the UC-M09.03 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M09.03-C042-T03 · Core artifact:** Implement the smallest selected-profile change for “Adapter verification” that realizes this source instruction: Include launch adapters and helper scripts in executable trust decisions.
- [ ] **UC-M09.03-C042-T04 · Concrete realization:** Trace “Adapter verification” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M09.03-C042-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Adapter verification” needed to preserve “A trusted image cannot be redirected by a tampered helper”; record an enforcement gap where only a model exists.
- [ ] **UC-M09.03-C042-T06 · Dependency connection:** Connect the “Adapter verification” implementation to approved dependency identities, mutable cache roots and executable handoff; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M09.03-C042-T07 · Resource behavior:** Account for “Adapter count and script bytes” in “Adapter verification”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M09.03-C042-T08 · Delivery check:** Run the smallest real “Adapter verification” path and its adverse fixture “A modified adapter bypasses the selected backend and runs host code”; retain actual output, state effects and final disposition.
- [ ] **UC-M09.03-C042-T09 · Patch review:** Review the “Adapter verification” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M09.03-C042-T10 · Delivery handoff:** Publish the “Adapter verification” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M09.03-C043 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: A trusted image cannot be redirected by a tampered helper. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M09.03-C043-T01 · Named property:** Create a stable property/check name under this parent for “Adapter verification”; copy its required invariant exactly: “A trusted image cannot be redirected by a tampered helper”.
- [ ] **UC-M09.03-C043-T02 · Observable terms:** Define each term in the “Adapter verification” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M09.03-C043-T03 · Precondition set:** List the preconditions under which “A trusted image cannot be redirected by a tampered helper” must hold for “Adapter verification”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M09.03-C043-T04 · Transition coverage:** Map the “Adapter verification” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M09.03-C043-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Adapter verification”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M09.03-C043-T06 · Satisfying fixture:** Create a concrete “Adapter verification” case that satisfies “A trusted image cannot be redirected by a tampered helper”; record its expected observation before running the assertion or review.
- [ ] **UC-M09.03-C043-T07 · Violating fixture:** Create the source counterexample “A modified adapter bypasses the selected backend and runs host code” for “Adapter verification”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M09.03-C043-T08 · Enforcement evidence:** Exercise the “Adapter verification” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M09.03-C043-T09 · Regression linkage:** Link the “Adapter verification” property to changes in approved dependency identities, mutable cache roots and executable handoff; record which dependency or contract changes require rerunning it.
- [ ] **UC-M09.03-C043-T10 · Property disposition:** Compare the satisfying and violating “Adapter verification” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M09.03-C044 · Integration

**Original checklist item:** Integrate adapter verification with approved dependency identities, mutable cache roots and executable handoff; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M09.03-C044-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Adapter verification” across approved dependency identities, mutable cache roots and executable handoff; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M09.03-C044-T02 · Field mapping:** Map every “Adapter verification” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M09.03-C044-T03 · Prerequisite identities:** Record the actual prerequisites for “Adapter verification” (source dependency list: UC-M04.05, UC-M06.05, UC-M09.01); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M09.03-C044-T04 · Ownership agreement:** Specify who owns “Adapter verification” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M09.03-C044-T05 · Handoff implementation:** Connect “Adapter verification” through the mapped seam using the real adapter or explicit specification reference; preserve “A trusted image cannot be redirected by a tampered helper” across the handoff.
- [ ] **UC-M09.03-C044-T06 · Absent-input case:** Omit one required “Adapter verification” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M09.03-C044-T07 · Stale-input case:** Supply an outdated “Adapter verification” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M09.03-C044-T08 · Incompatible-input case:** Supply an incompatible “Adapter verification” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M09.03-C044-T09 · Valid integration trace:** Run a valid “Adapter verification” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M09.03-C044-T10 · Seam review:** Reconcile the “Adapter verification” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M09.03-C045 · Valid-case test

**Original checklist item:** Run a valid-path fixture for adapter verification; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M09.03-C045-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Adapter verification” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M09.03-C045-T02 · Expected-result oracle:** Specify the “Adapter verification” expected result independently of the implementation output; include the property “A trusted image cannot be redirected by a tampered helper” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M09.03-C045-T03 · Fixture material:** Create the concrete “Adapter verification” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M09.03-C045-T04 · Target preparation:** Prepare the “Adapter verification” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M09.03-C045-T05 · Initial-state record:** Record the initial “Adapter verification” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M09.03-C045-T06 · Valid-path execution:** Execute the “Adapter verification” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M09.03-C045-T07 · Outcome comparison:** Compare every declared “Adapter verification” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M09.03-C045-T08 · State and bounds check:** Inspect the “Adapter verification” ownership/state effects and actual use of “Adapter count and script bytes”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M09.03-C045-T09 · Repeatability check:** Repeat the same “Adapter verification” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M09.03-C045-T10 · Positive evidence:** Attach the “Adapter verification” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M09.03-C046 · Negative test

**Original checklist item:** Negative case: A modified adapter bypasses the selected backend and runs host code. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M09.03-C046-T01 · Adverse-case definition:** Create a test record for the exact “Adapter verification” source counterexample: “A modified adapter bypasses the selected backend and runs host code”; state which precondition or invariant it challenges.
- [ ] **UC-M09.03-C046-T02 · Safe fixture boundary:** Define the contained test boundary for “Adapter verification”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M09.03-C046-T03 · Valid control:** Construct a valid “Adapter verification” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M09.03-C046-T04 · Minimal adverse input:** Derive the “Adapter verification” adverse fixture from the control with the smallest documented change needed to reproduce “A modified adapter bypasses the selected backend and runs host code”; retain that change as reproducible data.
- [ ] **UC-M09.03-C046-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Adapter verification”; require “A trusted image cannot be redirected by a tampered helper” and forbid a false-success verdict.
- [ ] **UC-M09.03-C046-T06 · Adverse execution:** Exercise the “Adapter verification” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M09.03-C046-T07 · Effect inspection:** Inspect “Adapter verification” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M09.03-C046-T08 · Refusal versus failure:** Confirm the “Adapter verification” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M09.03-C046-T09 · Reset and retention:** Restore only the disposable “Adapter verification” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M09.03-C046-T10 · Negative regression:** Register the “Adapter verification” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M09.03-C047 · Change / failure test

**Original checklist item:** Exercise adapter verification when a cached executable changes while its original hold archive remains intact; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M09.03-C047-T01 · Scenario record:** Write the “Adapter verification” change/failure scenario exactly as supplied: a cached executable changes while its original hold archive remains intact; identify the property that must remain true: “A trusted image cannot be redirected by a tampered helper”.
- [ ] **UC-M09.03-C047-T02 · Baseline capture:** Create a known-valid “Adapter verification” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M09.03-C047-T03 · Injection map:** Locate the “Adapter verification” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M09.03-C047-T04 · Disposition oracle:** Define the legal intermediate and final “Adapter verification” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M09.03-C047-T05 · Controlled trigger:** Introduce the controlled “Adapter verification” scenario in the disposable fixture: a cached executable changes while its original hold archive remains intact; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M09.03-C047-T06 · Intermediate inspection:** Inspect the “Adapter verification” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M09.03-C047-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Adapter verification”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M09.03-C047-T08 · Stale-evidence cleanup:** Invalidate superseded “Adapter verification” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M09.03-C047-T09 · Repeat and compare:** Repeat the selected “Adapter verification” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M09.03-C047-T10 · Failure evidence:** Publish the “Adapter verification” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M09.03-C048 · Bounds

**Original checklist item:** Choose, document and test limits for adapter count and script bytes; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M09.03-C048-T01 · Quantity inventory:** Create a measurement inventory for “Adapter verification”: “Adapter count and script bytes”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M09.03-C048-T02 · Measurement method:** Choose how to observe each “Adapter verification” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M09.03-C048-T03 · Budget decision:** Select justified resource and input limits for “Adapter verification”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M09.03-C048-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Adapter verification” cases for “Adapter count and script bytes”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M09.03-C048-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Adapter verification” limit; preserve “A trusted image cannot be redirected by a tampered helper”.
- [ ] **UC-M09.03-C048-T06 · Normal measurement:** Run or review the normal “Adapter verification” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M09.03-C048-T07 · At-limit measurement:** Exercise the “Adapter verification” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M09.03-C048-T08 · Over-limit measurement:** Exercise the “Adapter verification” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M09.03-C048-T09 · Uncovered-scope report:** List the “Adapter verification” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M09.03-C048-T10 · Limit evidence:** Publish the selected “Adapter verification” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M09.03-C049 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for adapter verification with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M09.03-C049-T01 · Event inventory:** List the “Adapter verification” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M09.03-C049-T02 · Diagnostic schema:** Define nonsecret fields for “Adapter verification” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M09.03-C049-T03 · Failure mapping:** Map each documented “Adapter verification” refusal or error to a diagnostic outcome; include “A modified adapter bypasses the selected backend and runs host code” and prohibit conversion into a success message.
- [ ] **UC-M09.03-C049-T04 · Emission path:** Add the “Adapter verification” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M09.03-C049-T05 · Redaction check:** Test “Adapter verification” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M09.03-C049-T06 · Output budget:** Set and exercise bounded “Adapter verification” message size, rate and retention compatible with “Adapter count and script bytes”; define truncation behavior that preserves the final reason.
- [ ] **UC-M09.03-C049-T07 · Success/refusal fixtures:** Capture “Adapter verification” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M09.03-C049-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Adapter verification” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M09.03-C049-T09 · Operator review:** Read the “Adapter verification” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M09.03-C049-T10 · Diagnostic evidence:** Publish redacted “Adapter verification” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M09.03-C050 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for adapter verification; label unexecuted checks as untested.

- [ ] **UC-M09.03-C050-T01 · Evidence inventory:** List the “Adapter verification” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M09.03-C050-T02 · Artifact references:** Record the exact “Adapter verification” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M09.03-C050-T03 · Fixture references:** Attach the “Adapter verification” fixture IDs, input identities and oracle definition; preserve the source counterexample “A modified adapter bypasses the selected backend and runs host code” as a distinct evidence case.
- [ ] **UC-M09.03-C050-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Adapter verification”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M09.03-C050-T05 · Environment record:** Record the actual “Adapter verification” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M09.03-C050-T06 · Expected versus observed:** Pair every “Adapter verification” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M09.03-C050-T07 · Failure and limit records:** Attach “Adapter verification” change/failure and bounds evidence where required; include uncovered “Adapter count and script bytes” and unresolved violations of “A trusted image cannot be redirected by a tampered helper”.
- [ ] **UC-M09.03-C050-T08 · Evidence hygiene:** Check the “Adapter verification” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M09.03-C050-T09 · Reproduction review:** Have the “Adapter verification” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M09.03-C050-T10 · Acceptance linkage:** Link the “Adapter verification” evidence to its parent and UC-M09.03 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 06. Mutable-root protection

**Source delivery:** Separate writable workspace state from approved executable cache authority.

**Source invariant:** Untrusted cargo cannot rewrite executable inputs in place.

**Source negative case:** A workload writes into a shared runtime cache.

**Source bounded quantities:** Writable roots and cache permissions.

### UC-M09.03-C051 · Contract

**Original checklist item:** Specify mutable-root protection inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M09.03-C051-T01 · Scope statement:** Draft the operation boundary for “Mutable-root protection” within Verified executable-cache reads; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M09.03-C051-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Mutable-root protection”; record each producer, representation and missing-value meaning.
- [ ] **UC-M09.03-C051-T03 · Output inventory:** List the outputs of “Mutable-root protection” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M09.03-C051-T04 · Field dictionary:** Create a field-and-term dictionary for “Mutable-root protection”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M09.03-C051-T05 · Prerequisite contract:** Map “Mutable-root protection” to the source component prerequisites (UC-M04.05, UC-M06.05, UC-M09.01); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M09.03-C051-T06 · Authority map:** Identify who may produce, change and consume “Mutable-root protection”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M09.03-C051-T07 · Invariant clause:** Add a normative clause for “Mutable-root protection” that preserves “Untrusted cargo cannot rewrite executable inputs in place”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M09.03-C051-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Mutable-root protection”; include the source counterexample “A workload writes into a shared runtime cache” and the intended safe disposition.
- [ ] **UC-M09.03-C051-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Writable roots and cache permissions” in the “Mutable-root protection” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M09.03-C051-T10 · Contract review:** Review the “Mutable-root protection” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M09.03-C052 · Delivery

**Original checklist item:** Separate writable workspace state from approved executable cache authority.

- [ ] **UC-M09.03-C052-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Mutable-root protection”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M09.03-C052-T02 · Change plan:** Break the source delivery for “Mutable-root protection” into concrete edit targets and reviewable outputs; keep the UC-M09.03 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M09.03-C052-T03 · Core artifact:** Implement the smallest selected-profile change for “Mutable-root protection” that realizes this source instruction: Separate writable workspace state from approved executable cache authority.
- [ ] **UC-M09.03-C052-T04 · Concrete realization:** Trace “Mutable-root protection” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M09.03-C052-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Mutable-root protection” needed to preserve “Untrusted cargo cannot rewrite executable inputs in place”; record an enforcement gap where only a model exists.
- [ ] **UC-M09.03-C052-T06 · Dependency connection:** Connect the “Mutable-root protection” implementation to approved dependency identities, mutable cache roots and executable handoff; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M09.03-C052-T07 · Resource behavior:** Account for “Writable roots and cache permissions” in “Mutable-root protection”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M09.03-C052-T08 · Delivery check:** Run the smallest real “Mutable-root protection” path and its adverse fixture “A workload writes into a shared runtime cache”; retain actual output, state effects and final disposition.
- [ ] **UC-M09.03-C052-T09 · Patch review:** Review the “Mutable-root protection” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M09.03-C052-T10 · Delivery handoff:** Publish the “Mutable-root protection” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M09.03-C053 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Untrusted cargo cannot rewrite executable inputs in place. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M09.03-C053-T01 · Named property:** Create a stable property/check name under this parent for “Mutable-root protection”; copy its required invariant exactly: “Untrusted cargo cannot rewrite executable inputs in place”.
- [ ] **UC-M09.03-C053-T02 · Observable terms:** Define each term in the “Mutable-root protection” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M09.03-C053-T03 · Precondition set:** List the preconditions under which “Untrusted cargo cannot rewrite executable inputs in place” must hold for “Mutable-root protection”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M09.03-C053-T04 · Transition coverage:** Map the “Mutable-root protection” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M09.03-C053-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Mutable-root protection”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M09.03-C053-T06 · Satisfying fixture:** Create a concrete “Mutable-root protection” case that satisfies “Untrusted cargo cannot rewrite executable inputs in place”; record its expected observation before running the assertion or review.
- [ ] **UC-M09.03-C053-T07 · Violating fixture:** Create the source counterexample “A workload writes into a shared runtime cache” for “Mutable-root protection”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M09.03-C053-T08 · Enforcement evidence:** Exercise the “Mutable-root protection” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M09.03-C053-T09 · Regression linkage:** Link the “Mutable-root protection” property to changes in approved dependency identities, mutable cache roots and executable handoff; record which dependency or contract changes require rerunning it.
- [ ] **UC-M09.03-C053-T10 · Property disposition:** Compare the satisfying and violating “Mutable-root protection” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M09.03-C054 · Integration

**Original checklist item:** Integrate mutable-root protection with approved dependency identities, mutable cache roots and executable handoff; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M09.03-C054-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Mutable-root protection” across approved dependency identities, mutable cache roots and executable handoff; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M09.03-C054-T02 · Field mapping:** Map every “Mutable-root protection” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M09.03-C054-T03 · Prerequisite identities:** Record the actual prerequisites for “Mutable-root protection” (source dependency list: UC-M04.05, UC-M06.05, UC-M09.01); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M09.03-C054-T04 · Ownership agreement:** Specify who owns “Mutable-root protection” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M09.03-C054-T05 · Handoff implementation:** Connect “Mutable-root protection” through the mapped seam using the real adapter or explicit specification reference; preserve “Untrusted cargo cannot rewrite executable inputs in place” across the handoff.
- [ ] **UC-M09.03-C054-T06 · Absent-input case:** Omit one required “Mutable-root protection” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M09.03-C054-T07 · Stale-input case:** Supply an outdated “Mutable-root protection” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M09.03-C054-T08 · Incompatible-input case:** Supply an incompatible “Mutable-root protection” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M09.03-C054-T09 · Valid integration trace:** Run a valid “Mutable-root protection” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M09.03-C054-T10 · Seam review:** Reconcile the “Mutable-root protection” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M09.03-C055 · Valid-case test

**Original checklist item:** Run a valid-path fixture for mutable-root protection; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M09.03-C055-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Mutable-root protection” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M09.03-C055-T02 · Expected-result oracle:** Specify the “Mutable-root protection” expected result independently of the implementation output; include the property “Untrusted cargo cannot rewrite executable inputs in place” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M09.03-C055-T03 · Fixture material:** Create the concrete “Mutable-root protection” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M09.03-C055-T04 · Target preparation:** Prepare the “Mutable-root protection” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M09.03-C055-T05 · Initial-state record:** Record the initial “Mutable-root protection” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M09.03-C055-T06 · Valid-path execution:** Execute the “Mutable-root protection” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M09.03-C055-T07 · Outcome comparison:** Compare every declared “Mutable-root protection” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M09.03-C055-T08 · State and bounds check:** Inspect the “Mutable-root protection” ownership/state effects and actual use of “Writable roots and cache permissions”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M09.03-C055-T09 · Repeatability check:** Repeat the same “Mutable-root protection” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M09.03-C055-T10 · Positive evidence:** Attach the “Mutable-root protection” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M09.03-C056 · Negative test

**Original checklist item:** Negative case: A workload writes into a shared runtime cache. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M09.03-C056-T01 · Adverse-case definition:** Create a test record for the exact “Mutable-root protection” source counterexample: “A workload writes into a shared runtime cache”; state which precondition or invariant it challenges.
- [ ] **UC-M09.03-C056-T02 · Safe fixture boundary:** Define the contained test boundary for “Mutable-root protection”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M09.03-C056-T03 · Valid control:** Construct a valid “Mutable-root protection” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M09.03-C056-T04 · Minimal adverse input:** Derive the “Mutable-root protection” adverse fixture from the control with the smallest documented change needed to reproduce “A workload writes into a shared runtime cache”; retain that change as reproducible data.
- [ ] **UC-M09.03-C056-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Mutable-root protection”; require “Untrusted cargo cannot rewrite executable inputs in place” and forbid a false-success verdict.
- [ ] **UC-M09.03-C056-T06 · Adverse execution:** Exercise the “Mutable-root protection” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M09.03-C056-T07 · Effect inspection:** Inspect “Mutable-root protection” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M09.03-C056-T08 · Refusal versus failure:** Confirm the “Mutable-root protection” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M09.03-C056-T09 · Reset and retention:** Restore only the disposable “Mutable-root protection” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M09.03-C056-T10 · Negative regression:** Register the “Mutable-root protection” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M09.03-C057 · Change / failure test

**Original checklist item:** Exercise mutable-root protection when a cached executable changes while its original hold archive remains intact; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M09.03-C057-T01 · Scenario record:** Write the “Mutable-root protection” change/failure scenario exactly as supplied: a cached executable changes while its original hold archive remains intact; identify the property that must remain true: “Untrusted cargo cannot rewrite executable inputs in place”.
- [ ] **UC-M09.03-C057-T02 · Baseline capture:** Create a known-valid “Mutable-root protection” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M09.03-C057-T03 · Injection map:** Locate the “Mutable-root protection” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M09.03-C057-T04 · Disposition oracle:** Define the legal intermediate and final “Mutable-root protection” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M09.03-C057-T05 · Controlled trigger:** Introduce the controlled “Mutable-root protection” scenario in the disposable fixture: a cached executable changes while its original hold archive remains intact; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M09.03-C057-T06 · Intermediate inspection:** Inspect the “Mutable-root protection” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M09.03-C057-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Mutable-root protection”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M09.03-C057-T08 · Stale-evidence cleanup:** Invalidate superseded “Mutable-root protection” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M09.03-C057-T09 · Repeat and compare:** Repeat the selected “Mutable-root protection” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M09.03-C057-T10 · Failure evidence:** Publish the “Mutable-root protection” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M09.03-C058 · Bounds

**Original checklist item:** Choose, document and test limits for writable roots and cache permissions; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M09.03-C058-T01 · Quantity inventory:** Create a measurement inventory for “Mutable-root protection”: “Writable roots and cache permissions”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M09.03-C058-T02 · Measurement method:** Choose how to observe each “Mutable-root protection” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M09.03-C058-T03 · Budget decision:** Select justified resource and input limits for “Mutable-root protection”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M09.03-C058-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Mutable-root protection” cases for “Writable roots and cache permissions”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M09.03-C058-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Mutable-root protection” limit; preserve “Untrusted cargo cannot rewrite executable inputs in place”.
- [ ] **UC-M09.03-C058-T06 · Normal measurement:** Run or review the normal “Mutable-root protection” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M09.03-C058-T07 · At-limit measurement:** Exercise the “Mutable-root protection” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M09.03-C058-T08 · Over-limit measurement:** Exercise the “Mutable-root protection” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M09.03-C058-T09 · Uncovered-scope report:** List the “Mutable-root protection” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M09.03-C058-T10 · Limit evidence:** Publish the selected “Mutable-root protection” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M09.03-C059 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for mutable-root protection with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M09.03-C059-T01 · Event inventory:** List the “Mutable-root protection” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M09.03-C059-T02 · Diagnostic schema:** Define nonsecret fields for “Mutable-root protection” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M09.03-C059-T03 · Failure mapping:** Map each documented “Mutable-root protection” refusal or error to a diagnostic outcome; include “A workload writes into a shared runtime cache” and prohibit conversion into a success message.
- [ ] **UC-M09.03-C059-T04 · Emission path:** Add the “Mutable-root protection” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M09.03-C059-T05 · Redaction check:** Test “Mutable-root protection” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M09.03-C059-T06 · Output budget:** Set and exercise bounded “Mutable-root protection” message size, rate and retention compatible with “Writable roots and cache permissions”; define truncation behavior that preserves the final reason.
- [ ] **UC-M09.03-C059-T07 · Success/refusal fixtures:** Capture “Mutable-root protection” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M09.03-C059-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Mutable-root protection” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M09.03-C059-T09 · Operator review:** Read the “Mutable-root protection” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M09.03-C059-T10 · Diagnostic evidence:** Publish redacted “Mutable-root protection” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M09.03-C060 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for mutable-root protection; label unexecuted checks as untested.

- [ ] **UC-M09.03-C060-T01 · Evidence inventory:** List the “Mutable-root protection” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M09.03-C060-T02 · Artifact references:** Record the exact “Mutable-root protection” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M09.03-C060-T03 · Fixture references:** Attach the “Mutable-root protection” fixture IDs, input identities and oracle definition; preserve the source counterexample “A workload writes into a shared runtime cache” as a distinct evidence case.
- [ ] **UC-M09.03-C060-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Mutable-root protection”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M09.03-C060-T05 · Environment record:** Record the actual “Mutable-root protection” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M09.03-C060-T06 · Expected versus observed:** Pair every “Mutable-root protection” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M09.03-C060-T07 · Failure and limit records:** Attach “Mutable-root protection” change/failure and bounds evidence where required; include uncovered “Writable roots and cache permissions” and unresolved violations of “Untrusted cargo cannot rewrite executable inputs in place”.
- [ ] **UC-M09.03-C060-T08 · Evidence hygiene:** Check the “Mutable-root protection” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M09.03-C060-T09 · Reproduction review:** Have the “Mutable-root protection” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M09.03-C060-T10 · Acceptance linkage:** Link the “Mutable-root protection” evidence to its parent and UC-M09.03 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 07. Verification-to-use binding

**Source delivery:** Minimize or close the documented substitution window between verification and use.

**Source invariant:** Verified bytes and executed bytes correspond under the selected host mechanism.

**Source negative case:** A file is replaced immediately after its digest is checked.

**Source bounded quantities:** Handoff interval and concurrent replacement attempts.

### UC-M09.03-C061 · Contract

**Original checklist item:** Specify verification-to-use binding inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M09.03-C061-T01 · Scope statement:** Draft the operation boundary for “Verification-to-use binding” within Verified executable-cache reads; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M09.03-C061-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Verification-to-use binding”; record each producer, representation and missing-value meaning.
- [ ] **UC-M09.03-C061-T03 · Output inventory:** List the outputs of “Verification-to-use binding” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M09.03-C061-T04 · Field dictionary:** Create a field-and-term dictionary for “Verification-to-use binding”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M09.03-C061-T05 · Prerequisite contract:** Map “Verification-to-use binding” to the source component prerequisites (UC-M04.05, UC-M06.05, UC-M09.01); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M09.03-C061-T06 · Authority map:** Identify who may produce, change and consume “Verification-to-use binding”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M09.03-C061-T07 · Invariant clause:** Add a normative clause for “Verification-to-use binding” that preserves “Verified bytes and executed bytes correspond under the selected host mechanism”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M09.03-C061-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Verification-to-use binding”; include the source counterexample “A file is replaced immediately after its digest is checked” and the intended safe disposition.
- [ ] **UC-M09.03-C061-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Handoff interval and concurrent replacement attempts” in the “Verification-to-use binding” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M09.03-C061-T10 · Contract review:** Review the “Verification-to-use binding” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M09.03-C062 · Delivery

**Original checklist item:** Minimize or close the documented substitution window between verification and use.

- [ ] **UC-M09.03-C062-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Verification-to-use binding”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M09.03-C062-T02 · Change plan:** Break the source delivery for “Verification-to-use binding” into concrete edit targets and reviewable outputs; keep the UC-M09.03 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M09.03-C062-T03 · Core artifact:** Implement the smallest selected-profile change for “Verification-to-use binding” that realizes this source instruction: Minimize or close the documented substitution window between verification and use.
- [ ] **UC-M09.03-C062-T04 · Concrete realization:** Trace “Verification-to-use binding” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M09.03-C062-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Verification-to-use binding” needed to preserve “Verified bytes and executed bytes correspond under the selected host mechanism”; record an enforcement gap where only a model exists.
- [ ] **UC-M09.03-C062-T06 · Dependency connection:** Connect the “Verification-to-use binding” implementation to approved dependency identities, mutable cache roots and executable handoff; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M09.03-C062-T07 · Resource behavior:** Account for “Handoff interval and concurrent replacement attempts” in “Verification-to-use binding”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M09.03-C062-T08 · Delivery check:** Run the smallest real “Verification-to-use binding” path and its adverse fixture “A file is replaced immediately after its digest is checked”; retain actual output, state effects and final disposition.
- [ ] **UC-M09.03-C062-T09 · Patch review:** Review the “Verification-to-use binding” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M09.03-C062-T10 · Delivery handoff:** Publish the “Verification-to-use binding” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M09.03-C063 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Verified bytes and executed bytes correspond under the selected host mechanism. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M09.03-C063-T01 · Named property:** Create a stable property/check name under this parent for “Verification-to-use binding”; copy its required invariant exactly: “Verified bytes and executed bytes correspond under the selected host mechanism”.
- [ ] **UC-M09.03-C063-T02 · Observable terms:** Define each term in the “Verification-to-use binding” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M09.03-C063-T03 · Precondition set:** List the preconditions under which “Verified bytes and executed bytes correspond under the selected host mechanism” must hold for “Verification-to-use binding”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M09.03-C063-T04 · Transition coverage:** Map the “Verification-to-use binding” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M09.03-C063-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Verification-to-use binding”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M09.03-C063-T06 · Satisfying fixture:** Create a concrete “Verification-to-use binding” case that satisfies “Verified bytes and executed bytes correspond under the selected host mechanism”; record its expected observation before running the assertion or review.
- [ ] **UC-M09.03-C063-T07 · Violating fixture:** Create the source counterexample “A file is replaced immediately after its digest is checked” for “Verification-to-use binding”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M09.03-C063-T08 · Enforcement evidence:** Exercise the “Verification-to-use binding” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M09.03-C063-T09 · Regression linkage:** Link the “Verification-to-use binding” property to changes in approved dependency identities, mutable cache roots and executable handoff; record which dependency or contract changes require rerunning it.
- [ ] **UC-M09.03-C063-T10 · Property disposition:** Compare the satisfying and violating “Verification-to-use binding” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M09.03-C064 · Integration

**Original checklist item:** Integrate verification-to-use binding with approved dependency identities, mutable cache roots and executable handoff; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M09.03-C064-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Verification-to-use binding” across approved dependency identities, mutable cache roots and executable handoff; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M09.03-C064-T02 · Field mapping:** Map every “Verification-to-use binding” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M09.03-C064-T03 · Prerequisite identities:** Record the actual prerequisites for “Verification-to-use binding” (source dependency list: UC-M04.05, UC-M06.05, UC-M09.01); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M09.03-C064-T04 · Ownership agreement:** Specify who owns “Verification-to-use binding” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M09.03-C064-T05 · Handoff implementation:** Connect “Verification-to-use binding” through the mapped seam using the real adapter or explicit specification reference; preserve “Verified bytes and executed bytes correspond under the selected host mechanism” across the handoff.
- [ ] **UC-M09.03-C064-T06 · Absent-input case:** Omit one required “Verification-to-use binding” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M09.03-C064-T07 · Stale-input case:** Supply an outdated “Verification-to-use binding” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M09.03-C064-T08 · Incompatible-input case:** Supply an incompatible “Verification-to-use binding” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M09.03-C064-T09 · Valid integration trace:** Run a valid “Verification-to-use binding” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M09.03-C064-T10 · Seam review:** Reconcile the “Verification-to-use binding” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M09.03-C065 · Valid-case test

**Original checklist item:** Run a valid-path fixture for verification-to-use binding; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M09.03-C065-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Verification-to-use binding” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M09.03-C065-T02 · Expected-result oracle:** Specify the “Verification-to-use binding” expected result independently of the implementation output; include the property “Verified bytes and executed bytes correspond under the selected host mechanism” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M09.03-C065-T03 · Fixture material:** Create the concrete “Verification-to-use binding” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M09.03-C065-T04 · Target preparation:** Prepare the “Verification-to-use binding” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M09.03-C065-T05 · Initial-state record:** Record the initial “Verification-to-use binding” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M09.03-C065-T06 · Valid-path execution:** Execute the “Verification-to-use binding” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M09.03-C065-T07 · Outcome comparison:** Compare every declared “Verification-to-use binding” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M09.03-C065-T08 · State and bounds check:** Inspect the “Verification-to-use binding” ownership/state effects and actual use of “Handoff interval and concurrent replacement attempts”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M09.03-C065-T09 · Repeatability check:** Repeat the same “Verification-to-use binding” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M09.03-C065-T10 · Positive evidence:** Attach the “Verification-to-use binding” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M09.03-C066 · Negative test

**Original checklist item:** Negative case: A file is replaced immediately after its digest is checked. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M09.03-C066-T01 · Adverse-case definition:** Create a test record for the exact “Verification-to-use binding” source counterexample: “A file is replaced immediately after its digest is checked”; state which precondition or invariant it challenges.
- [ ] **UC-M09.03-C066-T02 · Safe fixture boundary:** Define the contained test boundary for “Verification-to-use binding”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M09.03-C066-T03 · Valid control:** Construct a valid “Verification-to-use binding” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M09.03-C066-T04 · Minimal adverse input:** Derive the “Verification-to-use binding” adverse fixture from the control with the smallest documented change needed to reproduce “A file is replaced immediately after its digest is checked”; retain that change as reproducible data.
- [ ] **UC-M09.03-C066-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Verification-to-use binding”; require “Verified bytes and executed bytes correspond under the selected host mechanism” and forbid a false-success verdict.
- [ ] **UC-M09.03-C066-T06 · Adverse execution:** Exercise the “Verification-to-use binding” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M09.03-C066-T07 · Effect inspection:** Inspect “Verification-to-use binding” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M09.03-C066-T08 · Refusal versus failure:** Confirm the “Verification-to-use binding” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M09.03-C066-T09 · Reset and retention:** Restore only the disposable “Verification-to-use binding” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M09.03-C066-T10 · Negative regression:** Register the “Verification-to-use binding” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M09.03-C067 · Change / failure test

**Original checklist item:** Exercise verification-to-use binding when a cached executable changes while its original hold archive remains intact; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M09.03-C067-T01 · Scenario record:** Write the “Verification-to-use binding” change/failure scenario exactly as supplied: a cached executable changes while its original hold archive remains intact; identify the property that must remain true: “Verified bytes and executed bytes correspond under the selected host mechanism”.
- [ ] **UC-M09.03-C067-T02 · Baseline capture:** Create a known-valid “Verification-to-use binding” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M09.03-C067-T03 · Injection map:** Locate the “Verification-to-use binding” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M09.03-C067-T04 · Disposition oracle:** Define the legal intermediate and final “Verification-to-use binding” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M09.03-C067-T05 · Controlled trigger:** Introduce the controlled “Verification-to-use binding” scenario in the disposable fixture: a cached executable changes while its original hold archive remains intact; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M09.03-C067-T06 · Intermediate inspection:** Inspect the “Verification-to-use binding” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M09.03-C067-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Verification-to-use binding”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M09.03-C067-T08 · Stale-evidence cleanup:** Invalidate superseded “Verification-to-use binding” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M09.03-C067-T09 · Repeat and compare:** Repeat the selected “Verification-to-use binding” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M09.03-C067-T10 · Failure evidence:** Publish the “Verification-to-use binding” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M09.03-C068 · Bounds

**Original checklist item:** Choose, document and test limits for handoff interval and concurrent replacement attempts; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M09.03-C068-T01 · Quantity inventory:** Create a measurement inventory for “Verification-to-use binding”: “Handoff interval and concurrent replacement attempts”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M09.03-C068-T02 · Measurement method:** Choose how to observe each “Verification-to-use binding” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M09.03-C068-T03 · Budget decision:** Select justified resource and input limits for “Verification-to-use binding”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M09.03-C068-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Verification-to-use binding” cases for “Handoff interval and concurrent replacement attempts”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M09.03-C068-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Verification-to-use binding” limit; preserve “Verified bytes and executed bytes correspond under the selected host mechanism”.
- [ ] **UC-M09.03-C068-T06 · Normal measurement:** Run or review the normal “Verification-to-use binding” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M09.03-C068-T07 · At-limit measurement:** Exercise the “Verification-to-use binding” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M09.03-C068-T08 · Over-limit measurement:** Exercise the “Verification-to-use binding” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M09.03-C068-T09 · Uncovered-scope report:** List the “Verification-to-use binding” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M09.03-C068-T10 · Limit evidence:** Publish the selected “Verification-to-use binding” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M09.03-C069 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for verification-to-use binding with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M09.03-C069-T01 · Event inventory:** List the “Verification-to-use binding” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M09.03-C069-T02 · Diagnostic schema:** Define nonsecret fields for “Verification-to-use binding” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M09.03-C069-T03 · Failure mapping:** Map each documented “Verification-to-use binding” refusal or error to a diagnostic outcome; include “A file is replaced immediately after its digest is checked” and prohibit conversion into a success message.
- [ ] **UC-M09.03-C069-T04 · Emission path:** Add the “Verification-to-use binding” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M09.03-C069-T05 · Redaction check:** Test “Verification-to-use binding” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M09.03-C069-T06 · Output budget:** Set and exercise bounded “Verification-to-use binding” message size, rate and retention compatible with “Handoff interval and concurrent replacement attempts”; define truncation behavior that preserves the final reason.
- [ ] **UC-M09.03-C069-T07 · Success/refusal fixtures:** Capture “Verification-to-use binding” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M09.03-C069-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Verification-to-use binding” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M09.03-C069-T09 · Operator review:** Read the “Verification-to-use binding” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M09.03-C069-T10 · Diagnostic evidence:** Publish redacted “Verification-to-use binding” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M09.03-C070 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for verification-to-use binding; label unexecuted checks as untested.

- [ ] **UC-M09.03-C070-T01 · Evidence inventory:** List the “Verification-to-use binding” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M09.03-C070-T02 · Artifact references:** Record the exact “Verification-to-use binding” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M09.03-C070-T03 · Fixture references:** Attach the “Verification-to-use binding” fixture IDs, input identities and oracle definition; preserve the source counterexample “A file is replaced immediately after its digest is checked” as a distinct evidence case.
- [ ] **UC-M09.03-C070-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Verification-to-use binding”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M09.03-C070-T05 · Environment record:** Record the actual “Verification-to-use binding” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M09.03-C070-T06 · Expected versus observed:** Pair every “Verification-to-use binding” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M09.03-C070-T07 · Failure and limit records:** Attach “Verification-to-use binding” change/failure and bounds evidence where required; include uncovered “Handoff interval and concurrent replacement attempts” and unresolved violations of “Verified bytes and executed bytes correspond under the selected host mechanism”.
- [ ] **UC-M09.03-C070-T08 · Evidence hygiene:** Check the “Verification-to-use binding” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M09.03-C070-T09 · Reproduction review:** Have the “Verification-to-use binding” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M09.03-C070-T10 · Acceptance linkage:** Link the “Verification-to-use binding” evidence to its parent and UC-M09.03 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 08. Corruption response

**Source delivery:** Quarantine or refuse altered cache entries with clear invalidation reasons.

**Source invariant:** Verification failure cannot fall back to executing the suspect cache.

**Source negative case:** A digest mismatch is logged as a warning while execution continues.

**Source bounded quantities:** Quarantine bytes and retry count.

### UC-M09.03-C071 · Contract

**Original checklist item:** Specify corruption response inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M09.03-C071-T01 · Scope statement:** Draft the operation boundary for “Corruption response” within Verified executable-cache reads; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M09.03-C071-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Corruption response”; record each producer, representation and missing-value meaning.
- [ ] **UC-M09.03-C071-T03 · Output inventory:** List the outputs of “Corruption response” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M09.03-C071-T04 · Field dictionary:** Create a field-and-term dictionary for “Corruption response”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M09.03-C071-T05 · Prerequisite contract:** Map “Corruption response” to the source component prerequisites (UC-M04.05, UC-M06.05, UC-M09.01); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M09.03-C071-T06 · Authority map:** Identify who may produce, change and consume “Corruption response”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M09.03-C071-T07 · Invariant clause:** Add a normative clause for “Corruption response” that preserves “Verification failure cannot fall back to executing the suspect cache”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M09.03-C071-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Corruption response”; include the source counterexample “A digest mismatch is logged as a warning while execution continues” and the intended safe disposition.
- [ ] **UC-M09.03-C071-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Quarantine bytes and retry count” in the “Corruption response” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M09.03-C071-T10 · Contract review:** Review the “Corruption response” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M09.03-C072 · Delivery

**Original checklist item:** Quarantine or refuse altered cache entries with clear invalidation reasons.

- [ ] **UC-M09.03-C072-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Corruption response”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M09.03-C072-T02 · Change plan:** Break the source delivery for “Corruption response” into concrete edit targets and reviewable outputs; keep the UC-M09.03 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M09.03-C072-T03 · Core artifact:** Implement the smallest selected-profile change for “Corruption response” that realizes this source instruction: Quarantine or refuse altered cache entries with clear invalidation reasons.
- [ ] **UC-M09.03-C072-T04 · Concrete realization:** Trace “Corruption response” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M09.03-C072-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Corruption response” needed to preserve “Verification failure cannot fall back to executing the suspect cache”; record an enforcement gap where only a model exists.
- [ ] **UC-M09.03-C072-T06 · Dependency connection:** Connect the “Corruption response” implementation to approved dependency identities, mutable cache roots and executable handoff; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M09.03-C072-T07 · Resource behavior:** Account for “Quarantine bytes and retry count” in “Corruption response”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M09.03-C072-T08 · Delivery check:** Run the smallest real “Corruption response” path and its adverse fixture “A digest mismatch is logged as a warning while execution continues”; retain actual output, state effects and final disposition.
- [ ] **UC-M09.03-C072-T09 · Patch review:** Review the “Corruption response” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M09.03-C072-T10 · Delivery handoff:** Publish the “Corruption response” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M09.03-C073 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Verification failure cannot fall back to executing the suspect cache. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M09.03-C073-T01 · Named property:** Create a stable property/check name under this parent for “Corruption response”; copy its required invariant exactly: “Verification failure cannot fall back to executing the suspect cache”.
- [ ] **UC-M09.03-C073-T02 · Observable terms:** Define each term in the “Corruption response” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M09.03-C073-T03 · Precondition set:** List the preconditions under which “Verification failure cannot fall back to executing the suspect cache” must hold for “Corruption response”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M09.03-C073-T04 · Transition coverage:** Map the “Corruption response” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M09.03-C073-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Corruption response”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M09.03-C073-T06 · Satisfying fixture:** Create a concrete “Corruption response” case that satisfies “Verification failure cannot fall back to executing the suspect cache”; record its expected observation before running the assertion or review.
- [ ] **UC-M09.03-C073-T07 · Violating fixture:** Create the source counterexample “A digest mismatch is logged as a warning while execution continues” for “Corruption response”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M09.03-C073-T08 · Enforcement evidence:** Exercise the “Corruption response” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M09.03-C073-T09 · Regression linkage:** Link the “Corruption response” property to changes in approved dependency identities, mutable cache roots and executable handoff; record which dependency or contract changes require rerunning it.
- [ ] **UC-M09.03-C073-T10 · Property disposition:** Compare the satisfying and violating “Corruption response” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M09.03-C074 · Integration

**Original checklist item:** Integrate corruption response with approved dependency identities, mutable cache roots and executable handoff; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M09.03-C074-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Corruption response” across approved dependency identities, mutable cache roots and executable handoff; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M09.03-C074-T02 · Field mapping:** Map every “Corruption response” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M09.03-C074-T03 · Prerequisite identities:** Record the actual prerequisites for “Corruption response” (source dependency list: UC-M04.05, UC-M06.05, UC-M09.01); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M09.03-C074-T04 · Ownership agreement:** Specify who owns “Corruption response” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M09.03-C074-T05 · Handoff implementation:** Connect “Corruption response” through the mapped seam using the real adapter or explicit specification reference; preserve “Verification failure cannot fall back to executing the suspect cache” across the handoff.
- [ ] **UC-M09.03-C074-T06 · Absent-input case:** Omit one required “Corruption response” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M09.03-C074-T07 · Stale-input case:** Supply an outdated “Corruption response” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M09.03-C074-T08 · Incompatible-input case:** Supply an incompatible “Corruption response” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M09.03-C074-T09 · Valid integration trace:** Run a valid “Corruption response” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M09.03-C074-T10 · Seam review:** Reconcile the “Corruption response” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M09.03-C075 · Valid-case test

**Original checklist item:** Run a valid-path fixture for corruption response; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M09.03-C075-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Corruption response” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M09.03-C075-T02 · Expected-result oracle:** Specify the “Corruption response” expected result independently of the implementation output; include the property “Verification failure cannot fall back to executing the suspect cache” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M09.03-C075-T03 · Fixture material:** Create the concrete “Corruption response” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M09.03-C075-T04 · Target preparation:** Prepare the “Corruption response” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M09.03-C075-T05 · Initial-state record:** Record the initial “Corruption response” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M09.03-C075-T06 · Valid-path execution:** Execute the “Corruption response” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M09.03-C075-T07 · Outcome comparison:** Compare every declared “Corruption response” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M09.03-C075-T08 · State and bounds check:** Inspect the “Corruption response” ownership/state effects and actual use of “Quarantine bytes and retry count”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M09.03-C075-T09 · Repeatability check:** Repeat the same “Corruption response” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M09.03-C075-T10 · Positive evidence:** Attach the “Corruption response” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M09.03-C076 · Negative test

**Original checklist item:** Negative case: A digest mismatch is logged as a warning while execution continues. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M09.03-C076-T01 · Adverse-case definition:** Create a test record for the exact “Corruption response” source counterexample: “A digest mismatch is logged as a warning while execution continues”; state which precondition or invariant it challenges.
- [ ] **UC-M09.03-C076-T02 · Safe fixture boundary:** Define the contained test boundary for “Corruption response”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M09.03-C076-T03 · Valid control:** Construct a valid “Corruption response” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M09.03-C076-T04 · Minimal adverse input:** Derive the “Corruption response” adverse fixture from the control with the smallest documented change needed to reproduce “A digest mismatch is logged as a warning while execution continues”; retain that change as reproducible data.
- [ ] **UC-M09.03-C076-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Corruption response”; require “Verification failure cannot fall back to executing the suspect cache” and forbid a false-success verdict.
- [ ] **UC-M09.03-C076-T06 · Adverse execution:** Exercise the “Corruption response” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M09.03-C076-T07 · Effect inspection:** Inspect “Corruption response” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M09.03-C076-T08 · Refusal versus failure:** Confirm the “Corruption response” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M09.03-C076-T09 · Reset and retention:** Restore only the disposable “Corruption response” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M09.03-C076-T10 · Negative regression:** Register the “Corruption response” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M09.03-C077 · Change / failure test

**Original checklist item:** Exercise corruption response when a cached executable changes while its original hold archive remains intact; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M09.03-C077-T01 · Scenario record:** Write the “Corruption response” change/failure scenario exactly as supplied: a cached executable changes while its original hold archive remains intact; identify the property that must remain true: “Verification failure cannot fall back to executing the suspect cache”.
- [ ] **UC-M09.03-C077-T02 · Baseline capture:** Create a known-valid “Corruption response” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M09.03-C077-T03 · Injection map:** Locate the “Corruption response” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M09.03-C077-T04 · Disposition oracle:** Define the legal intermediate and final “Corruption response” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M09.03-C077-T05 · Controlled trigger:** Introduce the controlled “Corruption response” scenario in the disposable fixture: a cached executable changes while its original hold archive remains intact; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M09.03-C077-T06 · Intermediate inspection:** Inspect the “Corruption response” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M09.03-C077-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Corruption response”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M09.03-C077-T08 · Stale-evidence cleanup:** Invalidate superseded “Corruption response” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M09.03-C077-T09 · Repeat and compare:** Repeat the selected “Corruption response” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M09.03-C077-T10 · Failure evidence:** Publish the “Corruption response” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M09.03-C078 · Bounds

**Original checklist item:** Choose, document and test limits for quarantine bytes and retry count; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M09.03-C078-T01 · Quantity inventory:** Create a measurement inventory for “Corruption response”: “Quarantine bytes and retry count”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M09.03-C078-T02 · Measurement method:** Choose how to observe each “Corruption response” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M09.03-C078-T03 · Budget decision:** Select justified resource and input limits for “Corruption response”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M09.03-C078-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Corruption response” cases for “Quarantine bytes and retry count”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M09.03-C078-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Corruption response” limit; preserve “Verification failure cannot fall back to executing the suspect cache”.
- [ ] **UC-M09.03-C078-T06 · Normal measurement:** Run or review the normal “Corruption response” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M09.03-C078-T07 · At-limit measurement:** Exercise the “Corruption response” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M09.03-C078-T08 · Over-limit measurement:** Exercise the “Corruption response” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M09.03-C078-T09 · Uncovered-scope report:** List the “Corruption response” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M09.03-C078-T10 · Limit evidence:** Publish the selected “Corruption response” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M09.03-C079 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for corruption response with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M09.03-C079-T01 · Event inventory:** List the “Corruption response” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M09.03-C079-T02 · Diagnostic schema:** Define nonsecret fields for “Corruption response” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M09.03-C079-T03 · Failure mapping:** Map each documented “Corruption response” refusal or error to a diagnostic outcome; include “A digest mismatch is logged as a warning while execution continues” and prohibit conversion into a success message.
- [ ] **UC-M09.03-C079-T04 · Emission path:** Add the “Corruption response” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M09.03-C079-T05 · Redaction check:** Test “Corruption response” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M09.03-C079-T06 · Output budget:** Set and exercise bounded “Corruption response” message size, rate and retention compatible with “Quarantine bytes and retry count”; define truncation behavior that preserves the final reason.
- [ ] **UC-M09.03-C079-T07 · Success/refusal fixtures:** Capture “Corruption response” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M09.03-C079-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Corruption response” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M09.03-C079-T09 · Operator review:** Read the “Corruption response” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M09.03-C079-T10 · Diagnostic evidence:** Publish redacted “Corruption response” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M09.03-C080 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for corruption response; label unexecuted checks as untested.

- [ ] **UC-M09.03-C080-T01 · Evidence inventory:** List the “Corruption response” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M09.03-C080-T02 · Artifact references:** Record the exact “Corruption response” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M09.03-C080-T03 · Fixture references:** Attach the “Corruption response” fixture IDs, input identities and oracle definition; preserve the source counterexample “A digest mismatch is logged as a warning while execution continues” as a distinct evidence case.
- [ ] **UC-M09.03-C080-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Corruption response”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M09.03-C080-T05 · Environment record:** Record the actual “Corruption response” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M09.03-C080-T06 · Expected versus observed:** Pair every “Corruption response” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M09.03-C080-T07 · Failure and limit records:** Attach “Corruption response” change/failure and bounds evidence where required; include uncovered “Quarantine bytes and retry count” and unresolved violations of “Verification failure cannot fall back to executing the suspect cache”.
- [ ] **UC-M09.03-C080-T08 · Evidence hygiene:** Check the “Corruption response” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M09.03-C080-T09 · Reproduction review:** Have the “Corruption response” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M09.03-C080-T10 · Acceptance linkage:** Link the “Corruption response” evidence to its parent and UC-M09.03 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 09. Cache rebuild path

**Source delivery:** Rebuild refused entries only from approved locked inputs through the admitted build process.

**Source invariant:** Repair cannot download or execute an unapproved substitute silently.

**Source negative case:** Cache recovery fetches a similarly named unpinned runtime.

**Source bounded quantities:** Rebuild resources and dependency closure size.

### UC-M09.03-C081 · Contract

**Original checklist item:** Specify cache rebuild path inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M09.03-C081-T01 · Scope statement:** Draft the operation boundary for “Cache rebuild path” within Verified executable-cache reads; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M09.03-C081-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Cache rebuild path”; record each producer, representation and missing-value meaning.
- [ ] **UC-M09.03-C081-T03 · Output inventory:** List the outputs of “Cache rebuild path” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M09.03-C081-T04 · Field dictionary:** Create a field-and-term dictionary for “Cache rebuild path”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M09.03-C081-T05 · Prerequisite contract:** Map “Cache rebuild path” to the source component prerequisites (UC-M04.05, UC-M06.05, UC-M09.01); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M09.03-C081-T06 · Authority map:** Identify who may produce, change and consume “Cache rebuild path”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M09.03-C081-T07 · Invariant clause:** Add a normative clause for “Cache rebuild path” that preserves “Repair cannot download or execute an unapproved substitute silently”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M09.03-C081-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Cache rebuild path”; include the source counterexample “Cache recovery fetches a similarly named unpinned runtime” and the intended safe disposition.
- [ ] **UC-M09.03-C081-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Rebuild resources and dependency closure size” in the “Cache rebuild path” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M09.03-C081-T10 · Contract review:** Review the “Cache rebuild path” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M09.03-C082 · Delivery

**Original checklist item:** Rebuild refused entries only from approved locked inputs through the admitted build process.

- [ ] **UC-M09.03-C082-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Cache rebuild path”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M09.03-C082-T02 · Change plan:** Break the source delivery for “Cache rebuild path” into concrete edit targets and reviewable outputs; keep the UC-M09.03 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M09.03-C082-T03 · Core artifact:** Implement the smallest selected-profile change for “Cache rebuild path” that realizes this source instruction: Rebuild refused entries only from approved locked inputs through the admitted build process.
- [ ] **UC-M09.03-C082-T04 · Concrete realization:** Trace “Cache rebuild path” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M09.03-C082-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Cache rebuild path” needed to preserve “Repair cannot download or execute an unapproved substitute silently”; record an enforcement gap where only a model exists.
- [ ] **UC-M09.03-C082-T06 · Dependency connection:** Connect the “Cache rebuild path” implementation to approved dependency identities, mutable cache roots and executable handoff; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M09.03-C082-T07 · Resource behavior:** Account for “Rebuild resources and dependency closure size” in “Cache rebuild path”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M09.03-C082-T08 · Delivery check:** Run the smallest real “Cache rebuild path” path and its adverse fixture “Cache recovery fetches a similarly named unpinned runtime”; retain actual output, state effects and final disposition.
- [ ] **UC-M09.03-C082-T09 · Patch review:** Review the “Cache rebuild path” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M09.03-C082-T10 · Delivery handoff:** Publish the “Cache rebuild path” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M09.03-C083 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Repair cannot download or execute an unapproved substitute silently. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M09.03-C083-T01 · Named property:** Create a stable property/check name under this parent for “Cache rebuild path”; copy its required invariant exactly: “Repair cannot download or execute an unapproved substitute silently”.
- [ ] **UC-M09.03-C083-T02 · Observable terms:** Define each term in the “Cache rebuild path” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M09.03-C083-T03 · Precondition set:** List the preconditions under which “Repair cannot download or execute an unapproved substitute silently” must hold for “Cache rebuild path”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M09.03-C083-T04 · Transition coverage:** Map the “Cache rebuild path” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M09.03-C083-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Cache rebuild path”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M09.03-C083-T06 · Satisfying fixture:** Create a concrete “Cache rebuild path” case that satisfies “Repair cannot download or execute an unapproved substitute silently”; record its expected observation before running the assertion or review.
- [ ] **UC-M09.03-C083-T07 · Violating fixture:** Create the source counterexample “Cache recovery fetches a similarly named unpinned runtime” for “Cache rebuild path”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M09.03-C083-T08 · Enforcement evidence:** Exercise the “Cache rebuild path” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M09.03-C083-T09 · Regression linkage:** Link the “Cache rebuild path” property to changes in approved dependency identities, mutable cache roots and executable handoff; record which dependency or contract changes require rerunning it.
- [ ] **UC-M09.03-C083-T10 · Property disposition:** Compare the satisfying and violating “Cache rebuild path” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M09.03-C084 · Integration

**Original checklist item:** Integrate cache rebuild path with approved dependency identities, mutable cache roots and executable handoff; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M09.03-C084-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Cache rebuild path” across approved dependency identities, mutable cache roots and executable handoff; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M09.03-C084-T02 · Field mapping:** Map every “Cache rebuild path” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M09.03-C084-T03 · Prerequisite identities:** Record the actual prerequisites for “Cache rebuild path” (source dependency list: UC-M04.05, UC-M06.05, UC-M09.01); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M09.03-C084-T04 · Ownership agreement:** Specify who owns “Cache rebuild path” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M09.03-C084-T05 · Handoff implementation:** Connect “Cache rebuild path” through the mapped seam using the real adapter or explicit specification reference; preserve “Repair cannot download or execute an unapproved substitute silently” across the handoff.
- [ ] **UC-M09.03-C084-T06 · Absent-input case:** Omit one required “Cache rebuild path” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M09.03-C084-T07 · Stale-input case:** Supply an outdated “Cache rebuild path” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M09.03-C084-T08 · Incompatible-input case:** Supply an incompatible “Cache rebuild path” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M09.03-C084-T09 · Valid integration trace:** Run a valid “Cache rebuild path” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M09.03-C084-T10 · Seam review:** Reconcile the “Cache rebuild path” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M09.03-C085 · Valid-case test

**Original checklist item:** Run a valid-path fixture for cache rebuild path; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M09.03-C085-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Cache rebuild path” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M09.03-C085-T02 · Expected-result oracle:** Specify the “Cache rebuild path” expected result independently of the implementation output; include the property “Repair cannot download or execute an unapproved substitute silently” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M09.03-C085-T03 · Fixture material:** Create the concrete “Cache rebuild path” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M09.03-C085-T04 · Target preparation:** Prepare the “Cache rebuild path” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M09.03-C085-T05 · Initial-state record:** Record the initial “Cache rebuild path” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M09.03-C085-T06 · Valid-path execution:** Execute the “Cache rebuild path” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M09.03-C085-T07 · Outcome comparison:** Compare every declared “Cache rebuild path” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M09.03-C085-T08 · State and bounds check:** Inspect the “Cache rebuild path” ownership/state effects and actual use of “Rebuild resources and dependency closure size”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M09.03-C085-T09 · Repeatability check:** Repeat the same “Cache rebuild path” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M09.03-C085-T10 · Positive evidence:** Attach the “Cache rebuild path” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M09.03-C086 · Negative test

**Original checklist item:** Negative case: Cache recovery fetches a similarly named unpinned runtime. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M09.03-C086-T01 · Adverse-case definition:** Create a test record for the exact “Cache rebuild path” source counterexample: “Cache recovery fetches a similarly named unpinned runtime”; state which precondition or invariant it challenges.
- [ ] **UC-M09.03-C086-T02 · Safe fixture boundary:** Define the contained test boundary for “Cache rebuild path”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M09.03-C086-T03 · Valid control:** Construct a valid “Cache rebuild path” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M09.03-C086-T04 · Minimal adverse input:** Derive the “Cache rebuild path” adverse fixture from the control with the smallest documented change needed to reproduce “Cache recovery fetches a similarly named unpinned runtime”; retain that change as reproducible data.
- [ ] **UC-M09.03-C086-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Cache rebuild path”; require “Repair cannot download or execute an unapproved substitute silently” and forbid a false-success verdict.
- [ ] **UC-M09.03-C086-T06 · Adverse execution:** Exercise the “Cache rebuild path” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M09.03-C086-T07 · Effect inspection:** Inspect “Cache rebuild path” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M09.03-C086-T08 · Refusal versus failure:** Confirm the “Cache rebuild path” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M09.03-C086-T09 · Reset and retention:** Restore only the disposable “Cache rebuild path” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M09.03-C086-T10 · Negative regression:** Register the “Cache rebuild path” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M09.03-C087 · Change / failure test

**Original checklist item:** Exercise cache rebuild path when a cached executable changes while its original hold archive remains intact; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M09.03-C087-T01 · Scenario record:** Write the “Cache rebuild path” change/failure scenario exactly as supplied: a cached executable changes while its original hold archive remains intact; identify the property that must remain true: “Repair cannot download or execute an unapproved substitute silently”.
- [ ] **UC-M09.03-C087-T02 · Baseline capture:** Create a known-valid “Cache rebuild path” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M09.03-C087-T03 · Injection map:** Locate the “Cache rebuild path” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M09.03-C087-T04 · Disposition oracle:** Define the legal intermediate and final “Cache rebuild path” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M09.03-C087-T05 · Controlled trigger:** Introduce the controlled “Cache rebuild path” scenario in the disposable fixture: a cached executable changes while its original hold archive remains intact; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M09.03-C087-T06 · Intermediate inspection:** Inspect the “Cache rebuild path” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M09.03-C087-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Cache rebuild path”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M09.03-C087-T08 · Stale-evidence cleanup:** Invalidate superseded “Cache rebuild path” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M09.03-C087-T09 · Repeat and compare:** Repeat the selected “Cache rebuild path” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M09.03-C087-T10 · Failure evidence:** Publish the “Cache rebuild path” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M09.03-C088 · Bounds

**Original checklist item:** Choose, document and test limits for rebuild resources and dependency closure size; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M09.03-C088-T01 · Quantity inventory:** Create a measurement inventory for “Cache rebuild path”: “Rebuild resources and dependency closure size”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M09.03-C088-T02 · Measurement method:** Choose how to observe each “Cache rebuild path” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M09.03-C088-T03 · Budget decision:** Select justified resource and input limits for “Cache rebuild path”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M09.03-C088-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Cache rebuild path” cases for “Rebuild resources and dependency closure size”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M09.03-C088-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Cache rebuild path” limit; preserve “Repair cannot download or execute an unapproved substitute silently”.
- [ ] **UC-M09.03-C088-T06 · Normal measurement:** Run or review the normal “Cache rebuild path” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M09.03-C088-T07 · At-limit measurement:** Exercise the “Cache rebuild path” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M09.03-C088-T08 · Over-limit measurement:** Exercise the “Cache rebuild path” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M09.03-C088-T09 · Uncovered-scope report:** List the “Cache rebuild path” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M09.03-C088-T10 · Limit evidence:** Publish the selected “Cache rebuild path” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M09.03-C089 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for cache rebuild path with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M09.03-C089-T01 · Event inventory:** List the “Cache rebuild path” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M09.03-C089-T02 · Diagnostic schema:** Define nonsecret fields for “Cache rebuild path” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M09.03-C089-T03 · Failure mapping:** Map each documented “Cache rebuild path” refusal or error to a diagnostic outcome; include “Cache recovery fetches a similarly named unpinned runtime” and prohibit conversion into a success message.
- [ ] **UC-M09.03-C089-T04 · Emission path:** Add the “Cache rebuild path” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M09.03-C089-T05 · Redaction check:** Test “Cache rebuild path” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M09.03-C089-T06 · Output budget:** Set and exercise bounded “Cache rebuild path” message size, rate and retention compatible with “Rebuild resources and dependency closure size”; define truncation behavior that preserves the final reason.
- [ ] **UC-M09.03-C089-T07 · Success/refusal fixtures:** Capture “Cache rebuild path” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M09.03-C089-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Cache rebuild path” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M09.03-C089-T09 · Operator review:** Read the “Cache rebuild path” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M09.03-C089-T10 · Diagnostic evidence:** Publish redacted “Cache rebuild path” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M09.03-C090 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for cache rebuild path; label unexecuted checks as untested.

- [ ] **UC-M09.03-C090-T01 · Evidence inventory:** List the “Cache rebuild path” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M09.03-C090-T02 · Artifact references:** Record the exact “Cache rebuild path” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M09.03-C090-T03 · Fixture references:** Attach the “Cache rebuild path” fixture IDs, input identities and oracle definition; preserve the source counterexample “Cache recovery fetches a similarly named unpinned runtime” as a distinct evidence case.
- [ ] **UC-M09.03-C090-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Cache rebuild path”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M09.03-C090-T05 · Environment record:** Record the actual “Cache rebuild path” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M09.03-C090-T06 · Expected versus observed:** Pair every “Cache rebuild path” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M09.03-C090-T07 · Failure and limit records:** Attach “Cache rebuild path” change/failure and bounds evidence where required; include uncovered “Rebuild resources and dependency closure size” and unresolved violations of “Repair cannot download or execute an unapproved substitute silently”.
- [ ] **UC-M09.03-C090-T08 · Evidence hygiene:** Check the “Cache rebuild path” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M09.03-C090-T09 · Reproduction review:** Have the “Cache rebuild path” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M09.03-C090-T10 · Acceptance linkage:** Link the “Cache rebuild path” evidence to its parent and UC-M09.03 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 10. Cache tamper qualification

**Source delivery:** Modify adapters, source and binaries independently while retaining original archive pins.

**Source invariant:** Each executable mutation blocks use at its required trust boundary.

**Source negative case:** A cached binary alteration is missed because only hold pins are checked.

**Source bounded quantities:** Tamper fixtures and verification repetitions.

### UC-M09.03-C091 · Contract

**Original checklist item:** Specify cache tamper qualification inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M09.03-C091-T01 · Scope statement:** Draft the operation boundary for “Cache tamper qualification” within Verified executable-cache reads; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M09.03-C091-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Cache tamper qualification”; record each producer, representation and missing-value meaning.
- [ ] **UC-M09.03-C091-T03 · Output inventory:** List the outputs of “Cache tamper qualification” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M09.03-C091-T04 · Field dictionary:** Create a field-and-term dictionary for “Cache tamper qualification”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M09.03-C091-T05 · Prerequisite contract:** Map “Cache tamper qualification” to the source component prerequisites (UC-M04.05, UC-M06.05, UC-M09.01); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M09.03-C091-T06 · Authority map:** Identify who may produce, change and consume “Cache tamper qualification”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M09.03-C091-T07 · Invariant clause:** Add a normative clause for “Cache tamper qualification” that preserves “Each executable mutation blocks use at its required trust boundary”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M09.03-C091-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Cache tamper qualification”; include the source counterexample “A cached binary alteration is missed because only hold pins are checked” and the intended safe disposition.
- [ ] **UC-M09.03-C091-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Tamper fixtures and verification repetitions” in the “Cache tamper qualification” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M09.03-C091-T10 · Contract review:** Review the “Cache tamper qualification” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M09.03-C092 · Delivery

**Original checklist item:** Modify adapters, source and binaries independently while retaining original archive pins.

- [ ] **UC-M09.03-C092-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Cache tamper qualification”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M09.03-C092-T02 · Change plan:** Break the source delivery for “Cache tamper qualification” into concrete edit targets and reviewable outputs; keep the UC-M09.03 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M09.03-C092-T03 · Core artifact:** Implement the smallest selected-profile change for “Cache tamper qualification” that realizes this source instruction: Modify adapters, source and binaries independently while retaining original archive pins.
- [ ] **UC-M09.03-C092-T04 · Concrete realization:** Trace “Cache tamper qualification” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M09.03-C092-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Cache tamper qualification” needed to preserve “Each executable mutation blocks use at its required trust boundary”; record an enforcement gap where only a model exists.
- [ ] **UC-M09.03-C092-T06 · Dependency connection:** Connect the “Cache tamper qualification” implementation to approved dependency identities, mutable cache roots and executable handoff; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M09.03-C092-T07 · Resource behavior:** Account for “Tamper fixtures and verification repetitions” in “Cache tamper qualification”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M09.03-C092-T08 · Delivery check:** Run the smallest real “Cache tamper qualification” path and its adverse fixture “A cached binary alteration is missed because only hold pins are checked”; retain actual output, state effects and final disposition.
- [ ] **UC-M09.03-C092-T09 · Patch review:** Review the “Cache tamper qualification” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M09.03-C092-T10 · Delivery handoff:** Publish the “Cache tamper qualification” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M09.03-C093 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Each executable mutation blocks use at its required trust boundary. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M09.03-C093-T01 · Named property:** Create a stable property/check name under this parent for “Cache tamper qualification”; copy its required invariant exactly: “Each executable mutation blocks use at its required trust boundary”.
- [ ] **UC-M09.03-C093-T02 · Observable terms:** Define each term in the “Cache tamper qualification” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M09.03-C093-T03 · Precondition set:** List the preconditions under which “Each executable mutation blocks use at its required trust boundary” must hold for “Cache tamper qualification”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M09.03-C093-T04 · Transition coverage:** Map the “Cache tamper qualification” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M09.03-C093-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Cache tamper qualification”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M09.03-C093-T06 · Satisfying fixture:** Create a concrete “Cache tamper qualification” case that satisfies “Each executable mutation blocks use at its required trust boundary”; record its expected observation before running the assertion or review.
- [ ] **UC-M09.03-C093-T07 · Violating fixture:** Create the source counterexample “A cached binary alteration is missed because only hold pins are checked” for “Cache tamper qualification”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M09.03-C093-T08 · Enforcement evidence:** Exercise the “Cache tamper qualification” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M09.03-C093-T09 · Regression linkage:** Link the “Cache tamper qualification” property to changes in approved dependency identities, mutable cache roots and executable handoff; record which dependency or contract changes require rerunning it.
- [ ] **UC-M09.03-C093-T10 · Property disposition:** Compare the satisfying and violating “Cache tamper qualification” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M09.03-C094 · Integration

**Original checklist item:** Integrate cache tamper qualification with approved dependency identities, mutable cache roots and executable handoff; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M09.03-C094-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Cache tamper qualification” across approved dependency identities, mutable cache roots and executable handoff; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M09.03-C094-T02 · Field mapping:** Map every “Cache tamper qualification” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M09.03-C094-T03 · Prerequisite identities:** Record the actual prerequisites for “Cache tamper qualification” (source dependency list: UC-M04.05, UC-M06.05, UC-M09.01); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M09.03-C094-T04 · Ownership agreement:** Specify who owns “Cache tamper qualification” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M09.03-C094-T05 · Handoff implementation:** Connect “Cache tamper qualification” through the mapped seam using the real adapter or explicit specification reference; preserve “Each executable mutation blocks use at its required trust boundary” across the handoff.
- [ ] **UC-M09.03-C094-T06 · Absent-input case:** Omit one required “Cache tamper qualification” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M09.03-C094-T07 · Stale-input case:** Supply an outdated “Cache tamper qualification” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M09.03-C094-T08 · Incompatible-input case:** Supply an incompatible “Cache tamper qualification” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M09.03-C094-T09 · Valid integration trace:** Run a valid “Cache tamper qualification” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M09.03-C094-T10 · Seam review:** Reconcile the “Cache tamper qualification” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M09.03-C095 · Valid-case test

**Original checklist item:** Run a valid-path fixture for cache tamper qualification; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M09.03-C095-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Cache tamper qualification” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M09.03-C095-T02 · Expected-result oracle:** Specify the “Cache tamper qualification” expected result independently of the implementation output; include the property “Each executable mutation blocks use at its required trust boundary” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M09.03-C095-T03 · Fixture material:** Create the concrete “Cache tamper qualification” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M09.03-C095-T04 · Target preparation:** Prepare the “Cache tamper qualification” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M09.03-C095-T05 · Initial-state record:** Record the initial “Cache tamper qualification” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M09.03-C095-T06 · Valid-path execution:** Execute the “Cache tamper qualification” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M09.03-C095-T07 · Outcome comparison:** Compare every declared “Cache tamper qualification” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M09.03-C095-T08 · State and bounds check:** Inspect the “Cache tamper qualification” ownership/state effects and actual use of “Tamper fixtures and verification repetitions”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M09.03-C095-T09 · Repeatability check:** Repeat the same “Cache tamper qualification” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M09.03-C095-T10 · Positive evidence:** Attach the “Cache tamper qualification” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M09.03-C096 · Negative test

**Original checklist item:** Negative case: A cached binary alteration is missed because only hold pins are checked. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M09.03-C096-T01 · Adverse-case definition:** Create a test record for the exact “Cache tamper qualification” source counterexample: “A cached binary alteration is missed because only hold pins are checked”; state which precondition or invariant it challenges.
- [ ] **UC-M09.03-C096-T02 · Safe fixture boundary:** Define the contained test boundary for “Cache tamper qualification”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M09.03-C096-T03 · Valid control:** Construct a valid “Cache tamper qualification” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M09.03-C096-T04 · Minimal adverse input:** Derive the “Cache tamper qualification” adverse fixture from the control with the smallest documented change needed to reproduce “A cached binary alteration is missed because only hold pins are checked”; retain that change as reproducible data.
- [ ] **UC-M09.03-C096-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Cache tamper qualification”; require “Each executable mutation blocks use at its required trust boundary” and forbid a false-success verdict.
- [ ] **UC-M09.03-C096-T06 · Adverse execution:** Exercise the “Cache tamper qualification” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M09.03-C096-T07 · Effect inspection:** Inspect “Cache tamper qualification” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M09.03-C096-T08 · Refusal versus failure:** Confirm the “Cache tamper qualification” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M09.03-C096-T09 · Reset and retention:** Restore only the disposable “Cache tamper qualification” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M09.03-C096-T10 · Negative regression:** Register the “Cache tamper qualification” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M09.03-C097 · Change / failure test

**Original checklist item:** Exercise cache tamper qualification when a cached executable changes while its original hold archive remains intact; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M09.03-C097-T01 · Scenario record:** Write the “Cache tamper qualification” change/failure scenario exactly as supplied: a cached executable changes while its original hold archive remains intact; identify the property that must remain true: “Each executable mutation blocks use at its required trust boundary”.
- [ ] **UC-M09.03-C097-T02 · Baseline capture:** Create a known-valid “Cache tamper qualification” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M09.03-C097-T03 · Injection map:** Locate the “Cache tamper qualification” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M09.03-C097-T04 · Disposition oracle:** Define the legal intermediate and final “Cache tamper qualification” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M09.03-C097-T05 · Controlled trigger:** Introduce the controlled “Cache tamper qualification” scenario in the disposable fixture: a cached executable changes while its original hold archive remains intact; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M09.03-C097-T06 · Intermediate inspection:** Inspect the “Cache tamper qualification” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M09.03-C097-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Cache tamper qualification”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M09.03-C097-T08 · Stale-evidence cleanup:** Invalidate superseded “Cache tamper qualification” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M09.03-C097-T09 · Repeat and compare:** Repeat the selected “Cache tamper qualification” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M09.03-C097-T10 · Failure evidence:** Publish the “Cache tamper qualification” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M09.03-C098 · Bounds

**Original checklist item:** Choose, document and test limits for tamper fixtures and verification repetitions; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M09.03-C098-T01 · Quantity inventory:** Create a measurement inventory for “Cache tamper qualification”: “Tamper fixtures and verification repetitions”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M09.03-C098-T02 · Measurement method:** Choose how to observe each “Cache tamper qualification” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M09.03-C098-T03 · Budget decision:** Select justified resource and input limits for “Cache tamper qualification”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M09.03-C098-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Cache tamper qualification” cases for “Tamper fixtures and verification repetitions”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M09.03-C098-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Cache tamper qualification” limit; preserve “Each executable mutation blocks use at its required trust boundary”.
- [ ] **UC-M09.03-C098-T06 · Normal measurement:** Run or review the normal “Cache tamper qualification” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M09.03-C098-T07 · At-limit measurement:** Exercise the “Cache tamper qualification” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M09.03-C098-T08 · Over-limit measurement:** Exercise the “Cache tamper qualification” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M09.03-C098-T09 · Uncovered-scope report:** List the “Cache tamper qualification” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M09.03-C098-T10 · Limit evidence:** Publish the selected “Cache tamper qualification” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M09.03-C099 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for cache tamper qualification with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M09.03-C099-T01 · Event inventory:** List the “Cache tamper qualification” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M09.03-C099-T02 · Diagnostic schema:** Define nonsecret fields for “Cache tamper qualification” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M09.03-C099-T03 · Failure mapping:** Map each documented “Cache tamper qualification” refusal or error to a diagnostic outcome; include “A cached binary alteration is missed because only hold pins are checked” and prohibit conversion into a success message.
- [ ] **UC-M09.03-C099-T04 · Emission path:** Add the “Cache tamper qualification” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M09.03-C099-T05 · Redaction check:** Test “Cache tamper qualification” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M09.03-C099-T06 · Output budget:** Set and exercise bounded “Cache tamper qualification” message size, rate and retention compatible with “Tamper fixtures and verification repetitions”; define truncation behavior that preserves the final reason.
- [ ] **UC-M09.03-C099-T07 · Success/refusal fixtures:** Capture “Cache tamper qualification” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M09.03-C099-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Cache tamper qualification” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M09.03-C099-T09 · Operator review:** Read the “Cache tamper qualification” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M09.03-C099-T10 · Diagnostic evidence:** Publish redacted “Cache tamper qualification” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M09.03-C100 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for cache tamper qualification; label unexecuted checks as untested.

- [ ] **UC-M09.03-C100-T01 · Evidence inventory:** List the “Cache tamper qualification” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M09.03-C100-T02 · Artifact references:** Record the exact “Cache tamper qualification” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M09.03-C100-T03 · Fixture references:** Attach the “Cache tamper qualification” fixture IDs, input identities and oracle definition; preserve the source counterexample “A cached binary alteration is missed because only hold pins are checked” as a distinct evidence case.
- [ ] **UC-M09.03-C100-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Cache tamper qualification”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M09.03-C100-T05 · Environment record:** Record the actual “Cache tamper qualification” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M09.03-C100-T06 · Expected versus observed:** Pair every “Cache tamper qualification” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M09.03-C100-T07 · Failure and limit records:** Attach “Cache tamper qualification” change/failure and bounds evidence where required; include uncovered “Tamper fixtures and verification repetitions” and unresolved violations of “Each executable mutation blocks use at its required trust boundary”.
- [ ] **UC-M09.03-C100-T08 · Evidence hygiene:** Check the “Cache tamper qualification” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M09.03-C100-T09 · Reproduction review:** Have the “Cache tamper qualification” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M09.03-C100-T10 · Acceptance linkage:** Link the “Cache tamper qualification” evidence to its parent and UC-M09.03 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

