# UC-M01.04 — Canonical manifest and schema evolution

**To-Do Pack 2.0.0 · Baseline UC-2.2.0 · 100 parent checks × 10 subtasks = 1,000 to-dos**

[Master index](../../INDEX.md) · [Workstream index](../../w/01.md)

| Field | Preserved source value |
|---|---|
| Workstream | 01. Architecture and executable contracts |
| Milestone | A |
| Priority | P0 |
| Source assessment | PARTIAL |
| Scope | core or selected profile |
| Dependencies | [UC-M01.02](../01/UC-M01.02.md) |
| Source checklist pack | 1.0.0 |
| Original reference labels | [S1], [S3]. |

## Original requirement

Extend checksum parsing to duplicate-key-safe JSON, schema migration, canonical encoding and non-ambiguous field semantics.

**Original acceptance criterion:** Equivalent manifests hash consistently; malicious duplicates and lossy downgrade migrations are rejected.

**Source trace:** Original checklist `UC100/c/01/UC-M01.04.md` inside [s/checklists.zip](../../s/checklists.zip); exact parent records in [data/parents.jsonl](../../data/parents.jsonl). Original roadmap lines 82–92 are preserved in [s/roadmap.md](../../s/roadmap.md).

## How to use these lists

Every parent statement below is preserved verbatim. Its ten child tasks are proposed decomposition, not implemented capabilities or executed tests. Child IDs append `-T01` through `-T10` to the original parent ID. All begin unchecked / `TODO`. Design/review evidence does not establish runtime enforcement; observe the actual selected target where the parent requires it.

The source dependency graph and selected release profile determine applicability. The numbered child sequence is a local working order, not an added hard dependency graph. An unselected optional feature needs a recorded not-applicable rationale; missing prerequisites for selected work remain blockers. Numerical budgets, backends and trust mechanisms remain decisions unless fixed by the source. Test hostile cases only with synthetic inputs in authorized disposable environments.

## 01. Duplicate-safe parsing

**Source delivery:** Parse manifest objects with duplicate-key detection before schema conversion.

**Source invariant:** Duplicate keys cannot be silently overwritten.

**Source negative case:** A manifest repeats a policy field with conflicting values.

**Source bounded quantities:** Manifest bytes, object depth and key count.

### UC-M01.04-C001 · Contract

**Original checklist item:** Specify the scope and representation of duplicate-safe parsing; identify its producer, consumer, authority assumptions and explicitly unsupported cases.

- [ ] **UC-M01.04-C001-T01 · Scope statement:** Draft a scope note for “Duplicate-safe parsing” within Canonical manifest and schema evolution; separate required model statements, explicit exclusions and unresolved design decisions.
- [ ] **UC-M01.04-C001-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Duplicate-safe parsing”; record each producer, representation and missing-value meaning.
- [ ] **UC-M01.04-C001-T03 · Output inventory:** List the outputs of “Duplicate-safe parsing” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M01.04-C001-T04 · Field dictionary:** Create a field-and-term dictionary for “Duplicate-safe parsing”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M01.04-C001-T05 · Prerequisite contract:** Map “Duplicate-safe parsing” to the source component prerequisites (UC-M01.02); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M01.04-C001-T06 · Authority map:** Identify who may produce, change and consume “Duplicate-safe parsing”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M01.04-C001-T07 · Invariant clause:** Add a normative clause for “Duplicate-safe parsing” that preserves “Duplicate keys cannot be silently overwritten”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M01.04-C001-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Duplicate-safe parsing”; include the source counterexample “A manifest repeats a policy field with conflicting values” and the intended safe disposition.
- [ ] **UC-M01.04-C001-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Manifest bytes, object depth and key count” in the “Duplicate-safe parsing” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M01.04-C001-T10 · Contract review:** Review the “Duplicate-safe parsing” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M01.04-C002 · Delivery

**Original checklist item:** Parse manifest objects with duplicate-key detection before schema conversion.

- [ ] **UC-M01.04-C002-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Duplicate-safe parsing”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M01.04-C002-T02 · Change plan:** Break the source delivery for “Duplicate-safe parsing” into concrete edit targets and reviewable outputs; keep the UC-M01.04 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M01.04-C002-T03 · Core artifact:** Implement the smallest selected-profile change for “Duplicate-safe parsing” that realizes this source instruction: Parse manifest objects with duplicate-key detection before schema conversion.
- [ ] **UC-M01.04-C002-T04 · Concrete realization:** Trace “Duplicate-safe parsing” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M01.04-C002-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Duplicate-safe parsing” needed to preserve “Duplicate keys cannot be silently overwritten”; record an enforcement gap where only a model exists.
- [ ] **UC-M01.04-C002-T06 · Dependency connection:** Connect the “Duplicate-safe parsing” specification to manifest readers, canonical digest generation and schema migrations; record code coverage separately where the design is not yet enforced.
- [ ] **UC-M01.04-C002-T07 · Resource behavior:** Account for “Manifest bytes, object depth and key count” in “Duplicate-safe parsing”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M01.04-C002-T08 · Delivery check:** Walk the populated “Duplicate-safe parsing” model through a valid example and the source counterexample “A manifest repeats a policy field with conflicting values”; record corrections and unresolved enforcement gaps.
- [ ] **UC-M01.04-C002-T09 · Patch review:** Review the “Duplicate-safe parsing” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M01.04-C002-T10 · Delivery handoff:** Publish the “Duplicate-safe parsing” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M01.04-C003 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Duplicate keys cannot be silently overwritten. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M01.04-C003-T01 · Named property:** Create a stable property/check name under this parent for “Duplicate-safe parsing”; copy its required invariant exactly: “Duplicate keys cannot be silently overwritten”.
- [ ] **UC-M01.04-C003-T02 · Observable terms:** Define each term in the “Duplicate-safe parsing” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M01.04-C003-T03 · Precondition set:** List the preconditions under which “Duplicate keys cannot be silently overwritten” must hold for “Duplicate-safe parsing”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M01.04-C003-T04 · Transition coverage:** Map the “Duplicate-safe parsing” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M01.04-C003-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Duplicate-safe parsing”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M01.04-C003-T06 · Satisfying fixture:** Create a concrete “Duplicate-safe parsing” case that satisfies “Duplicate keys cannot be silently overwritten”; record its expected observation before running the assertion or review.
- [ ] **UC-M01.04-C003-T07 · Violating fixture:** Create the source counterexample “A manifest repeats a policy field with conflicting values” for “Duplicate-safe parsing”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M01.04-C003-T08 · Enforcement evidence:** Exercise the “Duplicate-safe parsing” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M01.04-C003-T09 · Regression linkage:** Link the “Duplicate-safe parsing” property to changes in manifest readers, canonical digest generation and schema migrations; record which dependency or contract changes require rerunning it.
- [ ] **UC-M01.04-C003-T10 · Property disposition:** Compare the satisfying and violating “Duplicate-safe parsing” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M01.04-C004 · Integration

**Original checklist item:** Integrate duplicate-safe parsing with manifest readers, canonical digest generation and schema migrations; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M01.04-C004-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Duplicate-safe parsing” across manifest readers, canonical digest generation and schema migrations; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M01.04-C004-T02 · Field mapping:** Map every “Duplicate-safe parsing” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M01.04-C004-T03 · Prerequisite identities:** Record the actual prerequisites for “Duplicate-safe parsing” (source dependency list: UC-M01.02); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M01.04-C004-T04 · Ownership agreement:** Specify who owns “Duplicate-safe parsing” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M01.04-C004-T05 · Handoff implementation:** Connect “Duplicate-safe parsing” through the mapped seam using the real adapter or explicit specification reference; preserve “Duplicate keys cannot be silently overwritten” across the handoff.
- [ ] **UC-M01.04-C004-T06 · Absent-input case:** Omit one required “Duplicate-safe parsing” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M01.04-C004-T07 · Stale-input case:** Supply an outdated “Duplicate-safe parsing” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M01.04-C004-T08 · Incompatible-input case:** Supply an incompatible “Duplicate-safe parsing” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M01.04-C004-T09 · Valid integration trace:** Run a valid “Duplicate-safe parsing” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M01.04-C004-T10 · Seam review:** Reconcile the “Duplicate-safe parsing” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M01.04-C005 · Valid-case test

**Original checklist item:** Construct a valid worked example for duplicate-safe parsing; evaluate it against predeclared expected decisions and, where enforcement exists, run the corresponding conformance fixture.

- [ ] **UC-M01.04-C005-T01 · Valid fixture choice:** Select one concrete valid worked example for “Duplicate-safe parsing”; enumerate the model inputs and the expected review decision before evaluating it.
- [ ] **UC-M01.04-C005-T02 · Expected-result oracle:** Specify the “Duplicate-safe parsing” expected result independently of the implementation output; include the property “Duplicate keys cannot be silently overwritten” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M01.04-C005-T03 · Fixture material:** Create the concrete “Duplicate-safe parsing” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M01.04-C005-T04 · Target preparation:** Prepare the “Duplicate-safe parsing” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M01.04-C005-T05 · Initial-state record:** Record the initial “Duplicate-safe parsing” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M01.04-C005-T06 · Valid-path execution:** Evaluate the “Duplicate-safe parsing” example against the reviewed model; where a runtime mechanism exists, run its corresponding fixture and label those observations separately.
- [ ] **UC-M01.04-C005-T07 · Outcome comparison:** Compare every declared “Duplicate-safe parsing” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M01.04-C005-T08 · State and bounds check:** Inspect the “Duplicate-safe parsing” ownership/state effects and actual use of “Manifest bytes, object depth and key count”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M01.04-C005-T09 · Repeatability check:** Repeat the same “Duplicate-safe parsing” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M01.04-C005-T10 · Positive evidence:** Attach the “Duplicate-safe parsing” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M01.04-C006 · Negative test

**Original checklist item:** Negative case: A manifest repeats a policy field with conflicting values. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M01.04-C006-T01 · Adverse-case definition:** Create a test record for the exact “Duplicate-safe parsing” source counterexample: “A manifest repeats a policy field with conflicting values”; state which precondition or invariant it challenges.
- [ ] **UC-M01.04-C006-T02 · Safe fixture boundary:** Define the contained test boundary for “Duplicate-safe parsing”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M01.04-C006-T03 · Valid control:** Construct a valid “Duplicate-safe parsing” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M01.04-C006-T04 · Minimal adverse input:** Derive the “Duplicate-safe parsing” adverse fixture from the control with the smallest documented change needed to reproduce “A manifest repeats a policy field with conflicting values”; retain that change as reproducible data.
- [ ] **UC-M01.04-C006-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Duplicate-safe parsing”; require “Duplicate keys cannot be silently overwritten” and forbid a false-success verdict.
- [ ] **UC-M01.04-C006-T06 · Adverse execution:** Evaluate the “Duplicate-safe parsing” adverse case through the actual review/contract gate; where implemented, also observe the runtime refusal and keep the two evidence classes separate.
- [ ] **UC-M01.04-C006-T07 · Effect inspection:** Inspect “Duplicate-safe parsing” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M01.04-C006-T08 · Refusal versus failure:** Confirm the “Duplicate-safe parsing” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M01.04-C006-T09 · Reset and retention:** Restore only the disposable “Duplicate-safe parsing” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M01.04-C006-T10 · Negative regression:** Register the “Duplicate-safe parsing” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M01.04-C007 · Change / failure test

**Original checklist item:** Exercise duplicate-safe parsing when a manifest is upgraded and then submitted to an older supported reader; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M01.04-C007-T01 · Scenario record:** Write the “Duplicate-safe parsing” change/failure scenario exactly as supplied: a manifest is upgraded and then submitted to an older supported reader; identify the property that must remain true: “Duplicate keys cannot be silently overwritten”.
- [ ] **UC-M01.04-C007-T02 · Baseline capture:** Create a known-valid “Duplicate-safe parsing” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M01.04-C007-T03 · Injection map:** Locate the “Duplicate-safe parsing” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M01.04-C007-T04 · Disposition oracle:** Define the legal intermediate and final “Duplicate-safe parsing” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M01.04-C007-T05 · Controlled trigger:** Apply the controlled model-change scenario for “Duplicate-safe parsing”: a manifest is upgraded and then submitted to an older supported reader; retain the exact before/after declarations. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M01.04-C007-T06 · Intermediate inspection:** Review which “Duplicate-safe parsing” claims, approvals and evidence references become stale after the change; keep unresolved enforcement gaps visible.
- [ ] **UC-M01.04-C007-T07 · Recovery path:** Revise or explicitly refuse the changed “Duplicate-safe parsing” model under the documented compatibility policy; re-review affected claims before restoring their approval.
- [ ] **UC-M01.04-C007-T08 · Stale-evidence cleanup:** Invalidate superseded “Duplicate-safe parsing” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M01.04-C007-T09 · Repeat and compare:** Repeat the selected “Duplicate-safe parsing” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M01.04-C007-T10 · Failure evidence:** Publish the “Duplicate-safe parsing” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M01.04-C008 · Bounds

**Original checklist item:** Define completeness and scaling criteria for manifest bytes, object depth and key count; exercise larger inventories or fixture sets, and report uncovered scope instead of silently excluding it.

- [ ] **UC-M01.04-C008-T01 · Quantity inventory:** Create a measurement inventory for “Duplicate-safe parsing”: “Manifest bytes, object depth and key count”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M01.04-C008-T02 · Measurement method:** Choose how to observe each “Duplicate-safe parsing” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M01.04-C008-T03 · Budget decision:** Select justified coverage and completeness limits for “Duplicate-safe parsing”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M01.04-C008-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Duplicate-safe parsing” cases for “Manifest bytes, object depth and key count”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M01.04-C008-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Duplicate-safe parsing” limit; preserve “Duplicate keys cannot be silently overwritten”.
- [ ] **UC-M01.04-C008-T06 · Normal measurement:** Run or review the normal “Duplicate-safe parsing” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M01.04-C008-T07 · At-limit measurement:** Exercise the “Duplicate-safe parsing” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M01.04-C008-T08 · Over-limit measurement:** Exercise the “Duplicate-safe parsing” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M01.04-C008-T09 · Uncovered-scope report:** List the “Duplicate-safe parsing” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M01.04-C008-T10 · Limit evidence:** Publish the selected “Duplicate-safe parsing” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M01.04-C009 · Diagnostics / review

**Original checklist item:** Record the rationale, unresolved assumptions, enforcement gaps and re-review triggers for duplicate-safe parsing; make design-only claims visibly distinct from observed behavior.

- [ ] **UC-M01.04-C009-T01 · Review inventory:** List the “Duplicate-safe parsing” decisions and claims requiring review; distinguish source requirements, implementation observations and engineering assumptions.
- [ ] **UC-M01.04-C009-T02 · Rationale record:** Write the rationale for the selected “Duplicate-safe parsing” representation or policy; link each choice to the requirement rather than an unexplained preference.
- [ ] **UC-M01.04-C009-T03 · Assumption ledger:** Record unresolved “Duplicate-safe parsing” assumptions, their owner and what observation or decision would resolve them; do not treat unknowns as approvals.
- [ ] **UC-M01.04-C009-T04 · Boundary map:** Map each “Duplicate-safe parsing” claim to an actual guard or explicit design/review gate; flag gaps against “Duplicate keys cannot be silently overwritten”.
- [ ] **UC-M01.04-C009-T05 · Counterexample review:** Walk reviewers through the “Duplicate-safe parsing” counterexample “A manifest repeats a policy field with conflicting values”; record whether the model detects it and whether any runtime guard was actually exercised.
- [ ] **UC-M01.04-C009-T06 · Review outcome vocabulary:** Define approved, blocked, superseded and untested review outcomes for “Duplicate-safe parsing”; ensure the wording cannot be read as runtime enforcement evidence.
- [ ] **UC-M01.04-C009-T07 · Re-review triggers:** List “Duplicate-safe parsing” invalidation triggers, including the source change scenario: a manifest is upgraded and then submitted to an older supported reader; identify the affected claims and evidence.
- [ ] **UC-M01.04-C009-T08 · Sensitive-data review:** Inspect the “Duplicate-safe parsing” review record for secrets and unrelated user content; retain nonsecret references sufficient for reproducibility.
- [ ] **UC-M01.04-C009-T09 · Independent reading:** Have the “Duplicate-safe parsing” record read against the original acceptance criterion and manifest readers, canonical digest generation and schema migrations; record misunderstandings or missing evidence as corrections.
- [ ] **UC-M01.04-C009-T10 · Review disposition:** Publish the “Duplicate-safe parsing” rationale, versioned review outcome, unresolved gaps and explicit next decision; keep blockers open until supported evidence resolves them.

### UC-M01.04-C010 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for duplicate-safe parsing; label unexecuted checks as untested.

- [ ] **UC-M01.04-C010-T01 · Evidence inventory:** List the “Duplicate-safe parsing” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M01.04-C010-T02 · Artifact references:** Record the exact “Duplicate-safe parsing” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M01.04-C010-T03 · Fixture references:** Attach the “Duplicate-safe parsing” fixture IDs, input identities and oracle definition; preserve the source counterexample “A manifest repeats a policy field with conflicting values” as a distinct evidence case.
- [ ] **UC-M01.04-C010-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Duplicate-safe parsing”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M01.04-C010-T05 · Environment record:** Record the actual “Duplicate-safe parsing” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M01.04-C010-T06 · Expected versus observed:** Pair every “Duplicate-safe parsing” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M01.04-C010-T07 · Failure and limit records:** Attach “Duplicate-safe parsing” change/failure and bounds evidence where required; include uncovered “Manifest bytes, object depth and key count” and unresolved violations of “Duplicate keys cannot be silently overwritten”.
- [ ] **UC-M01.04-C010-T08 · Evidence hygiene:** Check the “Duplicate-safe parsing” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M01.04-C010-T09 · Reproduction review:** Have the “Duplicate-safe parsing” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M01.04-C010-T10 · Acceptance linkage:** Link the “Duplicate-safe parsing” evidence to its parent and UC-M01.04 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 02. Canonical encoding

**Source delivery:** Specify canonical field ordering and byte encoding for manifests.

**Source invariant:** Equivalent accepted manifests produce identical canonical bytes.

**Source negative case:** Key order changes a digest despite equivalent declared semantics.

**Source bounded quantities:** Canonicalization memory and maximum document size.

### UC-M01.04-C011 · Contract

**Original checklist item:** Specify the scope and representation of canonical encoding; identify its producer, consumer, authority assumptions and explicitly unsupported cases.

- [ ] **UC-M01.04-C011-T01 · Scope statement:** Draft a scope note for “Canonical encoding” within Canonical manifest and schema evolution; separate required model statements, explicit exclusions and unresolved design decisions.
- [ ] **UC-M01.04-C011-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Canonical encoding”; record each producer, representation and missing-value meaning.
- [ ] **UC-M01.04-C011-T03 · Output inventory:** List the outputs of “Canonical encoding” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M01.04-C011-T04 · Field dictionary:** Create a field-and-term dictionary for “Canonical encoding”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M01.04-C011-T05 · Prerequisite contract:** Map “Canonical encoding” to the source component prerequisites (UC-M01.02); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M01.04-C011-T06 · Authority map:** Identify who may produce, change and consume “Canonical encoding”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M01.04-C011-T07 · Invariant clause:** Add a normative clause for “Canonical encoding” that preserves “Equivalent accepted manifests produce identical canonical bytes”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M01.04-C011-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Canonical encoding”; include the source counterexample “Key order changes a digest despite equivalent declared semantics” and the intended safe disposition.
- [ ] **UC-M01.04-C011-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Canonicalization memory and maximum document size” in the “Canonical encoding” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M01.04-C011-T10 · Contract review:** Review the “Canonical encoding” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M01.04-C012 · Delivery

**Original checklist item:** Specify canonical field ordering and byte encoding for manifests.

- [ ] **UC-M01.04-C012-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Canonical encoding”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M01.04-C012-T02 · Change plan:** Break the source delivery for “Canonical encoding” into concrete edit targets and reviewable outputs; keep the UC-M01.04 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M01.04-C012-T03 · Core artifact:** Create the “Canonical encoding” model, schema or inventory that realizes this source instruction: Specify canonical field ordering and byte encoding for manifests.
- [ ] **UC-M01.04-C012-T04 · Concrete realization:** Populate “Canonical encoding” with one concrete worked case; map every required entity or field to its source and flag any unmapped entry.
- [ ] **UC-M01.04-C012-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Canonical encoding” needed to preserve “Equivalent accepted manifests produce identical canonical bytes”; record an enforcement gap where only a model exists.
- [ ] **UC-M01.04-C012-T06 · Dependency connection:** Connect the “Canonical encoding” specification to manifest readers, canonical digest generation and schema migrations; record code coverage separately where the design is not yet enforced.
- [ ] **UC-M01.04-C012-T07 · Resource behavior:** Account for “Canonicalization memory and maximum document size” in “Canonical encoding”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M01.04-C012-T08 · Delivery check:** Walk the populated “Canonical encoding” model through a valid example and the source counterexample “Key order changes a digest despite equivalent declared semantics”; record corrections and unresolved enforcement gaps.
- [ ] **UC-M01.04-C012-T09 · Patch review:** Review the “Canonical encoding” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M01.04-C012-T10 · Delivery handoff:** Publish the “Canonical encoding” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M01.04-C013 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Equivalent accepted manifests produce identical canonical bytes. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M01.04-C013-T01 · Named property:** Create a stable property/check name under this parent for “Canonical encoding”; copy its required invariant exactly: “Equivalent accepted manifests produce identical canonical bytes”.
- [ ] **UC-M01.04-C013-T02 · Observable terms:** Define each term in the “Canonical encoding” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M01.04-C013-T03 · Precondition set:** List the preconditions under which “Equivalent accepted manifests produce identical canonical bytes” must hold for “Canonical encoding”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M01.04-C013-T04 · Transition coverage:** Map the “Canonical encoding” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M01.04-C013-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Canonical encoding”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M01.04-C013-T06 · Satisfying fixture:** Create a concrete “Canonical encoding” case that satisfies “Equivalent accepted manifests produce identical canonical bytes”; record its expected observation before running the assertion or review.
- [ ] **UC-M01.04-C013-T07 · Violating fixture:** Create the source counterexample “Key order changes a digest despite equivalent declared semantics” for “Canonical encoding”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M01.04-C013-T08 · Enforcement evidence:** Exercise the “Canonical encoding” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M01.04-C013-T09 · Regression linkage:** Link the “Canonical encoding” property to changes in manifest readers, canonical digest generation and schema migrations; record which dependency or contract changes require rerunning it.
- [ ] **UC-M01.04-C013-T10 · Property disposition:** Compare the satisfying and violating “Canonical encoding” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M01.04-C014 · Integration

**Original checklist item:** Integrate canonical encoding with manifest readers, canonical digest generation and schema migrations; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M01.04-C014-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Canonical encoding” across manifest readers, canonical digest generation and schema migrations; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M01.04-C014-T02 · Field mapping:** Map every “Canonical encoding” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M01.04-C014-T03 · Prerequisite identities:** Record the actual prerequisites for “Canonical encoding” (source dependency list: UC-M01.02); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M01.04-C014-T04 · Ownership agreement:** Specify who owns “Canonical encoding” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M01.04-C014-T05 · Handoff implementation:** Connect “Canonical encoding” through the mapped seam using the real adapter or explicit specification reference; preserve “Equivalent accepted manifests produce identical canonical bytes” across the handoff.
- [ ] **UC-M01.04-C014-T06 · Absent-input case:** Omit one required “Canonical encoding” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M01.04-C014-T07 · Stale-input case:** Supply an outdated “Canonical encoding” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M01.04-C014-T08 · Incompatible-input case:** Supply an incompatible “Canonical encoding” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M01.04-C014-T09 · Valid integration trace:** Run a valid “Canonical encoding” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M01.04-C014-T10 · Seam review:** Reconcile the “Canonical encoding” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M01.04-C015 · Valid-case test

**Original checklist item:** Construct a valid worked example for canonical encoding; evaluate it against predeclared expected decisions and, where enforcement exists, run the corresponding conformance fixture.

- [ ] **UC-M01.04-C015-T01 · Valid fixture choice:** Select one concrete valid worked example for “Canonical encoding”; enumerate the model inputs and the expected review decision before evaluating it.
- [ ] **UC-M01.04-C015-T02 · Expected-result oracle:** Specify the “Canonical encoding” expected result independently of the implementation output; include the property “Equivalent accepted manifests produce identical canonical bytes” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M01.04-C015-T03 · Fixture material:** Create the concrete “Canonical encoding” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M01.04-C015-T04 · Target preparation:** Prepare the “Canonical encoding” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M01.04-C015-T05 · Initial-state record:** Record the initial “Canonical encoding” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M01.04-C015-T06 · Valid-path execution:** Evaluate the “Canonical encoding” example against the reviewed model; where a runtime mechanism exists, run its corresponding fixture and label those observations separately.
- [ ] **UC-M01.04-C015-T07 · Outcome comparison:** Compare every declared “Canonical encoding” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M01.04-C015-T08 · State and bounds check:** Inspect the “Canonical encoding” ownership/state effects and actual use of “Canonicalization memory and maximum document size”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M01.04-C015-T09 · Repeatability check:** Repeat the same “Canonical encoding” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M01.04-C015-T10 · Positive evidence:** Attach the “Canonical encoding” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M01.04-C016 · Negative test

**Original checklist item:** Negative case: Key order changes a digest despite equivalent declared semantics. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M01.04-C016-T01 · Adverse-case definition:** Create a test record for the exact “Canonical encoding” source counterexample: “Key order changes a digest despite equivalent declared semantics”; state which precondition or invariant it challenges.
- [ ] **UC-M01.04-C016-T02 · Safe fixture boundary:** Define the contained test boundary for “Canonical encoding”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M01.04-C016-T03 · Valid control:** Construct a valid “Canonical encoding” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M01.04-C016-T04 · Minimal adverse input:** Derive the “Canonical encoding” adverse fixture from the control with the smallest documented change needed to reproduce “Key order changes a digest despite equivalent declared semantics”; retain that change as reproducible data.
- [ ] **UC-M01.04-C016-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Canonical encoding”; require “Equivalent accepted manifests produce identical canonical bytes” and forbid a false-success verdict.
- [ ] **UC-M01.04-C016-T06 · Adverse execution:** Evaluate the “Canonical encoding” adverse case through the actual review/contract gate; where implemented, also observe the runtime refusal and keep the two evidence classes separate.
- [ ] **UC-M01.04-C016-T07 · Effect inspection:** Inspect “Canonical encoding” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M01.04-C016-T08 · Refusal versus failure:** Confirm the “Canonical encoding” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M01.04-C016-T09 · Reset and retention:** Restore only the disposable “Canonical encoding” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M01.04-C016-T10 · Negative regression:** Register the “Canonical encoding” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M01.04-C017 · Change / failure test

**Original checklist item:** Exercise canonical encoding when a manifest is upgraded and then submitted to an older supported reader; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M01.04-C017-T01 · Scenario record:** Write the “Canonical encoding” change/failure scenario exactly as supplied: a manifest is upgraded and then submitted to an older supported reader; identify the property that must remain true: “Equivalent accepted manifests produce identical canonical bytes”.
- [ ] **UC-M01.04-C017-T02 · Baseline capture:** Create a known-valid “Canonical encoding” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M01.04-C017-T03 · Injection map:** Locate the “Canonical encoding” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M01.04-C017-T04 · Disposition oracle:** Define the legal intermediate and final “Canonical encoding” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M01.04-C017-T05 · Controlled trigger:** Apply the controlled model-change scenario for “Canonical encoding”: a manifest is upgraded and then submitted to an older supported reader; retain the exact before/after declarations. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M01.04-C017-T06 · Intermediate inspection:** Review which “Canonical encoding” claims, approvals and evidence references become stale after the change; keep unresolved enforcement gaps visible.
- [ ] **UC-M01.04-C017-T07 · Recovery path:** Revise or explicitly refuse the changed “Canonical encoding” model under the documented compatibility policy; re-review affected claims before restoring their approval.
- [ ] **UC-M01.04-C017-T08 · Stale-evidence cleanup:** Invalidate superseded “Canonical encoding” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M01.04-C017-T09 · Repeat and compare:** Repeat the selected “Canonical encoding” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M01.04-C017-T10 · Failure evidence:** Publish the “Canonical encoding” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M01.04-C018 · Bounds

**Original checklist item:** Define completeness and scaling criteria for canonicalization memory and maximum document size; exercise larger inventories or fixture sets, and report uncovered scope instead of silently excluding it.

- [ ] **UC-M01.04-C018-T01 · Quantity inventory:** Create a measurement inventory for “Canonical encoding”: “Canonicalization memory and maximum document size”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M01.04-C018-T02 · Measurement method:** Choose how to observe each “Canonical encoding” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M01.04-C018-T03 · Budget decision:** Select justified coverage and completeness limits for “Canonical encoding”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M01.04-C018-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Canonical encoding” cases for “Canonicalization memory and maximum document size”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M01.04-C018-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Canonical encoding” limit; preserve “Equivalent accepted manifests produce identical canonical bytes”.
- [ ] **UC-M01.04-C018-T06 · Normal measurement:** Run or review the normal “Canonical encoding” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M01.04-C018-T07 · At-limit measurement:** Exercise the “Canonical encoding” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M01.04-C018-T08 · Over-limit measurement:** Exercise the “Canonical encoding” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M01.04-C018-T09 · Uncovered-scope report:** List the “Canonical encoding” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M01.04-C018-T10 · Limit evidence:** Publish the selected “Canonical encoding” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M01.04-C019 · Diagnostics / review

**Original checklist item:** Record the rationale, unresolved assumptions, enforcement gaps and re-review triggers for canonical encoding; make design-only claims visibly distinct from observed behavior.

- [ ] **UC-M01.04-C019-T01 · Review inventory:** List the “Canonical encoding” decisions and claims requiring review; distinguish source requirements, implementation observations and engineering assumptions.
- [ ] **UC-M01.04-C019-T02 · Rationale record:** Write the rationale for the selected “Canonical encoding” representation or policy; link each choice to the requirement rather than an unexplained preference.
- [ ] **UC-M01.04-C019-T03 · Assumption ledger:** Record unresolved “Canonical encoding” assumptions, their owner and what observation or decision would resolve them; do not treat unknowns as approvals.
- [ ] **UC-M01.04-C019-T04 · Boundary map:** Map each “Canonical encoding” claim to an actual guard or explicit design/review gate; flag gaps against “Equivalent accepted manifests produce identical canonical bytes”.
- [ ] **UC-M01.04-C019-T05 · Counterexample review:** Walk reviewers through the “Canonical encoding” counterexample “Key order changes a digest despite equivalent declared semantics”; record whether the model detects it and whether any runtime guard was actually exercised.
- [ ] **UC-M01.04-C019-T06 · Review outcome vocabulary:** Define approved, blocked, superseded and untested review outcomes for “Canonical encoding”; ensure the wording cannot be read as runtime enforcement evidence.
- [ ] **UC-M01.04-C019-T07 · Re-review triggers:** List “Canonical encoding” invalidation triggers, including the source change scenario: a manifest is upgraded and then submitted to an older supported reader; identify the affected claims and evidence.
- [ ] **UC-M01.04-C019-T08 · Sensitive-data review:** Inspect the “Canonical encoding” review record for secrets and unrelated user content; retain nonsecret references sufficient for reproducibility.
- [ ] **UC-M01.04-C019-T09 · Independent reading:** Have the “Canonical encoding” record read against the original acceptance criterion and manifest readers, canonical digest generation and schema migrations; record misunderstandings or missing evidence as corrections.
- [ ] **UC-M01.04-C019-T10 · Review disposition:** Publish the “Canonical encoding” rationale, versioned review outcome, unresolved gaps and explicit next decision; keep blockers open until supported evidence resolves them.

### UC-M01.04-C020 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for canonical encoding; label unexecuted checks as untested.

- [ ] **UC-M01.04-C020-T01 · Evidence inventory:** List the “Canonical encoding” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M01.04-C020-T02 · Artifact references:** Record the exact “Canonical encoding” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M01.04-C020-T03 · Fixture references:** Attach the “Canonical encoding” fixture IDs, input identities and oracle definition; preserve the source counterexample “Key order changes a digest despite equivalent declared semantics” as a distinct evidence case.
- [ ] **UC-M01.04-C020-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Canonical encoding”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M01.04-C020-T05 · Environment record:** Record the actual “Canonical encoding” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M01.04-C020-T06 · Expected versus observed:** Pair every “Canonical encoding” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M01.04-C020-T07 · Failure and limit records:** Attach “Canonical encoding” change/failure and bounds evidence where required; include uncovered “Canonicalization memory and maximum document size” and unresolved violations of “Equivalent accepted manifests produce identical canonical bytes”.
- [ ] **UC-M01.04-C020-T08 · Evidence hygiene:** Check the “Canonical encoding” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M01.04-C020-T09 · Reproduction review:** Have the “Canonical encoding” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M01.04-C020-T10 · Acceptance linkage:** Link the “Canonical encoding” evidence to its parent and UC-M01.04 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 03. Numeric semantics

**Source delivery:** Define integer widths, range bounds and non-finite-number refusal.

**Source invariant:** Numbers have one lossless interpretation across consumers.

**Source negative case:** A generation exceeds its supported integer range.

**Source bounded quantities:** Numeric width, conversion time and boundary fixture count.

### UC-M01.04-C021 · Contract

**Original checklist item:** Specify the scope and representation of numeric semantics; identify its producer, consumer, authority assumptions and explicitly unsupported cases.

- [ ] **UC-M01.04-C021-T01 · Scope statement:** Draft a scope note for “Numeric semantics” within Canonical manifest and schema evolution; separate required model statements, explicit exclusions and unresolved design decisions.
- [ ] **UC-M01.04-C021-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Numeric semantics”; record each producer, representation and missing-value meaning.
- [ ] **UC-M01.04-C021-T03 · Output inventory:** List the outputs of “Numeric semantics” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M01.04-C021-T04 · Field dictionary:** Create a field-and-term dictionary for “Numeric semantics”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M01.04-C021-T05 · Prerequisite contract:** Map “Numeric semantics” to the source component prerequisites (UC-M01.02); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M01.04-C021-T06 · Authority map:** Identify who may produce, change and consume “Numeric semantics”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M01.04-C021-T07 · Invariant clause:** Add a normative clause for “Numeric semantics” that preserves “Numbers have one lossless interpretation across consumers”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M01.04-C021-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Numeric semantics”; include the source counterexample “A generation exceeds its supported integer range” and the intended safe disposition.
- [ ] **UC-M01.04-C021-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Numeric width, conversion time and boundary fixture count” in the “Numeric semantics” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M01.04-C021-T10 · Contract review:** Review the “Numeric semantics” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M01.04-C022 · Delivery

**Original checklist item:** Define integer widths, range bounds and non-finite-number refusal.

- [ ] **UC-M01.04-C022-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Numeric semantics”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M01.04-C022-T02 · Change plan:** Break the source delivery for “Numeric semantics” into concrete edit targets and reviewable outputs; keep the UC-M01.04 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M01.04-C022-T03 · Core artifact:** Create the “Numeric semantics” model, schema or inventory that realizes this source instruction: Define integer widths, range bounds and non-finite-number refusal.
- [ ] **UC-M01.04-C022-T04 · Concrete realization:** Populate “Numeric semantics” with one concrete worked case; map every required entity or field to its source and flag any unmapped entry.
- [ ] **UC-M01.04-C022-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Numeric semantics” needed to preserve “Numbers have one lossless interpretation across consumers”; record an enforcement gap where only a model exists.
- [ ] **UC-M01.04-C022-T06 · Dependency connection:** Connect the “Numeric semantics” specification to manifest readers, canonical digest generation and schema migrations; record code coverage separately where the design is not yet enforced.
- [ ] **UC-M01.04-C022-T07 · Resource behavior:** Account for “Numeric width, conversion time and boundary fixture count” in “Numeric semantics”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M01.04-C022-T08 · Delivery check:** Walk the populated “Numeric semantics” model through a valid example and the source counterexample “A generation exceeds its supported integer range”; record corrections and unresolved enforcement gaps.
- [ ] **UC-M01.04-C022-T09 · Patch review:** Review the “Numeric semantics” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M01.04-C022-T10 · Delivery handoff:** Publish the “Numeric semantics” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M01.04-C023 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Numbers have one lossless interpretation across consumers. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M01.04-C023-T01 · Named property:** Create a stable property/check name under this parent for “Numeric semantics”; copy its required invariant exactly: “Numbers have one lossless interpretation across consumers”.
- [ ] **UC-M01.04-C023-T02 · Observable terms:** Define each term in the “Numeric semantics” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M01.04-C023-T03 · Precondition set:** List the preconditions under which “Numbers have one lossless interpretation across consumers” must hold for “Numeric semantics”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M01.04-C023-T04 · Transition coverage:** Map the “Numeric semantics” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M01.04-C023-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Numeric semantics”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M01.04-C023-T06 · Satisfying fixture:** Create a concrete “Numeric semantics” case that satisfies “Numbers have one lossless interpretation across consumers”; record its expected observation before running the assertion or review.
- [ ] **UC-M01.04-C023-T07 · Violating fixture:** Create the source counterexample “A generation exceeds its supported integer range” for “Numeric semantics”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M01.04-C023-T08 · Enforcement evidence:** Exercise the “Numeric semantics” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M01.04-C023-T09 · Regression linkage:** Link the “Numeric semantics” property to changes in manifest readers, canonical digest generation and schema migrations; record which dependency or contract changes require rerunning it.
- [ ] **UC-M01.04-C023-T10 · Property disposition:** Compare the satisfying and violating “Numeric semantics” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M01.04-C024 · Integration

**Original checklist item:** Integrate numeric semantics with manifest readers, canonical digest generation and schema migrations; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M01.04-C024-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Numeric semantics” across manifest readers, canonical digest generation and schema migrations; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M01.04-C024-T02 · Field mapping:** Map every “Numeric semantics” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M01.04-C024-T03 · Prerequisite identities:** Record the actual prerequisites for “Numeric semantics” (source dependency list: UC-M01.02); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M01.04-C024-T04 · Ownership agreement:** Specify who owns “Numeric semantics” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M01.04-C024-T05 · Handoff implementation:** Connect “Numeric semantics” through the mapped seam using the real adapter or explicit specification reference; preserve “Numbers have one lossless interpretation across consumers” across the handoff.
- [ ] **UC-M01.04-C024-T06 · Absent-input case:** Omit one required “Numeric semantics” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M01.04-C024-T07 · Stale-input case:** Supply an outdated “Numeric semantics” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M01.04-C024-T08 · Incompatible-input case:** Supply an incompatible “Numeric semantics” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M01.04-C024-T09 · Valid integration trace:** Run a valid “Numeric semantics” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M01.04-C024-T10 · Seam review:** Reconcile the “Numeric semantics” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M01.04-C025 · Valid-case test

**Original checklist item:** Construct a valid worked example for numeric semantics; evaluate it against predeclared expected decisions and, where enforcement exists, run the corresponding conformance fixture.

- [ ] **UC-M01.04-C025-T01 · Valid fixture choice:** Select one concrete valid worked example for “Numeric semantics”; enumerate the model inputs and the expected review decision before evaluating it.
- [ ] **UC-M01.04-C025-T02 · Expected-result oracle:** Specify the “Numeric semantics” expected result independently of the implementation output; include the property “Numbers have one lossless interpretation across consumers” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M01.04-C025-T03 · Fixture material:** Create the concrete “Numeric semantics” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M01.04-C025-T04 · Target preparation:** Prepare the “Numeric semantics” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M01.04-C025-T05 · Initial-state record:** Record the initial “Numeric semantics” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M01.04-C025-T06 · Valid-path execution:** Evaluate the “Numeric semantics” example against the reviewed model; where a runtime mechanism exists, run its corresponding fixture and label those observations separately.
- [ ] **UC-M01.04-C025-T07 · Outcome comparison:** Compare every declared “Numeric semantics” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M01.04-C025-T08 · State and bounds check:** Inspect the “Numeric semantics” ownership/state effects and actual use of “Numeric width, conversion time and boundary fixture count”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M01.04-C025-T09 · Repeatability check:** Repeat the same “Numeric semantics” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M01.04-C025-T10 · Positive evidence:** Attach the “Numeric semantics” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M01.04-C026 · Negative test

**Original checklist item:** Negative case: A generation exceeds its supported integer range. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M01.04-C026-T01 · Adverse-case definition:** Create a test record for the exact “Numeric semantics” source counterexample: “A generation exceeds its supported integer range”; state which precondition or invariant it challenges.
- [ ] **UC-M01.04-C026-T02 · Safe fixture boundary:** Define the contained test boundary for “Numeric semantics”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M01.04-C026-T03 · Valid control:** Construct a valid “Numeric semantics” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M01.04-C026-T04 · Minimal adverse input:** Derive the “Numeric semantics” adverse fixture from the control with the smallest documented change needed to reproduce “A generation exceeds its supported integer range”; retain that change as reproducible data.
- [ ] **UC-M01.04-C026-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Numeric semantics”; require “Numbers have one lossless interpretation across consumers” and forbid a false-success verdict.
- [ ] **UC-M01.04-C026-T06 · Adverse execution:** Evaluate the “Numeric semantics” adverse case through the actual review/contract gate; where implemented, also observe the runtime refusal and keep the two evidence classes separate.
- [ ] **UC-M01.04-C026-T07 · Effect inspection:** Inspect “Numeric semantics” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M01.04-C026-T08 · Refusal versus failure:** Confirm the “Numeric semantics” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M01.04-C026-T09 · Reset and retention:** Restore only the disposable “Numeric semantics” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M01.04-C026-T10 · Negative regression:** Register the “Numeric semantics” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M01.04-C027 · Change / failure test

**Original checklist item:** Exercise numeric semantics when a manifest is upgraded and then submitted to an older supported reader; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M01.04-C027-T01 · Scenario record:** Write the “Numeric semantics” change/failure scenario exactly as supplied: a manifest is upgraded and then submitted to an older supported reader; identify the property that must remain true: “Numbers have one lossless interpretation across consumers”.
- [ ] **UC-M01.04-C027-T02 · Baseline capture:** Create a known-valid “Numeric semantics” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M01.04-C027-T03 · Injection map:** Locate the “Numeric semantics” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M01.04-C027-T04 · Disposition oracle:** Define the legal intermediate and final “Numeric semantics” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M01.04-C027-T05 · Controlled trigger:** Apply the controlled model-change scenario for “Numeric semantics”: a manifest is upgraded and then submitted to an older supported reader; retain the exact before/after declarations. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M01.04-C027-T06 · Intermediate inspection:** Review which “Numeric semantics” claims, approvals and evidence references become stale after the change; keep unresolved enforcement gaps visible.
- [ ] **UC-M01.04-C027-T07 · Recovery path:** Revise or explicitly refuse the changed “Numeric semantics” model under the documented compatibility policy; re-review affected claims before restoring their approval.
- [ ] **UC-M01.04-C027-T08 · Stale-evidence cleanup:** Invalidate superseded “Numeric semantics” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M01.04-C027-T09 · Repeat and compare:** Repeat the selected “Numeric semantics” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M01.04-C027-T10 · Failure evidence:** Publish the “Numeric semantics” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M01.04-C028 · Bounds

**Original checklist item:** Define completeness and scaling criteria for numeric width, conversion time and boundary fixture count; exercise larger inventories or fixture sets, and report uncovered scope instead of silently excluding it.

- [ ] **UC-M01.04-C028-T01 · Quantity inventory:** Create a measurement inventory for “Numeric semantics”: “Numeric width, conversion time and boundary fixture count”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M01.04-C028-T02 · Measurement method:** Choose how to observe each “Numeric semantics” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M01.04-C028-T03 · Budget decision:** Select justified coverage and completeness limits for “Numeric semantics”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M01.04-C028-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Numeric semantics” cases for “Numeric width, conversion time and boundary fixture count”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M01.04-C028-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Numeric semantics” limit; preserve “Numbers have one lossless interpretation across consumers”.
- [ ] **UC-M01.04-C028-T06 · Normal measurement:** Run or review the normal “Numeric semantics” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M01.04-C028-T07 · At-limit measurement:** Exercise the “Numeric semantics” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M01.04-C028-T08 · Over-limit measurement:** Exercise the “Numeric semantics” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M01.04-C028-T09 · Uncovered-scope report:** List the “Numeric semantics” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M01.04-C028-T10 · Limit evidence:** Publish the selected “Numeric semantics” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M01.04-C029 · Diagnostics / review

**Original checklist item:** Record the rationale, unresolved assumptions, enforcement gaps and re-review triggers for numeric semantics; make design-only claims visibly distinct from observed behavior.

- [ ] **UC-M01.04-C029-T01 · Review inventory:** List the “Numeric semantics” decisions and claims requiring review; distinguish source requirements, implementation observations and engineering assumptions.
- [ ] **UC-M01.04-C029-T02 · Rationale record:** Write the rationale for the selected “Numeric semantics” representation or policy; link each choice to the requirement rather than an unexplained preference.
- [ ] **UC-M01.04-C029-T03 · Assumption ledger:** Record unresolved “Numeric semantics” assumptions, their owner and what observation or decision would resolve them; do not treat unknowns as approvals.
- [ ] **UC-M01.04-C029-T04 · Boundary map:** Map each “Numeric semantics” claim to an actual guard or explicit design/review gate; flag gaps against “Numbers have one lossless interpretation across consumers”.
- [ ] **UC-M01.04-C029-T05 · Counterexample review:** Walk reviewers through the “Numeric semantics” counterexample “A generation exceeds its supported integer range”; record whether the model detects it and whether any runtime guard was actually exercised.
- [ ] **UC-M01.04-C029-T06 · Review outcome vocabulary:** Define approved, blocked, superseded and untested review outcomes for “Numeric semantics”; ensure the wording cannot be read as runtime enforcement evidence.
- [ ] **UC-M01.04-C029-T07 · Re-review triggers:** List “Numeric semantics” invalidation triggers, including the source change scenario: a manifest is upgraded and then submitted to an older supported reader; identify the affected claims and evidence.
- [ ] **UC-M01.04-C029-T08 · Sensitive-data review:** Inspect the “Numeric semantics” review record for secrets and unrelated user content; retain nonsecret references sufficient for reproducibility.
- [ ] **UC-M01.04-C029-T09 · Independent reading:** Have the “Numeric semantics” record read against the original acceptance criterion and manifest readers, canonical digest generation and schema migrations; record misunderstandings or missing evidence as corrections.
- [ ] **UC-M01.04-C029-T10 · Review disposition:** Publish the “Numeric semantics” rationale, versioned review outcome, unresolved gaps and explicit next decision; keep blockers open until supported evidence resolves them.

### UC-M01.04-C030 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for numeric semantics; label unexecuted checks as untested.

- [ ] **UC-M01.04-C030-T01 · Evidence inventory:** List the “Numeric semantics” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M01.04-C030-T02 · Artifact references:** Record the exact “Numeric semantics” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M01.04-C030-T03 · Fixture references:** Attach the “Numeric semantics” fixture IDs, input identities and oracle definition; preserve the source counterexample “A generation exceeds its supported integer range” as a distinct evidence case.
- [ ] **UC-M01.04-C030-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Numeric semantics”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M01.04-C030-T05 · Environment record:** Record the actual “Numeric semantics” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M01.04-C030-T06 · Expected versus observed:** Pair every “Numeric semantics” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M01.04-C030-T07 · Failure and limit records:** Attach “Numeric semantics” change/failure and bounds evidence where required; include uncovered “Numeric width, conversion time and boundary fixture count” and unresolved violations of “Numbers have one lossless interpretation across consumers”.
- [ ] **UC-M01.04-C030-T08 · Evidence hygiene:** Check the “Numeric semantics” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M01.04-C030-T09 · Reproduction review:** Have the “Numeric semantics” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M01.04-C030-T10 · Acceptance linkage:** Link the “Numeric semantics” evidence to its parent and UC-M01.04 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 04. Text and identifier rules

**Source delivery:** Define text encoding and normalization rules without merging distinct identities.

**Source invariant:** Normalization cannot silently change an authority-bearing identifier.

**Source negative case:** Two identifiers collapse to one normalized name.

**Source bounded quantities:** Identifier length and normalization expansion.

### UC-M01.04-C031 · Contract

**Original checklist item:** Specify the scope and representation of text and identifier rules; identify its producer, consumer, authority assumptions and explicitly unsupported cases.

- [ ] **UC-M01.04-C031-T01 · Scope statement:** Draft a scope note for “Text and identifier rules” within Canonical manifest and schema evolution; separate required model statements, explicit exclusions and unresolved design decisions.
- [ ] **UC-M01.04-C031-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Text and identifier rules”; record each producer, representation and missing-value meaning.
- [ ] **UC-M01.04-C031-T03 · Output inventory:** List the outputs of “Text and identifier rules” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M01.04-C031-T04 · Field dictionary:** Create a field-and-term dictionary for “Text and identifier rules”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M01.04-C031-T05 · Prerequisite contract:** Map “Text and identifier rules” to the source component prerequisites (UC-M01.02); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M01.04-C031-T06 · Authority map:** Identify who may produce, change and consume “Text and identifier rules”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M01.04-C031-T07 · Invariant clause:** Add a normative clause for “Text and identifier rules” that preserves “Normalization cannot silently change an authority-bearing identifier”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M01.04-C031-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Text and identifier rules”; include the source counterexample “Two identifiers collapse to one normalized name” and the intended safe disposition.
- [ ] **UC-M01.04-C031-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Identifier length and normalization expansion” in the “Text and identifier rules” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M01.04-C031-T10 · Contract review:** Review the “Text and identifier rules” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M01.04-C032 · Delivery

**Original checklist item:** Define text encoding and normalization rules without merging distinct identities.

- [ ] **UC-M01.04-C032-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Text and identifier rules”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M01.04-C032-T02 · Change plan:** Break the source delivery for “Text and identifier rules” into concrete edit targets and reviewable outputs; keep the UC-M01.04 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M01.04-C032-T03 · Core artifact:** Create the “Text and identifier rules” model, schema or inventory that realizes this source instruction: Define text encoding and normalization rules without merging distinct identities.
- [ ] **UC-M01.04-C032-T04 · Concrete realization:** Populate “Text and identifier rules” with one concrete worked case; map every required entity or field to its source and flag any unmapped entry.
- [ ] **UC-M01.04-C032-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Text and identifier rules” needed to preserve “Normalization cannot silently change an authority-bearing identifier”; record an enforcement gap where only a model exists.
- [ ] **UC-M01.04-C032-T06 · Dependency connection:** Connect the “Text and identifier rules” specification to manifest readers, canonical digest generation and schema migrations; record code coverage separately where the design is not yet enforced.
- [ ] **UC-M01.04-C032-T07 · Resource behavior:** Account for “Identifier length and normalization expansion” in “Text and identifier rules”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M01.04-C032-T08 · Delivery check:** Walk the populated “Text and identifier rules” model through a valid example and the source counterexample “Two identifiers collapse to one normalized name”; record corrections and unresolved enforcement gaps.
- [ ] **UC-M01.04-C032-T09 · Patch review:** Review the “Text and identifier rules” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M01.04-C032-T10 · Delivery handoff:** Publish the “Text and identifier rules” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M01.04-C033 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Normalization cannot silently change an authority-bearing identifier. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M01.04-C033-T01 · Named property:** Create a stable property/check name under this parent for “Text and identifier rules”; copy its required invariant exactly: “Normalization cannot silently change an authority-bearing identifier”.
- [ ] **UC-M01.04-C033-T02 · Observable terms:** Define each term in the “Text and identifier rules” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M01.04-C033-T03 · Precondition set:** List the preconditions under which “Normalization cannot silently change an authority-bearing identifier” must hold for “Text and identifier rules”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M01.04-C033-T04 · Transition coverage:** Map the “Text and identifier rules” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M01.04-C033-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Text and identifier rules”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M01.04-C033-T06 · Satisfying fixture:** Create a concrete “Text and identifier rules” case that satisfies “Normalization cannot silently change an authority-bearing identifier”; record its expected observation before running the assertion or review.
- [ ] **UC-M01.04-C033-T07 · Violating fixture:** Create the source counterexample “Two identifiers collapse to one normalized name” for “Text and identifier rules”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M01.04-C033-T08 · Enforcement evidence:** Exercise the “Text and identifier rules” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M01.04-C033-T09 · Regression linkage:** Link the “Text and identifier rules” property to changes in manifest readers, canonical digest generation and schema migrations; record which dependency or contract changes require rerunning it.
- [ ] **UC-M01.04-C033-T10 · Property disposition:** Compare the satisfying and violating “Text and identifier rules” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M01.04-C034 · Integration

**Original checklist item:** Integrate text and identifier rules with manifest readers, canonical digest generation and schema migrations; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M01.04-C034-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Text and identifier rules” across manifest readers, canonical digest generation and schema migrations; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M01.04-C034-T02 · Field mapping:** Map every “Text and identifier rules” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M01.04-C034-T03 · Prerequisite identities:** Record the actual prerequisites for “Text and identifier rules” (source dependency list: UC-M01.02); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M01.04-C034-T04 · Ownership agreement:** Specify who owns “Text and identifier rules” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M01.04-C034-T05 · Handoff implementation:** Connect “Text and identifier rules” through the mapped seam using the real adapter or explicit specification reference; preserve “Normalization cannot silently change an authority-bearing identifier” across the handoff.
- [ ] **UC-M01.04-C034-T06 · Absent-input case:** Omit one required “Text and identifier rules” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M01.04-C034-T07 · Stale-input case:** Supply an outdated “Text and identifier rules” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M01.04-C034-T08 · Incompatible-input case:** Supply an incompatible “Text and identifier rules” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M01.04-C034-T09 · Valid integration trace:** Run a valid “Text and identifier rules” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M01.04-C034-T10 · Seam review:** Reconcile the “Text and identifier rules” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M01.04-C035 · Valid-case test

**Original checklist item:** Construct a valid worked example for text and identifier rules; evaluate it against predeclared expected decisions and, where enforcement exists, run the corresponding conformance fixture.

- [ ] **UC-M01.04-C035-T01 · Valid fixture choice:** Select one concrete valid worked example for “Text and identifier rules”; enumerate the model inputs and the expected review decision before evaluating it.
- [ ] **UC-M01.04-C035-T02 · Expected-result oracle:** Specify the “Text and identifier rules” expected result independently of the implementation output; include the property “Normalization cannot silently change an authority-bearing identifier” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M01.04-C035-T03 · Fixture material:** Create the concrete “Text and identifier rules” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M01.04-C035-T04 · Target preparation:** Prepare the “Text and identifier rules” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M01.04-C035-T05 · Initial-state record:** Record the initial “Text and identifier rules” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M01.04-C035-T06 · Valid-path execution:** Evaluate the “Text and identifier rules” example against the reviewed model; where a runtime mechanism exists, run its corresponding fixture and label those observations separately.
- [ ] **UC-M01.04-C035-T07 · Outcome comparison:** Compare every declared “Text and identifier rules” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M01.04-C035-T08 · State and bounds check:** Inspect the “Text and identifier rules” ownership/state effects and actual use of “Identifier length and normalization expansion”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M01.04-C035-T09 · Repeatability check:** Repeat the same “Text and identifier rules” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M01.04-C035-T10 · Positive evidence:** Attach the “Text and identifier rules” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M01.04-C036 · Negative test

**Original checklist item:** Negative case: Two identifiers collapse to one normalized name. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M01.04-C036-T01 · Adverse-case definition:** Create a test record for the exact “Text and identifier rules” source counterexample: “Two identifiers collapse to one normalized name”; state which precondition or invariant it challenges.
- [ ] **UC-M01.04-C036-T02 · Safe fixture boundary:** Define the contained test boundary for “Text and identifier rules”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M01.04-C036-T03 · Valid control:** Construct a valid “Text and identifier rules” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M01.04-C036-T04 · Minimal adverse input:** Derive the “Text and identifier rules” adverse fixture from the control with the smallest documented change needed to reproduce “Two identifiers collapse to one normalized name”; retain that change as reproducible data.
- [ ] **UC-M01.04-C036-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Text and identifier rules”; require “Normalization cannot silently change an authority-bearing identifier” and forbid a false-success verdict.
- [ ] **UC-M01.04-C036-T06 · Adverse execution:** Evaluate the “Text and identifier rules” adverse case through the actual review/contract gate; where implemented, also observe the runtime refusal and keep the two evidence classes separate.
- [ ] **UC-M01.04-C036-T07 · Effect inspection:** Inspect “Text and identifier rules” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M01.04-C036-T08 · Refusal versus failure:** Confirm the “Text and identifier rules” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M01.04-C036-T09 · Reset and retention:** Restore only the disposable “Text and identifier rules” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M01.04-C036-T10 · Negative regression:** Register the “Text and identifier rules” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M01.04-C037 · Change / failure test

**Original checklist item:** Exercise text and identifier rules when a manifest is upgraded and then submitted to an older supported reader; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M01.04-C037-T01 · Scenario record:** Write the “Text and identifier rules” change/failure scenario exactly as supplied: a manifest is upgraded and then submitted to an older supported reader; identify the property that must remain true: “Normalization cannot silently change an authority-bearing identifier”.
- [ ] **UC-M01.04-C037-T02 · Baseline capture:** Create a known-valid “Text and identifier rules” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M01.04-C037-T03 · Injection map:** Locate the “Text and identifier rules” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M01.04-C037-T04 · Disposition oracle:** Define the legal intermediate and final “Text and identifier rules” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M01.04-C037-T05 · Controlled trigger:** Apply the controlled model-change scenario for “Text and identifier rules”: a manifest is upgraded and then submitted to an older supported reader; retain the exact before/after declarations. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M01.04-C037-T06 · Intermediate inspection:** Review which “Text and identifier rules” claims, approvals and evidence references become stale after the change; keep unresolved enforcement gaps visible.
- [ ] **UC-M01.04-C037-T07 · Recovery path:** Revise or explicitly refuse the changed “Text and identifier rules” model under the documented compatibility policy; re-review affected claims before restoring their approval.
- [ ] **UC-M01.04-C037-T08 · Stale-evidence cleanup:** Invalidate superseded “Text and identifier rules” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M01.04-C037-T09 · Repeat and compare:** Repeat the selected “Text and identifier rules” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M01.04-C037-T10 · Failure evidence:** Publish the “Text and identifier rules” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M01.04-C038 · Bounds

**Original checklist item:** Define completeness and scaling criteria for identifier length and normalization expansion; exercise larger inventories or fixture sets, and report uncovered scope instead of silently excluding it.

- [ ] **UC-M01.04-C038-T01 · Quantity inventory:** Create a measurement inventory for “Text and identifier rules”: “Identifier length and normalization expansion”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M01.04-C038-T02 · Measurement method:** Choose how to observe each “Text and identifier rules” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M01.04-C038-T03 · Budget decision:** Select justified coverage and completeness limits for “Text and identifier rules”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M01.04-C038-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Text and identifier rules” cases for “Identifier length and normalization expansion”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M01.04-C038-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Text and identifier rules” limit; preserve “Normalization cannot silently change an authority-bearing identifier”.
- [ ] **UC-M01.04-C038-T06 · Normal measurement:** Run or review the normal “Text and identifier rules” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M01.04-C038-T07 · At-limit measurement:** Exercise the “Text and identifier rules” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M01.04-C038-T08 · Over-limit measurement:** Exercise the “Text and identifier rules” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M01.04-C038-T09 · Uncovered-scope report:** List the “Text and identifier rules” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M01.04-C038-T10 · Limit evidence:** Publish the selected “Text and identifier rules” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M01.04-C039 · Diagnostics / review

**Original checklist item:** Record the rationale, unresolved assumptions, enforcement gaps and re-review triggers for text and identifier rules; make design-only claims visibly distinct from observed behavior.

- [ ] **UC-M01.04-C039-T01 · Review inventory:** List the “Text and identifier rules” decisions and claims requiring review; distinguish source requirements, implementation observations and engineering assumptions.
- [ ] **UC-M01.04-C039-T02 · Rationale record:** Write the rationale for the selected “Text and identifier rules” representation or policy; link each choice to the requirement rather than an unexplained preference.
- [ ] **UC-M01.04-C039-T03 · Assumption ledger:** Record unresolved “Text and identifier rules” assumptions, their owner and what observation or decision would resolve them; do not treat unknowns as approvals.
- [ ] **UC-M01.04-C039-T04 · Boundary map:** Map each “Text and identifier rules” claim to an actual guard or explicit design/review gate; flag gaps against “Normalization cannot silently change an authority-bearing identifier”.
- [ ] **UC-M01.04-C039-T05 · Counterexample review:** Walk reviewers through the “Text and identifier rules” counterexample “Two identifiers collapse to one normalized name”; record whether the model detects it and whether any runtime guard was actually exercised.
- [ ] **UC-M01.04-C039-T06 · Review outcome vocabulary:** Define approved, blocked, superseded and untested review outcomes for “Text and identifier rules”; ensure the wording cannot be read as runtime enforcement evidence.
- [ ] **UC-M01.04-C039-T07 · Re-review triggers:** List “Text and identifier rules” invalidation triggers, including the source change scenario: a manifest is upgraded and then submitted to an older supported reader; identify the affected claims and evidence.
- [ ] **UC-M01.04-C039-T08 · Sensitive-data review:** Inspect the “Text and identifier rules” review record for secrets and unrelated user content; retain nonsecret references sufficient for reproducibility.
- [ ] **UC-M01.04-C039-T09 · Independent reading:** Have the “Text and identifier rules” record read against the original acceptance criterion and manifest readers, canonical digest generation and schema migrations; record misunderstandings or missing evidence as corrections.
- [ ] **UC-M01.04-C039-T10 · Review disposition:** Publish the “Text and identifier rules” rationale, versioned review outcome, unresolved gaps and explicit next decision; keep blockers open until supported evidence resolves them.

### UC-M01.04-C040 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for text and identifier rules; label unexecuted checks as untested.

- [ ] **UC-M01.04-C040-T01 · Evidence inventory:** List the “Text and identifier rules” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M01.04-C040-T02 · Artifact references:** Record the exact “Text and identifier rules” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M01.04-C040-T03 · Fixture references:** Attach the “Text and identifier rules” fixture IDs, input identities and oracle definition; preserve the source counterexample “Two identifiers collapse to one normalized name” as a distinct evidence case.
- [ ] **UC-M01.04-C040-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Text and identifier rules”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M01.04-C040-T05 · Environment record:** Record the actual “Text and identifier rules” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M01.04-C040-T06 · Expected versus observed:** Pair every “Text and identifier rules” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M01.04-C040-T07 · Failure and limit records:** Attach “Text and identifier rules” change/failure and bounds evidence where required; include uncovered “Identifier length and normalization expansion” and unresolved violations of “Normalization cannot silently change an authority-bearing identifier”.
- [ ] **UC-M01.04-C040-T08 · Evidence hygiene:** Check the “Text and identifier rules” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M01.04-C040-T09 · Reproduction review:** Have the “Text and identifier rules” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M01.04-C040-T10 · Acceptance linkage:** Link the “Text and identifier rules” evidence to its parent and UC-M01.04 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 05. Field semantics

**Source delivery:** Document each field's type, units, default, requiredness and authority.

**Source invariant:** An omitted field cannot acquire an unsafe implicit meaning.

**Source negative case:** An absent isolation requirement defaults to weaker isolation.

**Source bounded quantities:** Schema field count and default expansion size.

### UC-M01.04-C041 · Contract

**Original checklist item:** Specify the scope and representation of field semantics; identify its producer, consumer, authority assumptions and explicitly unsupported cases.

- [ ] **UC-M01.04-C041-T01 · Scope statement:** Draft a scope note for “Field semantics” within Canonical manifest and schema evolution; separate required model statements, explicit exclusions and unresolved design decisions.
- [ ] **UC-M01.04-C041-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Field semantics”; record each producer, representation and missing-value meaning.
- [ ] **UC-M01.04-C041-T03 · Output inventory:** List the outputs of “Field semantics” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M01.04-C041-T04 · Field dictionary:** Create a field-and-term dictionary for “Field semantics”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M01.04-C041-T05 · Prerequisite contract:** Map “Field semantics” to the source component prerequisites (UC-M01.02); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M01.04-C041-T06 · Authority map:** Identify who may produce, change and consume “Field semantics”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M01.04-C041-T07 · Invariant clause:** Add a normative clause for “Field semantics” that preserves “An omitted field cannot acquire an unsafe implicit meaning”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M01.04-C041-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Field semantics”; include the source counterexample “An absent isolation requirement defaults to weaker isolation” and the intended safe disposition.
- [ ] **UC-M01.04-C041-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Schema field count and default expansion size” in the “Field semantics” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M01.04-C041-T10 · Contract review:** Review the “Field semantics” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M01.04-C042 · Delivery

**Original checklist item:** Document each field's type, units, default, requiredness and authority.

- [ ] **UC-M01.04-C042-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Field semantics”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M01.04-C042-T02 · Change plan:** Break the source delivery for “Field semantics” into concrete edit targets and reviewable outputs; keep the UC-M01.04 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M01.04-C042-T03 · Core artifact:** Create the “Field semantics” model, schema or inventory that realizes this source instruction: Document each field's type, units, default, requiredness and authority.
- [ ] **UC-M01.04-C042-T04 · Concrete realization:** Populate “Field semantics” with one concrete worked case; map every required entity or field to its source and flag any unmapped entry.
- [ ] **UC-M01.04-C042-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Field semantics” needed to preserve “An omitted field cannot acquire an unsafe implicit meaning”; record an enforcement gap where only a model exists.
- [ ] **UC-M01.04-C042-T06 · Dependency connection:** Connect the “Field semantics” specification to manifest readers, canonical digest generation and schema migrations; record code coverage separately where the design is not yet enforced.
- [ ] **UC-M01.04-C042-T07 · Resource behavior:** Account for “Schema field count and default expansion size” in “Field semantics”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M01.04-C042-T08 · Delivery check:** Walk the populated “Field semantics” model through a valid example and the source counterexample “An absent isolation requirement defaults to weaker isolation”; record corrections and unresolved enforcement gaps.
- [ ] **UC-M01.04-C042-T09 · Patch review:** Review the “Field semantics” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M01.04-C042-T10 · Delivery handoff:** Publish the “Field semantics” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M01.04-C043 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: An omitted field cannot acquire an unsafe implicit meaning. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M01.04-C043-T01 · Named property:** Create a stable property/check name under this parent for “Field semantics”; copy its required invariant exactly: “An omitted field cannot acquire an unsafe implicit meaning”.
- [ ] **UC-M01.04-C043-T02 · Observable terms:** Define each term in the “Field semantics” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M01.04-C043-T03 · Precondition set:** List the preconditions under which “An omitted field cannot acquire an unsafe implicit meaning” must hold for “Field semantics”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M01.04-C043-T04 · Transition coverage:** Map the “Field semantics” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M01.04-C043-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Field semantics”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M01.04-C043-T06 · Satisfying fixture:** Create a concrete “Field semantics” case that satisfies “An omitted field cannot acquire an unsafe implicit meaning”; record its expected observation before running the assertion or review.
- [ ] **UC-M01.04-C043-T07 · Violating fixture:** Create the source counterexample “An absent isolation requirement defaults to weaker isolation” for “Field semantics”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M01.04-C043-T08 · Enforcement evidence:** Exercise the “Field semantics” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M01.04-C043-T09 · Regression linkage:** Link the “Field semantics” property to changes in manifest readers, canonical digest generation and schema migrations; record which dependency or contract changes require rerunning it.
- [ ] **UC-M01.04-C043-T10 · Property disposition:** Compare the satisfying and violating “Field semantics” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M01.04-C044 · Integration

**Original checklist item:** Integrate field semantics with manifest readers, canonical digest generation and schema migrations; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M01.04-C044-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Field semantics” across manifest readers, canonical digest generation and schema migrations; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M01.04-C044-T02 · Field mapping:** Map every “Field semantics” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M01.04-C044-T03 · Prerequisite identities:** Record the actual prerequisites for “Field semantics” (source dependency list: UC-M01.02); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M01.04-C044-T04 · Ownership agreement:** Specify who owns “Field semantics” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M01.04-C044-T05 · Handoff implementation:** Connect “Field semantics” through the mapped seam using the real adapter or explicit specification reference; preserve “An omitted field cannot acquire an unsafe implicit meaning” across the handoff.
- [ ] **UC-M01.04-C044-T06 · Absent-input case:** Omit one required “Field semantics” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M01.04-C044-T07 · Stale-input case:** Supply an outdated “Field semantics” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M01.04-C044-T08 · Incompatible-input case:** Supply an incompatible “Field semantics” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M01.04-C044-T09 · Valid integration trace:** Run a valid “Field semantics” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M01.04-C044-T10 · Seam review:** Reconcile the “Field semantics” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M01.04-C045 · Valid-case test

**Original checklist item:** Construct a valid worked example for field semantics; evaluate it against predeclared expected decisions and, where enforcement exists, run the corresponding conformance fixture.

- [ ] **UC-M01.04-C045-T01 · Valid fixture choice:** Select one concrete valid worked example for “Field semantics”; enumerate the model inputs and the expected review decision before evaluating it.
- [ ] **UC-M01.04-C045-T02 · Expected-result oracle:** Specify the “Field semantics” expected result independently of the implementation output; include the property “An omitted field cannot acquire an unsafe implicit meaning” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M01.04-C045-T03 · Fixture material:** Create the concrete “Field semantics” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M01.04-C045-T04 · Target preparation:** Prepare the “Field semantics” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M01.04-C045-T05 · Initial-state record:** Record the initial “Field semantics” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M01.04-C045-T06 · Valid-path execution:** Evaluate the “Field semantics” example against the reviewed model; where a runtime mechanism exists, run its corresponding fixture and label those observations separately.
- [ ] **UC-M01.04-C045-T07 · Outcome comparison:** Compare every declared “Field semantics” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M01.04-C045-T08 · State and bounds check:** Inspect the “Field semantics” ownership/state effects and actual use of “Schema field count and default expansion size”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M01.04-C045-T09 · Repeatability check:** Repeat the same “Field semantics” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M01.04-C045-T10 · Positive evidence:** Attach the “Field semantics” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M01.04-C046 · Negative test

**Original checklist item:** Negative case: An absent isolation requirement defaults to weaker isolation. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M01.04-C046-T01 · Adverse-case definition:** Create a test record for the exact “Field semantics” source counterexample: “An absent isolation requirement defaults to weaker isolation”; state which precondition or invariant it challenges.
- [ ] **UC-M01.04-C046-T02 · Safe fixture boundary:** Define the contained test boundary for “Field semantics”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M01.04-C046-T03 · Valid control:** Construct a valid “Field semantics” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M01.04-C046-T04 · Minimal adverse input:** Derive the “Field semantics” adverse fixture from the control with the smallest documented change needed to reproduce “An absent isolation requirement defaults to weaker isolation”; retain that change as reproducible data.
- [ ] **UC-M01.04-C046-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Field semantics”; require “An omitted field cannot acquire an unsafe implicit meaning” and forbid a false-success verdict.
- [ ] **UC-M01.04-C046-T06 · Adverse execution:** Evaluate the “Field semantics” adverse case through the actual review/contract gate; where implemented, also observe the runtime refusal and keep the two evidence classes separate.
- [ ] **UC-M01.04-C046-T07 · Effect inspection:** Inspect “Field semantics” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M01.04-C046-T08 · Refusal versus failure:** Confirm the “Field semantics” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M01.04-C046-T09 · Reset and retention:** Restore only the disposable “Field semantics” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M01.04-C046-T10 · Negative regression:** Register the “Field semantics” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M01.04-C047 · Change / failure test

**Original checklist item:** Exercise field semantics when a manifest is upgraded and then submitted to an older supported reader; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M01.04-C047-T01 · Scenario record:** Write the “Field semantics” change/failure scenario exactly as supplied: a manifest is upgraded and then submitted to an older supported reader; identify the property that must remain true: “An omitted field cannot acquire an unsafe implicit meaning”.
- [ ] **UC-M01.04-C047-T02 · Baseline capture:** Create a known-valid “Field semantics” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M01.04-C047-T03 · Injection map:** Locate the “Field semantics” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M01.04-C047-T04 · Disposition oracle:** Define the legal intermediate and final “Field semantics” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M01.04-C047-T05 · Controlled trigger:** Apply the controlled model-change scenario for “Field semantics”: a manifest is upgraded and then submitted to an older supported reader; retain the exact before/after declarations. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M01.04-C047-T06 · Intermediate inspection:** Review which “Field semantics” claims, approvals and evidence references become stale after the change; keep unresolved enforcement gaps visible.
- [ ] **UC-M01.04-C047-T07 · Recovery path:** Revise or explicitly refuse the changed “Field semantics” model under the documented compatibility policy; re-review affected claims before restoring their approval.
- [ ] **UC-M01.04-C047-T08 · Stale-evidence cleanup:** Invalidate superseded “Field semantics” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M01.04-C047-T09 · Repeat and compare:** Repeat the selected “Field semantics” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M01.04-C047-T10 · Failure evidence:** Publish the “Field semantics” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M01.04-C048 · Bounds

**Original checklist item:** Define completeness and scaling criteria for schema field count and default expansion size; exercise larger inventories or fixture sets, and report uncovered scope instead of silently excluding it.

- [ ] **UC-M01.04-C048-T01 · Quantity inventory:** Create a measurement inventory for “Field semantics”: “Schema field count and default expansion size”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M01.04-C048-T02 · Measurement method:** Choose how to observe each “Field semantics” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M01.04-C048-T03 · Budget decision:** Select justified coverage and completeness limits for “Field semantics”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M01.04-C048-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Field semantics” cases for “Schema field count and default expansion size”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M01.04-C048-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Field semantics” limit; preserve “An omitted field cannot acquire an unsafe implicit meaning”.
- [ ] **UC-M01.04-C048-T06 · Normal measurement:** Run or review the normal “Field semantics” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M01.04-C048-T07 · At-limit measurement:** Exercise the “Field semantics” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M01.04-C048-T08 · Over-limit measurement:** Exercise the “Field semantics” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M01.04-C048-T09 · Uncovered-scope report:** List the “Field semantics” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M01.04-C048-T10 · Limit evidence:** Publish the selected “Field semantics” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M01.04-C049 · Diagnostics / review

**Original checklist item:** Record the rationale, unresolved assumptions, enforcement gaps and re-review triggers for field semantics; make design-only claims visibly distinct from observed behavior.

- [ ] **UC-M01.04-C049-T01 · Review inventory:** List the “Field semantics” decisions and claims requiring review; distinguish source requirements, implementation observations and engineering assumptions.
- [ ] **UC-M01.04-C049-T02 · Rationale record:** Write the rationale for the selected “Field semantics” representation or policy; link each choice to the requirement rather than an unexplained preference.
- [ ] **UC-M01.04-C049-T03 · Assumption ledger:** Record unresolved “Field semantics” assumptions, their owner and what observation or decision would resolve them; do not treat unknowns as approvals.
- [ ] **UC-M01.04-C049-T04 · Boundary map:** Map each “Field semantics” claim to an actual guard or explicit design/review gate; flag gaps against “An omitted field cannot acquire an unsafe implicit meaning”.
- [ ] **UC-M01.04-C049-T05 · Counterexample review:** Walk reviewers through the “Field semantics” counterexample “An absent isolation requirement defaults to weaker isolation”; record whether the model detects it and whether any runtime guard was actually exercised.
- [ ] **UC-M01.04-C049-T06 · Review outcome vocabulary:** Define approved, blocked, superseded and untested review outcomes for “Field semantics”; ensure the wording cannot be read as runtime enforcement evidence.
- [ ] **UC-M01.04-C049-T07 · Re-review triggers:** List “Field semantics” invalidation triggers, including the source change scenario: a manifest is upgraded and then submitted to an older supported reader; identify the affected claims and evidence.
- [ ] **UC-M01.04-C049-T08 · Sensitive-data review:** Inspect the “Field semantics” review record for secrets and unrelated user content; retain nonsecret references sufficient for reproducibility.
- [ ] **UC-M01.04-C049-T09 · Independent reading:** Have the “Field semantics” record read against the original acceptance criterion and manifest readers, canonical digest generation and schema migrations; record misunderstandings or missing evidence as corrections.
- [ ] **UC-M01.04-C049-T10 · Review disposition:** Publish the “Field semantics” rationale, versioned review outcome, unresolved gaps and explicit next decision; keep blockers open until supported evidence resolves them.

### UC-M01.04-C050 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for field semantics; label unexecuted checks as untested.

- [ ] **UC-M01.04-C050-T01 · Evidence inventory:** List the “Field semantics” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M01.04-C050-T02 · Artifact references:** Record the exact “Field semantics” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M01.04-C050-T03 · Fixture references:** Attach the “Field semantics” fixture IDs, input identities and oracle definition; preserve the source counterexample “An absent isolation requirement defaults to weaker isolation” as a distinct evidence case.
- [ ] **UC-M01.04-C050-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Field semantics”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M01.04-C050-T05 · Environment record:** Record the actual “Field semantics” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M01.04-C050-T06 · Expected versus observed:** Pair every “Field semantics” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M01.04-C050-T07 · Failure and limit records:** Attach “Field semantics” change/failure and bounds evidence where required; include uncovered “Schema field count and default expansion size” and unresolved violations of “An omitted field cannot acquire an unsafe implicit meaning”.
- [ ] **UC-M01.04-C050-T08 · Evidence hygiene:** Check the “Field semantics” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M01.04-C050-T09 · Reproduction review:** Have the “Field semantics” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M01.04-C050-T10 · Acceptance linkage:** Link the “Field semantics” evidence to its parent and UC-M01.04 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 06. Schema version identity

**Source delivery:** Bind each manifest to an explicit schema version and compatibility policy.

**Source invariant:** Unknown incompatible schemas fail before use.

**Source negative case:** A newer schema is processed as an older one.

**Source bounded quantities:** Version history and supported migration span.

### UC-M01.04-C051 · Contract

**Original checklist item:** Specify the scope and representation of schema version identity; identify its producer, consumer, authority assumptions and explicitly unsupported cases.

- [ ] **UC-M01.04-C051-T01 · Scope statement:** Draft a scope note for “Schema version identity” within Canonical manifest and schema evolution; separate required model statements, explicit exclusions and unresolved design decisions.
- [ ] **UC-M01.04-C051-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Schema version identity”; record each producer, representation and missing-value meaning.
- [ ] **UC-M01.04-C051-T03 · Output inventory:** List the outputs of “Schema version identity” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M01.04-C051-T04 · Field dictionary:** Create a field-and-term dictionary for “Schema version identity”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M01.04-C051-T05 · Prerequisite contract:** Map “Schema version identity” to the source component prerequisites (UC-M01.02); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M01.04-C051-T06 · Authority map:** Identify who may produce, change and consume “Schema version identity”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M01.04-C051-T07 · Invariant clause:** Add a normative clause for “Schema version identity” that preserves “Unknown incompatible schemas fail before use”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M01.04-C051-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Schema version identity”; include the source counterexample “A newer schema is processed as an older one” and the intended safe disposition.
- [ ] **UC-M01.04-C051-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Version history and supported migration span” in the “Schema version identity” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M01.04-C051-T10 · Contract review:** Review the “Schema version identity” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M01.04-C052 · Delivery

**Original checklist item:** Bind each manifest to an explicit schema version and compatibility policy.

- [ ] **UC-M01.04-C052-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Schema version identity”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M01.04-C052-T02 · Change plan:** Break the source delivery for “Schema version identity” into concrete edit targets and reviewable outputs; keep the UC-M01.04 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M01.04-C052-T03 · Core artifact:** Implement the smallest selected-profile change for “Schema version identity” that realizes this source instruction: Bind each manifest to an explicit schema version and compatibility policy.
- [ ] **UC-M01.04-C052-T04 · Concrete realization:** Trace “Schema version identity” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M01.04-C052-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Schema version identity” needed to preserve “Unknown incompatible schemas fail before use”; record an enforcement gap where only a model exists.
- [ ] **UC-M01.04-C052-T06 · Dependency connection:** Connect the “Schema version identity” specification to manifest readers, canonical digest generation and schema migrations; record code coverage separately where the design is not yet enforced.
- [ ] **UC-M01.04-C052-T07 · Resource behavior:** Account for “Version history and supported migration span” in “Schema version identity”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M01.04-C052-T08 · Delivery check:** Walk the populated “Schema version identity” model through a valid example and the source counterexample “A newer schema is processed as an older one”; record corrections and unresolved enforcement gaps.
- [ ] **UC-M01.04-C052-T09 · Patch review:** Review the “Schema version identity” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M01.04-C052-T10 · Delivery handoff:** Publish the “Schema version identity” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M01.04-C053 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Unknown incompatible schemas fail before use. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M01.04-C053-T01 · Named property:** Create a stable property/check name under this parent for “Schema version identity”; copy its required invariant exactly: “Unknown incompatible schemas fail before use”.
- [ ] **UC-M01.04-C053-T02 · Observable terms:** Define each term in the “Schema version identity” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M01.04-C053-T03 · Precondition set:** List the preconditions under which “Unknown incompatible schemas fail before use” must hold for “Schema version identity”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M01.04-C053-T04 · Transition coverage:** Map the “Schema version identity” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M01.04-C053-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Schema version identity”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M01.04-C053-T06 · Satisfying fixture:** Create a concrete “Schema version identity” case that satisfies “Unknown incompatible schemas fail before use”; record its expected observation before running the assertion or review.
- [ ] **UC-M01.04-C053-T07 · Violating fixture:** Create the source counterexample “A newer schema is processed as an older one” for “Schema version identity”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M01.04-C053-T08 · Enforcement evidence:** Exercise the “Schema version identity” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M01.04-C053-T09 · Regression linkage:** Link the “Schema version identity” property to changes in manifest readers, canonical digest generation and schema migrations; record which dependency or contract changes require rerunning it.
- [ ] **UC-M01.04-C053-T10 · Property disposition:** Compare the satisfying and violating “Schema version identity” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M01.04-C054 · Integration

**Original checklist item:** Integrate schema version identity with manifest readers, canonical digest generation and schema migrations; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M01.04-C054-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Schema version identity” across manifest readers, canonical digest generation and schema migrations; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M01.04-C054-T02 · Field mapping:** Map every “Schema version identity” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M01.04-C054-T03 · Prerequisite identities:** Record the actual prerequisites for “Schema version identity” (source dependency list: UC-M01.02); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M01.04-C054-T04 · Ownership agreement:** Specify who owns “Schema version identity” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M01.04-C054-T05 · Handoff implementation:** Connect “Schema version identity” through the mapped seam using the real adapter or explicit specification reference; preserve “Unknown incompatible schemas fail before use” across the handoff.
- [ ] **UC-M01.04-C054-T06 · Absent-input case:** Omit one required “Schema version identity” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M01.04-C054-T07 · Stale-input case:** Supply an outdated “Schema version identity” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M01.04-C054-T08 · Incompatible-input case:** Supply an incompatible “Schema version identity” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M01.04-C054-T09 · Valid integration trace:** Run a valid “Schema version identity” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M01.04-C054-T10 · Seam review:** Reconcile the “Schema version identity” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M01.04-C055 · Valid-case test

**Original checklist item:** Construct a valid worked example for schema version identity; evaluate it against predeclared expected decisions and, where enforcement exists, run the corresponding conformance fixture.

- [ ] **UC-M01.04-C055-T01 · Valid fixture choice:** Select one concrete valid worked example for “Schema version identity”; enumerate the model inputs and the expected review decision before evaluating it.
- [ ] **UC-M01.04-C055-T02 · Expected-result oracle:** Specify the “Schema version identity” expected result independently of the implementation output; include the property “Unknown incompatible schemas fail before use” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M01.04-C055-T03 · Fixture material:** Create the concrete “Schema version identity” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M01.04-C055-T04 · Target preparation:** Prepare the “Schema version identity” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M01.04-C055-T05 · Initial-state record:** Record the initial “Schema version identity” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M01.04-C055-T06 · Valid-path execution:** Evaluate the “Schema version identity” example against the reviewed model; where a runtime mechanism exists, run its corresponding fixture and label those observations separately.
- [ ] **UC-M01.04-C055-T07 · Outcome comparison:** Compare every declared “Schema version identity” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M01.04-C055-T08 · State and bounds check:** Inspect the “Schema version identity” ownership/state effects and actual use of “Version history and supported migration span”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M01.04-C055-T09 · Repeatability check:** Repeat the same “Schema version identity” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M01.04-C055-T10 · Positive evidence:** Attach the “Schema version identity” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M01.04-C056 · Negative test

**Original checklist item:** Negative case: A newer schema is processed as an older one. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M01.04-C056-T01 · Adverse-case definition:** Create a test record for the exact “Schema version identity” source counterexample: “A newer schema is processed as an older one”; state which precondition or invariant it challenges.
- [ ] **UC-M01.04-C056-T02 · Safe fixture boundary:** Define the contained test boundary for “Schema version identity”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M01.04-C056-T03 · Valid control:** Construct a valid “Schema version identity” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M01.04-C056-T04 · Minimal adverse input:** Derive the “Schema version identity” adverse fixture from the control with the smallest documented change needed to reproduce “A newer schema is processed as an older one”; retain that change as reproducible data.
- [ ] **UC-M01.04-C056-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Schema version identity”; require “Unknown incompatible schemas fail before use” and forbid a false-success verdict.
- [ ] **UC-M01.04-C056-T06 · Adverse execution:** Evaluate the “Schema version identity” adverse case through the actual review/contract gate; where implemented, also observe the runtime refusal and keep the two evidence classes separate.
- [ ] **UC-M01.04-C056-T07 · Effect inspection:** Inspect “Schema version identity” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M01.04-C056-T08 · Refusal versus failure:** Confirm the “Schema version identity” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M01.04-C056-T09 · Reset and retention:** Restore only the disposable “Schema version identity” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M01.04-C056-T10 · Negative regression:** Register the “Schema version identity” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M01.04-C057 · Change / failure test

**Original checklist item:** Exercise schema version identity when a manifest is upgraded and then submitted to an older supported reader; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M01.04-C057-T01 · Scenario record:** Write the “Schema version identity” change/failure scenario exactly as supplied: a manifest is upgraded and then submitted to an older supported reader; identify the property that must remain true: “Unknown incompatible schemas fail before use”.
- [ ] **UC-M01.04-C057-T02 · Baseline capture:** Create a known-valid “Schema version identity” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M01.04-C057-T03 · Injection map:** Locate the “Schema version identity” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M01.04-C057-T04 · Disposition oracle:** Define the legal intermediate and final “Schema version identity” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M01.04-C057-T05 · Controlled trigger:** Apply the controlled model-change scenario for “Schema version identity”: a manifest is upgraded and then submitted to an older supported reader; retain the exact before/after declarations. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M01.04-C057-T06 · Intermediate inspection:** Review which “Schema version identity” claims, approvals and evidence references become stale after the change; keep unresolved enforcement gaps visible.
- [ ] **UC-M01.04-C057-T07 · Recovery path:** Revise or explicitly refuse the changed “Schema version identity” model under the documented compatibility policy; re-review affected claims before restoring their approval.
- [ ] **UC-M01.04-C057-T08 · Stale-evidence cleanup:** Invalidate superseded “Schema version identity” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M01.04-C057-T09 · Repeat and compare:** Repeat the selected “Schema version identity” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M01.04-C057-T10 · Failure evidence:** Publish the “Schema version identity” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M01.04-C058 · Bounds

**Original checklist item:** Define completeness and scaling criteria for version history and supported migration span; exercise larger inventories or fixture sets, and report uncovered scope instead of silently excluding it.

- [ ] **UC-M01.04-C058-T01 · Quantity inventory:** Create a measurement inventory for “Schema version identity”: “Version history and supported migration span”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M01.04-C058-T02 · Measurement method:** Choose how to observe each “Schema version identity” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M01.04-C058-T03 · Budget decision:** Select justified coverage and completeness limits for “Schema version identity”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M01.04-C058-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Schema version identity” cases for “Version history and supported migration span”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M01.04-C058-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Schema version identity” limit; preserve “Unknown incompatible schemas fail before use”.
- [ ] **UC-M01.04-C058-T06 · Normal measurement:** Run or review the normal “Schema version identity” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M01.04-C058-T07 · At-limit measurement:** Exercise the “Schema version identity” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M01.04-C058-T08 · Over-limit measurement:** Exercise the “Schema version identity” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M01.04-C058-T09 · Uncovered-scope report:** List the “Schema version identity” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M01.04-C058-T10 · Limit evidence:** Publish the selected “Schema version identity” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M01.04-C059 · Diagnostics / review

**Original checklist item:** Record the rationale, unresolved assumptions, enforcement gaps and re-review triggers for schema version identity; make design-only claims visibly distinct from observed behavior.

- [ ] **UC-M01.04-C059-T01 · Review inventory:** List the “Schema version identity” decisions and claims requiring review; distinguish source requirements, implementation observations and engineering assumptions.
- [ ] **UC-M01.04-C059-T02 · Rationale record:** Write the rationale for the selected “Schema version identity” representation or policy; link each choice to the requirement rather than an unexplained preference.
- [ ] **UC-M01.04-C059-T03 · Assumption ledger:** Record unresolved “Schema version identity” assumptions, their owner and what observation or decision would resolve them; do not treat unknowns as approvals.
- [ ] **UC-M01.04-C059-T04 · Boundary map:** Map each “Schema version identity” claim to an actual guard or explicit design/review gate; flag gaps against “Unknown incompatible schemas fail before use”.
- [ ] **UC-M01.04-C059-T05 · Counterexample review:** Walk reviewers through the “Schema version identity” counterexample “A newer schema is processed as an older one”; record whether the model detects it and whether any runtime guard was actually exercised.
- [ ] **UC-M01.04-C059-T06 · Review outcome vocabulary:** Define approved, blocked, superseded and untested review outcomes for “Schema version identity”; ensure the wording cannot be read as runtime enforcement evidence.
- [ ] **UC-M01.04-C059-T07 · Re-review triggers:** List “Schema version identity” invalidation triggers, including the source change scenario: a manifest is upgraded and then submitted to an older supported reader; identify the affected claims and evidence.
- [ ] **UC-M01.04-C059-T08 · Sensitive-data review:** Inspect the “Schema version identity” review record for secrets and unrelated user content; retain nonsecret references sufficient for reproducibility.
- [ ] **UC-M01.04-C059-T09 · Independent reading:** Have the “Schema version identity” record read against the original acceptance criterion and manifest readers, canonical digest generation and schema migrations; record misunderstandings or missing evidence as corrections.
- [ ] **UC-M01.04-C059-T10 · Review disposition:** Publish the “Schema version identity” rationale, versioned review outcome, unresolved gaps and explicit next decision; keep blockers open until supported evidence resolves them.

### UC-M01.04-C060 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for schema version identity; label unexecuted checks as untested.

- [ ] **UC-M01.04-C060-T01 · Evidence inventory:** List the “Schema version identity” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M01.04-C060-T02 · Artifact references:** Record the exact “Schema version identity” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M01.04-C060-T03 · Fixture references:** Attach the “Schema version identity” fixture IDs, input identities and oracle definition; preserve the source counterexample “A newer schema is processed as an older one” as a distinct evidence case.
- [ ] **UC-M01.04-C060-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Schema version identity”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M01.04-C060-T05 · Environment record:** Record the actual “Schema version identity” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M01.04-C060-T06 · Expected versus observed:** Pair every “Schema version identity” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M01.04-C060-T07 · Failure and limit records:** Attach “Schema version identity” change/failure and bounds evidence where required; include uncovered “Version history and supported migration span” and unresolved violations of “Unknown incompatible schemas fail before use”.
- [ ] **UC-M01.04-C060-T08 · Evidence hygiene:** Check the “Schema version identity” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M01.04-C060-T09 · Reproduction review:** Have the “Schema version identity” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M01.04-C060-T10 · Acceptance linkage:** Link the “Schema version identity” evidence to its parent and UC-M01.04 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 07. Migration transformations

**Source delivery:** Implement explicit validated transformations between supported schemas.

**Source invariant:** Migration preserves defined semantics and original identity bindings.

**Source negative case:** A migration drops a required policy field.

**Source bounded quantities:** Migration input size and number of transformation steps.

### UC-M01.04-C061 · Contract

**Original checklist item:** Specify the scope and representation of migration transformations; identify its producer, consumer, authority assumptions and explicitly unsupported cases.

- [ ] **UC-M01.04-C061-T01 · Scope statement:** Draft a scope note for “Migration transformations” within Canonical manifest and schema evolution; separate required model statements, explicit exclusions and unresolved design decisions.
- [ ] **UC-M01.04-C061-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Migration transformations”; record each producer, representation and missing-value meaning.
- [ ] **UC-M01.04-C061-T03 · Output inventory:** List the outputs of “Migration transformations” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M01.04-C061-T04 · Field dictionary:** Create a field-and-term dictionary for “Migration transformations”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M01.04-C061-T05 · Prerequisite contract:** Map “Migration transformations” to the source component prerequisites (UC-M01.02); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M01.04-C061-T06 · Authority map:** Identify who may produce, change and consume “Migration transformations”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M01.04-C061-T07 · Invariant clause:** Add a normative clause for “Migration transformations” that preserves “Migration preserves defined semantics and original identity bindings”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M01.04-C061-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Migration transformations”; include the source counterexample “A migration drops a required policy field” and the intended safe disposition.
- [ ] **UC-M01.04-C061-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Migration input size and number of transformation steps” in the “Migration transformations” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M01.04-C061-T10 · Contract review:** Review the “Migration transformations” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M01.04-C062 · Delivery

**Original checklist item:** Implement explicit validated transformations between supported schemas.

- [ ] **UC-M01.04-C062-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Migration transformations”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M01.04-C062-T02 · Change plan:** Break the source delivery for “Migration transformations” into concrete edit targets and reviewable outputs; keep the UC-M01.04 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M01.04-C062-T03 · Core artifact:** Implement the smallest selected-profile change for “Migration transformations” that realizes this source instruction: Implement explicit validated transformations between supported schemas.
- [ ] **UC-M01.04-C062-T04 · Concrete realization:** Trace “Migration transformations” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M01.04-C062-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Migration transformations” needed to preserve “Migration preserves defined semantics and original identity bindings”; record an enforcement gap where only a model exists.
- [ ] **UC-M01.04-C062-T06 · Dependency connection:** Connect the “Migration transformations” specification to manifest readers, canonical digest generation and schema migrations; record code coverage separately where the design is not yet enforced.
- [ ] **UC-M01.04-C062-T07 · Resource behavior:** Account for “Migration input size and number of transformation steps” in “Migration transformations”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M01.04-C062-T08 · Delivery check:** Walk the populated “Migration transformations” model through a valid example and the source counterexample “A migration drops a required policy field”; record corrections and unresolved enforcement gaps.
- [ ] **UC-M01.04-C062-T09 · Patch review:** Review the “Migration transformations” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M01.04-C062-T10 · Delivery handoff:** Publish the “Migration transformations” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M01.04-C063 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Migration preserves defined semantics and original identity bindings. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M01.04-C063-T01 · Named property:** Create a stable property/check name under this parent for “Migration transformations”; copy its required invariant exactly: “Migration preserves defined semantics and original identity bindings”.
- [ ] **UC-M01.04-C063-T02 · Observable terms:** Define each term in the “Migration transformations” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M01.04-C063-T03 · Precondition set:** List the preconditions under which “Migration preserves defined semantics and original identity bindings” must hold for “Migration transformations”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M01.04-C063-T04 · Transition coverage:** Map the “Migration transformations” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M01.04-C063-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Migration transformations”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M01.04-C063-T06 · Satisfying fixture:** Create a concrete “Migration transformations” case that satisfies “Migration preserves defined semantics and original identity bindings”; record its expected observation before running the assertion or review.
- [ ] **UC-M01.04-C063-T07 · Violating fixture:** Create the source counterexample “A migration drops a required policy field” for “Migration transformations”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M01.04-C063-T08 · Enforcement evidence:** Exercise the “Migration transformations” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M01.04-C063-T09 · Regression linkage:** Link the “Migration transformations” property to changes in manifest readers, canonical digest generation and schema migrations; record which dependency or contract changes require rerunning it.
- [ ] **UC-M01.04-C063-T10 · Property disposition:** Compare the satisfying and violating “Migration transformations” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M01.04-C064 · Integration

**Original checklist item:** Integrate migration transformations with manifest readers, canonical digest generation and schema migrations; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M01.04-C064-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Migration transformations” across manifest readers, canonical digest generation and schema migrations; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M01.04-C064-T02 · Field mapping:** Map every “Migration transformations” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M01.04-C064-T03 · Prerequisite identities:** Record the actual prerequisites for “Migration transformations” (source dependency list: UC-M01.02); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M01.04-C064-T04 · Ownership agreement:** Specify who owns “Migration transformations” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M01.04-C064-T05 · Handoff implementation:** Connect “Migration transformations” through the mapped seam using the real adapter or explicit specification reference; preserve “Migration preserves defined semantics and original identity bindings” across the handoff.
- [ ] **UC-M01.04-C064-T06 · Absent-input case:** Omit one required “Migration transformations” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M01.04-C064-T07 · Stale-input case:** Supply an outdated “Migration transformations” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M01.04-C064-T08 · Incompatible-input case:** Supply an incompatible “Migration transformations” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M01.04-C064-T09 · Valid integration trace:** Run a valid “Migration transformations” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M01.04-C064-T10 · Seam review:** Reconcile the “Migration transformations” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M01.04-C065 · Valid-case test

**Original checklist item:** Construct a valid worked example for migration transformations; evaluate it against predeclared expected decisions and, where enforcement exists, run the corresponding conformance fixture.

- [ ] **UC-M01.04-C065-T01 · Valid fixture choice:** Select one concrete valid worked example for “Migration transformations”; enumerate the model inputs and the expected review decision before evaluating it.
- [ ] **UC-M01.04-C065-T02 · Expected-result oracle:** Specify the “Migration transformations” expected result independently of the implementation output; include the property “Migration preserves defined semantics and original identity bindings” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M01.04-C065-T03 · Fixture material:** Create the concrete “Migration transformations” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M01.04-C065-T04 · Target preparation:** Prepare the “Migration transformations” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M01.04-C065-T05 · Initial-state record:** Record the initial “Migration transformations” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M01.04-C065-T06 · Valid-path execution:** Evaluate the “Migration transformations” example against the reviewed model; where a runtime mechanism exists, run its corresponding fixture and label those observations separately.
- [ ] **UC-M01.04-C065-T07 · Outcome comparison:** Compare every declared “Migration transformations” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M01.04-C065-T08 · State and bounds check:** Inspect the “Migration transformations” ownership/state effects and actual use of “Migration input size and number of transformation steps”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M01.04-C065-T09 · Repeatability check:** Repeat the same “Migration transformations” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M01.04-C065-T10 · Positive evidence:** Attach the “Migration transformations” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M01.04-C066 · Negative test

**Original checklist item:** Negative case: A migration drops a required policy field. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M01.04-C066-T01 · Adverse-case definition:** Create a test record for the exact “Migration transformations” source counterexample: “A migration drops a required policy field”; state which precondition or invariant it challenges.
- [ ] **UC-M01.04-C066-T02 · Safe fixture boundary:** Define the contained test boundary for “Migration transformations”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M01.04-C066-T03 · Valid control:** Construct a valid “Migration transformations” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M01.04-C066-T04 · Minimal adverse input:** Derive the “Migration transformations” adverse fixture from the control with the smallest documented change needed to reproduce “A migration drops a required policy field”; retain that change as reproducible data.
- [ ] **UC-M01.04-C066-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Migration transformations”; require “Migration preserves defined semantics and original identity bindings” and forbid a false-success verdict.
- [ ] **UC-M01.04-C066-T06 · Adverse execution:** Evaluate the “Migration transformations” adverse case through the actual review/contract gate; where implemented, also observe the runtime refusal and keep the two evidence classes separate.
- [ ] **UC-M01.04-C066-T07 · Effect inspection:** Inspect “Migration transformations” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M01.04-C066-T08 · Refusal versus failure:** Confirm the “Migration transformations” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M01.04-C066-T09 · Reset and retention:** Restore only the disposable “Migration transformations” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M01.04-C066-T10 · Negative regression:** Register the “Migration transformations” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M01.04-C067 · Change / failure test

**Original checklist item:** Exercise migration transformations when a manifest is upgraded and then submitted to an older supported reader; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M01.04-C067-T01 · Scenario record:** Write the “Migration transformations” change/failure scenario exactly as supplied: a manifest is upgraded and then submitted to an older supported reader; identify the property that must remain true: “Migration preserves defined semantics and original identity bindings”.
- [ ] **UC-M01.04-C067-T02 · Baseline capture:** Create a known-valid “Migration transformations” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M01.04-C067-T03 · Injection map:** Locate the “Migration transformations” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M01.04-C067-T04 · Disposition oracle:** Define the legal intermediate and final “Migration transformations” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M01.04-C067-T05 · Controlled trigger:** Apply the controlled model-change scenario for “Migration transformations”: a manifest is upgraded and then submitted to an older supported reader; retain the exact before/after declarations. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M01.04-C067-T06 · Intermediate inspection:** Review which “Migration transformations” claims, approvals and evidence references become stale after the change; keep unresolved enforcement gaps visible.
- [ ] **UC-M01.04-C067-T07 · Recovery path:** Revise or explicitly refuse the changed “Migration transformations” model under the documented compatibility policy; re-review affected claims before restoring their approval.
- [ ] **UC-M01.04-C067-T08 · Stale-evidence cleanup:** Invalidate superseded “Migration transformations” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M01.04-C067-T09 · Repeat and compare:** Repeat the selected “Migration transformations” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M01.04-C067-T10 · Failure evidence:** Publish the “Migration transformations” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M01.04-C068 · Bounds

**Original checklist item:** Define completeness and scaling criteria for migration input size and number of transformation steps; exercise larger inventories or fixture sets, and report uncovered scope instead of silently excluding it.

- [ ] **UC-M01.04-C068-T01 · Quantity inventory:** Create a measurement inventory for “Migration transformations”: “Migration input size and number of transformation steps”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M01.04-C068-T02 · Measurement method:** Choose how to observe each “Migration transformations” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M01.04-C068-T03 · Budget decision:** Select justified coverage and completeness limits for “Migration transformations”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M01.04-C068-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Migration transformations” cases for “Migration input size and number of transformation steps”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M01.04-C068-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Migration transformations” limit; preserve “Migration preserves defined semantics and original identity bindings”.
- [ ] **UC-M01.04-C068-T06 · Normal measurement:** Run or review the normal “Migration transformations” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M01.04-C068-T07 · At-limit measurement:** Exercise the “Migration transformations” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M01.04-C068-T08 · Over-limit measurement:** Exercise the “Migration transformations” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M01.04-C068-T09 · Uncovered-scope report:** List the “Migration transformations” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M01.04-C068-T10 · Limit evidence:** Publish the selected “Migration transformations” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M01.04-C069 · Diagnostics / review

**Original checklist item:** Record the rationale, unresolved assumptions, enforcement gaps and re-review triggers for migration transformations; make design-only claims visibly distinct from observed behavior.

- [ ] **UC-M01.04-C069-T01 · Review inventory:** List the “Migration transformations” decisions and claims requiring review; distinguish source requirements, implementation observations and engineering assumptions.
- [ ] **UC-M01.04-C069-T02 · Rationale record:** Write the rationale for the selected “Migration transformations” representation or policy; link each choice to the requirement rather than an unexplained preference.
- [ ] **UC-M01.04-C069-T03 · Assumption ledger:** Record unresolved “Migration transformations” assumptions, their owner and what observation or decision would resolve them; do not treat unknowns as approvals.
- [ ] **UC-M01.04-C069-T04 · Boundary map:** Map each “Migration transformations” claim to an actual guard or explicit design/review gate; flag gaps against “Migration preserves defined semantics and original identity bindings”.
- [ ] **UC-M01.04-C069-T05 · Counterexample review:** Walk reviewers through the “Migration transformations” counterexample “A migration drops a required policy field”; record whether the model detects it and whether any runtime guard was actually exercised.
- [ ] **UC-M01.04-C069-T06 · Review outcome vocabulary:** Define approved, blocked, superseded and untested review outcomes for “Migration transformations”; ensure the wording cannot be read as runtime enforcement evidence.
- [ ] **UC-M01.04-C069-T07 · Re-review triggers:** List “Migration transformations” invalidation triggers, including the source change scenario: a manifest is upgraded and then submitted to an older supported reader; identify the affected claims and evidence.
- [ ] **UC-M01.04-C069-T08 · Sensitive-data review:** Inspect the “Migration transformations” review record for secrets and unrelated user content; retain nonsecret references sufficient for reproducibility.
- [ ] **UC-M01.04-C069-T09 · Independent reading:** Have the “Migration transformations” record read against the original acceptance criterion and manifest readers, canonical digest generation and schema migrations; record misunderstandings or missing evidence as corrections.
- [ ] **UC-M01.04-C069-T10 · Review disposition:** Publish the “Migration transformations” rationale, versioned review outcome, unresolved gaps and explicit next decision; keep blockers open until supported evidence resolves them.

### UC-M01.04-C070 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for migration transformations; label unexecuted checks as untested.

- [ ] **UC-M01.04-C070-T01 · Evidence inventory:** List the “Migration transformations” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M01.04-C070-T02 · Artifact references:** Record the exact “Migration transformations” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M01.04-C070-T03 · Fixture references:** Attach the “Migration transformations” fixture IDs, input identities and oracle definition; preserve the source counterexample “A migration drops a required policy field” as a distinct evidence case.
- [ ] **UC-M01.04-C070-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Migration transformations”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M01.04-C070-T05 · Environment record:** Record the actual “Migration transformations” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M01.04-C070-T06 · Expected versus observed:** Pair every “Migration transformations” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M01.04-C070-T07 · Failure and limit records:** Attach “Migration transformations” change/failure and bounds evidence where required; include uncovered “Migration input size and number of transformation steps” and unresolved violations of “Migration preserves defined semantics and original identity bindings”.
- [ ] **UC-M01.04-C070-T08 · Evidence hygiene:** Check the “Migration transformations” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M01.04-C070-T09 · Reproduction review:** Have the “Migration transformations” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M01.04-C070-T10 · Acceptance linkage:** Link the “Migration transformations” evidence to its parent and UC-M01.04 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 08. Downgrade refusal

**Source delivery:** Detect lossy or security-weakening downgrade attempts.

**Source invariant:** A downgrade cannot discard a required protection silently.

**Source negative case:** An older schema lacks the manifest's enforced network restriction.

**Source bounded quantities:** Downgrade paths and compatibility-check time.

### UC-M01.04-C071 · Contract

**Original checklist item:** Specify the scope and representation of downgrade refusal; identify its producer, consumer, authority assumptions and explicitly unsupported cases.

- [ ] **UC-M01.04-C071-T01 · Scope statement:** Draft a scope note for “Downgrade refusal” within Canonical manifest and schema evolution; separate required model statements, explicit exclusions and unresolved design decisions.
- [ ] **UC-M01.04-C071-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Downgrade refusal”; record each producer, representation and missing-value meaning.
- [ ] **UC-M01.04-C071-T03 · Output inventory:** List the outputs of “Downgrade refusal” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M01.04-C071-T04 · Field dictionary:** Create a field-and-term dictionary for “Downgrade refusal”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M01.04-C071-T05 · Prerequisite contract:** Map “Downgrade refusal” to the source component prerequisites (UC-M01.02); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M01.04-C071-T06 · Authority map:** Identify who may produce, change and consume “Downgrade refusal”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M01.04-C071-T07 · Invariant clause:** Add a normative clause for “Downgrade refusal” that preserves “A downgrade cannot discard a required protection silently”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M01.04-C071-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Downgrade refusal”; include the source counterexample “An older schema lacks the manifest's enforced network restriction” and the intended safe disposition.
- [ ] **UC-M01.04-C071-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Downgrade paths and compatibility-check time” in the “Downgrade refusal” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M01.04-C071-T10 · Contract review:** Review the “Downgrade refusal” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M01.04-C072 · Delivery

**Original checklist item:** Detect lossy or security-weakening downgrade attempts.

- [ ] **UC-M01.04-C072-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Downgrade refusal”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M01.04-C072-T02 · Change plan:** Break the source delivery for “Downgrade refusal” into concrete edit targets and reviewable outputs; keep the UC-M01.04 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M01.04-C072-T03 · Core artifact:** Implement the smallest selected-profile change for “Downgrade refusal” that realizes this source instruction: Detect lossy or security-weakening downgrade attempts.
- [ ] **UC-M01.04-C072-T04 · Concrete realization:** Trace “Downgrade refusal” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M01.04-C072-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Downgrade refusal” needed to preserve “A downgrade cannot discard a required protection silently”; record an enforcement gap where only a model exists.
- [ ] **UC-M01.04-C072-T06 · Dependency connection:** Connect the “Downgrade refusal” specification to manifest readers, canonical digest generation and schema migrations; record code coverage separately where the design is not yet enforced.
- [ ] **UC-M01.04-C072-T07 · Resource behavior:** Account for “Downgrade paths and compatibility-check time” in “Downgrade refusal”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M01.04-C072-T08 · Delivery check:** Walk the populated “Downgrade refusal” model through a valid example and the source counterexample “An older schema lacks the manifest's enforced network restriction”; record corrections and unresolved enforcement gaps.
- [ ] **UC-M01.04-C072-T09 · Patch review:** Review the “Downgrade refusal” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M01.04-C072-T10 · Delivery handoff:** Publish the “Downgrade refusal” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M01.04-C073 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: A downgrade cannot discard a required protection silently. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M01.04-C073-T01 · Named property:** Create a stable property/check name under this parent for “Downgrade refusal”; copy its required invariant exactly: “A downgrade cannot discard a required protection silently”.
- [ ] **UC-M01.04-C073-T02 · Observable terms:** Define each term in the “Downgrade refusal” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M01.04-C073-T03 · Precondition set:** List the preconditions under which “A downgrade cannot discard a required protection silently” must hold for “Downgrade refusal”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M01.04-C073-T04 · Transition coverage:** Map the “Downgrade refusal” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M01.04-C073-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Downgrade refusal”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M01.04-C073-T06 · Satisfying fixture:** Create a concrete “Downgrade refusal” case that satisfies “A downgrade cannot discard a required protection silently”; record its expected observation before running the assertion or review.
- [ ] **UC-M01.04-C073-T07 · Violating fixture:** Create the source counterexample “An older schema lacks the manifest's enforced network restriction” for “Downgrade refusal”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M01.04-C073-T08 · Enforcement evidence:** Exercise the “Downgrade refusal” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M01.04-C073-T09 · Regression linkage:** Link the “Downgrade refusal” property to changes in manifest readers, canonical digest generation and schema migrations; record which dependency or contract changes require rerunning it.
- [ ] **UC-M01.04-C073-T10 · Property disposition:** Compare the satisfying and violating “Downgrade refusal” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M01.04-C074 · Integration

**Original checklist item:** Integrate downgrade refusal with manifest readers, canonical digest generation and schema migrations; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M01.04-C074-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Downgrade refusal” across manifest readers, canonical digest generation and schema migrations; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M01.04-C074-T02 · Field mapping:** Map every “Downgrade refusal” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M01.04-C074-T03 · Prerequisite identities:** Record the actual prerequisites for “Downgrade refusal” (source dependency list: UC-M01.02); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M01.04-C074-T04 · Ownership agreement:** Specify who owns “Downgrade refusal” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M01.04-C074-T05 · Handoff implementation:** Connect “Downgrade refusal” through the mapped seam using the real adapter or explicit specification reference; preserve “A downgrade cannot discard a required protection silently” across the handoff.
- [ ] **UC-M01.04-C074-T06 · Absent-input case:** Omit one required “Downgrade refusal” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M01.04-C074-T07 · Stale-input case:** Supply an outdated “Downgrade refusal” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M01.04-C074-T08 · Incompatible-input case:** Supply an incompatible “Downgrade refusal” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M01.04-C074-T09 · Valid integration trace:** Run a valid “Downgrade refusal” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M01.04-C074-T10 · Seam review:** Reconcile the “Downgrade refusal” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M01.04-C075 · Valid-case test

**Original checklist item:** Construct a valid worked example for downgrade refusal; evaluate it against predeclared expected decisions and, where enforcement exists, run the corresponding conformance fixture.

- [ ] **UC-M01.04-C075-T01 · Valid fixture choice:** Select one concrete valid worked example for “Downgrade refusal”; enumerate the model inputs and the expected review decision before evaluating it.
- [ ] **UC-M01.04-C075-T02 · Expected-result oracle:** Specify the “Downgrade refusal” expected result independently of the implementation output; include the property “A downgrade cannot discard a required protection silently” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M01.04-C075-T03 · Fixture material:** Create the concrete “Downgrade refusal” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M01.04-C075-T04 · Target preparation:** Prepare the “Downgrade refusal” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M01.04-C075-T05 · Initial-state record:** Record the initial “Downgrade refusal” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M01.04-C075-T06 · Valid-path execution:** Evaluate the “Downgrade refusal” example against the reviewed model; where a runtime mechanism exists, run its corresponding fixture and label those observations separately.
- [ ] **UC-M01.04-C075-T07 · Outcome comparison:** Compare every declared “Downgrade refusal” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M01.04-C075-T08 · State and bounds check:** Inspect the “Downgrade refusal” ownership/state effects and actual use of “Downgrade paths and compatibility-check time”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M01.04-C075-T09 · Repeatability check:** Repeat the same “Downgrade refusal” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M01.04-C075-T10 · Positive evidence:** Attach the “Downgrade refusal” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M01.04-C076 · Negative test

**Original checklist item:** Negative case: An older schema lacks the manifest's enforced network restriction. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M01.04-C076-T01 · Adverse-case definition:** Create a test record for the exact “Downgrade refusal” source counterexample: “An older schema lacks the manifest's enforced network restriction”; state which precondition or invariant it challenges.
- [ ] **UC-M01.04-C076-T02 · Safe fixture boundary:** Define the contained test boundary for “Downgrade refusal”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M01.04-C076-T03 · Valid control:** Construct a valid “Downgrade refusal” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M01.04-C076-T04 · Minimal adverse input:** Derive the “Downgrade refusal” adverse fixture from the control with the smallest documented change needed to reproduce “An older schema lacks the manifest's enforced network restriction”; retain that change as reproducible data.
- [ ] **UC-M01.04-C076-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Downgrade refusal”; require “A downgrade cannot discard a required protection silently” and forbid a false-success verdict.
- [ ] **UC-M01.04-C076-T06 · Adverse execution:** Evaluate the “Downgrade refusal” adverse case through the actual review/contract gate; where implemented, also observe the runtime refusal and keep the two evidence classes separate.
- [ ] **UC-M01.04-C076-T07 · Effect inspection:** Inspect “Downgrade refusal” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M01.04-C076-T08 · Refusal versus failure:** Confirm the “Downgrade refusal” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M01.04-C076-T09 · Reset and retention:** Restore only the disposable “Downgrade refusal” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M01.04-C076-T10 · Negative regression:** Register the “Downgrade refusal” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M01.04-C077 · Change / failure test

**Original checklist item:** Exercise downgrade refusal when a manifest is upgraded and then submitted to an older supported reader; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M01.04-C077-T01 · Scenario record:** Write the “Downgrade refusal” change/failure scenario exactly as supplied: a manifest is upgraded and then submitted to an older supported reader; identify the property that must remain true: “A downgrade cannot discard a required protection silently”.
- [ ] **UC-M01.04-C077-T02 · Baseline capture:** Create a known-valid “Downgrade refusal” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M01.04-C077-T03 · Injection map:** Locate the “Downgrade refusal” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M01.04-C077-T04 · Disposition oracle:** Define the legal intermediate and final “Downgrade refusal” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M01.04-C077-T05 · Controlled trigger:** Apply the controlled model-change scenario for “Downgrade refusal”: a manifest is upgraded and then submitted to an older supported reader; retain the exact before/after declarations. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M01.04-C077-T06 · Intermediate inspection:** Review which “Downgrade refusal” claims, approvals and evidence references become stale after the change; keep unresolved enforcement gaps visible.
- [ ] **UC-M01.04-C077-T07 · Recovery path:** Revise or explicitly refuse the changed “Downgrade refusal” model under the documented compatibility policy; re-review affected claims before restoring their approval.
- [ ] **UC-M01.04-C077-T08 · Stale-evidence cleanup:** Invalidate superseded “Downgrade refusal” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M01.04-C077-T09 · Repeat and compare:** Repeat the selected “Downgrade refusal” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M01.04-C077-T10 · Failure evidence:** Publish the “Downgrade refusal” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M01.04-C078 · Bounds

**Original checklist item:** Define completeness and scaling criteria for downgrade paths and compatibility-check time; exercise larger inventories or fixture sets, and report uncovered scope instead of silently excluding it.

- [ ] **UC-M01.04-C078-T01 · Quantity inventory:** Create a measurement inventory for “Downgrade refusal”: “Downgrade paths and compatibility-check time”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M01.04-C078-T02 · Measurement method:** Choose how to observe each “Downgrade refusal” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M01.04-C078-T03 · Budget decision:** Select justified coverage and completeness limits for “Downgrade refusal”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M01.04-C078-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Downgrade refusal” cases for “Downgrade paths and compatibility-check time”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M01.04-C078-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Downgrade refusal” limit; preserve “A downgrade cannot discard a required protection silently”.
- [ ] **UC-M01.04-C078-T06 · Normal measurement:** Run or review the normal “Downgrade refusal” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M01.04-C078-T07 · At-limit measurement:** Exercise the “Downgrade refusal” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M01.04-C078-T08 · Over-limit measurement:** Exercise the “Downgrade refusal” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M01.04-C078-T09 · Uncovered-scope report:** List the “Downgrade refusal” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M01.04-C078-T10 · Limit evidence:** Publish the selected “Downgrade refusal” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M01.04-C079 · Diagnostics / review

**Original checklist item:** Record the rationale, unresolved assumptions, enforcement gaps and re-review triggers for downgrade refusal; make design-only claims visibly distinct from observed behavior.

- [ ] **UC-M01.04-C079-T01 · Review inventory:** List the “Downgrade refusal” decisions and claims requiring review; distinguish source requirements, implementation observations and engineering assumptions.
- [ ] **UC-M01.04-C079-T02 · Rationale record:** Write the rationale for the selected “Downgrade refusal” representation or policy; link each choice to the requirement rather than an unexplained preference.
- [ ] **UC-M01.04-C079-T03 · Assumption ledger:** Record unresolved “Downgrade refusal” assumptions, their owner and what observation or decision would resolve them; do not treat unknowns as approvals.
- [ ] **UC-M01.04-C079-T04 · Boundary map:** Map each “Downgrade refusal” claim to an actual guard or explicit design/review gate; flag gaps against “A downgrade cannot discard a required protection silently”.
- [ ] **UC-M01.04-C079-T05 · Counterexample review:** Walk reviewers through the “Downgrade refusal” counterexample “An older schema lacks the manifest's enforced network restriction”; record whether the model detects it and whether any runtime guard was actually exercised.
- [ ] **UC-M01.04-C079-T06 · Review outcome vocabulary:** Define approved, blocked, superseded and untested review outcomes for “Downgrade refusal”; ensure the wording cannot be read as runtime enforcement evidence.
- [ ] **UC-M01.04-C079-T07 · Re-review triggers:** List “Downgrade refusal” invalidation triggers, including the source change scenario: a manifest is upgraded and then submitted to an older supported reader; identify the affected claims and evidence.
- [ ] **UC-M01.04-C079-T08 · Sensitive-data review:** Inspect the “Downgrade refusal” review record for secrets and unrelated user content; retain nonsecret references sufficient for reproducibility.
- [ ] **UC-M01.04-C079-T09 · Independent reading:** Have the “Downgrade refusal” record read against the original acceptance criterion and manifest readers, canonical digest generation and schema migrations; record misunderstandings or missing evidence as corrections.
- [ ] **UC-M01.04-C079-T10 · Review disposition:** Publish the “Downgrade refusal” rationale, versioned review outcome, unresolved gaps and explicit next decision; keep blockers open until supported evidence resolves them.

### UC-M01.04-C080 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for downgrade refusal; label unexecuted checks as untested.

- [ ] **UC-M01.04-C080-T01 · Evidence inventory:** List the “Downgrade refusal” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M01.04-C080-T02 · Artifact references:** Record the exact “Downgrade refusal” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M01.04-C080-T03 · Fixture references:** Attach the “Downgrade refusal” fixture IDs, input identities and oracle definition; preserve the source counterexample “An older schema lacks the manifest's enforced network restriction” as a distinct evidence case.
- [ ] **UC-M01.04-C080-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Downgrade refusal”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M01.04-C080-T05 · Environment record:** Record the actual “Downgrade refusal” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M01.04-C080-T06 · Expected versus observed:** Pair every “Downgrade refusal” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M01.04-C080-T07 · Failure and limit records:** Attach “Downgrade refusal” change/failure and bounds evidence where required; include uncovered “Downgrade paths and compatibility-check time” and unresolved violations of “A downgrade cannot discard a required protection silently”.
- [ ] **UC-M01.04-C080-T08 · Evidence hygiene:** Check the “Downgrade refusal” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M01.04-C080-T09 · Reproduction review:** Have the “Downgrade refusal” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M01.04-C080-T10 · Acceptance linkage:** Link the “Downgrade refusal” evidence to its parent and UC-M01.04 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 09. Unknown-field policy

**Source delivery:** Distinguish permitted extensions from ambiguous or sensitive unknown fields.

**Source invariant:** Unknown authority-bearing fields are rejected.

**Source negative case:** A misspelled signing-policy field is ignored.

**Source bounded quantities:** Unknown-field count and extension payload size.

### UC-M01.04-C081 · Contract

**Original checklist item:** Specify the scope and representation of unknown-field policy; identify its producer, consumer, authority assumptions and explicitly unsupported cases.

- [ ] **UC-M01.04-C081-T01 · Scope statement:** Draft a scope note for “Unknown-field policy” within Canonical manifest and schema evolution; separate required model statements, explicit exclusions and unresolved design decisions.
- [ ] **UC-M01.04-C081-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Unknown-field policy”; record each producer, representation and missing-value meaning.
- [ ] **UC-M01.04-C081-T03 · Output inventory:** List the outputs of “Unknown-field policy” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M01.04-C081-T04 · Field dictionary:** Create a field-and-term dictionary for “Unknown-field policy”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M01.04-C081-T05 · Prerequisite contract:** Map “Unknown-field policy” to the source component prerequisites (UC-M01.02); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M01.04-C081-T06 · Authority map:** Identify who may produce, change and consume “Unknown-field policy”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M01.04-C081-T07 · Invariant clause:** Add a normative clause for “Unknown-field policy” that preserves “Unknown authority-bearing fields are rejected”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M01.04-C081-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Unknown-field policy”; include the source counterexample “A misspelled signing-policy field is ignored” and the intended safe disposition.
- [ ] **UC-M01.04-C081-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Unknown-field count and extension payload size” in the “Unknown-field policy” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M01.04-C081-T10 · Contract review:** Review the “Unknown-field policy” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M01.04-C082 · Delivery

**Original checklist item:** Distinguish permitted extensions from ambiguous or sensitive unknown fields.

- [ ] **UC-M01.04-C082-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Unknown-field policy”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M01.04-C082-T02 · Change plan:** Break the source delivery for “Unknown-field policy” into concrete edit targets and reviewable outputs; keep the UC-M01.04 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M01.04-C082-T03 · Core artifact:** Create the “Unknown-field policy” model, schema or inventory that realizes this source instruction: Distinguish permitted extensions from ambiguous or sensitive unknown fields.
- [ ] **UC-M01.04-C082-T04 · Concrete realization:** Populate “Unknown-field policy” with one concrete worked case; map every required entity or field to its source and flag any unmapped entry.
- [ ] **UC-M01.04-C082-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Unknown-field policy” needed to preserve “Unknown authority-bearing fields are rejected”; record an enforcement gap where only a model exists.
- [ ] **UC-M01.04-C082-T06 · Dependency connection:** Connect the “Unknown-field policy” specification to manifest readers, canonical digest generation and schema migrations; record code coverage separately where the design is not yet enforced.
- [ ] **UC-M01.04-C082-T07 · Resource behavior:** Account for “Unknown-field count and extension payload size” in “Unknown-field policy”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M01.04-C082-T08 · Delivery check:** Walk the populated “Unknown-field policy” model through a valid example and the source counterexample “A misspelled signing-policy field is ignored”; record corrections and unresolved enforcement gaps.
- [ ] **UC-M01.04-C082-T09 · Patch review:** Review the “Unknown-field policy” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M01.04-C082-T10 · Delivery handoff:** Publish the “Unknown-field policy” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M01.04-C083 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Unknown authority-bearing fields are rejected. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M01.04-C083-T01 · Named property:** Create a stable property/check name under this parent for “Unknown-field policy”; copy its required invariant exactly: “Unknown authority-bearing fields are rejected”.
- [ ] **UC-M01.04-C083-T02 · Observable terms:** Define each term in the “Unknown-field policy” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M01.04-C083-T03 · Precondition set:** List the preconditions under which “Unknown authority-bearing fields are rejected” must hold for “Unknown-field policy”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M01.04-C083-T04 · Transition coverage:** Map the “Unknown-field policy” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M01.04-C083-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Unknown-field policy”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M01.04-C083-T06 · Satisfying fixture:** Create a concrete “Unknown-field policy” case that satisfies “Unknown authority-bearing fields are rejected”; record its expected observation before running the assertion or review.
- [ ] **UC-M01.04-C083-T07 · Violating fixture:** Create the source counterexample “A misspelled signing-policy field is ignored” for “Unknown-field policy”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M01.04-C083-T08 · Enforcement evidence:** Exercise the “Unknown-field policy” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M01.04-C083-T09 · Regression linkage:** Link the “Unknown-field policy” property to changes in manifest readers, canonical digest generation and schema migrations; record which dependency or contract changes require rerunning it.
- [ ] **UC-M01.04-C083-T10 · Property disposition:** Compare the satisfying and violating “Unknown-field policy” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M01.04-C084 · Integration

**Original checklist item:** Integrate unknown-field policy with manifest readers, canonical digest generation and schema migrations; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M01.04-C084-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Unknown-field policy” across manifest readers, canonical digest generation and schema migrations; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M01.04-C084-T02 · Field mapping:** Map every “Unknown-field policy” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M01.04-C084-T03 · Prerequisite identities:** Record the actual prerequisites for “Unknown-field policy” (source dependency list: UC-M01.02); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M01.04-C084-T04 · Ownership agreement:** Specify who owns “Unknown-field policy” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M01.04-C084-T05 · Handoff implementation:** Connect “Unknown-field policy” through the mapped seam using the real adapter or explicit specification reference; preserve “Unknown authority-bearing fields are rejected” across the handoff.
- [ ] **UC-M01.04-C084-T06 · Absent-input case:** Omit one required “Unknown-field policy” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M01.04-C084-T07 · Stale-input case:** Supply an outdated “Unknown-field policy” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M01.04-C084-T08 · Incompatible-input case:** Supply an incompatible “Unknown-field policy” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M01.04-C084-T09 · Valid integration trace:** Run a valid “Unknown-field policy” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M01.04-C084-T10 · Seam review:** Reconcile the “Unknown-field policy” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M01.04-C085 · Valid-case test

**Original checklist item:** Construct a valid worked example for unknown-field policy; evaluate it against predeclared expected decisions and, where enforcement exists, run the corresponding conformance fixture.

- [ ] **UC-M01.04-C085-T01 · Valid fixture choice:** Select one concrete valid worked example for “Unknown-field policy”; enumerate the model inputs and the expected review decision before evaluating it.
- [ ] **UC-M01.04-C085-T02 · Expected-result oracle:** Specify the “Unknown-field policy” expected result independently of the implementation output; include the property “Unknown authority-bearing fields are rejected” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M01.04-C085-T03 · Fixture material:** Create the concrete “Unknown-field policy” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M01.04-C085-T04 · Target preparation:** Prepare the “Unknown-field policy” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M01.04-C085-T05 · Initial-state record:** Record the initial “Unknown-field policy” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M01.04-C085-T06 · Valid-path execution:** Evaluate the “Unknown-field policy” example against the reviewed model; where a runtime mechanism exists, run its corresponding fixture and label those observations separately.
- [ ] **UC-M01.04-C085-T07 · Outcome comparison:** Compare every declared “Unknown-field policy” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M01.04-C085-T08 · State and bounds check:** Inspect the “Unknown-field policy” ownership/state effects and actual use of “Unknown-field count and extension payload size”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M01.04-C085-T09 · Repeatability check:** Repeat the same “Unknown-field policy” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M01.04-C085-T10 · Positive evidence:** Attach the “Unknown-field policy” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M01.04-C086 · Negative test

**Original checklist item:** Negative case: A misspelled signing-policy field is ignored. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M01.04-C086-T01 · Adverse-case definition:** Create a test record for the exact “Unknown-field policy” source counterexample: “A misspelled signing-policy field is ignored”; state which precondition or invariant it challenges.
- [ ] **UC-M01.04-C086-T02 · Safe fixture boundary:** Define the contained test boundary for “Unknown-field policy”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M01.04-C086-T03 · Valid control:** Construct a valid “Unknown-field policy” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M01.04-C086-T04 · Minimal adverse input:** Derive the “Unknown-field policy” adverse fixture from the control with the smallest documented change needed to reproduce “A misspelled signing-policy field is ignored”; retain that change as reproducible data.
- [ ] **UC-M01.04-C086-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Unknown-field policy”; require “Unknown authority-bearing fields are rejected” and forbid a false-success verdict.
- [ ] **UC-M01.04-C086-T06 · Adverse execution:** Evaluate the “Unknown-field policy” adverse case through the actual review/contract gate; where implemented, also observe the runtime refusal and keep the two evidence classes separate.
- [ ] **UC-M01.04-C086-T07 · Effect inspection:** Inspect “Unknown-field policy” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M01.04-C086-T08 · Refusal versus failure:** Confirm the “Unknown-field policy” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M01.04-C086-T09 · Reset and retention:** Restore only the disposable “Unknown-field policy” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M01.04-C086-T10 · Negative regression:** Register the “Unknown-field policy” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M01.04-C087 · Change / failure test

**Original checklist item:** Exercise unknown-field policy when a manifest is upgraded and then submitted to an older supported reader; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M01.04-C087-T01 · Scenario record:** Write the “Unknown-field policy” change/failure scenario exactly as supplied: a manifest is upgraded and then submitted to an older supported reader; identify the property that must remain true: “Unknown authority-bearing fields are rejected”.
- [ ] **UC-M01.04-C087-T02 · Baseline capture:** Create a known-valid “Unknown-field policy” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M01.04-C087-T03 · Injection map:** Locate the “Unknown-field policy” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M01.04-C087-T04 · Disposition oracle:** Define the legal intermediate and final “Unknown-field policy” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M01.04-C087-T05 · Controlled trigger:** Apply the controlled model-change scenario for “Unknown-field policy”: a manifest is upgraded and then submitted to an older supported reader; retain the exact before/after declarations. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M01.04-C087-T06 · Intermediate inspection:** Review which “Unknown-field policy” claims, approvals and evidence references become stale after the change; keep unresolved enforcement gaps visible.
- [ ] **UC-M01.04-C087-T07 · Recovery path:** Revise or explicitly refuse the changed “Unknown-field policy” model under the documented compatibility policy; re-review affected claims before restoring their approval.
- [ ] **UC-M01.04-C087-T08 · Stale-evidence cleanup:** Invalidate superseded “Unknown-field policy” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M01.04-C087-T09 · Repeat and compare:** Repeat the selected “Unknown-field policy” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M01.04-C087-T10 · Failure evidence:** Publish the “Unknown-field policy” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M01.04-C088 · Bounds

**Original checklist item:** Define completeness and scaling criteria for unknown-field count and extension payload size; exercise larger inventories or fixture sets, and report uncovered scope instead of silently excluding it.

- [ ] **UC-M01.04-C088-T01 · Quantity inventory:** Create a measurement inventory for “Unknown-field policy”: “Unknown-field count and extension payload size”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M01.04-C088-T02 · Measurement method:** Choose how to observe each “Unknown-field policy” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M01.04-C088-T03 · Budget decision:** Select justified coverage and completeness limits for “Unknown-field policy”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M01.04-C088-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Unknown-field policy” cases for “Unknown-field count and extension payload size”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M01.04-C088-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Unknown-field policy” limit; preserve “Unknown authority-bearing fields are rejected”.
- [ ] **UC-M01.04-C088-T06 · Normal measurement:** Run or review the normal “Unknown-field policy” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M01.04-C088-T07 · At-limit measurement:** Exercise the “Unknown-field policy” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M01.04-C088-T08 · Over-limit measurement:** Exercise the “Unknown-field policy” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M01.04-C088-T09 · Uncovered-scope report:** List the “Unknown-field policy” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M01.04-C088-T10 · Limit evidence:** Publish the selected “Unknown-field policy” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M01.04-C089 · Diagnostics / review

**Original checklist item:** Record the rationale, unresolved assumptions, enforcement gaps and re-review triggers for unknown-field policy; make design-only claims visibly distinct from observed behavior.

- [ ] **UC-M01.04-C089-T01 · Review inventory:** List the “Unknown-field policy” decisions and claims requiring review; distinguish source requirements, implementation observations and engineering assumptions.
- [ ] **UC-M01.04-C089-T02 · Rationale record:** Write the rationale for the selected “Unknown-field policy” representation or policy; link each choice to the requirement rather than an unexplained preference.
- [ ] **UC-M01.04-C089-T03 · Assumption ledger:** Record unresolved “Unknown-field policy” assumptions, their owner and what observation or decision would resolve them; do not treat unknowns as approvals.
- [ ] **UC-M01.04-C089-T04 · Boundary map:** Map each “Unknown-field policy” claim to an actual guard or explicit design/review gate; flag gaps against “Unknown authority-bearing fields are rejected”.
- [ ] **UC-M01.04-C089-T05 · Counterexample review:** Walk reviewers through the “Unknown-field policy” counterexample “A misspelled signing-policy field is ignored”; record whether the model detects it and whether any runtime guard was actually exercised.
- [ ] **UC-M01.04-C089-T06 · Review outcome vocabulary:** Define approved, blocked, superseded and untested review outcomes for “Unknown-field policy”; ensure the wording cannot be read as runtime enforcement evidence.
- [ ] **UC-M01.04-C089-T07 · Re-review triggers:** List “Unknown-field policy” invalidation triggers, including the source change scenario: a manifest is upgraded and then submitted to an older supported reader; identify the affected claims and evidence.
- [ ] **UC-M01.04-C089-T08 · Sensitive-data review:** Inspect the “Unknown-field policy” review record for secrets and unrelated user content; retain nonsecret references sufficient for reproducibility.
- [ ] **UC-M01.04-C089-T09 · Independent reading:** Have the “Unknown-field policy” record read against the original acceptance criterion and manifest readers, canonical digest generation and schema migrations; record misunderstandings or missing evidence as corrections.
- [ ] **UC-M01.04-C089-T10 · Review disposition:** Publish the “Unknown-field policy” rationale, versioned review outcome, unresolved gaps and explicit next decision; keep blockers open until supported evidence resolves them.

### UC-M01.04-C090 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for unknown-field policy; label unexecuted checks as untested.

- [ ] **UC-M01.04-C090-T01 · Evidence inventory:** List the “Unknown-field policy” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M01.04-C090-T02 · Artifact references:** Record the exact “Unknown-field policy” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M01.04-C090-T03 · Fixture references:** Attach the “Unknown-field policy” fixture IDs, input identities and oracle definition; preserve the source counterexample “A misspelled signing-policy field is ignored” as a distinct evidence case.
- [ ] **UC-M01.04-C090-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Unknown-field policy”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M01.04-C090-T05 · Environment record:** Record the actual “Unknown-field policy” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M01.04-C090-T06 · Expected versus observed:** Pair every “Unknown-field policy” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M01.04-C090-T07 · Failure and limit records:** Attach “Unknown-field policy” change/failure and bounds evidence where required; include uncovered “Unknown-field count and extension payload size” and unresolved violations of “Unknown authority-bearing fields are rejected”.
- [ ] **UC-M01.04-C090-T08 · Evidence hygiene:** Check the “Unknown-field policy” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M01.04-C090-T09 · Reproduction review:** Have the “Unknown-field policy” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M01.04-C090-T10 · Acceptance linkage:** Link the “Unknown-field policy” evidence to its parent and UC-M01.04 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 10. Round-trip fixtures

**Source delivery:** Create encode, decode and migration round-trip fixtures with canonical digests.

**Source invariant:** Supported round trips preserve declared values without loss.

**Source negative case:** Encoding and decoding changes a large integer.

**Source bounded quantities:** Fixture sizes and cross-version test matrix.

### UC-M01.04-C091 · Contract

**Original checklist item:** Specify the scope and representation of round-trip fixtures; identify its producer, consumer, authority assumptions and explicitly unsupported cases.

- [ ] **UC-M01.04-C091-T01 · Scope statement:** Draft a scope note for “Round-trip fixtures” within Canonical manifest and schema evolution; separate required model statements, explicit exclusions and unresolved design decisions.
- [ ] **UC-M01.04-C091-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Round-trip fixtures”; record each producer, representation and missing-value meaning.
- [ ] **UC-M01.04-C091-T03 · Output inventory:** List the outputs of “Round-trip fixtures” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M01.04-C091-T04 · Field dictionary:** Create a field-and-term dictionary for “Round-trip fixtures”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M01.04-C091-T05 · Prerequisite contract:** Map “Round-trip fixtures” to the source component prerequisites (UC-M01.02); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M01.04-C091-T06 · Authority map:** Identify who may produce, change and consume “Round-trip fixtures”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M01.04-C091-T07 · Invariant clause:** Add a normative clause for “Round-trip fixtures” that preserves “Supported round trips preserve declared values without loss”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M01.04-C091-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Round-trip fixtures”; include the source counterexample “Encoding and decoding changes a large integer” and the intended safe disposition.
- [ ] **UC-M01.04-C091-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Fixture sizes and cross-version test matrix” in the “Round-trip fixtures” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M01.04-C091-T10 · Contract review:** Review the “Round-trip fixtures” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M01.04-C092 · Delivery

**Original checklist item:** Create encode, decode and migration round-trip fixtures with canonical digests.

- [ ] **UC-M01.04-C092-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Round-trip fixtures”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M01.04-C092-T02 · Change plan:** Break the source delivery for “Round-trip fixtures” into concrete edit targets and reviewable outputs; keep the UC-M01.04 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M01.04-C092-T03 · Core artifact:** Implement the smallest selected-profile change for “Round-trip fixtures” that realizes this source instruction: Create encode, decode and migration round-trip fixtures with canonical digests.
- [ ] **UC-M01.04-C092-T04 · Concrete realization:** Trace “Round-trip fixtures” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M01.04-C092-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Round-trip fixtures” needed to preserve “Supported round trips preserve declared values without loss”; record an enforcement gap where only a model exists.
- [ ] **UC-M01.04-C092-T06 · Dependency connection:** Connect the “Round-trip fixtures” specification to manifest readers, canonical digest generation and schema migrations; record code coverage separately where the design is not yet enforced.
- [ ] **UC-M01.04-C092-T07 · Resource behavior:** Account for “Fixture sizes and cross-version test matrix” in “Round-trip fixtures”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M01.04-C092-T08 · Delivery check:** Walk the populated “Round-trip fixtures” model through a valid example and the source counterexample “Encoding and decoding changes a large integer”; record corrections and unresolved enforcement gaps.
- [ ] **UC-M01.04-C092-T09 · Patch review:** Review the “Round-trip fixtures” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M01.04-C092-T10 · Delivery handoff:** Publish the “Round-trip fixtures” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M01.04-C093 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Supported round trips preserve declared values without loss. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M01.04-C093-T01 · Named property:** Create a stable property/check name under this parent for “Round-trip fixtures”; copy its required invariant exactly: “Supported round trips preserve declared values without loss”.
- [ ] **UC-M01.04-C093-T02 · Observable terms:** Define each term in the “Round-trip fixtures” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M01.04-C093-T03 · Precondition set:** List the preconditions under which “Supported round trips preserve declared values without loss” must hold for “Round-trip fixtures”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M01.04-C093-T04 · Transition coverage:** Map the “Round-trip fixtures” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M01.04-C093-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Round-trip fixtures”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M01.04-C093-T06 · Satisfying fixture:** Create a concrete “Round-trip fixtures” case that satisfies “Supported round trips preserve declared values without loss”; record its expected observation before running the assertion or review.
- [ ] **UC-M01.04-C093-T07 · Violating fixture:** Create the source counterexample “Encoding and decoding changes a large integer” for “Round-trip fixtures”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M01.04-C093-T08 · Enforcement evidence:** Exercise the “Round-trip fixtures” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M01.04-C093-T09 · Regression linkage:** Link the “Round-trip fixtures” property to changes in manifest readers, canonical digest generation and schema migrations; record which dependency or contract changes require rerunning it.
- [ ] **UC-M01.04-C093-T10 · Property disposition:** Compare the satisfying and violating “Round-trip fixtures” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M01.04-C094 · Integration

**Original checklist item:** Integrate round-trip fixtures with manifest readers, canonical digest generation and schema migrations; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M01.04-C094-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Round-trip fixtures” across manifest readers, canonical digest generation and schema migrations; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M01.04-C094-T02 · Field mapping:** Map every “Round-trip fixtures” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M01.04-C094-T03 · Prerequisite identities:** Record the actual prerequisites for “Round-trip fixtures” (source dependency list: UC-M01.02); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M01.04-C094-T04 · Ownership agreement:** Specify who owns “Round-trip fixtures” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M01.04-C094-T05 · Handoff implementation:** Connect “Round-trip fixtures” through the mapped seam using the real adapter or explicit specification reference; preserve “Supported round trips preserve declared values without loss” across the handoff.
- [ ] **UC-M01.04-C094-T06 · Absent-input case:** Omit one required “Round-trip fixtures” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M01.04-C094-T07 · Stale-input case:** Supply an outdated “Round-trip fixtures” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M01.04-C094-T08 · Incompatible-input case:** Supply an incompatible “Round-trip fixtures” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M01.04-C094-T09 · Valid integration trace:** Run a valid “Round-trip fixtures” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M01.04-C094-T10 · Seam review:** Reconcile the “Round-trip fixtures” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M01.04-C095 · Valid-case test

**Original checklist item:** Construct a valid worked example for round-trip fixtures; evaluate it against predeclared expected decisions and, where enforcement exists, run the corresponding conformance fixture.

- [ ] **UC-M01.04-C095-T01 · Valid fixture choice:** Select one concrete valid worked example for “Round-trip fixtures”; enumerate the model inputs and the expected review decision before evaluating it.
- [ ] **UC-M01.04-C095-T02 · Expected-result oracle:** Specify the “Round-trip fixtures” expected result independently of the implementation output; include the property “Supported round trips preserve declared values without loss” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M01.04-C095-T03 · Fixture material:** Create the concrete “Round-trip fixtures” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M01.04-C095-T04 · Target preparation:** Prepare the “Round-trip fixtures” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M01.04-C095-T05 · Initial-state record:** Record the initial “Round-trip fixtures” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M01.04-C095-T06 · Valid-path execution:** Evaluate the “Round-trip fixtures” example against the reviewed model; where a runtime mechanism exists, run its corresponding fixture and label those observations separately.
- [ ] **UC-M01.04-C095-T07 · Outcome comparison:** Compare every declared “Round-trip fixtures” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M01.04-C095-T08 · State and bounds check:** Inspect the “Round-trip fixtures” ownership/state effects and actual use of “Fixture sizes and cross-version test matrix”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M01.04-C095-T09 · Repeatability check:** Repeat the same “Round-trip fixtures” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M01.04-C095-T10 · Positive evidence:** Attach the “Round-trip fixtures” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M01.04-C096 · Negative test

**Original checklist item:** Negative case: Encoding and decoding changes a large integer. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M01.04-C096-T01 · Adverse-case definition:** Create a test record for the exact “Round-trip fixtures” source counterexample: “Encoding and decoding changes a large integer”; state which precondition or invariant it challenges.
- [ ] **UC-M01.04-C096-T02 · Safe fixture boundary:** Define the contained test boundary for “Round-trip fixtures”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M01.04-C096-T03 · Valid control:** Construct a valid “Round-trip fixtures” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M01.04-C096-T04 · Minimal adverse input:** Derive the “Round-trip fixtures” adverse fixture from the control with the smallest documented change needed to reproduce “Encoding and decoding changes a large integer”; retain that change as reproducible data.
- [ ] **UC-M01.04-C096-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Round-trip fixtures”; require “Supported round trips preserve declared values without loss” and forbid a false-success verdict.
- [ ] **UC-M01.04-C096-T06 · Adverse execution:** Evaluate the “Round-trip fixtures” adverse case through the actual review/contract gate; where implemented, also observe the runtime refusal and keep the two evidence classes separate.
- [ ] **UC-M01.04-C096-T07 · Effect inspection:** Inspect “Round-trip fixtures” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M01.04-C096-T08 · Refusal versus failure:** Confirm the “Round-trip fixtures” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M01.04-C096-T09 · Reset and retention:** Restore only the disposable “Round-trip fixtures” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M01.04-C096-T10 · Negative regression:** Register the “Round-trip fixtures” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M01.04-C097 · Change / failure test

**Original checklist item:** Exercise round-trip fixtures when a manifest is upgraded and then submitted to an older supported reader; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M01.04-C097-T01 · Scenario record:** Write the “Round-trip fixtures” change/failure scenario exactly as supplied: a manifest is upgraded and then submitted to an older supported reader; identify the property that must remain true: “Supported round trips preserve declared values without loss”.
- [ ] **UC-M01.04-C097-T02 · Baseline capture:** Create a known-valid “Round-trip fixtures” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M01.04-C097-T03 · Injection map:** Locate the “Round-trip fixtures” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M01.04-C097-T04 · Disposition oracle:** Define the legal intermediate and final “Round-trip fixtures” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M01.04-C097-T05 · Controlled trigger:** Apply the controlled model-change scenario for “Round-trip fixtures”: a manifest is upgraded and then submitted to an older supported reader; retain the exact before/after declarations. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M01.04-C097-T06 · Intermediate inspection:** Review which “Round-trip fixtures” claims, approvals and evidence references become stale after the change; keep unresolved enforcement gaps visible.
- [ ] **UC-M01.04-C097-T07 · Recovery path:** Revise or explicitly refuse the changed “Round-trip fixtures” model under the documented compatibility policy; re-review affected claims before restoring their approval.
- [ ] **UC-M01.04-C097-T08 · Stale-evidence cleanup:** Invalidate superseded “Round-trip fixtures” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M01.04-C097-T09 · Repeat and compare:** Repeat the selected “Round-trip fixtures” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M01.04-C097-T10 · Failure evidence:** Publish the “Round-trip fixtures” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M01.04-C098 · Bounds

**Original checklist item:** Define completeness and scaling criteria for fixture sizes and cross-version test matrix; exercise larger inventories or fixture sets, and report uncovered scope instead of silently excluding it.

- [ ] **UC-M01.04-C098-T01 · Quantity inventory:** Create a measurement inventory for “Round-trip fixtures”: “Fixture sizes and cross-version test matrix”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M01.04-C098-T02 · Measurement method:** Choose how to observe each “Round-trip fixtures” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M01.04-C098-T03 · Budget decision:** Select justified coverage and completeness limits for “Round-trip fixtures”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M01.04-C098-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Round-trip fixtures” cases for “Fixture sizes and cross-version test matrix”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M01.04-C098-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Round-trip fixtures” limit; preserve “Supported round trips preserve declared values without loss”.
- [ ] **UC-M01.04-C098-T06 · Normal measurement:** Run or review the normal “Round-trip fixtures” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M01.04-C098-T07 · At-limit measurement:** Exercise the “Round-trip fixtures” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M01.04-C098-T08 · Over-limit measurement:** Exercise the “Round-trip fixtures” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M01.04-C098-T09 · Uncovered-scope report:** List the “Round-trip fixtures” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M01.04-C098-T10 · Limit evidence:** Publish the selected “Round-trip fixtures” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M01.04-C099 · Diagnostics / review

**Original checklist item:** Record the rationale, unresolved assumptions, enforcement gaps and re-review triggers for round-trip fixtures; make design-only claims visibly distinct from observed behavior.

- [ ] **UC-M01.04-C099-T01 · Review inventory:** List the “Round-trip fixtures” decisions and claims requiring review; distinguish source requirements, implementation observations and engineering assumptions.
- [ ] **UC-M01.04-C099-T02 · Rationale record:** Write the rationale for the selected “Round-trip fixtures” representation or policy; link each choice to the requirement rather than an unexplained preference.
- [ ] **UC-M01.04-C099-T03 · Assumption ledger:** Record unresolved “Round-trip fixtures” assumptions, their owner and what observation or decision would resolve them; do not treat unknowns as approvals.
- [ ] **UC-M01.04-C099-T04 · Boundary map:** Map each “Round-trip fixtures” claim to an actual guard or explicit design/review gate; flag gaps against “Supported round trips preserve declared values without loss”.
- [ ] **UC-M01.04-C099-T05 · Counterexample review:** Walk reviewers through the “Round-trip fixtures” counterexample “Encoding and decoding changes a large integer”; record whether the model detects it and whether any runtime guard was actually exercised.
- [ ] **UC-M01.04-C099-T06 · Review outcome vocabulary:** Define approved, blocked, superseded and untested review outcomes for “Round-trip fixtures”; ensure the wording cannot be read as runtime enforcement evidence.
- [ ] **UC-M01.04-C099-T07 · Re-review triggers:** List “Round-trip fixtures” invalidation triggers, including the source change scenario: a manifest is upgraded and then submitted to an older supported reader; identify the affected claims and evidence.
- [ ] **UC-M01.04-C099-T08 · Sensitive-data review:** Inspect the “Round-trip fixtures” review record for secrets and unrelated user content; retain nonsecret references sufficient for reproducibility.
- [ ] **UC-M01.04-C099-T09 · Independent reading:** Have the “Round-trip fixtures” record read against the original acceptance criterion and manifest readers, canonical digest generation and schema migrations; record misunderstandings or missing evidence as corrections.
- [ ] **UC-M01.04-C099-T10 · Review disposition:** Publish the “Round-trip fixtures” rationale, versioned review outcome, unresolved gaps and explicit next decision; keep blockers open until supported evidence resolves them.

### UC-M01.04-C100 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for round-trip fixtures; label unexecuted checks as untested.

- [ ] **UC-M01.04-C100-T01 · Evidence inventory:** List the “Round-trip fixtures” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M01.04-C100-T02 · Artifact references:** Record the exact “Round-trip fixtures” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M01.04-C100-T03 · Fixture references:** Attach the “Round-trip fixtures” fixture IDs, input identities and oracle definition; preserve the source counterexample “Encoding and decoding changes a large integer” as a distinct evidence case.
- [ ] **UC-M01.04-C100-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Round-trip fixtures”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M01.04-C100-T05 · Environment record:** Record the actual “Round-trip fixtures” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M01.04-C100-T06 · Expected versus observed:** Pair every “Round-trip fixtures” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M01.04-C100-T07 · Failure and limit records:** Attach “Round-trip fixtures” change/failure and bounds evidence where required; include uncovered “Fixture sizes and cross-version test matrix” and unresolved violations of “Supported round trips preserve declared values without loss”.
- [ ] **UC-M01.04-C100-T08 · Evidence hygiene:** Check the “Round-trip fixtures” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M01.04-C100-T09 · Reproduction review:** Have the “Round-trip fixtures” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M01.04-C100-T10 · Acceptance linkage:** Link the “Round-trip fixtures” evidence to its parent and UC-M01.04 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

