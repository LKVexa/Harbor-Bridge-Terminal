# UC-M01.03 — Lifecycle state machine

**To-Do Pack 2.0.0 · Baseline UC-2.2.0 · 100 parent checks × 10 subtasks = 1,000 to-dos**

[Master index](../../INDEX.md) · [Workstream index](../../w/01.md)

| Field | Preserved source value |
|---|---|
| Workstream | 01. Architecture and executable contracts |
| Milestone | A |
| Priority | P0 |
| Source assessment | PARTIAL |
| Scope | core or selected profile |
| Dependencies | [UC-M01.02](../01/UC-M01.02.md) |
| Source checklist pack | 1.0.0 |
| Original reference labels | [S1], [S3]. |

## Original requirement

Separate desired and observed states: admitted, staged, built, booting, ready, running, draining, stopped, failed and quarantined.

**Original acceptance criterion:** Every transition has a durable reason and legal predecessor; failed readiness cannot produce a running status.

**Source trace:** Original checklist `UC100/c/01/UC-M01.03.md` inside [s/checklists.zip](../../s/checklists.zip); exact parent records in [data/parents.jsonl](../../data/parents.jsonl). Original roadmap lines 71–81 are preserved in [s/roadmap.md](../../s/roadmap.md).

## How to use these lists

Every parent statement below is preserved verbatim. Its ten child tasks are proposed decomposition, not implemented capabilities or executed tests. Child IDs append `-T01` through `-T10` to the original parent ID. All begin unchecked / `TODO`. Design/review evidence does not establish runtime enforcement; observe the actual selected target where the parent requires it.

The source dependency graph and selected release profile determine applicability. The numbered child sequence is a local working order, not an added hard dependency graph. An unselected optional feature needs a recorded not-applicable rationale; missing prerequisites for selected work remain blockers. Numerical budgets, backends and trust mechanisms remain decisions unless fixed by the source. Test hostile cases only with synthetic inputs in authorized disposable environments.

## 01. State vocabulary

**Source delivery:** Define admitted, staged, built, booting, ready, running, draining, stopped, failed and quarantined.

**Source invariant:** Every reported lifecycle state has a documented meaning.

**Source negative case:** A directory's presence alone is treated as running.

**Source bounded quantities:** State count and unsupported state combinations.

### UC-M01.03-C001 · Contract

**Original checklist item:** Specify state vocabulary inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M01.03-C001-T01 · Scope statement:** Draft the operation boundary for “State vocabulary” within Lifecycle state machine; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M01.03-C001-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “State vocabulary”; record each producer, representation and missing-value meaning.
- [ ] **UC-M01.03-C001-T03 · Output inventory:** List the outputs of “State vocabulary” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M01.03-C001-T04 · Field dictionary:** Create a field-and-term dictionary for “State vocabulary”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M01.03-C001-T05 · Prerequisite contract:** Map “State vocabulary” to the source component prerequisites (UC-M01.02); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M01.03-C001-T06 · Authority map:** Identify who may produce, change and consume “State vocabulary”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M01.03-C001-T07 · Invariant clause:** Add a normative clause for “State vocabulary” that preserves “Every reported lifecycle state has a documented meaning”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M01.03-C001-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “State vocabulary”; include the source counterexample “A directory's presence alone is treated as running” and the intended safe disposition.
- [ ] **UC-M01.03-C001-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “State count and unsupported state combinations” in the “State vocabulary” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M01.03-C001-T10 · Contract review:** Review the “State vocabulary” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M01.03-C002 · Delivery

**Original checklist item:** Define admitted, staged, built, booting, ready, running, draining, stopped, failed and quarantined.

- [ ] **UC-M01.03-C002-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “State vocabulary”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M01.03-C002-T02 · Change plan:** Break the source delivery for “State vocabulary” into concrete edit targets and reviewable outputs; keep the UC-M01.03 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M01.03-C002-T03 · Core artifact:** Create the “State vocabulary” model, schema or inventory that realizes this source instruction: Define admitted, staged, built, booting, ready, running, draining, stopped, failed and quarantined.
- [ ] **UC-M01.03-C002-T04 · Concrete realization:** Populate “State vocabulary” with one concrete worked case; map every required entity or field to its source and flag any unmapped entry.
- [ ] **UC-M01.03-C002-T05 · Invariant protection:** Add the actual guard, check or review criterion for “State vocabulary” needed to preserve “Every reported lifecycle state has a documented meaning”; record an enforcement gap where only a model exists.
- [ ] **UC-M01.03-C002-T06 · Dependency connection:** Connect the “State vocabulary” implementation to durable desired state, observed backend state and transition journals; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M01.03-C002-T07 · Resource behavior:** Account for “State count and unsupported state combinations” in “State vocabulary”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M01.03-C002-T08 · Delivery check:** Run the smallest real “State vocabulary” path and its adverse fixture “A directory's presence alone is treated as running”; retain actual output, state effects and final disposition.
- [ ] **UC-M01.03-C002-T09 · Patch review:** Review the “State vocabulary” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M01.03-C002-T10 · Delivery handoff:** Publish the “State vocabulary” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M01.03-C003 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Every reported lifecycle state has a documented meaning. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M01.03-C003-T01 · Named property:** Create a stable property/check name under this parent for “State vocabulary”; copy its required invariant exactly: “Every reported lifecycle state has a documented meaning”.
- [ ] **UC-M01.03-C003-T02 · Observable terms:** Define each term in the “State vocabulary” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M01.03-C003-T03 · Precondition set:** List the preconditions under which “Every reported lifecycle state has a documented meaning” must hold for “State vocabulary”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M01.03-C003-T04 · Transition coverage:** Map the “State vocabulary” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M01.03-C003-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “State vocabulary”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M01.03-C003-T06 · Satisfying fixture:** Create a concrete “State vocabulary” case that satisfies “Every reported lifecycle state has a documented meaning”; record its expected observation before running the assertion or review.
- [ ] **UC-M01.03-C003-T07 · Violating fixture:** Create the source counterexample “A directory's presence alone is treated as running” for “State vocabulary”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M01.03-C003-T08 · Enforcement evidence:** Exercise the “State vocabulary” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M01.03-C003-T09 · Regression linkage:** Link the “State vocabulary” property to changes in durable desired state, observed backend state and transition journals; record which dependency or contract changes require rerunning it.
- [ ] **UC-M01.03-C003-T10 · Property disposition:** Compare the satisfying and violating “State vocabulary” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M01.03-C004 · Integration

**Original checklist item:** Integrate state vocabulary with durable desired state, observed backend state and transition journals; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M01.03-C004-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “State vocabulary” across durable desired state, observed backend state and transition journals; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M01.03-C004-T02 · Field mapping:** Map every “State vocabulary” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M01.03-C004-T03 · Prerequisite identities:** Record the actual prerequisites for “State vocabulary” (source dependency list: UC-M01.02); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M01.03-C004-T04 · Ownership agreement:** Specify who owns “State vocabulary” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M01.03-C004-T05 · Handoff implementation:** Connect “State vocabulary” through the mapped seam using the real adapter or explicit specification reference; preserve “Every reported lifecycle state has a documented meaning” across the handoff.
- [ ] **UC-M01.03-C004-T06 · Absent-input case:** Omit one required “State vocabulary” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M01.03-C004-T07 · Stale-input case:** Supply an outdated “State vocabulary” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M01.03-C004-T08 · Incompatible-input case:** Supply an incompatible “State vocabulary” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M01.03-C004-T09 · Valid integration trace:** Run a valid “State vocabulary” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M01.03-C004-T10 · Seam review:** Reconcile the “State vocabulary” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M01.03-C005 · Valid-case test

**Original checklist item:** Run a valid-path fixture for state vocabulary; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M01.03-C005-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “State vocabulary” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M01.03-C005-T02 · Expected-result oracle:** Specify the “State vocabulary” expected result independently of the implementation output; include the property “Every reported lifecycle state has a documented meaning” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M01.03-C005-T03 · Fixture material:** Create the concrete “State vocabulary” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M01.03-C005-T04 · Target preparation:** Prepare the “State vocabulary” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M01.03-C005-T05 · Initial-state record:** Record the initial “State vocabulary” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M01.03-C005-T06 · Valid-path execution:** Execute the “State vocabulary” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M01.03-C005-T07 · Outcome comparison:** Compare every declared “State vocabulary” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M01.03-C005-T08 · State and bounds check:** Inspect the “State vocabulary” ownership/state effects and actual use of “State count and unsupported state combinations”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M01.03-C005-T09 · Repeatability check:** Repeat the same “State vocabulary” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M01.03-C005-T10 · Positive evidence:** Attach the “State vocabulary” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M01.03-C006 · Negative test

**Original checklist item:** Negative case: A directory's presence alone is treated as running. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M01.03-C006-T01 · Adverse-case definition:** Create a test record for the exact “State vocabulary” source counterexample: “A directory's presence alone is treated as running”; state which precondition or invariant it challenges.
- [ ] **UC-M01.03-C006-T02 · Safe fixture boundary:** Define the contained test boundary for “State vocabulary”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M01.03-C006-T03 · Valid control:** Construct a valid “State vocabulary” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M01.03-C006-T04 · Minimal adverse input:** Derive the “State vocabulary” adverse fixture from the control with the smallest documented change needed to reproduce “A directory's presence alone is treated as running”; retain that change as reproducible data.
- [ ] **UC-M01.03-C006-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “State vocabulary”; require “Every reported lifecycle state has a documented meaning” and forbid a false-success verdict.
- [ ] **UC-M01.03-C006-T06 · Adverse execution:** Exercise the “State vocabulary” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M01.03-C006-T07 · Effect inspection:** Inspect “State vocabulary” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M01.03-C006-T08 · Refusal versus failure:** Confirm the “State vocabulary” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M01.03-C006-T09 · Reset and retention:** Restore only the disposable “State vocabulary” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M01.03-C006-T10 · Negative regression:** Register the “State vocabulary” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M01.03-C007 · Change / failure test

**Original checklist item:** Exercise state vocabulary when the controller restarts between accepting intent and observing the resulting state; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M01.03-C007-T01 · Scenario record:** Write the “State vocabulary” change/failure scenario exactly as supplied: the controller restarts between accepting intent and observing the resulting state; identify the property that must remain true: “Every reported lifecycle state has a documented meaning”.
- [ ] **UC-M01.03-C007-T02 · Baseline capture:** Create a known-valid “State vocabulary” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M01.03-C007-T03 · Injection map:** Locate the “State vocabulary” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M01.03-C007-T04 · Disposition oracle:** Define the legal intermediate and final “State vocabulary” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M01.03-C007-T05 · Controlled trigger:** Introduce the controlled “State vocabulary” scenario in the disposable fixture: the controller restarts between accepting intent and observing the resulting state; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M01.03-C007-T06 · Intermediate inspection:** Inspect the “State vocabulary” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M01.03-C007-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “State vocabulary”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M01.03-C007-T08 · Stale-evidence cleanup:** Invalidate superseded “State vocabulary” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M01.03-C007-T09 · Repeat and compare:** Repeat the selected “State vocabulary” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M01.03-C007-T10 · Failure evidence:** Publish the “State vocabulary” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M01.03-C008 · Bounds

**Original checklist item:** Choose, document and test limits for state count and unsupported state combinations; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M01.03-C008-T01 · Quantity inventory:** Create a measurement inventory for “State vocabulary”: “State count and unsupported state combinations”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M01.03-C008-T02 · Measurement method:** Choose how to observe each “State vocabulary” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M01.03-C008-T03 · Budget decision:** Select justified resource and input limits for “State vocabulary”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M01.03-C008-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “State vocabulary” cases for “State count and unsupported state combinations”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M01.03-C008-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “State vocabulary” limit; preserve “Every reported lifecycle state has a documented meaning”.
- [ ] **UC-M01.03-C008-T06 · Normal measurement:** Run or review the normal “State vocabulary” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M01.03-C008-T07 · At-limit measurement:** Exercise the “State vocabulary” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M01.03-C008-T08 · Over-limit measurement:** Exercise the “State vocabulary” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M01.03-C008-T09 · Uncovered-scope report:** List the “State vocabulary” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M01.03-C008-T10 · Limit evidence:** Publish the selected “State vocabulary” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M01.03-C009 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for state vocabulary with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M01.03-C009-T01 · Event inventory:** List the “State vocabulary” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M01.03-C009-T02 · Diagnostic schema:** Define nonsecret fields for “State vocabulary” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M01.03-C009-T03 · Failure mapping:** Map each documented “State vocabulary” refusal or error to a diagnostic outcome; include “A directory's presence alone is treated as running” and prohibit conversion into a success message.
- [ ] **UC-M01.03-C009-T04 · Emission path:** Add the “State vocabulary” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M01.03-C009-T05 · Redaction check:** Test “State vocabulary” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M01.03-C009-T06 · Output budget:** Set and exercise bounded “State vocabulary” message size, rate and retention compatible with “State count and unsupported state combinations”; define truncation behavior that preserves the final reason.
- [ ] **UC-M01.03-C009-T07 · Success/refusal fixtures:** Capture “State vocabulary” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M01.03-C009-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “State vocabulary” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M01.03-C009-T09 · Operator review:** Read the “State vocabulary” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M01.03-C009-T10 · Diagnostic evidence:** Publish redacted “State vocabulary” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M01.03-C010 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for state vocabulary; label unexecuted checks as untested.

- [ ] **UC-M01.03-C010-T01 · Evidence inventory:** List the “State vocabulary” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M01.03-C010-T02 · Artifact references:** Record the exact “State vocabulary” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M01.03-C010-T03 · Fixture references:** Attach the “State vocabulary” fixture IDs, input identities and oracle definition; preserve the source counterexample “A directory's presence alone is treated as running” as a distinct evidence case.
- [ ] **UC-M01.03-C010-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “State vocabulary”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M01.03-C010-T05 · Environment record:** Record the actual “State vocabulary” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M01.03-C010-T06 · Expected versus observed:** Pair every “State vocabulary” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M01.03-C010-T07 · Failure and limit records:** Attach “State vocabulary” change/failure and bounds evidence where required; include uncovered “State count and unsupported state combinations” and unresolved violations of “Every reported lifecycle state has a documented meaning”.
- [ ] **UC-M01.03-C010-T08 · Evidence hygiene:** Check the “State vocabulary” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M01.03-C010-T09 · Reproduction review:** Have the “State vocabulary” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M01.03-C010-T10 · Acceptance linkage:** Link the “State vocabulary” evidence to its parent and UC-M01.03 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 02. Desired versus observed state

**Source delivery:** Store requested intent separately from directly observed backend state.

**Source invariant:** A desired running state is not evidence of a running guest.

**Source negative case:** A failed boot leaves the desired state displayed as observed health.

**Source bounded quantities:** Observation age and reconciliation delay.

### UC-M01.03-C011 · Contract

**Original checklist item:** Specify desired versus observed state inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M01.03-C011-T01 · Scope statement:** Draft the operation boundary for “Desired versus observed state” within Lifecycle state machine; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M01.03-C011-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Desired versus observed state”; record each producer, representation and missing-value meaning.
- [ ] **UC-M01.03-C011-T03 · Output inventory:** List the outputs of “Desired versus observed state” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M01.03-C011-T04 · Field dictionary:** Create a field-and-term dictionary for “Desired versus observed state”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M01.03-C011-T05 · Prerequisite contract:** Map “Desired versus observed state” to the source component prerequisites (UC-M01.02); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M01.03-C011-T06 · Authority map:** Identify who may produce, change and consume “Desired versus observed state”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M01.03-C011-T07 · Invariant clause:** Add a normative clause for “Desired versus observed state” that preserves “A desired running state is not evidence of a running guest”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M01.03-C011-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Desired versus observed state”; include the source counterexample “A failed boot leaves the desired state displayed as observed health” and the intended safe disposition.
- [ ] **UC-M01.03-C011-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Observation age and reconciliation delay” in the “Desired versus observed state” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M01.03-C011-T10 · Contract review:** Review the “Desired versus observed state” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M01.03-C012 · Delivery

**Original checklist item:** Store requested intent separately from directly observed backend state.

- [ ] **UC-M01.03-C012-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Desired versus observed state”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M01.03-C012-T02 · Change plan:** Break the source delivery for “Desired versus observed state” into concrete edit targets and reviewable outputs; keep the UC-M01.03 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M01.03-C012-T03 · Core artifact:** Implement the smallest selected-profile change for “Desired versus observed state” that realizes this source instruction: Store requested intent separately from directly observed backend state.
- [ ] **UC-M01.03-C012-T04 · Concrete realization:** Trace “Desired versus observed state” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M01.03-C012-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Desired versus observed state” needed to preserve “A desired running state is not evidence of a running guest”; record an enforcement gap where only a model exists.
- [ ] **UC-M01.03-C012-T06 · Dependency connection:** Connect the “Desired versus observed state” implementation to durable desired state, observed backend state and transition journals; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M01.03-C012-T07 · Resource behavior:** Account for “Observation age and reconciliation delay” in “Desired versus observed state”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M01.03-C012-T08 · Delivery check:** Run the smallest real “Desired versus observed state” path and its adverse fixture “A failed boot leaves the desired state displayed as observed health”; retain actual output, state effects and final disposition.
- [ ] **UC-M01.03-C012-T09 · Patch review:** Review the “Desired versus observed state” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M01.03-C012-T10 · Delivery handoff:** Publish the “Desired versus observed state” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M01.03-C013 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: A desired running state is not evidence of a running guest. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M01.03-C013-T01 · Named property:** Create a stable property/check name under this parent for “Desired versus observed state”; copy its required invariant exactly: “A desired running state is not evidence of a running guest”.
- [ ] **UC-M01.03-C013-T02 · Observable terms:** Define each term in the “Desired versus observed state” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M01.03-C013-T03 · Precondition set:** List the preconditions under which “A desired running state is not evidence of a running guest” must hold for “Desired versus observed state”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M01.03-C013-T04 · Transition coverage:** Map the “Desired versus observed state” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M01.03-C013-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Desired versus observed state”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M01.03-C013-T06 · Satisfying fixture:** Create a concrete “Desired versus observed state” case that satisfies “A desired running state is not evidence of a running guest”; record its expected observation before running the assertion or review.
- [ ] **UC-M01.03-C013-T07 · Violating fixture:** Create the source counterexample “A failed boot leaves the desired state displayed as observed health” for “Desired versus observed state”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M01.03-C013-T08 · Enforcement evidence:** Exercise the “Desired versus observed state” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M01.03-C013-T09 · Regression linkage:** Link the “Desired versus observed state” property to changes in durable desired state, observed backend state and transition journals; record which dependency or contract changes require rerunning it.
- [ ] **UC-M01.03-C013-T10 · Property disposition:** Compare the satisfying and violating “Desired versus observed state” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M01.03-C014 · Integration

**Original checklist item:** Integrate desired versus observed state with durable desired state, observed backend state and transition journals; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M01.03-C014-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Desired versus observed state” across durable desired state, observed backend state and transition journals; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M01.03-C014-T02 · Field mapping:** Map every “Desired versus observed state” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M01.03-C014-T03 · Prerequisite identities:** Record the actual prerequisites for “Desired versus observed state” (source dependency list: UC-M01.02); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M01.03-C014-T04 · Ownership agreement:** Specify who owns “Desired versus observed state” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M01.03-C014-T05 · Handoff implementation:** Connect “Desired versus observed state” through the mapped seam using the real adapter or explicit specification reference; preserve “A desired running state is not evidence of a running guest” across the handoff.
- [ ] **UC-M01.03-C014-T06 · Absent-input case:** Omit one required “Desired versus observed state” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M01.03-C014-T07 · Stale-input case:** Supply an outdated “Desired versus observed state” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M01.03-C014-T08 · Incompatible-input case:** Supply an incompatible “Desired versus observed state” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M01.03-C014-T09 · Valid integration trace:** Run a valid “Desired versus observed state” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M01.03-C014-T10 · Seam review:** Reconcile the “Desired versus observed state” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M01.03-C015 · Valid-case test

**Original checklist item:** Run a valid-path fixture for desired versus observed state; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M01.03-C015-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Desired versus observed state” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M01.03-C015-T02 · Expected-result oracle:** Specify the “Desired versus observed state” expected result independently of the implementation output; include the property “A desired running state is not evidence of a running guest” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M01.03-C015-T03 · Fixture material:** Create the concrete “Desired versus observed state” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M01.03-C015-T04 · Target preparation:** Prepare the “Desired versus observed state” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M01.03-C015-T05 · Initial-state record:** Record the initial “Desired versus observed state” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M01.03-C015-T06 · Valid-path execution:** Execute the “Desired versus observed state” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M01.03-C015-T07 · Outcome comparison:** Compare every declared “Desired versus observed state” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M01.03-C015-T08 · State and bounds check:** Inspect the “Desired versus observed state” ownership/state effects and actual use of “Observation age and reconciliation delay”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M01.03-C015-T09 · Repeatability check:** Repeat the same “Desired versus observed state” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M01.03-C015-T10 · Positive evidence:** Attach the “Desired versus observed state” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M01.03-C016 · Negative test

**Original checklist item:** Negative case: A failed boot leaves the desired state displayed as observed health. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M01.03-C016-T01 · Adverse-case definition:** Create a test record for the exact “Desired versus observed state” source counterexample: “A failed boot leaves the desired state displayed as observed health”; state which precondition or invariant it challenges.
- [ ] **UC-M01.03-C016-T02 · Safe fixture boundary:** Define the contained test boundary for “Desired versus observed state”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M01.03-C016-T03 · Valid control:** Construct a valid “Desired versus observed state” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M01.03-C016-T04 · Minimal adverse input:** Derive the “Desired versus observed state” adverse fixture from the control with the smallest documented change needed to reproduce “A failed boot leaves the desired state displayed as observed health”; retain that change as reproducible data.
- [ ] **UC-M01.03-C016-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Desired versus observed state”; require “A desired running state is not evidence of a running guest” and forbid a false-success verdict.
- [ ] **UC-M01.03-C016-T06 · Adverse execution:** Exercise the “Desired versus observed state” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M01.03-C016-T07 · Effect inspection:** Inspect “Desired versus observed state” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M01.03-C016-T08 · Refusal versus failure:** Confirm the “Desired versus observed state” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M01.03-C016-T09 · Reset and retention:** Restore only the disposable “Desired versus observed state” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M01.03-C016-T10 · Negative regression:** Register the “Desired versus observed state” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M01.03-C017 · Change / failure test

**Original checklist item:** Exercise desired versus observed state when the controller restarts between accepting intent and observing the resulting state; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M01.03-C017-T01 · Scenario record:** Write the “Desired versus observed state” change/failure scenario exactly as supplied: the controller restarts between accepting intent and observing the resulting state; identify the property that must remain true: “A desired running state is not evidence of a running guest”.
- [ ] **UC-M01.03-C017-T02 · Baseline capture:** Create a known-valid “Desired versus observed state” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M01.03-C017-T03 · Injection map:** Locate the “Desired versus observed state” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M01.03-C017-T04 · Disposition oracle:** Define the legal intermediate and final “Desired versus observed state” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M01.03-C017-T05 · Controlled trigger:** Introduce the controlled “Desired versus observed state” scenario in the disposable fixture: the controller restarts between accepting intent and observing the resulting state; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M01.03-C017-T06 · Intermediate inspection:** Inspect the “Desired versus observed state” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M01.03-C017-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Desired versus observed state”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M01.03-C017-T08 · Stale-evidence cleanup:** Invalidate superseded “Desired versus observed state” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M01.03-C017-T09 · Repeat and compare:** Repeat the selected “Desired versus observed state” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M01.03-C017-T10 · Failure evidence:** Publish the “Desired versus observed state” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M01.03-C018 · Bounds

**Original checklist item:** Choose, document and test limits for observation age and reconciliation delay; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M01.03-C018-T01 · Quantity inventory:** Create a measurement inventory for “Desired versus observed state”: “Observation age and reconciliation delay”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M01.03-C018-T02 · Measurement method:** Choose how to observe each “Desired versus observed state” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M01.03-C018-T03 · Budget decision:** Select justified resource and input limits for “Desired versus observed state”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M01.03-C018-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Desired versus observed state” cases for “Observation age and reconciliation delay”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M01.03-C018-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Desired versus observed state” limit; preserve “A desired running state is not evidence of a running guest”.
- [ ] **UC-M01.03-C018-T06 · Normal measurement:** Run or review the normal “Desired versus observed state” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M01.03-C018-T07 · At-limit measurement:** Exercise the “Desired versus observed state” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M01.03-C018-T08 · Over-limit measurement:** Exercise the “Desired versus observed state” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M01.03-C018-T09 · Uncovered-scope report:** List the “Desired versus observed state” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M01.03-C018-T10 · Limit evidence:** Publish the selected “Desired versus observed state” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M01.03-C019 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for desired versus observed state with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M01.03-C019-T01 · Event inventory:** List the “Desired versus observed state” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M01.03-C019-T02 · Diagnostic schema:** Define nonsecret fields for “Desired versus observed state” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M01.03-C019-T03 · Failure mapping:** Map each documented “Desired versus observed state” refusal or error to a diagnostic outcome; include “A failed boot leaves the desired state displayed as observed health” and prohibit conversion into a success message.
- [ ] **UC-M01.03-C019-T04 · Emission path:** Add the “Desired versus observed state” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M01.03-C019-T05 · Redaction check:** Test “Desired versus observed state” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M01.03-C019-T06 · Output budget:** Set and exercise bounded “Desired versus observed state” message size, rate and retention compatible with “Observation age and reconciliation delay”; define truncation behavior that preserves the final reason.
- [ ] **UC-M01.03-C019-T07 · Success/refusal fixtures:** Capture “Desired versus observed state” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M01.03-C019-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Desired versus observed state” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M01.03-C019-T09 · Operator review:** Read the “Desired versus observed state” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M01.03-C019-T10 · Diagnostic evidence:** Publish redacted “Desired versus observed state” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M01.03-C020 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for desired versus observed state; label unexecuted checks as untested.

- [ ] **UC-M01.03-C020-T01 · Evidence inventory:** List the “Desired versus observed state” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M01.03-C020-T02 · Artifact references:** Record the exact “Desired versus observed state” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M01.03-C020-T03 · Fixture references:** Attach the “Desired versus observed state” fixture IDs, input identities and oracle definition; preserve the source counterexample “A failed boot leaves the desired state displayed as observed health” as a distinct evidence case.
- [ ] **UC-M01.03-C020-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Desired versus observed state”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M01.03-C020-T05 · Environment record:** Record the actual “Desired versus observed state” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M01.03-C020-T06 · Expected versus observed:** Pair every “Desired versus observed state” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M01.03-C020-T07 · Failure and limit records:** Attach “Desired versus observed state” change/failure and bounds evidence where required; include uncovered “Observation age and reconciliation delay” and unresolved violations of “A desired running state is not evidence of a running guest”.
- [ ] **UC-M01.03-C020-T08 · Evidence hygiene:** Check the “Desired versus observed state” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M01.03-C020-T09 · Reproduction review:** Have the “Desired versus observed state” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M01.03-C020-T10 · Acceptance linkage:** Link the “Desired versus observed state” evidence to its parent and UC-M01.03 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 03. Transition matrix

**Source delivery:** Specify legal predecessors and side effects for every state transition.

**Source invariant:** A transition cannot skip its required predecessor.

**Source negative case:** A staged workload moves directly to running without readiness.

**Source bounded quantities:** Transition count and reachable-state coverage.

### UC-M01.03-C021 · Contract

**Original checklist item:** Specify transition matrix inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M01.03-C021-T01 · Scope statement:** Draft the operation boundary for “Transition matrix” within Lifecycle state machine; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M01.03-C021-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Transition matrix”; record each producer, representation and missing-value meaning.
- [ ] **UC-M01.03-C021-T03 · Output inventory:** List the outputs of “Transition matrix” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M01.03-C021-T04 · Field dictionary:** Create a field-and-term dictionary for “Transition matrix”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M01.03-C021-T05 · Prerequisite contract:** Map “Transition matrix” to the source component prerequisites (UC-M01.02); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M01.03-C021-T06 · Authority map:** Identify who may produce, change and consume “Transition matrix”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M01.03-C021-T07 · Invariant clause:** Add a normative clause for “Transition matrix” that preserves “A transition cannot skip its required predecessor”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M01.03-C021-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Transition matrix”; include the source counterexample “A staged workload moves directly to running without readiness” and the intended safe disposition.
- [ ] **UC-M01.03-C021-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Transition count and reachable-state coverage” in the “Transition matrix” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M01.03-C021-T10 · Contract review:** Review the “Transition matrix” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M01.03-C022 · Delivery

**Original checklist item:** Specify legal predecessors and side effects for every state transition.

- [ ] **UC-M01.03-C022-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Transition matrix”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M01.03-C022-T02 · Change plan:** Break the source delivery for “Transition matrix” into concrete edit targets and reviewable outputs; keep the UC-M01.03 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M01.03-C022-T03 · Core artifact:** Create the “Transition matrix” model, schema or inventory that realizes this source instruction: Specify legal predecessors and side effects for every state transition.
- [ ] **UC-M01.03-C022-T04 · Concrete realization:** Populate “Transition matrix” with one concrete worked case; map every required entity or field to its source and flag any unmapped entry.
- [ ] **UC-M01.03-C022-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Transition matrix” needed to preserve “A transition cannot skip its required predecessor”; record an enforcement gap where only a model exists.
- [ ] **UC-M01.03-C022-T06 · Dependency connection:** Connect the “Transition matrix” implementation to durable desired state, observed backend state and transition journals; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M01.03-C022-T07 · Resource behavior:** Account for “Transition count and reachable-state coverage” in “Transition matrix”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M01.03-C022-T08 · Delivery check:** Run the smallest real “Transition matrix” path and its adverse fixture “A staged workload moves directly to running without readiness”; retain actual output, state effects and final disposition.
- [ ] **UC-M01.03-C022-T09 · Patch review:** Review the “Transition matrix” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M01.03-C022-T10 · Delivery handoff:** Publish the “Transition matrix” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M01.03-C023 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: A transition cannot skip its required predecessor. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M01.03-C023-T01 · Named property:** Create a stable property/check name under this parent for “Transition matrix”; copy its required invariant exactly: “A transition cannot skip its required predecessor”.
- [ ] **UC-M01.03-C023-T02 · Observable terms:** Define each term in the “Transition matrix” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M01.03-C023-T03 · Precondition set:** List the preconditions under which “A transition cannot skip its required predecessor” must hold for “Transition matrix”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M01.03-C023-T04 · Transition coverage:** Map the “Transition matrix” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M01.03-C023-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Transition matrix”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M01.03-C023-T06 · Satisfying fixture:** Create a concrete “Transition matrix” case that satisfies “A transition cannot skip its required predecessor”; record its expected observation before running the assertion or review.
- [ ] **UC-M01.03-C023-T07 · Violating fixture:** Create the source counterexample “A staged workload moves directly to running without readiness” for “Transition matrix”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M01.03-C023-T08 · Enforcement evidence:** Exercise the “Transition matrix” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M01.03-C023-T09 · Regression linkage:** Link the “Transition matrix” property to changes in durable desired state, observed backend state and transition journals; record which dependency or contract changes require rerunning it.
- [ ] **UC-M01.03-C023-T10 · Property disposition:** Compare the satisfying and violating “Transition matrix” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M01.03-C024 · Integration

**Original checklist item:** Integrate transition matrix with durable desired state, observed backend state and transition journals; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M01.03-C024-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Transition matrix” across durable desired state, observed backend state and transition journals; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M01.03-C024-T02 · Field mapping:** Map every “Transition matrix” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M01.03-C024-T03 · Prerequisite identities:** Record the actual prerequisites for “Transition matrix” (source dependency list: UC-M01.02); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M01.03-C024-T04 · Ownership agreement:** Specify who owns “Transition matrix” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M01.03-C024-T05 · Handoff implementation:** Connect “Transition matrix” through the mapped seam using the real adapter or explicit specification reference; preserve “A transition cannot skip its required predecessor” across the handoff.
- [ ] **UC-M01.03-C024-T06 · Absent-input case:** Omit one required “Transition matrix” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M01.03-C024-T07 · Stale-input case:** Supply an outdated “Transition matrix” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M01.03-C024-T08 · Incompatible-input case:** Supply an incompatible “Transition matrix” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M01.03-C024-T09 · Valid integration trace:** Run a valid “Transition matrix” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M01.03-C024-T10 · Seam review:** Reconcile the “Transition matrix” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M01.03-C025 · Valid-case test

**Original checklist item:** Run a valid-path fixture for transition matrix; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M01.03-C025-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Transition matrix” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M01.03-C025-T02 · Expected-result oracle:** Specify the “Transition matrix” expected result independently of the implementation output; include the property “A transition cannot skip its required predecessor” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M01.03-C025-T03 · Fixture material:** Create the concrete “Transition matrix” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M01.03-C025-T04 · Target preparation:** Prepare the “Transition matrix” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M01.03-C025-T05 · Initial-state record:** Record the initial “Transition matrix” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M01.03-C025-T06 · Valid-path execution:** Execute the “Transition matrix” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M01.03-C025-T07 · Outcome comparison:** Compare every declared “Transition matrix” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M01.03-C025-T08 · State and bounds check:** Inspect the “Transition matrix” ownership/state effects and actual use of “Transition count and reachable-state coverage”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M01.03-C025-T09 · Repeatability check:** Repeat the same “Transition matrix” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M01.03-C025-T10 · Positive evidence:** Attach the “Transition matrix” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M01.03-C026 · Negative test

**Original checklist item:** Negative case: A staged workload moves directly to running without readiness. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M01.03-C026-T01 · Adverse-case definition:** Create a test record for the exact “Transition matrix” source counterexample: “A staged workload moves directly to running without readiness”; state which precondition or invariant it challenges.
- [ ] **UC-M01.03-C026-T02 · Safe fixture boundary:** Define the contained test boundary for “Transition matrix”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M01.03-C026-T03 · Valid control:** Construct a valid “Transition matrix” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M01.03-C026-T04 · Minimal adverse input:** Derive the “Transition matrix” adverse fixture from the control with the smallest documented change needed to reproduce “A staged workload moves directly to running without readiness”; retain that change as reproducible data.
- [ ] **UC-M01.03-C026-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Transition matrix”; require “A transition cannot skip its required predecessor” and forbid a false-success verdict.
- [ ] **UC-M01.03-C026-T06 · Adverse execution:** Exercise the “Transition matrix” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M01.03-C026-T07 · Effect inspection:** Inspect “Transition matrix” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M01.03-C026-T08 · Refusal versus failure:** Confirm the “Transition matrix” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M01.03-C026-T09 · Reset and retention:** Restore only the disposable “Transition matrix” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M01.03-C026-T10 · Negative regression:** Register the “Transition matrix” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M01.03-C027 · Change / failure test

**Original checklist item:** Exercise transition matrix when the controller restarts between accepting intent and observing the resulting state; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M01.03-C027-T01 · Scenario record:** Write the “Transition matrix” change/failure scenario exactly as supplied: the controller restarts between accepting intent and observing the resulting state; identify the property that must remain true: “A transition cannot skip its required predecessor”.
- [ ] **UC-M01.03-C027-T02 · Baseline capture:** Create a known-valid “Transition matrix” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M01.03-C027-T03 · Injection map:** Locate the “Transition matrix” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M01.03-C027-T04 · Disposition oracle:** Define the legal intermediate and final “Transition matrix” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M01.03-C027-T05 · Controlled trigger:** Introduce the controlled “Transition matrix” scenario in the disposable fixture: the controller restarts between accepting intent and observing the resulting state; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M01.03-C027-T06 · Intermediate inspection:** Inspect the “Transition matrix” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M01.03-C027-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Transition matrix”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M01.03-C027-T08 · Stale-evidence cleanup:** Invalidate superseded “Transition matrix” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M01.03-C027-T09 · Repeat and compare:** Repeat the selected “Transition matrix” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M01.03-C027-T10 · Failure evidence:** Publish the “Transition matrix” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M01.03-C028 · Bounds

**Original checklist item:** Choose, document and test limits for transition count and reachable-state coverage; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M01.03-C028-T01 · Quantity inventory:** Create a measurement inventory for “Transition matrix”: “Transition count and reachable-state coverage”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M01.03-C028-T02 · Measurement method:** Choose how to observe each “Transition matrix” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M01.03-C028-T03 · Budget decision:** Select justified resource and input limits for “Transition matrix”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M01.03-C028-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Transition matrix” cases for “Transition count and reachable-state coverage”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M01.03-C028-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Transition matrix” limit; preserve “A transition cannot skip its required predecessor”.
- [ ] **UC-M01.03-C028-T06 · Normal measurement:** Run or review the normal “Transition matrix” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M01.03-C028-T07 · At-limit measurement:** Exercise the “Transition matrix” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M01.03-C028-T08 · Over-limit measurement:** Exercise the “Transition matrix” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M01.03-C028-T09 · Uncovered-scope report:** List the “Transition matrix” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M01.03-C028-T10 · Limit evidence:** Publish the selected “Transition matrix” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M01.03-C029 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for transition matrix with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M01.03-C029-T01 · Event inventory:** List the “Transition matrix” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M01.03-C029-T02 · Diagnostic schema:** Define nonsecret fields for “Transition matrix” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M01.03-C029-T03 · Failure mapping:** Map each documented “Transition matrix” refusal or error to a diagnostic outcome; include “A staged workload moves directly to running without readiness” and prohibit conversion into a success message.
- [ ] **UC-M01.03-C029-T04 · Emission path:** Add the “Transition matrix” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M01.03-C029-T05 · Redaction check:** Test “Transition matrix” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M01.03-C029-T06 · Output budget:** Set and exercise bounded “Transition matrix” message size, rate and retention compatible with “Transition count and reachable-state coverage”; define truncation behavior that preserves the final reason.
- [ ] **UC-M01.03-C029-T07 · Success/refusal fixtures:** Capture “Transition matrix” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M01.03-C029-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Transition matrix” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M01.03-C029-T09 · Operator review:** Read the “Transition matrix” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M01.03-C029-T10 · Diagnostic evidence:** Publish redacted “Transition matrix” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M01.03-C030 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for transition matrix; label unexecuted checks as untested.

- [ ] **UC-M01.03-C030-T01 · Evidence inventory:** List the “Transition matrix” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M01.03-C030-T02 · Artifact references:** Record the exact “Transition matrix” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M01.03-C030-T03 · Fixture references:** Attach the “Transition matrix” fixture IDs, input identities and oracle definition; preserve the source counterexample “A staged workload moves directly to running without readiness” as a distinct evidence case.
- [ ] **UC-M01.03-C030-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Transition matrix”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M01.03-C030-T05 · Environment record:** Record the actual “Transition matrix” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M01.03-C030-T06 · Expected versus observed:** Pair every “Transition matrix” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M01.03-C030-T07 · Failure and limit records:** Attach “Transition matrix” change/failure and bounds evidence where required; include uncovered “Transition count and reachable-state coverage” and unresolved violations of “A transition cannot skip its required predecessor”.
- [ ] **UC-M01.03-C030-T08 · Evidence hygiene:** Check the “Transition matrix” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M01.03-C030-T09 · Reproduction review:** Have the “Transition matrix” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M01.03-C030-T10 · Acceptance linkage:** Link the “Transition matrix” evidence to its parent and UC-M01.03 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 04. Durable reasons

**Source delivery:** Persist the cause, actor, generation and evidence for each transition.

**Source invariant:** A state change has a recoverable explanation.

**Source negative case:** A crash replaces the last transition reason with an empty record.

**Source bounded quantities:** Reason record size and retention duration.

### UC-M01.03-C031 · Contract

**Original checklist item:** Specify durable reasons inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M01.03-C031-T01 · Scope statement:** Draft the operation boundary for “Durable reasons” within Lifecycle state machine; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M01.03-C031-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Durable reasons”; record each producer, representation and missing-value meaning.
- [ ] **UC-M01.03-C031-T03 · Output inventory:** List the outputs of “Durable reasons” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M01.03-C031-T04 · Field dictionary:** Create a field-and-term dictionary for “Durable reasons”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M01.03-C031-T05 · Prerequisite contract:** Map “Durable reasons” to the source component prerequisites (UC-M01.02); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M01.03-C031-T06 · Authority map:** Identify who may produce, change and consume “Durable reasons”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M01.03-C031-T07 · Invariant clause:** Add a normative clause for “Durable reasons” that preserves “A state change has a recoverable explanation”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M01.03-C031-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Durable reasons”; include the source counterexample “A crash replaces the last transition reason with an empty record” and the intended safe disposition.
- [ ] **UC-M01.03-C031-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Reason record size and retention duration” in the “Durable reasons” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M01.03-C031-T10 · Contract review:** Review the “Durable reasons” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M01.03-C032 · Delivery

**Original checklist item:** Persist the cause, actor, generation and evidence for each transition.

- [ ] **UC-M01.03-C032-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Durable reasons”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M01.03-C032-T02 · Change plan:** Break the source delivery for “Durable reasons” into concrete edit targets and reviewable outputs; keep the UC-M01.03 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M01.03-C032-T03 · Core artifact:** Implement the smallest selected-profile change for “Durable reasons” that realizes this source instruction: Persist the cause, actor, generation and evidence for each transition.
- [ ] **UC-M01.03-C032-T04 · Concrete realization:** Trace “Durable reasons” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M01.03-C032-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Durable reasons” needed to preserve “A state change has a recoverable explanation”; record an enforcement gap where only a model exists.
- [ ] **UC-M01.03-C032-T06 · Dependency connection:** Connect the “Durable reasons” implementation to durable desired state, observed backend state and transition journals; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M01.03-C032-T07 · Resource behavior:** Account for “Reason record size and retention duration” in “Durable reasons”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M01.03-C032-T08 · Delivery check:** Run the smallest real “Durable reasons” path and its adverse fixture “A crash replaces the last transition reason with an empty record”; retain actual output, state effects and final disposition.
- [ ] **UC-M01.03-C032-T09 · Patch review:** Review the “Durable reasons” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M01.03-C032-T10 · Delivery handoff:** Publish the “Durable reasons” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M01.03-C033 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: A state change has a recoverable explanation. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M01.03-C033-T01 · Named property:** Create a stable property/check name under this parent for “Durable reasons”; copy its required invariant exactly: “A state change has a recoverable explanation”.
- [ ] **UC-M01.03-C033-T02 · Observable terms:** Define each term in the “Durable reasons” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M01.03-C033-T03 · Precondition set:** List the preconditions under which “A state change has a recoverable explanation” must hold for “Durable reasons”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M01.03-C033-T04 · Transition coverage:** Map the “Durable reasons” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M01.03-C033-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Durable reasons”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M01.03-C033-T06 · Satisfying fixture:** Create a concrete “Durable reasons” case that satisfies “A state change has a recoverable explanation”; record its expected observation before running the assertion or review.
- [ ] **UC-M01.03-C033-T07 · Violating fixture:** Create the source counterexample “A crash replaces the last transition reason with an empty record” for “Durable reasons”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M01.03-C033-T08 · Enforcement evidence:** Exercise the “Durable reasons” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M01.03-C033-T09 · Regression linkage:** Link the “Durable reasons” property to changes in durable desired state, observed backend state and transition journals; record which dependency or contract changes require rerunning it.
- [ ] **UC-M01.03-C033-T10 · Property disposition:** Compare the satisfying and violating “Durable reasons” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M01.03-C034 · Integration

**Original checklist item:** Integrate durable reasons with durable desired state, observed backend state and transition journals; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M01.03-C034-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Durable reasons” across durable desired state, observed backend state and transition journals; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M01.03-C034-T02 · Field mapping:** Map every “Durable reasons” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M01.03-C034-T03 · Prerequisite identities:** Record the actual prerequisites for “Durable reasons” (source dependency list: UC-M01.02); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M01.03-C034-T04 · Ownership agreement:** Specify who owns “Durable reasons” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M01.03-C034-T05 · Handoff implementation:** Connect “Durable reasons” through the mapped seam using the real adapter or explicit specification reference; preserve “A state change has a recoverable explanation” across the handoff.
- [ ] **UC-M01.03-C034-T06 · Absent-input case:** Omit one required “Durable reasons” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M01.03-C034-T07 · Stale-input case:** Supply an outdated “Durable reasons” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M01.03-C034-T08 · Incompatible-input case:** Supply an incompatible “Durable reasons” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M01.03-C034-T09 · Valid integration trace:** Run a valid “Durable reasons” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M01.03-C034-T10 · Seam review:** Reconcile the “Durable reasons” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M01.03-C035 · Valid-case test

**Original checklist item:** Run a valid-path fixture for durable reasons; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M01.03-C035-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Durable reasons” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M01.03-C035-T02 · Expected-result oracle:** Specify the “Durable reasons” expected result independently of the implementation output; include the property “A state change has a recoverable explanation” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M01.03-C035-T03 · Fixture material:** Create the concrete “Durable reasons” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M01.03-C035-T04 · Target preparation:** Prepare the “Durable reasons” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M01.03-C035-T05 · Initial-state record:** Record the initial “Durable reasons” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M01.03-C035-T06 · Valid-path execution:** Execute the “Durable reasons” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M01.03-C035-T07 · Outcome comparison:** Compare every declared “Durable reasons” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M01.03-C035-T08 · State and bounds check:** Inspect the “Durable reasons” ownership/state effects and actual use of “Reason record size and retention duration”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M01.03-C035-T09 · Repeatability check:** Repeat the same “Durable reasons” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M01.03-C035-T10 · Positive evidence:** Attach the “Durable reasons” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M01.03-C036 · Negative test

**Original checklist item:** Negative case: A crash replaces the last transition reason with an empty record. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M01.03-C036-T01 · Adverse-case definition:** Create a test record for the exact “Durable reasons” source counterexample: “A crash replaces the last transition reason with an empty record”; state which precondition or invariant it challenges.
- [ ] **UC-M01.03-C036-T02 · Safe fixture boundary:** Define the contained test boundary for “Durable reasons”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M01.03-C036-T03 · Valid control:** Construct a valid “Durable reasons” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M01.03-C036-T04 · Minimal adverse input:** Derive the “Durable reasons” adverse fixture from the control with the smallest documented change needed to reproduce “A crash replaces the last transition reason with an empty record”; retain that change as reproducible data.
- [ ] **UC-M01.03-C036-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Durable reasons”; require “A state change has a recoverable explanation” and forbid a false-success verdict.
- [ ] **UC-M01.03-C036-T06 · Adverse execution:** Exercise the “Durable reasons” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M01.03-C036-T07 · Effect inspection:** Inspect “Durable reasons” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M01.03-C036-T08 · Refusal versus failure:** Confirm the “Durable reasons” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M01.03-C036-T09 · Reset and retention:** Restore only the disposable “Durable reasons” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M01.03-C036-T10 · Negative regression:** Register the “Durable reasons” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M01.03-C037 · Change / failure test

**Original checklist item:** Exercise durable reasons when the controller restarts between accepting intent and observing the resulting state; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M01.03-C037-T01 · Scenario record:** Write the “Durable reasons” change/failure scenario exactly as supplied: the controller restarts between accepting intent and observing the resulting state; identify the property that must remain true: “A state change has a recoverable explanation”.
- [ ] **UC-M01.03-C037-T02 · Baseline capture:** Create a known-valid “Durable reasons” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M01.03-C037-T03 · Injection map:** Locate the “Durable reasons” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M01.03-C037-T04 · Disposition oracle:** Define the legal intermediate and final “Durable reasons” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M01.03-C037-T05 · Controlled trigger:** Introduce the controlled “Durable reasons” scenario in the disposable fixture: the controller restarts between accepting intent and observing the resulting state; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M01.03-C037-T06 · Intermediate inspection:** Inspect the “Durable reasons” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M01.03-C037-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Durable reasons”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M01.03-C037-T08 · Stale-evidence cleanup:** Invalidate superseded “Durable reasons” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M01.03-C037-T09 · Repeat and compare:** Repeat the selected “Durable reasons” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M01.03-C037-T10 · Failure evidence:** Publish the “Durable reasons” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M01.03-C038 · Bounds

**Original checklist item:** Choose, document and test limits for reason record size and retention duration; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M01.03-C038-T01 · Quantity inventory:** Create a measurement inventory for “Durable reasons”: “Reason record size and retention duration”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M01.03-C038-T02 · Measurement method:** Choose how to observe each “Durable reasons” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M01.03-C038-T03 · Budget decision:** Select justified resource and input limits for “Durable reasons”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M01.03-C038-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Durable reasons” cases for “Reason record size and retention duration”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M01.03-C038-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Durable reasons” limit; preserve “A state change has a recoverable explanation”.
- [ ] **UC-M01.03-C038-T06 · Normal measurement:** Run or review the normal “Durable reasons” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M01.03-C038-T07 · At-limit measurement:** Exercise the “Durable reasons” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M01.03-C038-T08 · Over-limit measurement:** Exercise the “Durable reasons” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M01.03-C038-T09 · Uncovered-scope report:** List the “Durable reasons” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M01.03-C038-T10 · Limit evidence:** Publish the selected “Durable reasons” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M01.03-C039 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for durable reasons with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M01.03-C039-T01 · Event inventory:** List the “Durable reasons” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M01.03-C039-T02 · Diagnostic schema:** Define nonsecret fields for “Durable reasons” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M01.03-C039-T03 · Failure mapping:** Map each documented “Durable reasons” refusal or error to a diagnostic outcome; include “A crash replaces the last transition reason with an empty record” and prohibit conversion into a success message.
- [ ] **UC-M01.03-C039-T04 · Emission path:** Add the “Durable reasons” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M01.03-C039-T05 · Redaction check:** Test “Durable reasons” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M01.03-C039-T06 · Output budget:** Set and exercise bounded “Durable reasons” message size, rate and retention compatible with “Reason record size and retention duration”; define truncation behavior that preserves the final reason.
- [ ] **UC-M01.03-C039-T07 · Success/refusal fixtures:** Capture “Durable reasons” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M01.03-C039-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Durable reasons” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M01.03-C039-T09 · Operator review:** Read the “Durable reasons” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M01.03-C039-T10 · Diagnostic evidence:** Publish redacted “Durable reasons” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M01.03-C040 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for durable reasons; label unexecuted checks as untested.

- [ ] **UC-M01.03-C040-T01 · Evidence inventory:** List the “Durable reasons” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M01.03-C040-T02 · Artifact references:** Record the exact “Durable reasons” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M01.03-C040-T03 · Fixture references:** Attach the “Durable reasons” fixture IDs, input identities and oracle definition; preserve the source counterexample “A crash replaces the last transition reason with an empty record” as a distinct evidence case.
- [ ] **UC-M01.03-C040-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Durable reasons”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M01.03-C040-T05 · Environment record:** Record the actual “Durable reasons” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M01.03-C040-T06 · Expected versus observed:** Pair every “Durable reasons” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M01.03-C040-T07 · Failure and limit records:** Attach “Durable reasons” change/failure and bounds evidence where required; include uncovered “Reason record size and retention duration” and unresolved violations of “A state change has a recoverable explanation”.
- [ ] **UC-M01.03-C040-T08 · Evidence hygiene:** Check the “Durable reasons” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M01.03-C040-T09 · Reproduction review:** Have the “Durable reasons” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M01.03-C040-T10 · Acceptance linkage:** Link the “Durable reasons” evidence to its parent and UC-M01.03 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 05. Readiness barrier

**Source delivery:** Require a successful readiness observation before publishing running eligibility.

**Source invariant:** Failed readiness cannot produce running status.

**Source negative case:** A live process with a failing readiness probe is marked ready.

**Source bounded quantities:** Probe deadline and readiness observation age.

### UC-M01.03-C041 · Contract

**Original checklist item:** Specify readiness barrier inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M01.03-C041-T01 · Scope statement:** Draft the operation boundary for “Readiness barrier” within Lifecycle state machine; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M01.03-C041-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Readiness barrier”; record each producer, representation and missing-value meaning.
- [ ] **UC-M01.03-C041-T03 · Output inventory:** List the outputs of “Readiness barrier” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M01.03-C041-T04 · Field dictionary:** Create a field-and-term dictionary for “Readiness barrier”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M01.03-C041-T05 · Prerequisite contract:** Map “Readiness barrier” to the source component prerequisites (UC-M01.02); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M01.03-C041-T06 · Authority map:** Identify who may produce, change and consume “Readiness barrier”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M01.03-C041-T07 · Invariant clause:** Add a normative clause for “Readiness barrier” that preserves “Failed readiness cannot produce running status”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M01.03-C041-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Readiness barrier”; include the source counterexample “A live process with a failing readiness probe is marked ready” and the intended safe disposition.
- [ ] **UC-M01.03-C041-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Probe deadline and readiness observation age” in the “Readiness barrier” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M01.03-C041-T10 · Contract review:** Review the “Readiness barrier” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M01.03-C042 · Delivery

**Original checklist item:** Require a successful readiness observation before publishing running eligibility.

- [ ] **UC-M01.03-C042-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Readiness barrier”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M01.03-C042-T02 · Change plan:** Break the source delivery for “Readiness barrier” into concrete edit targets and reviewable outputs; keep the UC-M01.03 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M01.03-C042-T03 · Core artifact:** Implement the smallest selected-profile change for “Readiness barrier” that realizes this source instruction: Require a successful readiness observation before publishing running eligibility.
- [ ] **UC-M01.03-C042-T04 · Concrete realization:** Trace “Readiness barrier” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M01.03-C042-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Readiness barrier” needed to preserve “Failed readiness cannot produce running status”; record an enforcement gap where only a model exists.
- [ ] **UC-M01.03-C042-T06 · Dependency connection:** Connect the “Readiness barrier” implementation to durable desired state, observed backend state and transition journals; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M01.03-C042-T07 · Resource behavior:** Account for “Probe deadline and readiness observation age” in “Readiness barrier”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M01.03-C042-T08 · Delivery check:** Run the smallest real “Readiness barrier” path and its adverse fixture “A live process with a failing readiness probe is marked ready”; retain actual output, state effects and final disposition.
- [ ] **UC-M01.03-C042-T09 · Patch review:** Review the “Readiness barrier” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M01.03-C042-T10 · Delivery handoff:** Publish the “Readiness barrier” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M01.03-C043 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Failed readiness cannot produce running status. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M01.03-C043-T01 · Named property:** Create a stable property/check name under this parent for “Readiness barrier”; copy its required invariant exactly: “Failed readiness cannot produce running status”.
- [ ] **UC-M01.03-C043-T02 · Observable terms:** Define each term in the “Readiness barrier” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M01.03-C043-T03 · Precondition set:** List the preconditions under which “Failed readiness cannot produce running status” must hold for “Readiness barrier”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M01.03-C043-T04 · Transition coverage:** Map the “Readiness barrier” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M01.03-C043-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Readiness barrier”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M01.03-C043-T06 · Satisfying fixture:** Create a concrete “Readiness barrier” case that satisfies “Failed readiness cannot produce running status”; record its expected observation before running the assertion or review.
- [ ] **UC-M01.03-C043-T07 · Violating fixture:** Create the source counterexample “A live process with a failing readiness probe is marked ready” for “Readiness barrier”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M01.03-C043-T08 · Enforcement evidence:** Exercise the “Readiness barrier” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M01.03-C043-T09 · Regression linkage:** Link the “Readiness barrier” property to changes in durable desired state, observed backend state and transition journals; record which dependency or contract changes require rerunning it.
- [ ] **UC-M01.03-C043-T10 · Property disposition:** Compare the satisfying and violating “Readiness barrier” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M01.03-C044 · Integration

**Original checklist item:** Integrate readiness barrier with durable desired state, observed backend state and transition journals; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M01.03-C044-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Readiness barrier” across durable desired state, observed backend state and transition journals; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M01.03-C044-T02 · Field mapping:** Map every “Readiness barrier” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M01.03-C044-T03 · Prerequisite identities:** Record the actual prerequisites for “Readiness barrier” (source dependency list: UC-M01.02); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M01.03-C044-T04 · Ownership agreement:** Specify who owns “Readiness barrier” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M01.03-C044-T05 · Handoff implementation:** Connect “Readiness barrier” through the mapped seam using the real adapter or explicit specification reference; preserve “Failed readiness cannot produce running status” across the handoff.
- [ ] **UC-M01.03-C044-T06 · Absent-input case:** Omit one required “Readiness barrier” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M01.03-C044-T07 · Stale-input case:** Supply an outdated “Readiness barrier” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M01.03-C044-T08 · Incompatible-input case:** Supply an incompatible “Readiness barrier” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M01.03-C044-T09 · Valid integration trace:** Run a valid “Readiness barrier” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M01.03-C044-T10 · Seam review:** Reconcile the “Readiness barrier” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M01.03-C045 · Valid-case test

**Original checklist item:** Run a valid-path fixture for readiness barrier; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M01.03-C045-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Readiness barrier” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M01.03-C045-T02 · Expected-result oracle:** Specify the “Readiness barrier” expected result independently of the implementation output; include the property “Failed readiness cannot produce running status” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M01.03-C045-T03 · Fixture material:** Create the concrete “Readiness barrier” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M01.03-C045-T04 · Target preparation:** Prepare the “Readiness barrier” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M01.03-C045-T05 · Initial-state record:** Record the initial “Readiness barrier” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M01.03-C045-T06 · Valid-path execution:** Execute the “Readiness barrier” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M01.03-C045-T07 · Outcome comparison:** Compare every declared “Readiness barrier” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M01.03-C045-T08 · State and bounds check:** Inspect the “Readiness barrier” ownership/state effects and actual use of “Probe deadline and readiness observation age”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M01.03-C045-T09 · Repeatability check:** Repeat the same “Readiness barrier” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M01.03-C045-T10 · Positive evidence:** Attach the “Readiness barrier” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M01.03-C046 · Negative test

**Original checklist item:** Negative case: A live process with a failing readiness probe is marked ready. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M01.03-C046-T01 · Adverse-case definition:** Create a test record for the exact “Readiness barrier” source counterexample: “A live process with a failing readiness probe is marked ready”; state which precondition or invariant it challenges.
- [ ] **UC-M01.03-C046-T02 · Safe fixture boundary:** Define the contained test boundary for “Readiness barrier”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M01.03-C046-T03 · Valid control:** Construct a valid “Readiness barrier” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M01.03-C046-T04 · Minimal adverse input:** Derive the “Readiness barrier” adverse fixture from the control with the smallest documented change needed to reproduce “A live process with a failing readiness probe is marked ready”; retain that change as reproducible data.
- [ ] **UC-M01.03-C046-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Readiness barrier”; require “Failed readiness cannot produce running status” and forbid a false-success verdict.
- [ ] **UC-M01.03-C046-T06 · Adverse execution:** Exercise the “Readiness barrier” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M01.03-C046-T07 · Effect inspection:** Inspect “Readiness barrier” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M01.03-C046-T08 · Refusal versus failure:** Confirm the “Readiness barrier” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M01.03-C046-T09 · Reset and retention:** Restore only the disposable “Readiness barrier” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M01.03-C046-T10 · Negative regression:** Register the “Readiness barrier” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M01.03-C047 · Change / failure test

**Original checklist item:** Exercise readiness barrier when the controller restarts between accepting intent and observing the resulting state; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M01.03-C047-T01 · Scenario record:** Write the “Readiness barrier” change/failure scenario exactly as supplied: the controller restarts between accepting intent and observing the resulting state; identify the property that must remain true: “Failed readiness cannot produce running status”.
- [ ] **UC-M01.03-C047-T02 · Baseline capture:** Create a known-valid “Readiness barrier” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M01.03-C047-T03 · Injection map:** Locate the “Readiness barrier” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M01.03-C047-T04 · Disposition oracle:** Define the legal intermediate and final “Readiness barrier” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M01.03-C047-T05 · Controlled trigger:** Introduce the controlled “Readiness barrier” scenario in the disposable fixture: the controller restarts between accepting intent and observing the resulting state; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M01.03-C047-T06 · Intermediate inspection:** Inspect the “Readiness barrier” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M01.03-C047-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Readiness barrier”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M01.03-C047-T08 · Stale-evidence cleanup:** Invalidate superseded “Readiness barrier” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M01.03-C047-T09 · Repeat and compare:** Repeat the selected “Readiness barrier” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M01.03-C047-T10 · Failure evidence:** Publish the “Readiness barrier” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M01.03-C048 · Bounds

**Original checklist item:** Choose, document and test limits for probe deadline and readiness observation age; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M01.03-C048-T01 · Quantity inventory:** Create a measurement inventory for “Readiness barrier”: “Probe deadline and readiness observation age”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M01.03-C048-T02 · Measurement method:** Choose how to observe each “Readiness barrier” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M01.03-C048-T03 · Budget decision:** Select justified resource and input limits for “Readiness barrier”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M01.03-C048-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Readiness barrier” cases for “Probe deadline and readiness observation age”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M01.03-C048-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Readiness barrier” limit; preserve “Failed readiness cannot produce running status”.
- [ ] **UC-M01.03-C048-T06 · Normal measurement:** Run or review the normal “Readiness barrier” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M01.03-C048-T07 · At-limit measurement:** Exercise the “Readiness barrier” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M01.03-C048-T08 · Over-limit measurement:** Exercise the “Readiness barrier” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M01.03-C048-T09 · Uncovered-scope report:** List the “Readiness barrier” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M01.03-C048-T10 · Limit evidence:** Publish the selected “Readiness barrier” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M01.03-C049 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for readiness barrier with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M01.03-C049-T01 · Event inventory:** List the “Readiness barrier” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M01.03-C049-T02 · Diagnostic schema:** Define nonsecret fields for “Readiness barrier” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M01.03-C049-T03 · Failure mapping:** Map each documented “Readiness barrier” refusal or error to a diagnostic outcome; include “A live process with a failing readiness probe is marked ready” and prohibit conversion into a success message.
- [ ] **UC-M01.03-C049-T04 · Emission path:** Add the “Readiness barrier” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M01.03-C049-T05 · Redaction check:** Test “Readiness barrier” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M01.03-C049-T06 · Output budget:** Set and exercise bounded “Readiness barrier” message size, rate and retention compatible with “Probe deadline and readiness observation age”; define truncation behavior that preserves the final reason.
- [ ] **UC-M01.03-C049-T07 · Success/refusal fixtures:** Capture “Readiness barrier” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M01.03-C049-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Readiness barrier” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M01.03-C049-T09 · Operator review:** Read the “Readiness barrier” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M01.03-C049-T10 · Diagnostic evidence:** Publish redacted “Readiness barrier” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M01.03-C050 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for readiness barrier; label unexecuted checks as untested.

- [ ] **UC-M01.03-C050-T01 · Evidence inventory:** List the “Readiness barrier” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M01.03-C050-T02 · Artifact references:** Record the exact “Readiness barrier” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M01.03-C050-T03 · Fixture references:** Attach the “Readiness barrier” fixture IDs, input identities and oracle definition; preserve the source counterexample “A live process with a failing readiness probe is marked ready” as a distinct evidence case.
- [ ] **UC-M01.03-C050-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Readiness barrier”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M01.03-C050-T05 · Environment record:** Record the actual “Readiness barrier” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M01.03-C050-T06 · Expected versus observed:** Pair every “Readiness barrier” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M01.03-C050-T07 · Failure and limit records:** Attach “Readiness barrier” change/failure and bounds evidence where required; include uncovered “Probe deadline and readiness observation age” and unresolved violations of “Failed readiness cannot produce running status”.
- [ ] **UC-M01.03-C050-T08 · Evidence hygiene:** Check the “Readiness barrier” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M01.03-C050-T09 · Reproduction review:** Have the “Readiness barrier” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M01.03-C050-T10 · Acceptance linkage:** Link the “Readiness barrier” evidence to its parent and UC-M01.03 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 06. Failure classification

**Source delivery:** Separate failed execution, rejected admission and quarantined unsafe state.

**Source invariant:** A quarantine requires an explicit authorized recovery path.

**Source negative case:** Automatic retry silently clears a quarantine flag.

**Source bounded quantities:** Failure classes and quarantine backlog.

### UC-M01.03-C051 · Contract

**Original checklist item:** Specify failure classification inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M01.03-C051-T01 · Scope statement:** Draft the operation boundary for “Failure classification” within Lifecycle state machine; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M01.03-C051-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Failure classification”; record each producer, representation and missing-value meaning.
- [ ] **UC-M01.03-C051-T03 · Output inventory:** List the outputs of “Failure classification” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M01.03-C051-T04 · Field dictionary:** Create a field-and-term dictionary for “Failure classification”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M01.03-C051-T05 · Prerequisite contract:** Map “Failure classification” to the source component prerequisites (UC-M01.02); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M01.03-C051-T06 · Authority map:** Identify who may produce, change and consume “Failure classification”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M01.03-C051-T07 · Invariant clause:** Add a normative clause for “Failure classification” that preserves “A quarantine requires an explicit authorized recovery path”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M01.03-C051-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Failure classification”; include the source counterexample “Automatic retry silently clears a quarantine flag” and the intended safe disposition.
- [ ] **UC-M01.03-C051-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Failure classes and quarantine backlog” in the “Failure classification” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M01.03-C051-T10 · Contract review:** Review the “Failure classification” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M01.03-C052 · Delivery

**Original checklist item:** Separate failed execution, rejected admission and quarantined unsafe state.

- [ ] **UC-M01.03-C052-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Failure classification”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M01.03-C052-T02 · Change plan:** Break the source delivery for “Failure classification” into concrete edit targets and reviewable outputs; keep the UC-M01.03 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M01.03-C052-T03 · Core artifact:** Implement the smallest selected-profile change for “Failure classification” that realizes this source instruction: Separate failed execution, rejected admission and quarantined unsafe state.
- [ ] **UC-M01.03-C052-T04 · Concrete realization:** Trace “Failure classification” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M01.03-C052-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Failure classification” needed to preserve “A quarantine requires an explicit authorized recovery path”; record an enforcement gap where only a model exists.
- [ ] **UC-M01.03-C052-T06 · Dependency connection:** Connect the “Failure classification” implementation to durable desired state, observed backend state and transition journals; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M01.03-C052-T07 · Resource behavior:** Account for “Failure classes and quarantine backlog” in “Failure classification”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M01.03-C052-T08 · Delivery check:** Run the smallest real “Failure classification” path and its adverse fixture “Automatic retry silently clears a quarantine flag”; retain actual output, state effects and final disposition.
- [ ] **UC-M01.03-C052-T09 · Patch review:** Review the “Failure classification” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M01.03-C052-T10 · Delivery handoff:** Publish the “Failure classification” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M01.03-C053 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: A quarantine requires an explicit authorized recovery path. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M01.03-C053-T01 · Named property:** Create a stable property/check name under this parent for “Failure classification”; copy its required invariant exactly: “A quarantine requires an explicit authorized recovery path”.
- [ ] **UC-M01.03-C053-T02 · Observable terms:** Define each term in the “Failure classification” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M01.03-C053-T03 · Precondition set:** List the preconditions under which “A quarantine requires an explicit authorized recovery path” must hold for “Failure classification”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M01.03-C053-T04 · Transition coverage:** Map the “Failure classification” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M01.03-C053-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Failure classification”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M01.03-C053-T06 · Satisfying fixture:** Create a concrete “Failure classification” case that satisfies “A quarantine requires an explicit authorized recovery path”; record its expected observation before running the assertion or review.
- [ ] **UC-M01.03-C053-T07 · Violating fixture:** Create the source counterexample “Automatic retry silently clears a quarantine flag” for “Failure classification”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M01.03-C053-T08 · Enforcement evidence:** Exercise the “Failure classification” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M01.03-C053-T09 · Regression linkage:** Link the “Failure classification” property to changes in durable desired state, observed backend state and transition journals; record which dependency or contract changes require rerunning it.
- [ ] **UC-M01.03-C053-T10 · Property disposition:** Compare the satisfying and violating “Failure classification” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M01.03-C054 · Integration

**Original checklist item:** Integrate failure classification with durable desired state, observed backend state and transition journals; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M01.03-C054-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Failure classification” across durable desired state, observed backend state and transition journals; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M01.03-C054-T02 · Field mapping:** Map every “Failure classification” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M01.03-C054-T03 · Prerequisite identities:** Record the actual prerequisites for “Failure classification” (source dependency list: UC-M01.02); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M01.03-C054-T04 · Ownership agreement:** Specify who owns “Failure classification” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M01.03-C054-T05 · Handoff implementation:** Connect “Failure classification” through the mapped seam using the real adapter or explicit specification reference; preserve “A quarantine requires an explicit authorized recovery path” across the handoff.
- [ ] **UC-M01.03-C054-T06 · Absent-input case:** Omit one required “Failure classification” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M01.03-C054-T07 · Stale-input case:** Supply an outdated “Failure classification” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M01.03-C054-T08 · Incompatible-input case:** Supply an incompatible “Failure classification” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M01.03-C054-T09 · Valid integration trace:** Run a valid “Failure classification” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M01.03-C054-T10 · Seam review:** Reconcile the “Failure classification” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M01.03-C055 · Valid-case test

**Original checklist item:** Run a valid-path fixture for failure classification; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M01.03-C055-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Failure classification” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M01.03-C055-T02 · Expected-result oracle:** Specify the “Failure classification” expected result independently of the implementation output; include the property “A quarantine requires an explicit authorized recovery path” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M01.03-C055-T03 · Fixture material:** Create the concrete “Failure classification” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M01.03-C055-T04 · Target preparation:** Prepare the “Failure classification” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M01.03-C055-T05 · Initial-state record:** Record the initial “Failure classification” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M01.03-C055-T06 · Valid-path execution:** Execute the “Failure classification” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M01.03-C055-T07 · Outcome comparison:** Compare every declared “Failure classification” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M01.03-C055-T08 · State and bounds check:** Inspect the “Failure classification” ownership/state effects and actual use of “Failure classes and quarantine backlog”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M01.03-C055-T09 · Repeatability check:** Repeat the same “Failure classification” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M01.03-C055-T10 · Positive evidence:** Attach the “Failure classification” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M01.03-C056 · Negative test

**Original checklist item:** Negative case: Automatic retry silently clears a quarantine flag. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M01.03-C056-T01 · Adverse-case definition:** Create a test record for the exact “Failure classification” source counterexample: “Automatic retry silently clears a quarantine flag”; state which precondition or invariant it challenges.
- [ ] **UC-M01.03-C056-T02 · Safe fixture boundary:** Define the contained test boundary for “Failure classification”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M01.03-C056-T03 · Valid control:** Construct a valid “Failure classification” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M01.03-C056-T04 · Minimal adverse input:** Derive the “Failure classification” adverse fixture from the control with the smallest documented change needed to reproduce “Automatic retry silently clears a quarantine flag”; retain that change as reproducible data.
- [ ] **UC-M01.03-C056-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Failure classification”; require “A quarantine requires an explicit authorized recovery path” and forbid a false-success verdict.
- [ ] **UC-M01.03-C056-T06 · Adverse execution:** Exercise the “Failure classification” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M01.03-C056-T07 · Effect inspection:** Inspect “Failure classification” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M01.03-C056-T08 · Refusal versus failure:** Confirm the “Failure classification” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M01.03-C056-T09 · Reset and retention:** Restore only the disposable “Failure classification” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M01.03-C056-T10 · Negative regression:** Register the “Failure classification” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M01.03-C057 · Change / failure test

**Original checklist item:** Exercise failure classification when the controller restarts between accepting intent and observing the resulting state; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M01.03-C057-T01 · Scenario record:** Write the “Failure classification” change/failure scenario exactly as supplied: the controller restarts between accepting intent and observing the resulting state; identify the property that must remain true: “A quarantine requires an explicit authorized recovery path”.
- [ ] **UC-M01.03-C057-T02 · Baseline capture:** Create a known-valid “Failure classification” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M01.03-C057-T03 · Injection map:** Locate the “Failure classification” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M01.03-C057-T04 · Disposition oracle:** Define the legal intermediate and final “Failure classification” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M01.03-C057-T05 · Controlled trigger:** Introduce the controlled “Failure classification” scenario in the disposable fixture: the controller restarts between accepting intent and observing the resulting state; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M01.03-C057-T06 · Intermediate inspection:** Inspect the “Failure classification” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M01.03-C057-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Failure classification”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M01.03-C057-T08 · Stale-evidence cleanup:** Invalidate superseded “Failure classification” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M01.03-C057-T09 · Repeat and compare:** Repeat the selected “Failure classification” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M01.03-C057-T10 · Failure evidence:** Publish the “Failure classification” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M01.03-C058 · Bounds

**Original checklist item:** Choose, document and test limits for failure classes and quarantine backlog; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M01.03-C058-T01 · Quantity inventory:** Create a measurement inventory for “Failure classification”: “Failure classes and quarantine backlog”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M01.03-C058-T02 · Measurement method:** Choose how to observe each “Failure classification” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M01.03-C058-T03 · Budget decision:** Select justified resource and input limits for “Failure classification”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M01.03-C058-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Failure classification” cases for “Failure classes and quarantine backlog”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M01.03-C058-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Failure classification” limit; preserve “A quarantine requires an explicit authorized recovery path”.
- [ ] **UC-M01.03-C058-T06 · Normal measurement:** Run or review the normal “Failure classification” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M01.03-C058-T07 · At-limit measurement:** Exercise the “Failure classification” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M01.03-C058-T08 · Over-limit measurement:** Exercise the “Failure classification” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M01.03-C058-T09 · Uncovered-scope report:** List the “Failure classification” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M01.03-C058-T10 · Limit evidence:** Publish the selected “Failure classification” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M01.03-C059 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for failure classification with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M01.03-C059-T01 · Event inventory:** List the “Failure classification” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M01.03-C059-T02 · Diagnostic schema:** Define nonsecret fields for “Failure classification” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M01.03-C059-T03 · Failure mapping:** Map each documented “Failure classification” refusal or error to a diagnostic outcome; include “Automatic retry silently clears a quarantine flag” and prohibit conversion into a success message.
- [ ] **UC-M01.03-C059-T04 · Emission path:** Add the “Failure classification” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M01.03-C059-T05 · Redaction check:** Test “Failure classification” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M01.03-C059-T06 · Output budget:** Set and exercise bounded “Failure classification” message size, rate and retention compatible with “Failure classes and quarantine backlog”; define truncation behavior that preserves the final reason.
- [ ] **UC-M01.03-C059-T07 · Success/refusal fixtures:** Capture “Failure classification” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M01.03-C059-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Failure classification” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M01.03-C059-T09 · Operator review:** Read the “Failure classification” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M01.03-C059-T10 · Diagnostic evidence:** Publish redacted “Failure classification” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M01.03-C060 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for failure classification; label unexecuted checks as untested.

- [ ] **UC-M01.03-C060-T01 · Evidence inventory:** List the “Failure classification” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M01.03-C060-T02 · Artifact references:** Record the exact “Failure classification” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M01.03-C060-T03 · Fixture references:** Attach the “Failure classification” fixture IDs, input identities and oracle definition; preserve the source counterexample “Automatic retry silently clears a quarantine flag” as a distinct evidence case.
- [ ] **UC-M01.03-C060-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Failure classification”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M01.03-C060-T05 · Environment record:** Record the actual “Failure classification” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M01.03-C060-T06 · Expected versus observed:** Pair every “Failure classification” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M01.03-C060-T07 · Failure and limit records:** Attach “Failure classification” change/failure and bounds evidence where required; include uncovered “Failure classes and quarantine backlog” and unresolved violations of “A quarantine requires an explicit authorized recovery path”.
- [ ] **UC-M01.03-C060-T08 · Evidence hygiene:** Check the “Failure classification” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M01.03-C060-T09 · Reproduction review:** Have the “Failure classification” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M01.03-C060-T10 · Acceptance linkage:** Link the “Failure classification” evidence to its parent and UC-M01.03 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 07. Concurrency control

**Source delivery:** Serialize or compare generations when multiple actors request transitions.

**Source invariant:** Only one legal transition wins from a given generation.

**Source negative case:** Concurrent stop and replace commands both commit incompatible states.

**Source bounded quantities:** Contending requests and lock wait time.

### UC-M01.03-C061 · Contract

**Original checklist item:** Specify concurrency control inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M01.03-C061-T01 · Scope statement:** Draft the operation boundary for “Concurrency control” within Lifecycle state machine; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M01.03-C061-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Concurrency control”; record each producer, representation and missing-value meaning.
- [ ] **UC-M01.03-C061-T03 · Output inventory:** List the outputs of “Concurrency control” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M01.03-C061-T04 · Field dictionary:** Create a field-and-term dictionary for “Concurrency control”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M01.03-C061-T05 · Prerequisite contract:** Map “Concurrency control” to the source component prerequisites (UC-M01.02); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M01.03-C061-T06 · Authority map:** Identify who may produce, change and consume “Concurrency control”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M01.03-C061-T07 · Invariant clause:** Add a normative clause for “Concurrency control” that preserves “Only one legal transition wins from a given generation”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M01.03-C061-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Concurrency control”; include the source counterexample “Concurrent stop and replace commands both commit incompatible states” and the intended safe disposition.
- [ ] **UC-M01.03-C061-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Contending requests and lock wait time” in the “Concurrency control” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M01.03-C061-T10 · Contract review:** Review the “Concurrency control” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M01.03-C062 · Delivery

**Original checklist item:** Serialize or compare generations when multiple actors request transitions.

- [ ] **UC-M01.03-C062-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Concurrency control”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M01.03-C062-T02 · Change plan:** Break the source delivery for “Concurrency control” into concrete edit targets and reviewable outputs; keep the UC-M01.03 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M01.03-C062-T03 · Core artifact:** Implement the smallest selected-profile change for “Concurrency control” that realizes this source instruction: Serialize or compare generations when multiple actors request transitions.
- [ ] **UC-M01.03-C062-T04 · Concrete realization:** Trace “Concurrency control” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M01.03-C062-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Concurrency control” needed to preserve “Only one legal transition wins from a given generation”; record an enforcement gap where only a model exists.
- [ ] **UC-M01.03-C062-T06 · Dependency connection:** Connect the “Concurrency control” implementation to durable desired state, observed backend state and transition journals; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M01.03-C062-T07 · Resource behavior:** Account for “Contending requests and lock wait time” in “Concurrency control”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M01.03-C062-T08 · Delivery check:** Run the smallest real “Concurrency control” path and its adverse fixture “Concurrent stop and replace commands both commit incompatible states”; retain actual output, state effects and final disposition.
- [ ] **UC-M01.03-C062-T09 · Patch review:** Review the “Concurrency control” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M01.03-C062-T10 · Delivery handoff:** Publish the “Concurrency control” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M01.03-C063 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Only one legal transition wins from a given generation. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M01.03-C063-T01 · Named property:** Create a stable property/check name under this parent for “Concurrency control”; copy its required invariant exactly: “Only one legal transition wins from a given generation”.
- [ ] **UC-M01.03-C063-T02 · Observable terms:** Define each term in the “Concurrency control” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M01.03-C063-T03 · Precondition set:** List the preconditions under which “Only one legal transition wins from a given generation” must hold for “Concurrency control”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M01.03-C063-T04 · Transition coverage:** Map the “Concurrency control” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M01.03-C063-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Concurrency control”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M01.03-C063-T06 · Satisfying fixture:** Create a concrete “Concurrency control” case that satisfies “Only one legal transition wins from a given generation”; record its expected observation before running the assertion or review.
- [ ] **UC-M01.03-C063-T07 · Violating fixture:** Create the source counterexample “Concurrent stop and replace commands both commit incompatible states” for “Concurrency control”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M01.03-C063-T08 · Enforcement evidence:** Exercise the “Concurrency control” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M01.03-C063-T09 · Regression linkage:** Link the “Concurrency control” property to changes in durable desired state, observed backend state and transition journals; record which dependency or contract changes require rerunning it.
- [ ] **UC-M01.03-C063-T10 · Property disposition:** Compare the satisfying and violating “Concurrency control” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M01.03-C064 · Integration

**Original checklist item:** Integrate concurrency control with durable desired state, observed backend state and transition journals; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M01.03-C064-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Concurrency control” across durable desired state, observed backend state and transition journals; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M01.03-C064-T02 · Field mapping:** Map every “Concurrency control” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M01.03-C064-T03 · Prerequisite identities:** Record the actual prerequisites for “Concurrency control” (source dependency list: UC-M01.02); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M01.03-C064-T04 · Ownership agreement:** Specify who owns “Concurrency control” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M01.03-C064-T05 · Handoff implementation:** Connect “Concurrency control” through the mapped seam using the real adapter or explicit specification reference; preserve “Only one legal transition wins from a given generation” across the handoff.
- [ ] **UC-M01.03-C064-T06 · Absent-input case:** Omit one required “Concurrency control” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M01.03-C064-T07 · Stale-input case:** Supply an outdated “Concurrency control” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M01.03-C064-T08 · Incompatible-input case:** Supply an incompatible “Concurrency control” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M01.03-C064-T09 · Valid integration trace:** Run a valid “Concurrency control” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M01.03-C064-T10 · Seam review:** Reconcile the “Concurrency control” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M01.03-C065 · Valid-case test

**Original checklist item:** Run a valid-path fixture for concurrency control; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M01.03-C065-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Concurrency control” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M01.03-C065-T02 · Expected-result oracle:** Specify the “Concurrency control” expected result independently of the implementation output; include the property “Only one legal transition wins from a given generation” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M01.03-C065-T03 · Fixture material:** Create the concrete “Concurrency control” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M01.03-C065-T04 · Target preparation:** Prepare the “Concurrency control” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M01.03-C065-T05 · Initial-state record:** Record the initial “Concurrency control” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M01.03-C065-T06 · Valid-path execution:** Execute the “Concurrency control” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M01.03-C065-T07 · Outcome comparison:** Compare every declared “Concurrency control” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M01.03-C065-T08 · State and bounds check:** Inspect the “Concurrency control” ownership/state effects and actual use of “Contending requests and lock wait time”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M01.03-C065-T09 · Repeatability check:** Repeat the same “Concurrency control” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M01.03-C065-T10 · Positive evidence:** Attach the “Concurrency control” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M01.03-C066 · Negative test

**Original checklist item:** Negative case: Concurrent stop and replace commands both commit incompatible states. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M01.03-C066-T01 · Adverse-case definition:** Create a test record for the exact “Concurrency control” source counterexample: “Concurrent stop and replace commands both commit incompatible states”; state which precondition or invariant it challenges.
- [ ] **UC-M01.03-C066-T02 · Safe fixture boundary:** Define the contained test boundary for “Concurrency control”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M01.03-C066-T03 · Valid control:** Construct a valid “Concurrency control” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M01.03-C066-T04 · Minimal adverse input:** Derive the “Concurrency control” adverse fixture from the control with the smallest documented change needed to reproduce “Concurrent stop and replace commands both commit incompatible states”; retain that change as reproducible data.
- [ ] **UC-M01.03-C066-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Concurrency control”; require “Only one legal transition wins from a given generation” and forbid a false-success verdict.
- [ ] **UC-M01.03-C066-T06 · Adverse execution:** Exercise the “Concurrency control” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M01.03-C066-T07 · Effect inspection:** Inspect “Concurrency control” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M01.03-C066-T08 · Refusal versus failure:** Confirm the “Concurrency control” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M01.03-C066-T09 · Reset and retention:** Restore only the disposable “Concurrency control” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M01.03-C066-T10 · Negative regression:** Register the “Concurrency control” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M01.03-C067 · Change / failure test

**Original checklist item:** Exercise concurrency control when the controller restarts between accepting intent and observing the resulting state; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M01.03-C067-T01 · Scenario record:** Write the “Concurrency control” change/failure scenario exactly as supplied: the controller restarts between accepting intent and observing the resulting state; identify the property that must remain true: “Only one legal transition wins from a given generation”.
- [ ] **UC-M01.03-C067-T02 · Baseline capture:** Create a known-valid “Concurrency control” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M01.03-C067-T03 · Injection map:** Locate the “Concurrency control” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M01.03-C067-T04 · Disposition oracle:** Define the legal intermediate and final “Concurrency control” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M01.03-C067-T05 · Controlled trigger:** Introduce the controlled “Concurrency control” scenario in the disposable fixture: the controller restarts between accepting intent and observing the resulting state; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M01.03-C067-T06 · Intermediate inspection:** Inspect the “Concurrency control” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M01.03-C067-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Concurrency control”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M01.03-C067-T08 · Stale-evidence cleanup:** Invalidate superseded “Concurrency control” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M01.03-C067-T09 · Repeat and compare:** Repeat the selected “Concurrency control” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M01.03-C067-T10 · Failure evidence:** Publish the “Concurrency control” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M01.03-C068 · Bounds

**Original checklist item:** Choose, document and test limits for contending requests and lock wait time; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M01.03-C068-T01 · Quantity inventory:** Create a measurement inventory for “Concurrency control”: “Contending requests and lock wait time”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M01.03-C068-T02 · Measurement method:** Choose how to observe each “Concurrency control” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M01.03-C068-T03 · Budget decision:** Select justified resource and input limits for “Concurrency control”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M01.03-C068-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Concurrency control” cases for “Contending requests and lock wait time”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M01.03-C068-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Concurrency control” limit; preserve “Only one legal transition wins from a given generation”.
- [ ] **UC-M01.03-C068-T06 · Normal measurement:** Run or review the normal “Concurrency control” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M01.03-C068-T07 · At-limit measurement:** Exercise the “Concurrency control” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M01.03-C068-T08 · Over-limit measurement:** Exercise the “Concurrency control” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M01.03-C068-T09 · Uncovered-scope report:** List the “Concurrency control” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M01.03-C068-T10 · Limit evidence:** Publish the selected “Concurrency control” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M01.03-C069 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for concurrency control with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M01.03-C069-T01 · Event inventory:** List the “Concurrency control” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M01.03-C069-T02 · Diagnostic schema:** Define nonsecret fields for “Concurrency control” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M01.03-C069-T03 · Failure mapping:** Map each documented “Concurrency control” refusal or error to a diagnostic outcome; include “Concurrent stop and replace commands both commit incompatible states” and prohibit conversion into a success message.
- [ ] **UC-M01.03-C069-T04 · Emission path:** Add the “Concurrency control” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M01.03-C069-T05 · Redaction check:** Test “Concurrency control” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M01.03-C069-T06 · Output budget:** Set and exercise bounded “Concurrency control” message size, rate and retention compatible with “Contending requests and lock wait time”; define truncation behavior that preserves the final reason.
- [ ] **UC-M01.03-C069-T07 · Success/refusal fixtures:** Capture “Concurrency control” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M01.03-C069-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Concurrency control” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M01.03-C069-T09 · Operator review:** Read the “Concurrency control” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M01.03-C069-T10 · Diagnostic evidence:** Publish redacted “Concurrency control” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M01.03-C070 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for concurrency control; label unexecuted checks as untested.

- [ ] **UC-M01.03-C070-T01 · Evidence inventory:** List the “Concurrency control” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M01.03-C070-T02 · Artifact references:** Record the exact “Concurrency control” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M01.03-C070-T03 · Fixture references:** Attach the “Concurrency control” fixture IDs, input identities and oracle definition; preserve the source counterexample “Concurrent stop and replace commands both commit incompatible states” as a distinct evidence case.
- [ ] **UC-M01.03-C070-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Concurrency control”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M01.03-C070-T05 · Environment record:** Record the actual “Concurrency control” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M01.03-C070-T06 · Expected versus observed:** Pair every “Concurrency control” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M01.03-C070-T07 · Failure and limit records:** Attach “Concurrency control” change/failure and bounds evidence where required; include uncovered “Contending requests and lock wait time” and unresolved violations of “Only one legal transition wins from a given generation”.
- [ ] **UC-M01.03-C070-T08 · Evidence hygiene:** Check the “Concurrency control” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M01.03-C070-T09 · Reproduction review:** Have the “Concurrency control” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M01.03-C070-T10 · Acceptance linkage:** Link the “Concurrency control” evidence to its parent and UC-M01.03 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 08. Restart reconstruction

**Source delivery:** Rebuild observed state from durable intent and backend inspection after restart.

**Source invariant:** Recovery does not fabricate successful execution.

**Source negative case:** A missing process is restored as running from stale metadata.

**Source bounded quantities:** Recovery scan size and reconciliation deadline.

### UC-M01.03-C071 · Contract

**Original checklist item:** Specify restart reconstruction inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M01.03-C071-T01 · Scope statement:** Draft the operation boundary for “Restart reconstruction” within Lifecycle state machine; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M01.03-C071-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Restart reconstruction”; record each producer, representation and missing-value meaning.
- [ ] **UC-M01.03-C071-T03 · Output inventory:** List the outputs of “Restart reconstruction” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M01.03-C071-T04 · Field dictionary:** Create a field-and-term dictionary for “Restart reconstruction”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M01.03-C071-T05 · Prerequisite contract:** Map “Restart reconstruction” to the source component prerequisites (UC-M01.02); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M01.03-C071-T06 · Authority map:** Identify who may produce, change and consume “Restart reconstruction”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M01.03-C071-T07 · Invariant clause:** Add a normative clause for “Restart reconstruction” that preserves “Recovery does not fabricate successful execution”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M01.03-C071-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Restart reconstruction”; include the source counterexample “A missing process is restored as running from stale metadata” and the intended safe disposition.
- [ ] **UC-M01.03-C071-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Recovery scan size and reconciliation deadline” in the “Restart reconstruction” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M01.03-C071-T10 · Contract review:** Review the “Restart reconstruction” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M01.03-C072 · Delivery

**Original checklist item:** Rebuild observed state from durable intent and backend inspection after restart.

- [ ] **UC-M01.03-C072-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Restart reconstruction”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M01.03-C072-T02 · Change plan:** Break the source delivery for “Restart reconstruction” into concrete edit targets and reviewable outputs; keep the UC-M01.03 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M01.03-C072-T03 · Core artifact:** Implement the smallest selected-profile change for “Restart reconstruction” that realizes this source instruction: Rebuild observed state from durable intent and backend inspection after restart.
- [ ] **UC-M01.03-C072-T04 · Concrete realization:** Trace “Restart reconstruction” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M01.03-C072-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Restart reconstruction” needed to preserve “Recovery does not fabricate successful execution”; record an enforcement gap where only a model exists.
- [ ] **UC-M01.03-C072-T06 · Dependency connection:** Connect the “Restart reconstruction” implementation to durable desired state, observed backend state and transition journals; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M01.03-C072-T07 · Resource behavior:** Account for “Recovery scan size and reconciliation deadline” in “Restart reconstruction”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M01.03-C072-T08 · Delivery check:** Run the smallest real “Restart reconstruction” path and its adverse fixture “A missing process is restored as running from stale metadata”; retain actual output, state effects and final disposition.
- [ ] **UC-M01.03-C072-T09 · Patch review:** Review the “Restart reconstruction” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M01.03-C072-T10 · Delivery handoff:** Publish the “Restart reconstruction” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M01.03-C073 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Recovery does not fabricate successful execution. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M01.03-C073-T01 · Named property:** Create a stable property/check name under this parent for “Restart reconstruction”; copy its required invariant exactly: “Recovery does not fabricate successful execution”.
- [ ] **UC-M01.03-C073-T02 · Observable terms:** Define each term in the “Restart reconstruction” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M01.03-C073-T03 · Precondition set:** List the preconditions under which “Recovery does not fabricate successful execution” must hold for “Restart reconstruction”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M01.03-C073-T04 · Transition coverage:** Map the “Restart reconstruction” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M01.03-C073-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Restart reconstruction”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M01.03-C073-T06 · Satisfying fixture:** Create a concrete “Restart reconstruction” case that satisfies “Recovery does not fabricate successful execution”; record its expected observation before running the assertion or review.
- [ ] **UC-M01.03-C073-T07 · Violating fixture:** Create the source counterexample “A missing process is restored as running from stale metadata” for “Restart reconstruction”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M01.03-C073-T08 · Enforcement evidence:** Exercise the “Restart reconstruction” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M01.03-C073-T09 · Regression linkage:** Link the “Restart reconstruction” property to changes in durable desired state, observed backend state and transition journals; record which dependency or contract changes require rerunning it.
- [ ] **UC-M01.03-C073-T10 · Property disposition:** Compare the satisfying and violating “Restart reconstruction” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M01.03-C074 · Integration

**Original checklist item:** Integrate restart reconstruction with durable desired state, observed backend state and transition journals; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M01.03-C074-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Restart reconstruction” across durable desired state, observed backend state and transition journals; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M01.03-C074-T02 · Field mapping:** Map every “Restart reconstruction” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M01.03-C074-T03 · Prerequisite identities:** Record the actual prerequisites for “Restart reconstruction” (source dependency list: UC-M01.02); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M01.03-C074-T04 · Ownership agreement:** Specify who owns “Restart reconstruction” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M01.03-C074-T05 · Handoff implementation:** Connect “Restart reconstruction” through the mapped seam using the real adapter or explicit specification reference; preserve “Recovery does not fabricate successful execution” across the handoff.
- [ ] **UC-M01.03-C074-T06 · Absent-input case:** Omit one required “Restart reconstruction” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M01.03-C074-T07 · Stale-input case:** Supply an outdated “Restart reconstruction” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M01.03-C074-T08 · Incompatible-input case:** Supply an incompatible “Restart reconstruction” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M01.03-C074-T09 · Valid integration trace:** Run a valid “Restart reconstruction” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M01.03-C074-T10 · Seam review:** Reconcile the “Restart reconstruction” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M01.03-C075 · Valid-case test

**Original checklist item:** Run a valid-path fixture for restart reconstruction; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M01.03-C075-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Restart reconstruction” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M01.03-C075-T02 · Expected-result oracle:** Specify the “Restart reconstruction” expected result independently of the implementation output; include the property “Recovery does not fabricate successful execution” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M01.03-C075-T03 · Fixture material:** Create the concrete “Restart reconstruction” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M01.03-C075-T04 · Target preparation:** Prepare the “Restart reconstruction” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M01.03-C075-T05 · Initial-state record:** Record the initial “Restart reconstruction” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M01.03-C075-T06 · Valid-path execution:** Execute the “Restart reconstruction” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M01.03-C075-T07 · Outcome comparison:** Compare every declared “Restart reconstruction” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M01.03-C075-T08 · State and bounds check:** Inspect the “Restart reconstruction” ownership/state effects and actual use of “Recovery scan size and reconciliation deadline”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M01.03-C075-T09 · Repeatability check:** Repeat the same “Restart reconstruction” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M01.03-C075-T10 · Positive evidence:** Attach the “Restart reconstruction” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M01.03-C076 · Negative test

**Original checklist item:** Negative case: A missing process is restored as running from stale metadata. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M01.03-C076-T01 · Adverse-case definition:** Create a test record for the exact “Restart reconstruction” source counterexample: “A missing process is restored as running from stale metadata”; state which precondition or invariant it challenges.
- [ ] **UC-M01.03-C076-T02 · Safe fixture boundary:** Define the contained test boundary for “Restart reconstruction”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M01.03-C076-T03 · Valid control:** Construct a valid “Restart reconstruction” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M01.03-C076-T04 · Minimal adverse input:** Derive the “Restart reconstruction” adverse fixture from the control with the smallest documented change needed to reproduce “A missing process is restored as running from stale metadata”; retain that change as reproducible data.
- [ ] **UC-M01.03-C076-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Restart reconstruction”; require “Recovery does not fabricate successful execution” and forbid a false-success verdict.
- [ ] **UC-M01.03-C076-T06 · Adverse execution:** Exercise the “Restart reconstruction” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M01.03-C076-T07 · Effect inspection:** Inspect “Restart reconstruction” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M01.03-C076-T08 · Refusal versus failure:** Confirm the “Restart reconstruction” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M01.03-C076-T09 · Reset and retention:** Restore only the disposable “Restart reconstruction” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M01.03-C076-T10 · Negative regression:** Register the “Restart reconstruction” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M01.03-C077 · Change / failure test

**Original checklist item:** Exercise restart reconstruction when the controller restarts between accepting intent and observing the resulting state; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M01.03-C077-T01 · Scenario record:** Write the “Restart reconstruction” change/failure scenario exactly as supplied: the controller restarts between accepting intent and observing the resulting state; identify the property that must remain true: “Recovery does not fabricate successful execution”.
- [ ] **UC-M01.03-C077-T02 · Baseline capture:** Create a known-valid “Restart reconstruction” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M01.03-C077-T03 · Injection map:** Locate the “Restart reconstruction” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M01.03-C077-T04 · Disposition oracle:** Define the legal intermediate and final “Restart reconstruction” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M01.03-C077-T05 · Controlled trigger:** Introduce the controlled “Restart reconstruction” scenario in the disposable fixture: the controller restarts between accepting intent and observing the resulting state; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M01.03-C077-T06 · Intermediate inspection:** Inspect the “Restart reconstruction” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M01.03-C077-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Restart reconstruction”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M01.03-C077-T08 · Stale-evidence cleanup:** Invalidate superseded “Restart reconstruction” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M01.03-C077-T09 · Repeat and compare:** Repeat the selected “Restart reconstruction” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M01.03-C077-T10 · Failure evidence:** Publish the “Restart reconstruction” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M01.03-C078 · Bounds

**Original checklist item:** Choose, document and test limits for recovery scan size and reconciliation deadline; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M01.03-C078-T01 · Quantity inventory:** Create a measurement inventory for “Restart reconstruction”: “Recovery scan size and reconciliation deadline”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M01.03-C078-T02 · Measurement method:** Choose how to observe each “Restart reconstruction” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M01.03-C078-T03 · Budget decision:** Select justified resource and input limits for “Restart reconstruction”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M01.03-C078-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Restart reconstruction” cases for “Recovery scan size and reconciliation deadline”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M01.03-C078-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Restart reconstruction” limit; preserve “Recovery does not fabricate successful execution”.
- [ ] **UC-M01.03-C078-T06 · Normal measurement:** Run or review the normal “Restart reconstruction” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M01.03-C078-T07 · At-limit measurement:** Exercise the “Restart reconstruction” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M01.03-C078-T08 · Over-limit measurement:** Exercise the “Restart reconstruction” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M01.03-C078-T09 · Uncovered-scope report:** List the “Restart reconstruction” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M01.03-C078-T10 · Limit evidence:** Publish the selected “Restart reconstruction” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M01.03-C079 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for restart reconstruction with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M01.03-C079-T01 · Event inventory:** List the “Restart reconstruction” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M01.03-C079-T02 · Diagnostic schema:** Define nonsecret fields for “Restart reconstruction” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M01.03-C079-T03 · Failure mapping:** Map each documented “Restart reconstruction” refusal or error to a diagnostic outcome; include “A missing process is restored as running from stale metadata” and prohibit conversion into a success message.
- [ ] **UC-M01.03-C079-T04 · Emission path:** Add the “Restart reconstruction” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M01.03-C079-T05 · Redaction check:** Test “Restart reconstruction” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M01.03-C079-T06 · Output budget:** Set and exercise bounded “Restart reconstruction” message size, rate and retention compatible with “Recovery scan size and reconciliation deadline”; define truncation behavior that preserves the final reason.
- [ ] **UC-M01.03-C079-T07 · Success/refusal fixtures:** Capture “Restart reconstruction” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M01.03-C079-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Restart reconstruction” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M01.03-C079-T09 · Operator review:** Read the “Restart reconstruction” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M01.03-C079-T10 · Diagnostic evidence:** Publish redacted “Restart reconstruction” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M01.03-C080 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for restart reconstruction; label unexecuted checks as untested.

- [ ] **UC-M01.03-C080-T01 · Evidence inventory:** List the “Restart reconstruction” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M01.03-C080-T02 · Artifact references:** Record the exact “Restart reconstruction” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M01.03-C080-T03 · Fixture references:** Attach the “Restart reconstruction” fixture IDs, input identities and oracle definition; preserve the source counterexample “A missing process is restored as running from stale metadata” as a distinct evidence case.
- [ ] **UC-M01.03-C080-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Restart reconstruction”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M01.03-C080-T05 · Environment record:** Record the actual “Restart reconstruction” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M01.03-C080-T06 · Expected versus observed:** Pair every “Restart reconstruction” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M01.03-C080-T07 · Failure and limit records:** Attach “Restart reconstruction” change/failure and bounds evidence where required; include uncovered “Recovery scan size and reconciliation deadline” and unresolved violations of “Recovery does not fabricate successful execution”.
- [ ] **UC-M01.03-C080-T08 · Evidence hygiene:** Check the “Restart reconstruction” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M01.03-C080-T09 · Reproduction review:** Have the “Restart reconstruction” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M01.03-C080-T10 · Acceptance linkage:** Link the “Restart reconstruction” evidence to its parent and UC-M01.03 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 09. Idempotent events

**Source delivery:** Assign durable event identities and suppress repeated transition effects.

**Source invariant:** Replaying one event does not duplicate its side effects.

**Source negative case:** An already committed stop event is delivered again.

**Source bounded quantities:** Deduplication records and retention window.

### UC-M01.03-C081 · Contract

**Original checklist item:** Specify idempotent events inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M01.03-C081-T01 · Scope statement:** Draft the operation boundary for “Idempotent events” within Lifecycle state machine; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M01.03-C081-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Idempotent events”; record each producer, representation and missing-value meaning.
- [ ] **UC-M01.03-C081-T03 · Output inventory:** List the outputs of “Idempotent events” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M01.03-C081-T04 · Field dictionary:** Create a field-and-term dictionary for “Idempotent events”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M01.03-C081-T05 · Prerequisite contract:** Map “Idempotent events” to the source component prerequisites (UC-M01.02); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M01.03-C081-T06 · Authority map:** Identify who may produce, change and consume “Idempotent events”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M01.03-C081-T07 · Invariant clause:** Add a normative clause for “Idempotent events” that preserves “Replaying one event does not duplicate its side effects”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M01.03-C081-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Idempotent events”; include the source counterexample “An already committed stop event is delivered again” and the intended safe disposition.
- [ ] **UC-M01.03-C081-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Deduplication records and retention window” in the “Idempotent events” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M01.03-C081-T10 · Contract review:** Review the “Idempotent events” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M01.03-C082 · Delivery

**Original checklist item:** Assign durable event identities and suppress repeated transition effects.

- [ ] **UC-M01.03-C082-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Idempotent events”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M01.03-C082-T02 · Change plan:** Break the source delivery for “Idempotent events” into concrete edit targets and reviewable outputs; keep the UC-M01.03 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M01.03-C082-T03 · Core artifact:** Implement the smallest selected-profile change for “Idempotent events” that realizes this source instruction: Assign durable event identities and suppress repeated transition effects.
- [ ] **UC-M01.03-C082-T04 · Concrete realization:** Trace “Idempotent events” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M01.03-C082-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Idempotent events” needed to preserve “Replaying one event does not duplicate its side effects”; record an enforcement gap where only a model exists.
- [ ] **UC-M01.03-C082-T06 · Dependency connection:** Connect the “Idempotent events” implementation to durable desired state, observed backend state and transition journals; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M01.03-C082-T07 · Resource behavior:** Account for “Deduplication records and retention window” in “Idempotent events”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M01.03-C082-T08 · Delivery check:** Run the smallest real “Idempotent events” path and its adverse fixture “An already committed stop event is delivered again”; retain actual output, state effects and final disposition.
- [ ] **UC-M01.03-C082-T09 · Patch review:** Review the “Idempotent events” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M01.03-C082-T10 · Delivery handoff:** Publish the “Idempotent events” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M01.03-C083 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Replaying one event does not duplicate its side effects. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M01.03-C083-T01 · Named property:** Create a stable property/check name under this parent for “Idempotent events”; copy its required invariant exactly: “Replaying one event does not duplicate its side effects”.
- [ ] **UC-M01.03-C083-T02 · Observable terms:** Define each term in the “Idempotent events” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M01.03-C083-T03 · Precondition set:** List the preconditions under which “Replaying one event does not duplicate its side effects” must hold for “Idempotent events”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M01.03-C083-T04 · Transition coverage:** Map the “Idempotent events” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M01.03-C083-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Idempotent events”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M01.03-C083-T06 · Satisfying fixture:** Create a concrete “Idempotent events” case that satisfies “Replaying one event does not duplicate its side effects”; record its expected observation before running the assertion or review.
- [ ] **UC-M01.03-C083-T07 · Violating fixture:** Create the source counterexample “An already committed stop event is delivered again” for “Idempotent events”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M01.03-C083-T08 · Enforcement evidence:** Exercise the “Idempotent events” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M01.03-C083-T09 · Regression linkage:** Link the “Idempotent events” property to changes in durable desired state, observed backend state and transition journals; record which dependency or contract changes require rerunning it.
- [ ] **UC-M01.03-C083-T10 · Property disposition:** Compare the satisfying and violating “Idempotent events” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M01.03-C084 · Integration

**Original checklist item:** Integrate idempotent events with durable desired state, observed backend state and transition journals; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M01.03-C084-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Idempotent events” across durable desired state, observed backend state and transition journals; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M01.03-C084-T02 · Field mapping:** Map every “Idempotent events” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M01.03-C084-T03 · Prerequisite identities:** Record the actual prerequisites for “Idempotent events” (source dependency list: UC-M01.02); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M01.03-C084-T04 · Ownership agreement:** Specify who owns “Idempotent events” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M01.03-C084-T05 · Handoff implementation:** Connect “Idempotent events” through the mapped seam using the real adapter or explicit specification reference; preserve “Replaying one event does not duplicate its side effects” across the handoff.
- [ ] **UC-M01.03-C084-T06 · Absent-input case:** Omit one required “Idempotent events” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M01.03-C084-T07 · Stale-input case:** Supply an outdated “Idempotent events” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M01.03-C084-T08 · Incompatible-input case:** Supply an incompatible “Idempotent events” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M01.03-C084-T09 · Valid integration trace:** Run a valid “Idempotent events” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M01.03-C084-T10 · Seam review:** Reconcile the “Idempotent events” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M01.03-C085 · Valid-case test

**Original checklist item:** Run a valid-path fixture for idempotent events; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M01.03-C085-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Idempotent events” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M01.03-C085-T02 · Expected-result oracle:** Specify the “Idempotent events” expected result independently of the implementation output; include the property “Replaying one event does not duplicate its side effects” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M01.03-C085-T03 · Fixture material:** Create the concrete “Idempotent events” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M01.03-C085-T04 · Target preparation:** Prepare the “Idempotent events” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M01.03-C085-T05 · Initial-state record:** Record the initial “Idempotent events” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M01.03-C085-T06 · Valid-path execution:** Execute the “Idempotent events” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M01.03-C085-T07 · Outcome comparison:** Compare every declared “Idempotent events” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M01.03-C085-T08 · State and bounds check:** Inspect the “Idempotent events” ownership/state effects and actual use of “Deduplication records and retention window”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M01.03-C085-T09 · Repeatability check:** Repeat the same “Idempotent events” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M01.03-C085-T10 · Positive evidence:** Attach the “Idempotent events” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M01.03-C086 · Negative test

**Original checklist item:** Negative case: An already committed stop event is delivered again. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M01.03-C086-T01 · Adverse-case definition:** Create a test record for the exact “Idempotent events” source counterexample: “An already committed stop event is delivered again”; state which precondition or invariant it challenges.
- [ ] **UC-M01.03-C086-T02 · Safe fixture boundary:** Define the contained test boundary for “Idempotent events”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M01.03-C086-T03 · Valid control:** Construct a valid “Idempotent events” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M01.03-C086-T04 · Minimal adverse input:** Derive the “Idempotent events” adverse fixture from the control with the smallest documented change needed to reproduce “An already committed stop event is delivered again”; retain that change as reproducible data.
- [ ] **UC-M01.03-C086-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Idempotent events”; require “Replaying one event does not duplicate its side effects” and forbid a false-success verdict.
- [ ] **UC-M01.03-C086-T06 · Adverse execution:** Exercise the “Idempotent events” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M01.03-C086-T07 · Effect inspection:** Inspect “Idempotent events” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M01.03-C086-T08 · Refusal versus failure:** Confirm the “Idempotent events” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M01.03-C086-T09 · Reset and retention:** Restore only the disposable “Idempotent events” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M01.03-C086-T10 · Negative regression:** Register the “Idempotent events” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M01.03-C087 · Change / failure test

**Original checklist item:** Exercise idempotent events when the controller restarts between accepting intent and observing the resulting state; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M01.03-C087-T01 · Scenario record:** Write the “Idempotent events” change/failure scenario exactly as supplied: the controller restarts between accepting intent and observing the resulting state; identify the property that must remain true: “Replaying one event does not duplicate its side effects”.
- [ ] **UC-M01.03-C087-T02 · Baseline capture:** Create a known-valid “Idempotent events” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M01.03-C087-T03 · Injection map:** Locate the “Idempotent events” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M01.03-C087-T04 · Disposition oracle:** Define the legal intermediate and final “Idempotent events” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M01.03-C087-T05 · Controlled trigger:** Introduce the controlled “Idempotent events” scenario in the disposable fixture: the controller restarts between accepting intent and observing the resulting state; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M01.03-C087-T06 · Intermediate inspection:** Inspect the “Idempotent events” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M01.03-C087-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Idempotent events”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M01.03-C087-T08 · Stale-evidence cleanup:** Invalidate superseded “Idempotent events” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M01.03-C087-T09 · Repeat and compare:** Repeat the selected “Idempotent events” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M01.03-C087-T10 · Failure evidence:** Publish the “Idempotent events” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M01.03-C088 · Bounds

**Original checklist item:** Choose, document and test limits for deduplication records and retention window; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M01.03-C088-T01 · Quantity inventory:** Create a measurement inventory for “Idempotent events”: “Deduplication records and retention window”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M01.03-C088-T02 · Measurement method:** Choose how to observe each “Idempotent events” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M01.03-C088-T03 · Budget decision:** Select justified resource and input limits for “Idempotent events”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M01.03-C088-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Idempotent events” cases for “Deduplication records and retention window”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M01.03-C088-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Idempotent events” limit; preserve “Replaying one event does not duplicate its side effects”.
- [ ] **UC-M01.03-C088-T06 · Normal measurement:** Run or review the normal “Idempotent events” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M01.03-C088-T07 · At-limit measurement:** Exercise the “Idempotent events” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M01.03-C088-T08 · Over-limit measurement:** Exercise the “Idempotent events” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M01.03-C088-T09 · Uncovered-scope report:** List the “Idempotent events” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M01.03-C088-T10 · Limit evidence:** Publish the selected “Idempotent events” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M01.03-C089 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for idempotent events with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M01.03-C089-T01 · Event inventory:** List the “Idempotent events” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M01.03-C089-T02 · Diagnostic schema:** Define nonsecret fields for “Idempotent events” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M01.03-C089-T03 · Failure mapping:** Map each documented “Idempotent events” refusal or error to a diagnostic outcome; include “An already committed stop event is delivered again” and prohibit conversion into a success message.
- [ ] **UC-M01.03-C089-T04 · Emission path:** Add the “Idempotent events” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M01.03-C089-T05 · Redaction check:** Test “Idempotent events” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M01.03-C089-T06 · Output budget:** Set and exercise bounded “Idempotent events” message size, rate and retention compatible with “Deduplication records and retention window”; define truncation behavior that preserves the final reason.
- [ ] **UC-M01.03-C089-T07 · Success/refusal fixtures:** Capture “Idempotent events” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M01.03-C089-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Idempotent events” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M01.03-C089-T09 · Operator review:** Read the “Idempotent events” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M01.03-C089-T10 · Diagnostic evidence:** Publish redacted “Idempotent events” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M01.03-C090 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for idempotent events; label unexecuted checks as untested.

- [ ] **UC-M01.03-C090-T01 · Evidence inventory:** List the “Idempotent events” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M01.03-C090-T02 · Artifact references:** Record the exact “Idempotent events” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M01.03-C090-T03 · Fixture references:** Attach the “Idempotent events” fixture IDs, input identities and oracle definition; preserve the source counterexample “An already committed stop event is delivered again” as a distinct evidence case.
- [ ] **UC-M01.03-C090-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Idempotent events”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M01.03-C090-T05 · Environment record:** Record the actual “Idempotent events” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M01.03-C090-T06 · Expected versus observed:** Pair every “Idempotent events” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M01.03-C090-T07 · Failure and limit records:** Attach “Idempotent events” change/failure and bounds evidence where required; include uncovered “Deduplication records and retention window” and unresolved violations of “Replaying one event does not duplicate its side effects”.
- [ ] **UC-M01.03-C090-T08 · Evidence hygiene:** Check the “Idempotent events” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M01.03-C090-T09 · Reproduction review:** Have the “Idempotent events” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M01.03-C090-T10 · Acceptance linkage:** Link the “Idempotent events” evidence to its parent and UC-M01.03 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 10. State inspection

**Source delivery:** Expose desired state, observed state and last transition reason together.

**Source invariant:** Operators can distinguish progress from a blocked transition.

**Source negative case:** Inspection omits the reason a workload remains booting.

**Source bounded quantities:** Inspection response size and acceptable staleness.

### UC-M01.03-C091 · Contract

**Original checklist item:** Specify state inspection inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M01.03-C091-T01 · Scope statement:** Draft the operation boundary for “State inspection” within Lifecycle state machine; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M01.03-C091-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “State inspection”; record each producer, representation and missing-value meaning.
- [ ] **UC-M01.03-C091-T03 · Output inventory:** List the outputs of “State inspection” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M01.03-C091-T04 · Field dictionary:** Create a field-and-term dictionary for “State inspection”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M01.03-C091-T05 · Prerequisite contract:** Map “State inspection” to the source component prerequisites (UC-M01.02); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M01.03-C091-T06 · Authority map:** Identify who may produce, change and consume “State inspection”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M01.03-C091-T07 · Invariant clause:** Add a normative clause for “State inspection” that preserves “Operators can distinguish progress from a blocked transition”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M01.03-C091-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “State inspection”; include the source counterexample “Inspection omits the reason a workload remains booting” and the intended safe disposition.
- [ ] **UC-M01.03-C091-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Inspection response size and acceptable staleness” in the “State inspection” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M01.03-C091-T10 · Contract review:** Review the “State inspection” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M01.03-C092 · Delivery

**Original checklist item:** Expose desired state, observed state and last transition reason together.

- [ ] **UC-M01.03-C092-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “State inspection”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M01.03-C092-T02 · Change plan:** Break the source delivery for “State inspection” into concrete edit targets and reviewable outputs; keep the UC-M01.03 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M01.03-C092-T03 · Core artifact:** Implement the smallest selected-profile change for “State inspection” that realizes this source instruction: Expose desired state, observed state and last transition reason together.
- [ ] **UC-M01.03-C092-T04 · Concrete realization:** Trace “State inspection” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M01.03-C092-T05 · Invariant protection:** Add the actual guard, check or review criterion for “State inspection” needed to preserve “Operators can distinguish progress from a blocked transition”; record an enforcement gap where only a model exists.
- [ ] **UC-M01.03-C092-T06 · Dependency connection:** Connect the “State inspection” implementation to durable desired state, observed backend state and transition journals; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M01.03-C092-T07 · Resource behavior:** Account for “Inspection response size and acceptable staleness” in “State inspection”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M01.03-C092-T08 · Delivery check:** Run the smallest real “State inspection” path and its adverse fixture “Inspection omits the reason a workload remains booting”; retain actual output, state effects and final disposition.
- [ ] **UC-M01.03-C092-T09 · Patch review:** Review the “State inspection” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M01.03-C092-T10 · Delivery handoff:** Publish the “State inspection” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M01.03-C093 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Operators can distinguish progress from a blocked transition. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M01.03-C093-T01 · Named property:** Create a stable property/check name under this parent for “State inspection”; copy its required invariant exactly: “Operators can distinguish progress from a blocked transition”.
- [ ] **UC-M01.03-C093-T02 · Observable terms:** Define each term in the “State inspection” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M01.03-C093-T03 · Precondition set:** List the preconditions under which “Operators can distinguish progress from a blocked transition” must hold for “State inspection”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M01.03-C093-T04 · Transition coverage:** Map the “State inspection” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M01.03-C093-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “State inspection”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M01.03-C093-T06 · Satisfying fixture:** Create a concrete “State inspection” case that satisfies “Operators can distinguish progress from a blocked transition”; record its expected observation before running the assertion or review.
- [ ] **UC-M01.03-C093-T07 · Violating fixture:** Create the source counterexample “Inspection omits the reason a workload remains booting” for “State inspection”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M01.03-C093-T08 · Enforcement evidence:** Exercise the “State inspection” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M01.03-C093-T09 · Regression linkage:** Link the “State inspection” property to changes in durable desired state, observed backend state and transition journals; record which dependency or contract changes require rerunning it.
- [ ] **UC-M01.03-C093-T10 · Property disposition:** Compare the satisfying and violating “State inspection” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M01.03-C094 · Integration

**Original checklist item:** Integrate state inspection with durable desired state, observed backend state and transition journals; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M01.03-C094-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “State inspection” across durable desired state, observed backend state and transition journals; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M01.03-C094-T02 · Field mapping:** Map every “State inspection” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M01.03-C094-T03 · Prerequisite identities:** Record the actual prerequisites for “State inspection” (source dependency list: UC-M01.02); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M01.03-C094-T04 · Ownership agreement:** Specify who owns “State inspection” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M01.03-C094-T05 · Handoff implementation:** Connect “State inspection” through the mapped seam using the real adapter or explicit specification reference; preserve “Operators can distinguish progress from a blocked transition” across the handoff.
- [ ] **UC-M01.03-C094-T06 · Absent-input case:** Omit one required “State inspection” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M01.03-C094-T07 · Stale-input case:** Supply an outdated “State inspection” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M01.03-C094-T08 · Incompatible-input case:** Supply an incompatible “State inspection” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M01.03-C094-T09 · Valid integration trace:** Run a valid “State inspection” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M01.03-C094-T10 · Seam review:** Reconcile the “State inspection” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M01.03-C095 · Valid-case test

**Original checklist item:** Run a valid-path fixture for state inspection; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M01.03-C095-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “State inspection” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M01.03-C095-T02 · Expected-result oracle:** Specify the “State inspection” expected result independently of the implementation output; include the property “Operators can distinguish progress from a blocked transition” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M01.03-C095-T03 · Fixture material:** Create the concrete “State inspection” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M01.03-C095-T04 · Target preparation:** Prepare the “State inspection” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M01.03-C095-T05 · Initial-state record:** Record the initial “State inspection” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M01.03-C095-T06 · Valid-path execution:** Execute the “State inspection” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M01.03-C095-T07 · Outcome comparison:** Compare every declared “State inspection” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M01.03-C095-T08 · State and bounds check:** Inspect the “State inspection” ownership/state effects and actual use of “Inspection response size and acceptable staleness”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M01.03-C095-T09 · Repeatability check:** Repeat the same “State inspection” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M01.03-C095-T10 · Positive evidence:** Attach the “State inspection” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M01.03-C096 · Negative test

**Original checklist item:** Negative case: Inspection omits the reason a workload remains booting. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M01.03-C096-T01 · Adverse-case definition:** Create a test record for the exact “State inspection” source counterexample: “Inspection omits the reason a workload remains booting”; state which precondition or invariant it challenges.
- [ ] **UC-M01.03-C096-T02 · Safe fixture boundary:** Define the contained test boundary for “State inspection”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M01.03-C096-T03 · Valid control:** Construct a valid “State inspection” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M01.03-C096-T04 · Minimal adverse input:** Derive the “State inspection” adverse fixture from the control with the smallest documented change needed to reproduce “Inspection omits the reason a workload remains booting”; retain that change as reproducible data.
- [ ] **UC-M01.03-C096-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “State inspection”; require “Operators can distinguish progress from a blocked transition” and forbid a false-success verdict.
- [ ] **UC-M01.03-C096-T06 · Adverse execution:** Exercise the “State inspection” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M01.03-C096-T07 · Effect inspection:** Inspect “State inspection” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M01.03-C096-T08 · Refusal versus failure:** Confirm the “State inspection” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M01.03-C096-T09 · Reset and retention:** Restore only the disposable “State inspection” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M01.03-C096-T10 · Negative regression:** Register the “State inspection” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M01.03-C097 · Change / failure test

**Original checklist item:** Exercise state inspection when the controller restarts between accepting intent and observing the resulting state; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M01.03-C097-T01 · Scenario record:** Write the “State inspection” change/failure scenario exactly as supplied: the controller restarts between accepting intent and observing the resulting state; identify the property that must remain true: “Operators can distinguish progress from a blocked transition”.
- [ ] **UC-M01.03-C097-T02 · Baseline capture:** Create a known-valid “State inspection” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M01.03-C097-T03 · Injection map:** Locate the “State inspection” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M01.03-C097-T04 · Disposition oracle:** Define the legal intermediate and final “State inspection” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M01.03-C097-T05 · Controlled trigger:** Introduce the controlled “State inspection” scenario in the disposable fixture: the controller restarts between accepting intent and observing the resulting state; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M01.03-C097-T06 · Intermediate inspection:** Inspect the “State inspection” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M01.03-C097-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “State inspection”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M01.03-C097-T08 · Stale-evidence cleanup:** Invalidate superseded “State inspection” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M01.03-C097-T09 · Repeat and compare:** Repeat the selected “State inspection” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M01.03-C097-T10 · Failure evidence:** Publish the “State inspection” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M01.03-C098 · Bounds

**Original checklist item:** Choose, document and test limits for inspection response size and acceptable staleness; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M01.03-C098-T01 · Quantity inventory:** Create a measurement inventory for “State inspection”: “Inspection response size and acceptable staleness”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M01.03-C098-T02 · Measurement method:** Choose how to observe each “State inspection” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M01.03-C098-T03 · Budget decision:** Select justified resource and input limits for “State inspection”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M01.03-C098-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “State inspection” cases for “Inspection response size and acceptable staleness”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M01.03-C098-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “State inspection” limit; preserve “Operators can distinguish progress from a blocked transition”.
- [ ] **UC-M01.03-C098-T06 · Normal measurement:** Run or review the normal “State inspection” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M01.03-C098-T07 · At-limit measurement:** Exercise the “State inspection” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M01.03-C098-T08 · Over-limit measurement:** Exercise the “State inspection” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M01.03-C098-T09 · Uncovered-scope report:** List the “State inspection” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M01.03-C098-T10 · Limit evidence:** Publish the selected “State inspection” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M01.03-C099 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for state inspection with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M01.03-C099-T01 · Event inventory:** List the “State inspection” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M01.03-C099-T02 · Diagnostic schema:** Define nonsecret fields for “State inspection” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M01.03-C099-T03 · Failure mapping:** Map each documented “State inspection” refusal or error to a diagnostic outcome; include “Inspection omits the reason a workload remains booting” and prohibit conversion into a success message.
- [ ] **UC-M01.03-C099-T04 · Emission path:** Add the “State inspection” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M01.03-C099-T05 · Redaction check:** Test “State inspection” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M01.03-C099-T06 · Output budget:** Set and exercise bounded “State inspection” message size, rate and retention compatible with “Inspection response size and acceptable staleness”; define truncation behavior that preserves the final reason.
- [ ] **UC-M01.03-C099-T07 · Success/refusal fixtures:** Capture “State inspection” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M01.03-C099-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “State inspection” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M01.03-C099-T09 · Operator review:** Read the “State inspection” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M01.03-C099-T10 · Diagnostic evidence:** Publish redacted “State inspection” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M01.03-C100 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for state inspection; label unexecuted checks as untested.

- [ ] **UC-M01.03-C100-T01 · Evidence inventory:** List the “State inspection” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M01.03-C100-T02 · Artifact references:** Record the exact “State inspection” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M01.03-C100-T03 · Fixture references:** Attach the “State inspection” fixture IDs, input identities and oracle definition; preserve the source counterexample “Inspection omits the reason a workload remains booting” as a distinct evidence case.
- [ ] **UC-M01.03-C100-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “State inspection”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M01.03-C100-T05 · Environment record:** Record the actual “State inspection” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M01.03-C100-T06 · Expected versus observed:** Pair every “State inspection” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M01.03-C100-T07 · Failure and limit records:** Attach “State inspection” change/failure and bounds evidence where required; include uncovered “Inspection response size and acceptable staleness” and unresolved violations of “Operators can distinguish progress from a blocked transition”.
- [ ] **UC-M01.03-C100-T08 · Evidence hygiene:** Check the “State inspection” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M01.03-C100-T09 · Reproduction review:** Have the “State inspection” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M01.03-C100-T10 · Acceptance linkage:** Link the “State inspection” evidence to its parent and UC-M01.03 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

