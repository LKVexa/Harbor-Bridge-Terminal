# UC-M01.02 — Versioned runtime and guest contracts

**To-Do Pack 2.0.0 · Baseline UC-2.2.0 · 100 parent checks × 10 subtasks = 1,000 to-dos**

[Master index](../../INDEX.md) · [Workstream index](../../w/01.md)

| Field | Preserved source value |
|---|---|
| Workstream | 01. Architecture and executable contracts |
| Milestone | A |
| Priority | P0 |
| Source assessment | PARTIAL |
| Scope | core or selected profile |
| Dependencies | [UC-M01.01](../01/UC-M01.01.md) |
| Source checklist pack | 1.0.0 |
| Original reference labels | [S1], [S3]. |

## Original requirement

Specify boot, invoke, stop, inspect, snapshot and error contracts with strict required fields, extensions and version negotiation.

**Original acceptance criterion:** Contract tests reject unknown incompatible versions, duplicate fields and unsupported capabilities before mutation.

**Source trace:** Original checklist `UC100/c/01/UC-M01.02.md` inside [s/checklists.zip](../../s/checklists.zip); exact parent records in [data/parents.jsonl](../../data/parents.jsonl). Original roadmap lines 60–70 are preserved in [s/roadmap.md](../../s/roadmap.md).

## How to use these lists

Every parent statement below is preserved verbatim. Its ten child tasks are proposed decomposition, not implemented capabilities or executed tests. Child IDs append `-T01` through `-T10` to the original parent ID. All begin unchecked / `TODO`. Design/review evidence does not establish runtime enforcement; observe the actual selected target where the parent requires it.

The source dependency graph and selected release profile determine applicability. The numbered child sequence is a local working order, not an added hard dependency graph. An unselected optional feature needs a recorded not-applicable rationale; missing prerequisites for selected work remain blockers. Numerical budgets, backends and trust mechanisms remain decisions unless fixed by the source. Test hostile cases only with synthetic inputs in authorized disposable environments.

## 01. Operation vocabulary

**Source delivery:** Specify separate boot, invoke, stop, inspect and snapshot operations.

**Source invariant:** An operation has one unambiguous semantic meaning.

**Source negative case:** A stop request is interpreted as destructive unload.

**Source bounded quantities:** Operation count and extension namespace size.

### UC-M01.02-C001 · Contract

**Original checklist item:** Specify the scope and representation of operation vocabulary; identify its producer, consumer, authority assumptions and explicitly unsupported cases.

- [ ] **UC-M01.02-C001-T01 · Scope statement:** Draft a scope note for “Operation vocabulary” within Versioned runtime and guest contracts; separate required model statements, explicit exclusions and unresolved design decisions.
- [ ] **UC-M01.02-C001-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Operation vocabulary”; record each producer, representation and missing-value meaning.
- [ ] **UC-M01.02-C001-T03 · Output inventory:** List the outputs of “Operation vocabulary” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M01.02-C001-T04 · Field dictionary:** Create a field-and-term dictionary for “Operation vocabulary”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M01.02-C001-T05 · Prerequisite contract:** Map “Operation vocabulary” to the source component prerequisites (UC-M01.01); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M01.02-C001-T06 · Authority map:** Identify who may produce, change and consume “Operation vocabulary”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M01.02-C001-T07 · Invariant clause:** Add a normative clause for “Operation vocabulary” that preserves “An operation has one unambiguous semantic meaning”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M01.02-C001-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Operation vocabulary”; include the source counterexample “A stop request is interpreted as destructive unload” and the intended safe disposition.
- [ ] **UC-M01.02-C001-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Operation count and extension namespace size” in the “Operation vocabulary” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M01.02-C001-T10 · Contract review:** Review the “Operation vocabulary” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M01.02-C002 · Delivery

**Original checklist item:** Specify separate boot, invoke, stop, inspect and snapshot operations.

- [ ] **UC-M01.02-C002-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Operation vocabulary”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M01.02-C002-T02 · Change plan:** Break the source delivery for “Operation vocabulary” into concrete edit targets and reviewable outputs; keep the UC-M01.02 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M01.02-C002-T03 · Core artifact:** Create the “Operation vocabulary” model, schema or inventory that realizes this source instruction: Specify separate boot, invoke, stop, inspect and snapshot operations.
- [ ] **UC-M01.02-C002-T04 · Concrete realization:** Populate “Operation vocabulary” with one concrete worked case; map every required entity or field to its source and flag any unmapped entry.
- [ ] **UC-M01.02-C002-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Operation vocabulary” needed to preserve “An operation has one unambiguous semantic meaning”; record an enforcement gap where only a model exists.
- [ ] **UC-M01.02-C002-T06 · Dependency connection:** Connect the “Operation vocabulary” specification to CLI requests, backend adapters and guest ABI negotiation; record code coverage separately where the design is not yet enforced.
- [ ] **UC-M01.02-C002-T07 · Resource behavior:** Account for “Operation count and extension namespace size” in “Operation vocabulary”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M01.02-C002-T08 · Delivery check:** Walk the populated “Operation vocabulary” model through a valid example and the source counterexample “A stop request is interpreted as destructive unload”; record corrections and unresolved enforcement gaps.
- [ ] **UC-M01.02-C002-T09 · Patch review:** Review the “Operation vocabulary” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M01.02-C002-T10 · Delivery handoff:** Publish the “Operation vocabulary” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M01.02-C003 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: An operation has one unambiguous semantic meaning. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M01.02-C003-T01 · Named property:** Create a stable property/check name under this parent for “Operation vocabulary”; copy its required invariant exactly: “An operation has one unambiguous semantic meaning”.
- [ ] **UC-M01.02-C003-T02 · Observable terms:** Define each term in the “Operation vocabulary” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M01.02-C003-T03 · Precondition set:** List the preconditions under which “An operation has one unambiguous semantic meaning” must hold for “Operation vocabulary”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M01.02-C003-T04 · Transition coverage:** Map the “Operation vocabulary” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M01.02-C003-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Operation vocabulary”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M01.02-C003-T06 · Satisfying fixture:** Create a concrete “Operation vocabulary” case that satisfies “An operation has one unambiguous semantic meaning”; record its expected observation before running the assertion or review.
- [ ] **UC-M01.02-C003-T07 · Violating fixture:** Create the source counterexample “A stop request is interpreted as destructive unload” for “Operation vocabulary”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M01.02-C003-T08 · Enforcement evidence:** Exercise the “Operation vocabulary” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M01.02-C003-T09 · Regression linkage:** Link the “Operation vocabulary” property to changes in CLI requests, backend adapters and guest ABI negotiation; record which dependency or contract changes require rerunning it.
- [ ] **UC-M01.02-C003-T10 · Property disposition:** Compare the satisfying and violating “Operation vocabulary” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M01.02-C004 · Integration

**Original checklist item:** Integrate operation vocabulary with CLI requests, backend adapters and guest ABI negotiation; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M01.02-C004-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Operation vocabulary” across CLI requests, backend adapters and guest ABI negotiation; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M01.02-C004-T02 · Field mapping:** Map every “Operation vocabulary” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M01.02-C004-T03 · Prerequisite identities:** Record the actual prerequisites for “Operation vocabulary” (source dependency list: UC-M01.01); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M01.02-C004-T04 · Ownership agreement:** Specify who owns “Operation vocabulary” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M01.02-C004-T05 · Handoff implementation:** Connect “Operation vocabulary” through the mapped seam using the real adapter or explicit specification reference; preserve “An operation has one unambiguous semantic meaning” across the handoff.
- [ ] **UC-M01.02-C004-T06 · Absent-input case:** Omit one required “Operation vocabulary” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M01.02-C004-T07 · Stale-input case:** Supply an outdated “Operation vocabulary” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M01.02-C004-T08 · Incompatible-input case:** Supply an incompatible “Operation vocabulary” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M01.02-C004-T09 · Valid integration trace:** Run a valid “Operation vocabulary” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M01.02-C004-T10 · Seam review:** Reconcile the “Operation vocabulary” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M01.02-C005 · Valid-case test

**Original checklist item:** Construct a valid worked example for operation vocabulary; evaluate it against predeclared expected decisions and, where enforcement exists, run the corresponding conformance fixture.

- [ ] **UC-M01.02-C005-T01 · Valid fixture choice:** Select one concrete valid worked example for “Operation vocabulary”; enumerate the model inputs and the expected review decision before evaluating it.
- [ ] **UC-M01.02-C005-T02 · Expected-result oracle:** Specify the “Operation vocabulary” expected result independently of the implementation output; include the property “An operation has one unambiguous semantic meaning” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M01.02-C005-T03 · Fixture material:** Create the concrete “Operation vocabulary” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M01.02-C005-T04 · Target preparation:** Prepare the “Operation vocabulary” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M01.02-C005-T05 · Initial-state record:** Record the initial “Operation vocabulary” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M01.02-C005-T06 · Valid-path execution:** Evaluate the “Operation vocabulary” example against the reviewed model; where a runtime mechanism exists, run its corresponding fixture and label those observations separately.
- [ ] **UC-M01.02-C005-T07 · Outcome comparison:** Compare every declared “Operation vocabulary” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M01.02-C005-T08 · State and bounds check:** Inspect the “Operation vocabulary” ownership/state effects and actual use of “Operation count and extension namespace size”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M01.02-C005-T09 · Repeatability check:** Repeat the same “Operation vocabulary” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M01.02-C005-T10 · Positive evidence:** Attach the “Operation vocabulary” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M01.02-C006 · Negative test

**Original checklist item:** Negative case: A stop request is interpreted as destructive unload. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M01.02-C006-T01 · Adverse-case definition:** Create a test record for the exact “Operation vocabulary” source counterexample: “A stop request is interpreted as destructive unload”; state which precondition or invariant it challenges.
- [ ] **UC-M01.02-C006-T02 · Safe fixture boundary:** Define the contained test boundary for “Operation vocabulary”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M01.02-C006-T03 · Valid control:** Construct a valid “Operation vocabulary” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M01.02-C006-T04 · Minimal adverse input:** Derive the “Operation vocabulary” adverse fixture from the control with the smallest documented change needed to reproduce “A stop request is interpreted as destructive unload”; retain that change as reproducible data.
- [ ] **UC-M01.02-C006-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Operation vocabulary”; require “An operation has one unambiguous semantic meaning” and forbid a false-success verdict.
- [ ] **UC-M01.02-C006-T06 · Adverse execution:** Evaluate the “Operation vocabulary” adverse case through the actual review/contract gate; where implemented, also observe the runtime refusal and keep the two evidence classes separate.
- [ ] **UC-M01.02-C006-T07 · Effect inspection:** Inspect “Operation vocabulary” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M01.02-C006-T08 · Refusal versus failure:** Confirm the “Operation vocabulary” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M01.02-C006-T09 · Reset and retention:** Restore only the disposable “Operation vocabulary” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M01.02-C006-T10 · Negative regression:** Register the “Operation vocabulary” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M01.02-C007 · Change / failure test

**Original checklist item:** Exercise operation vocabulary when a client and backend advertise different contract versions; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M01.02-C007-T01 · Scenario record:** Write the “Operation vocabulary” change/failure scenario exactly as supplied: a client and backend advertise different contract versions; identify the property that must remain true: “An operation has one unambiguous semantic meaning”.
- [ ] **UC-M01.02-C007-T02 · Baseline capture:** Create a known-valid “Operation vocabulary” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M01.02-C007-T03 · Injection map:** Locate the “Operation vocabulary” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M01.02-C007-T04 · Disposition oracle:** Define the legal intermediate and final “Operation vocabulary” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M01.02-C007-T05 · Controlled trigger:** Apply the controlled model-change scenario for “Operation vocabulary”: a client and backend advertise different contract versions; retain the exact before/after declarations. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M01.02-C007-T06 · Intermediate inspection:** Review which “Operation vocabulary” claims, approvals and evidence references become stale after the change; keep unresolved enforcement gaps visible.
- [ ] **UC-M01.02-C007-T07 · Recovery path:** Revise or explicitly refuse the changed “Operation vocabulary” model under the documented compatibility policy; re-review affected claims before restoring their approval.
- [ ] **UC-M01.02-C007-T08 · Stale-evidence cleanup:** Invalidate superseded “Operation vocabulary” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M01.02-C007-T09 · Repeat and compare:** Repeat the selected “Operation vocabulary” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M01.02-C007-T10 · Failure evidence:** Publish the “Operation vocabulary” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M01.02-C008 · Bounds

**Original checklist item:** Define completeness and scaling criteria for operation count and extension namespace size; exercise larger inventories or fixture sets, and report uncovered scope instead of silently excluding it.

- [ ] **UC-M01.02-C008-T01 · Quantity inventory:** Create a measurement inventory for “Operation vocabulary”: “Operation count and extension namespace size”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M01.02-C008-T02 · Measurement method:** Choose how to observe each “Operation vocabulary” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M01.02-C008-T03 · Budget decision:** Select justified coverage and completeness limits for “Operation vocabulary”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M01.02-C008-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Operation vocabulary” cases for “Operation count and extension namespace size”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M01.02-C008-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Operation vocabulary” limit; preserve “An operation has one unambiguous semantic meaning”.
- [ ] **UC-M01.02-C008-T06 · Normal measurement:** Run or review the normal “Operation vocabulary” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M01.02-C008-T07 · At-limit measurement:** Exercise the “Operation vocabulary” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M01.02-C008-T08 · Over-limit measurement:** Exercise the “Operation vocabulary” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M01.02-C008-T09 · Uncovered-scope report:** List the “Operation vocabulary” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M01.02-C008-T10 · Limit evidence:** Publish the selected “Operation vocabulary” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M01.02-C009 · Diagnostics / review

**Original checklist item:** Record the rationale, unresolved assumptions, enforcement gaps and re-review triggers for operation vocabulary; make design-only claims visibly distinct from observed behavior.

- [ ] **UC-M01.02-C009-T01 · Review inventory:** List the “Operation vocabulary” decisions and claims requiring review; distinguish source requirements, implementation observations and engineering assumptions.
- [ ] **UC-M01.02-C009-T02 · Rationale record:** Write the rationale for the selected “Operation vocabulary” representation or policy; link each choice to the requirement rather than an unexplained preference.
- [ ] **UC-M01.02-C009-T03 · Assumption ledger:** Record unresolved “Operation vocabulary” assumptions, their owner and what observation or decision would resolve them; do not treat unknowns as approvals.
- [ ] **UC-M01.02-C009-T04 · Boundary map:** Map each “Operation vocabulary” claim to an actual guard or explicit design/review gate; flag gaps against “An operation has one unambiguous semantic meaning”.
- [ ] **UC-M01.02-C009-T05 · Counterexample review:** Walk reviewers through the “Operation vocabulary” counterexample “A stop request is interpreted as destructive unload”; record whether the model detects it and whether any runtime guard was actually exercised.
- [ ] **UC-M01.02-C009-T06 · Review outcome vocabulary:** Define approved, blocked, superseded and untested review outcomes for “Operation vocabulary”; ensure the wording cannot be read as runtime enforcement evidence.
- [ ] **UC-M01.02-C009-T07 · Re-review triggers:** List “Operation vocabulary” invalidation triggers, including the source change scenario: a client and backend advertise different contract versions; identify the affected claims and evidence.
- [ ] **UC-M01.02-C009-T08 · Sensitive-data review:** Inspect the “Operation vocabulary” review record for secrets and unrelated user content; retain nonsecret references sufficient for reproducibility.
- [ ] **UC-M01.02-C009-T09 · Independent reading:** Have the “Operation vocabulary” record read against the original acceptance criterion and CLI requests, backend adapters and guest ABI negotiation; record misunderstandings or missing evidence as corrections.
- [ ] **UC-M01.02-C009-T10 · Review disposition:** Publish the “Operation vocabulary” rationale, versioned review outcome, unresolved gaps and explicit next decision; keep blockers open until supported evidence resolves them.

### UC-M01.02-C010 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for operation vocabulary; label unexecuted checks as untested.

- [ ] **UC-M01.02-C010-T01 · Evidence inventory:** List the “Operation vocabulary” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M01.02-C010-T02 · Artifact references:** Record the exact “Operation vocabulary” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M01.02-C010-T03 · Fixture references:** Attach the “Operation vocabulary” fixture IDs, input identities and oracle definition; preserve the source counterexample “A stop request is interpreted as destructive unload” as a distinct evidence case.
- [ ] **UC-M01.02-C010-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Operation vocabulary”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M01.02-C010-T05 · Environment record:** Record the actual “Operation vocabulary” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M01.02-C010-T06 · Expected versus observed:** Pair every “Operation vocabulary” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M01.02-C010-T07 · Failure and limit records:** Attach “Operation vocabulary” change/failure and bounds evidence where required; include uncovered “Operation count and extension namespace size” and unresolved violations of “An operation has one unambiguous semantic meaning”.
- [ ] **UC-M01.02-C010-T08 · Evidence hygiene:** Check the “Operation vocabulary” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M01.02-C010-T09 · Reproduction review:** Have the “Operation vocabulary” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M01.02-C010-T10 · Acceptance linkage:** Link the “Operation vocabulary” evidence to its parent and UC-M01.02 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 02. Required request fields

**Source delivery:** Define required identity, generation and operation-specific input fields.

**Source invariant:** Missing mandatory fields cause rejection before mutation.

**Source negative case:** A boot request omits the selected image identity.

**Source bounded quantities:** Request bytes, field count and nesting depth.

### UC-M01.02-C011 · Contract

**Original checklist item:** Specify the scope and representation of required request fields; identify its producer, consumer, authority assumptions and explicitly unsupported cases.

- [ ] **UC-M01.02-C011-T01 · Scope statement:** Draft a scope note for “Required request fields” within Versioned runtime and guest contracts; separate required model statements, explicit exclusions and unresolved design decisions.
- [ ] **UC-M01.02-C011-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Required request fields”; record each producer, representation and missing-value meaning.
- [ ] **UC-M01.02-C011-T03 · Output inventory:** List the outputs of “Required request fields” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M01.02-C011-T04 · Field dictionary:** Create a field-and-term dictionary for “Required request fields”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M01.02-C011-T05 · Prerequisite contract:** Map “Required request fields” to the source component prerequisites (UC-M01.01); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M01.02-C011-T06 · Authority map:** Identify who may produce, change and consume “Required request fields”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M01.02-C011-T07 · Invariant clause:** Add a normative clause for “Required request fields” that preserves “Missing mandatory fields cause rejection before mutation”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M01.02-C011-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Required request fields”; include the source counterexample “A boot request omits the selected image identity” and the intended safe disposition.
- [ ] **UC-M01.02-C011-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Request bytes, field count and nesting depth” in the “Required request fields” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M01.02-C011-T10 · Contract review:** Review the “Required request fields” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M01.02-C012 · Delivery

**Original checklist item:** Define required identity, generation and operation-specific input fields.

- [ ] **UC-M01.02-C012-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Required request fields”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M01.02-C012-T02 · Change plan:** Break the source delivery for “Required request fields” into concrete edit targets and reviewable outputs; keep the UC-M01.02 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M01.02-C012-T03 · Core artifact:** Create the “Required request fields” model, schema or inventory that realizes this source instruction: Define required identity, generation and operation-specific input fields.
- [ ] **UC-M01.02-C012-T04 · Concrete realization:** Populate “Required request fields” with one concrete worked case; map every required entity or field to its source and flag any unmapped entry.
- [ ] **UC-M01.02-C012-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Required request fields” needed to preserve “Missing mandatory fields cause rejection before mutation”; record an enforcement gap where only a model exists.
- [ ] **UC-M01.02-C012-T06 · Dependency connection:** Connect the “Required request fields” specification to CLI requests, backend adapters and guest ABI negotiation; record code coverage separately where the design is not yet enforced.
- [ ] **UC-M01.02-C012-T07 · Resource behavior:** Account for “Request bytes, field count and nesting depth” in “Required request fields”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M01.02-C012-T08 · Delivery check:** Walk the populated “Required request fields” model through a valid example and the source counterexample “A boot request omits the selected image identity”; record corrections and unresolved enforcement gaps.
- [ ] **UC-M01.02-C012-T09 · Patch review:** Review the “Required request fields” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M01.02-C012-T10 · Delivery handoff:** Publish the “Required request fields” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M01.02-C013 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Missing mandatory fields cause rejection before mutation. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M01.02-C013-T01 · Named property:** Create a stable property/check name under this parent for “Required request fields”; copy its required invariant exactly: “Missing mandatory fields cause rejection before mutation”.
- [ ] **UC-M01.02-C013-T02 · Observable terms:** Define each term in the “Required request fields” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M01.02-C013-T03 · Precondition set:** List the preconditions under which “Missing mandatory fields cause rejection before mutation” must hold for “Required request fields”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M01.02-C013-T04 · Transition coverage:** Map the “Required request fields” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M01.02-C013-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Required request fields”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M01.02-C013-T06 · Satisfying fixture:** Create a concrete “Required request fields” case that satisfies “Missing mandatory fields cause rejection before mutation”; record its expected observation before running the assertion or review.
- [ ] **UC-M01.02-C013-T07 · Violating fixture:** Create the source counterexample “A boot request omits the selected image identity” for “Required request fields”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M01.02-C013-T08 · Enforcement evidence:** Exercise the “Required request fields” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M01.02-C013-T09 · Regression linkage:** Link the “Required request fields” property to changes in CLI requests, backend adapters and guest ABI negotiation; record which dependency or contract changes require rerunning it.
- [ ] **UC-M01.02-C013-T10 · Property disposition:** Compare the satisfying and violating “Required request fields” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M01.02-C014 · Integration

**Original checklist item:** Integrate required request fields with CLI requests, backend adapters and guest ABI negotiation; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M01.02-C014-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Required request fields” across CLI requests, backend adapters and guest ABI negotiation; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M01.02-C014-T02 · Field mapping:** Map every “Required request fields” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M01.02-C014-T03 · Prerequisite identities:** Record the actual prerequisites for “Required request fields” (source dependency list: UC-M01.01); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M01.02-C014-T04 · Ownership agreement:** Specify who owns “Required request fields” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M01.02-C014-T05 · Handoff implementation:** Connect “Required request fields” through the mapped seam using the real adapter or explicit specification reference; preserve “Missing mandatory fields cause rejection before mutation” across the handoff.
- [ ] **UC-M01.02-C014-T06 · Absent-input case:** Omit one required “Required request fields” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M01.02-C014-T07 · Stale-input case:** Supply an outdated “Required request fields” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M01.02-C014-T08 · Incompatible-input case:** Supply an incompatible “Required request fields” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M01.02-C014-T09 · Valid integration trace:** Run a valid “Required request fields” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M01.02-C014-T10 · Seam review:** Reconcile the “Required request fields” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M01.02-C015 · Valid-case test

**Original checklist item:** Construct a valid worked example for required request fields; evaluate it against predeclared expected decisions and, where enforcement exists, run the corresponding conformance fixture.

- [ ] **UC-M01.02-C015-T01 · Valid fixture choice:** Select one concrete valid worked example for “Required request fields”; enumerate the model inputs and the expected review decision before evaluating it.
- [ ] **UC-M01.02-C015-T02 · Expected-result oracle:** Specify the “Required request fields” expected result independently of the implementation output; include the property “Missing mandatory fields cause rejection before mutation” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M01.02-C015-T03 · Fixture material:** Create the concrete “Required request fields” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M01.02-C015-T04 · Target preparation:** Prepare the “Required request fields” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M01.02-C015-T05 · Initial-state record:** Record the initial “Required request fields” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M01.02-C015-T06 · Valid-path execution:** Evaluate the “Required request fields” example against the reviewed model; where a runtime mechanism exists, run its corresponding fixture and label those observations separately.
- [ ] **UC-M01.02-C015-T07 · Outcome comparison:** Compare every declared “Required request fields” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M01.02-C015-T08 · State and bounds check:** Inspect the “Required request fields” ownership/state effects and actual use of “Request bytes, field count and nesting depth”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M01.02-C015-T09 · Repeatability check:** Repeat the same “Required request fields” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M01.02-C015-T10 · Positive evidence:** Attach the “Required request fields” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M01.02-C016 · Negative test

**Original checklist item:** Negative case: A boot request omits the selected image identity. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M01.02-C016-T01 · Adverse-case definition:** Create a test record for the exact “Required request fields” source counterexample: “A boot request omits the selected image identity”; state which precondition or invariant it challenges.
- [ ] **UC-M01.02-C016-T02 · Safe fixture boundary:** Define the contained test boundary for “Required request fields”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M01.02-C016-T03 · Valid control:** Construct a valid “Required request fields” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M01.02-C016-T04 · Minimal adverse input:** Derive the “Required request fields” adverse fixture from the control with the smallest documented change needed to reproduce “A boot request omits the selected image identity”; retain that change as reproducible data.
- [ ] **UC-M01.02-C016-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Required request fields”; require “Missing mandatory fields cause rejection before mutation” and forbid a false-success verdict.
- [ ] **UC-M01.02-C016-T06 · Adverse execution:** Evaluate the “Required request fields” adverse case through the actual review/contract gate; where implemented, also observe the runtime refusal and keep the two evidence classes separate.
- [ ] **UC-M01.02-C016-T07 · Effect inspection:** Inspect “Required request fields” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M01.02-C016-T08 · Refusal versus failure:** Confirm the “Required request fields” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M01.02-C016-T09 · Reset and retention:** Restore only the disposable “Required request fields” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M01.02-C016-T10 · Negative regression:** Register the “Required request fields” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M01.02-C017 · Change / failure test

**Original checklist item:** Exercise required request fields when a client and backend advertise different contract versions; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M01.02-C017-T01 · Scenario record:** Write the “Required request fields” change/failure scenario exactly as supplied: a client and backend advertise different contract versions; identify the property that must remain true: “Missing mandatory fields cause rejection before mutation”.
- [ ] **UC-M01.02-C017-T02 · Baseline capture:** Create a known-valid “Required request fields” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M01.02-C017-T03 · Injection map:** Locate the “Required request fields” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M01.02-C017-T04 · Disposition oracle:** Define the legal intermediate and final “Required request fields” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M01.02-C017-T05 · Controlled trigger:** Apply the controlled model-change scenario for “Required request fields”: a client and backend advertise different contract versions; retain the exact before/after declarations. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M01.02-C017-T06 · Intermediate inspection:** Review which “Required request fields” claims, approvals and evidence references become stale after the change; keep unresolved enforcement gaps visible.
- [ ] **UC-M01.02-C017-T07 · Recovery path:** Revise or explicitly refuse the changed “Required request fields” model under the documented compatibility policy; re-review affected claims before restoring their approval.
- [ ] **UC-M01.02-C017-T08 · Stale-evidence cleanup:** Invalidate superseded “Required request fields” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M01.02-C017-T09 · Repeat and compare:** Repeat the selected “Required request fields” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M01.02-C017-T10 · Failure evidence:** Publish the “Required request fields” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M01.02-C018 · Bounds

**Original checklist item:** Define completeness and scaling criteria for request bytes, field count and nesting depth; exercise larger inventories or fixture sets, and report uncovered scope instead of silently excluding it.

- [ ] **UC-M01.02-C018-T01 · Quantity inventory:** Create a measurement inventory for “Required request fields”: “Request bytes, field count and nesting depth”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M01.02-C018-T02 · Measurement method:** Choose how to observe each “Required request fields” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M01.02-C018-T03 · Budget decision:** Select justified coverage and completeness limits for “Required request fields”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M01.02-C018-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Required request fields” cases for “Request bytes, field count and nesting depth”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M01.02-C018-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Required request fields” limit; preserve “Missing mandatory fields cause rejection before mutation”.
- [ ] **UC-M01.02-C018-T06 · Normal measurement:** Run or review the normal “Required request fields” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M01.02-C018-T07 · At-limit measurement:** Exercise the “Required request fields” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M01.02-C018-T08 · Over-limit measurement:** Exercise the “Required request fields” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M01.02-C018-T09 · Uncovered-scope report:** List the “Required request fields” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M01.02-C018-T10 · Limit evidence:** Publish the selected “Required request fields” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M01.02-C019 · Diagnostics / review

**Original checklist item:** Record the rationale, unresolved assumptions, enforcement gaps and re-review triggers for required request fields; make design-only claims visibly distinct from observed behavior.

- [ ] **UC-M01.02-C019-T01 · Review inventory:** List the “Required request fields” decisions and claims requiring review; distinguish source requirements, implementation observations and engineering assumptions.
- [ ] **UC-M01.02-C019-T02 · Rationale record:** Write the rationale for the selected “Required request fields” representation or policy; link each choice to the requirement rather than an unexplained preference.
- [ ] **UC-M01.02-C019-T03 · Assumption ledger:** Record unresolved “Required request fields” assumptions, their owner and what observation or decision would resolve them; do not treat unknowns as approvals.
- [ ] **UC-M01.02-C019-T04 · Boundary map:** Map each “Required request fields” claim to an actual guard or explicit design/review gate; flag gaps against “Missing mandatory fields cause rejection before mutation”.
- [ ] **UC-M01.02-C019-T05 · Counterexample review:** Walk reviewers through the “Required request fields” counterexample “A boot request omits the selected image identity”; record whether the model detects it and whether any runtime guard was actually exercised.
- [ ] **UC-M01.02-C019-T06 · Review outcome vocabulary:** Define approved, blocked, superseded and untested review outcomes for “Required request fields”; ensure the wording cannot be read as runtime enforcement evidence.
- [ ] **UC-M01.02-C019-T07 · Re-review triggers:** List “Required request fields” invalidation triggers, including the source change scenario: a client and backend advertise different contract versions; identify the affected claims and evidence.
- [ ] **UC-M01.02-C019-T08 · Sensitive-data review:** Inspect the “Required request fields” review record for secrets and unrelated user content; retain nonsecret references sufficient for reproducibility.
- [ ] **UC-M01.02-C019-T09 · Independent reading:** Have the “Required request fields” record read against the original acceptance criterion and CLI requests, backend adapters and guest ABI negotiation; record misunderstandings or missing evidence as corrections.
- [ ] **UC-M01.02-C019-T10 · Review disposition:** Publish the “Required request fields” rationale, versioned review outcome, unresolved gaps and explicit next decision; keep blockers open until supported evidence resolves them.

### UC-M01.02-C020 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for required request fields; label unexecuted checks as untested.

- [ ] **UC-M01.02-C020-T01 · Evidence inventory:** List the “Required request fields” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M01.02-C020-T02 · Artifact references:** Record the exact “Required request fields” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M01.02-C020-T03 · Fixture references:** Attach the “Required request fields” fixture IDs, input identities and oracle definition; preserve the source counterexample “A boot request omits the selected image identity” as a distinct evidence case.
- [ ] **UC-M01.02-C020-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Required request fields”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M01.02-C020-T05 · Environment record:** Record the actual “Required request fields” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M01.02-C020-T06 · Expected versus observed:** Pair every “Required request fields” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M01.02-C020-T07 · Failure and limit records:** Attach “Required request fields” change/failure and bounds evidence where required; include uncovered “Request bytes, field count and nesting depth” and unresolved violations of “Missing mandatory fields cause rejection before mutation”.
- [ ] **UC-M01.02-C020-T08 · Evidence hygiene:** Check the “Required request fields” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M01.02-C020-T09 · Reproduction review:** Have the “Required request fields” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M01.02-C020-T10 · Acceptance linkage:** Link the “Required request fields” evidence to its parent and UC-M01.02 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 03. Response envelopes

**Source delivery:** Define structured success, failure and asynchronous-operation responses.

**Source invariant:** A response does not equate acceptance with completed execution.

**Source negative case:** A queued request returns a completed-success disposition.

**Source bounded quantities:** Response bytes and retained diagnostic size.

### UC-M01.02-C021 · Contract

**Original checklist item:** Specify the scope and representation of response envelopes; identify its producer, consumer, authority assumptions and explicitly unsupported cases.

- [ ] **UC-M01.02-C021-T01 · Scope statement:** Draft a scope note for “Response envelopes” within Versioned runtime and guest contracts; separate required model statements, explicit exclusions and unresolved design decisions.
- [ ] **UC-M01.02-C021-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Response envelopes”; record each producer, representation and missing-value meaning.
- [ ] **UC-M01.02-C021-T03 · Output inventory:** List the outputs of “Response envelopes” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M01.02-C021-T04 · Field dictionary:** Create a field-and-term dictionary for “Response envelopes”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M01.02-C021-T05 · Prerequisite contract:** Map “Response envelopes” to the source component prerequisites (UC-M01.01); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M01.02-C021-T06 · Authority map:** Identify who may produce, change and consume “Response envelopes”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M01.02-C021-T07 · Invariant clause:** Add a normative clause for “Response envelopes” that preserves “A response does not equate acceptance with completed execution”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M01.02-C021-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Response envelopes”; include the source counterexample “A queued request returns a completed-success disposition” and the intended safe disposition.
- [ ] **UC-M01.02-C021-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Response bytes and retained diagnostic size” in the “Response envelopes” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M01.02-C021-T10 · Contract review:** Review the “Response envelopes” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M01.02-C022 · Delivery

**Original checklist item:** Define structured success, failure and asynchronous-operation responses.

- [ ] **UC-M01.02-C022-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Response envelopes”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M01.02-C022-T02 · Change plan:** Break the source delivery for “Response envelopes” into concrete edit targets and reviewable outputs; keep the UC-M01.02 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M01.02-C022-T03 · Core artifact:** Create the “Response envelopes” model, schema or inventory that realizes this source instruction: Define structured success, failure and asynchronous-operation responses.
- [ ] **UC-M01.02-C022-T04 · Concrete realization:** Populate “Response envelopes” with one concrete worked case; map every required entity or field to its source and flag any unmapped entry.
- [ ] **UC-M01.02-C022-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Response envelopes” needed to preserve “A response does not equate acceptance with completed execution”; record an enforcement gap where only a model exists.
- [ ] **UC-M01.02-C022-T06 · Dependency connection:** Connect the “Response envelopes” specification to CLI requests, backend adapters and guest ABI negotiation; record code coverage separately where the design is not yet enforced.
- [ ] **UC-M01.02-C022-T07 · Resource behavior:** Account for “Response bytes and retained diagnostic size” in “Response envelopes”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M01.02-C022-T08 · Delivery check:** Walk the populated “Response envelopes” model through a valid example and the source counterexample “A queued request returns a completed-success disposition”; record corrections and unresolved enforcement gaps.
- [ ] **UC-M01.02-C022-T09 · Patch review:** Review the “Response envelopes” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M01.02-C022-T10 · Delivery handoff:** Publish the “Response envelopes” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M01.02-C023 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: A response does not equate acceptance with completed execution. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M01.02-C023-T01 · Named property:** Create a stable property/check name under this parent for “Response envelopes”; copy its required invariant exactly: “A response does not equate acceptance with completed execution”.
- [ ] **UC-M01.02-C023-T02 · Observable terms:** Define each term in the “Response envelopes” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M01.02-C023-T03 · Precondition set:** List the preconditions under which “A response does not equate acceptance with completed execution” must hold for “Response envelopes”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M01.02-C023-T04 · Transition coverage:** Map the “Response envelopes” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M01.02-C023-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Response envelopes”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M01.02-C023-T06 · Satisfying fixture:** Create a concrete “Response envelopes” case that satisfies “A response does not equate acceptance with completed execution”; record its expected observation before running the assertion or review.
- [ ] **UC-M01.02-C023-T07 · Violating fixture:** Create the source counterexample “A queued request returns a completed-success disposition” for “Response envelopes”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M01.02-C023-T08 · Enforcement evidence:** Exercise the “Response envelopes” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M01.02-C023-T09 · Regression linkage:** Link the “Response envelopes” property to changes in CLI requests, backend adapters and guest ABI negotiation; record which dependency or contract changes require rerunning it.
- [ ] **UC-M01.02-C023-T10 · Property disposition:** Compare the satisfying and violating “Response envelopes” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M01.02-C024 · Integration

**Original checklist item:** Integrate response envelopes with CLI requests, backend adapters and guest ABI negotiation; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M01.02-C024-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Response envelopes” across CLI requests, backend adapters and guest ABI negotiation; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M01.02-C024-T02 · Field mapping:** Map every “Response envelopes” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M01.02-C024-T03 · Prerequisite identities:** Record the actual prerequisites for “Response envelopes” (source dependency list: UC-M01.01); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M01.02-C024-T04 · Ownership agreement:** Specify who owns “Response envelopes” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M01.02-C024-T05 · Handoff implementation:** Connect “Response envelopes” through the mapped seam using the real adapter or explicit specification reference; preserve “A response does not equate acceptance with completed execution” across the handoff.
- [ ] **UC-M01.02-C024-T06 · Absent-input case:** Omit one required “Response envelopes” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M01.02-C024-T07 · Stale-input case:** Supply an outdated “Response envelopes” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M01.02-C024-T08 · Incompatible-input case:** Supply an incompatible “Response envelopes” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M01.02-C024-T09 · Valid integration trace:** Run a valid “Response envelopes” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M01.02-C024-T10 · Seam review:** Reconcile the “Response envelopes” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M01.02-C025 · Valid-case test

**Original checklist item:** Construct a valid worked example for response envelopes; evaluate it against predeclared expected decisions and, where enforcement exists, run the corresponding conformance fixture.

- [ ] **UC-M01.02-C025-T01 · Valid fixture choice:** Select one concrete valid worked example for “Response envelopes”; enumerate the model inputs and the expected review decision before evaluating it.
- [ ] **UC-M01.02-C025-T02 · Expected-result oracle:** Specify the “Response envelopes” expected result independently of the implementation output; include the property “A response does not equate acceptance with completed execution” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M01.02-C025-T03 · Fixture material:** Create the concrete “Response envelopes” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M01.02-C025-T04 · Target preparation:** Prepare the “Response envelopes” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M01.02-C025-T05 · Initial-state record:** Record the initial “Response envelopes” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M01.02-C025-T06 · Valid-path execution:** Evaluate the “Response envelopes” example against the reviewed model; where a runtime mechanism exists, run its corresponding fixture and label those observations separately.
- [ ] **UC-M01.02-C025-T07 · Outcome comparison:** Compare every declared “Response envelopes” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M01.02-C025-T08 · State and bounds check:** Inspect the “Response envelopes” ownership/state effects and actual use of “Response bytes and retained diagnostic size”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M01.02-C025-T09 · Repeatability check:** Repeat the same “Response envelopes” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M01.02-C025-T10 · Positive evidence:** Attach the “Response envelopes” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M01.02-C026 · Negative test

**Original checklist item:** Negative case: A queued request returns a completed-success disposition. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M01.02-C026-T01 · Adverse-case definition:** Create a test record for the exact “Response envelopes” source counterexample: “A queued request returns a completed-success disposition”; state which precondition or invariant it challenges.
- [ ] **UC-M01.02-C026-T02 · Safe fixture boundary:** Define the contained test boundary for “Response envelopes”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M01.02-C026-T03 · Valid control:** Construct a valid “Response envelopes” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M01.02-C026-T04 · Minimal adverse input:** Derive the “Response envelopes” adverse fixture from the control with the smallest documented change needed to reproduce “A queued request returns a completed-success disposition”; retain that change as reproducible data.
- [ ] **UC-M01.02-C026-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Response envelopes”; require “A response does not equate acceptance with completed execution” and forbid a false-success verdict.
- [ ] **UC-M01.02-C026-T06 · Adverse execution:** Evaluate the “Response envelopes” adverse case through the actual review/contract gate; where implemented, also observe the runtime refusal and keep the two evidence classes separate.
- [ ] **UC-M01.02-C026-T07 · Effect inspection:** Inspect “Response envelopes” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M01.02-C026-T08 · Refusal versus failure:** Confirm the “Response envelopes” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M01.02-C026-T09 · Reset and retention:** Restore only the disposable “Response envelopes” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M01.02-C026-T10 · Negative regression:** Register the “Response envelopes” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M01.02-C027 · Change / failure test

**Original checklist item:** Exercise response envelopes when a client and backend advertise different contract versions; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M01.02-C027-T01 · Scenario record:** Write the “Response envelopes” change/failure scenario exactly as supplied: a client and backend advertise different contract versions; identify the property that must remain true: “A response does not equate acceptance with completed execution”.
- [ ] **UC-M01.02-C027-T02 · Baseline capture:** Create a known-valid “Response envelopes” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M01.02-C027-T03 · Injection map:** Locate the “Response envelopes” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M01.02-C027-T04 · Disposition oracle:** Define the legal intermediate and final “Response envelopes” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M01.02-C027-T05 · Controlled trigger:** Apply the controlled model-change scenario for “Response envelopes”: a client and backend advertise different contract versions; retain the exact before/after declarations. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M01.02-C027-T06 · Intermediate inspection:** Review which “Response envelopes” claims, approvals and evidence references become stale after the change; keep unresolved enforcement gaps visible.
- [ ] **UC-M01.02-C027-T07 · Recovery path:** Revise or explicitly refuse the changed “Response envelopes” model under the documented compatibility policy; re-review affected claims before restoring their approval.
- [ ] **UC-M01.02-C027-T08 · Stale-evidence cleanup:** Invalidate superseded “Response envelopes” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M01.02-C027-T09 · Repeat and compare:** Repeat the selected “Response envelopes” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M01.02-C027-T10 · Failure evidence:** Publish the “Response envelopes” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M01.02-C028 · Bounds

**Original checklist item:** Define completeness and scaling criteria for response bytes and retained diagnostic size; exercise larger inventories or fixture sets, and report uncovered scope instead of silently excluding it.

- [ ] **UC-M01.02-C028-T01 · Quantity inventory:** Create a measurement inventory for “Response envelopes”: “Response bytes and retained diagnostic size”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M01.02-C028-T02 · Measurement method:** Choose how to observe each “Response envelopes” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M01.02-C028-T03 · Budget decision:** Select justified coverage and completeness limits for “Response envelopes”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M01.02-C028-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Response envelopes” cases for “Response bytes and retained diagnostic size”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M01.02-C028-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Response envelopes” limit; preserve “A response does not equate acceptance with completed execution”.
- [ ] **UC-M01.02-C028-T06 · Normal measurement:** Run or review the normal “Response envelopes” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M01.02-C028-T07 · At-limit measurement:** Exercise the “Response envelopes” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M01.02-C028-T08 · Over-limit measurement:** Exercise the “Response envelopes” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M01.02-C028-T09 · Uncovered-scope report:** List the “Response envelopes” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M01.02-C028-T10 · Limit evidence:** Publish the selected “Response envelopes” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M01.02-C029 · Diagnostics / review

**Original checklist item:** Record the rationale, unresolved assumptions, enforcement gaps and re-review triggers for response envelopes; make design-only claims visibly distinct from observed behavior.

- [ ] **UC-M01.02-C029-T01 · Review inventory:** List the “Response envelopes” decisions and claims requiring review; distinguish source requirements, implementation observations and engineering assumptions.
- [ ] **UC-M01.02-C029-T02 · Rationale record:** Write the rationale for the selected “Response envelopes” representation or policy; link each choice to the requirement rather than an unexplained preference.
- [ ] **UC-M01.02-C029-T03 · Assumption ledger:** Record unresolved “Response envelopes” assumptions, their owner and what observation or decision would resolve them; do not treat unknowns as approvals.
- [ ] **UC-M01.02-C029-T04 · Boundary map:** Map each “Response envelopes” claim to an actual guard or explicit design/review gate; flag gaps against “A response does not equate acceptance with completed execution”.
- [ ] **UC-M01.02-C029-T05 · Counterexample review:** Walk reviewers through the “Response envelopes” counterexample “A queued request returns a completed-success disposition”; record whether the model detects it and whether any runtime guard was actually exercised.
- [ ] **UC-M01.02-C029-T06 · Review outcome vocabulary:** Define approved, blocked, superseded and untested review outcomes for “Response envelopes”; ensure the wording cannot be read as runtime enforcement evidence.
- [ ] **UC-M01.02-C029-T07 · Re-review triggers:** List “Response envelopes” invalidation triggers, including the source change scenario: a client and backend advertise different contract versions; identify the affected claims and evidence.
- [ ] **UC-M01.02-C029-T08 · Sensitive-data review:** Inspect the “Response envelopes” review record for secrets and unrelated user content; retain nonsecret references sufficient for reproducibility.
- [ ] **UC-M01.02-C029-T09 · Independent reading:** Have the “Response envelopes” record read against the original acceptance criterion and CLI requests, backend adapters and guest ABI negotiation; record misunderstandings or missing evidence as corrections.
- [ ] **UC-M01.02-C029-T10 · Review disposition:** Publish the “Response envelopes” rationale, versioned review outcome, unresolved gaps and explicit next decision; keep blockers open until supported evidence resolves them.

### UC-M01.02-C030 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for response envelopes; label unexecuted checks as untested.

- [ ] **UC-M01.02-C030-T01 · Evidence inventory:** List the “Response envelopes” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M01.02-C030-T02 · Artifact references:** Record the exact “Response envelopes” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M01.02-C030-T03 · Fixture references:** Attach the “Response envelopes” fixture IDs, input identities and oracle definition; preserve the source counterexample “A queued request returns a completed-success disposition” as a distinct evidence case.
- [ ] **UC-M01.02-C030-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Response envelopes”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M01.02-C030-T05 · Environment record:** Record the actual “Response envelopes” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M01.02-C030-T06 · Expected versus observed:** Pair every “Response envelopes” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M01.02-C030-T07 · Failure and limit records:** Attach “Response envelopes” change/failure and bounds evidence where required; include uncovered “Response bytes and retained diagnostic size” and unresolved violations of “A response does not equate acceptance with completed execution”.
- [ ] **UC-M01.02-C030-T08 · Evidence hygiene:** Check the “Response envelopes” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M01.02-C030-T09 · Reproduction review:** Have the “Response envelopes” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M01.02-C030-T10 · Acceptance linkage:** Link the “Response envelopes” evidence to its parent and UC-M01.02 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 04. Error taxonomy

**Source delivery:** Assign stable error codes and retryability to contract failures.

**Source invariant:** Machine callers need not parse human prose for the outcome.

**Source negative case:** An unsupported operation returns a generic success code.

**Source bounded quantities:** Error vocabulary and nested cause depth.

### UC-M01.02-C031 · Contract

**Original checklist item:** Specify the scope and representation of error taxonomy; identify its producer, consumer, authority assumptions and explicitly unsupported cases.

- [ ] **UC-M01.02-C031-T01 · Scope statement:** Draft a scope note for “Error taxonomy” within Versioned runtime and guest contracts; separate required model statements, explicit exclusions and unresolved design decisions.
- [ ] **UC-M01.02-C031-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Error taxonomy”; record each producer, representation and missing-value meaning.
- [ ] **UC-M01.02-C031-T03 · Output inventory:** List the outputs of “Error taxonomy” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M01.02-C031-T04 · Field dictionary:** Create a field-and-term dictionary for “Error taxonomy”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M01.02-C031-T05 · Prerequisite contract:** Map “Error taxonomy” to the source component prerequisites (UC-M01.01); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M01.02-C031-T06 · Authority map:** Identify who may produce, change and consume “Error taxonomy”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M01.02-C031-T07 · Invariant clause:** Add a normative clause for “Error taxonomy” that preserves “Machine callers need not parse human prose for the outcome”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M01.02-C031-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Error taxonomy”; include the source counterexample “An unsupported operation returns a generic success code” and the intended safe disposition.
- [ ] **UC-M01.02-C031-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Error vocabulary and nested cause depth” in the “Error taxonomy” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M01.02-C031-T10 · Contract review:** Review the “Error taxonomy” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M01.02-C032 · Delivery

**Original checklist item:** Assign stable error codes and retryability to contract failures.

- [ ] **UC-M01.02-C032-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Error taxonomy”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M01.02-C032-T02 · Change plan:** Break the source delivery for “Error taxonomy” into concrete edit targets and reviewable outputs; keep the UC-M01.02 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M01.02-C032-T03 · Core artifact:** Implement the smallest selected-profile change for “Error taxonomy” that realizes this source instruction: Assign stable error codes and retryability to contract failures.
- [ ] **UC-M01.02-C032-T04 · Concrete realization:** Trace “Error taxonomy” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M01.02-C032-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Error taxonomy” needed to preserve “Machine callers need not parse human prose for the outcome”; record an enforcement gap where only a model exists.
- [ ] **UC-M01.02-C032-T06 · Dependency connection:** Connect the “Error taxonomy” specification to CLI requests, backend adapters and guest ABI negotiation; record code coverage separately where the design is not yet enforced.
- [ ] **UC-M01.02-C032-T07 · Resource behavior:** Account for “Error vocabulary and nested cause depth” in “Error taxonomy”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M01.02-C032-T08 · Delivery check:** Walk the populated “Error taxonomy” model through a valid example and the source counterexample “An unsupported operation returns a generic success code”; record corrections and unresolved enforcement gaps.
- [ ] **UC-M01.02-C032-T09 · Patch review:** Review the “Error taxonomy” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M01.02-C032-T10 · Delivery handoff:** Publish the “Error taxonomy” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M01.02-C033 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Machine callers need not parse human prose for the outcome. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M01.02-C033-T01 · Named property:** Create a stable property/check name under this parent for “Error taxonomy”; copy its required invariant exactly: “Machine callers need not parse human prose for the outcome”.
- [ ] **UC-M01.02-C033-T02 · Observable terms:** Define each term in the “Error taxonomy” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M01.02-C033-T03 · Precondition set:** List the preconditions under which “Machine callers need not parse human prose for the outcome” must hold for “Error taxonomy”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M01.02-C033-T04 · Transition coverage:** Map the “Error taxonomy” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M01.02-C033-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Error taxonomy”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M01.02-C033-T06 · Satisfying fixture:** Create a concrete “Error taxonomy” case that satisfies “Machine callers need not parse human prose for the outcome”; record its expected observation before running the assertion or review.
- [ ] **UC-M01.02-C033-T07 · Violating fixture:** Create the source counterexample “An unsupported operation returns a generic success code” for “Error taxonomy”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M01.02-C033-T08 · Enforcement evidence:** Exercise the “Error taxonomy” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M01.02-C033-T09 · Regression linkage:** Link the “Error taxonomy” property to changes in CLI requests, backend adapters and guest ABI negotiation; record which dependency or contract changes require rerunning it.
- [ ] **UC-M01.02-C033-T10 · Property disposition:** Compare the satisfying and violating “Error taxonomy” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M01.02-C034 · Integration

**Original checklist item:** Integrate error taxonomy with CLI requests, backend adapters and guest ABI negotiation; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M01.02-C034-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Error taxonomy” across CLI requests, backend adapters and guest ABI negotiation; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M01.02-C034-T02 · Field mapping:** Map every “Error taxonomy” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M01.02-C034-T03 · Prerequisite identities:** Record the actual prerequisites for “Error taxonomy” (source dependency list: UC-M01.01); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M01.02-C034-T04 · Ownership agreement:** Specify who owns “Error taxonomy” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M01.02-C034-T05 · Handoff implementation:** Connect “Error taxonomy” through the mapped seam using the real adapter or explicit specification reference; preserve “Machine callers need not parse human prose for the outcome” across the handoff.
- [ ] **UC-M01.02-C034-T06 · Absent-input case:** Omit one required “Error taxonomy” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M01.02-C034-T07 · Stale-input case:** Supply an outdated “Error taxonomy” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M01.02-C034-T08 · Incompatible-input case:** Supply an incompatible “Error taxonomy” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M01.02-C034-T09 · Valid integration trace:** Run a valid “Error taxonomy” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M01.02-C034-T10 · Seam review:** Reconcile the “Error taxonomy” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M01.02-C035 · Valid-case test

**Original checklist item:** Construct a valid worked example for error taxonomy; evaluate it against predeclared expected decisions and, where enforcement exists, run the corresponding conformance fixture.

- [ ] **UC-M01.02-C035-T01 · Valid fixture choice:** Select one concrete valid worked example for “Error taxonomy”; enumerate the model inputs and the expected review decision before evaluating it.
- [ ] **UC-M01.02-C035-T02 · Expected-result oracle:** Specify the “Error taxonomy” expected result independently of the implementation output; include the property “Machine callers need not parse human prose for the outcome” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M01.02-C035-T03 · Fixture material:** Create the concrete “Error taxonomy” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M01.02-C035-T04 · Target preparation:** Prepare the “Error taxonomy” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M01.02-C035-T05 · Initial-state record:** Record the initial “Error taxonomy” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M01.02-C035-T06 · Valid-path execution:** Evaluate the “Error taxonomy” example against the reviewed model; where a runtime mechanism exists, run its corresponding fixture and label those observations separately.
- [ ] **UC-M01.02-C035-T07 · Outcome comparison:** Compare every declared “Error taxonomy” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M01.02-C035-T08 · State and bounds check:** Inspect the “Error taxonomy” ownership/state effects and actual use of “Error vocabulary and nested cause depth”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M01.02-C035-T09 · Repeatability check:** Repeat the same “Error taxonomy” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M01.02-C035-T10 · Positive evidence:** Attach the “Error taxonomy” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M01.02-C036 · Negative test

**Original checklist item:** Negative case: An unsupported operation returns a generic success code. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M01.02-C036-T01 · Adverse-case definition:** Create a test record for the exact “Error taxonomy” source counterexample: “An unsupported operation returns a generic success code”; state which precondition or invariant it challenges.
- [ ] **UC-M01.02-C036-T02 · Safe fixture boundary:** Define the contained test boundary for “Error taxonomy”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M01.02-C036-T03 · Valid control:** Construct a valid “Error taxonomy” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M01.02-C036-T04 · Minimal adverse input:** Derive the “Error taxonomy” adverse fixture from the control with the smallest documented change needed to reproduce “An unsupported operation returns a generic success code”; retain that change as reproducible data.
- [ ] **UC-M01.02-C036-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Error taxonomy”; require “Machine callers need not parse human prose for the outcome” and forbid a false-success verdict.
- [ ] **UC-M01.02-C036-T06 · Adverse execution:** Evaluate the “Error taxonomy” adverse case through the actual review/contract gate; where implemented, also observe the runtime refusal and keep the two evidence classes separate.
- [ ] **UC-M01.02-C036-T07 · Effect inspection:** Inspect “Error taxonomy” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M01.02-C036-T08 · Refusal versus failure:** Confirm the “Error taxonomy” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M01.02-C036-T09 · Reset and retention:** Restore only the disposable “Error taxonomy” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M01.02-C036-T10 · Negative regression:** Register the “Error taxonomy” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M01.02-C037 · Change / failure test

**Original checklist item:** Exercise error taxonomy when a client and backend advertise different contract versions; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M01.02-C037-T01 · Scenario record:** Write the “Error taxonomy” change/failure scenario exactly as supplied: a client and backend advertise different contract versions; identify the property that must remain true: “Machine callers need not parse human prose for the outcome”.
- [ ] **UC-M01.02-C037-T02 · Baseline capture:** Create a known-valid “Error taxonomy” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M01.02-C037-T03 · Injection map:** Locate the “Error taxonomy” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M01.02-C037-T04 · Disposition oracle:** Define the legal intermediate and final “Error taxonomy” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M01.02-C037-T05 · Controlled trigger:** Apply the controlled model-change scenario for “Error taxonomy”: a client and backend advertise different contract versions; retain the exact before/after declarations. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M01.02-C037-T06 · Intermediate inspection:** Review which “Error taxonomy” claims, approvals and evidence references become stale after the change; keep unresolved enforcement gaps visible.
- [ ] **UC-M01.02-C037-T07 · Recovery path:** Revise or explicitly refuse the changed “Error taxonomy” model under the documented compatibility policy; re-review affected claims before restoring their approval.
- [ ] **UC-M01.02-C037-T08 · Stale-evidence cleanup:** Invalidate superseded “Error taxonomy” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M01.02-C037-T09 · Repeat and compare:** Repeat the selected “Error taxonomy” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M01.02-C037-T10 · Failure evidence:** Publish the “Error taxonomy” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M01.02-C038 · Bounds

**Original checklist item:** Define completeness and scaling criteria for error vocabulary and nested cause depth; exercise larger inventories or fixture sets, and report uncovered scope instead of silently excluding it.

- [ ] **UC-M01.02-C038-T01 · Quantity inventory:** Create a measurement inventory for “Error taxonomy”: “Error vocabulary and nested cause depth”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M01.02-C038-T02 · Measurement method:** Choose how to observe each “Error taxonomy” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M01.02-C038-T03 · Budget decision:** Select justified coverage and completeness limits for “Error taxonomy”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M01.02-C038-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Error taxonomy” cases for “Error vocabulary and nested cause depth”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M01.02-C038-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Error taxonomy” limit; preserve “Machine callers need not parse human prose for the outcome”.
- [ ] **UC-M01.02-C038-T06 · Normal measurement:** Run or review the normal “Error taxonomy” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M01.02-C038-T07 · At-limit measurement:** Exercise the “Error taxonomy” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M01.02-C038-T08 · Over-limit measurement:** Exercise the “Error taxonomy” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M01.02-C038-T09 · Uncovered-scope report:** List the “Error taxonomy” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M01.02-C038-T10 · Limit evidence:** Publish the selected “Error taxonomy” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M01.02-C039 · Diagnostics / review

**Original checklist item:** Record the rationale, unresolved assumptions, enforcement gaps and re-review triggers for error taxonomy; make design-only claims visibly distinct from observed behavior.

- [ ] **UC-M01.02-C039-T01 · Review inventory:** List the “Error taxonomy” decisions and claims requiring review; distinguish source requirements, implementation observations and engineering assumptions.
- [ ] **UC-M01.02-C039-T02 · Rationale record:** Write the rationale for the selected “Error taxonomy” representation or policy; link each choice to the requirement rather than an unexplained preference.
- [ ] **UC-M01.02-C039-T03 · Assumption ledger:** Record unresolved “Error taxonomy” assumptions, their owner and what observation or decision would resolve them; do not treat unknowns as approvals.
- [ ] **UC-M01.02-C039-T04 · Boundary map:** Map each “Error taxonomy” claim to an actual guard or explicit design/review gate; flag gaps against “Machine callers need not parse human prose for the outcome”.
- [ ] **UC-M01.02-C039-T05 · Counterexample review:** Walk reviewers through the “Error taxonomy” counterexample “An unsupported operation returns a generic success code”; record whether the model detects it and whether any runtime guard was actually exercised.
- [ ] **UC-M01.02-C039-T06 · Review outcome vocabulary:** Define approved, blocked, superseded and untested review outcomes for “Error taxonomy”; ensure the wording cannot be read as runtime enforcement evidence.
- [ ] **UC-M01.02-C039-T07 · Re-review triggers:** List “Error taxonomy” invalidation triggers, including the source change scenario: a client and backend advertise different contract versions; identify the affected claims and evidence.
- [ ] **UC-M01.02-C039-T08 · Sensitive-data review:** Inspect the “Error taxonomy” review record for secrets and unrelated user content; retain nonsecret references sufficient for reproducibility.
- [ ] **UC-M01.02-C039-T09 · Independent reading:** Have the “Error taxonomy” record read against the original acceptance criterion and CLI requests, backend adapters and guest ABI negotiation; record misunderstandings or missing evidence as corrections.
- [ ] **UC-M01.02-C039-T10 · Review disposition:** Publish the “Error taxonomy” rationale, versioned review outcome, unresolved gaps and explicit next decision; keep blockers open until supported evidence resolves them.

### UC-M01.02-C040 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for error taxonomy; label unexecuted checks as untested.

- [ ] **UC-M01.02-C040-T01 · Evidence inventory:** List the “Error taxonomy” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M01.02-C040-T02 · Artifact references:** Record the exact “Error taxonomy” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M01.02-C040-T03 · Fixture references:** Attach the “Error taxonomy” fixture IDs, input identities and oracle definition; preserve the source counterexample “An unsupported operation returns a generic success code” as a distinct evidence case.
- [ ] **UC-M01.02-C040-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Error taxonomy”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M01.02-C040-T05 · Environment record:** Record the actual “Error taxonomy” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M01.02-C040-T06 · Expected versus observed:** Pair every “Error taxonomy” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M01.02-C040-T07 · Failure and limit records:** Attach “Error taxonomy” change/failure and bounds evidence where required; include uncovered “Error vocabulary and nested cause depth” and unresolved violations of “Machine callers need not parse human prose for the outcome”.
- [ ] **UC-M01.02-C040-T08 · Evidence hygiene:** Check the “Error taxonomy” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M01.02-C040-T09 · Reproduction review:** Have the “Error taxonomy” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M01.02-C040-T10 · Acceptance linkage:** Link the “Error taxonomy” evidence to its parent and UC-M01.02 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 05. Version negotiation

**Source delivery:** Define compatible version ranges and explicit negotiation failure.

**Source invariant:** Unknown incompatible versions cannot reach executable actions.

**Source negative case:** A future major version is accepted with current defaults.

**Source bounded quantities:** Supported versions and negotiation round trips.

### UC-M01.02-C041 · Contract

**Original checklist item:** Specify the scope and representation of version negotiation; identify its producer, consumer, authority assumptions and explicitly unsupported cases.

- [ ] **UC-M01.02-C041-T01 · Scope statement:** Draft a scope note for “Version negotiation” within Versioned runtime and guest contracts; separate required model statements, explicit exclusions and unresolved design decisions.
- [ ] **UC-M01.02-C041-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Version negotiation”; record each producer, representation and missing-value meaning.
- [ ] **UC-M01.02-C041-T03 · Output inventory:** List the outputs of “Version negotiation” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M01.02-C041-T04 · Field dictionary:** Create a field-and-term dictionary for “Version negotiation”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M01.02-C041-T05 · Prerequisite contract:** Map “Version negotiation” to the source component prerequisites (UC-M01.01); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M01.02-C041-T06 · Authority map:** Identify who may produce, change and consume “Version negotiation”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M01.02-C041-T07 · Invariant clause:** Add a normative clause for “Version negotiation” that preserves “Unknown incompatible versions cannot reach executable actions”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M01.02-C041-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Version negotiation”; include the source counterexample “A future major version is accepted with current defaults” and the intended safe disposition.
- [ ] **UC-M01.02-C041-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Supported versions and negotiation round trips” in the “Version negotiation” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M01.02-C041-T10 · Contract review:** Review the “Version negotiation” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M01.02-C042 · Delivery

**Original checklist item:** Define compatible version ranges and explicit negotiation failure.

- [ ] **UC-M01.02-C042-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Version negotiation”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M01.02-C042-T02 · Change plan:** Break the source delivery for “Version negotiation” into concrete edit targets and reviewable outputs; keep the UC-M01.02 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M01.02-C042-T03 · Core artifact:** Create the “Version negotiation” model, schema or inventory that realizes this source instruction: Define compatible version ranges and explicit negotiation failure.
- [ ] **UC-M01.02-C042-T04 · Concrete realization:** Populate “Version negotiation” with one concrete worked case; map every required entity or field to its source and flag any unmapped entry.
- [ ] **UC-M01.02-C042-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Version negotiation” needed to preserve “Unknown incompatible versions cannot reach executable actions”; record an enforcement gap where only a model exists.
- [ ] **UC-M01.02-C042-T06 · Dependency connection:** Connect the “Version negotiation” specification to CLI requests, backend adapters and guest ABI negotiation; record code coverage separately where the design is not yet enforced.
- [ ] **UC-M01.02-C042-T07 · Resource behavior:** Account for “Supported versions and negotiation round trips” in “Version negotiation”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M01.02-C042-T08 · Delivery check:** Walk the populated “Version negotiation” model through a valid example and the source counterexample “A future major version is accepted with current defaults”; record corrections and unresolved enforcement gaps.
- [ ] **UC-M01.02-C042-T09 · Patch review:** Review the “Version negotiation” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M01.02-C042-T10 · Delivery handoff:** Publish the “Version negotiation” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M01.02-C043 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Unknown incompatible versions cannot reach executable actions. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M01.02-C043-T01 · Named property:** Create a stable property/check name under this parent for “Version negotiation”; copy its required invariant exactly: “Unknown incompatible versions cannot reach executable actions”.
- [ ] **UC-M01.02-C043-T02 · Observable terms:** Define each term in the “Version negotiation” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M01.02-C043-T03 · Precondition set:** List the preconditions under which “Unknown incompatible versions cannot reach executable actions” must hold for “Version negotiation”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M01.02-C043-T04 · Transition coverage:** Map the “Version negotiation” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M01.02-C043-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Version negotiation”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M01.02-C043-T06 · Satisfying fixture:** Create a concrete “Version negotiation” case that satisfies “Unknown incompatible versions cannot reach executable actions”; record its expected observation before running the assertion or review.
- [ ] **UC-M01.02-C043-T07 · Violating fixture:** Create the source counterexample “A future major version is accepted with current defaults” for “Version negotiation”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M01.02-C043-T08 · Enforcement evidence:** Exercise the “Version negotiation” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M01.02-C043-T09 · Regression linkage:** Link the “Version negotiation” property to changes in CLI requests, backend adapters and guest ABI negotiation; record which dependency or contract changes require rerunning it.
- [ ] **UC-M01.02-C043-T10 · Property disposition:** Compare the satisfying and violating “Version negotiation” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M01.02-C044 · Integration

**Original checklist item:** Integrate version negotiation with CLI requests, backend adapters and guest ABI negotiation; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M01.02-C044-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Version negotiation” across CLI requests, backend adapters and guest ABI negotiation; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M01.02-C044-T02 · Field mapping:** Map every “Version negotiation” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M01.02-C044-T03 · Prerequisite identities:** Record the actual prerequisites for “Version negotiation” (source dependency list: UC-M01.01); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M01.02-C044-T04 · Ownership agreement:** Specify who owns “Version negotiation” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M01.02-C044-T05 · Handoff implementation:** Connect “Version negotiation” through the mapped seam using the real adapter or explicit specification reference; preserve “Unknown incompatible versions cannot reach executable actions” across the handoff.
- [ ] **UC-M01.02-C044-T06 · Absent-input case:** Omit one required “Version negotiation” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M01.02-C044-T07 · Stale-input case:** Supply an outdated “Version negotiation” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M01.02-C044-T08 · Incompatible-input case:** Supply an incompatible “Version negotiation” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M01.02-C044-T09 · Valid integration trace:** Run a valid “Version negotiation” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M01.02-C044-T10 · Seam review:** Reconcile the “Version negotiation” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M01.02-C045 · Valid-case test

**Original checklist item:** Construct a valid worked example for version negotiation; evaluate it against predeclared expected decisions and, where enforcement exists, run the corresponding conformance fixture.

- [ ] **UC-M01.02-C045-T01 · Valid fixture choice:** Select one concrete valid worked example for “Version negotiation”; enumerate the model inputs and the expected review decision before evaluating it.
- [ ] **UC-M01.02-C045-T02 · Expected-result oracle:** Specify the “Version negotiation” expected result independently of the implementation output; include the property “Unknown incompatible versions cannot reach executable actions” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M01.02-C045-T03 · Fixture material:** Create the concrete “Version negotiation” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M01.02-C045-T04 · Target preparation:** Prepare the “Version negotiation” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M01.02-C045-T05 · Initial-state record:** Record the initial “Version negotiation” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M01.02-C045-T06 · Valid-path execution:** Evaluate the “Version negotiation” example against the reviewed model; where a runtime mechanism exists, run its corresponding fixture and label those observations separately.
- [ ] **UC-M01.02-C045-T07 · Outcome comparison:** Compare every declared “Version negotiation” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M01.02-C045-T08 · State and bounds check:** Inspect the “Version negotiation” ownership/state effects and actual use of “Supported versions and negotiation round trips”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M01.02-C045-T09 · Repeatability check:** Repeat the same “Version negotiation” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M01.02-C045-T10 · Positive evidence:** Attach the “Version negotiation” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M01.02-C046 · Negative test

**Original checklist item:** Negative case: A future major version is accepted with current defaults. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M01.02-C046-T01 · Adverse-case definition:** Create a test record for the exact “Version negotiation” source counterexample: “A future major version is accepted with current defaults”; state which precondition or invariant it challenges.
- [ ] **UC-M01.02-C046-T02 · Safe fixture boundary:** Define the contained test boundary for “Version negotiation”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M01.02-C046-T03 · Valid control:** Construct a valid “Version negotiation” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M01.02-C046-T04 · Minimal adverse input:** Derive the “Version negotiation” adverse fixture from the control with the smallest documented change needed to reproduce “A future major version is accepted with current defaults”; retain that change as reproducible data.
- [ ] **UC-M01.02-C046-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Version negotiation”; require “Unknown incompatible versions cannot reach executable actions” and forbid a false-success verdict.
- [ ] **UC-M01.02-C046-T06 · Adverse execution:** Evaluate the “Version negotiation” adverse case through the actual review/contract gate; where implemented, also observe the runtime refusal and keep the two evidence classes separate.
- [ ] **UC-M01.02-C046-T07 · Effect inspection:** Inspect “Version negotiation” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M01.02-C046-T08 · Refusal versus failure:** Confirm the “Version negotiation” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M01.02-C046-T09 · Reset and retention:** Restore only the disposable “Version negotiation” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M01.02-C046-T10 · Negative regression:** Register the “Version negotiation” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M01.02-C047 · Change / failure test

**Original checklist item:** Exercise version negotiation when a client and backend advertise different contract versions; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M01.02-C047-T01 · Scenario record:** Write the “Version negotiation” change/failure scenario exactly as supplied: a client and backend advertise different contract versions; identify the property that must remain true: “Unknown incompatible versions cannot reach executable actions”.
- [ ] **UC-M01.02-C047-T02 · Baseline capture:** Create a known-valid “Version negotiation” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M01.02-C047-T03 · Injection map:** Locate the “Version negotiation” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M01.02-C047-T04 · Disposition oracle:** Define the legal intermediate and final “Version negotiation” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M01.02-C047-T05 · Controlled trigger:** Apply the controlled model-change scenario for “Version negotiation”: a client and backend advertise different contract versions; retain the exact before/after declarations. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M01.02-C047-T06 · Intermediate inspection:** Review which “Version negotiation” claims, approvals and evidence references become stale after the change; keep unresolved enforcement gaps visible.
- [ ] **UC-M01.02-C047-T07 · Recovery path:** Revise or explicitly refuse the changed “Version negotiation” model under the documented compatibility policy; re-review affected claims before restoring their approval.
- [ ] **UC-M01.02-C047-T08 · Stale-evidence cleanup:** Invalidate superseded “Version negotiation” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M01.02-C047-T09 · Repeat and compare:** Repeat the selected “Version negotiation” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M01.02-C047-T10 · Failure evidence:** Publish the “Version negotiation” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M01.02-C048 · Bounds

**Original checklist item:** Define completeness and scaling criteria for supported versions and negotiation round trips; exercise larger inventories or fixture sets, and report uncovered scope instead of silently excluding it.

- [ ] **UC-M01.02-C048-T01 · Quantity inventory:** Create a measurement inventory for “Version negotiation”: “Supported versions and negotiation round trips”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M01.02-C048-T02 · Measurement method:** Choose how to observe each “Version negotiation” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M01.02-C048-T03 · Budget decision:** Select justified coverage and completeness limits for “Version negotiation”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M01.02-C048-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Version negotiation” cases for “Supported versions and negotiation round trips”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M01.02-C048-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Version negotiation” limit; preserve “Unknown incompatible versions cannot reach executable actions”.
- [ ] **UC-M01.02-C048-T06 · Normal measurement:** Run or review the normal “Version negotiation” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M01.02-C048-T07 · At-limit measurement:** Exercise the “Version negotiation” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M01.02-C048-T08 · Over-limit measurement:** Exercise the “Version negotiation” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M01.02-C048-T09 · Uncovered-scope report:** List the “Version negotiation” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M01.02-C048-T10 · Limit evidence:** Publish the selected “Version negotiation” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M01.02-C049 · Diagnostics / review

**Original checklist item:** Record the rationale, unresolved assumptions, enforcement gaps and re-review triggers for version negotiation; make design-only claims visibly distinct from observed behavior.

- [ ] **UC-M01.02-C049-T01 · Review inventory:** List the “Version negotiation” decisions and claims requiring review; distinguish source requirements, implementation observations and engineering assumptions.
- [ ] **UC-M01.02-C049-T02 · Rationale record:** Write the rationale for the selected “Version negotiation” representation or policy; link each choice to the requirement rather than an unexplained preference.
- [ ] **UC-M01.02-C049-T03 · Assumption ledger:** Record unresolved “Version negotiation” assumptions, their owner and what observation or decision would resolve them; do not treat unknowns as approvals.
- [ ] **UC-M01.02-C049-T04 · Boundary map:** Map each “Version negotiation” claim to an actual guard or explicit design/review gate; flag gaps against “Unknown incompatible versions cannot reach executable actions”.
- [ ] **UC-M01.02-C049-T05 · Counterexample review:** Walk reviewers through the “Version negotiation” counterexample “A future major version is accepted with current defaults”; record whether the model detects it and whether any runtime guard was actually exercised.
- [ ] **UC-M01.02-C049-T06 · Review outcome vocabulary:** Define approved, blocked, superseded and untested review outcomes for “Version negotiation”; ensure the wording cannot be read as runtime enforcement evidence.
- [ ] **UC-M01.02-C049-T07 · Re-review triggers:** List “Version negotiation” invalidation triggers, including the source change scenario: a client and backend advertise different contract versions; identify the affected claims and evidence.
- [ ] **UC-M01.02-C049-T08 · Sensitive-data review:** Inspect the “Version negotiation” review record for secrets and unrelated user content; retain nonsecret references sufficient for reproducibility.
- [ ] **UC-M01.02-C049-T09 · Independent reading:** Have the “Version negotiation” record read against the original acceptance criterion and CLI requests, backend adapters and guest ABI negotiation; record misunderstandings or missing evidence as corrections.
- [ ] **UC-M01.02-C049-T10 · Review disposition:** Publish the “Version negotiation” rationale, versioned review outcome, unresolved gaps and explicit next decision; keep blockers open until supported evidence resolves them.

### UC-M01.02-C050 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for version negotiation; label unexecuted checks as untested.

- [ ] **UC-M01.02-C050-T01 · Evidence inventory:** List the “Version negotiation” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M01.02-C050-T02 · Artifact references:** Record the exact “Version negotiation” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M01.02-C050-T03 · Fixture references:** Attach the “Version negotiation” fixture IDs, input identities and oracle definition; preserve the source counterexample “A future major version is accepted with current defaults” as a distinct evidence case.
- [ ] **UC-M01.02-C050-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Version negotiation”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M01.02-C050-T05 · Environment record:** Record the actual “Version negotiation” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M01.02-C050-T06 · Expected versus observed:** Pair every “Version negotiation” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M01.02-C050-T07 · Failure and limit records:** Attach “Version negotiation” change/failure and bounds evidence where required; include uncovered “Supported versions and negotiation round trips” and unresolved violations of “Unknown incompatible versions cannot reach executable actions”.
- [ ] **UC-M01.02-C050-T08 · Evidence hygiene:** Check the “Version negotiation” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M01.02-C050-T09 · Reproduction review:** Have the “Version negotiation” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M01.02-C050-T10 · Acceptance linkage:** Link the “Version negotiation” evidence to its parent and UC-M01.02 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 06. Extension handling

**Source delivery:** Separate permitted extensions from unknown security-sensitive fields.

**Source invariant:** Ignoring an extension cannot weaken isolation or authority.

**Source negative case:** An unknown field attempts to disable signature admission.

**Source bounded quantities:** Extension bytes, extension count and lookup cost.

### UC-M01.02-C051 · Contract

**Original checklist item:** Specify the scope and representation of extension handling; identify its producer, consumer, authority assumptions and explicitly unsupported cases.

- [ ] **UC-M01.02-C051-T01 · Scope statement:** Draft a scope note for “Extension handling” within Versioned runtime and guest contracts; separate required model statements, explicit exclusions and unresolved design decisions.
- [ ] **UC-M01.02-C051-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Extension handling”; record each producer, representation and missing-value meaning.
- [ ] **UC-M01.02-C051-T03 · Output inventory:** List the outputs of “Extension handling” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M01.02-C051-T04 · Field dictionary:** Create a field-and-term dictionary for “Extension handling”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M01.02-C051-T05 · Prerequisite contract:** Map “Extension handling” to the source component prerequisites (UC-M01.01); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M01.02-C051-T06 · Authority map:** Identify who may produce, change and consume “Extension handling”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M01.02-C051-T07 · Invariant clause:** Add a normative clause for “Extension handling” that preserves “Ignoring an extension cannot weaken isolation or authority”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M01.02-C051-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Extension handling”; include the source counterexample “An unknown field attempts to disable signature admission” and the intended safe disposition.
- [ ] **UC-M01.02-C051-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Extension bytes, extension count and lookup cost” in the “Extension handling” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M01.02-C051-T10 · Contract review:** Review the “Extension handling” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M01.02-C052 · Delivery

**Original checklist item:** Separate permitted extensions from unknown security-sensitive fields.

- [ ] **UC-M01.02-C052-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Extension handling”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M01.02-C052-T02 · Change plan:** Break the source delivery for “Extension handling” into concrete edit targets and reviewable outputs; keep the UC-M01.02 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M01.02-C052-T03 · Core artifact:** Implement the smallest selected-profile change for “Extension handling” that realizes this source instruction: Separate permitted extensions from unknown security-sensitive fields.
- [ ] **UC-M01.02-C052-T04 · Concrete realization:** Trace “Extension handling” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M01.02-C052-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Extension handling” needed to preserve “Ignoring an extension cannot weaken isolation or authority”; record an enforcement gap where only a model exists.
- [ ] **UC-M01.02-C052-T06 · Dependency connection:** Connect the “Extension handling” specification to CLI requests, backend adapters and guest ABI negotiation; record code coverage separately where the design is not yet enforced.
- [ ] **UC-M01.02-C052-T07 · Resource behavior:** Account for “Extension bytes, extension count and lookup cost” in “Extension handling”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M01.02-C052-T08 · Delivery check:** Walk the populated “Extension handling” model through a valid example and the source counterexample “An unknown field attempts to disable signature admission”; record corrections and unresolved enforcement gaps.
- [ ] **UC-M01.02-C052-T09 · Patch review:** Review the “Extension handling” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M01.02-C052-T10 · Delivery handoff:** Publish the “Extension handling” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M01.02-C053 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Ignoring an extension cannot weaken isolation or authority. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M01.02-C053-T01 · Named property:** Create a stable property/check name under this parent for “Extension handling”; copy its required invariant exactly: “Ignoring an extension cannot weaken isolation or authority”.
- [ ] **UC-M01.02-C053-T02 · Observable terms:** Define each term in the “Extension handling” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M01.02-C053-T03 · Precondition set:** List the preconditions under which “Ignoring an extension cannot weaken isolation or authority” must hold for “Extension handling”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M01.02-C053-T04 · Transition coverage:** Map the “Extension handling” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M01.02-C053-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Extension handling”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M01.02-C053-T06 · Satisfying fixture:** Create a concrete “Extension handling” case that satisfies “Ignoring an extension cannot weaken isolation or authority”; record its expected observation before running the assertion or review.
- [ ] **UC-M01.02-C053-T07 · Violating fixture:** Create the source counterexample “An unknown field attempts to disable signature admission” for “Extension handling”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M01.02-C053-T08 · Enforcement evidence:** Exercise the “Extension handling” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M01.02-C053-T09 · Regression linkage:** Link the “Extension handling” property to changes in CLI requests, backend adapters and guest ABI negotiation; record which dependency or contract changes require rerunning it.
- [ ] **UC-M01.02-C053-T10 · Property disposition:** Compare the satisfying and violating “Extension handling” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M01.02-C054 · Integration

**Original checklist item:** Integrate extension handling with CLI requests, backend adapters and guest ABI negotiation; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M01.02-C054-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Extension handling” across CLI requests, backend adapters and guest ABI negotiation; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M01.02-C054-T02 · Field mapping:** Map every “Extension handling” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M01.02-C054-T03 · Prerequisite identities:** Record the actual prerequisites for “Extension handling” (source dependency list: UC-M01.01); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M01.02-C054-T04 · Ownership agreement:** Specify who owns “Extension handling” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M01.02-C054-T05 · Handoff implementation:** Connect “Extension handling” through the mapped seam using the real adapter or explicit specification reference; preserve “Ignoring an extension cannot weaken isolation or authority” across the handoff.
- [ ] **UC-M01.02-C054-T06 · Absent-input case:** Omit one required “Extension handling” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M01.02-C054-T07 · Stale-input case:** Supply an outdated “Extension handling” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M01.02-C054-T08 · Incompatible-input case:** Supply an incompatible “Extension handling” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M01.02-C054-T09 · Valid integration trace:** Run a valid “Extension handling” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M01.02-C054-T10 · Seam review:** Reconcile the “Extension handling” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M01.02-C055 · Valid-case test

**Original checklist item:** Construct a valid worked example for extension handling; evaluate it against predeclared expected decisions and, where enforcement exists, run the corresponding conformance fixture.

- [ ] **UC-M01.02-C055-T01 · Valid fixture choice:** Select one concrete valid worked example for “Extension handling”; enumerate the model inputs and the expected review decision before evaluating it.
- [ ] **UC-M01.02-C055-T02 · Expected-result oracle:** Specify the “Extension handling” expected result independently of the implementation output; include the property “Ignoring an extension cannot weaken isolation or authority” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M01.02-C055-T03 · Fixture material:** Create the concrete “Extension handling” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M01.02-C055-T04 · Target preparation:** Prepare the “Extension handling” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M01.02-C055-T05 · Initial-state record:** Record the initial “Extension handling” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M01.02-C055-T06 · Valid-path execution:** Evaluate the “Extension handling” example against the reviewed model; where a runtime mechanism exists, run its corresponding fixture and label those observations separately.
- [ ] **UC-M01.02-C055-T07 · Outcome comparison:** Compare every declared “Extension handling” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M01.02-C055-T08 · State and bounds check:** Inspect the “Extension handling” ownership/state effects and actual use of “Extension bytes, extension count and lookup cost”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M01.02-C055-T09 · Repeatability check:** Repeat the same “Extension handling” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M01.02-C055-T10 · Positive evidence:** Attach the “Extension handling” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M01.02-C056 · Negative test

**Original checklist item:** Negative case: An unknown field attempts to disable signature admission. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M01.02-C056-T01 · Adverse-case definition:** Create a test record for the exact “Extension handling” source counterexample: “An unknown field attempts to disable signature admission”; state which precondition or invariant it challenges.
- [ ] **UC-M01.02-C056-T02 · Safe fixture boundary:** Define the contained test boundary for “Extension handling”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M01.02-C056-T03 · Valid control:** Construct a valid “Extension handling” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M01.02-C056-T04 · Minimal adverse input:** Derive the “Extension handling” adverse fixture from the control with the smallest documented change needed to reproduce “An unknown field attempts to disable signature admission”; retain that change as reproducible data.
- [ ] **UC-M01.02-C056-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Extension handling”; require “Ignoring an extension cannot weaken isolation or authority” and forbid a false-success verdict.
- [ ] **UC-M01.02-C056-T06 · Adverse execution:** Evaluate the “Extension handling” adverse case through the actual review/contract gate; where implemented, also observe the runtime refusal and keep the two evidence classes separate.
- [ ] **UC-M01.02-C056-T07 · Effect inspection:** Inspect “Extension handling” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M01.02-C056-T08 · Refusal versus failure:** Confirm the “Extension handling” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M01.02-C056-T09 · Reset and retention:** Restore only the disposable “Extension handling” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M01.02-C056-T10 · Negative regression:** Register the “Extension handling” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M01.02-C057 · Change / failure test

**Original checklist item:** Exercise extension handling when a client and backend advertise different contract versions; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M01.02-C057-T01 · Scenario record:** Write the “Extension handling” change/failure scenario exactly as supplied: a client and backend advertise different contract versions; identify the property that must remain true: “Ignoring an extension cannot weaken isolation or authority”.
- [ ] **UC-M01.02-C057-T02 · Baseline capture:** Create a known-valid “Extension handling” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M01.02-C057-T03 · Injection map:** Locate the “Extension handling” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M01.02-C057-T04 · Disposition oracle:** Define the legal intermediate and final “Extension handling” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M01.02-C057-T05 · Controlled trigger:** Apply the controlled model-change scenario for “Extension handling”: a client and backend advertise different contract versions; retain the exact before/after declarations. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M01.02-C057-T06 · Intermediate inspection:** Review which “Extension handling” claims, approvals and evidence references become stale after the change; keep unresolved enforcement gaps visible.
- [ ] **UC-M01.02-C057-T07 · Recovery path:** Revise or explicitly refuse the changed “Extension handling” model under the documented compatibility policy; re-review affected claims before restoring their approval.
- [ ] **UC-M01.02-C057-T08 · Stale-evidence cleanup:** Invalidate superseded “Extension handling” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M01.02-C057-T09 · Repeat and compare:** Repeat the selected “Extension handling” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M01.02-C057-T10 · Failure evidence:** Publish the “Extension handling” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M01.02-C058 · Bounds

**Original checklist item:** Define completeness and scaling criteria for extension bytes, extension count and lookup cost; exercise larger inventories or fixture sets, and report uncovered scope instead of silently excluding it.

- [ ] **UC-M01.02-C058-T01 · Quantity inventory:** Create a measurement inventory for “Extension handling”: “Extension bytes, extension count and lookup cost”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M01.02-C058-T02 · Measurement method:** Choose how to observe each “Extension handling” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M01.02-C058-T03 · Budget decision:** Select justified coverage and completeness limits for “Extension handling”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M01.02-C058-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Extension handling” cases for “Extension bytes, extension count and lookup cost”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M01.02-C058-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Extension handling” limit; preserve “Ignoring an extension cannot weaken isolation or authority”.
- [ ] **UC-M01.02-C058-T06 · Normal measurement:** Run or review the normal “Extension handling” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M01.02-C058-T07 · At-limit measurement:** Exercise the “Extension handling” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M01.02-C058-T08 · Over-limit measurement:** Exercise the “Extension handling” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M01.02-C058-T09 · Uncovered-scope report:** List the “Extension handling” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M01.02-C058-T10 · Limit evidence:** Publish the selected “Extension handling” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M01.02-C059 · Diagnostics / review

**Original checklist item:** Record the rationale, unresolved assumptions, enforcement gaps and re-review triggers for extension handling; make design-only claims visibly distinct from observed behavior.

- [ ] **UC-M01.02-C059-T01 · Review inventory:** List the “Extension handling” decisions and claims requiring review; distinguish source requirements, implementation observations and engineering assumptions.
- [ ] **UC-M01.02-C059-T02 · Rationale record:** Write the rationale for the selected “Extension handling” representation or policy; link each choice to the requirement rather than an unexplained preference.
- [ ] **UC-M01.02-C059-T03 · Assumption ledger:** Record unresolved “Extension handling” assumptions, their owner and what observation or decision would resolve them; do not treat unknowns as approvals.
- [ ] **UC-M01.02-C059-T04 · Boundary map:** Map each “Extension handling” claim to an actual guard or explicit design/review gate; flag gaps against “Ignoring an extension cannot weaken isolation or authority”.
- [ ] **UC-M01.02-C059-T05 · Counterexample review:** Walk reviewers through the “Extension handling” counterexample “An unknown field attempts to disable signature admission”; record whether the model detects it and whether any runtime guard was actually exercised.
- [ ] **UC-M01.02-C059-T06 · Review outcome vocabulary:** Define approved, blocked, superseded and untested review outcomes for “Extension handling”; ensure the wording cannot be read as runtime enforcement evidence.
- [ ] **UC-M01.02-C059-T07 · Re-review triggers:** List “Extension handling” invalidation triggers, including the source change scenario: a client and backend advertise different contract versions; identify the affected claims and evidence.
- [ ] **UC-M01.02-C059-T08 · Sensitive-data review:** Inspect the “Extension handling” review record for secrets and unrelated user content; retain nonsecret references sufficient for reproducibility.
- [ ] **UC-M01.02-C059-T09 · Independent reading:** Have the “Extension handling” record read against the original acceptance criterion and CLI requests, backend adapters and guest ABI negotiation; record misunderstandings or missing evidence as corrections.
- [ ] **UC-M01.02-C059-T10 · Review disposition:** Publish the “Extension handling” rationale, versioned review outcome, unresolved gaps and explicit next decision; keep blockers open until supported evidence resolves them.

### UC-M01.02-C060 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for extension handling; label unexecuted checks as untested.

- [ ] **UC-M01.02-C060-T01 · Evidence inventory:** List the “Extension handling” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M01.02-C060-T02 · Artifact references:** Record the exact “Extension handling” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M01.02-C060-T03 · Fixture references:** Attach the “Extension handling” fixture IDs, input identities and oracle definition; preserve the source counterexample “An unknown field attempts to disable signature admission” as a distinct evidence case.
- [ ] **UC-M01.02-C060-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Extension handling”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M01.02-C060-T05 · Environment record:** Record the actual “Extension handling” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M01.02-C060-T06 · Expected versus observed:** Pair every “Extension handling” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M01.02-C060-T07 · Failure and limit records:** Attach “Extension handling” change/failure and bounds evidence where required; include uncovered “Extension bytes, extension count and lookup cost” and unresolved violations of “Ignoring an extension cannot weaken isolation or authority”.
- [ ] **UC-M01.02-C060-T08 · Evidence hygiene:** Check the “Extension handling” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M01.02-C060-T09 · Reproduction review:** Have the “Extension handling” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M01.02-C060-T10 · Acceptance linkage:** Link the “Extension handling” evidence to its parent and UC-M01.02 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 07. Duplicate-field rejection

**Source delivery:** Reject duplicate request keys before constructing typed contract objects.

**Source invariant:** One field cannot carry two competing values.

**Source negative case:** A request repeats the generation field with different values.

**Source bounded quantities:** Parser input size and duplicate-detection memory.

### UC-M01.02-C061 · Contract

**Original checklist item:** Specify the scope and representation of duplicate-field rejection; identify its producer, consumer, authority assumptions and explicitly unsupported cases.

- [ ] **UC-M01.02-C061-T01 · Scope statement:** Draft a scope note for “Duplicate-field rejection” within Versioned runtime and guest contracts; separate required model statements, explicit exclusions and unresolved design decisions.
- [ ] **UC-M01.02-C061-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Duplicate-field rejection”; record each producer, representation and missing-value meaning.
- [ ] **UC-M01.02-C061-T03 · Output inventory:** List the outputs of “Duplicate-field rejection” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M01.02-C061-T04 · Field dictionary:** Create a field-and-term dictionary for “Duplicate-field rejection”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M01.02-C061-T05 · Prerequisite contract:** Map “Duplicate-field rejection” to the source component prerequisites (UC-M01.01); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M01.02-C061-T06 · Authority map:** Identify who may produce, change and consume “Duplicate-field rejection”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M01.02-C061-T07 · Invariant clause:** Add a normative clause for “Duplicate-field rejection” that preserves “One field cannot carry two competing values”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M01.02-C061-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Duplicate-field rejection”; include the source counterexample “A request repeats the generation field with different values” and the intended safe disposition.
- [ ] **UC-M01.02-C061-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Parser input size and duplicate-detection memory” in the “Duplicate-field rejection” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M01.02-C061-T10 · Contract review:** Review the “Duplicate-field rejection” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M01.02-C062 · Delivery

**Original checklist item:** Reject duplicate request keys before constructing typed contract objects.

- [ ] **UC-M01.02-C062-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Duplicate-field rejection”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M01.02-C062-T02 · Change plan:** Break the source delivery for “Duplicate-field rejection” into concrete edit targets and reviewable outputs; keep the UC-M01.02 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M01.02-C062-T03 · Core artifact:** Implement the smallest selected-profile change for “Duplicate-field rejection” that realizes this source instruction: Reject duplicate request keys before constructing typed contract objects.
- [ ] **UC-M01.02-C062-T04 · Concrete realization:** Trace “Duplicate-field rejection” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M01.02-C062-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Duplicate-field rejection” needed to preserve “One field cannot carry two competing values”; record an enforcement gap where only a model exists.
- [ ] **UC-M01.02-C062-T06 · Dependency connection:** Connect the “Duplicate-field rejection” specification to CLI requests, backend adapters and guest ABI negotiation; record code coverage separately where the design is not yet enforced.
- [ ] **UC-M01.02-C062-T07 · Resource behavior:** Account for “Parser input size and duplicate-detection memory” in “Duplicate-field rejection”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M01.02-C062-T08 · Delivery check:** Walk the populated “Duplicate-field rejection” model through a valid example and the source counterexample “A request repeats the generation field with different values”; record corrections and unresolved enforcement gaps.
- [ ] **UC-M01.02-C062-T09 · Patch review:** Review the “Duplicate-field rejection” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M01.02-C062-T10 · Delivery handoff:** Publish the “Duplicate-field rejection” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M01.02-C063 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: One field cannot carry two competing values. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M01.02-C063-T01 · Named property:** Create a stable property/check name under this parent for “Duplicate-field rejection”; copy its required invariant exactly: “One field cannot carry two competing values”.
- [ ] **UC-M01.02-C063-T02 · Observable terms:** Define each term in the “Duplicate-field rejection” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M01.02-C063-T03 · Precondition set:** List the preconditions under which “One field cannot carry two competing values” must hold for “Duplicate-field rejection”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M01.02-C063-T04 · Transition coverage:** Map the “Duplicate-field rejection” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M01.02-C063-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Duplicate-field rejection”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M01.02-C063-T06 · Satisfying fixture:** Create a concrete “Duplicate-field rejection” case that satisfies “One field cannot carry two competing values”; record its expected observation before running the assertion or review.
- [ ] **UC-M01.02-C063-T07 · Violating fixture:** Create the source counterexample “A request repeats the generation field with different values” for “Duplicate-field rejection”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M01.02-C063-T08 · Enforcement evidence:** Exercise the “Duplicate-field rejection” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M01.02-C063-T09 · Regression linkage:** Link the “Duplicate-field rejection” property to changes in CLI requests, backend adapters and guest ABI negotiation; record which dependency or contract changes require rerunning it.
- [ ] **UC-M01.02-C063-T10 · Property disposition:** Compare the satisfying and violating “Duplicate-field rejection” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M01.02-C064 · Integration

**Original checklist item:** Integrate duplicate-field rejection with CLI requests, backend adapters and guest ABI negotiation; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M01.02-C064-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Duplicate-field rejection” across CLI requests, backend adapters and guest ABI negotiation; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M01.02-C064-T02 · Field mapping:** Map every “Duplicate-field rejection” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M01.02-C064-T03 · Prerequisite identities:** Record the actual prerequisites for “Duplicate-field rejection” (source dependency list: UC-M01.01); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M01.02-C064-T04 · Ownership agreement:** Specify who owns “Duplicate-field rejection” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M01.02-C064-T05 · Handoff implementation:** Connect “Duplicate-field rejection” through the mapped seam using the real adapter or explicit specification reference; preserve “One field cannot carry two competing values” across the handoff.
- [ ] **UC-M01.02-C064-T06 · Absent-input case:** Omit one required “Duplicate-field rejection” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M01.02-C064-T07 · Stale-input case:** Supply an outdated “Duplicate-field rejection” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M01.02-C064-T08 · Incompatible-input case:** Supply an incompatible “Duplicate-field rejection” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M01.02-C064-T09 · Valid integration trace:** Run a valid “Duplicate-field rejection” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M01.02-C064-T10 · Seam review:** Reconcile the “Duplicate-field rejection” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M01.02-C065 · Valid-case test

**Original checklist item:** Construct a valid worked example for duplicate-field rejection; evaluate it against predeclared expected decisions and, where enforcement exists, run the corresponding conformance fixture.

- [ ] **UC-M01.02-C065-T01 · Valid fixture choice:** Select one concrete valid worked example for “Duplicate-field rejection”; enumerate the model inputs and the expected review decision before evaluating it.
- [ ] **UC-M01.02-C065-T02 · Expected-result oracle:** Specify the “Duplicate-field rejection” expected result independently of the implementation output; include the property “One field cannot carry two competing values” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M01.02-C065-T03 · Fixture material:** Create the concrete “Duplicate-field rejection” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M01.02-C065-T04 · Target preparation:** Prepare the “Duplicate-field rejection” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M01.02-C065-T05 · Initial-state record:** Record the initial “Duplicate-field rejection” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M01.02-C065-T06 · Valid-path execution:** Evaluate the “Duplicate-field rejection” example against the reviewed model; where a runtime mechanism exists, run its corresponding fixture and label those observations separately.
- [ ] **UC-M01.02-C065-T07 · Outcome comparison:** Compare every declared “Duplicate-field rejection” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M01.02-C065-T08 · State and bounds check:** Inspect the “Duplicate-field rejection” ownership/state effects and actual use of “Parser input size and duplicate-detection memory”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M01.02-C065-T09 · Repeatability check:** Repeat the same “Duplicate-field rejection” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M01.02-C065-T10 · Positive evidence:** Attach the “Duplicate-field rejection” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M01.02-C066 · Negative test

**Original checklist item:** Negative case: A request repeats the generation field with different values. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M01.02-C066-T01 · Adverse-case definition:** Create a test record for the exact “Duplicate-field rejection” source counterexample: “A request repeats the generation field with different values”; state which precondition or invariant it challenges.
- [ ] **UC-M01.02-C066-T02 · Safe fixture boundary:** Define the contained test boundary for “Duplicate-field rejection”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M01.02-C066-T03 · Valid control:** Construct a valid “Duplicate-field rejection” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M01.02-C066-T04 · Minimal adverse input:** Derive the “Duplicate-field rejection” adverse fixture from the control with the smallest documented change needed to reproduce “A request repeats the generation field with different values”; retain that change as reproducible data.
- [ ] **UC-M01.02-C066-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Duplicate-field rejection”; require “One field cannot carry two competing values” and forbid a false-success verdict.
- [ ] **UC-M01.02-C066-T06 · Adverse execution:** Evaluate the “Duplicate-field rejection” adverse case through the actual review/contract gate; where implemented, also observe the runtime refusal and keep the two evidence classes separate.
- [ ] **UC-M01.02-C066-T07 · Effect inspection:** Inspect “Duplicate-field rejection” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M01.02-C066-T08 · Refusal versus failure:** Confirm the “Duplicate-field rejection” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M01.02-C066-T09 · Reset and retention:** Restore only the disposable “Duplicate-field rejection” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M01.02-C066-T10 · Negative regression:** Register the “Duplicate-field rejection” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M01.02-C067 · Change / failure test

**Original checklist item:** Exercise duplicate-field rejection when a client and backend advertise different contract versions; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M01.02-C067-T01 · Scenario record:** Write the “Duplicate-field rejection” change/failure scenario exactly as supplied: a client and backend advertise different contract versions; identify the property that must remain true: “One field cannot carry two competing values”.
- [ ] **UC-M01.02-C067-T02 · Baseline capture:** Create a known-valid “Duplicate-field rejection” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M01.02-C067-T03 · Injection map:** Locate the “Duplicate-field rejection” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M01.02-C067-T04 · Disposition oracle:** Define the legal intermediate and final “Duplicate-field rejection” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M01.02-C067-T05 · Controlled trigger:** Apply the controlled model-change scenario for “Duplicate-field rejection”: a client and backend advertise different contract versions; retain the exact before/after declarations. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M01.02-C067-T06 · Intermediate inspection:** Review which “Duplicate-field rejection” claims, approvals and evidence references become stale after the change; keep unresolved enforcement gaps visible.
- [ ] **UC-M01.02-C067-T07 · Recovery path:** Revise or explicitly refuse the changed “Duplicate-field rejection” model under the documented compatibility policy; re-review affected claims before restoring their approval.
- [ ] **UC-M01.02-C067-T08 · Stale-evidence cleanup:** Invalidate superseded “Duplicate-field rejection” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M01.02-C067-T09 · Repeat and compare:** Repeat the selected “Duplicate-field rejection” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M01.02-C067-T10 · Failure evidence:** Publish the “Duplicate-field rejection” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M01.02-C068 · Bounds

**Original checklist item:** Define completeness and scaling criteria for parser input size and duplicate-detection memory; exercise larger inventories or fixture sets, and report uncovered scope instead of silently excluding it.

- [ ] **UC-M01.02-C068-T01 · Quantity inventory:** Create a measurement inventory for “Duplicate-field rejection”: “Parser input size and duplicate-detection memory”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M01.02-C068-T02 · Measurement method:** Choose how to observe each “Duplicate-field rejection” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M01.02-C068-T03 · Budget decision:** Select justified coverage and completeness limits for “Duplicate-field rejection”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M01.02-C068-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Duplicate-field rejection” cases for “Parser input size and duplicate-detection memory”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M01.02-C068-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Duplicate-field rejection” limit; preserve “One field cannot carry two competing values”.
- [ ] **UC-M01.02-C068-T06 · Normal measurement:** Run or review the normal “Duplicate-field rejection” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M01.02-C068-T07 · At-limit measurement:** Exercise the “Duplicate-field rejection” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M01.02-C068-T08 · Over-limit measurement:** Exercise the “Duplicate-field rejection” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M01.02-C068-T09 · Uncovered-scope report:** List the “Duplicate-field rejection” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M01.02-C068-T10 · Limit evidence:** Publish the selected “Duplicate-field rejection” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M01.02-C069 · Diagnostics / review

**Original checklist item:** Record the rationale, unresolved assumptions, enforcement gaps and re-review triggers for duplicate-field rejection; make design-only claims visibly distinct from observed behavior.

- [ ] **UC-M01.02-C069-T01 · Review inventory:** List the “Duplicate-field rejection” decisions and claims requiring review; distinguish source requirements, implementation observations and engineering assumptions.
- [ ] **UC-M01.02-C069-T02 · Rationale record:** Write the rationale for the selected “Duplicate-field rejection” representation or policy; link each choice to the requirement rather than an unexplained preference.
- [ ] **UC-M01.02-C069-T03 · Assumption ledger:** Record unresolved “Duplicate-field rejection” assumptions, their owner and what observation or decision would resolve them; do not treat unknowns as approvals.
- [ ] **UC-M01.02-C069-T04 · Boundary map:** Map each “Duplicate-field rejection” claim to an actual guard or explicit design/review gate; flag gaps against “One field cannot carry two competing values”.
- [ ] **UC-M01.02-C069-T05 · Counterexample review:** Walk reviewers through the “Duplicate-field rejection” counterexample “A request repeats the generation field with different values”; record whether the model detects it and whether any runtime guard was actually exercised.
- [ ] **UC-M01.02-C069-T06 · Review outcome vocabulary:** Define approved, blocked, superseded and untested review outcomes for “Duplicate-field rejection”; ensure the wording cannot be read as runtime enforcement evidence.
- [ ] **UC-M01.02-C069-T07 · Re-review triggers:** List “Duplicate-field rejection” invalidation triggers, including the source change scenario: a client and backend advertise different contract versions; identify the affected claims and evidence.
- [ ] **UC-M01.02-C069-T08 · Sensitive-data review:** Inspect the “Duplicate-field rejection” review record for secrets and unrelated user content; retain nonsecret references sufficient for reproducibility.
- [ ] **UC-M01.02-C069-T09 · Independent reading:** Have the “Duplicate-field rejection” record read against the original acceptance criterion and CLI requests, backend adapters and guest ABI negotiation; record misunderstandings or missing evidence as corrections.
- [ ] **UC-M01.02-C069-T10 · Review disposition:** Publish the “Duplicate-field rejection” rationale, versioned review outcome, unresolved gaps and explicit next decision; keep blockers open until supported evidence resolves them.

### UC-M01.02-C070 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for duplicate-field rejection; label unexecuted checks as untested.

- [ ] **UC-M01.02-C070-T01 · Evidence inventory:** List the “Duplicate-field rejection” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M01.02-C070-T02 · Artifact references:** Record the exact “Duplicate-field rejection” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M01.02-C070-T03 · Fixture references:** Attach the “Duplicate-field rejection” fixture IDs, input identities and oracle definition; preserve the source counterexample “A request repeats the generation field with different values” as a distinct evidence case.
- [ ] **UC-M01.02-C070-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Duplicate-field rejection”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M01.02-C070-T05 · Environment record:** Record the actual “Duplicate-field rejection” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M01.02-C070-T06 · Expected versus observed:** Pair every “Duplicate-field rejection” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M01.02-C070-T07 · Failure and limit records:** Attach “Duplicate-field rejection” change/failure and bounds evidence where required; include uncovered “Parser input size and duplicate-detection memory” and unresolved violations of “One field cannot carry two competing values”.
- [ ] **UC-M01.02-C070-T08 · Evidence hygiene:** Check the “Duplicate-field rejection” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M01.02-C070-T09 · Reproduction review:** Have the “Duplicate-field rejection” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M01.02-C070-T10 · Acceptance linkage:** Link the “Duplicate-field rejection” evidence to its parent and UC-M01.02 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 08. Capability negotiation

**Source delivery:** Bind requested features to the selected backend's verified capability set.

**Source invariant:** Required unsupported capabilities cause refusal.

**Source negative case:** A snapshot requirement is dropped by a backend adapter.

**Source bounded quantities:** Capability set size and negotiation time.

### UC-M01.02-C071 · Contract

**Original checklist item:** Specify the scope and representation of capability negotiation; identify its producer, consumer, authority assumptions and explicitly unsupported cases.

- [ ] **UC-M01.02-C071-T01 · Scope statement:** Draft a scope note for “Capability negotiation” within Versioned runtime and guest contracts; separate required model statements, explicit exclusions and unresolved design decisions.
- [ ] **UC-M01.02-C071-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Capability negotiation”; record each producer, representation and missing-value meaning.
- [ ] **UC-M01.02-C071-T03 · Output inventory:** List the outputs of “Capability negotiation” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M01.02-C071-T04 · Field dictionary:** Create a field-and-term dictionary for “Capability negotiation”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M01.02-C071-T05 · Prerequisite contract:** Map “Capability negotiation” to the source component prerequisites (UC-M01.01); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M01.02-C071-T06 · Authority map:** Identify who may produce, change and consume “Capability negotiation”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M01.02-C071-T07 · Invariant clause:** Add a normative clause for “Capability negotiation” that preserves “Required unsupported capabilities cause refusal”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M01.02-C071-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Capability negotiation”; include the source counterexample “A snapshot requirement is dropped by a backend adapter” and the intended safe disposition.
- [ ] **UC-M01.02-C071-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Capability set size and negotiation time” in the “Capability negotiation” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M01.02-C071-T10 · Contract review:** Review the “Capability negotiation” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M01.02-C072 · Delivery

**Original checklist item:** Bind requested features to the selected backend's verified capability set.

- [ ] **UC-M01.02-C072-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Capability negotiation”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M01.02-C072-T02 · Change plan:** Break the source delivery for “Capability negotiation” into concrete edit targets and reviewable outputs; keep the UC-M01.02 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M01.02-C072-T03 · Core artifact:** Implement the smallest selected-profile change for “Capability negotiation” that realizes this source instruction: Bind requested features to the selected backend's verified capability set.
- [ ] **UC-M01.02-C072-T04 · Concrete realization:** Trace “Capability negotiation” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M01.02-C072-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Capability negotiation” needed to preserve “Required unsupported capabilities cause refusal”; record an enforcement gap where only a model exists.
- [ ] **UC-M01.02-C072-T06 · Dependency connection:** Connect the “Capability negotiation” specification to CLI requests, backend adapters and guest ABI negotiation; record code coverage separately where the design is not yet enforced.
- [ ] **UC-M01.02-C072-T07 · Resource behavior:** Account for “Capability set size and negotiation time” in “Capability negotiation”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M01.02-C072-T08 · Delivery check:** Walk the populated “Capability negotiation” model through a valid example and the source counterexample “A snapshot requirement is dropped by a backend adapter”; record corrections and unresolved enforcement gaps.
- [ ] **UC-M01.02-C072-T09 · Patch review:** Review the “Capability negotiation” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M01.02-C072-T10 · Delivery handoff:** Publish the “Capability negotiation” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M01.02-C073 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Required unsupported capabilities cause refusal. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M01.02-C073-T01 · Named property:** Create a stable property/check name under this parent for “Capability negotiation”; copy its required invariant exactly: “Required unsupported capabilities cause refusal”.
- [ ] **UC-M01.02-C073-T02 · Observable terms:** Define each term in the “Capability negotiation” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M01.02-C073-T03 · Precondition set:** List the preconditions under which “Required unsupported capabilities cause refusal” must hold for “Capability negotiation”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M01.02-C073-T04 · Transition coverage:** Map the “Capability negotiation” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M01.02-C073-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Capability negotiation”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M01.02-C073-T06 · Satisfying fixture:** Create a concrete “Capability negotiation” case that satisfies “Required unsupported capabilities cause refusal”; record its expected observation before running the assertion or review.
- [ ] **UC-M01.02-C073-T07 · Violating fixture:** Create the source counterexample “A snapshot requirement is dropped by a backend adapter” for “Capability negotiation”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M01.02-C073-T08 · Enforcement evidence:** Exercise the “Capability negotiation” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M01.02-C073-T09 · Regression linkage:** Link the “Capability negotiation” property to changes in CLI requests, backend adapters and guest ABI negotiation; record which dependency or contract changes require rerunning it.
- [ ] **UC-M01.02-C073-T10 · Property disposition:** Compare the satisfying and violating “Capability negotiation” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M01.02-C074 · Integration

**Original checklist item:** Integrate capability negotiation with CLI requests, backend adapters and guest ABI negotiation; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M01.02-C074-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Capability negotiation” across CLI requests, backend adapters and guest ABI negotiation; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M01.02-C074-T02 · Field mapping:** Map every “Capability negotiation” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M01.02-C074-T03 · Prerequisite identities:** Record the actual prerequisites for “Capability negotiation” (source dependency list: UC-M01.01); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M01.02-C074-T04 · Ownership agreement:** Specify who owns “Capability negotiation” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M01.02-C074-T05 · Handoff implementation:** Connect “Capability negotiation” through the mapped seam using the real adapter or explicit specification reference; preserve “Required unsupported capabilities cause refusal” across the handoff.
- [ ] **UC-M01.02-C074-T06 · Absent-input case:** Omit one required “Capability negotiation” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M01.02-C074-T07 · Stale-input case:** Supply an outdated “Capability negotiation” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M01.02-C074-T08 · Incompatible-input case:** Supply an incompatible “Capability negotiation” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M01.02-C074-T09 · Valid integration trace:** Run a valid “Capability negotiation” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M01.02-C074-T10 · Seam review:** Reconcile the “Capability negotiation” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M01.02-C075 · Valid-case test

**Original checklist item:** Construct a valid worked example for capability negotiation; evaluate it against predeclared expected decisions and, where enforcement exists, run the corresponding conformance fixture.

- [ ] **UC-M01.02-C075-T01 · Valid fixture choice:** Select one concrete valid worked example for “Capability negotiation”; enumerate the model inputs and the expected review decision before evaluating it.
- [ ] **UC-M01.02-C075-T02 · Expected-result oracle:** Specify the “Capability negotiation” expected result independently of the implementation output; include the property “Required unsupported capabilities cause refusal” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M01.02-C075-T03 · Fixture material:** Create the concrete “Capability negotiation” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M01.02-C075-T04 · Target preparation:** Prepare the “Capability negotiation” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M01.02-C075-T05 · Initial-state record:** Record the initial “Capability negotiation” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M01.02-C075-T06 · Valid-path execution:** Evaluate the “Capability negotiation” example against the reviewed model; where a runtime mechanism exists, run its corresponding fixture and label those observations separately.
- [ ] **UC-M01.02-C075-T07 · Outcome comparison:** Compare every declared “Capability negotiation” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M01.02-C075-T08 · State and bounds check:** Inspect the “Capability negotiation” ownership/state effects and actual use of “Capability set size and negotiation time”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M01.02-C075-T09 · Repeatability check:** Repeat the same “Capability negotiation” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M01.02-C075-T10 · Positive evidence:** Attach the “Capability negotiation” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M01.02-C076 · Negative test

**Original checklist item:** Negative case: A snapshot requirement is dropped by a backend adapter. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M01.02-C076-T01 · Adverse-case definition:** Create a test record for the exact “Capability negotiation” source counterexample: “A snapshot requirement is dropped by a backend adapter”; state which precondition or invariant it challenges.
- [ ] **UC-M01.02-C076-T02 · Safe fixture boundary:** Define the contained test boundary for “Capability negotiation”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M01.02-C076-T03 · Valid control:** Construct a valid “Capability negotiation” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M01.02-C076-T04 · Minimal adverse input:** Derive the “Capability negotiation” adverse fixture from the control with the smallest documented change needed to reproduce “A snapshot requirement is dropped by a backend adapter”; retain that change as reproducible data.
- [ ] **UC-M01.02-C076-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Capability negotiation”; require “Required unsupported capabilities cause refusal” and forbid a false-success verdict.
- [ ] **UC-M01.02-C076-T06 · Adverse execution:** Evaluate the “Capability negotiation” adverse case through the actual review/contract gate; where implemented, also observe the runtime refusal and keep the two evidence classes separate.
- [ ] **UC-M01.02-C076-T07 · Effect inspection:** Inspect “Capability negotiation” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M01.02-C076-T08 · Refusal versus failure:** Confirm the “Capability negotiation” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M01.02-C076-T09 · Reset and retention:** Restore only the disposable “Capability negotiation” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M01.02-C076-T10 · Negative regression:** Register the “Capability negotiation” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M01.02-C077 · Change / failure test

**Original checklist item:** Exercise capability negotiation when a client and backend advertise different contract versions; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M01.02-C077-T01 · Scenario record:** Write the “Capability negotiation” change/failure scenario exactly as supplied: a client and backend advertise different contract versions; identify the property that must remain true: “Required unsupported capabilities cause refusal”.
- [ ] **UC-M01.02-C077-T02 · Baseline capture:** Create a known-valid “Capability negotiation” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M01.02-C077-T03 · Injection map:** Locate the “Capability negotiation” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M01.02-C077-T04 · Disposition oracle:** Define the legal intermediate and final “Capability negotiation” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M01.02-C077-T05 · Controlled trigger:** Apply the controlled model-change scenario for “Capability negotiation”: a client and backend advertise different contract versions; retain the exact before/after declarations. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M01.02-C077-T06 · Intermediate inspection:** Review which “Capability negotiation” claims, approvals and evidence references become stale after the change; keep unresolved enforcement gaps visible.
- [ ] **UC-M01.02-C077-T07 · Recovery path:** Revise or explicitly refuse the changed “Capability negotiation” model under the documented compatibility policy; re-review affected claims before restoring their approval.
- [ ] **UC-M01.02-C077-T08 · Stale-evidence cleanup:** Invalidate superseded “Capability negotiation” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M01.02-C077-T09 · Repeat and compare:** Repeat the selected “Capability negotiation” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M01.02-C077-T10 · Failure evidence:** Publish the “Capability negotiation” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M01.02-C078 · Bounds

**Original checklist item:** Define completeness and scaling criteria for capability set size and negotiation time; exercise larger inventories or fixture sets, and report uncovered scope instead of silently excluding it.

- [ ] **UC-M01.02-C078-T01 · Quantity inventory:** Create a measurement inventory for “Capability negotiation”: “Capability set size and negotiation time”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M01.02-C078-T02 · Measurement method:** Choose how to observe each “Capability negotiation” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M01.02-C078-T03 · Budget decision:** Select justified coverage and completeness limits for “Capability negotiation”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M01.02-C078-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Capability negotiation” cases for “Capability set size and negotiation time”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M01.02-C078-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Capability negotiation” limit; preserve “Required unsupported capabilities cause refusal”.
- [ ] **UC-M01.02-C078-T06 · Normal measurement:** Run or review the normal “Capability negotiation” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M01.02-C078-T07 · At-limit measurement:** Exercise the “Capability negotiation” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M01.02-C078-T08 · Over-limit measurement:** Exercise the “Capability negotiation” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M01.02-C078-T09 · Uncovered-scope report:** List the “Capability negotiation” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M01.02-C078-T10 · Limit evidence:** Publish the selected “Capability negotiation” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M01.02-C079 · Diagnostics / review

**Original checklist item:** Record the rationale, unresolved assumptions, enforcement gaps and re-review triggers for capability negotiation; make design-only claims visibly distinct from observed behavior.

- [ ] **UC-M01.02-C079-T01 · Review inventory:** List the “Capability negotiation” decisions and claims requiring review; distinguish source requirements, implementation observations and engineering assumptions.
- [ ] **UC-M01.02-C079-T02 · Rationale record:** Write the rationale for the selected “Capability negotiation” representation or policy; link each choice to the requirement rather than an unexplained preference.
- [ ] **UC-M01.02-C079-T03 · Assumption ledger:** Record unresolved “Capability negotiation” assumptions, their owner and what observation or decision would resolve them; do not treat unknowns as approvals.
- [ ] **UC-M01.02-C079-T04 · Boundary map:** Map each “Capability negotiation” claim to an actual guard or explicit design/review gate; flag gaps against “Required unsupported capabilities cause refusal”.
- [ ] **UC-M01.02-C079-T05 · Counterexample review:** Walk reviewers through the “Capability negotiation” counterexample “A snapshot requirement is dropped by a backend adapter”; record whether the model detects it and whether any runtime guard was actually exercised.
- [ ] **UC-M01.02-C079-T06 · Review outcome vocabulary:** Define approved, blocked, superseded and untested review outcomes for “Capability negotiation”; ensure the wording cannot be read as runtime enforcement evidence.
- [ ] **UC-M01.02-C079-T07 · Re-review triggers:** List “Capability negotiation” invalidation triggers, including the source change scenario: a client and backend advertise different contract versions; identify the affected claims and evidence.
- [ ] **UC-M01.02-C079-T08 · Sensitive-data review:** Inspect the “Capability negotiation” review record for secrets and unrelated user content; retain nonsecret references sufficient for reproducibility.
- [ ] **UC-M01.02-C079-T09 · Independent reading:** Have the “Capability negotiation” record read against the original acceptance criterion and CLI requests, backend adapters and guest ABI negotiation; record misunderstandings or missing evidence as corrections.
- [ ] **UC-M01.02-C079-T10 · Review disposition:** Publish the “Capability negotiation” rationale, versioned review outcome, unresolved gaps and explicit next decision; keep blockers open until supported evidence resolves them.

### UC-M01.02-C080 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for capability negotiation; label unexecuted checks as untested.

- [ ] **UC-M01.02-C080-T01 · Evidence inventory:** List the “Capability negotiation” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M01.02-C080-T02 · Artifact references:** Record the exact “Capability negotiation” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M01.02-C080-T03 · Fixture references:** Attach the “Capability negotiation” fixture IDs, input identities and oracle definition; preserve the source counterexample “A snapshot requirement is dropped by a backend adapter” as a distinct evidence case.
- [ ] **UC-M01.02-C080-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Capability negotiation”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M01.02-C080-T05 · Environment record:** Record the actual “Capability negotiation” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M01.02-C080-T06 · Expected versus observed:** Pair every “Capability negotiation” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M01.02-C080-T07 · Failure and limit records:** Attach “Capability negotiation” change/failure and bounds evidence where required; include uncovered “Capability set size and negotiation time” and unresolved violations of “Required unsupported capabilities cause refusal”.
- [ ] **UC-M01.02-C080-T08 · Evidence hygiene:** Check the “Capability negotiation” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M01.02-C080-T09 · Reproduction review:** Have the “Capability negotiation” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M01.02-C080-T10 · Acceptance linkage:** Link the “Capability negotiation” evidence to its parent and UC-M01.02 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 09. Mutation barriers

**Source delivery:** Place complete contract validation before resource allocation or persistent mutation.

**Source invariant:** Rejected requests leave no admitted workload or executable child.

**Source negative case:** An invalid invoke request creates a guest before validation.

**Source bounded quantities:** Preflight allocations and cleanup deadlines.

### UC-M01.02-C081 · Contract

**Original checklist item:** Specify the scope and representation of mutation barriers; identify its producer, consumer, authority assumptions and explicitly unsupported cases.

- [ ] **UC-M01.02-C081-T01 · Scope statement:** Draft a scope note for “Mutation barriers” within Versioned runtime and guest contracts; separate required model statements, explicit exclusions and unresolved design decisions.
- [ ] **UC-M01.02-C081-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Mutation barriers”; record each producer, representation and missing-value meaning.
- [ ] **UC-M01.02-C081-T03 · Output inventory:** List the outputs of “Mutation barriers” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M01.02-C081-T04 · Field dictionary:** Create a field-and-term dictionary for “Mutation barriers”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M01.02-C081-T05 · Prerequisite contract:** Map “Mutation barriers” to the source component prerequisites (UC-M01.01); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M01.02-C081-T06 · Authority map:** Identify who may produce, change and consume “Mutation barriers”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M01.02-C081-T07 · Invariant clause:** Add a normative clause for “Mutation barriers” that preserves “Rejected requests leave no admitted workload or executable child”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M01.02-C081-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Mutation barriers”; include the source counterexample “An invalid invoke request creates a guest before validation” and the intended safe disposition.
- [ ] **UC-M01.02-C081-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Preflight allocations and cleanup deadlines” in the “Mutation barriers” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M01.02-C081-T10 · Contract review:** Review the “Mutation barriers” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M01.02-C082 · Delivery

**Original checklist item:** Place complete contract validation before resource allocation or persistent mutation.

- [ ] **UC-M01.02-C082-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Mutation barriers”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M01.02-C082-T02 · Change plan:** Break the source delivery for “Mutation barriers” into concrete edit targets and reviewable outputs; keep the UC-M01.02 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M01.02-C082-T03 · Core artifact:** Implement the smallest selected-profile change for “Mutation barriers” that realizes this source instruction: Place complete contract validation before resource allocation or persistent mutation.
- [ ] **UC-M01.02-C082-T04 · Concrete realization:** Trace “Mutation barriers” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M01.02-C082-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Mutation barriers” needed to preserve “Rejected requests leave no admitted workload or executable child”; record an enforcement gap where only a model exists.
- [ ] **UC-M01.02-C082-T06 · Dependency connection:** Connect the “Mutation barriers” specification to CLI requests, backend adapters and guest ABI negotiation; record code coverage separately where the design is not yet enforced.
- [ ] **UC-M01.02-C082-T07 · Resource behavior:** Account for “Preflight allocations and cleanup deadlines” in “Mutation barriers”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M01.02-C082-T08 · Delivery check:** Walk the populated “Mutation barriers” model through a valid example and the source counterexample “An invalid invoke request creates a guest before validation”; record corrections and unresolved enforcement gaps.
- [ ] **UC-M01.02-C082-T09 · Patch review:** Review the “Mutation barriers” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M01.02-C082-T10 · Delivery handoff:** Publish the “Mutation barriers” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M01.02-C083 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Rejected requests leave no admitted workload or executable child. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M01.02-C083-T01 · Named property:** Create a stable property/check name under this parent for “Mutation barriers”; copy its required invariant exactly: “Rejected requests leave no admitted workload or executable child”.
- [ ] **UC-M01.02-C083-T02 · Observable terms:** Define each term in the “Mutation barriers” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M01.02-C083-T03 · Precondition set:** List the preconditions under which “Rejected requests leave no admitted workload or executable child” must hold for “Mutation barriers”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M01.02-C083-T04 · Transition coverage:** Map the “Mutation barriers” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M01.02-C083-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Mutation barriers”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M01.02-C083-T06 · Satisfying fixture:** Create a concrete “Mutation barriers” case that satisfies “Rejected requests leave no admitted workload or executable child”; record its expected observation before running the assertion or review.
- [ ] **UC-M01.02-C083-T07 · Violating fixture:** Create the source counterexample “An invalid invoke request creates a guest before validation” for “Mutation barriers”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M01.02-C083-T08 · Enforcement evidence:** Exercise the “Mutation barriers” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M01.02-C083-T09 · Regression linkage:** Link the “Mutation barriers” property to changes in CLI requests, backend adapters and guest ABI negotiation; record which dependency or contract changes require rerunning it.
- [ ] **UC-M01.02-C083-T10 · Property disposition:** Compare the satisfying and violating “Mutation barriers” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M01.02-C084 · Integration

**Original checklist item:** Integrate mutation barriers with CLI requests, backend adapters and guest ABI negotiation; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M01.02-C084-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Mutation barriers” across CLI requests, backend adapters and guest ABI negotiation; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M01.02-C084-T02 · Field mapping:** Map every “Mutation barriers” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M01.02-C084-T03 · Prerequisite identities:** Record the actual prerequisites for “Mutation barriers” (source dependency list: UC-M01.01); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M01.02-C084-T04 · Ownership agreement:** Specify who owns “Mutation barriers” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M01.02-C084-T05 · Handoff implementation:** Connect “Mutation barriers” through the mapped seam using the real adapter or explicit specification reference; preserve “Rejected requests leave no admitted workload or executable child” across the handoff.
- [ ] **UC-M01.02-C084-T06 · Absent-input case:** Omit one required “Mutation barriers” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M01.02-C084-T07 · Stale-input case:** Supply an outdated “Mutation barriers” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M01.02-C084-T08 · Incompatible-input case:** Supply an incompatible “Mutation barriers” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M01.02-C084-T09 · Valid integration trace:** Run a valid “Mutation barriers” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M01.02-C084-T10 · Seam review:** Reconcile the “Mutation barriers” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M01.02-C085 · Valid-case test

**Original checklist item:** Construct a valid worked example for mutation barriers; evaluate it against predeclared expected decisions and, where enforcement exists, run the corresponding conformance fixture.

- [ ] **UC-M01.02-C085-T01 · Valid fixture choice:** Select one concrete valid worked example for “Mutation barriers”; enumerate the model inputs and the expected review decision before evaluating it.
- [ ] **UC-M01.02-C085-T02 · Expected-result oracle:** Specify the “Mutation barriers” expected result independently of the implementation output; include the property “Rejected requests leave no admitted workload or executable child” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M01.02-C085-T03 · Fixture material:** Create the concrete “Mutation barriers” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M01.02-C085-T04 · Target preparation:** Prepare the “Mutation barriers” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M01.02-C085-T05 · Initial-state record:** Record the initial “Mutation barriers” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M01.02-C085-T06 · Valid-path execution:** Evaluate the “Mutation barriers” example against the reviewed model; where a runtime mechanism exists, run its corresponding fixture and label those observations separately.
- [ ] **UC-M01.02-C085-T07 · Outcome comparison:** Compare every declared “Mutation barriers” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M01.02-C085-T08 · State and bounds check:** Inspect the “Mutation barriers” ownership/state effects and actual use of “Preflight allocations and cleanup deadlines”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M01.02-C085-T09 · Repeatability check:** Repeat the same “Mutation barriers” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M01.02-C085-T10 · Positive evidence:** Attach the “Mutation barriers” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M01.02-C086 · Negative test

**Original checklist item:** Negative case: An invalid invoke request creates a guest before validation. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M01.02-C086-T01 · Adverse-case definition:** Create a test record for the exact “Mutation barriers” source counterexample: “An invalid invoke request creates a guest before validation”; state which precondition or invariant it challenges.
- [ ] **UC-M01.02-C086-T02 · Safe fixture boundary:** Define the contained test boundary for “Mutation barriers”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M01.02-C086-T03 · Valid control:** Construct a valid “Mutation barriers” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M01.02-C086-T04 · Minimal adverse input:** Derive the “Mutation barriers” adverse fixture from the control with the smallest documented change needed to reproduce “An invalid invoke request creates a guest before validation”; retain that change as reproducible data.
- [ ] **UC-M01.02-C086-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Mutation barriers”; require “Rejected requests leave no admitted workload or executable child” and forbid a false-success verdict.
- [ ] **UC-M01.02-C086-T06 · Adverse execution:** Evaluate the “Mutation barriers” adverse case through the actual review/contract gate; where implemented, also observe the runtime refusal and keep the two evidence classes separate.
- [ ] **UC-M01.02-C086-T07 · Effect inspection:** Inspect “Mutation barriers” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M01.02-C086-T08 · Refusal versus failure:** Confirm the “Mutation barriers” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M01.02-C086-T09 · Reset and retention:** Restore only the disposable “Mutation barriers” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M01.02-C086-T10 · Negative regression:** Register the “Mutation barriers” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M01.02-C087 · Change / failure test

**Original checklist item:** Exercise mutation barriers when a client and backend advertise different contract versions; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M01.02-C087-T01 · Scenario record:** Write the “Mutation barriers” change/failure scenario exactly as supplied: a client and backend advertise different contract versions; identify the property that must remain true: “Rejected requests leave no admitted workload or executable child”.
- [ ] **UC-M01.02-C087-T02 · Baseline capture:** Create a known-valid “Mutation barriers” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M01.02-C087-T03 · Injection map:** Locate the “Mutation barriers” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M01.02-C087-T04 · Disposition oracle:** Define the legal intermediate and final “Mutation barriers” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M01.02-C087-T05 · Controlled trigger:** Apply the controlled model-change scenario for “Mutation barriers”: a client and backend advertise different contract versions; retain the exact before/after declarations. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M01.02-C087-T06 · Intermediate inspection:** Review which “Mutation barriers” claims, approvals and evidence references become stale after the change; keep unresolved enforcement gaps visible.
- [ ] **UC-M01.02-C087-T07 · Recovery path:** Revise or explicitly refuse the changed “Mutation barriers” model under the documented compatibility policy; re-review affected claims before restoring their approval.
- [ ] **UC-M01.02-C087-T08 · Stale-evidence cleanup:** Invalidate superseded “Mutation barriers” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M01.02-C087-T09 · Repeat and compare:** Repeat the selected “Mutation barriers” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M01.02-C087-T10 · Failure evidence:** Publish the “Mutation barriers” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M01.02-C088 · Bounds

**Original checklist item:** Define completeness and scaling criteria for preflight allocations and cleanup deadlines; exercise larger inventories or fixture sets, and report uncovered scope instead of silently excluding it.

- [ ] **UC-M01.02-C088-T01 · Quantity inventory:** Create a measurement inventory for “Mutation barriers”: “Preflight allocations and cleanup deadlines”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M01.02-C088-T02 · Measurement method:** Choose how to observe each “Mutation barriers” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M01.02-C088-T03 · Budget decision:** Select justified coverage and completeness limits for “Mutation barriers”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M01.02-C088-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Mutation barriers” cases for “Preflight allocations and cleanup deadlines”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M01.02-C088-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Mutation barriers” limit; preserve “Rejected requests leave no admitted workload or executable child”.
- [ ] **UC-M01.02-C088-T06 · Normal measurement:** Run or review the normal “Mutation barriers” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M01.02-C088-T07 · At-limit measurement:** Exercise the “Mutation barriers” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M01.02-C088-T08 · Over-limit measurement:** Exercise the “Mutation barriers” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M01.02-C088-T09 · Uncovered-scope report:** List the “Mutation barriers” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M01.02-C088-T10 · Limit evidence:** Publish the selected “Mutation barriers” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M01.02-C089 · Diagnostics / review

**Original checklist item:** Record the rationale, unresolved assumptions, enforcement gaps and re-review triggers for mutation barriers; make design-only claims visibly distinct from observed behavior.

- [ ] **UC-M01.02-C089-T01 · Review inventory:** List the “Mutation barriers” decisions and claims requiring review; distinguish source requirements, implementation observations and engineering assumptions.
- [ ] **UC-M01.02-C089-T02 · Rationale record:** Write the rationale for the selected “Mutation barriers” representation or policy; link each choice to the requirement rather than an unexplained preference.
- [ ] **UC-M01.02-C089-T03 · Assumption ledger:** Record unresolved “Mutation barriers” assumptions, their owner and what observation or decision would resolve them; do not treat unknowns as approvals.
- [ ] **UC-M01.02-C089-T04 · Boundary map:** Map each “Mutation barriers” claim to an actual guard or explicit design/review gate; flag gaps against “Rejected requests leave no admitted workload or executable child”.
- [ ] **UC-M01.02-C089-T05 · Counterexample review:** Walk reviewers through the “Mutation barriers” counterexample “An invalid invoke request creates a guest before validation”; record whether the model detects it and whether any runtime guard was actually exercised.
- [ ] **UC-M01.02-C089-T06 · Review outcome vocabulary:** Define approved, blocked, superseded and untested review outcomes for “Mutation barriers”; ensure the wording cannot be read as runtime enforcement evidence.
- [ ] **UC-M01.02-C089-T07 · Re-review triggers:** List “Mutation barriers” invalidation triggers, including the source change scenario: a client and backend advertise different contract versions; identify the affected claims and evidence.
- [ ] **UC-M01.02-C089-T08 · Sensitive-data review:** Inspect the “Mutation barriers” review record for secrets and unrelated user content; retain nonsecret references sufficient for reproducibility.
- [ ] **UC-M01.02-C089-T09 · Independent reading:** Have the “Mutation barriers” record read against the original acceptance criterion and CLI requests, backend adapters and guest ABI negotiation; record misunderstandings or missing evidence as corrections.
- [ ] **UC-M01.02-C089-T10 · Review disposition:** Publish the “Mutation barriers” rationale, versioned review outcome, unresolved gaps and explicit next decision; keep blockers open until supported evidence resolves them.

### UC-M01.02-C090 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for mutation barriers; label unexecuted checks as untested.

- [ ] **UC-M01.02-C090-T01 · Evidence inventory:** List the “Mutation barriers” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M01.02-C090-T02 · Artifact references:** Record the exact “Mutation barriers” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M01.02-C090-T03 · Fixture references:** Attach the “Mutation barriers” fixture IDs, input identities and oracle definition; preserve the source counterexample “An invalid invoke request creates a guest before validation” as a distinct evidence case.
- [ ] **UC-M01.02-C090-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Mutation barriers”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M01.02-C090-T05 · Environment record:** Record the actual “Mutation barriers” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M01.02-C090-T06 · Expected versus observed:** Pair every “Mutation barriers” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M01.02-C090-T07 · Failure and limit records:** Attach “Mutation barriers” change/failure and bounds evidence where required; include uncovered “Preflight allocations and cleanup deadlines” and unresolved violations of “Rejected requests leave no admitted workload or executable child”.
- [ ] **UC-M01.02-C090-T08 · Evidence hygiene:** Check the “Mutation barriers” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M01.02-C090-T09 · Reproduction review:** Have the “Mutation barriers” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M01.02-C090-T10 · Acceptance linkage:** Link the “Mutation barriers” evidence to its parent and UC-M01.02 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 10. Contract fixture suite

**Source delivery:** Maintain positive, incompatible-version and malformed-request fixtures for each operation.

**Source invariant:** Every public operation has repeatable acceptance and refusal evidence.

**Source negative case:** A new operation ships without a negative contract test.

**Source bounded quantities:** Fixture count, test runtime and compatibility coverage.

### UC-M01.02-C091 · Contract

**Original checklist item:** Specify the scope and representation of contract fixture suite; identify its producer, consumer, authority assumptions and explicitly unsupported cases.

- [ ] **UC-M01.02-C091-T01 · Scope statement:** Draft a scope note for “Contract fixture suite” within Versioned runtime and guest contracts; separate required model statements, explicit exclusions and unresolved design decisions.
- [ ] **UC-M01.02-C091-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Contract fixture suite”; record each producer, representation and missing-value meaning.
- [ ] **UC-M01.02-C091-T03 · Output inventory:** List the outputs of “Contract fixture suite” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M01.02-C091-T04 · Field dictionary:** Create a field-and-term dictionary for “Contract fixture suite”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M01.02-C091-T05 · Prerequisite contract:** Map “Contract fixture suite” to the source component prerequisites (UC-M01.01); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M01.02-C091-T06 · Authority map:** Identify who may produce, change and consume “Contract fixture suite”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M01.02-C091-T07 · Invariant clause:** Add a normative clause for “Contract fixture suite” that preserves “Every public operation has repeatable acceptance and refusal evidence”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M01.02-C091-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Contract fixture suite”; include the source counterexample “A new operation ships without a negative contract test” and the intended safe disposition.
- [ ] **UC-M01.02-C091-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Fixture count, test runtime and compatibility coverage” in the “Contract fixture suite” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M01.02-C091-T10 · Contract review:** Review the “Contract fixture suite” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M01.02-C092 · Delivery

**Original checklist item:** Maintain positive, incompatible-version and malformed-request fixtures for each operation.

- [ ] **UC-M01.02-C092-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Contract fixture suite”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M01.02-C092-T02 · Change plan:** Break the source delivery for “Contract fixture suite” into concrete edit targets and reviewable outputs; keep the UC-M01.02 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M01.02-C092-T03 · Core artifact:** Implement the smallest selected-profile change for “Contract fixture suite” that realizes this source instruction: Maintain positive, incompatible-version and malformed-request fixtures for each operation.
- [ ] **UC-M01.02-C092-T04 · Concrete realization:** Trace “Contract fixture suite” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M01.02-C092-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Contract fixture suite” needed to preserve “Every public operation has repeatable acceptance and refusal evidence”; record an enforcement gap where only a model exists.
- [ ] **UC-M01.02-C092-T06 · Dependency connection:** Connect the “Contract fixture suite” specification to CLI requests, backend adapters and guest ABI negotiation; record code coverage separately where the design is not yet enforced.
- [ ] **UC-M01.02-C092-T07 · Resource behavior:** Account for “Fixture count, test runtime and compatibility coverage” in “Contract fixture suite”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M01.02-C092-T08 · Delivery check:** Walk the populated “Contract fixture suite” model through a valid example and the source counterexample “A new operation ships without a negative contract test”; record corrections and unresolved enforcement gaps.
- [ ] **UC-M01.02-C092-T09 · Patch review:** Review the “Contract fixture suite” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M01.02-C092-T10 · Delivery handoff:** Publish the “Contract fixture suite” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M01.02-C093 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Every public operation has repeatable acceptance and refusal evidence. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M01.02-C093-T01 · Named property:** Create a stable property/check name under this parent for “Contract fixture suite”; copy its required invariant exactly: “Every public operation has repeatable acceptance and refusal evidence”.
- [ ] **UC-M01.02-C093-T02 · Observable terms:** Define each term in the “Contract fixture suite” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M01.02-C093-T03 · Precondition set:** List the preconditions under which “Every public operation has repeatable acceptance and refusal evidence” must hold for “Contract fixture suite”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M01.02-C093-T04 · Transition coverage:** Map the “Contract fixture suite” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M01.02-C093-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Contract fixture suite”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M01.02-C093-T06 · Satisfying fixture:** Create a concrete “Contract fixture suite” case that satisfies “Every public operation has repeatable acceptance and refusal evidence”; record its expected observation before running the assertion or review.
- [ ] **UC-M01.02-C093-T07 · Violating fixture:** Create the source counterexample “A new operation ships without a negative contract test” for “Contract fixture suite”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M01.02-C093-T08 · Enforcement evidence:** Exercise the “Contract fixture suite” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M01.02-C093-T09 · Regression linkage:** Link the “Contract fixture suite” property to changes in CLI requests, backend adapters and guest ABI negotiation; record which dependency or contract changes require rerunning it.
- [ ] **UC-M01.02-C093-T10 · Property disposition:** Compare the satisfying and violating “Contract fixture suite” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M01.02-C094 · Integration

**Original checklist item:** Integrate contract fixture suite with CLI requests, backend adapters and guest ABI negotiation; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M01.02-C094-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Contract fixture suite” across CLI requests, backend adapters and guest ABI negotiation; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M01.02-C094-T02 · Field mapping:** Map every “Contract fixture suite” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M01.02-C094-T03 · Prerequisite identities:** Record the actual prerequisites for “Contract fixture suite” (source dependency list: UC-M01.01); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M01.02-C094-T04 · Ownership agreement:** Specify who owns “Contract fixture suite” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M01.02-C094-T05 · Handoff implementation:** Connect “Contract fixture suite” through the mapped seam using the real adapter or explicit specification reference; preserve “Every public operation has repeatable acceptance and refusal evidence” across the handoff.
- [ ] **UC-M01.02-C094-T06 · Absent-input case:** Omit one required “Contract fixture suite” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M01.02-C094-T07 · Stale-input case:** Supply an outdated “Contract fixture suite” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M01.02-C094-T08 · Incompatible-input case:** Supply an incompatible “Contract fixture suite” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M01.02-C094-T09 · Valid integration trace:** Run a valid “Contract fixture suite” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M01.02-C094-T10 · Seam review:** Reconcile the “Contract fixture suite” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M01.02-C095 · Valid-case test

**Original checklist item:** Construct a valid worked example for contract fixture suite; evaluate it against predeclared expected decisions and, where enforcement exists, run the corresponding conformance fixture.

- [ ] **UC-M01.02-C095-T01 · Valid fixture choice:** Select one concrete valid worked example for “Contract fixture suite”; enumerate the model inputs and the expected review decision before evaluating it.
- [ ] **UC-M01.02-C095-T02 · Expected-result oracle:** Specify the “Contract fixture suite” expected result independently of the implementation output; include the property “Every public operation has repeatable acceptance and refusal evidence” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M01.02-C095-T03 · Fixture material:** Create the concrete “Contract fixture suite” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M01.02-C095-T04 · Target preparation:** Prepare the “Contract fixture suite” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M01.02-C095-T05 · Initial-state record:** Record the initial “Contract fixture suite” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M01.02-C095-T06 · Valid-path execution:** Evaluate the “Contract fixture suite” example against the reviewed model; where a runtime mechanism exists, run its corresponding fixture and label those observations separately.
- [ ] **UC-M01.02-C095-T07 · Outcome comparison:** Compare every declared “Contract fixture suite” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M01.02-C095-T08 · State and bounds check:** Inspect the “Contract fixture suite” ownership/state effects and actual use of “Fixture count, test runtime and compatibility coverage”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M01.02-C095-T09 · Repeatability check:** Repeat the same “Contract fixture suite” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M01.02-C095-T10 · Positive evidence:** Attach the “Contract fixture suite” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M01.02-C096 · Negative test

**Original checklist item:** Negative case: A new operation ships without a negative contract test. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M01.02-C096-T01 · Adverse-case definition:** Create a test record for the exact “Contract fixture suite” source counterexample: “A new operation ships without a negative contract test”; state which precondition or invariant it challenges.
- [ ] **UC-M01.02-C096-T02 · Safe fixture boundary:** Define the contained test boundary for “Contract fixture suite”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M01.02-C096-T03 · Valid control:** Construct a valid “Contract fixture suite” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M01.02-C096-T04 · Minimal adverse input:** Derive the “Contract fixture suite” adverse fixture from the control with the smallest documented change needed to reproduce “A new operation ships without a negative contract test”; retain that change as reproducible data.
- [ ] **UC-M01.02-C096-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Contract fixture suite”; require “Every public operation has repeatable acceptance and refusal evidence” and forbid a false-success verdict.
- [ ] **UC-M01.02-C096-T06 · Adverse execution:** Evaluate the “Contract fixture suite” adverse case through the actual review/contract gate; where implemented, also observe the runtime refusal and keep the two evidence classes separate.
- [ ] **UC-M01.02-C096-T07 · Effect inspection:** Inspect “Contract fixture suite” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M01.02-C096-T08 · Refusal versus failure:** Confirm the “Contract fixture suite” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M01.02-C096-T09 · Reset and retention:** Restore only the disposable “Contract fixture suite” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M01.02-C096-T10 · Negative regression:** Register the “Contract fixture suite” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M01.02-C097 · Change / failure test

**Original checklist item:** Exercise contract fixture suite when a client and backend advertise different contract versions; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M01.02-C097-T01 · Scenario record:** Write the “Contract fixture suite” change/failure scenario exactly as supplied: a client and backend advertise different contract versions; identify the property that must remain true: “Every public operation has repeatable acceptance and refusal evidence”.
- [ ] **UC-M01.02-C097-T02 · Baseline capture:** Create a known-valid “Contract fixture suite” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M01.02-C097-T03 · Injection map:** Locate the “Contract fixture suite” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M01.02-C097-T04 · Disposition oracle:** Define the legal intermediate and final “Contract fixture suite” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M01.02-C097-T05 · Controlled trigger:** Apply the controlled model-change scenario for “Contract fixture suite”: a client and backend advertise different contract versions; retain the exact before/after declarations. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M01.02-C097-T06 · Intermediate inspection:** Review which “Contract fixture suite” claims, approvals and evidence references become stale after the change; keep unresolved enforcement gaps visible.
- [ ] **UC-M01.02-C097-T07 · Recovery path:** Revise or explicitly refuse the changed “Contract fixture suite” model under the documented compatibility policy; re-review affected claims before restoring their approval.
- [ ] **UC-M01.02-C097-T08 · Stale-evidence cleanup:** Invalidate superseded “Contract fixture suite” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M01.02-C097-T09 · Repeat and compare:** Repeat the selected “Contract fixture suite” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M01.02-C097-T10 · Failure evidence:** Publish the “Contract fixture suite” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M01.02-C098 · Bounds

**Original checklist item:** Define completeness and scaling criteria for fixture count, test runtime and compatibility coverage; exercise larger inventories or fixture sets, and report uncovered scope instead of silently excluding it.

- [ ] **UC-M01.02-C098-T01 · Quantity inventory:** Create a measurement inventory for “Contract fixture suite”: “Fixture count, test runtime and compatibility coverage”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M01.02-C098-T02 · Measurement method:** Choose how to observe each “Contract fixture suite” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M01.02-C098-T03 · Budget decision:** Select justified coverage and completeness limits for “Contract fixture suite”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M01.02-C098-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Contract fixture suite” cases for “Fixture count, test runtime and compatibility coverage”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M01.02-C098-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Contract fixture suite” limit; preserve “Every public operation has repeatable acceptance and refusal evidence”.
- [ ] **UC-M01.02-C098-T06 · Normal measurement:** Run or review the normal “Contract fixture suite” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M01.02-C098-T07 · At-limit measurement:** Exercise the “Contract fixture suite” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M01.02-C098-T08 · Over-limit measurement:** Exercise the “Contract fixture suite” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M01.02-C098-T09 · Uncovered-scope report:** List the “Contract fixture suite” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M01.02-C098-T10 · Limit evidence:** Publish the selected “Contract fixture suite” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M01.02-C099 · Diagnostics / review

**Original checklist item:** Record the rationale, unresolved assumptions, enforcement gaps and re-review triggers for contract fixture suite; make design-only claims visibly distinct from observed behavior.

- [ ] **UC-M01.02-C099-T01 · Review inventory:** List the “Contract fixture suite” decisions and claims requiring review; distinguish source requirements, implementation observations and engineering assumptions.
- [ ] **UC-M01.02-C099-T02 · Rationale record:** Write the rationale for the selected “Contract fixture suite” representation or policy; link each choice to the requirement rather than an unexplained preference.
- [ ] **UC-M01.02-C099-T03 · Assumption ledger:** Record unresolved “Contract fixture suite” assumptions, their owner and what observation or decision would resolve them; do not treat unknowns as approvals.
- [ ] **UC-M01.02-C099-T04 · Boundary map:** Map each “Contract fixture suite” claim to an actual guard or explicit design/review gate; flag gaps against “Every public operation has repeatable acceptance and refusal evidence”.
- [ ] **UC-M01.02-C099-T05 · Counterexample review:** Walk reviewers through the “Contract fixture suite” counterexample “A new operation ships without a negative contract test”; record whether the model detects it and whether any runtime guard was actually exercised.
- [ ] **UC-M01.02-C099-T06 · Review outcome vocabulary:** Define approved, blocked, superseded and untested review outcomes for “Contract fixture suite”; ensure the wording cannot be read as runtime enforcement evidence.
- [ ] **UC-M01.02-C099-T07 · Re-review triggers:** List “Contract fixture suite” invalidation triggers, including the source change scenario: a client and backend advertise different contract versions; identify the affected claims and evidence.
- [ ] **UC-M01.02-C099-T08 · Sensitive-data review:** Inspect the “Contract fixture suite” review record for secrets and unrelated user content; retain nonsecret references sufficient for reproducibility.
- [ ] **UC-M01.02-C099-T09 · Independent reading:** Have the “Contract fixture suite” record read against the original acceptance criterion and CLI requests, backend adapters and guest ABI negotiation; record misunderstandings or missing evidence as corrections.
- [ ] **UC-M01.02-C099-T10 · Review disposition:** Publish the “Contract fixture suite” rationale, versioned review outcome, unresolved gaps and explicit next decision; keep blockers open until supported evidence resolves them.

### UC-M01.02-C100 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for contract fixture suite; label unexecuted checks as untested.

- [ ] **UC-M01.02-C100-T01 · Evidence inventory:** List the “Contract fixture suite” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M01.02-C100-T02 · Artifact references:** Record the exact “Contract fixture suite” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M01.02-C100-T03 · Fixture references:** Attach the “Contract fixture suite” fixture IDs, input identities and oracle definition; preserve the source counterexample “A new operation ships without a negative contract test” as a distinct evidence case.
- [ ] **UC-M01.02-C100-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Contract fixture suite”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M01.02-C100-T05 · Environment record:** Record the actual “Contract fixture suite” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M01.02-C100-T06 · Expected versus observed:** Pair every “Contract fixture suite” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M01.02-C100-T07 · Failure and limit records:** Attach “Contract fixture suite” change/failure and bounds evidence where required; include uncovered “Fixture count, test runtime and compatibility coverage” and unresolved violations of “Every public operation has repeatable acceptance and refusal evidence”.
- [ ] **UC-M01.02-C100-T08 · Evidence hygiene:** Check the “Contract fixture suite” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M01.02-C100-T09 · Reproduction review:** Have the “Contract fixture suite” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M01.02-C100-T10 · Acceptance linkage:** Link the “Contract fixture suite” evidence to its parent and UC-M01.02 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

