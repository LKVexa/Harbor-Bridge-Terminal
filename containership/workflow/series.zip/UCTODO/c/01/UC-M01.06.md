# UC-M01.06 — Closed-world source and dependency inventory

**To-Do Pack 2.0.0 · Baseline UC-2.2.0 · 100 parent checks × 10 subtasks = 1,000 to-dos**

[Master index](../../INDEX.md) · [Workstream index](../../w/01.md)

| Field | Preserved source value |
|---|---|
| Workstream | 01. Architecture and executable contracts |
| Milestone | A |
| Priority | P0 |
| Source assessment | PARTIAL |
| Scope | core or selected profile |
| Dependencies | [UC-M01.04](../01/UC-M01.04.md) |
| Source checklist pack | 1.0.0 |
| Original reference labels | [S1], [S3]. |

## Original requirement

Define which files are input, generated, excluded or runtime state; preserve an explicit rejection/exclusion ledger for every ingest.

**Original acceptance criterion:** Every original archive member is either hash-accounted cargo or has a documented policy disposition; no silently lost dependencies.

**Source trace:** Original checklist `UC100/c/01/UC-M01.06.md` inside [s/checklists.zip](../../s/checklists.zip); exact parent records in [data/parents.jsonl](../../data/parents.jsonl). Original roadmap lines 104–114 are preserved in [s/roadmap.md](../../s/roadmap.md).

## How to use these lists

Every parent statement below is preserved verbatim. Its ten child tasks are proposed decomposition, not implemented capabilities or executed tests. Child IDs append `-T01` through `-T10` to the original parent ID. All begin unchecked / `TODO`. Design/review evidence does not establish runtime enforcement; observe the actual selected target where the parent requires it.

The source dependency graph and selected release profile determine applicability. The numbered child sequence is a local working order, not an added hard dependency graph. An unselected optional feature needs a recorded not-applicable rationale; missing prerequisites for selected work remain blockers. Numerical budgets, backends and trust mechanisms remain decisions unless fixed by the source. Test hostile cases only with synthetic inputs in authorized disposable environments.

## 01. Archive member census

**Source delivery:** Inventory every original archive member before selection or transformation.

**Source invariant:** Every input member receives an explicit disposition.

**Source negative case:** An unfamiliar file type disappears during ingest.

**Source bounded quantities:** Archive member count and total expanded bytes.

### UC-M01.06-C001 · Contract

**Original checklist item:** Specify archive member census inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M01.06-C001-T01 · Scope statement:** Draft the operation boundary for “Archive member census” within Closed-world source and dependency inventory; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M01.06-C001-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Archive member census”; record each producer, representation and missing-value meaning.
- [ ] **UC-M01.06-C001-T03 · Output inventory:** List the outputs of “Archive member census” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M01.06-C001-T04 · Field dictionary:** Create a field-and-term dictionary for “Archive member census”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M01.06-C001-T05 · Prerequisite contract:** Map “Archive member census” to the source component prerequisites (UC-M01.04); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M01.06-C001-T06 · Authority map:** Identify who may produce, change and consume “Archive member census”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M01.06-C001-T07 · Invariant clause:** Add a normative clause for “Archive member census” that preserves “Every input member receives an explicit disposition”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M01.06-C001-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Archive member census”; include the source counterexample “An unfamiliar file type disappears during ingest” and the intended safe disposition.
- [ ] **UC-M01.06-C001-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Archive member count and total expanded bytes” in the “Archive member census” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M01.06-C001-T10 · Contract review:** Review the “Archive member census” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M01.06-C002 · Delivery

**Original checklist item:** Inventory every original archive member before selection or transformation.

- [ ] **UC-M01.06-C002-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Archive member census”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M01.06-C002-T02 · Change plan:** Break the source delivery for “Archive member census” into concrete edit targets and reviewable outputs; keep the UC-M01.06 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M01.06-C002-T03 · Core artifact:** Create the “Archive member census” model, schema or inventory that realizes this source instruction: Inventory every original archive member before selection or transformation.
- [ ] **UC-M01.06-C002-T04 · Concrete realization:** Populate “Archive member census” with one concrete worked case; map every required entity or field to its source and flag any unmapped entry.
- [ ] **UC-M01.06-C002-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Archive member census” needed to preserve “Every input member receives an explicit disposition”; record an enforcement gap where only a model exists.
- [ ] **UC-M01.06-C002-T06 · Dependency connection:** Connect the “Archive member census” implementation to archive admission, source ledgers and dependency resolution; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M01.06-C002-T07 · Resource behavior:** Account for “Archive member count and total expanded bytes” in “Archive member census”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M01.06-C002-T08 · Delivery check:** Run the smallest real “Archive member census” path and its adverse fixture “An unfamiliar file type disappears during ingest”; retain actual output, state effects and final disposition.
- [ ] **UC-M01.06-C002-T09 · Patch review:** Review the “Archive member census” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M01.06-C002-T10 · Delivery handoff:** Publish the “Archive member census” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M01.06-C003 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Every input member receives an explicit disposition. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M01.06-C003-T01 · Named property:** Create a stable property/check name under this parent for “Archive member census”; copy its required invariant exactly: “Every input member receives an explicit disposition”.
- [ ] **UC-M01.06-C003-T02 · Observable terms:** Define each term in the “Archive member census” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M01.06-C003-T03 · Precondition set:** List the preconditions under which “Every input member receives an explicit disposition” must hold for “Archive member census”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M01.06-C003-T04 · Transition coverage:** Map the “Archive member census” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M01.06-C003-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Archive member census”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M01.06-C003-T06 · Satisfying fixture:** Create a concrete “Archive member census” case that satisfies “Every input member receives an explicit disposition”; record its expected observation before running the assertion or review.
- [ ] **UC-M01.06-C003-T07 · Violating fixture:** Create the source counterexample “An unfamiliar file type disappears during ingest” for “Archive member census”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M01.06-C003-T08 · Enforcement evidence:** Exercise the “Archive member census” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M01.06-C003-T09 · Regression linkage:** Link the “Archive member census” property to changes in archive admission, source ledgers and dependency resolution; record which dependency or contract changes require rerunning it.
- [ ] **UC-M01.06-C003-T10 · Property disposition:** Compare the satisfying and violating “Archive member census” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M01.06-C004 · Integration

**Original checklist item:** Integrate archive member census with archive admission, source ledgers and dependency resolution; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M01.06-C004-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Archive member census” across archive admission, source ledgers and dependency resolution; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M01.06-C004-T02 · Field mapping:** Map every “Archive member census” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M01.06-C004-T03 · Prerequisite identities:** Record the actual prerequisites for “Archive member census” (source dependency list: UC-M01.04); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M01.06-C004-T04 · Ownership agreement:** Specify who owns “Archive member census” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M01.06-C004-T05 · Handoff implementation:** Connect “Archive member census” through the mapped seam using the real adapter or explicit specification reference; preserve “Every input member receives an explicit disposition” across the handoff.
- [ ] **UC-M01.06-C004-T06 · Absent-input case:** Omit one required “Archive member census” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M01.06-C004-T07 · Stale-input case:** Supply an outdated “Archive member census” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M01.06-C004-T08 · Incompatible-input case:** Supply an incompatible “Archive member census” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M01.06-C004-T09 · Valid integration trace:** Run a valid “Archive member census” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M01.06-C004-T10 · Seam review:** Reconcile the “Archive member census” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M01.06-C005 · Valid-case test

**Original checklist item:** Run a valid-path fixture for archive member census; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M01.06-C005-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Archive member census” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M01.06-C005-T02 · Expected-result oracle:** Specify the “Archive member census” expected result independently of the implementation output; include the property “Every input member receives an explicit disposition” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M01.06-C005-T03 · Fixture material:** Create the concrete “Archive member census” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M01.06-C005-T04 · Target preparation:** Prepare the “Archive member census” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M01.06-C005-T05 · Initial-state record:** Record the initial “Archive member census” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M01.06-C005-T06 · Valid-path execution:** Execute the “Archive member census” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M01.06-C005-T07 · Outcome comparison:** Compare every declared “Archive member census” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M01.06-C005-T08 · State and bounds check:** Inspect the “Archive member census” ownership/state effects and actual use of “Archive member count and total expanded bytes”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M01.06-C005-T09 · Repeatability check:** Repeat the same “Archive member census” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M01.06-C005-T10 · Positive evidence:** Attach the “Archive member census” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M01.06-C006 · Negative test

**Original checklist item:** Negative case: An unfamiliar file type disappears during ingest. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M01.06-C006-T01 · Adverse-case definition:** Create a test record for the exact “Archive member census” source counterexample: “An unfamiliar file type disappears during ingest”; state which precondition or invariant it challenges.
- [ ] **UC-M01.06-C006-T02 · Safe fixture boundary:** Define the contained test boundary for “Archive member census”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M01.06-C006-T03 · Valid control:** Construct a valid “Archive member census” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M01.06-C006-T04 · Minimal adverse input:** Derive the “Archive member census” adverse fixture from the control with the smallest documented change needed to reproduce “An unfamiliar file type disappears during ingest”; retain that change as reproducible data.
- [ ] **UC-M01.06-C006-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Archive member census”; require “Every input member receives an explicit disposition” and forbid a false-success verdict.
- [ ] **UC-M01.06-C006-T06 · Adverse execution:** Exercise the “Archive member census” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M01.06-C006-T07 · Effect inspection:** Inspect “Archive member census” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M01.06-C006-T08 · Refusal versus failure:** Confirm the “Archive member census” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M01.06-C006-T09 · Reset and retention:** Restore only the disposable “Archive member census” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M01.06-C006-T10 · Negative regression:** Register the “Archive member census” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M01.06-C007 · Change / failure test

**Original checklist item:** Exercise archive member census when ingest is interrupted after some members have been copied but before reconciliation; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M01.06-C007-T01 · Scenario record:** Write the “Archive member census” change/failure scenario exactly as supplied: ingest is interrupted after some members have been copied but before reconciliation; identify the property that must remain true: “Every input member receives an explicit disposition”.
- [ ] **UC-M01.06-C007-T02 · Baseline capture:** Create a known-valid “Archive member census” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M01.06-C007-T03 · Injection map:** Locate the “Archive member census” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M01.06-C007-T04 · Disposition oracle:** Define the legal intermediate and final “Archive member census” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M01.06-C007-T05 · Controlled trigger:** Introduce the controlled “Archive member census” scenario in the disposable fixture: ingest is interrupted after some members have been copied but before reconciliation; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M01.06-C007-T06 · Intermediate inspection:** Inspect the “Archive member census” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M01.06-C007-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Archive member census”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M01.06-C007-T08 · Stale-evidence cleanup:** Invalidate superseded “Archive member census” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M01.06-C007-T09 · Repeat and compare:** Repeat the selected “Archive member census” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M01.06-C007-T10 · Failure evidence:** Publish the “Archive member census” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M01.06-C008 · Bounds

**Original checklist item:** Choose, document and test limits for archive member count and total expanded bytes; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M01.06-C008-T01 · Quantity inventory:** Create a measurement inventory for “Archive member census”: “Archive member count and total expanded bytes”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M01.06-C008-T02 · Measurement method:** Choose how to observe each “Archive member census” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M01.06-C008-T03 · Budget decision:** Select justified resource and input limits for “Archive member census”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M01.06-C008-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Archive member census” cases for “Archive member count and total expanded bytes”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M01.06-C008-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Archive member census” limit; preserve “Every input member receives an explicit disposition”.
- [ ] **UC-M01.06-C008-T06 · Normal measurement:** Run or review the normal “Archive member census” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M01.06-C008-T07 · At-limit measurement:** Exercise the “Archive member census” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M01.06-C008-T08 · Over-limit measurement:** Exercise the “Archive member census” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M01.06-C008-T09 · Uncovered-scope report:** List the “Archive member census” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M01.06-C008-T10 · Limit evidence:** Publish the selected “Archive member census” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M01.06-C009 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for archive member census with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M01.06-C009-T01 · Event inventory:** List the “Archive member census” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M01.06-C009-T02 · Diagnostic schema:** Define nonsecret fields for “Archive member census” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M01.06-C009-T03 · Failure mapping:** Map each documented “Archive member census” refusal or error to a diagnostic outcome; include “An unfamiliar file type disappears during ingest” and prohibit conversion into a success message.
- [ ] **UC-M01.06-C009-T04 · Emission path:** Add the “Archive member census” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M01.06-C009-T05 · Redaction check:** Test “Archive member census” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M01.06-C009-T06 · Output budget:** Set and exercise bounded “Archive member census” message size, rate and retention compatible with “Archive member count and total expanded bytes”; define truncation behavior that preserves the final reason.
- [ ] **UC-M01.06-C009-T07 · Success/refusal fixtures:** Capture “Archive member census” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M01.06-C009-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Archive member census” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M01.06-C009-T09 · Operator review:** Read the “Archive member census” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M01.06-C009-T10 · Diagnostic evidence:** Publish redacted “Archive member census” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M01.06-C010 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for archive member census; label unexecuted checks as untested.

- [ ] **UC-M01.06-C010-T01 · Evidence inventory:** List the “Archive member census” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M01.06-C010-T02 · Artifact references:** Record the exact “Archive member census” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M01.06-C010-T03 · Fixture references:** Attach the “Archive member census” fixture IDs, input identities and oracle definition; preserve the source counterexample “An unfamiliar file type disappears during ingest” as a distinct evidence case.
- [ ] **UC-M01.06-C010-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Archive member census”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M01.06-C010-T05 · Environment record:** Record the actual “Archive member census” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M01.06-C010-T06 · Expected versus observed:** Pair every “Archive member census” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M01.06-C010-T07 · Failure and limit records:** Attach “Archive member census” change/failure and bounds evidence where required; include uncovered “Archive member count and total expanded bytes” and unresolved violations of “Every input member receives an explicit disposition”.
- [ ] **UC-M01.06-C010-T08 · Evidence hygiene:** Check the “Archive member census” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M01.06-C010-T09 · Reproduction review:** Have the “Archive member census” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M01.06-C010-T10 · Acceptance linkage:** Link the “Archive member census” evidence to its parent and UC-M01.06 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 02. Input classification

**Source delivery:** Classify files as source input, generated output, excluded material or runtime state.

**Source invariant:** Classification does not erase source provenance.

**Source negative case:** A generated-looking source file is excluded without a reason.

**Source bounded quantities:** Classification rules and ambiguous-file backlog.

### UC-M01.06-C011 · Contract

**Original checklist item:** Specify input classification inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M01.06-C011-T01 · Scope statement:** Draft the operation boundary for “Input classification” within Closed-world source and dependency inventory; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M01.06-C011-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Input classification”; record each producer, representation and missing-value meaning.
- [ ] **UC-M01.06-C011-T03 · Output inventory:** List the outputs of “Input classification” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M01.06-C011-T04 · Field dictionary:** Create a field-and-term dictionary for “Input classification”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M01.06-C011-T05 · Prerequisite contract:** Map “Input classification” to the source component prerequisites (UC-M01.04); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M01.06-C011-T06 · Authority map:** Identify who may produce, change and consume “Input classification”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M01.06-C011-T07 · Invariant clause:** Add a normative clause for “Input classification” that preserves “Classification does not erase source provenance”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M01.06-C011-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Input classification”; include the source counterexample “A generated-looking source file is excluded without a reason” and the intended safe disposition.
- [ ] **UC-M01.06-C011-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Classification rules and ambiguous-file backlog” in the “Input classification” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M01.06-C011-T10 · Contract review:** Review the “Input classification” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M01.06-C012 · Delivery

**Original checklist item:** Classify files as source input, generated output, excluded material or runtime state.

- [ ] **UC-M01.06-C012-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Input classification”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M01.06-C012-T02 · Change plan:** Break the source delivery for “Input classification” into concrete edit targets and reviewable outputs; keep the UC-M01.06 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M01.06-C012-T03 · Core artifact:** Create the “Input classification” model, schema or inventory that realizes this source instruction: Classify files as source input, generated output, excluded material or runtime state.
- [ ] **UC-M01.06-C012-T04 · Concrete realization:** Populate “Input classification” with one concrete worked case; map every required entity or field to its source and flag any unmapped entry.
- [ ] **UC-M01.06-C012-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Input classification” needed to preserve “Classification does not erase source provenance”; record an enforcement gap where only a model exists.
- [ ] **UC-M01.06-C012-T06 · Dependency connection:** Connect the “Input classification” implementation to archive admission, source ledgers and dependency resolution; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M01.06-C012-T07 · Resource behavior:** Account for “Classification rules and ambiguous-file backlog” in “Input classification”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M01.06-C012-T08 · Delivery check:** Run the smallest real “Input classification” path and its adverse fixture “A generated-looking source file is excluded without a reason”; retain actual output, state effects and final disposition.
- [ ] **UC-M01.06-C012-T09 · Patch review:** Review the “Input classification” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M01.06-C012-T10 · Delivery handoff:** Publish the “Input classification” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M01.06-C013 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Classification does not erase source provenance. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M01.06-C013-T01 · Named property:** Create a stable property/check name under this parent for “Input classification”; copy its required invariant exactly: “Classification does not erase source provenance”.
- [ ] **UC-M01.06-C013-T02 · Observable terms:** Define each term in the “Input classification” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M01.06-C013-T03 · Precondition set:** List the preconditions under which “Classification does not erase source provenance” must hold for “Input classification”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M01.06-C013-T04 · Transition coverage:** Map the “Input classification” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M01.06-C013-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Input classification”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M01.06-C013-T06 · Satisfying fixture:** Create a concrete “Input classification” case that satisfies “Classification does not erase source provenance”; record its expected observation before running the assertion or review.
- [ ] **UC-M01.06-C013-T07 · Violating fixture:** Create the source counterexample “A generated-looking source file is excluded without a reason” for “Input classification”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M01.06-C013-T08 · Enforcement evidence:** Exercise the “Input classification” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M01.06-C013-T09 · Regression linkage:** Link the “Input classification” property to changes in archive admission, source ledgers and dependency resolution; record which dependency or contract changes require rerunning it.
- [ ] **UC-M01.06-C013-T10 · Property disposition:** Compare the satisfying and violating “Input classification” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M01.06-C014 · Integration

**Original checklist item:** Integrate input classification with archive admission, source ledgers and dependency resolution; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M01.06-C014-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Input classification” across archive admission, source ledgers and dependency resolution; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M01.06-C014-T02 · Field mapping:** Map every “Input classification” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M01.06-C014-T03 · Prerequisite identities:** Record the actual prerequisites for “Input classification” (source dependency list: UC-M01.04); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M01.06-C014-T04 · Ownership agreement:** Specify who owns “Input classification” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M01.06-C014-T05 · Handoff implementation:** Connect “Input classification” through the mapped seam using the real adapter or explicit specification reference; preserve “Classification does not erase source provenance” across the handoff.
- [ ] **UC-M01.06-C014-T06 · Absent-input case:** Omit one required “Input classification” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M01.06-C014-T07 · Stale-input case:** Supply an outdated “Input classification” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M01.06-C014-T08 · Incompatible-input case:** Supply an incompatible “Input classification” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M01.06-C014-T09 · Valid integration trace:** Run a valid “Input classification” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M01.06-C014-T10 · Seam review:** Reconcile the “Input classification” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M01.06-C015 · Valid-case test

**Original checklist item:** Run a valid-path fixture for input classification; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M01.06-C015-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Input classification” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M01.06-C015-T02 · Expected-result oracle:** Specify the “Input classification” expected result independently of the implementation output; include the property “Classification does not erase source provenance” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M01.06-C015-T03 · Fixture material:** Create the concrete “Input classification” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M01.06-C015-T04 · Target preparation:** Prepare the “Input classification” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M01.06-C015-T05 · Initial-state record:** Record the initial “Input classification” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M01.06-C015-T06 · Valid-path execution:** Execute the “Input classification” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M01.06-C015-T07 · Outcome comparison:** Compare every declared “Input classification” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M01.06-C015-T08 · State and bounds check:** Inspect the “Input classification” ownership/state effects and actual use of “Classification rules and ambiguous-file backlog”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M01.06-C015-T09 · Repeatability check:** Repeat the same “Input classification” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M01.06-C015-T10 · Positive evidence:** Attach the “Input classification” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M01.06-C016 · Negative test

**Original checklist item:** Negative case: A generated-looking source file is excluded without a reason. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M01.06-C016-T01 · Adverse-case definition:** Create a test record for the exact “Input classification” source counterexample: “A generated-looking source file is excluded without a reason”; state which precondition or invariant it challenges.
- [ ] **UC-M01.06-C016-T02 · Safe fixture boundary:** Define the contained test boundary for “Input classification”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M01.06-C016-T03 · Valid control:** Construct a valid “Input classification” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M01.06-C016-T04 · Minimal adverse input:** Derive the “Input classification” adverse fixture from the control with the smallest documented change needed to reproduce “A generated-looking source file is excluded without a reason”; retain that change as reproducible data.
- [ ] **UC-M01.06-C016-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Input classification”; require “Classification does not erase source provenance” and forbid a false-success verdict.
- [ ] **UC-M01.06-C016-T06 · Adverse execution:** Exercise the “Input classification” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M01.06-C016-T07 · Effect inspection:** Inspect “Input classification” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M01.06-C016-T08 · Refusal versus failure:** Confirm the “Input classification” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M01.06-C016-T09 · Reset and retention:** Restore only the disposable “Input classification” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M01.06-C016-T10 · Negative regression:** Register the “Input classification” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M01.06-C017 · Change / failure test

**Original checklist item:** Exercise input classification when ingest is interrupted after some members have been copied but before reconciliation; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M01.06-C017-T01 · Scenario record:** Write the “Input classification” change/failure scenario exactly as supplied: ingest is interrupted after some members have been copied but before reconciliation; identify the property that must remain true: “Classification does not erase source provenance”.
- [ ] **UC-M01.06-C017-T02 · Baseline capture:** Create a known-valid “Input classification” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M01.06-C017-T03 · Injection map:** Locate the “Input classification” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M01.06-C017-T04 · Disposition oracle:** Define the legal intermediate and final “Input classification” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M01.06-C017-T05 · Controlled trigger:** Introduce the controlled “Input classification” scenario in the disposable fixture: ingest is interrupted after some members have been copied but before reconciliation; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M01.06-C017-T06 · Intermediate inspection:** Inspect the “Input classification” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M01.06-C017-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Input classification”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M01.06-C017-T08 · Stale-evidence cleanup:** Invalidate superseded “Input classification” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M01.06-C017-T09 · Repeat and compare:** Repeat the selected “Input classification” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M01.06-C017-T10 · Failure evidence:** Publish the “Input classification” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M01.06-C018 · Bounds

**Original checklist item:** Choose, document and test limits for classification rules and ambiguous-file backlog; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M01.06-C018-T01 · Quantity inventory:** Create a measurement inventory for “Input classification”: “Classification rules and ambiguous-file backlog”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M01.06-C018-T02 · Measurement method:** Choose how to observe each “Input classification” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M01.06-C018-T03 · Budget decision:** Select justified resource and input limits for “Input classification”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M01.06-C018-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Input classification” cases for “Classification rules and ambiguous-file backlog”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M01.06-C018-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Input classification” limit; preserve “Classification does not erase source provenance”.
- [ ] **UC-M01.06-C018-T06 · Normal measurement:** Run or review the normal “Input classification” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M01.06-C018-T07 · At-limit measurement:** Exercise the “Input classification” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M01.06-C018-T08 · Over-limit measurement:** Exercise the “Input classification” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M01.06-C018-T09 · Uncovered-scope report:** List the “Input classification” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M01.06-C018-T10 · Limit evidence:** Publish the selected “Input classification” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M01.06-C019 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for input classification with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M01.06-C019-T01 · Event inventory:** List the “Input classification” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M01.06-C019-T02 · Diagnostic schema:** Define nonsecret fields for “Input classification” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M01.06-C019-T03 · Failure mapping:** Map each documented “Input classification” refusal or error to a diagnostic outcome; include “A generated-looking source file is excluded without a reason” and prohibit conversion into a success message.
- [ ] **UC-M01.06-C019-T04 · Emission path:** Add the “Input classification” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M01.06-C019-T05 · Redaction check:** Test “Input classification” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M01.06-C019-T06 · Output budget:** Set and exercise bounded “Input classification” message size, rate and retention compatible with “Classification rules and ambiguous-file backlog”; define truncation behavior that preserves the final reason.
- [ ] **UC-M01.06-C019-T07 · Success/refusal fixtures:** Capture “Input classification” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M01.06-C019-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Input classification” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M01.06-C019-T09 · Operator review:** Read the “Input classification” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M01.06-C019-T10 · Diagnostic evidence:** Publish redacted “Input classification” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M01.06-C020 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for input classification; label unexecuted checks as untested.

- [ ] **UC-M01.06-C020-T01 · Evidence inventory:** List the “Input classification” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M01.06-C020-T02 · Artifact references:** Record the exact “Input classification” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M01.06-C020-T03 · Fixture references:** Attach the “Input classification” fixture IDs, input identities and oracle definition; preserve the source counterexample “A generated-looking source file is excluded without a reason” as a distinct evidence case.
- [ ] **UC-M01.06-C020-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Input classification”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M01.06-C020-T05 · Environment record:** Record the actual “Input classification” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M01.06-C020-T06 · Expected versus observed:** Pair every “Input classification” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M01.06-C020-T07 · Failure and limit records:** Attach “Input classification” change/failure and bounds evidence where required; include uncovered “Classification rules and ambiguous-file backlog” and unresolved violations of “Classification does not erase source provenance”.
- [ ] **UC-M01.06-C020-T08 · Evidence hygiene:** Check the “Input classification” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M01.06-C020-T09 · Reproduction review:** Have the “Input classification” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M01.06-C020-T10 · Acceptance linkage:** Link the “Input classification” evidence to its parent and UC-M01.06 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 03. Original-byte accounting

**Source delivery:** Record original size and cryptographic digest for accounted cargo.

**Source invariant:** Transformation never replaces the original byte identity in the ledger.

**Source negative case:** A renamed file keeps a digest of transformed rather than original bytes.

**Source bounded quantities:** Hashing bytes and per-ingest time.

### UC-M01.06-C021 · Contract

**Original checklist item:** Specify original-byte accounting inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M01.06-C021-T01 · Scope statement:** Draft the operation boundary for “Original-byte accounting” within Closed-world source and dependency inventory; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M01.06-C021-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Original-byte accounting”; record each producer, representation and missing-value meaning.
- [ ] **UC-M01.06-C021-T03 · Output inventory:** List the outputs of “Original-byte accounting” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M01.06-C021-T04 · Field dictionary:** Create a field-and-term dictionary for “Original-byte accounting”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M01.06-C021-T05 · Prerequisite contract:** Map “Original-byte accounting” to the source component prerequisites (UC-M01.04); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M01.06-C021-T06 · Authority map:** Identify who may produce, change and consume “Original-byte accounting”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M01.06-C021-T07 · Invariant clause:** Add a normative clause for “Original-byte accounting” that preserves “Transformation never replaces the original byte identity in the ledger”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M01.06-C021-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Original-byte accounting”; include the source counterexample “A renamed file keeps a digest of transformed rather than original bytes” and the intended safe disposition.
- [ ] **UC-M01.06-C021-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Hashing bytes and per-ingest time” in the “Original-byte accounting” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M01.06-C021-T10 · Contract review:** Review the “Original-byte accounting” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M01.06-C022 · Delivery

**Original checklist item:** Record original size and cryptographic digest for accounted cargo.

- [ ] **UC-M01.06-C022-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Original-byte accounting”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M01.06-C022-T02 · Change plan:** Break the source delivery for “Original-byte accounting” into concrete edit targets and reviewable outputs; keep the UC-M01.06 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M01.06-C022-T03 · Core artifact:** Create the “Original-byte accounting” model, schema or inventory that realizes this source instruction: Record original size and cryptographic digest for accounted cargo.
- [ ] **UC-M01.06-C022-T04 · Concrete realization:** Populate “Original-byte accounting” with one concrete worked case; map every required entity or field to its source and flag any unmapped entry.
- [ ] **UC-M01.06-C022-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Original-byte accounting” needed to preserve “Transformation never replaces the original byte identity in the ledger”; record an enforcement gap where only a model exists.
- [ ] **UC-M01.06-C022-T06 · Dependency connection:** Connect the “Original-byte accounting” implementation to archive admission, source ledgers and dependency resolution; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M01.06-C022-T07 · Resource behavior:** Account for “Hashing bytes and per-ingest time” in “Original-byte accounting”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M01.06-C022-T08 · Delivery check:** Run the smallest real “Original-byte accounting” path and its adverse fixture “A renamed file keeps a digest of transformed rather than original bytes”; retain actual output, state effects and final disposition.
- [ ] **UC-M01.06-C022-T09 · Patch review:** Review the “Original-byte accounting” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M01.06-C022-T10 · Delivery handoff:** Publish the “Original-byte accounting” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M01.06-C023 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Transformation never replaces the original byte identity in the ledger. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M01.06-C023-T01 · Named property:** Create a stable property/check name under this parent for “Original-byte accounting”; copy its required invariant exactly: “Transformation never replaces the original byte identity in the ledger”.
- [ ] **UC-M01.06-C023-T02 · Observable terms:** Define each term in the “Original-byte accounting” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M01.06-C023-T03 · Precondition set:** List the preconditions under which “Transformation never replaces the original byte identity in the ledger” must hold for “Original-byte accounting”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M01.06-C023-T04 · Transition coverage:** Map the “Original-byte accounting” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M01.06-C023-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Original-byte accounting”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M01.06-C023-T06 · Satisfying fixture:** Create a concrete “Original-byte accounting” case that satisfies “Transformation never replaces the original byte identity in the ledger”; record its expected observation before running the assertion or review.
- [ ] **UC-M01.06-C023-T07 · Violating fixture:** Create the source counterexample “A renamed file keeps a digest of transformed rather than original bytes” for “Original-byte accounting”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M01.06-C023-T08 · Enforcement evidence:** Exercise the “Original-byte accounting” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M01.06-C023-T09 · Regression linkage:** Link the “Original-byte accounting” property to changes in archive admission, source ledgers and dependency resolution; record which dependency or contract changes require rerunning it.
- [ ] **UC-M01.06-C023-T10 · Property disposition:** Compare the satisfying and violating “Original-byte accounting” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M01.06-C024 · Integration

**Original checklist item:** Integrate original-byte accounting with archive admission, source ledgers and dependency resolution; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M01.06-C024-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Original-byte accounting” across archive admission, source ledgers and dependency resolution; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M01.06-C024-T02 · Field mapping:** Map every “Original-byte accounting” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M01.06-C024-T03 · Prerequisite identities:** Record the actual prerequisites for “Original-byte accounting” (source dependency list: UC-M01.04); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M01.06-C024-T04 · Ownership agreement:** Specify who owns “Original-byte accounting” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M01.06-C024-T05 · Handoff implementation:** Connect “Original-byte accounting” through the mapped seam using the real adapter or explicit specification reference; preserve “Transformation never replaces the original byte identity in the ledger” across the handoff.
- [ ] **UC-M01.06-C024-T06 · Absent-input case:** Omit one required “Original-byte accounting” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M01.06-C024-T07 · Stale-input case:** Supply an outdated “Original-byte accounting” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M01.06-C024-T08 · Incompatible-input case:** Supply an incompatible “Original-byte accounting” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M01.06-C024-T09 · Valid integration trace:** Run a valid “Original-byte accounting” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M01.06-C024-T10 · Seam review:** Reconcile the “Original-byte accounting” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M01.06-C025 · Valid-case test

**Original checklist item:** Run a valid-path fixture for original-byte accounting; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M01.06-C025-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Original-byte accounting” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M01.06-C025-T02 · Expected-result oracle:** Specify the “Original-byte accounting” expected result independently of the implementation output; include the property “Transformation never replaces the original byte identity in the ledger” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M01.06-C025-T03 · Fixture material:** Create the concrete “Original-byte accounting” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M01.06-C025-T04 · Target preparation:** Prepare the “Original-byte accounting” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M01.06-C025-T05 · Initial-state record:** Record the initial “Original-byte accounting” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M01.06-C025-T06 · Valid-path execution:** Execute the “Original-byte accounting” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M01.06-C025-T07 · Outcome comparison:** Compare every declared “Original-byte accounting” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M01.06-C025-T08 · State and bounds check:** Inspect the “Original-byte accounting” ownership/state effects and actual use of “Hashing bytes and per-ingest time”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M01.06-C025-T09 · Repeatability check:** Repeat the same “Original-byte accounting” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M01.06-C025-T10 · Positive evidence:** Attach the “Original-byte accounting” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M01.06-C026 · Negative test

**Original checklist item:** Negative case: A renamed file keeps a digest of transformed rather than original bytes. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M01.06-C026-T01 · Adverse-case definition:** Create a test record for the exact “Original-byte accounting” source counterexample: “A renamed file keeps a digest of transformed rather than original bytes”; state which precondition or invariant it challenges.
- [ ] **UC-M01.06-C026-T02 · Safe fixture boundary:** Define the contained test boundary for “Original-byte accounting”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M01.06-C026-T03 · Valid control:** Construct a valid “Original-byte accounting” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M01.06-C026-T04 · Minimal adverse input:** Derive the “Original-byte accounting” adverse fixture from the control with the smallest documented change needed to reproduce “A renamed file keeps a digest of transformed rather than original bytes”; retain that change as reproducible data.
- [ ] **UC-M01.06-C026-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Original-byte accounting”; require “Transformation never replaces the original byte identity in the ledger” and forbid a false-success verdict.
- [ ] **UC-M01.06-C026-T06 · Adverse execution:** Exercise the “Original-byte accounting” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M01.06-C026-T07 · Effect inspection:** Inspect “Original-byte accounting” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M01.06-C026-T08 · Refusal versus failure:** Confirm the “Original-byte accounting” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M01.06-C026-T09 · Reset and retention:** Restore only the disposable “Original-byte accounting” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M01.06-C026-T10 · Negative regression:** Register the “Original-byte accounting” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M01.06-C027 · Change / failure test

**Original checklist item:** Exercise original-byte accounting when ingest is interrupted after some members have been copied but before reconciliation; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M01.06-C027-T01 · Scenario record:** Write the “Original-byte accounting” change/failure scenario exactly as supplied: ingest is interrupted after some members have been copied but before reconciliation; identify the property that must remain true: “Transformation never replaces the original byte identity in the ledger”.
- [ ] **UC-M01.06-C027-T02 · Baseline capture:** Create a known-valid “Original-byte accounting” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M01.06-C027-T03 · Injection map:** Locate the “Original-byte accounting” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M01.06-C027-T04 · Disposition oracle:** Define the legal intermediate and final “Original-byte accounting” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M01.06-C027-T05 · Controlled trigger:** Introduce the controlled “Original-byte accounting” scenario in the disposable fixture: ingest is interrupted after some members have been copied but before reconciliation; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M01.06-C027-T06 · Intermediate inspection:** Inspect the “Original-byte accounting” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M01.06-C027-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Original-byte accounting”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M01.06-C027-T08 · Stale-evidence cleanup:** Invalidate superseded “Original-byte accounting” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M01.06-C027-T09 · Repeat and compare:** Repeat the selected “Original-byte accounting” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M01.06-C027-T10 · Failure evidence:** Publish the “Original-byte accounting” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M01.06-C028 · Bounds

**Original checklist item:** Choose, document and test limits for hashing bytes and per-ingest time; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M01.06-C028-T01 · Quantity inventory:** Create a measurement inventory for “Original-byte accounting”: “Hashing bytes and per-ingest time”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M01.06-C028-T02 · Measurement method:** Choose how to observe each “Original-byte accounting” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M01.06-C028-T03 · Budget decision:** Select justified resource and input limits for “Original-byte accounting”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M01.06-C028-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Original-byte accounting” cases for “Hashing bytes and per-ingest time”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M01.06-C028-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Original-byte accounting” limit; preserve “Transformation never replaces the original byte identity in the ledger”.
- [ ] **UC-M01.06-C028-T06 · Normal measurement:** Run or review the normal “Original-byte accounting” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M01.06-C028-T07 · At-limit measurement:** Exercise the “Original-byte accounting” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M01.06-C028-T08 · Over-limit measurement:** Exercise the “Original-byte accounting” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M01.06-C028-T09 · Uncovered-scope report:** List the “Original-byte accounting” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M01.06-C028-T10 · Limit evidence:** Publish the selected “Original-byte accounting” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M01.06-C029 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for original-byte accounting with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M01.06-C029-T01 · Event inventory:** List the “Original-byte accounting” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M01.06-C029-T02 · Diagnostic schema:** Define nonsecret fields for “Original-byte accounting” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M01.06-C029-T03 · Failure mapping:** Map each documented “Original-byte accounting” refusal or error to a diagnostic outcome; include “A renamed file keeps a digest of transformed rather than original bytes” and prohibit conversion into a success message.
- [ ] **UC-M01.06-C029-T04 · Emission path:** Add the “Original-byte accounting” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M01.06-C029-T05 · Redaction check:** Test “Original-byte accounting” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M01.06-C029-T06 · Output budget:** Set and exercise bounded “Original-byte accounting” message size, rate and retention compatible with “Hashing bytes and per-ingest time”; define truncation behavior that preserves the final reason.
- [ ] **UC-M01.06-C029-T07 · Success/refusal fixtures:** Capture “Original-byte accounting” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M01.06-C029-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Original-byte accounting” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M01.06-C029-T09 · Operator review:** Read the “Original-byte accounting” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M01.06-C029-T10 · Diagnostic evidence:** Publish redacted “Original-byte accounting” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M01.06-C030 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for original-byte accounting; label unexecuted checks as untested.

- [ ] **UC-M01.06-C030-T01 · Evidence inventory:** List the “Original-byte accounting” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M01.06-C030-T02 · Artifact references:** Record the exact “Original-byte accounting” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M01.06-C030-T03 · Fixture references:** Attach the “Original-byte accounting” fixture IDs, input identities and oracle definition; preserve the source counterexample “A renamed file keeps a digest of transformed rather than original bytes” as a distinct evidence case.
- [ ] **UC-M01.06-C030-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Original-byte accounting”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M01.06-C030-T05 · Environment record:** Record the actual “Original-byte accounting” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M01.06-C030-T06 · Expected versus observed:** Pair every “Original-byte accounting” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M01.06-C030-T07 · Failure and limit records:** Attach “Original-byte accounting” change/failure and bounds evidence where required; include uncovered “Hashing bytes and per-ingest time” and unresolved violations of “Transformation never replaces the original byte identity in the ledger”.
- [ ] **UC-M01.06-C030-T08 · Evidence hygiene:** Check the “Original-byte accounting” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M01.06-C030-T09 · Reproduction review:** Have the “Original-byte accounting” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M01.06-C030-T10 · Acceptance linkage:** Link the “Original-byte accounting” evidence to its parent and UC-M01.06 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 04. Rejection ledger

**Source delivery:** Record rejected members with the policy rule and observable reason.

**Source invariant:** Rejection is visible rather than silently counted as success.

**Source negative case:** An unsafe archive path is dropped without a ledger entry.

**Source bounded quantities:** Rejection count and diagnostic record size.

### UC-M01.06-C031 · Contract

**Original checklist item:** Specify rejection ledger inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M01.06-C031-T01 · Scope statement:** Draft the operation boundary for “Rejection ledger” within Closed-world source and dependency inventory; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M01.06-C031-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Rejection ledger”; record each producer, representation and missing-value meaning.
- [ ] **UC-M01.06-C031-T03 · Output inventory:** List the outputs of “Rejection ledger” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M01.06-C031-T04 · Field dictionary:** Create a field-and-term dictionary for “Rejection ledger”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M01.06-C031-T05 · Prerequisite contract:** Map “Rejection ledger” to the source component prerequisites (UC-M01.04); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M01.06-C031-T06 · Authority map:** Identify who may produce, change and consume “Rejection ledger”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M01.06-C031-T07 · Invariant clause:** Add a normative clause for “Rejection ledger” that preserves “Rejection is visible rather than silently counted as success”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M01.06-C031-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Rejection ledger”; include the source counterexample “An unsafe archive path is dropped without a ledger entry” and the intended safe disposition.
- [ ] **UC-M01.06-C031-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Rejection count and diagnostic record size” in the “Rejection ledger” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M01.06-C031-T10 · Contract review:** Review the “Rejection ledger” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M01.06-C032 · Delivery

**Original checklist item:** Record rejected members with the policy rule and observable reason.

- [ ] **UC-M01.06-C032-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Rejection ledger”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M01.06-C032-T02 · Change plan:** Break the source delivery for “Rejection ledger” into concrete edit targets and reviewable outputs; keep the UC-M01.06 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M01.06-C032-T03 · Core artifact:** Create the “Rejection ledger” model, schema or inventory that realizes this source instruction: Record rejected members with the policy rule and observable reason.
- [ ] **UC-M01.06-C032-T04 · Concrete realization:** Populate “Rejection ledger” with one concrete worked case; map every required entity or field to its source and flag any unmapped entry.
- [ ] **UC-M01.06-C032-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Rejection ledger” needed to preserve “Rejection is visible rather than silently counted as success”; record an enforcement gap where only a model exists.
- [ ] **UC-M01.06-C032-T06 · Dependency connection:** Connect the “Rejection ledger” implementation to archive admission, source ledgers and dependency resolution; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M01.06-C032-T07 · Resource behavior:** Account for “Rejection count and diagnostic record size” in “Rejection ledger”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M01.06-C032-T08 · Delivery check:** Run the smallest real “Rejection ledger” path and its adverse fixture “An unsafe archive path is dropped without a ledger entry”; retain actual output, state effects and final disposition.
- [ ] **UC-M01.06-C032-T09 · Patch review:** Review the “Rejection ledger” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M01.06-C032-T10 · Delivery handoff:** Publish the “Rejection ledger” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M01.06-C033 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Rejection is visible rather than silently counted as success. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M01.06-C033-T01 · Named property:** Create a stable property/check name under this parent for “Rejection ledger”; copy its required invariant exactly: “Rejection is visible rather than silently counted as success”.
- [ ] **UC-M01.06-C033-T02 · Observable terms:** Define each term in the “Rejection ledger” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M01.06-C033-T03 · Precondition set:** List the preconditions under which “Rejection is visible rather than silently counted as success” must hold for “Rejection ledger”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M01.06-C033-T04 · Transition coverage:** Map the “Rejection ledger” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M01.06-C033-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Rejection ledger”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M01.06-C033-T06 · Satisfying fixture:** Create a concrete “Rejection ledger” case that satisfies “Rejection is visible rather than silently counted as success”; record its expected observation before running the assertion or review.
- [ ] **UC-M01.06-C033-T07 · Violating fixture:** Create the source counterexample “An unsafe archive path is dropped without a ledger entry” for “Rejection ledger”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M01.06-C033-T08 · Enforcement evidence:** Exercise the “Rejection ledger” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M01.06-C033-T09 · Regression linkage:** Link the “Rejection ledger” property to changes in archive admission, source ledgers and dependency resolution; record which dependency or contract changes require rerunning it.
- [ ] **UC-M01.06-C033-T10 · Property disposition:** Compare the satisfying and violating “Rejection ledger” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M01.06-C034 · Integration

**Original checklist item:** Integrate rejection ledger with archive admission, source ledgers and dependency resolution; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M01.06-C034-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Rejection ledger” across archive admission, source ledgers and dependency resolution; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M01.06-C034-T02 · Field mapping:** Map every “Rejection ledger” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M01.06-C034-T03 · Prerequisite identities:** Record the actual prerequisites for “Rejection ledger” (source dependency list: UC-M01.04); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M01.06-C034-T04 · Ownership agreement:** Specify who owns “Rejection ledger” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M01.06-C034-T05 · Handoff implementation:** Connect “Rejection ledger” through the mapped seam using the real adapter or explicit specification reference; preserve “Rejection is visible rather than silently counted as success” across the handoff.
- [ ] **UC-M01.06-C034-T06 · Absent-input case:** Omit one required “Rejection ledger” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M01.06-C034-T07 · Stale-input case:** Supply an outdated “Rejection ledger” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M01.06-C034-T08 · Incompatible-input case:** Supply an incompatible “Rejection ledger” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M01.06-C034-T09 · Valid integration trace:** Run a valid “Rejection ledger” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M01.06-C034-T10 · Seam review:** Reconcile the “Rejection ledger” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M01.06-C035 · Valid-case test

**Original checklist item:** Run a valid-path fixture for rejection ledger; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M01.06-C035-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Rejection ledger” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M01.06-C035-T02 · Expected-result oracle:** Specify the “Rejection ledger” expected result independently of the implementation output; include the property “Rejection is visible rather than silently counted as success” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M01.06-C035-T03 · Fixture material:** Create the concrete “Rejection ledger” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M01.06-C035-T04 · Target preparation:** Prepare the “Rejection ledger” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M01.06-C035-T05 · Initial-state record:** Record the initial “Rejection ledger” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M01.06-C035-T06 · Valid-path execution:** Execute the “Rejection ledger” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M01.06-C035-T07 · Outcome comparison:** Compare every declared “Rejection ledger” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M01.06-C035-T08 · State and bounds check:** Inspect the “Rejection ledger” ownership/state effects and actual use of “Rejection count and diagnostic record size”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M01.06-C035-T09 · Repeatability check:** Repeat the same “Rejection ledger” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M01.06-C035-T10 · Positive evidence:** Attach the “Rejection ledger” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M01.06-C036 · Negative test

**Original checklist item:** Negative case: An unsafe archive path is dropped without a ledger entry. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M01.06-C036-T01 · Adverse-case definition:** Create a test record for the exact “Rejection ledger” source counterexample: “An unsafe archive path is dropped without a ledger entry”; state which precondition or invariant it challenges.
- [ ] **UC-M01.06-C036-T02 · Safe fixture boundary:** Define the contained test boundary for “Rejection ledger”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M01.06-C036-T03 · Valid control:** Construct a valid “Rejection ledger” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M01.06-C036-T04 · Minimal adverse input:** Derive the “Rejection ledger” adverse fixture from the control with the smallest documented change needed to reproduce “An unsafe archive path is dropped without a ledger entry”; retain that change as reproducible data.
- [ ] **UC-M01.06-C036-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Rejection ledger”; require “Rejection is visible rather than silently counted as success” and forbid a false-success verdict.
- [ ] **UC-M01.06-C036-T06 · Adverse execution:** Exercise the “Rejection ledger” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M01.06-C036-T07 · Effect inspection:** Inspect “Rejection ledger” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M01.06-C036-T08 · Refusal versus failure:** Confirm the “Rejection ledger” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M01.06-C036-T09 · Reset and retention:** Restore only the disposable “Rejection ledger” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M01.06-C036-T10 · Negative regression:** Register the “Rejection ledger” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M01.06-C037 · Change / failure test

**Original checklist item:** Exercise rejection ledger when ingest is interrupted after some members have been copied but before reconciliation; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M01.06-C037-T01 · Scenario record:** Write the “Rejection ledger” change/failure scenario exactly as supplied: ingest is interrupted after some members have been copied but before reconciliation; identify the property that must remain true: “Rejection is visible rather than silently counted as success”.
- [ ] **UC-M01.06-C037-T02 · Baseline capture:** Create a known-valid “Rejection ledger” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M01.06-C037-T03 · Injection map:** Locate the “Rejection ledger” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M01.06-C037-T04 · Disposition oracle:** Define the legal intermediate and final “Rejection ledger” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M01.06-C037-T05 · Controlled trigger:** Introduce the controlled “Rejection ledger” scenario in the disposable fixture: ingest is interrupted after some members have been copied but before reconciliation; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M01.06-C037-T06 · Intermediate inspection:** Inspect the “Rejection ledger” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M01.06-C037-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Rejection ledger”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M01.06-C037-T08 · Stale-evidence cleanup:** Invalidate superseded “Rejection ledger” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M01.06-C037-T09 · Repeat and compare:** Repeat the selected “Rejection ledger” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M01.06-C037-T10 · Failure evidence:** Publish the “Rejection ledger” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M01.06-C038 · Bounds

**Original checklist item:** Choose, document and test limits for rejection count and diagnostic record size; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M01.06-C038-T01 · Quantity inventory:** Create a measurement inventory for “Rejection ledger”: “Rejection count and diagnostic record size”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M01.06-C038-T02 · Measurement method:** Choose how to observe each “Rejection ledger” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M01.06-C038-T03 · Budget decision:** Select justified resource and input limits for “Rejection ledger”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M01.06-C038-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Rejection ledger” cases for “Rejection count and diagnostic record size”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M01.06-C038-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Rejection ledger” limit; preserve “Rejection is visible rather than silently counted as success”.
- [ ] **UC-M01.06-C038-T06 · Normal measurement:** Run or review the normal “Rejection ledger” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M01.06-C038-T07 · At-limit measurement:** Exercise the “Rejection ledger” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M01.06-C038-T08 · Over-limit measurement:** Exercise the “Rejection ledger” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M01.06-C038-T09 · Uncovered-scope report:** List the “Rejection ledger” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M01.06-C038-T10 · Limit evidence:** Publish the selected “Rejection ledger” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M01.06-C039 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for rejection ledger with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M01.06-C039-T01 · Event inventory:** List the “Rejection ledger” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M01.06-C039-T02 · Diagnostic schema:** Define nonsecret fields for “Rejection ledger” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M01.06-C039-T03 · Failure mapping:** Map each documented “Rejection ledger” refusal or error to a diagnostic outcome; include “An unsafe archive path is dropped without a ledger entry” and prohibit conversion into a success message.
- [ ] **UC-M01.06-C039-T04 · Emission path:** Add the “Rejection ledger” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M01.06-C039-T05 · Redaction check:** Test “Rejection ledger” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M01.06-C039-T06 · Output budget:** Set and exercise bounded “Rejection ledger” message size, rate and retention compatible with “Rejection count and diagnostic record size”; define truncation behavior that preserves the final reason.
- [ ] **UC-M01.06-C039-T07 · Success/refusal fixtures:** Capture “Rejection ledger” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M01.06-C039-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Rejection ledger” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M01.06-C039-T09 · Operator review:** Read the “Rejection ledger” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M01.06-C039-T10 · Diagnostic evidence:** Publish redacted “Rejection ledger” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M01.06-C040 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for rejection ledger; label unexecuted checks as untested.

- [ ] **UC-M01.06-C040-T01 · Evidence inventory:** List the “Rejection ledger” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M01.06-C040-T02 · Artifact references:** Record the exact “Rejection ledger” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M01.06-C040-T03 · Fixture references:** Attach the “Rejection ledger” fixture IDs, input identities and oracle definition; preserve the source counterexample “An unsafe archive path is dropped without a ledger entry” as a distinct evidence case.
- [ ] **UC-M01.06-C040-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Rejection ledger”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M01.06-C040-T05 · Environment record:** Record the actual “Rejection ledger” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M01.06-C040-T06 · Expected versus observed:** Pair every “Rejection ledger” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M01.06-C040-T07 · Failure and limit records:** Attach “Rejection ledger” change/failure and bounds evidence where required; include uncovered “Rejection count and diagnostic record size” and unresolved violations of “Rejection is visible rather than silently counted as success”.
- [ ] **UC-M01.06-C040-T08 · Evidence hygiene:** Check the “Rejection ledger” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M01.06-C040-T09 · Reproduction review:** Have the “Rejection ledger” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M01.06-C040-T10 · Acceptance linkage:** Link the “Rejection ledger” evidence to its parent and UC-M01.06 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 05. Exclusion ledger

**Source delivery:** Record intentional exclusions and their effect on dependency closure.

**Source invariant:** Excluded dependencies cannot remain implicitly required.

**Source negative case:** A needed header is excluded by a broad ignore rule.

**Source bounded quantities:** Exclusion rules and impact-analysis fan-out.

### UC-M01.06-C041 · Contract

**Original checklist item:** Specify exclusion ledger inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M01.06-C041-T01 · Scope statement:** Draft the operation boundary for “Exclusion ledger” within Closed-world source and dependency inventory; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M01.06-C041-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Exclusion ledger”; record each producer, representation and missing-value meaning.
- [ ] **UC-M01.06-C041-T03 · Output inventory:** List the outputs of “Exclusion ledger” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M01.06-C041-T04 · Field dictionary:** Create a field-and-term dictionary for “Exclusion ledger”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M01.06-C041-T05 · Prerequisite contract:** Map “Exclusion ledger” to the source component prerequisites (UC-M01.04); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M01.06-C041-T06 · Authority map:** Identify who may produce, change and consume “Exclusion ledger”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M01.06-C041-T07 · Invariant clause:** Add a normative clause for “Exclusion ledger” that preserves “Excluded dependencies cannot remain implicitly required”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M01.06-C041-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Exclusion ledger”; include the source counterexample “A needed header is excluded by a broad ignore rule” and the intended safe disposition.
- [ ] **UC-M01.06-C041-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Exclusion rules and impact-analysis fan-out” in the “Exclusion ledger” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M01.06-C041-T10 · Contract review:** Review the “Exclusion ledger” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M01.06-C042 · Delivery

**Original checklist item:** Record intentional exclusions and their effect on dependency closure.

- [ ] **UC-M01.06-C042-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Exclusion ledger”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M01.06-C042-T02 · Change plan:** Break the source delivery for “Exclusion ledger” into concrete edit targets and reviewable outputs; keep the UC-M01.06 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M01.06-C042-T03 · Core artifact:** Create the “Exclusion ledger” model, schema or inventory that realizes this source instruction: Record intentional exclusions and their effect on dependency closure.
- [ ] **UC-M01.06-C042-T04 · Concrete realization:** Populate “Exclusion ledger” with one concrete worked case; map every required entity or field to its source and flag any unmapped entry.
- [ ] **UC-M01.06-C042-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Exclusion ledger” needed to preserve “Excluded dependencies cannot remain implicitly required”; record an enforcement gap where only a model exists.
- [ ] **UC-M01.06-C042-T06 · Dependency connection:** Connect the “Exclusion ledger” implementation to archive admission, source ledgers and dependency resolution; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M01.06-C042-T07 · Resource behavior:** Account for “Exclusion rules and impact-analysis fan-out” in “Exclusion ledger”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M01.06-C042-T08 · Delivery check:** Run the smallest real “Exclusion ledger” path and its adverse fixture “A needed header is excluded by a broad ignore rule”; retain actual output, state effects and final disposition.
- [ ] **UC-M01.06-C042-T09 · Patch review:** Review the “Exclusion ledger” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M01.06-C042-T10 · Delivery handoff:** Publish the “Exclusion ledger” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M01.06-C043 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Excluded dependencies cannot remain implicitly required. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M01.06-C043-T01 · Named property:** Create a stable property/check name under this parent for “Exclusion ledger”; copy its required invariant exactly: “Excluded dependencies cannot remain implicitly required”.
- [ ] **UC-M01.06-C043-T02 · Observable terms:** Define each term in the “Exclusion ledger” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M01.06-C043-T03 · Precondition set:** List the preconditions under which “Excluded dependencies cannot remain implicitly required” must hold for “Exclusion ledger”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M01.06-C043-T04 · Transition coverage:** Map the “Exclusion ledger” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M01.06-C043-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Exclusion ledger”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M01.06-C043-T06 · Satisfying fixture:** Create a concrete “Exclusion ledger” case that satisfies “Excluded dependencies cannot remain implicitly required”; record its expected observation before running the assertion or review.
- [ ] **UC-M01.06-C043-T07 · Violating fixture:** Create the source counterexample “A needed header is excluded by a broad ignore rule” for “Exclusion ledger”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M01.06-C043-T08 · Enforcement evidence:** Exercise the “Exclusion ledger” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M01.06-C043-T09 · Regression linkage:** Link the “Exclusion ledger” property to changes in archive admission, source ledgers and dependency resolution; record which dependency or contract changes require rerunning it.
- [ ] **UC-M01.06-C043-T10 · Property disposition:** Compare the satisfying and violating “Exclusion ledger” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M01.06-C044 · Integration

**Original checklist item:** Integrate exclusion ledger with archive admission, source ledgers and dependency resolution; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M01.06-C044-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Exclusion ledger” across archive admission, source ledgers and dependency resolution; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M01.06-C044-T02 · Field mapping:** Map every “Exclusion ledger” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M01.06-C044-T03 · Prerequisite identities:** Record the actual prerequisites for “Exclusion ledger” (source dependency list: UC-M01.04); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M01.06-C044-T04 · Ownership agreement:** Specify who owns “Exclusion ledger” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M01.06-C044-T05 · Handoff implementation:** Connect “Exclusion ledger” through the mapped seam using the real adapter or explicit specification reference; preserve “Excluded dependencies cannot remain implicitly required” across the handoff.
- [ ] **UC-M01.06-C044-T06 · Absent-input case:** Omit one required “Exclusion ledger” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M01.06-C044-T07 · Stale-input case:** Supply an outdated “Exclusion ledger” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M01.06-C044-T08 · Incompatible-input case:** Supply an incompatible “Exclusion ledger” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M01.06-C044-T09 · Valid integration trace:** Run a valid “Exclusion ledger” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M01.06-C044-T10 · Seam review:** Reconcile the “Exclusion ledger” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M01.06-C045 · Valid-case test

**Original checklist item:** Run a valid-path fixture for exclusion ledger; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M01.06-C045-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Exclusion ledger” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M01.06-C045-T02 · Expected-result oracle:** Specify the “Exclusion ledger” expected result independently of the implementation output; include the property “Excluded dependencies cannot remain implicitly required” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M01.06-C045-T03 · Fixture material:** Create the concrete “Exclusion ledger” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M01.06-C045-T04 · Target preparation:** Prepare the “Exclusion ledger” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M01.06-C045-T05 · Initial-state record:** Record the initial “Exclusion ledger” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M01.06-C045-T06 · Valid-path execution:** Execute the “Exclusion ledger” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M01.06-C045-T07 · Outcome comparison:** Compare every declared “Exclusion ledger” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M01.06-C045-T08 · State and bounds check:** Inspect the “Exclusion ledger” ownership/state effects and actual use of “Exclusion rules and impact-analysis fan-out”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M01.06-C045-T09 · Repeatability check:** Repeat the same “Exclusion ledger” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M01.06-C045-T10 · Positive evidence:** Attach the “Exclusion ledger” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M01.06-C046 · Negative test

**Original checklist item:** Negative case: A needed header is excluded by a broad ignore rule. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M01.06-C046-T01 · Adverse-case definition:** Create a test record for the exact “Exclusion ledger” source counterexample: “A needed header is excluded by a broad ignore rule”; state which precondition or invariant it challenges.
- [ ] **UC-M01.06-C046-T02 · Safe fixture boundary:** Define the contained test boundary for “Exclusion ledger”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M01.06-C046-T03 · Valid control:** Construct a valid “Exclusion ledger” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M01.06-C046-T04 · Minimal adverse input:** Derive the “Exclusion ledger” adverse fixture from the control with the smallest documented change needed to reproduce “A needed header is excluded by a broad ignore rule”; retain that change as reproducible data.
- [ ] **UC-M01.06-C046-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Exclusion ledger”; require “Excluded dependencies cannot remain implicitly required” and forbid a false-success verdict.
- [ ] **UC-M01.06-C046-T06 · Adverse execution:** Exercise the “Exclusion ledger” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M01.06-C046-T07 · Effect inspection:** Inspect “Exclusion ledger” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M01.06-C046-T08 · Refusal versus failure:** Confirm the “Exclusion ledger” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M01.06-C046-T09 · Reset and retention:** Restore only the disposable “Exclusion ledger” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M01.06-C046-T10 · Negative regression:** Register the “Exclusion ledger” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M01.06-C047 · Change / failure test

**Original checklist item:** Exercise exclusion ledger when ingest is interrupted after some members have been copied but before reconciliation; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M01.06-C047-T01 · Scenario record:** Write the “Exclusion ledger” change/failure scenario exactly as supplied: ingest is interrupted after some members have been copied but before reconciliation; identify the property that must remain true: “Excluded dependencies cannot remain implicitly required”.
- [ ] **UC-M01.06-C047-T02 · Baseline capture:** Create a known-valid “Exclusion ledger” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M01.06-C047-T03 · Injection map:** Locate the “Exclusion ledger” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M01.06-C047-T04 · Disposition oracle:** Define the legal intermediate and final “Exclusion ledger” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M01.06-C047-T05 · Controlled trigger:** Introduce the controlled “Exclusion ledger” scenario in the disposable fixture: ingest is interrupted after some members have been copied but before reconciliation; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M01.06-C047-T06 · Intermediate inspection:** Inspect the “Exclusion ledger” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M01.06-C047-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Exclusion ledger”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M01.06-C047-T08 · Stale-evidence cleanup:** Invalidate superseded “Exclusion ledger” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M01.06-C047-T09 · Repeat and compare:** Repeat the selected “Exclusion ledger” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M01.06-C047-T10 · Failure evidence:** Publish the “Exclusion ledger” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M01.06-C048 · Bounds

**Original checklist item:** Choose, document and test limits for exclusion rules and impact-analysis fan-out; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M01.06-C048-T01 · Quantity inventory:** Create a measurement inventory for “Exclusion ledger”: “Exclusion rules and impact-analysis fan-out”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M01.06-C048-T02 · Measurement method:** Choose how to observe each “Exclusion ledger” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M01.06-C048-T03 · Budget decision:** Select justified resource and input limits for “Exclusion ledger”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M01.06-C048-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Exclusion ledger” cases for “Exclusion rules and impact-analysis fan-out”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M01.06-C048-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Exclusion ledger” limit; preserve “Excluded dependencies cannot remain implicitly required”.
- [ ] **UC-M01.06-C048-T06 · Normal measurement:** Run or review the normal “Exclusion ledger” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M01.06-C048-T07 · At-limit measurement:** Exercise the “Exclusion ledger” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M01.06-C048-T08 · Over-limit measurement:** Exercise the “Exclusion ledger” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M01.06-C048-T09 · Uncovered-scope report:** List the “Exclusion ledger” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M01.06-C048-T10 · Limit evidence:** Publish the selected “Exclusion ledger” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M01.06-C049 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for exclusion ledger with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M01.06-C049-T01 · Event inventory:** List the “Exclusion ledger” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M01.06-C049-T02 · Diagnostic schema:** Define nonsecret fields for “Exclusion ledger” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M01.06-C049-T03 · Failure mapping:** Map each documented “Exclusion ledger” refusal or error to a diagnostic outcome; include “A needed header is excluded by a broad ignore rule” and prohibit conversion into a success message.
- [ ] **UC-M01.06-C049-T04 · Emission path:** Add the “Exclusion ledger” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M01.06-C049-T05 · Redaction check:** Test “Exclusion ledger” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M01.06-C049-T06 · Output budget:** Set and exercise bounded “Exclusion ledger” message size, rate and retention compatible with “Exclusion rules and impact-analysis fan-out”; define truncation behavior that preserves the final reason.
- [ ] **UC-M01.06-C049-T07 · Success/refusal fixtures:** Capture “Exclusion ledger” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M01.06-C049-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Exclusion ledger” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M01.06-C049-T09 · Operator review:** Read the “Exclusion ledger” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M01.06-C049-T10 · Diagnostic evidence:** Publish redacted “Exclusion ledger” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M01.06-C050 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for exclusion ledger; label unexecuted checks as untested.

- [ ] **UC-M01.06-C050-T01 · Evidence inventory:** List the “Exclusion ledger” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M01.06-C050-T02 · Artifact references:** Record the exact “Exclusion ledger” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M01.06-C050-T03 · Fixture references:** Attach the “Exclusion ledger” fixture IDs, input identities and oracle definition; preserve the source counterexample “A needed header is excluded by a broad ignore rule” as a distinct evidence case.
- [ ] **UC-M01.06-C050-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Exclusion ledger”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M01.06-C050-T05 · Environment record:** Record the actual “Exclusion ledger” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M01.06-C050-T06 · Expected versus observed:** Pair every “Exclusion ledger” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M01.06-C050-T07 · Failure and limit records:** Attach “Exclusion ledger” change/failure and bounds evidence where required; include uncovered “Exclusion rules and impact-analysis fan-out” and unresolved violations of “Excluded dependencies cannot remain implicitly required”.
- [ ] **UC-M01.06-C050-T08 · Evidence hygiene:** Check the “Exclusion ledger” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M01.06-C050-T09 · Reproduction review:** Have the “Exclusion ledger” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M01.06-C050-T10 · Acceptance linkage:** Link the “Exclusion ledger” evidence to its parent and UC-M01.06 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 06. Alias preservation

**Source delivery:** Map safe storage aliases back to original names and identities.

**Source invariant:** Distinct original members remain distinct after aliasing.

**Source negative case:** Case-colliding filenames map to one stored path.

**Source bounded quantities:** Alias length and collision search cost.

### UC-M01.06-C051 · Contract

**Original checklist item:** Specify alias preservation inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M01.06-C051-T01 · Scope statement:** Draft the operation boundary for “Alias preservation” within Closed-world source and dependency inventory; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M01.06-C051-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Alias preservation”; record each producer, representation and missing-value meaning.
- [ ] **UC-M01.06-C051-T03 · Output inventory:** List the outputs of “Alias preservation” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M01.06-C051-T04 · Field dictionary:** Create a field-and-term dictionary for “Alias preservation”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M01.06-C051-T05 · Prerequisite contract:** Map “Alias preservation” to the source component prerequisites (UC-M01.04); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M01.06-C051-T06 · Authority map:** Identify who may produce, change and consume “Alias preservation”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M01.06-C051-T07 · Invariant clause:** Add a normative clause for “Alias preservation” that preserves “Distinct original members remain distinct after aliasing”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M01.06-C051-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Alias preservation”; include the source counterexample “Case-colliding filenames map to one stored path” and the intended safe disposition.
- [ ] **UC-M01.06-C051-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Alias length and collision search cost” in the “Alias preservation” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M01.06-C051-T10 · Contract review:** Review the “Alias preservation” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M01.06-C052 · Delivery

**Original checklist item:** Map safe storage aliases back to original names and identities.

- [ ] **UC-M01.06-C052-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Alias preservation”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M01.06-C052-T02 · Change plan:** Break the source delivery for “Alias preservation” into concrete edit targets and reviewable outputs; keep the UC-M01.06 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M01.06-C052-T03 · Core artifact:** Create the “Alias preservation” model, schema or inventory that realizes this source instruction: Map safe storage aliases back to original names and identities.
- [ ] **UC-M01.06-C052-T04 · Concrete realization:** Populate “Alias preservation” with one concrete worked case; map every required entity or field to its source and flag any unmapped entry.
- [ ] **UC-M01.06-C052-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Alias preservation” needed to preserve “Distinct original members remain distinct after aliasing”; record an enforcement gap where only a model exists.
- [ ] **UC-M01.06-C052-T06 · Dependency connection:** Connect the “Alias preservation” implementation to archive admission, source ledgers and dependency resolution; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M01.06-C052-T07 · Resource behavior:** Account for “Alias length and collision search cost” in “Alias preservation”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M01.06-C052-T08 · Delivery check:** Run the smallest real “Alias preservation” path and its adverse fixture “Case-colliding filenames map to one stored path”; retain actual output, state effects and final disposition.
- [ ] **UC-M01.06-C052-T09 · Patch review:** Review the “Alias preservation” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M01.06-C052-T10 · Delivery handoff:** Publish the “Alias preservation” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M01.06-C053 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Distinct original members remain distinct after aliasing. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M01.06-C053-T01 · Named property:** Create a stable property/check name under this parent for “Alias preservation”; copy its required invariant exactly: “Distinct original members remain distinct after aliasing”.
- [ ] **UC-M01.06-C053-T02 · Observable terms:** Define each term in the “Alias preservation” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M01.06-C053-T03 · Precondition set:** List the preconditions under which “Distinct original members remain distinct after aliasing” must hold for “Alias preservation”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M01.06-C053-T04 · Transition coverage:** Map the “Alias preservation” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M01.06-C053-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Alias preservation”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M01.06-C053-T06 · Satisfying fixture:** Create a concrete “Alias preservation” case that satisfies “Distinct original members remain distinct after aliasing”; record its expected observation before running the assertion or review.
- [ ] **UC-M01.06-C053-T07 · Violating fixture:** Create the source counterexample “Case-colliding filenames map to one stored path” for “Alias preservation”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M01.06-C053-T08 · Enforcement evidence:** Exercise the “Alias preservation” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M01.06-C053-T09 · Regression linkage:** Link the “Alias preservation” property to changes in archive admission, source ledgers and dependency resolution; record which dependency or contract changes require rerunning it.
- [ ] **UC-M01.06-C053-T10 · Property disposition:** Compare the satisfying and violating “Alias preservation” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M01.06-C054 · Integration

**Original checklist item:** Integrate alias preservation with archive admission, source ledgers and dependency resolution; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M01.06-C054-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Alias preservation” across archive admission, source ledgers and dependency resolution; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M01.06-C054-T02 · Field mapping:** Map every “Alias preservation” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M01.06-C054-T03 · Prerequisite identities:** Record the actual prerequisites for “Alias preservation” (source dependency list: UC-M01.04); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M01.06-C054-T04 · Ownership agreement:** Specify who owns “Alias preservation” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M01.06-C054-T05 · Handoff implementation:** Connect “Alias preservation” through the mapped seam using the real adapter or explicit specification reference; preserve “Distinct original members remain distinct after aliasing” across the handoff.
- [ ] **UC-M01.06-C054-T06 · Absent-input case:** Omit one required “Alias preservation” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M01.06-C054-T07 · Stale-input case:** Supply an outdated “Alias preservation” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M01.06-C054-T08 · Incompatible-input case:** Supply an incompatible “Alias preservation” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M01.06-C054-T09 · Valid integration trace:** Run a valid “Alias preservation” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M01.06-C054-T10 · Seam review:** Reconcile the “Alias preservation” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M01.06-C055 · Valid-case test

**Original checklist item:** Run a valid-path fixture for alias preservation; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M01.06-C055-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Alias preservation” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M01.06-C055-T02 · Expected-result oracle:** Specify the “Alias preservation” expected result independently of the implementation output; include the property “Distinct original members remain distinct after aliasing” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M01.06-C055-T03 · Fixture material:** Create the concrete “Alias preservation” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M01.06-C055-T04 · Target preparation:** Prepare the “Alias preservation” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M01.06-C055-T05 · Initial-state record:** Record the initial “Alias preservation” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M01.06-C055-T06 · Valid-path execution:** Execute the “Alias preservation” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M01.06-C055-T07 · Outcome comparison:** Compare every declared “Alias preservation” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M01.06-C055-T08 · State and bounds check:** Inspect the “Alias preservation” ownership/state effects and actual use of “Alias length and collision search cost”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M01.06-C055-T09 · Repeatability check:** Repeat the same “Alias preservation” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M01.06-C055-T10 · Positive evidence:** Attach the “Alias preservation” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M01.06-C056 · Negative test

**Original checklist item:** Negative case: Case-colliding filenames map to one stored path. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M01.06-C056-T01 · Adverse-case definition:** Create a test record for the exact “Alias preservation” source counterexample: “Case-colliding filenames map to one stored path”; state which precondition or invariant it challenges.
- [ ] **UC-M01.06-C056-T02 · Safe fixture boundary:** Define the contained test boundary for “Alias preservation”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M01.06-C056-T03 · Valid control:** Construct a valid “Alias preservation” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M01.06-C056-T04 · Minimal adverse input:** Derive the “Alias preservation” adverse fixture from the control with the smallest documented change needed to reproduce “Case-colliding filenames map to one stored path”; retain that change as reproducible data.
- [ ] **UC-M01.06-C056-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Alias preservation”; require “Distinct original members remain distinct after aliasing” and forbid a false-success verdict.
- [ ] **UC-M01.06-C056-T06 · Adverse execution:** Exercise the “Alias preservation” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M01.06-C056-T07 · Effect inspection:** Inspect “Alias preservation” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M01.06-C056-T08 · Refusal versus failure:** Confirm the “Alias preservation” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M01.06-C056-T09 · Reset and retention:** Restore only the disposable “Alias preservation” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M01.06-C056-T10 · Negative regression:** Register the “Alias preservation” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M01.06-C057 · Change / failure test

**Original checklist item:** Exercise alias preservation when ingest is interrupted after some members have been copied but before reconciliation; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M01.06-C057-T01 · Scenario record:** Write the “Alias preservation” change/failure scenario exactly as supplied: ingest is interrupted after some members have been copied but before reconciliation; identify the property that must remain true: “Distinct original members remain distinct after aliasing”.
- [ ] **UC-M01.06-C057-T02 · Baseline capture:** Create a known-valid “Alias preservation” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M01.06-C057-T03 · Injection map:** Locate the “Alias preservation” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M01.06-C057-T04 · Disposition oracle:** Define the legal intermediate and final “Alias preservation” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M01.06-C057-T05 · Controlled trigger:** Introduce the controlled “Alias preservation” scenario in the disposable fixture: ingest is interrupted after some members have been copied but before reconciliation; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M01.06-C057-T06 · Intermediate inspection:** Inspect the “Alias preservation” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M01.06-C057-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Alias preservation”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M01.06-C057-T08 · Stale-evidence cleanup:** Invalidate superseded “Alias preservation” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M01.06-C057-T09 · Repeat and compare:** Repeat the selected “Alias preservation” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M01.06-C057-T10 · Failure evidence:** Publish the “Alias preservation” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M01.06-C058 · Bounds

**Original checklist item:** Choose, document and test limits for alias length and collision search cost; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M01.06-C058-T01 · Quantity inventory:** Create a measurement inventory for “Alias preservation”: “Alias length and collision search cost”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M01.06-C058-T02 · Measurement method:** Choose how to observe each “Alias preservation” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M01.06-C058-T03 · Budget decision:** Select justified resource and input limits for “Alias preservation”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M01.06-C058-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Alias preservation” cases for “Alias length and collision search cost”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M01.06-C058-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Alias preservation” limit; preserve “Distinct original members remain distinct after aliasing”.
- [ ] **UC-M01.06-C058-T06 · Normal measurement:** Run or review the normal “Alias preservation” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M01.06-C058-T07 · At-limit measurement:** Exercise the “Alias preservation” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M01.06-C058-T08 · Over-limit measurement:** Exercise the “Alias preservation” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M01.06-C058-T09 · Uncovered-scope report:** List the “Alias preservation” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M01.06-C058-T10 · Limit evidence:** Publish the selected “Alias preservation” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M01.06-C059 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for alias preservation with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M01.06-C059-T01 · Event inventory:** List the “Alias preservation” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M01.06-C059-T02 · Diagnostic schema:** Define nonsecret fields for “Alias preservation” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M01.06-C059-T03 · Failure mapping:** Map each documented “Alias preservation” refusal or error to a diagnostic outcome; include “Case-colliding filenames map to one stored path” and prohibit conversion into a success message.
- [ ] **UC-M01.06-C059-T04 · Emission path:** Add the “Alias preservation” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M01.06-C059-T05 · Redaction check:** Test “Alias preservation” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M01.06-C059-T06 · Output budget:** Set and exercise bounded “Alias preservation” message size, rate and retention compatible with “Alias length and collision search cost”; define truncation behavior that preserves the final reason.
- [ ] **UC-M01.06-C059-T07 · Success/refusal fixtures:** Capture “Alias preservation” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M01.06-C059-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Alias preservation” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M01.06-C059-T09 · Operator review:** Read the “Alias preservation” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M01.06-C059-T10 · Diagnostic evidence:** Publish redacted “Alias preservation” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M01.06-C060 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for alias preservation; label unexecuted checks as untested.

- [ ] **UC-M01.06-C060-T01 · Evidence inventory:** List the “Alias preservation” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M01.06-C060-T02 · Artifact references:** Record the exact “Alias preservation” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M01.06-C060-T03 · Fixture references:** Attach the “Alias preservation” fixture IDs, input identities and oracle definition; preserve the source counterexample “Case-colliding filenames map to one stored path” as a distinct evidence case.
- [ ] **UC-M01.06-C060-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Alias preservation”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M01.06-C060-T05 · Environment record:** Record the actual “Alias preservation” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M01.06-C060-T06 · Expected versus observed:** Pair every “Alias preservation” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M01.06-C060-T07 · Failure and limit records:** Attach “Alias preservation” change/failure and bounds evidence where required; include uncovered “Alias length and collision search cost” and unresolved violations of “Distinct original members remain distinct after aliasing”.
- [ ] **UC-M01.06-C060-T08 · Evidence hygiene:** Check the “Alias preservation” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M01.06-C060-T09 · Reproduction review:** Have the “Alias preservation” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M01.06-C060-T10 · Acceptance linkage:** Link the “Alias preservation” evidence to its parent and UC-M01.06 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 07. Dependency discovery

**Source delivery:** Resolve declared and detected source dependencies against the closed inventory.

**Source invariant:** Every required input is present or explicitly unresolved.

**Source negative case:** A build reaches outside the inventoried tree for a library.

**Source bounded quantities:** Dependency edge count and traversal depth.

### UC-M01.06-C061 · Contract

**Original checklist item:** Specify dependency discovery inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M01.06-C061-T01 · Scope statement:** Draft the operation boundary for “Dependency discovery” within Closed-world source and dependency inventory; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M01.06-C061-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Dependency discovery”; record each producer, representation and missing-value meaning.
- [ ] **UC-M01.06-C061-T03 · Output inventory:** List the outputs of “Dependency discovery” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M01.06-C061-T04 · Field dictionary:** Create a field-and-term dictionary for “Dependency discovery”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M01.06-C061-T05 · Prerequisite contract:** Map “Dependency discovery” to the source component prerequisites (UC-M01.04); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M01.06-C061-T06 · Authority map:** Identify who may produce, change and consume “Dependency discovery”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M01.06-C061-T07 · Invariant clause:** Add a normative clause for “Dependency discovery” that preserves “Every required input is present or explicitly unresolved”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M01.06-C061-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Dependency discovery”; include the source counterexample “A build reaches outside the inventoried tree for a library” and the intended safe disposition.
- [ ] **UC-M01.06-C061-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Dependency edge count and traversal depth” in the “Dependency discovery” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M01.06-C061-T10 · Contract review:** Review the “Dependency discovery” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M01.06-C062 · Delivery

**Original checklist item:** Resolve declared and detected source dependencies against the closed inventory.

- [ ] **UC-M01.06-C062-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Dependency discovery”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M01.06-C062-T02 · Change plan:** Break the source delivery for “Dependency discovery” into concrete edit targets and reviewable outputs; keep the UC-M01.06 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M01.06-C062-T03 · Core artifact:** Implement the smallest selected-profile change for “Dependency discovery” that realizes this source instruction: Resolve declared and detected source dependencies against the closed inventory.
- [ ] **UC-M01.06-C062-T04 · Concrete realization:** Trace “Dependency discovery” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M01.06-C062-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Dependency discovery” needed to preserve “Every required input is present or explicitly unresolved”; record an enforcement gap where only a model exists.
- [ ] **UC-M01.06-C062-T06 · Dependency connection:** Connect the “Dependency discovery” implementation to archive admission, source ledgers and dependency resolution; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M01.06-C062-T07 · Resource behavior:** Account for “Dependency edge count and traversal depth” in “Dependency discovery”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M01.06-C062-T08 · Delivery check:** Run the smallest real “Dependency discovery” path and its adverse fixture “A build reaches outside the inventoried tree for a library”; retain actual output, state effects and final disposition.
- [ ] **UC-M01.06-C062-T09 · Patch review:** Review the “Dependency discovery” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M01.06-C062-T10 · Delivery handoff:** Publish the “Dependency discovery” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M01.06-C063 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Every required input is present or explicitly unresolved. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M01.06-C063-T01 · Named property:** Create a stable property/check name under this parent for “Dependency discovery”; copy its required invariant exactly: “Every required input is present or explicitly unresolved”.
- [ ] **UC-M01.06-C063-T02 · Observable terms:** Define each term in the “Dependency discovery” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M01.06-C063-T03 · Precondition set:** List the preconditions under which “Every required input is present or explicitly unresolved” must hold for “Dependency discovery”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M01.06-C063-T04 · Transition coverage:** Map the “Dependency discovery” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M01.06-C063-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Dependency discovery”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M01.06-C063-T06 · Satisfying fixture:** Create a concrete “Dependency discovery” case that satisfies “Every required input is present or explicitly unresolved”; record its expected observation before running the assertion or review.
- [ ] **UC-M01.06-C063-T07 · Violating fixture:** Create the source counterexample “A build reaches outside the inventoried tree for a library” for “Dependency discovery”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M01.06-C063-T08 · Enforcement evidence:** Exercise the “Dependency discovery” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M01.06-C063-T09 · Regression linkage:** Link the “Dependency discovery” property to changes in archive admission, source ledgers and dependency resolution; record which dependency or contract changes require rerunning it.
- [ ] **UC-M01.06-C063-T10 · Property disposition:** Compare the satisfying and violating “Dependency discovery” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M01.06-C064 · Integration

**Original checklist item:** Integrate dependency discovery with archive admission, source ledgers and dependency resolution; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M01.06-C064-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Dependency discovery” across archive admission, source ledgers and dependency resolution; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M01.06-C064-T02 · Field mapping:** Map every “Dependency discovery” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M01.06-C064-T03 · Prerequisite identities:** Record the actual prerequisites for “Dependency discovery” (source dependency list: UC-M01.04); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M01.06-C064-T04 · Ownership agreement:** Specify who owns “Dependency discovery” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M01.06-C064-T05 · Handoff implementation:** Connect “Dependency discovery” through the mapped seam using the real adapter or explicit specification reference; preserve “Every required input is present or explicitly unresolved” across the handoff.
- [ ] **UC-M01.06-C064-T06 · Absent-input case:** Omit one required “Dependency discovery” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M01.06-C064-T07 · Stale-input case:** Supply an outdated “Dependency discovery” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M01.06-C064-T08 · Incompatible-input case:** Supply an incompatible “Dependency discovery” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M01.06-C064-T09 · Valid integration trace:** Run a valid “Dependency discovery” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M01.06-C064-T10 · Seam review:** Reconcile the “Dependency discovery” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M01.06-C065 · Valid-case test

**Original checklist item:** Run a valid-path fixture for dependency discovery; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M01.06-C065-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Dependency discovery” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M01.06-C065-T02 · Expected-result oracle:** Specify the “Dependency discovery” expected result independently of the implementation output; include the property “Every required input is present or explicitly unresolved” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M01.06-C065-T03 · Fixture material:** Create the concrete “Dependency discovery” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M01.06-C065-T04 · Target preparation:** Prepare the “Dependency discovery” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M01.06-C065-T05 · Initial-state record:** Record the initial “Dependency discovery” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M01.06-C065-T06 · Valid-path execution:** Execute the “Dependency discovery” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M01.06-C065-T07 · Outcome comparison:** Compare every declared “Dependency discovery” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M01.06-C065-T08 · State and bounds check:** Inspect the “Dependency discovery” ownership/state effects and actual use of “Dependency edge count and traversal depth”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M01.06-C065-T09 · Repeatability check:** Repeat the same “Dependency discovery” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M01.06-C065-T10 · Positive evidence:** Attach the “Dependency discovery” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M01.06-C066 · Negative test

**Original checklist item:** Negative case: A build reaches outside the inventoried tree for a library. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M01.06-C066-T01 · Adverse-case definition:** Create a test record for the exact “Dependency discovery” source counterexample: “A build reaches outside the inventoried tree for a library”; state which precondition or invariant it challenges.
- [ ] **UC-M01.06-C066-T02 · Safe fixture boundary:** Define the contained test boundary for “Dependency discovery”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M01.06-C066-T03 · Valid control:** Construct a valid “Dependency discovery” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M01.06-C066-T04 · Minimal adverse input:** Derive the “Dependency discovery” adverse fixture from the control with the smallest documented change needed to reproduce “A build reaches outside the inventoried tree for a library”; retain that change as reproducible data.
- [ ] **UC-M01.06-C066-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Dependency discovery”; require “Every required input is present or explicitly unresolved” and forbid a false-success verdict.
- [ ] **UC-M01.06-C066-T06 · Adverse execution:** Exercise the “Dependency discovery” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M01.06-C066-T07 · Effect inspection:** Inspect “Dependency discovery” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M01.06-C066-T08 · Refusal versus failure:** Confirm the “Dependency discovery” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M01.06-C066-T09 · Reset and retention:** Restore only the disposable “Dependency discovery” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M01.06-C066-T10 · Negative regression:** Register the “Dependency discovery” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M01.06-C067 · Change / failure test

**Original checklist item:** Exercise dependency discovery when ingest is interrupted after some members have been copied but before reconciliation; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M01.06-C067-T01 · Scenario record:** Write the “Dependency discovery” change/failure scenario exactly as supplied: ingest is interrupted after some members have been copied but before reconciliation; identify the property that must remain true: “Every required input is present or explicitly unresolved”.
- [ ] **UC-M01.06-C067-T02 · Baseline capture:** Create a known-valid “Dependency discovery” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M01.06-C067-T03 · Injection map:** Locate the “Dependency discovery” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M01.06-C067-T04 · Disposition oracle:** Define the legal intermediate and final “Dependency discovery” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M01.06-C067-T05 · Controlled trigger:** Introduce the controlled “Dependency discovery” scenario in the disposable fixture: ingest is interrupted after some members have been copied but before reconciliation; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M01.06-C067-T06 · Intermediate inspection:** Inspect the “Dependency discovery” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M01.06-C067-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Dependency discovery”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M01.06-C067-T08 · Stale-evidence cleanup:** Invalidate superseded “Dependency discovery” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M01.06-C067-T09 · Repeat and compare:** Repeat the selected “Dependency discovery” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M01.06-C067-T10 · Failure evidence:** Publish the “Dependency discovery” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M01.06-C068 · Bounds

**Original checklist item:** Choose, document and test limits for dependency edge count and traversal depth; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M01.06-C068-T01 · Quantity inventory:** Create a measurement inventory for “Dependency discovery”: “Dependency edge count and traversal depth”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M01.06-C068-T02 · Measurement method:** Choose how to observe each “Dependency discovery” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M01.06-C068-T03 · Budget decision:** Select justified resource and input limits for “Dependency discovery”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M01.06-C068-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Dependency discovery” cases for “Dependency edge count and traversal depth”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M01.06-C068-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Dependency discovery” limit; preserve “Every required input is present or explicitly unresolved”.
- [ ] **UC-M01.06-C068-T06 · Normal measurement:** Run or review the normal “Dependency discovery” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M01.06-C068-T07 · At-limit measurement:** Exercise the “Dependency discovery” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M01.06-C068-T08 · Over-limit measurement:** Exercise the “Dependency discovery” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M01.06-C068-T09 · Uncovered-scope report:** List the “Dependency discovery” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M01.06-C068-T10 · Limit evidence:** Publish the selected “Dependency discovery” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M01.06-C069 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for dependency discovery with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M01.06-C069-T01 · Event inventory:** List the “Dependency discovery” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M01.06-C069-T02 · Diagnostic schema:** Define nonsecret fields for “Dependency discovery” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M01.06-C069-T03 · Failure mapping:** Map each documented “Dependency discovery” refusal or error to a diagnostic outcome; include “A build reaches outside the inventoried tree for a library” and prohibit conversion into a success message.
- [ ] **UC-M01.06-C069-T04 · Emission path:** Add the “Dependency discovery” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M01.06-C069-T05 · Redaction check:** Test “Dependency discovery” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M01.06-C069-T06 · Output budget:** Set and exercise bounded “Dependency discovery” message size, rate and retention compatible with “Dependency edge count and traversal depth”; define truncation behavior that preserves the final reason.
- [ ] **UC-M01.06-C069-T07 · Success/refusal fixtures:** Capture “Dependency discovery” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M01.06-C069-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Dependency discovery” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M01.06-C069-T09 · Operator review:** Read the “Dependency discovery” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M01.06-C069-T10 · Diagnostic evidence:** Publish redacted “Dependency discovery” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M01.06-C070 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for dependency discovery; label unexecuted checks as untested.

- [ ] **UC-M01.06-C070-T01 · Evidence inventory:** List the “Dependency discovery” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M01.06-C070-T02 · Artifact references:** Record the exact “Dependency discovery” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M01.06-C070-T03 · Fixture references:** Attach the “Dependency discovery” fixture IDs, input identities and oracle definition; preserve the source counterexample “A build reaches outside the inventoried tree for a library” as a distinct evidence case.
- [ ] **UC-M01.06-C070-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Dependency discovery”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M01.06-C070-T05 · Environment record:** Record the actual “Dependency discovery” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M01.06-C070-T06 · Expected versus observed:** Pair every “Dependency discovery” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M01.06-C070-T07 · Failure and limit records:** Attach “Dependency discovery” change/failure and bounds evidence where required; include uncovered “Dependency edge count and traversal depth” and unresolved violations of “Every required input is present or explicitly unresolved”.
- [ ] **UC-M01.06-C070-T08 · Evidence hygiene:** Check the “Dependency discovery” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M01.06-C070-T09 · Reproduction review:** Have the “Dependency discovery” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M01.06-C070-T10 · Acceptance linkage:** Link the “Dependency discovery” evidence to its parent and UC-M01.06 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 08. Nested input handling

**Source delivery:** Define how nested archives and imported trees are counted and inspected.

**Source invariant:** Nested material cannot bypass accounting limits.

**Source negative case:** A nested archive hides additional required files.

**Source bounded quantities:** Nesting depth and cumulative expanded bytes.

### UC-M01.06-C071 · Contract

**Original checklist item:** Specify nested input handling inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M01.06-C071-T01 · Scope statement:** Draft the operation boundary for “Nested input handling” within Closed-world source and dependency inventory; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M01.06-C071-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Nested input handling”; record each producer, representation and missing-value meaning.
- [ ] **UC-M01.06-C071-T03 · Output inventory:** List the outputs of “Nested input handling” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M01.06-C071-T04 · Field dictionary:** Create a field-and-term dictionary for “Nested input handling”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M01.06-C071-T05 · Prerequisite contract:** Map “Nested input handling” to the source component prerequisites (UC-M01.04); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M01.06-C071-T06 · Authority map:** Identify who may produce, change and consume “Nested input handling”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M01.06-C071-T07 · Invariant clause:** Add a normative clause for “Nested input handling” that preserves “Nested material cannot bypass accounting limits”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M01.06-C071-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Nested input handling”; include the source counterexample “A nested archive hides additional required files” and the intended safe disposition.
- [ ] **UC-M01.06-C071-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Nesting depth and cumulative expanded bytes” in the “Nested input handling” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M01.06-C071-T10 · Contract review:** Review the “Nested input handling” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M01.06-C072 · Delivery

**Original checklist item:** Define how nested archives and imported trees are counted and inspected.

- [ ] **UC-M01.06-C072-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Nested input handling”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M01.06-C072-T02 · Change plan:** Break the source delivery for “Nested input handling” into concrete edit targets and reviewable outputs; keep the UC-M01.06 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M01.06-C072-T03 · Core artifact:** Create the “Nested input handling” model, schema or inventory that realizes this source instruction: Define how nested archives and imported trees are counted and inspected.
- [ ] **UC-M01.06-C072-T04 · Concrete realization:** Populate “Nested input handling” with one concrete worked case; map every required entity or field to its source and flag any unmapped entry.
- [ ] **UC-M01.06-C072-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Nested input handling” needed to preserve “Nested material cannot bypass accounting limits”; record an enforcement gap where only a model exists.
- [ ] **UC-M01.06-C072-T06 · Dependency connection:** Connect the “Nested input handling” implementation to archive admission, source ledgers and dependency resolution; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M01.06-C072-T07 · Resource behavior:** Account for “Nesting depth and cumulative expanded bytes” in “Nested input handling”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M01.06-C072-T08 · Delivery check:** Run the smallest real “Nested input handling” path and its adverse fixture “A nested archive hides additional required files”; retain actual output, state effects and final disposition.
- [ ] **UC-M01.06-C072-T09 · Patch review:** Review the “Nested input handling” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M01.06-C072-T10 · Delivery handoff:** Publish the “Nested input handling” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M01.06-C073 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Nested material cannot bypass accounting limits. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M01.06-C073-T01 · Named property:** Create a stable property/check name under this parent for “Nested input handling”; copy its required invariant exactly: “Nested material cannot bypass accounting limits”.
- [ ] **UC-M01.06-C073-T02 · Observable terms:** Define each term in the “Nested input handling” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M01.06-C073-T03 · Precondition set:** List the preconditions under which “Nested material cannot bypass accounting limits” must hold for “Nested input handling”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M01.06-C073-T04 · Transition coverage:** Map the “Nested input handling” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M01.06-C073-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Nested input handling”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M01.06-C073-T06 · Satisfying fixture:** Create a concrete “Nested input handling” case that satisfies “Nested material cannot bypass accounting limits”; record its expected observation before running the assertion or review.
- [ ] **UC-M01.06-C073-T07 · Violating fixture:** Create the source counterexample “A nested archive hides additional required files” for “Nested input handling”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M01.06-C073-T08 · Enforcement evidence:** Exercise the “Nested input handling” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M01.06-C073-T09 · Regression linkage:** Link the “Nested input handling” property to changes in archive admission, source ledgers and dependency resolution; record which dependency or contract changes require rerunning it.
- [ ] **UC-M01.06-C073-T10 · Property disposition:** Compare the satisfying and violating “Nested input handling” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M01.06-C074 · Integration

**Original checklist item:** Integrate nested input handling with archive admission, source ledgers and dependency resolution; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M01.06-C074-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Nested input handling” across archive admission, source ledgers and dependency resolution; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M01.06-C074-T02 · Field mapping:** Map every “Nested input handling” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M01.06-C074-T03 · Prerequisite identities:** Record the actual prerequisites for “Nested input handling” (source dependency list: UC-M01.04); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M01.06-C074-T04 · Ownership agreement:** Specify who owns “Nested input handling” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M01.06-C074-T05 · Handoff implementation:** Connect “Nested input handling” through the mapped seam using the real adapter or explicit specification reference; preserve “Nested material cannot bypass accounting limits” across the handoff.
- [ ] **UC-M01.06-C074-T06 · Absent-input case:** Omit one required “Nested input handling” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M01.06-C074-T07 · Stale-input case:** Supply an outdated “Nested input handling” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M01.06-C074-T08 · Incompatible-input case:** Supply an incompatible “Nested input handling” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M01.06-C074-T09 · Valid integration trace:** Run a valid “Nested input handling” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M01.06-C074-T10 · Seam review:** Reconcile the “Nested input handling” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M01.06-C075 · Valid-case test

**Original checklist item:** Run a valid-path fixture for nested input handling; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M01.06-C075-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Nested input handling” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M01.06-C075-T02 · Expected-result oracle:** Specify the “Nested input handling” expected result independently of the implementation output; include the property “Nested material cannot bypass accounting limits” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M01.06-C075-T03 · Fixture material:** Create the concrete “Nested input handling” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M01.06-C075-T04 · Target preparation:** Prepare the “Nested input handling” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M01.06-C075-T05 · Initial-state record:** Record the initial “Nested input handling” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M01.06-C075-T06 · Valid-path execution:** Execute the “Nested input handling” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M01.06-C075-T07 · Outcome comparison:** Compare every declared “Nested input handling” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M01.06-C075-T08 · State and bounds check:** Inspect the “Nested input handling” ownership/state effects and actual use of “Nesting depth and cumulative expanded bytes”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M01.06-C075-T09 · Repeatability check:** Repeat the same “Nested input handling” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M01.06-C075-T10 · Positive evidence:** Attach the “Nested input handling” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M01.06-C076 · Negative test

**Original checklist item:** Negative case: A nested archive hides additional required files. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M01.06-C076-T01 · Adverse-case definition:** Create a test record for the exact “Nested input handling” source counterexample: “A nested archive hides additional required files”; state which precondition or invariant it challenges.
- [ ] **UC-M01.06-C076-T02 · Safe fixture boundary:** Define the contained test boundary for “Nested input handling”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M01.06-C076-T03 · Valid control:** Construct a valid “Nested input handling” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M01.06-C076-T04 · Minimal adverse input:** Derive the “Nested input handling” adverse fixture from the control with the smallest documented change needed to reproduce “A nested archive hides additional required files”; retain that change as reproducible data.
- [ ] **UC-M01.06-C076-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Nested input handling”; require “Nested material cannot bypass accounting limits” and forbid a false-success verdict.
- [ ] **UC-M01.06-C076-T06 · Adverse execution:** Exercise the “Nested input handling” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M01.06-C076-T07 · Effect inspection:** Inspect “Nested input handling” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M01.06-C076-T08 · Refusal versus failure:** Confirm the “Nested input handling” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M01.06-C076-T09 · Reset and retention:** Restore only the disposable “Nested input handling” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M01.06-C076-T10 · Negative regression:** Register the “Nested input handling” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M01.06-C077 · Change / failure test

**Original checklist item:** Exercise nested input handling when ingest is interrupted after some members have been copied but before reconciliation; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M01.06-C077-T01 · Scenario record:** Write the “Nested input handling” change/failure scenario exactly as supplied: ingest is interrupted after some members have been copied but before reconciliation; identify the property that must remain true: “Nested material cannot bypass accounting limits”.
- [ ] **UC-M01.06-C077-T02 · Baseline capture:** Create a known-valid “Nested input handling” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M01.06-C077-T03 · Injection map:** Locate the “Nested input handling” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M01.06-C077-T04 · Disposition oracle:** Define the legal intermediate and final “Nested input handling” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M01.06-C077-T05 · Controlled trigger:** Introduce the controlled “Nested input handling” scenario in the disposable fixture: ingest is interrupted after some members have been copied but before reconciliation; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M01.06-C077-T06 · Intermediate inspection:** Inspect the “Nested input handling” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M01.06-C077-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Nested input handling”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M01.06-C077-T08 · Stale-evidence cleanup:** Invalidate superseded “Nested input handling” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M01.06-C077-T09 · Repeat and compare:** Repeat the selected “Nested input handling” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M01.06-C077-T10 · Failure evidence:** Publish the “Nested input handling” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M01.06-C078 · Bounds

**Original checklist item:** Choose, document and test limits for nesting depth and cumulative expanded bytes; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M01.06-C078-T01 · Quantity inventory:** Create a measurement inventory for “Nested input handling”: “Nesting depth and cumulative expanded bytes”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M01.06-C078-T02 · Measurement method:** Choose how to observe each “Nested input handling” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M01.06-C078-T03 · Budget decision:** Select justified resource and input limits for “Nested input handling”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M01.06-C078-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Nested input handling” cases for “Nesting depth and cumulative expanded bytes”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M01.06-C078-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Nested input handling” limit; preserve “Nested material cannot bypass accounting limits”.
- [ ] **UC-M01.06-C078-T06 · Normal measurement:** Run or review the normal “Nested input handling” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M01.06-C078-T07 · At-limit measurement:** Exercise the “Nested input handling” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M01.06-C078-T08 · Over-limit measurement:** Exercise the “Nested input handling” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M01.06-C078-T09 · Uncovered-scope report:** List the “Nested input handling” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M01.06-C078-T10 · Limit evidence:** Publish the selected “Nested input handling” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M01.06-C079 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for nested input handling with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M01.06-C079-T01 · Event inventory:** List the “Nested input handling” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M01.06-C079-T02 · Diagnostic schema:** Define nonsecret fields for “Nested input handling” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M01.06-C079-T03 · Failure mapping:** Map each documented “Nested input handling” refusal or error to a diagnostic outcome; include “A nested archive hides additional required files” and prohibit conversion into a success message.
- [ ] **UC-M01.06-C079-T04 · Emission path:** Add the “Nested input handling” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M01.06-C079-T05 · Redaction check:** Test “Nested input handling” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M01.06-C079-T06 · Output budget:** Set and exercise bounded “Nested input handling” message size, rate and retention compatible with “Nesting depth and cumulative expanded bytes”; define truncation behavior that preserves the final reason.
- [ ] **UC-M01.06-C079-T07 · Success/refusal fixtures:** Capture “Nested input handling” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M01.06-C079-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Nested input handling” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M01.06-C079-T09 · Operator review:** Read the “Nested input handling” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M01.06-C079-T10 · Diagnostic evidence:** Publish redacted “Nested input handling” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M01.06-C080 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for nested input handling; label unexecuted checks as untested.

- [ ] **UC-M01.06-C080-T01 · Evidence inventory:** List the “Nested input handling” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M01.06-C080-T02 · Artifact references:** Record the exact “Nested input handling” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M01.06-C080-T03 · Fixture references:** Attach the “Nested input handling” fixture IDs, input identities and oracle definition; preserve the source counterexample “A nested archive hides additional required files” as a distinct evidence case.
- [ ] **UC-M01.06-C080-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Nested input handling”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M01.06-C080-T05 · Environment record:** Record the actual “Nested input handling” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M01.06-C080-T06 · Expected versus observed:** Pair every “Nested input handling” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M01.06-C080-T07 · Failure and limit records:** Attach “Nested input handling” change/failure and bounds evidence where required; include uncovered “Nesting depth and cumulative expanded bytes” and unresolved violations of “Nested material cannot bypass accounting limits”.
- [ ] **UC-M01.06-C080-T08 · Evidence hygiene:** Check the “Nested input handling” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M01.06-C080-T09 · Reproduction review:** Have the “Nested input handling” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M01.06-C080-T10 · Acceptance linkage:** Link the “Nested input handling” evidence to its parent and UC-M01.06 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 09. Inventory reconciliation

**Source delivery:** Compare stored cargo, original members and disposition totals after ingest.

**Source invariant:** Accounted cargo plus explicit dispositions covers all original members.

**Source negative case:** A copy interruption leaves an unaccounted member.

**Source bounded quantities:** Reconciliation memory and maximum file count.

### UC-M01.06-C081 · Contract

**Original checklist item:** Specify inventory reconciliation inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M01.06-C081-T01 · Scope statement:** Draft the operation boundary for “Inventory reconciliation” within Closed-world source and dependency inventory; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M01.06-C081-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Inventory reconciliation”; record each producer, representation and missing-value meaning.
- [ ] **UC-M01.06-C081-T03 · Output inventory:** List the outputs of “Inventory reconciliation” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M01.06-C081-T04 · Field dictionary:** Create a field-and-term dictionary for “Inventory reconciliation”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M01.06-C081-T05 · Prerequisite contract:** Map “Inventory reconciliation” to the source component prerequisites (UC-M01.04); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M01.06-C081-T06 · Authority map:** Identify who may produce, change and consume “Inventory reconciliation”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M01.06-C081-T07 · Invariant clause:** Add a normative clause for “Inventory reconciliation” that preserves “Accounted cargo plus explicit dispositions covers all original members”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M01.06-C081-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Inventory reconciliation”; include the source counterexample “A copy interruption leaves an unaccounted member” and the intended safe disposition.
- [ ] **UC-M01.06-C081-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Reconciliation memory and maximum file count” in the “Inventory reconciliation” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M01.06-C081-T10 · Contract review:** Review the “Inventory reconciliation” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M01.06-C082 · Delivery

**Original checklist item:** Compare stored cargo, original members and disposition totals after ingest.

- [ ] **UC-M01.06-C082-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Inventory reconciliation”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M01.06-C082-T02 · Change plan:** Break the source delivery for “Inventory reconciliation” into concrete edit targets and reviewable outputs; keep the UC-M01.06 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M01.06-C082-T03 · Core artifact:** Create the “Inventory reconciliation” fixture or harness for this source instruction: Compare stored cargo, original members and disposition totals after ingest.
- [ ] **UC-M01.06-C082-T04 · Concrete realization:** Connect the “Inventory reconciliation” harness to its actual intended target, set the expected oracle before running it, and distinguish a mock/control run from a target run.
- [ ] **UC-M01.06-C082-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Inventory reconciliation” needed to preserve “Accounted cargo plus explicit dispositions covers all original members”; record an enforcement gap where only a model exists.
- [ ] **UC-M01.06-C082-T06 · Dependency connection:** Connect the “Inventory reconciliation” implementation to archive admission, source ledgers and dependency resolution; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M01.06-C082-T07 · Resource behavior:** Account for “Reconciliation memory and maximum file count” in “Inventory reconciliation”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M01.06-C082-T08 · Delivery check:** Run the smallest real “Inventory reconciliation” path and its adverse fixture “A copy interruption leaves an unaccounted member”; retain actual output, state effects and final disposition.
- [ ] **UC-M01.06-C082-T09 · Patch review:** Review the “Inventory reconciliation” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M01.06-C082-T10 · Delivery handoff:** Publish the “Inventory reconciliation” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M01.06-C083 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Accounted cargo plus explicit dispositions covers all original members. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M01.06-C083-T01 · Named property:** Create a stable property/check name under this parent for “Inventory reconciliation”; copy its required invariant exactly: “Accounted cargo plus explicit dispositions covers all original members”.
- [ ] **UC-M01.06-C083-T02 · Observable terms:** Define each term in the “Inventory reconciliation” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M01.06-C083-T03 · Precondition set:** List the preconditions under which “Accounted cargo plus explicit dispositions covers all original members” must hold for “Inventory reconciliation”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M01.06-C083-T04 · Transition coverage:** Map the “Inventory reconciliation” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M01.06-C083-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Inventory reconciliation”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M01.06-C083-T06 · Satisfying fixture:** Create a concrete “Inventory reconciliation” case that satisfies “Accounted cargo plus explicit dispositions covers all original members”; record its expected observation before running the assertion or review.
- [ ] **UC-M01.06-C083-T07 · Violating fixture:** Create the source counterexample “A copy interruption leaves an unaccounted member” for “Inventory reconciliation”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M01.06-C083-T08 · Enforcement evidence:** Exercise the “Inventory reconciliation” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M01.06-C083-T09 · Regression linkage:** Link the “Inventory reconciliation” property to changes in archive admission, source ledgers and dependency resolution; record which dependency or contract changes require rerunning it.
- [ ] **UC-M01.06-C083-T10 · Property disposition:** Compare the satisfying and violating “Inventory reconciliation” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M01.06-C084 · Integration

**Original checklist item:** Integrate inventory reconciliation with archive admission, source ledgers and dependency resolution; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M01.06-C084-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Inventory reconciliation” across archive admission, source ledgers and dependency resolution; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M01.06-C084-T02 · Field mapping:** Map every “Inventory reconciliation” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M01.06-C084-T03 · Prerequisite identities:** Record the actual prerequisites for “Inventory reconciliation” (source dependency list: UC-M01.04); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M01.06-C084-T04 · Ownership agreement:** Specify who owns “Inventory reconciliation” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M01.06-C084-T05 · Handoff implementation:** Connect “Inventory reconciliation” through the mapped seam using the real adapter or explicit specification reference; preserve “Accounted cargo plus explicit dispositions covers all original members” across the handoff.
- [ ] **UC-M01.06-C084-T06 · Absent-input case:** Omit one required “Inventory reconciliation” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M01.06-C084-T07 · Stale-input case:** Supply an outdated “Inventory reconciliation” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M01.06-C084-T08 · Incompatible-input case:** Supply an incompatible “Inventory reconciliation” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M01.06-C084-T09 · Valid integration trace:** Run a valid “Inventory reconciliation” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M01.06-C084-T10 · Seam review:** Reconcile the “Inventory reconciliation” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M01.06-C085 · Valid-case test

**Original checklist item:** Run a valid-path fixture for inventory reconciliation; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M01.06-C085-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Inventory reconciliation” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M01.06-C085-T02 · Expected-result oracle:** Specify the “Inventory reconciliation” expected result independently of the implementation output; include the property “Accounted cargo plus explicit dispositions covers all original members” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M01.06-C085-T03 · Fixture material:** Create the concrete “Inventory reconciliation” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M01.06-C085-T04 · Target preparation:** Prepare the “Inventory reconciliation” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M01.06-C085-T05 · Initial-state record:** Record the initial “Inventory reconciliation” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M01.06-C085-T06 · Valid-path execution:** Execute the “Inventory reconciliation” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M01.06-C085-T07 · Outcome comparison:** Compare every declared “Inventory reconciliation” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M01.06-C085-T08 · State and bounds check:** Inspect the “Inventory reconciliation” ownership/state effects and actual use of “Reconciliation memory and maximum file count”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M01.06-C085-T09 · Repeatability check:** Repeat the same “Inventory reconciliation” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M01.06-C085-T10 · Positive evidence:** Attach the “Inventory reconciliation” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M01.06-C086 · Negative test

**Original checklist item:** Negative case: A copy interruption leaves an unaccounted member. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M01.06-C086-T01 · Adverse-case definition:** Create a test record for the exact “Inventory reconciliation” source counterexample: “A copy interruption leaves an unaccounted member”; state which precondition or invariant it challenges.
- [ ] **UC-M01.06-C086-T02 · Safe fixture boundary:** Define the contained test boundary for “Inventory reconciliation”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M01.06-C086-T03 · Valid control:** Construct a valid “Inventory reconciliation” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M01.06-C086-T04 · Minimal adverse input:** Derive the “Inventory reconciliation” adverse fixture from the control with the smallest documented change needed to reproduce “A copy interruption leaves an unaccounted member”; retain that change as reproducible data.
- [ ] **UC-M01.06-C086-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Inventory reconciliation”; require “Accounted cargo plus explicit dispositions covers all original members” and forbid a false-success verdict.
- [ ] **UC-M01.06-C086-T06 · Adverse execution:** Exercise the “Inventory reconciliation” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M01.06-C086-T07 · Effect inspection:** Inspect “Inventory reconciliation” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M01.06-C086-T08 · Refusal versus failure:** Confirm the “Inventory reconciliation” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M01.06-C086-T09 · Reset and retention:** Restore only the disposable “Inventory reconciliation” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M01.06-C086-T10 · Negative regression:** Register the “Inventory reconciliation” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M01.06-C087 · Change / failure test

**Original checklist item:** Exercise inventory reconciliation when ingest is interrupted after some members have been copied but before reconciliation; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M01.06-C087-T01 · Scenario record:** Write the “Inventory reconciliation” change/failure scenario exactly as supplied: ingest is interrupted after some members have been copied but before reconciliation; identify the property that must remain true: “Accounted cargo plus explicit dispositions covers all original members”.
- [ ] **UC-M01.06-C087-T02 · Baseline capture:** Create a known-valid “Inventory reconciliation” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M01.06-C087-T03 · Injection map:** Locate the “Inventory reconciliation” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M01.06-C087-T04 · Disposition oracle:** Define the legal intermediate and final “Inventory reconciliation” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M01.06-C087-T05 · Controlled trigger:** Introduce the controlled “Inventory reconciliation” scenario in the disposable fixture: ingest is interrupted after some members have been copied but before reconciliation; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M01.06-C087-T06 · Intermediate inspection:** Inspect the “Inventory reconciliation” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M01.06-C087-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Inventory reconciliation”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M01.06-C087-T08 · Stale-evidence cleanup:** Invalidate superseded “Inventory reconciliation” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M01.06-C087-T09 · Repeat and compare:** Repeat the selected “Inventory reconciliation” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M01.06-C087-T10 · Failure evidence:** Publish the “Inventory reconciliation” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M01.06-C088 · Bounds

**Original checklist item:** Choose, document and test limits for reconciliation memory and maximum file count; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M01.06-C088-T01 · Quantity inventory:** Create a measurement inventory for “Inventory reconciliation”: “Reconciliation memory and maximum file count”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M01.06-C088-T02 · Measurement method:** Choose how to observe each “Inventory reconciliation” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M01.06-C088-T03 · Budget decision:** Select justified resource and input limits for “Inventory reconciliation”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M01.06-C088-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Inventory reconciliation” cases for “Reconciliation memory and maximum file count”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M01.06-C088-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Inventory reconciliation” limit; preserve “Accounted cargo plus explicit dispositions covers all original members”.
- [ ] **UC-M01.06-C088-T06 · Normal measurement:** Run or review the normal “Inventory reconciliation” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M01.06-C088-T07 · At-limit measurement:** Exercise the “Inventory reconciliation” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M01.06-C088-T08 · Over-limit measurement:** Exercise the “Inventory reconciliation” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M01.06-C088-T09 · Uncovered-scope report:** List the “Inventory reconciliation” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M01.06-C088-T10 · Limit evidence:** Publish the selected “Inventory reconciliation” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M01.06-C089 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for inventory reconciliation with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M01.06-C089-T01 · Event inventory:** List the “Inventory reconciliation” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M01.06-C089-T02 · Diagnostic schema:** Define nonsecret fields for “Inventory reconciliation” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M01.06-C089-T03 · Failure mapping:** Map each documented “Inventory reconciliation” refusal or error to a diagnostic outcome; include “A copy interruption leaves an unaccounted member” and prohibit conversion into a success message.
- [ ] **UC-M01.06-C089-T04 · Emission path:** Add the “Inventory reconciliation” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M01.06-C089-T05 · Redaction check:** Test “Inventory reconciliation” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M01.06-C089-T06 · Output budget:** Set and exercise bounded “Inventory reconciliation” message size, rate and retention compatible with “Reconciliation memory and maximum file count”; define truncation behavior that preserves the final reason.
- [ ] **UC-M01.06-C089-T07 · Success/refusal fixtures:** Capture “Inventory reconciliation” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M01.06-C089-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Inventory reconciliation” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M01.06-C089-T09 · Operator review:** Read the “Inventory reconciliation” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M01.06-C089-T10 · Diagnostic evidence:** Publish redacted “Inventory reconciliation” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M01.06-C090 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for inventory reconciliation; label unexecuted checks as untested.

- [ ] **UC-M01.06-C090-T01 · Evidence inventory:** List the “Inventory reconciliation” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M01.06-C090-T02 · Artifact references:** Record the exact “Inventory reconciliation” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M01.06-C090-T03 · Fixture references:** Attach the “Inventory reconciliation” fixture IDs, input identities and oracle definition; preserve the source counterexample “A copy interruption leaves an unaccounted member” as a distinct evidence case.
- [ ] **UC-M01.06-C090-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Inventory reconciliation”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M01.06-C090-T05 · Environment record:** Record the actual “Inventory reconciliation” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M01.06-C090-T06 · Expected versus observed:** Pair every “Inventory reconciliation” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M01.06-C090-T07 · Failure and limit records:** Attach “Inventory reconciliation” change/failure and bounds evidence where required; include uncovered “Reconciliation memory and maximum file count” and unresolved violations of “Accounted cargo plus explicit dispositions covers all original members”.
- [ ] **UC-M01.06-C090-T08 · Evidence hygiene:** Check the “Inventory reconciliation” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M01.06-C090-T09 · Reproduction review:** Have the “Inventory reconciliation” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M01.06-C090-T10 · Acceptance linkage:** Link the “Inventory reconciliation” evidence to its parent and UC-M01.06 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 10. Inventory export

**Source delivery:** Publish a machine-readable ledger with stable IDs and source relationships.

**Source invariant:** Another tool can reconstruct why each original member was kept or excluded.

**Source negative case:** An export omits the reason for excluded dependencies.

**Source bounded quantities:** Export bytes and schema compatibility span.

### UC-M01.06-C091 · Contract

**Original checklist item:** Specify inventory export inputs, outputs, ownership context, permitted callers and error dispositions for the selected workload/backend profile.

- [ ] **UC-M01.06-C091-T01 · Scope statement:** Draft the operation boundary for “Inventory export” within Closed-world source and dependency inventory; identify its entry condition, completion condition and explicitly unsupported paths.
- [ ] **UC-M01.06-C091-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Inventory export”; record each producer, representation and missing-value meaning.
- [ ] **UC-M01.06-C091-T03 · Output inventory:** List the outputs of “Inventory export” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M01.06-C091-T04 · Field dictionary:** Create a field-and-term dictionary for “Inventory export”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M01.06-C091-T05 · Prerequisite contract:** Map “Inventory export” to the source component prerequisites (UC-M01.04); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M01.06-C091-T06 · Authority map:** Identify who may produce, change and consume “Inventory export”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M01.06-C091-T07 · Invariant clause:** Add a normative clause for “Inventory export” that preserves “Another tool can reconstruct why each original member was kept or excluded”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M01.06-C091-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Inventory export”; include the source counterexample “An export omits the reason for excluded dependencies” and the intended safe disposition.
- [ ] **UC-M01.06-C091-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Export bytes and schema compatibility span” in the “Inventory export” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M01.06-C091-T10 · Contract review:** Review the “Inventory export” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M01.06-C092 · Delivery

**Original checklist item:** Publish a machine-readable ledger with stable IDs and source relationships.

- [ ] **UC-M01.06-C092-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Inventory export”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M01.06-C092-T02 · Change plan:** Break the source delivery for “Inventory export” into concrete edit targets and reviewable outputs; keep the UC-M01.06 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M01.06-C092-T03 · Core artifact:** Create the “Inventory export” output artifact for this source instruction: Publish a machine-readable ledger with stable IDs and source relationships.
- [ ] **UC-M01.06-C092-T04 · Concrete realization:** Populate the “Inventory export” artifact from identified observations; keep unknown, failed and unexecuted results distinct and exclude unapproved sensitive material.
- [ ] **UC-M01.06-C092-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Inventory export” needed to preserve “Another tool can reconstruct why each original member was kept or excluded”; record an enforcement gap where only a model exists.
- [ ] **UC-M01.06-C092-T06 · Dependency connection:** Connect the “Inventory export” implementation to archive admission, source ledgers and dependency resolution; record the actual exchanged data and the missing-prerequisite behavior.
- [ ] **UC-M01.06-C092-T07 · Resource behavior:** Account for “Export bytes and schema compatibility span” in “Inventory export”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M01.06-C092-T08 · Delivery check:** Run the smallest real “Inventory export” path and its adverse fixture “An export omits the reason for excluded dependencies”; retain actual output, state effects and final disposition.
- [ ] **UC-M01.06-C092-T09 · Patch review:** Review the “Inventory export” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M01.06-C092-T10 · Delivery handoff:** Publish the “Inventory export” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M01.06-C093 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Another tool can reconstruct why each original member was kept or excluded. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M01.06-C093-T01 · Named property:** Create a stable property/check name under this parent for “Inventory export”; copy its required invariant exactly: “Another tool can reconstruct why each original member was kept or excluded”.
- [ ] **UC-M01.06-C093-T02 · Observable terms:** Define each term in the “Inventory export” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M01.06-C093-T03 · Precondition set:** List the preconditions under which “Another tool can reconstruct why each original member was kept or excluded” must hold for “Inventory export”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M01.06-C093-T04 · Transition coverage:** Map the “Inventory export” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M01.06-C093-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Inventory export”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M01.06-C093-T06 · Satisfying fixture:** Create a concrete “Inventory export” case that satisfies “Another tool can reconstruct why each original member was kept or excluded”; record its expected observation before running the assertion or review.
- [ ] **UC-M01.06-C093-T07 · Violating fixture:** Create the source counterexample “An export omits the reason for excluded dependencies” for “Inventory export”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M01.06-C093-T08 · Enforcement evidence:** Exercise the “Inventory export” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M01.06-C093-T09 · Regression linkage:** Link the “Inventory export” property to changes in archive admission, source ledgers and dependency resolution; record which dependency or contract changes require rerunning it.
- [ ] **UC-M01.06-C093-T10 · Property disposition:** Compare the satisfying and violating “Inventory export” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M01.06-C094 · Integration

**Original checklist item:** Integrate inventory export with archive admission, source ledgers and dependency resolution; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M01.06-C094-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Inventory export” across archive admission, source ledgers and dependency resolution; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M01.06-C094-T02 · Field mapping:** Map every “Inventory export” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M01.06-C094-T03 · Prerequisite identities:** Record the actual prerequisites for “Inventory export” (source dependency list: UC-M01.04); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M01.06-C094-T04 · Ownership agreement:** Specify who owns “Inventory export” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M01.06-C094-T05 · Handoff implementation:** Connect “Inventory export” through the mapped seam using the real adapter or explicit specification reference; preserve “Another tool can reconstruct why each original member was kept or excluded” across the handoff.
- [ ] **UC-M01.06-C094-T06 · Absent-input case:** Omit one required “Inventory export” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M01.06-C094-T07 · Stale-input case:** Supply an outdated “Inventory export” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M01.06-C094-T08 · Incompatible-input case:** Supply an incompatible “Inventory export” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M01.06-C094-T09 · Valid integration trace:** Run a valid “Inventory export” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M01.06-C094-T10 · Seam review:** Reconcile the “Inventory export” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M01.06-C095 · Valid-case test

**Original checklist item:** Run a valid-path fixture for inventory export; compare output, ownership/state effects and final disposition with an independently specified expected result.

- [ ] **UC-M01.06-C095-T01 · Valid fixture choice:** Choose the smallest nontrivial supported “Inventory export” input; record the selected host/backend profile and expected final disposition.
- [ ] **UC-M01.06-C095-T02 · Expected-result oracle:** Specify the “Inventory export” expected result independently of the implementation output; include the property “Another tool can reconstruct why each original member was kept or excluded” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M01.06-C095-T03 · Fixture material:** Create the concrete “Inventory export” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M01.06-C095-T04 · Target preparation:** Prepare the “Inventory export” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M01.06-C095-T05 · Initial-state record:** Record the initial “Inventory export” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M01.06-C095-T06 · Valid-path execution:** Execute the “Inventory export” valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.
- [ ] **UC-M01.06-C095-T07 · Outcome comparison:** Compare every declared “Inventory export” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M01.06-C095-T08 · State and bounds check:** Inspect the “Inventory export” ownership/state effects and actual use of “Export bytes and schema compatibility span”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M01.06-C095-T09 · Repeatability check:** Repeat the same “Inventory export” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M01.06-C095-T10 · Positive evidence:** Attach the “Inventory export” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M01.06-C096 · Negative test

**Original checklist item:** Negative case: An export omits the reason for excluded dependencies. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M01.06-C096-T01 · Adverse-case definition:** Create a test record for the exact “Inventory export” source counterexample: “An export omits the reason for excluded dependencies”; state which precondition or invariant it challenges.
- [ ] **UC-M01.06-C096-T02 · Safe fixture boundary:** Define the contained test boundary for “Inventory export”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M01.06-C096-T03 · Valid control:** Construct a valid “Inventory export” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M01.06-C096-T04 · Minimal adverse input:** Derive the “Inventory export” adverse fixture from the control with the smallest documented change needed to reproduce “An export omits the reason for excluded dependencies”; retain that change as reproducible data.
- [ ] **UC-M01.06-C096-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Inventory export”; require “Another tool can reconstruct why each original member was kept or excluded” and forbid a false-success verdict.
- [ ] **UC-M01.06-C096-T06 · Adverse execution:** Exercise the “Inventory export” adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.
- [ ] **UC-M01.06-C096-T07 · Effect inspection:** Inspect “Inventory export” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M01.06-C096-T08 · Refusal versus failure:** Confirm the “Inventory export” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M01.06-C096-T09 · Reset and retention:** Restore only the disposable “Inventory export” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M01.06-C096-T10 · Negative regression:** Register the “Inventory export” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M01.06-C097 · Change / failure test

**Original checklist item:** Exercise inventory export when ingest is interrupted after some members have been copied but before reconciliation; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M01.06-C097-T01 · Scenario record:** Write the “Inventory export” change/failure scenario exactly as supplied: ingest is interrupted after some members have been copied but before reconciliation; identify the property that must remain true: “Another tool can reconstruct why each original member was kept or excluded”.
- [ ] **UC-M01.06-C097-T02 · Baseline capture:** Create a known-valid “Inventory export” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M01.06-C097-T03 · Injection map:** Locate the “Inventory export” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M01.06-C097-T04 · Disposition oracle:** Define the legal intermediate and final “Inventory export” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M01.06-C097-T05 · Controlled trigger:** Introduce the controlled “Inventory export” scenario in the disposable fixture: ingest is interrupted after some members have been copied but before reconciliation; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M01.06-C097-T06 · Intermediate inspection:** Inspect the “Inventory export” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M01.06-C097-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Inventory export”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M01.06-C097-T08 · Stale-evidence cleanup:** Invalidate superseded “Inventory export” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M01.06-C097-T09 · Repeat and compare:** Repeat the selected “Inventory export” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M01.06-C097-T10 · Failure evidence:** Publish the “Inventory export” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M01.06-C098 · Bounds

**Original checklist item:** Choose, document and test limits for export bytes and schema compatibility span; cover normal, at-limit and over-limit conditions with the declared safe refusal or bounded-degradation behavior.

- [ ] **UC-M01.06-C098-T01 · Quantity inventory:** Create a measurement inventory for “Inventory export”: “Export bytes and schema compatibility span”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M01.06-C098-T02 · Measurement method:** Choose how to observe each “Inventory export” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M01.06-C098-T03 · Budget decision:** Select justified resource and input limits for “Inventory export”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M01.06-C098-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Inventory export” cases for “Export bytes and schema compatibility span”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M01.06-C098-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Inventory export” limit; preserve “Another tool can reconstruct why each original member was kept or excluded”.
- [ ] **UC-M01.06-C098-T06 · Normal measurement:** Run or review the normal “Inventory export” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M01.06-C098-T07 · At-limit measurement:** Exercise the “Inventory export” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M01.06-C098-T08 · Over-limit measurement:** Exercise the “Inventory export” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M01.06-C098-T09 · Uncovered-scope report:** List the “Inventory export” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M01.06-C098-T10 · Limit evidence:** Publish the selected “Inventory export” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M01.06-C099 · Diagnostics / review

**Original checklist item:** Emit bounded, nonsecret diagnostics for inventory export with target identity, operation, outcome and relevant failure reason; verify that failures cannot appear as success.

- [ ] **UC-M01.06-C099-T01 · Event inventory:** List the “Inventory export” start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.
- [ ] **UC-M01.06-C099-T02 · Diagnostic schema:** Define nonsecret fields for “Inventory export” target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.
- [ ] **UC-M01.06-C099-T03 · Failure mapping:** Map each documented “Inventory export” refusal or error to a diagnostic outcome; include “An export omits the reason for excluded dependencies” and prohibit conversion into a success message.
- [ ] **UC-M01.06-C099-T04 · Emission path:** Add the “Inventory export” event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.
- [ ] **UC-M01.06-C099-T05 · Redaction check:** Test “Inventory export” diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.
- [ ] **UC-M01.06-C099-T06 · Output budget:** Set and exercise bounded “Inventory export” message size, rate and retention compatible with “Export bytes and schema compatibility span”; define truncation behavior that preserves the final reason.
- [ ] **UC-M01.06-C099-T07 · Success/refusal fixtures:** Capture “Inventory export” diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.
- [ ] **UC-M01.06-C099-T08 · Diagnostic-path failure:** Exercise unavailable or saturated diagnostic output for “Inventory export” in a disposable fixture; verify it cannot turn a failed operation into a reported pass.
- [ ] **UC-M01.06-C099-T09 · Operator review:** Read the “Inventory export” record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.
- [ ] **UC-M01.06-C099-T10 · Diagnostic evidence:** Publish redacted “Inventory export” event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.

### UC-M01.06-C100 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for inventory export; label unexecuted checks as untested.

- [ ] **UC-M01.06-C100-T01 · Evidence inventory:** List the “Inventory export” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M01.06-C100-T02 · Artifact references:** Record the exact “Inventory export” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M01.06-C100-T03 · Fixture references:** Attach the “Inventory export” fixture IDs, input identities and oracle definition; preserve the source counterexample “An export omits the reason for excluded dependencies” as a distinct evidence case.
- [ ] **UC-M01.06-C100-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Inventory export”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M01.06-C100-T05 · Environment record:** Record the actual “Inventory export” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M01.06-C100-T06 · Expected versus observed:** Pair every “Inventory export” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M01.06-C100-T07 · Failure and limit records:** Attach “Inventory export” change/failure and bounds evidence where required; include uncovered “Export bytes and schema compatibility span” and unresolved violations of “Another tool can reconstruct why each original member was kept or excluded”.
- [ ] **UC-M01.06-C100-T08 · Evidence hygiene:** Check the “Inventory export” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M01.06-C100-T09 · Reproduction review:** Have the “Inventory export” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M01.06-C100-T10 · Acceptance linkage:** Link the “Inventory export” evidence to its parent and UC-M01.06 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

