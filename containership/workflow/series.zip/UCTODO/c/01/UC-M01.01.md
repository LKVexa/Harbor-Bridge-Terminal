# UC-M01.01 — Trust-boundary and capability model

**To-Do Pack 2.0.0 · Baseline UC-2.2.0 · 100 parent checks × 10 subtasks = 1,000 to-dos**

[Master index](../../INDEX.md) · [Workstream index](../../w/01.md)

| Field | Preserved source value |
|---|---|
| Workstream | 01. Architecture and executable contracts |
| Milestone | A |
| Priority | P0 |
| Source assessment | PARTIAL |
| Scope | core or selected profile |
| Dependencies | None; foundational decision. |
| Source checklist pack | 1.0.0 |
| Original reference labels | [S1], [S3]. |

## Original requirement

Define operator, cargo author, guest, engine, hull and host trust boundaries. Keep control-plane permission, guest capability and proof status as separate fields.

**Original acceptance criterion:** A reviewed threat model maps every entry point to its actual enforcement boundary; no declaration is labeled enforcement.

**Source trace:** Original checklist `UC100/c/01/UC-M01.01.md` inside [s/checklists.zip](../../s/checklists.zip); exact parent records in [data/parents.jsonl](../../data/parents.jsonl). Original roadmap lines 49–59 are preserved in [s/roadmap.md](../../s/roadmap.md).

## How to use these lists

Every parent statement below is preserved verbatim. Its ten child tasks are proposed decomposition, not implemented capabilities or executed tests. Child IDs append `-T01` through `-T10` to the original parent ID. All begin unchecked / `TODO`. Design/review evidence does not establish runtime enforcement; observe the actual selected target where the parent requires it.

The source dependency graph and selected release profile determine applicability. The numbered child sequence is a local working order, not an added hard dependency graph. An unselected optional feature needs a recorded not-applicable rationale; missing prerequisites for selected work remain blockers. Numerical budgets, backends and trust mechanisms remain decisions unless fixed by the source. Test hostile cases only with synthetic inputs in authorized disposable environments.

## 01. Actor inventory

**Source delivery:** Enumerate operator, cargo author, guest, engine, hull and host actors and their delegated identities.

**Source invariant:** Display names do not confer authority.

**Source negative case:** A cargo author claims an operator role in its manifest.

**Source bounded quantities:** Actor count, delegation depth and inventory coverage.

### UC-M01.01-C001 · Contract

**Original checklist item:** Specify the scope and representation of actor inventory; identify its producer, consumer, authority assumptions and explicitly unsupported cases.

- [ ] **UC-M01.01-C001-T01 · Scope statement:** Draft a scope note for “Actor inventory” within Trust-boundary and capability model; separate required model statements, explicit exclusions and unresolved design decisions.
- [ ] **UC-M01.01-C001-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Actor inventory”; record each producer, representation and missing-value meaning.
- [ ] **UC-M01.01-C001-T03 · Output inventory:** List the outputs of “Actor inventory” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M01.01-C001-T04 · Field dictionary:** Create a field-and-term dictionary for “Actor inventory”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M01.01-C001-T05 · Prerequisite contract:** Map “Actor inventory” to the source component prerequisites (none declared; foundational work); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M01.01-C001-T06 · Authority map:** Identify who may produce, change and consume “Actor inventory”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M01.01-C001-T07 · Invariant clause:** Add a normative clause for “Actor inventory” that preserves “Display names do not confer authority”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M01.01-C001-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Actor inventory”; include the source counterexample “A cargo author claims an operator role in its manifest” and the intended safe disposition.
- [ ] **UC-M01.01-C001-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Actor count, delegation depth and inventory coverage” in the “Actor inventory” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M01.01-C001-T10 · Contract review:** Review the “Actor inventory” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M01.01-C002 · Delivery

**Original checklist item:** Enumerate operator, cargo author, guest, engine, hull and host actors and their delegated identities.

- [ ] **UC-M01.01-C002-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Actor inventory”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M01.01-C002-T02 · Change plan:** Break the source delivery for “Actor inventory” into concrete edit targets and reviewable outputs; keep the UC-M01.01 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M01.01-C002-T03 · Core artifact:** Create the “Actor inventory” model, schema or inventory that realizes this source instruction: Enumerate operator, cargo author, guest, engine, hull and host actors and their delegated identities.
- [ ] **UC-M01.01-C002-T04 · Concrete realization:** Populate “Actor inventory” with one concrete worked case; map every required entity or field to its source and flag any unmapped entry.
- [ ] **UC-M01.01-C002-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Actor inventory” needed to preserve “Display names do not confer authority”; record an enforcement gap where only a model exists.
- [ ] **UC-M01.01-C002-T06 · Dependency connection:** Connect the “Actor inventory” specification to entry-point inventory, policy decisions and observed host enforcement; record code coverage separately where the design is not yet enforced.
- [ ] **UC-M01.01-C002-T07 · Resource behavior:** Account for “Actor count, delegation depth and inventory coverage” in “Actor inventory”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M01.01-C002-T08 · Delivery check:** Walk the populated “Actor inventory” model through a valid example and the source counterexample “A cargo author claims an operator role in its manifest”; record corrections and unresolved enforcement gaps.
- [ ] **UC-M01.01-C002-T09 · Patch review:** Review the “Actor inventory” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M01.01-C002-T10 · Delivery handoff:** Publish the “Actor inventory” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M01.01-C003 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Display names do not confer authority. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M01.01-C003-T01 · Named property:** Create a stable property/check name under this parent for “Actor inventory”; copy its required invariant exactly: “Display names do not confer authority”.
- [ ] **UC-M01.01-C003-T02 · Observable terms:** Define each term in the “Actor inventory” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M01.01-C003-T03 · Precondition set:** List the preconditions under which “Display names do not confer authority” must hold for “Actor inventory”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M01.01-C003-T04 · Transition coverage:** Map the “Actor inventory” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M01.01-C003-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Actor inventory”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M01.01-C003-T06 · Satisfying fixture:** Create a concrete “Actor inventory” case that satisfies “Display names do not confer authority”; record its expected observation before running the assertion or review.
- [ ] **UC-M01.01-C003-T07 · Violating fixture:** Create the source counterexample “A cargo author claims an operator role in its manifest” for “Actor inventory”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M01.01-C003-T08 · Enforcement evidence:** Exercise the “Actor inventory” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M01.01-C003-T09 · Regression linkage:** Link the “Actor inventory” property to changes in entry-point inventory, policy decisions and observed host enforcement; record which dependency or contract changes require rerunning it.
- [ ] **UC-M01.01-C003-T10 · Property disposition:** Compare the satisfying and violating “Actor inventory” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M01.01-C004 · Integration

**Original checklist item:** Integrate actor inventory with entry-point inventory, policy decisions and observed host enforcement; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M01.01-C004-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Actor inventory” across entry-point inventory, policy decisions and observed host enforcement; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M01.01-C004-T02 · Field mapping:** Map every “Actor inventory” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M01.01-C004-T03 · Prerequisite identities:** Record the actual prerequisites for “Actor inventory” (source dependency list: none declared; foundational work); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M01.01-C004-T04 · Ownership agreement:** Specify who owns “Actor inventory” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M01.01-C004-T05 · Handoff implementation:** Connect “Actor inventory” through the mapped seam using the real adapter or explicit specification reference; preserve “Display names do not confer authority” across the handoff.
- [ ] **UC-M01.01-C004-T06 · Absent-input case:** Omit one required “Actor inventory” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M01.01-C004-T07 · Stale-input case:** Supply an outdated “Actor inventory” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M01.01-C004-T08 · Incompatible-input case:** Supply an incompatible “Actor inventory” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M01.01-C004-T09 · Valid integration trace:** Run a valid “Actor inventory” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M01.01-C004-T10 · Seam review:** Reconcile the “Actor inventory” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M01.01-C005 · Valid-case test

**Original checklist item:** Construct a valid worked example for actor inventory; evaluate it against predeclared expected decisions and, where enforcement exists, run the corresponding conformance fixture.

- [ ] **UC-M01.01-C005-T01 · Valid fixture choice:** Select one concrete valid worked example for “Actor inventory”; enumerate the model inputs and the expected review decision before evaluating it.
- [ ] **UC-M01.01-C005-T02 · Expected-result oracle:** Specify the “Actor inventory” expected result independently of the implementation output; include the property “Display names do not confer authority” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M01.01-C005-T03 · Fixture material:** Create the concrete “Actor inventory” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M01.01-C005-T04 · Target preparation:** Prepare the “Actor inventory” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M01.01-C005-T05 · Initial-state record:** Record the initial “Actor inventory” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M01.01-C005-T06 · Valid-path execution:** Evaluate the “Actor inventory” example against the reviewed model; where a runtime mechanism exists, run its corresponding fixture and label those observations separately.
- [ ] **UC-M01.01-C005-T07 · Outcome comparison:** Compare every declared “Actor inventory” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M01.01-C005-T08 · State and bounds check:** Inspect the “Actor inventory” ownership/state effects and actual use of “Actor count, delegation depth and inventory coverage”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M01.01-C005-T09 · Repeatability check:** Repeat the same “Actor inventory” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M01.01-C005-T10 · Positive evidence:** Attach the “Actor inventory” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M01.01-C006 · Negative test

**Original checklist item:** Negative case: A cargo author claims an operator role in its manifest. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M01.01-C006-T01 · Adverse-case definition:** Create a test record for the exact “Actor inventory” source counterexample: “A cargo author claims an operator role in its manifest”; state which precondition or invariant it challenges.
- [ ] **UC-M01.01-C006-T02 · Safe fixture boundary:** Define the contained test boundary for “Actor inventory”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M01.01-C006-T03 · Valid control:** Construct a valid “Actor inventory” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M01.01-C006-T04 · Minimal adverse input:** Derive the “Actor inventory” adverse fixture from the control with the smallest documented change needed to reproduce “A cargo author claims an operator role in its manifest”; retain that change as reproducible data.
- [ ] **UC-M01.01-C006-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Actor inventory”; require “Display names do not confer authority” and forbid a false-success verdict.
- [ ] **UC-M01.01-C006-T06 · Adverse execution:** Evaluate the “Actor inventory” adverse case through the actual review/contract gate; where implemented, also observe the runtime refusal and keep the two evidence classes separate.
- [ ] **UC-M01.01-C006-T07 · Effect inspection:** Inspect “Actor inventory” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M01.01-C006-T08 · Refusal versus failure:** Confirm the “Actor inventory” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M01.01-C006-T09 · Reset and retention:** Restore only the disposable “Actor inventory” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M01.01-C006-T10 · Negative regression:** Register the “Actor inventory” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M01.01-C007 · Change / failure test

**Original checklist item:** Exercise actor inventory when an entry point or trusted actor is added after the model was reviewed; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M01.01-C007-T01 · Scenario record:** Write the “Actor inventory” change/failure scenario exactly as supplied: an entry point or trusted actor is added after the model was reviewed; identify the property that must remain true: “Display names do not confer authority”.
- [ ] **UC-M01.01-C007-T02 · Baseline capture:** Create a known-valid “Actor inventory” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M01.01-C007-T03 · Injection map:** Locate the “Actor inventory” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M01.01-C007-T04 · Disposition oracle:** Define the legal intermediate and final “Actor inventory” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M01.01-C007-T05 · Controlled trigger:** Apply the controlled model-change scenario for “Actor inventory”: an entry point or trusted actor is added after the model was reviewed; retain the exact before/after declarations. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M01.01-C007-T06 · Intermediate inspection:** Review which “Actor inventory” claims, approvals and evidence references become stale after the change; keep unresolved enforcement gaps visible.
- [ ] **UC-M01.01-C007-T07 · Recovery path:** Revise or explicitly refuse the changed “Actor inventory” model under the documented compatibility policy; re-review affected claims before restoring their approval.
- [ ] **UC-M01.01-C007-T08 · Stale-evidence cleanup:** Invalidate superseded “Actor inventory” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M01.01-C007-T09 · Repeat and compare:** Repeat the selected “Actor inventory” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M01.01-C007-T10 · Failure evidence:** Publish the “Actor inventory” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M01.01-C008 · Bounds

**Original checklist item:** Define completeness and scaling criteria for actor count, delegation depth and inventory coverage; exercise larger inventories or fixture sets, and report uncovered scope instead of silently excluding it.

- [ ] **UC-M01.01-C008-T01 · Quantity inventory:** Create a measurement inventory for “Actor inventory”: “Actor count, delegation depth and inventory coverage”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M01.01-C008-T02 · Measurement method:** Choose how to observe each “Actor inventory” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M01.01-C008-T03 · Budget decision:** Select justified coverage and completeness limits for “Actor inventory”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M01.01-C008-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Actor inventory” cases for “Actor count, delegation depth and inventory coverage”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M01.01-C008-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Actor inventory” limit; preserve “Display names do not confer authority”.
- [ ] **UC-M01.01-C008-T06 · Normal measurement:** Run or review the normal “Actor inventory” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M01.01-C008-T07 · At-limit measurement:** Exercise the “Actor inventory” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M01.01-C008-T08 · Over-limit measurement:** Exercise the “Actor inventory” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M01.01-C008-T09 · Uncovered-scope report:** List the “Actor inventory” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M01.01-C008-T10 · Limit evidence:** Publish the selected “Actor inventory” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M01.01-C009 · Diagnostics / review

**Original checklist item:** Record the rationale, unresolved assumptions, enforcement gaps and re-review triggers for actor inventory; make design-only claims visibly distinct from observed behavior.

- [ ] **UC-M01.01-C009-T01 · Review inventory:** List the “Actor inventory” decisions and claims requiring review; distinguish source requirements, implementation observations and engineering assumptions.
- [ ] **UC-M01.01-C009-T02 · Rationale record:** Write the rationale for the selected “Actor inventory” representation or policy; link each choice to the requirement rather than an unexplained preference.
- [ ] **UC-M01.01-C009-T03 · Assumption ledger:** Record unresolved “Actor inventory” assumptions, their owner and what observation or decision would resolve them; do not treat unknowns as approvals.
- [ ] **UC-M01.01-C009-T04 · Boundary map:** Map each “Actor inventory” claim to an actual guard or explicit design/review gate; flag gaps against “Display names do not confer authority”.
- [ ] **UC-M01.01-C009-T05 · Counterexample review:** Walk reviewers through the “Actor inventory” counterexample “A cargo author claims an operator role in its manifest”; record whether the model detects it and whether any runtime guard was actually exercised.
- [ ] **UC-M01.01-C009-T06 · Review outcome vocabulary:** Define approved, blocked, superseded and untested review outcomes for “Actor inventory”; ensure the wording cannot be read as runtime enforcement evidence.
- [ ] **UC-M01.01-C009-T07 · Re-review triggers:** List “Actor inventory” invalidation triggers, including the source change scenario: an entry point or trusted actor is added after the model was reviewed; identify the affected claims and evidence.
- [ ] **UC-M01.01-C009-T08 · Sensitive-data review:** Inspect the “Actor inventory” review record for secrets and unrelated user content; retain nonsecret references sufficient for reproducibility.
- [ ] **UC-M01.01-C009-T09 · Independent reading:** Have the “Actor inventory” record read against the original acceptance criterion and entry-point inventory, policy decisions and observed host enforcement; record misunderstandings or missing evidence as corrections.
- [ ] **UC-M01.01-C009-T10 · Review disposition:** Publish the “Actor inventory” rationale, versioned review outcome, unresolved gaps and explicit next decision; keep blockers open until supported evidence resolves them.

### UC-M01.01-C010 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for actor inventory; label unexecuted checks as untested.

- [ ] **UC-M01.01-C010-T01 · Evidence inventory:** List the “Actor inventory” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M01.01-C010-T02 · Artifact references:** Record the exact “Actor inventory” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M01.01-C010-T03 · Fixture references:** Attach the “Actor inventory” fixture IDs, input identities and oracle definition; preserve the source counterexample “A cargo author claims an operator role in its manifest” as a distinct evidence case.
- [ ] **UC-M01.01-C010-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Actor inventory”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M01.01-C010-T05 · Environment record:** Record the actual “Actor inventory” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M01.01-C010-T06 · Expected versus observed:** Pair every “Actor inventory” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M01.01-C010-T07 · Failure and limit records:** Attach “Actor inventory” change/failure and bounds evidence where required; include uncovered “Actor count, delegation depth and inventory coverage” and unresolved violations of “Display names do not confer authority”.
- [ ] **UC-M01.01-C010-T08 · Evidence hygiene:** Check the “Actor inventory” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M01.01-C010-T09 · Reproduction review:** Have the “Actor inventory” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M01.01-C010-T10 · Acceptance linkage:** Link the “Actor inventory” evidence to its parent and UC-M01.01 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 02. Asset classification

**Source delivery:** Classify source, executable images, mutable state, signing keys and evidence by owner and sensitivity.

**Source invariant:** Evidence and secret material have distinct access rules.

**Source negative case:** A public support record contains an operator credential.

**Source bounded quantities:** Asset classes, retained copies and classification coverage.

### UC-M01.01-C011 · Contract

**Original checklist item:** Specify the scope and representation of asset classification; identify its producer, consumer, authority assumptions and explicitly unsupported cases.

- [ ] **UC-M01.01-C011-T01 · Scope statement:** Draft a scope note for “Asset classification” within Trust-boundary and capability model; separate required model statements, explicit exclusions and unresolved design decisions.
- [ ] **UC-M01.01-C011-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Asset classification”; record each producer, representation and missing-value meaning.
- [ ] **UC-M01.01-C011-T03 · Output inventory:** List the outputs of “Asset classification” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M01.01-C011-T04 · Field dictionary:** Create a field-and-term dictionary for “Asset classification”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M01.01-C011-T05 · Prerequisite contract:** Map “Asset classification” to the source component prerequisites (none declared; foundational work); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M01.01-C011-T06 · Authority map:** Identify who may produce, change and consume “Asset classification”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M01.01-C011-T07 · Invariant clause:** Add a normative clause for “Asset classification” that preserves “Evidence and secret material have distinct access rules”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M01.01-C011-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Asset classification”; include the source counterexample “A public support record contains an operator credential” and the intended safe disposition.
- [ ] **UC-M01.01-C011-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Asset classes, retained copies and classification coverage” in the “Asset classification” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M01.01-C011-T10 · Contract review:** Review the “Asset classification” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M01.01-C012 · Delivery

**Original checklist item:** Classify source, executable images, mutable state, signing keys and evidence by owner and sensitivity.

- [ ] **UC-M01.01-C012-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Asset classification”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M01.01-C012-T02 · Change plan:** Break the source delivery for “Asset classification” into concrete edit targets and reviewable outputs; keep the UC-M01.01 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M01.01-C012-T03 · Core artifact:** Create the “Asset classification” model, schema or inventory that realizes this source instruction: Classify source, executable images, mutable state, signing keys and evidence by owner and sensitivity.
- [ ] **UC-M01.01-C012-T04 · Concrete realization:** Populate “Asset classification” with one concrete worked case; map every required entity or field to its source and flag any unmapped entry.
- [ ] **UC-M01.01-C012-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Asset classification” needed to preserve “Evidence and secret material have distinct access rules”; record an enforcement gap where only a model exists.
- [ ] **UC-M01.01-C012-T06 · Dependency connection:** Connect the “Asset classification” specification to entry-point inventory, policy decisions and observed host enforcement; record code coverage separately where the design is not yet enforced.
- [ ] **UC-M01.01-C012-T07 · Resource behavior:** Account for “Asset classes, retained copies and classification coverage” in “Asset classification”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M01.01-C012-T08 · Delivery check:** Walk the populated “Asset classification” model through a valid example and the source counterexample “A public support record contains an operator credential”; record corrections and unresolved enforcement gaps.
- [ ] **UC-M01.01-C012-T09 · Patch review:** Review the “Asset classification” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M01.01-C012-T10 · Delivery handoff:** Publish the “Asset classification” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M01.01-C013 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Evidence and secret material have distinct access rules. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M01.01-C013-T01 · Named property:** Create a stable property/check name under this parent for “Asset classification”; copy its required invariant exactly: “Evidence and secret material have distinct access rules”.
- [ ] **UC-M01.01-C013-T02 · Observable terms:** Define each term in the “Asset classification” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M01.01-C013-T03 · Precondition set:** List the preconditions under which “Evidence and secret material have distinct access rules” must hold for “Asset classification”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M01.01-C013-T04 · Transition coverage:** Map the “Asset classification” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M01.01-C013-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Asset classification”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M01.01-C013-T06 · Satisfying fixture:** Create a concrete “Asset classification” case that satisfies “Evidence and secret material have distinct access rules”; record its expected observation before running the assertion or review.
- [ ] **UC-M01.01-C013-T07 · Violating fixture:** Create the source counterexample “A public support record contains an operator credential” for “Asset classification”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M01.01-C013-T08 · Enforcement evidence:** Exercise the “Asset classification” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M01.01-C013-T09 · Regression linkage:** Link the “Asset classification” property to changes in entry-point inventory, policy decisions and observed host enforcement; record which dependency or contract changes require rerunning it.
- [ ] **UC-M01.01-C013-T10 · Property disposition:** Compare the satisfying and violating “Asset classification” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M01.01-C014 · Integration

**Original checklist item:** Integrate asset classification with entry-point inventory, policy decisions and observed host enforcement; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M01.01-C014-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Asset classification” across entry-point inventory, policy decisions and observed host enforcement; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M01.01-C014-T02 · Field mapping:** Map every “Asset classification” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M01.01-C014-T03 · Prerequisite identities:** Record the actual prerequisites for “Asset classification” (source dependency list: none declared; foundational work); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M01.01-C014-T04 · Ownership agreement:** Specify who owns “Asset classification” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M01.01-C014-T05 · Handoff implementation:** Connect “Asset classification” through the mapped seam using the real adapter or explicit specification reference; preserve “Evidence and secret material have distinct access rules” across the handoff.
- [ ] **UC-M01.01-C014-T06 · Absent-input case:** Omit one required “Asset classification” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M01.01-C014-T07 · Stale-input case:** Supply an outdated “Asset classification” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M01.01-C014-T08 · Incompatible-input case:** Supply an incompatible “Asset classification” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M01.01-C014-T09 · Valid integration trace:** Run a valid “Asset classification” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M01.01-C014-T10 · Seam review:** Reconcile the “Asset classification” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M01.01-C015 · Valid-case test

**Original checklist item:** Construct a valid worked example for asset classification; evaluate it against predeclared expected decisions and, where enforcement exists, run the corresponding conformance fixture.

- [ ] **UC-M01.01-C015-T01 · Valid fixture choice:** Select one concrete valid worked example for “Asset classification”; enumerate the model inputs and the expected review decision before evaluating it.
- [ ] **UC-M01.01-C015-T02 · Expected-result oracle:** Specify the “Asset classification” expected result independently of the implementation output; include the property “Evidence and secret material have distinct access rules” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M01.01-C015-T03 · Fixture material:** Create the concrete “Asset classification” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M01.01-C015-T04 · Target preparation:** Prepare the “Asset classification” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M01.01-C015-T05 · Initial-state record:** Record the initial “Asset classification” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M01.01-C015-T06 · Valid-path execution:** Evaluate the “Asset classification” example against the reviewed model; where a runtime mechanism exists, run its corresponding fixture and label those observations separately.
- [ ] **UC-M01.01-C015-T07 · Outcome comparison:** Compare every declared “Asset classification” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M01.01-C015-T08 · State and bounds check:** Inspect the “Asset classification” ownership/state effects and actual use of “Asset classes, retained copies and classification coverage”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M01.01-C015-T09 · Repeatability check:** Repeat the same “Asset classification” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M01.01-C015-T10 · Positive evidence:** Attach the “Asset classification” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M01.01-C016 · Negative test

**Original checklist item:** Negative case: A public support record contains an operator credential. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M01.01-C016-T01 · Adverse-case definition:** Create a test record for the exact “Asset classification” source counterexample: “A public support record contains an operator credential”; state which precondition or invariant it challenges.
- [ ] **UC-M01.01-C016-T02 · Safe fixture boundary:** Define the contained test boundary for “Asset classification”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M01.01-C016-T03 · Valid control:** Construct a valid “Asset classification” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M01.01-C016-T04 · Minimal adverse input:** Derive the “Asset classification” adverse fixture from the control with the smallest documented change needed to reproduce “A public support record contains an operator credential”; retain that change as reproducible data.
- [ ] **UC-M01.01-C016-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Asset classification”; require “Evidence and secret material have distinct access rules” and forbid a false-success verdict.
- [ ] **UC-M01.01-C016-T06 · Adverse execution:** Evaluate the “Asset classification” adverse case through the actual review/contract gate; where implemented, also observe the runtime refusal and keep the two evidence classes separate.
- [ ] **UC-M01.01-C016-T07 · Effect inspection:** Inspect “Asset classification” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M01.01-C016-T08 · Refusal versus failure:** Confirm the “Asset classification” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M01.01-C016-T09 · Reset and retention:** Restore only the disposable “Asset classification” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M01.01-C016-T10 · Negative regression:** Register the “Asset classification” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M01.01-C017 · Change / failure test

**Original checklist item:** Exercise asset classification when an entry point or trusted actor is added after the model was reviewed; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M01.01-C017-T01 · Scenario record:** Write the “Asset classification” change/failure scenario exactly as supplied: an entry point or trusted actor is added after the model was reviewed; identify the property that must remain true: “Evidence and secret material have distinct access rules”.
- [ ] **UC-M01.01-C017-T02 · Baseline capture:** Create a known-valid “Asset classification” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M01.01-C017-T03 · Injection map:** Locate the “Asset classification” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M01.01-C017-T04 · Disposition oracle:** Define the legal intermediate and final “Asset classification” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M01.01-C017-T05 · Controlled trigger:** Apply the controlled model-change scenario for “Asset classification”: an entry point or trusted actor is added after the model was reviewed; retain the exact before/after declarations. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M01.01-C017-T06 · Intermediate inspection:** Review which “Asset classification” claims, approvals and evidence references become stale after the change; keep unresolved enforcement gaps visible.
- [ ] **UC-M01.01-C017-T07 · Recovery path:** Revise or explicitly refuse the changed “Asset classification” model under the documented compatibility policy; re-review affected claims before restoring their approval.
- [ ] **UC-M01.01-C017-T08 · Stale-evidence cleanup:** Invalidate superseded “Asset classification” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M01.01-C017-T09 · Repeat and compare:** Repeat the selected “Asset classification” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M01.01-C017-T10 · Failure evidence:** Publish the “Asset classification” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M01.01-C018 · Bounds

**Original checklist item:** Define completeness and scaling criteria for asset classes, retained copies and classification coverage; exercise larger inventories or fixture sets, and report uncovered scope instead of silently excluding it.

- [ ] **UC-M01.01-C018-T01 · Quantity inventory:** Create a measurement inventory for “Asset classification”: “Asset classes, retained copies and classification coverage”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M01.01-C018-T02 · Measurement method:** Choose how to observe each “Asset classification” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M01.01-C018-T03 · Budget decision:** Select justified coverage and completeness limits for “Asset classification”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M01.01-C018-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Asset classification” cases for “Asset classes, retained copies and classification coverage”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M01.01-C018-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Asset classification” limit; preserve “Evidence and secret material have distinct access rules”.
- [ ] **UC-M01.01-C018-T06 · Normal measurement:** Run or review the normal “Asset classification” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M01.01-C018-T07 · At-limit measurement:** Exercise the “Asset classification” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M01.01-C018-T08 · Over-limit measurement:** Exercise the “Asset classification” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M01.01-C018-T09 · Uncovered-scope report:** List the “Asset classification” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M01.01-C018-T10 · Limit evidence:** Publish the selected “Asset classification” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M01.01-C019 · Diagnostics / review

**Original checklist item:** Record the rationale, unresolved assumptions, enforcement gaps and re-review triggers for asset classification; make design-only claims visibly distinct from observed behavior.

- [ ] **UC-M01.01-C019-T01 · Review inventory:** List the “Asset classification” decisions and claims requiring review; distinguish source requirements, implementation observations and engineering assumptions.
- [ ] **UC-M01.01-C019-T02 · Rationale record:** Write the rationale for the selected “Asset classification” representation or policy; link each choice to the requirement rather than an unexplained preference.
- [ ] **UC-M01.01-C019-T03 · Assumption ledger:** Record unresolved “Asset classification” assumptions, their owner and what observation or decision would resolve them; do not treat unknowns as approvals.
- [ ] **UC-M01.01-C019-T04 · Boundary map:** Map each “Asset classification” claim to an actual guard or explicit design/review gate; flag gaps against “Evidence and secret material have distinct access rules”.
- [ ] **UC-M01.01-C019-T05 · Counterexample review:** Walk reviewers through the “Asset classification” counterexample “A public support record contains an operator credential”; record whether the model detects it and whether any runtime guard was actually exercised.
- [ ] **UC-M01.01-C019-T06 · Review outcome vocabulary:** Define approved, blocked, superseded and untested review outcomes for “Asset classification”; ensure the wording cannot be read as runtime enforcement evidence.
- [ ] **UC-M01.01-C019-T07 · Re-review triggers:** List “Asset classification” invalidation triggers, including the source change scenario: an entry point or trusted actor is added after the model was reviewed; identify the affected claims and evidence.
- [ ] **UC-M01.01-C019-T08 · Sensitive-data review:** Inspect the “Asset classification” review record for secrets and unrelated user content; retain nonsecret references sufficient for reproducibility.
- [ ] **UC-M01.01-C019-T09 · Independent reading:** Have the “Asset classification” record read against the original acceptance criterion and entry-point inventory, policy decisions and observed host enforcement; record misunderstandings or missing evidence as corrections.
- [ ] **UC-M01.01-C019-T10 · Review disposition:** Publish the “Asset classification” rationale, versioned review outcome, unresolved gaps and explicit next decision; keep blockers open until supported evidence resolves them.

### UC-M01.01-C020 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for asset classification; label unexecuted checks as untested.

- [ ] **UC-M01.01-C020-T01 · Evidence inventory:** List the “Asset classification” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M01.01-C020-T02 · Artifact references:** Record the exact “Asset classification” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M01.01-C020-T03 · Fixture references:** Attach the “Asset classification” fixture IDs, input identities and oracle definition; preserve the source counterexample “A public support record contains an operator credential” as a distinct evidence case.
- [ ] **UC-M01.01-C020-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Asset classification”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M01.01-C020-T05 · Environment record:** Record the actual “Asset classification” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M01.01-C020-T06 · Expected versus observed:** Pair every “Asset classification” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M01.01-C020-T07 · Failure and limit records:** Attach “Asset classification” change/failure and bounds evidence where required; include uncovered “Asset classes, retained copies and classification coverage” and unresolved violations of “Evidence and secret material have distinct access rules”.
- [ ] **UC-M01.01-C020-T08 · Evidence hygiene:** Check the “Asset classification” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M01.01-C020-T09 · Reproduction review:** Have the “Asset classification” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M01.01-C020-T10 · Acceptance linkage:** Link the “Asset classification” evidence to its parent and UC-M01.01 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 03. Entry-point mapping

**Source delivery:** Map CLI, archive, decoder, loader, broker and guest-device entry points to their callers.

**Source invariant:** Every executable entry point has an identified enforcement boundary.

**Source negative case:** An import path invokes a decoder absent from the threat model.

**Source bounded quantities:** Entry points, nested import depth and uncovered paths.

### UC-M01.01-C021 · Contract

**Original checklist item:** Specify the scope and representation of entry-point mapping; identify its producer, consumer, authority assumptions and explicitly unsupported cases.

- [ ] **UC-M01.01-C021-T01 · Scope statement:** Draft a scope note for “Entry-point mapping” within Trust-boundary and capability model; separate required model statements, explicit exclusions and unresolved design decisions.
- [ ] **UC-M01.01-C021-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Entry-point mapping”; record each producer, representation and missing-value meaning.
- [ ] **UC-M01.01-C021-T03 · Output inventory:** List the outputs of “Entry-point mapping” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M01.01-C021-T04 · Field dictionary:** Create a field-and-term dictionary for “Entry-point mapping”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M01.01-C021-T05 · Prerequisite contract:** Map “Entry-point mapping” to the source component prerequisites (none declared; foundational work); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M01.01-C021-T06 · Authority map:** Identify who may produce, change and consume “Entry-point mapping”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M01.01-C021-T07 · Invariant clause:** Add a normative clause for “Entry-point mapping” that preserves “Every executable entry point has an identified enforcement boundary”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M01.01-C021-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Entry-point mapping”; include the source counterexample “An import path invokes a decoder absent from the threat model” and the intended safe disposition.
- [ ] **UC-M01.01-C021-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Entry points, nested import depth and uncovered paths” in the “Entry-point mapping” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M01.01-C021-T10 · Contract review:** Review the “Entry-point mapping” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M01.01-C022 · Delivery

**Original checklist item:** Map CLI, archive, decoder, loader, broker and guest-device entry points to their callers.

- [ ] **UC-M01.01-C022-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Entry-point mapping”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M01.01-C022-T02 · Change plan:** Break the source delivery for “Entry-point mapping” into concrete edit targets and reviewable outputs; keep the UC-M01.01 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M01.01-C022-T03 · Core artifact:** Create the “Entry-point mapping” model, schema or inventory that realizes this source instruction: Map CLI, archive, decoder, loader, broker and guest-device entry points to their callers.
- [ ] **UC-M01.01-C022-T04 · Concrete realization:** Populate “Entry-point mapping” with one concrete worked case; map every required entity or field to its source and flag any unmapped entry.
- [ ] **UC-M01.01-C022-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Entry-point mapping” needed to preserve “Every executable entry point has an identified enforcement boundary”; record an enforcement gap where only a model exists.
- [ ] **UC-M01.01-C022-T06 · Dependency connection:** Connect the “Entry-point mapping” specification to entry-point inventory, policy decisions and observed host enforcement; record code coverage separately where the design is not yet enforced.
- [ ] **UC-M01.01-C022-T07 · Resource behavior:** Account for “Entry points, nested import depth and uncovered paths” in “Entry-point mapping”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M01.01-C022-T08 · Delivery check:** Walk the populated “Entry-point mapping” model through a valid example and the source counterexample “An import path invokes a decoder absent from the threat model”; record corrections and unresolved enforcement gaps.
- [ ] **UC-M01.01-C022-T09 · Patch review:** Review the “Entry-point mapping” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M01.01-C022-T10 · Delivery handoff:** Publish the “Entry-point mapping” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M01.01-C023 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Every executable entry point has an identified enforcement boundary. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M01.01-C023-T01 · Named property:** Create a stable property/check name under this parent for “Entry-point mapping”; copy its required invariant exactly: “Every executable entry point has an identified enforcement boundary”.
- [ ] **UC-M01.01-C023-T02 · Observable terms:** Define each term in the “Entry-point mapping” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M01.01-C023-T03 · Precondition set:** List the preconditions under which “Every executable entry point has an identified enforcement boundary” must hold for “Entry-point mapping”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M01.01-C023-T04 · Transition coverage:** Map the “Entry-point mapping” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M01.01-C023-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Entry-point mapping”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M01.01-C023-T06 · Satisfying fixture:** Create a concrete “Entry-point mapping” case that satisfies “Every executable entry point has an identified enforcement boundary”; record its expected observation before running the assertion or review.
- [ ] **UC-M01.01-C023-T07 · Violating fixture:** Create the source counterexample “An import path invokes a decoder absent from the threat model” for “Entry-point mapping”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M01.01-C023-T08 · Enforcement evidence:** Exercise the “Entry-point mapping” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M01.01-C023-T09 · Regression linkage:** Link the “Entry-point mapping” property to changes in entry-point inventory, policy decisions and observed host enforcement; record which dependency or contract changes require rerunning it.
- [ ] **UC-M01.01-C023-T10 · Property disposition:** Compare the satisfying and violating “Entry-point mapping” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M01.01-C024 · Integration

**Original checklist item:** Integrate entry-point mapping with entry-point inventory, policy decisions and observed host enforcement; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M01.01-C024-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Entry-point mapping” across entry-point inventory, policy decisions and observed host enforcement; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M01.01-C024-T02 · Field mapping:** Map every “Entry-point mapping” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M01.01-C024-T03 · Prerequisite identities:** Record the actual prerequisites for “Entry-point mapping” (source dependency list: none declared; foundational work); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M01.01-C024-T04 · Ownership agreement:** Specify who owns “Entry-point mapping” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M01.01-C024-T05 · Handoff implementation:** Connect “Entry-point mapping” through the mapped seam using the real adapter or explicit specification reference; preserve “Every executable entry point has an identified enforcement boundary” across the handoff.
- [ ] **UC-M01.01-C024-T06 · Absent-input case:** Omit one required “Entry-point mapping” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M01.01-C024-T07 · Stale-input case:** Supply an outdated “Entry-point mapping” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M01.01-C024-T08 · Incompatible-input case:** Supply an incompatible “Entry-point mapping” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M01.01-C024-T09 · Valid integration trace:** Run a valid “Entry-point mapping” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M01.01-C024-T10 · Seam review:** Reconcile the “Entry-point mapping” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M01.01-C025 · Valid-case test

**Original checklist item:** Construct a valid worked example for entry-point mapping; evaluate it against predeclared expected decisions and, where enforcement exists, run the corresponding conformance fixture.

- [ ] **UC-M01.01-C025-T01 · Valid fixture choice:** Select one concrete valid worked example for “Entry-point mapping”; enumerate the model inputs and the expected review decision before evaluating it.
- [ ] **UC-M01.01-C025-T02 · Expected-result oracle:** Specify the “Entry-point mapping” expected result independently of the implementation output; include the property “Every executable entry point has an identified enforcement boundary” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M01.01-C025-T03 · Fixture material:** Create the concrete “Entry-point mapping” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M01.01-C025-T04 · Target preparation:** Prepare the “Entry-point mapping” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M01.01-C025-T05 · Initial-state record:** Record the initial “Entry-point mapping” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M01.01-C025-T06 · Valid-path execution:** Evaluate the “Entry-point mapping” example against the reviewed model; where a runtime mechanism exists, run its corresponding fixture and label those observations separately.
- [ ] **UC-M01.01-C025-T07 · Outcome comparison:** Compare every declared “Entry-point mapping” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M01.01-C025-T08 · State and bounds check:** Inspect the “Entry-point mapping” ownership/state effects and actual use of “Entry points, nested import depth and uncovered paths”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M01.01-C025-T09 · Repeatability check:** Repeat the same “Entry-point mapping” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M01.01-C025-T10 · Positive evidence:** Attach the “Entry-point mapping” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M01.01-C026 · Negative test

**Original checklist item:** Negative case: An import path invokes a decoder absent from the threat model. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M01.01-C026-T01 · Adverse-case definition:** Create a test record for the exact “Entry-point mapping” source counterexample: “An import path invokes a decoder absent from the threat model”; state which precondition or invariant it challenges.
- [ ] **UC-M01.01-C026-T02 · Safe fixture boundary:** Define the contained test boundary for “Entry-point mapping”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M01.01-C026-T03 · Valid control:** Construct a valid “Entry-point mapping” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M01.01-C026-T04 · Minimal adverse input:** Derive the “Entry-point mapping” adverse fixture from the control with the smallest documented change needed to reproduce “An import path invokes a decoder absent from the threat model”; retain that change as reproducible data.
- [ ] **UC-M01.01-C026-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Entry-point mapping”; require “Every executable entry point has an identified enforcement boundary” and forbid a false-success verdict.
- [ ] **UC-M01.01-C026-T06 · Adverse execution:** Evaluate the “Entry-point mapping” adverse case through the actual review/contract gate; where implemented, also observe the runtime refusal and keep the two evidence classes separate.
- [ ] **UC-M01.01-C026-T07 · Effect inspection:** Inspect “Entry-point mapping” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M01.01-C026-T08 · Refusal versus failure:** Confirm the “Entry-point mapping” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M01.01-C026-T09 · Reset and retention:** Restore only the disposable “Entry-point mapping” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M01.01-C026-T10 · Negative regression:** Register the “Entry-point mapping” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M01.01-C027 · Change / failure test

**Original checklist item:** Exercise entry-point mapping when an entry point or trusted actor is added after the model was reviewed; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M01.01-C027-T01 · Scenario record:** Write the “Entry-point mapping” change/failure scenario exactly as supplied: an entry point or trusted actor is added after the model was reviewed; identify the property that must remain true: “Every executable entry point has an identified enforcement boundary”.
- [ ] **UC-M01.01-C027-T02 · Baseline capture:** Create a known-valid “Entry-point mapping” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M01.01-C027-T03 · Injection map:** Locate the “Entry-point mapping” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M01.01-C027-T04 · Disposition oracle:** Define the legal intermediate and final “Entry-point mapping” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M01.01-C027-T05 · Controlled trigger:** Apply the controlled model-change scenario for “Entry-point mapping”: an entry point or trusted actor is added after the model was reviewed; retain the exact before/after declarations. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M01.01-C027-T06 · Intermediate inspection:** Review which “Entry-point mapping” claims, approvals and evidence references become stale after the change; keep unresolved enforcement gaps visible.
- [ ] **UC-M01.01-C027-T07 · Recovery path:** Revise or explicitly refuse the changed “Entry-point mapping” model under the documented compatibility policy; re-review affected claims before restoring their approval.
- [ ] **UC-M01.01-C027-T08 · Stale-evidence cleanup:** Invalidate superseded “Entry-point mapping” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M01.01-C027-T09 · Repeat and compare:** Repeat the selected “Entry-point mapping” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M01.01-C027-T10 · Failure evidence:** Publish the “Entry-point mapping” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M01.01-C028 · Bounds

**Original checklist item:** Define completeness and scaling criteria for entry points, nested import depth and uncovered paths; exercise larger inventories or fixture sets, and report uncovered scope instead of silently excluding it.

- [ ] **UC-M01.01-C028-T01 · Quantity inventory:** Create a measurement inventory for “Entry-point mapping”: “Entry points, nested import depth and uncovered paths”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M01.01-C028-T02 · Measurement method:** Choose how to observe each “Entry-point mapping” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M01.01-C028-T03 · Budget decision:** Select justified coverage and completeness limits for “Entry-point mapping”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M01.01-C028-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Entry-point mapping” cases for “Entry points, nested import depth and uncovered paths”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M01.01-C028-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Entry-point mapping” limit; preserve “Every executable entry point has an identified enforcement boundary”.
- [ ] **UC-M01.01-C028-T06 · Normal measurement:** Run or review the normal “Entry-point mapping” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M01.01-C028-T07 · At-limit measurement:** Exercise the “Entry-point mapping” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M01.01-C028-T08 · Over-limit measurement:** Exercise the “Entry-point mapping” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M01.01-C028-T09 · Uncovered-scope report:** List the “Entry-point mapping” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M01.01-C028-T10 · Limit evidence:** Publish the selected “Entry-point mapping” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M01.01-C029 · Diagnostics / review

**Original checklist item:** Record the rationale, unresolved assumptions, enforcement gaps and re-review triggers for entry-point mapping; make design-only claims visibly distinct from observed behavior.

- [ ] **UC-M01.01-C029-T01 · Review inventory:** List the “Entry-point mapping” decisions and claims requiring review; distinguish source requirements, implementation observations and engineering assumptions.
- [ ] **UC-M01.01-C029-T02 · Rationale record:** Write the rationale for the selected “Entry-point mapping” representation or policy; link each choice to the requirement rather than an unexplained preference.
- [ ] **UC-M01.01-C029-T03 · Assumption ledger:** Record unresolved “Entry-point mapping” assumptions, their owner and what observation or decision would resolve them; do not treat unknowns as approvals.
- [ ] **UC-M01.01-C029-T04 · Boundary map:** Map each “Entry-point mapping” claim to an actual guard or explicit design/review gate; flag gaps against “Every executable entry point has an identified enforcement boundary”.
- [ ] **UC-M01.01-C029-T05 · Counterexample review:** Walk reviewers through the “Entry-point mapping” counterexample “An import path invokes a decoder absent from the threat model”; record whether the model detects it and whether any runtime guard was actually exercised.
- [ ] **UC-M01.01-C029-T06 · Review outcome vocabulary:** Define approved, blocked, superseded and untested review outcomes for “Entry-point mapping”; ensure the wording cannot be read as runtime enforcement evidence.
- [ ] **UC-M01.01-C029-T07 · Re-review triggers:** List “Entry-point mapping” invalidation triggers, including the source change scenario: an entry point or trusted actor is added after the model was reviewed; identify the affected claims and evidence.
- [ ] **UC-M01.01-C029-T08 · Sensitive-data review:** Inspect the “Entry-point mapping” review record for secrets and unrelated user content; retain nonsecret references sufficient for reproducibility.
- [ ] **UC-M01.01-C029-T09 · Independent reading:** Have the “Entry-point mapping” record read against the original acceptance criterion and entry-point inventory, policy decisions and observed host enforcement; record misunderstandings or missing evidence as corrections.
- [ ] **UC-M01.01-C029-T10 · Review disposition:** Publish the “Entry-point mapping” rationale, versioned review outcome, unresolved gaps and explicit next decision; keep blockers open until supported evidence resolves them.

### UC-M01.01-C030 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for entry-point mapping; label unexecuted checks as untested.

- [ ] **UC-M01.01-C030-T01 · Evidence inventory:** List the “Entry-point mapping” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M01.01-C030-T02 · Artifact references:** Record the exact “Entry-point mapping” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M01.01-C030-T03 · Fixture references:** Attach the “Entry-point mapping” fixture IDs, input identities and oracle definition; preserve the source counterexample “An import path invokes a decoder absent from the threat model” as a distinct evidence case.
- [ ] **UC-M01.01-C030-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Entry-point mapping”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M01.01-C030-T05 · Environment record:** Record the actual “Entry-point mapping” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M01.01-C030-T06 · Expected versus observed:** Pair every “Entry-point mapping” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M01.01-C030-T07 · Failure and limit records:** Attach “Entry-point mapping” change/failure and bounds evidence where required; include uncovered “Entry points, nested import depth and uncovered paths” and unresolved violations of “Every executable entry point has an identified enforcement boundary”.
- [ ] **UC-M01.01-C030-T08 · Evidence hygiene:** Check the “Entry-point mapping” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M01.01-C030-T09 · Reproduction review:** Have the “Entry-point mapping” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M01.01-C030-T10 · Acceptance linkage:** Link the “Entry-point mapping” evidence to its parent and UC-M01.01 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 04. Boundary inventory

**Source delivery:** Describe transitions among the management process, native engine, guest, VMM and host.

**Source invariant:** A subprocess boundary is not represented as a hypervisor boundary.

**Source negative case:** A host interpreter advertises the isolated-guest class.

**Source bounded quantities:** Boundary classes and supported host/backend combinations.

### UC-M01.01-C031 · Contract

**Original checklist item:** Specify the scope and representation of boundary inventory; identify its producer, consumer, authority assumptions and explicitly unsupported cases.

- [ ] **UC-M01.01-C031-T01 · Scope statement:** Draft a scope note for “Boundary inventory” within Trust-boundary and capability model; separate required model statements, explicit exclusions and unresolved design decisions.
- [ ] **UC-M01.01-C031-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Boundary inventory”; record each producer, representation and missing-value meaning.
- [ ] **UC-M01.01-C031-T03 · Output inventory:** List the outputs of “Boundary inventory” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M01.01-C031-T04 · Field dictionary:** Create a field-and-term dictionary for “Boundary inventory”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M01.01-C031-T05 · Prerequisite contract:** Map “Boundary inventory” to the source component prerequisites (none declared; foundational work); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M01.01-C031-T06 · Authority map:** Identify who may produce, change and consume “Boundary inventory”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M01.01-C031-T07 · Invariant clause:** Add a normative clause for “Boundary inventory” that preserves “A subprocess boundary is not represented as a hypervisor boundary”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M01.01-C031-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Boundary inventory”; include the source counterexample “A host interpreter advertises the isolated-guest class” and the intended safe disposition.
- [ ] **UC-M01.01-C031-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Boundary classes and supported host/backend combinations” in the “Boundary inventory” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M01.01-C031-T10 · Contract review:** Review the “Boundary inventory” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M01.01-C032 · Delivery

**Original checklist item:** Describe transitions among the management process, native engine, guest, VMM and host.

- [ ] **UC-M01.01-C032-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Boundary inventory”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M01.01-C032-T02 · Change plan:** Break the source delivery for “Boundary inventory” into concrete edit targets and reviewable outputs; keep the UC-M01.01 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M01.01-C032-T03 · Core artifact:** Create the “Boundary inventory” model, schema or inventory that realizes this source instruction: Describe transitions among the management process, native engine, guest, VMM and host.
- [ ] **UC-M01.01-C032-T04 · Concrete realization:** Populate “Boundary inventory” with one concrete worked case; map every required entity or field to its source and flag any unmapped entry.
- [ ] **UC-M01.01-C032-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Boundary inventory” needed to preserve “A subprocess boundary is not represented as a hypervisor boundary”; record an enforcement gap where only a model exists.
- [ ] **UC-M01.01-C032-T06 · Dependency connection:** Connect the “Boundary inventory” specification to entry-point inventory, policy decisions and observed host enforcement; record code coverage separately where the design is not yet enforced.
- [ ] **UC-M01.01-C032-T07 · Resource behavior:** Account for “Boundary classes and supported host/backend combinations” in “Boundary inventory”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M01.01-C032-T08 · Delivery check:** Walk the populated “Boundary inventory” model through a valid example and the source counterexample “A host interpreter advertises the isolated-guest class”; record corrections and unresolved enforcement gaps.
- [ ] **UC-M01.01-C032-T09 · Patch review:** Review the “Boundary inventory” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M01.01-C032-T10 · Delivery handoff:** Publish the “Boundary inventory” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M01.01-C033 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: A subprocess boundary is not represented as a hypervisor boundary. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M01.01-C033-T01 · Named property:** Create a stable property/check name under this parent for “Boundary inventory”; copy its required invariant exactly: “A subprocess boundary is not represented as a hypervisor boundary”.
- [ ] **UC-M01.01-C033-T02 · Observable terms:** Define each term in the “Boundary inventory” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M01.01-C033-T03 · Precondition set:** List the preconditions under which “A subprocess boundary is not represented as a hypervisor boundary” must hold for “Boundary inventory”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M01.01-C033-T04 · Transition coverage:** Map the “Boundary inventory” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M01.01-C033-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Boundary inventory”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M01.01-C033-T06 · Satisfying fixture:** Create a concrete “Boundary inventory” case that satisfies “A subprocess boundary is not represented as a hypervisor boundary”; record its expected observation before running the assertion or review.
- [ ] **UC-M01.01-C033-T07 · Violating fixture:** Create the source counterexample “A host interpreter advertises the isolated-guest class” for “Boundary inventory”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M01.01-C033-T08 · Enforcement evidence:** Exercise the “Boundary inventory” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M01.01-C033-T09 · Regression linkage:** Link the “Boundary inventory” property to changes in entry-point inventory, policy decisions and observed host enforcement; record which dependency or contract changes require rerunning it.
- [ ] **UC-M01.01-C033-T10 · Property disposition:** Compare the satisfying and violating “Boundary inventory” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M01.01-C034 · Integration

**Original checklist item:** Integrate boundary inventory with entry-point inventory, policy decisions and observed host enforcement; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M01.01-C034-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Boundary inventory” across entry-point inventory, policy decisions and observed host enforcement; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M01.01-C034-T02 · Field mapping:** Map every “Boundary inventory” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M01.01-C034-T03 · Prerequisite identities:** Record the actual prerequisites for “Boundary inventory” (source dependency list: none declared; foundational work); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M01.01-C034-T04 · Ownership agreement:** Specify who owns “Boundary inventory” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M01.01-C034-T05 · Handoff implementation:** Connect “Boundary inventory” through the mapped seam using the real adapter or explicit specification reference; preserve “A subprocess boundary is not represented as a hypervisor boundary” across the handoff.
- [ ] **UC-M01.01-C034-T06 · Absent-input case:** Omit one required “Boundary inventory” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M01.01-C034-T07 · Stale-input case:** Supply an outdated “Boundary inventory” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M01.01-C034-T08 · Incompatible-input case:** Supply an incompatible “Boundary inventory” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M01.01-C034-T09 · Valid integration trace:** Run a valid “Boundary inventory” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M01.01-C034-T10 · Seam review:** Reconcile the “Boundary inventory” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M01.01-C035 · Valid-case test

**Original checklist item:** Construct a valid worked example for boundary inventory; evaluate it against predeclared expected decisions and, where enforcement exists, run the corresponding conformance fixture.

- [ ] **UC-M01.01-C035-T01 · Valid fixture choice:** Select one concrete valid worked example for “Boundary inventory”; enumerate the model inputs and the expected review decision before evaluating it.
- [ ] **UC-M01.01-C035-T02 · Expected-result oracle:** Specify the “Boundary inventory” expected result independently of the implementation output; include the property “A subprocess boundary is not represented as a hypervisor boundary” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M01.01-C035-T03 · Fixture material:** Create the concrete “Boundary inventory” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M01.01-C035-T04 · Target preparation:** Prepare the “Boundary inventory” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M01.01-C035-T05 · Initial-state record:** Record the initial “Boundary inventory” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M01.01-C035-T06 · Valid-path execution:** Evaluate the “Boundary inventory” example against the reviewed model; where a runtime mechanism exists, run its corresponding fixture and label those observations separately.
- [ ] **UC-M01.01-C035-T07 · Outcome comparison:** Compare every declared “Boundary inventory” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M01.01-C035-T08 · State and bounds check:** Inspect the “Boundary inventory” ownership/state effects and actual use of “Boundary classes and supported host/backend combinations”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M01.01-C035-T09 · Repeatability check:** Repeat the same “Boundary inventory” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M01.01-C035-T10 · Positive evidence:** Attach the “Boundary inventory” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M01.01-C036 · Negative test

**Original checklist item:** Negative case: A host interpreter advertises the isolated-guest class. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M01.01-C036-T01 · Adverse-case definition:** Create a test record for the exact “Boundary inventory” source counterexample: “A host interpreter advertises the isolated-guest class”; state which precondition or invariant it challenges.
- [ ] **UC-M01.01-C036-T02 · Safe fixture boundary:** Define the contained test boundary for “Boundary inventory”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M01.01-C036-T03 · Valid control:** Construct a valid “Boundary inventory” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M01.01-C036-T04 · Minimal adverse input:** Derive the “Boundary inventory” adverse fixture from the control with the smallest documented change needed to reproduce “A host interpreter advertises the isolated-guest class”; retain that change as reproducible data.
- [ ] **UC-M01.01-C036-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Boundary inventory”; require “A subprocess boundary is not represented as a hypervisor boundary” and forbid a false-success verdict.
- [ ] **UC-M01.01-C036-T06 · Adverse execution:** Evaluate the “Boundary inventory” adverse case through the actual review/contract gate; where implemented, also observe the runtime refusal and keep the two evidence classes separate.
- [ ] **UC-M01.01-C036-T07 · Effect inspection:** Inspect “Boundary inventory” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M01.01-C036-T08 · Refusal versus failure:** Confirm the “Boundary inventory” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M01.01-C036-T09 · Reset and retention:** Restore only the disposable “Boundary inventory” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M01.01-C036-T10 · Negative regression:** Register the “Boundary inventory” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M01.01-C037 · Change / failure test

**Original checklist item:** Exercise boundary inventory when an entry point or trusted actor is added after the model was reviewed; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M01.01-C037-T01 · Scenario record:** Write the “Boundary inventory” change/failure scenario exactly as supplied: an entry point or trusted actor is added after the model was reviewed; identify the property that must remain true: “A subprocess boundary is not represented as a hypervisor boundary”.
- [ ] **UC-M01.01-C037-T02 · Baseline capture:** Create a known-valid “Boundary inventory” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M01.01-C037-T03 · Injection map:** Locate the “Boundary inventory” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M01.01-C037-T04 · Disposition oracle:** Define the legal intermediate and final “Boundary inventory” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M01.01-C037-T05 · Controlled trigger:** Apply the controlled model-change scenario for “Boundary inventory”: an entry point or trusted actor is added after the model was reviewed; retain the exact before/after declarations. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M01.01-C037-T06 · Intermediate inspection:** Review which “Boundary inventory” claims, approvals and evidence references become stale after the change; keep unresolved enforcement gaps visible.
- [ ] **UC-M01.01-C037-T07 · Recovery path:** Revise or explicitly refuse the changed “Boundary inventory” model under the documented compatibility policy; re-review affected claims before restoring their approval.
- [ ] **UC-M01.01-C037-T08 · Stale-evidence cleanup:** Invalidate superseded “Boundary inventory” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M01.01-C037-T09 · Repeat and compare:** Repeat the selected “Boundary inventory” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M01.01-C037-T10 · Failure evidence:** Publish the “Boundary inventory” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M01.01-C038 · Bounds

**Original checklist item:** Define completeness and scaling criteria for boundary classes and supported host/backend combinations; exercise larger inventories or fixture sets, and report uncovered scope instead of silently excluding it.

- [ ] **UC-M01.01-C038-T01 · Quantity inventory:** Create a measurement inventory for “Boundary inventory”: “Boundary classes and supported host/backend combinations”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M01.01-C038-T02 · Measurement method:** Choose how to observe each “Boundary inventory” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M01.01-C038-T03 · Budget decision:** Select justified coverage and completeness limits for “Boundary inventory”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M01.01-C038-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Boundary inventory” cases for “Boundary classes and supported host/backend combinations”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M01.01-C038-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Boundary inventory” limit; preserve “A subprocess boundary is not represented as a hypervisor boundary”.
- [ ] **UC-M01.01-C038-T06 · Normal measurement:** Run or review the normal “Boundary inventory” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M01.01-C038-T07 · At-limit measurement:** Exercise the “Boundary inventory” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M01.01-C038-T08 · Over-limit measurement:** Exercise the “Boundary inventory” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M01.01-C038-T09 · Uncovered-scope report:** List the “Boundary inventory” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M01.01-C038-T10 · Limit evidence:** Publish the selected “Boundary inventory” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M01.01-C039 · Diagnostics / review

**Original checklist item:** Record the rationale, unresolved assumptions, enforcement gaps and re-review triggers for boundary inventory; make design-only claims visibly distinct from observed behavior.

- [ ] **UC-M01.01-C039-T01 · Review inventory:** List the “Boundary inventory” decisions and claims requiring review; distinguish source requirements, implementation observations and engineering assumptions.
- [ ] **UC-M01.01-C039-T02 · Rationale record:** Write the rationale for the selected “Boundary inventory” representation or policy; link each choice to the requirement rather than an unexplained preference.
- [ ] **UC-M01.01-C039-T03 · Assumption ledger:** Record unresolved “Boundary inventory” assumptions, their owner and what observation or decision would resolve them; do not treat unknowns as approvals.
- [ ] **UC-M01.01-C039-T04 · Boundary map:** Map each “Boundary inventory” claim to an actual guard or explicit design/review gate; flag gaps against “A subprocess boundary is not represented as a hypervisor boundary”.
- [ ] **UC-M01.01-C039-T05 · Counterexample review:** Walk reviewers through the “Boundary inventory” counterexample “A host interpreter advertises the isolated-guest class”; record whether the model detects it and whether any runtime guard was actually exercised.
- [ ] **UC-M01.01-C039-T06 · Review outcome vocabulary:** Define approved, blocked, superseded and untested review outcomes for “Boundary inventory”; ensure the wording cannot be read as runtime enforcement evidence.
- [ ] **UC-M01.01-C039-T07 · Re-review triggers:** List “Boundary inventory” invalidation triggers, including the source change scenario: an entry point or trusted actor is added after the model was reviewed; identify the affected claims and evidence.
- [ ] **UC-M01.01-C039-T08 · Sensitive-data review:** Inspect the “Boundary inventory” review record for secrets and unrelated user content; retain nonsecret references sufficient for reproducibility.
- [ ] **UC-M01.01-C039-T09 · Independent reading:** Have the “Boundary inventory” record read against the original acceptance criterion and entry-point inventory, policy decisions and observed host enforcement; record misunderstandings or missing evidence as corrections.
- [ ] **UC-M01.01-C039-T10 · Review disposition:** Publish the “Boundary inventory” rationale, versioned review outcome, unresolved gaps and explicit next decision; keep blockers open until supported evidence resolves them.

### UC-M01.01-C040 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for boundary inventory; label unexecuted checks as untested.

- [ ] **UC-M01.01-C040-T01 · Evidence inventory:** List the “Boundary inventory” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M01.01-C040-T02 · Artifact references:** Record the exact “Boundary inventory” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M01.01-C040-T03 · Fixture references:** Attach the “Boundary inventory” fixture IDs, input identities and oracle definition; preserve the source counterexample “A host interpreter advertises the isolated-guest class” as a distinct evidence case.
- [ ] **UC-M01.01-C040-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Boundary inventory”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M01.01-C040-T05 · Environment record:** Record the actual “Boundary inventory” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M01.01-C040-T06 · Expected versus observed:** Pair every “Boundary inventory” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M01.01-C040-T07 · Failure and limit records:** Attach “Boundary inventory” change/failure and bounds evidence where required; include uncovered “Boundary classes and supported host/backend combinations” and unresolved violations of “A subprocess boundary is not represented as a hypervisor boundary”.
- [ ] **UC-M01.01-C040-T08 · Evidence hygiene:** Check the “Boundary inventory” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M01.01-C040-T09 · Reproduction review:** Have the “Boundary inventory” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M01.01-C040-T10 · Acceptance linkage:** Link the “Boundary inventory” evidence to its parent and UC-M01.01 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 05. Capability vocabulary

**Source delivery:** Separate control-plane permissions, guest capabilities and evidence status in the model.

**Source invariant:** A proof-status field cannot grant execution permission.

**Source negative case:** A passing witness is supplied instead of execute permission.

**Source bounded quantities:** Capability vocabulary size and extension count.

### UC-M01.01-C041 · Contract

**Original checklist item:** Specify the scope and representation of capability vocabulary; identify its producer, consumer, authority assumptions and explicitly unsupported cases.

- [ ] **UC-M01.01-C041-T01 · Scope statement:** Draft a scope note for “Capability vocabulary” within Trust-boundary and capability model; separate required model statements, explicit exclusions and unresolved design decisions.
- [ ] **UC-M01.01-C041-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Capability vocabulary”; record each producer, representation and missing-value meaning.
- [ ] **UC-M01.01-C041-T03 · Output inventory:** List the outputs of “Capability vocabulary” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M01.01-C041-T04 · Field dictionary:** Create a field-and-term dictionary for “Capability vocabulary”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M01.01-C041-T05 · Prerequisite contract:** Map “Capability vocabulary” to the source component prerequisites (none declared; foundational work); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M01.01-C041-T06 · Authority map:** Identify who may produce, change and consume “Capability vocabulary”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M01.01-C041-T07 · Invariant clause:** Add a normative clause for “Capability vocabulary” that preserves “A proof-status field cannot grant execution permission”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M01.01-C041-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Capability vocabulary”; include the source counterexample “A passing witness is supplied instead of execute permission” and the intended safe disposition.
- [ ] **UC-M01.01-C041-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Capability vocabulary size and extension count” in the “Capability vocabulary” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M01.01-C041-T10 · Contract review:** Review the “Capability vocabulary” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M01.01-C042 · Delivery

**Original checklist item:** Separate control-plane permissions, guest capabilities and evidence status in the model.

- [ ] **UC-M01.01-C042-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Capability vocabulary”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M01.01-C042-T02 · Change plan:** Break the source delivery for “Capability vocabulary” into concrete edit targets and reviewable outputs; keep the UC-M01.01 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M01.01-C042-T03 · Core artifact:** Implement the smallest selected-profile change for “Capability vocabulary” that realizes this source instruction: Separate control-plane permissions, guest capabilities and evidence status in the model.
- [ ] **UC-M01.01-C042-T04 · Concrete realization:** Trace “Capability vocabulary” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M01.01-C042-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Capability vocabulary” needed to preserve “A proof-status field cannot grant execution permission”; record an enforcement gap where only a model exists.
- [ ] **UC-M01.01-C042-T06 · Dependency connection:** Connect the “Capability vocabulary” specification to entry-point inventory, policy decisions and observed host enforcement; record code coverage separately where the design is not yet enforced.
- [ ] **UC-M01.01-C042-T07 · Resource behavior:** Account for “Capability vocabulary size and extension count” in “Capability vocabulary”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M01.01-C042-T08 · Delivery check:** Walk the populated “Capability vocabulary” model through a valid example and the source counterexample “A passing witness is supplied instead of execute permission”; record corrections and unresolved enforcement gaps.
- [ ] **UC-M01.01-C042-T09 · Patch review:** Review the “Capability vocabulary” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M01.01-C042-T10 · Delivery handoff:** Publish the “Capability vocabulary” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M01.01-C043 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: A proof-status field cannot grant execution permission. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M01.01-C043-T01 · Named property:** Create a stable property/check name under this parent for “Capability vocabulary”; copy its required invariant exactly: “A proof-status field cannot grant execution permission”.
- [ ] **UC-M01.01-C043-T02 · Observable terms:** Define each term in the “Capability vocabulary” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M01.01-C043-T03 · Precondition set:** List the preconditions under which “A proof-status field cannot grant execution permission” must hold for “Capability vocabulary”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M01.01-C043-T04 · Transition coverage:** Map the “Capability vocabulary” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M01.01-C043-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Capability vocabulary”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M01.01-C043-T06 · Satisfying fixture:** Create a concrete “Capability vocabulary” case that satisfies “A proof-status field cannot grant execution permission”; record its expected observation before running the assertion or review.
- [ ] **UC-M01.01-C043-T07 · Violating fixture:** Create the source counterexample “A passing witness is supplied instead of execute permission” for “Capability vocabulary”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M01.01-C043-T08 · Enforcement evidence:** Exercise the “Capability vocabulary” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M01.01-C043-T09 · Regression linkage:** Link the “Capability vocabulary” property to changes in entry-point inventory, policy decisions and observed host enforcement; record which dependency or contract changes require rerunning it.
- [ ] **UC-M01.01-C043-T10 · Property disposition:** Compare the satisfying and violating “Capability vocabulary” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M01.01-C044 · Integration

**Original checklist item:** Integrate capability vocabulary with entry-point inventory, policy decisions and observed host enforcement; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M01.01-C044-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Capability vocabulary” across entry-point inventory, policy decisions and observed host enforcement; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M01.01-C044-T02 · Field mapping:** Map every “Capability vocabulary” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M01.01-C044-T03 · Prerequisite identities:** Record the actual prerequisites for “Capability vocabulary” (source dependency list: none declared; foundational work); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M01.01-C044-T04 · Ownership agreement:** Specify who owns “Capability vocabulary” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M01.01-C044-T05 · Handoff implementation:** Connect “Capability vocabulary” through the mapped seam using the real adapter or explicit specification reference; preserve “A proof-status field cannot grant execution permission” across the handoff.
- [ ] **UC-M01.01-C044-T06 · Absent-input case:** Omit one required “Capability vocabulary” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M01.01-C044-T07 · Stale-input case:** Supply an outdated “Capability vocabulary” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M01.01-C044-T08 · Incompatible-input case:** Supply an incompatible “Capability vocabulary” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M01.01-C044-T09 · Valid integration trace:** Run a valid “Capability vocabulary” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M01.01-C044-T10 · Seam review:** Reconcile the “Capability vocabulary” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M01.01-C045 · Valid-case test

**Original checklist item:** Construct a valid worked example for capability vocabulary; evaluate it against predeclared expected decisions and, where enforcement exists, run the corresponding conformance fixture.

- [ ] **UC-M01.01-C045-T01 · Valid fixture choice:** Select one concrete valid worked example for “Capability vocabulary”; enumerate the model inputs and the expected review decision before evaluating it.
- [ ] **UC-M01.01-C045-T02 · Expected-result oracle:** Specify the “Capability vocabulary” expected result independently of the implementation output; include the property “A proof-status field cannot grant execution permission” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M01.01-C045-T03 · Fixture material:** Create the concrete “Capability vocabulary” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M01.01-C045-T04 · Target preparation:** Prepare the “Capability vocabulary” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M01.01-C045-T05 · Initial-state record:** Record the initial “Capability vocabulary” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M01.01-C045-T06 · Valid-path execution:** Evaluate the “Capability vocabulary” example against the reviewed model; where a runtime mechanism exists, run its corresponding fixture and label those observations separately.
- [ ] **UC-M01.01-C045-T07 · Outcome comparison:** Compare every declared “Capability vocabulary” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M01.01-C045-T08 · State and bounds check:** Inspect the “Capability vocabulary” ownership/state effects and actual use of “Capability vocabulary size and extension count”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M01.01-C045-T09 · Repeatability check:** Repeat the same “Capability vocabulary” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M01.01-C045-T10 · Positive evidence:** Attach the “Capability vocabulary” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M01.01-C046 · Negative test

**Original checklist item:** Negative case: A passing witness is supplied instead of execute permission. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M01.01-C046-T01 · Adverse-case definition:** Create a test record for the exact “Capability vocabulary” source counterexample: “A passing witness is supplied instead of execute permission”; state which precondition or invariant it challenges.
- [ ] **UC-M01.01-C046-T02 · Safe fixture boundary:** Define the contained test boundary for “Capability vocabulary”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M01.01-C046-T03 · Valid control:** Construct a valid “Capability vocabulary” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M01.01-C046-T04 · Minimal adverse input:** Derive the “Capability vocabulary” adverse fixture from the control with the smallest documented change needed to reproduce “A passing witness is supplied instead of execute permission”; retain that change as reproducible data.
- [ ] **UC-M01.01-C046-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Capability vocabulary”; require “A proof-status field cannot grant execution permission” and forbid a false-success verdict.
- [ ] **UC-M01.01-C046-T06 · Adverse execution:** Evaluate the “Capability vocabulary” adverse case through the actual review/contract gate; where implemented, also observe the runtime refusal and keep the two evidence classes separate.
- [ ] **UC-M01.01-C046-T07 · Effect inspection:** Inspect “Capability vocabulary” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M01.01-C046-T08 · Refusal versus failure:** Confirm the “Capability vocabulary” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M01.01-C046-T09 · Reset and retention:** Restore only the disposable “Capability vocabulary” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M01.01-C046-T10 · Negative regression:** Register the “Capability vocabulary” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M01.01-C047 · Change / failure test

**Original checklist item:** Exercise capability vocabulary when an entry point or trusted actor is added after the model was reviewed; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M01.01-C047-T01 · Scenario record:** Write the “Capability vocabulary” change/failure scenario exactly as supplied: an entry point or trusted actor is added after the model was reviewed; identify the property that must remain true: “A proof-status field cannot grant execution permission”.
- [ ] **UC-M01.01-C047-T02 · Baseline capture:** Create a known-valid “Capability vocabulary” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M01.01-C047-T03 · Injection map:** Locate the “Capability vocabulary” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M01.01-C047-T04 · Disposition oracle:** Define the legal intermediate and final “Capability vocabulary” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M01.01-C047-T05 · Controlled trigger:** Apply the controlled model-change scenario for “Capability vocabulary”: an entry point or trusted actor is added after the model was reviewed; retain the exact before/after declarations. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M01.01-C047-T06 · Intermediate inspection:** Review which “Capability vocabulary” claims, approvals and evidence references become stale after the change; keep unresolved enforcement gaps visible.
- [ ] **UC-M01.01-C047-T07 · Recovery path:** Revise or explicitly refuse the changed “Capability vocabulary” model under the documented compatibility policy; re-review affected claims before restoring their approval.
- [ ] **UC-M01.01-C047-T08 · Stale-evidence cleanup:** Invalidate superseded “Capability vocabulary” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M01.01-C047-T09 · Repeat and compare:** Repeat the selected “Capability vocabulary” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M01.01-C047-T10 · Failure evidence:** Publish the “Capability vocabulary” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M01.01-C048 · Bounds

**Original checklist item:** Define completeness and scaling criteria for capability vocabulary size and extension count; exercise larger inventories or fixture sets, and report uncovered scope instead of silently excluding it.

- [ ] **UC-M01.01-C048-T01 · Quantity inventory:** Create a measurement inventory for “Capability vocabulary”: “Capability vocabulary size and extension count”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M01.01-C048-T02 · Measurement method:** Choose how to observe each “Capability vocabulary” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M01.01-C048-T03 · Budget decision:** Select justified coverage and completeness limits for “Capability vocabulary”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M01.01-C048-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Capability vocabulary” cases for “Capability vocabulary size and extension count”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M01.01-C048-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Capability vocabulary” limit; preserve “A proof-status field cannot grant execution permission”.
- [ ] **UC-M01.01-C048-T06 · Normal measurement:** Run or review the normal “Capability vocabulary” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M01.01-C048-T07 · At-limit measurement:** Exercise the “Capability vocabulary” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M01.01-C048-T08 · Over-limit measurement:** Exercise the “Capability vocabulary” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M01.01-C048-T09 · Uncovered-scope report:** List the “Capability vocabulary” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M01.01-C048-T10 · Limit evidence:** Publish the selected “Capability vocabulary” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M01.01-C049 · Diagnostics / review

**Original checklist item:** Record the rationale, unresolved assumptions, enforcement gaps and re-review triggers for capability vocabulary; make design-only claims visibly distinct from observed behavior.

- [ ] **UC-M01.01-C049-T01 · Review inventory:** List the “Capability vocabulary” decisions and claims requiring review; distinguish source requirements, implementation observations and engineering assumptions.
- [ ] **UC-M01.01-C049-T02 · Rationale record:** Write the rationale for the selected “Capability vocabulary” representation or policy; link each choice to the requirement rather than an unexplained preference.
- [ ] **UC-M01.01-C049-T03 · Assumption ledger:** Record unresolved “Capability vocabulary” assumptions, their owner and what observation or decision would resolve them; do not treat unknowns as approvals.
- [ ] **UC-M01.01-C049-T04 · Boundary map:** Map each “Capability vocabulary” claim to an actual guard or explicit design/review gate; flag gaps against “A proof-status field cannot grant execution permission”.
- [ ] **UC-M01.01-C049-T05 · Counterexample review:** Walk reviewers through the “Capability vocabulary” counterexample “A passing witness is supplied instead of execute permission”; record whether the model detects it and whether any runtime guard was actually exercised.
- [ ] **UC-M01.01-C049-T06 · Review outcome vocabulary:** Define approved, blocked, superseded and untested review outcomes for “Capability vocabulary”; ensure the wording cannot be read as runtime enforcement evidence.
- [ ] **UC-M01.01-C049-T07 · Re-review triggers:** List “Capability vocabulary” invalidation triggers, including the source change scenario: an entry point or trusted actor is added after the model was reviewed; identify the affected claims and evidence.
- [ ] **UC-M01.01-C049-T08 · Sensitive-data review:** Inspect the “Capability vocabulary” review record for secrets and unrelated user content; retain nonsecret references sufficient for reproducibility.
- [ ] **UC-M01.01-C049-T09 · Independent reading:** Have the “Capability vocabulary” record read against the original acceptance criterion and entry-point inventory, policy decisions and observed host enforcement; record misunderstandings or missing evidence as corrections.
- [ ] **UC-M01.01-C049-T10 · Review disposition:** Publish the “Capability vocabulary” rationale, versioned review outcome, unresolved gaps and explicit next decision; keep blockers open until supported evidence resolves them.

### UC-M01.01-C050 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for capability vocabulary; label unexecuted checks as untested.

- [ ] **UC-M01.01-C050-T01 · Evidence inventory:** List the “Capability vocabulary” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M01.01-C050-T02 · Artifact references:** Record the exact “Capability vocabulary” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M01.01-C050-T03 · Fixture references:** Attach the “Capability vocabulary” fixture IDs, input identities and oracle definition; preserve the source counterexample “A passing witness is supplied instead of execute permission” as a distinct evidence case.
- [ ] **UC-M01.01-C050-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Capability vocabulary”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M01.01-C050-T05 · Environment record:** Record the actual “Capability vocabulary” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M01.01-C050-T06 · Expected versus observed:** Pair every “Capability vocabulary” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M01.01-C050-T07 · Failure and limit records:** Attach “Capability vocabulary” change/failure and bounds evidence where required; include uncovered “Capability vocabulary size and extension count” and unresolved violations of “A proof-status field cannot grant execution permission”.
- [ ] **UC-M01.01-C050-T08 · Evidence hygiene:** Check the “Capability vocabulary” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M01.01-C050-T09 · Reproduction review:** Have the “Capability vocabulary” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M01.01-C050-T10 · Acceptance linkage:** Link the “Capability vocabulary” evidence to its parent and UC-M01.01 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 06. Authority delegation

**Source delivery:** Specify how a principal may delegate a narrower capability to another actor.

**Source invariant:** Delegation cannot widen the issuer's authority.

**Source negative case:** A delegated capability requests additional devices.

**Source bounded quantities:** Delegation chain length and capability lifetime.

### UC-M01.01-C051 · Contract

**Original checklist item:** Specify the scope and representation of authority delegation; identify its producer, consumer, authority assumptions and explicitly unsupported cases.

- [ ] **UC-M01.01-C051-T01 · Scope statement:** Draft a scope note for “Authority delegation” within Trust-boundary and capability model; separate required model statements, explicit exclusions and unresolved design decisions.
- [ ] **UC-M01.01-C051-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Authority delegation”; record each producer, representation and missing-value meaning.
- [ ] **UC-M01.01-C051-T03 · Output inventory:** List the outputs of “Authority delegation” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M01.01-C051-T04 · Field dictionary:** Create a field-and-term dictionary for “Authority delegation”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M01.01-C051-T05 · Prerequisite contract:** Map “Authority delegation” to the source component prerequisites (none declared; foundational work); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M01.01-C051-T06 · Authority map:** Identify who may produce, change and consume “Authority delegation”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M01.01-C051-T07 · Invariant clause:** Add a normative clause for “Authority delegation” that preserves “Delegation cannot widen the issuer's authority”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M01.01-C051-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Authority delegation”; include the source counterexample “A delegated capability requests additional devices” and the intended safe disposition.
- [ ] **UC-M01.01-C051-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Delegation chain length and capability lifetime” in the “Authority delegation” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M01.01-C051-T10 · Contract review:** Review the “Authority delegation” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M01.01-C052 · Delivery

**Original checklist item:** Specify how a principal may delegate a narrower capability to another actor.

- [ ] **UC-M01.01-C052-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Authority delegation”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M01.01-C052-T02 · Change plan:** Break the source delivery for “Authority delegation” into concrete edit targets and reviewable outputs; keep the UC-M01.01 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M01.01-C052-T03 · Core artifact:** Create the “Authority delegation” model, schema or inventory that realizes this source instruction: Specify how a principal may delegate a narrower capability to another actor.
- [ ] **UC-M01.01-C052-T04 · Concrete realization:** Populate “Authority delegation” with one concrete worked case; map every required entity or field to its source and flag any unmapped entry.
- [ ] **UC-M01.01-C052-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Authority delegation” needed to preserve “Delegation cannot widen the issuer's authority”; record an enforcement gap where only a model exists.
- [ ] **UC-M01.01-C052-T06 · Dependency connection:** Connect the “Authority delegation” specification to entry-point inventory, policy decisions and observed host enforcement; record code coverage separately where the design is not yet enforced.
- [ ] **UC-M01.01-C052-T07 · Resource behavior:** Account for “Delegation chain length and capability lifetime” in “Authority delegation”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M01.01-C052-T08 · Delivery check:** Walk the populated “Authority delegation” model through a valid example and the source counterexample “A delegated capability requests additional devices”; record corrections and unresolved enforcement gaps.
- [ ] **UC-M01.01-C052-T09 · Patch review:** Review the “Authority delegation” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M01.01-C052-T10 · Delivery handoff:** Publish the “Authority delegation” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M01.01-C053 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Delegation cannot widen the issuer's authority. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M01.01-C053-T01 · Named property:** Create a stable property/check name under this parent for “Authority delegation”; copy its required invariant exactly: “Delegation cannot widen the issuer's authority”.
- [ ] **UC-M01.01-C053-T02 · Observable terms:** Define each term in the “Authority delegation” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M01.01-C053-T03 · Precondition set:** List the preconditions under which “Delegation cannot widen the issuer's authority” must hold for “Authority delegation”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M01.01-C053-T04 · Transition coverage:** Map the “Authority delegation” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M01.01-C053-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Authority delegation”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M01.01-C053-T06 · Satisfying fixture:** Create a concrete “Authority delegation” case that satisfies “Delegation cannot widen the issuer's authority”; record its expected observation before running the assertion or review.
- [ ] **UC-M01.01-C053-T07 · Violating fixture:** Create the source counterexample “A delegated capability requests additional devices” for “Authority delegation”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M01.01-C053-T08 · Enforcement evidence:** Exercise the “Authority delegation” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M01.01-C053-T09 · Regression linkage:** Link the “Authority delegation” property to changes in entry-point inventory, policy decisions and observed host enforcement; record which dependency or contract changes require rerunning it.
- [ ] **UC-M01.01-C053-T10 · Property disposition:** Compare the satisfying and violating “Authority delegation” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M01.01-C054 · Integration

**Original checklist item:** Integrate authority delegation with entry-point inventory, policy decisions and observed host enforcement; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M01.01-C054-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Authority delegation” across entry-point inventory, policy decisions and observed host enforcement; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M01.01-C054-T02 · Field mapping:** Map every “Authority delegation” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M01.01-C054-T03 · Prerequisite identities:** Record the actual prerequisites for “Authority delegation” (source dependency list: none declared; foundational work); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M01.01-C054-T04 · Ownership agreement:** Specify who owns “Authority delegation” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M01.01-C054-T05 · Handoff implementation:** Connect “Authority delegation” through the mapped seam using the real adapter or explicit specification reference; preserve “Delegation cannot widen the issuer's authority” across the handoff.
- [ ] **UC-M01.01-C054-T06 · Absent-input case:** Omit one required “Authority delegation” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M01.01-C054-T07 · Stale-input case:** Supply an outdated “Authority delegation” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M01.01-C054-T08 · Incompatible-input case:** Supply an incompatible “Authority delegation” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M01.01-C054-T09 · Valid integration trace:** Run a valid “Authority delegation” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M01.01-C054-T10 · Seam review:** Reconcile the “Authority delegation” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M01.01-C055 · Valid-case test

**Original checklist item:** Construct a valid worked example for authority delegation; evaluate it against predeclared expected decisions and, where enforcement exists, run the corresponding conformance fixture.

- [ ] **UC-M01.01-C055-T01 · Valid fixture choice:** Select one concrete valid worked example for “Authority delegation”; enumerate the model inputs and the expected review decision before evaluating it.
- [ ] **UC-M01.01-C055-T02 · Expected-result oracle:** Specify the “Authority delegation” expected result independently of the implementation output; include the property “Delegation cannot widen the issuer's authority” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M01.01-C055-T03 · Fixture material:** Create the concrete “Authority delegation” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M01.01-C055-T04 · Target preparation:** Prepare the “Authority delegation” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M01.01-C055-T05 · Initial-state record:** Record the initial “Authority delegation” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M01.01-C055-T06 · Valid-path execution:** Evaluate the “Authority delegation” example against the reviewed model; where a runtime mechanism exists, run its corresponding fixture and label those observations separately.
- [ ] **UC-M01.01-C055-T07 · Outcome comparison:** Compare every declared “Authority delegation” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M01.01-C055-T08 · State and bounds check:** Inspect the “Authority delegation” ownership/state effects and actual use of “Delegation chain length and capability lifetime”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M01.01-C055-T09 · Repeatability check:** Repeat the same “Authority delegation” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M01.01-C055-T10 · Positive evidence:** Attach the “Authority delegation” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M01.01-C056 · Negative test

**Original checklist item:** Negative case: A delegated capability requests additional devices. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M01.01-C056-T01 · Adverse-case definition:** Create a test record for the exact “Authority delegation” source counterexample: “A delegated capability requests additional devices”; state which precondition or invariant it challenges.
- [ ] **UC-M01.01-C056-T02 · Safe fixture boundary:** Define the contained test boundary for “Authority delegation”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M01.01-C056-T03 · Valid control:** Construct a valid “Authority delegation” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M01.01-C056-T04 · Minimal adverse input:** Derive the “Authority delegation” adverse fixture from the control with the smallest documented change needed to reproduce “A delegated capability requests additional devices”; retain that change as reproducible data.
- [ ] **UC-M01.01-C056-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Authority delegation”; require “Delegation cannot widen the issuer's authority” and forbid a false-success verdict.
- [ ] **UC-M01.01-C056-T06 · Adverse execution:** Evaluate the “Authority delegation” adverse case through the actual review/contract gate; where implemented, also observe the runtime refusal and keep the two evidence classes separate.
- [ ] **UC-M01.01-C056-T07 · Effect inspection:** Inspect “Authority delegation” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M01.01-C056-T08 · Refusal versus failure:** Confirm the “Authority delegation” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M01.01-C056-T09 · Reset and retention:** Restore only the disposable “Authority delegation” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M01.01-C056-T10 · Negative regression:** Register the “Authority delegation” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M01.01-C057 · Change / failure test

**Original checklist item:** Exercise authority delegation when an entry point or trusted actor is added after the model was reviewed; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M01.01-C057-T01 · Scenario record:** Write the “Authority delegation” change/failure scenario exactly as supplied: an entry point or trusted actor is added after the model was reviewed; identify the property that must remain true: “Delegation cannot widen the issuer's authority”.
- [ ] **UC-M01.01-C057-T02 · Baseline capture:** Create a known-valid “Authority delegation” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M01.01-C057-T03 · Injection map:** Locate the “Authority delegation” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M01.01-C057-T04 · Disposition oracle:** Define the legal intermediate and final “Authority delegation” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M01.01-C057-T05 · Controlled trigger:** Apply the controlled model-change scenario for “Authority delegation”: an entry point or trusted actor is added after the model was reviewed; retain the exact before/after declarations. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M01.01-C057-T06 · Intermediate inspection:** Review which “Authority delegation” claims, approvals and evidence references become stale after the change; keep unresolved enforcement gaps visible.
- [ ] **UC-M01.01-C057-T07 · Recovery path:** Revise or explicitly refuse the changed “Authority delegation” model under the documented compatibility policy; re-review affected claims before restoring their approval.
- [ ] **UC-M01.01-C057-T08 · Stale-evidence cleanup:** Invalidate superseded “Authority delegation” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M01.01-C057-T09 · Repeat and compare:** Repeat the selected “Authority delegation” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M01.01-C057-T10 · Failure evidence:** Publish the “Authority delegation” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M01.01-C058 · Bounds

**Original checklist item:** Define completeness and scaling criteria for delegation chain length and capability lifetime; exercise larger inventories or fixture sets, and report uncovered scope instead of silently excluding it.

- [ ] **UC-M01.01-C058-T01 · Quantity inventory:** Create a measurement inventory for “Authority delegation”: “Delegation chain length and capability lifetime”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M01.01-C058-T02 · Measurement method:** Choose how to observe each “Authority delegation” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M01.01-C058-T03 · Budget decision:** Select justified coverage and completeness limits for “Authority delegation”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M01.01-C058-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Authority delegation” cases for “Delegation chain length and capability lifetime”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M01.01-C058-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Authority delegation” limit; preserve “Delegation cannot widen the issuer's authority”.
- [ ] **UC-M01.01-C058-T06 · Normal measurement:** Run or review the normal “Authority delegation” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M01.01-C058-T07 · At-limit measurement:** Exercise the “Authority delegation” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M01.01-C058-T08 · Over-limit measurement:** Exercise the “Authority delegation” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M01.01-C058-T09 · Uncovered-scope report:** List the “Authority delegation” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M01.01-C058-T10 · Limit evidence:** Publish the selected “Authority delegation” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M01.01-C059 · Diagnostics / review

**Original checklist item:** Record the rationale, unresolved assumptions, enforcement gaps and re-review triggers for authority delegation; make design-only claims visibly distinct from observed behavior.

- [ ] **UC-M01.01-C059-T01 · Review inventory:** List the “Authority delegation” decisions and claims requiring review; distinguish source requirements, implementation observations and engineering assumptions.
- [ ] **UC-M01.01-C059-T02 · Rationale record:** Write the rationale for the selected “Authority delegation” representation or policy; link each choice to the requirement rather than an unexplained preference.
- [ ] **UC-M01.01-C059-T03 · Assumption ledger:** Record unresolved “Authority delegation” assumptions, their owner and what observation or decision would resolve them; do not treat unknowns as approvals.
- [ ] **UC-M01.01-C059-T04 · Boundary map:** Map each “Authority delegation” claim to an actual guard or explicit design/review gate; flag gaps against “Delegation cannot widen the issuer's authority”.
- [ ] **UC-M01.01-C059-T05 · Counterexample review:** Walk reviewers through the “Authority delegation” counterexample “A delegated capability requests additional devices”; record whether the model detects it and whether any runtime guard was actually exercised.
- [ ] **UC-M01.01-C059-T06 · Review outcome vocabulary:** Define approved, blocked, superseded and untested review outcomes for “Authority delegation”; ensure the wording cannot be read as runtime enforcement evidence.
- [ ] **UC-M01.01-C059-T07 · Re-review triggers:** List “Authority delegation” invalidation triggers, including the source change scenario: an entry point or trusted actor is added after the model was reviewed; identify the affected claims and evidence.
- [ ] **UC-M01.01-C059-T08 · Sensitive-data review:** Inspect the “Authority delegation” review record for secrets and unrelated user content; retain nonsecret references sufficient for reproducibility.
- [ ] **UC-M01.01-C059-T09 · Independent reading:** Have the “Authority delegation” record read against the original acceptance criterion and entry-point inventory, policy decisions and observed host enforcement; record misunderstandings or missing evidence as corrections.
- [ ] **UC-M01.01-C059-T10 · Review disposition:** Publish the “Authority delegation” rationale, versioned review outcome, unresolved gaps and explicit next decision; keep blockers open until supported evidence resolves them.

### UC-M01.01-C060 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for authority delegation; label unexecuted checks as untested.

- [ ] **UC-M01.01-C060-T01 · Evidence inventory:** List the “Authority delegation” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M01.01-C060-T02 · Artifact references:** Record the exact “Authority delegation” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M01.01-C060-T03 · Fixture references:** Attach the “Authority delegation” fixture IDs, input identities and oracle definition; preserve the source counterexample “A delegated capability requests additional devices” as a distinct evidence case.
- [ ] **UC-M01.01-C060-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Authority delegation”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M01.01-C060-T05 · Environment record:** Record the actual “Authority delegation” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M01.01-C060-T06 · Expected versus observed:** Pair every “Authority delegation” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M01.01-C060-T07 · Failure and limit records:** Attach “Authority delegation” change/failure and bounds evidence where required; include uncovered “Delegation chain length and capability lifetime” and unresolved violations of “Delegation cannot widen the issuer's authority”.
- [ ] **UC-M01.01-C060-T08 · Evidence hygiene:** Check the “Authority delegation” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M01.01-C060-T09 · Reproduction review:** Have the “Authority delegation” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M01.01-C060-T10 · Acceptance linkage:** Link the “Authority delegation” evidence to its parent and UC-M01.01 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 07. Threat scenarios

**Source delivery:** Build abuse scenarios for malicious cargo, a compromised guest and a mistaken operator.

**Source invariant:** Each scenario names an affected asset and concrete boundary.

**Source negative case:** A scenario is dismissed solely because checksums match.

**Source bounded quantities:** Scenario coverage and review effort per release.

### UC-M01.01-C061 · Contract

**Original checklist item:** Specify the scope and representation of threat scenarios; identify its producer, consumer, authority assumptions and explicitly unsupported cases.

- [ ] **UC-M01.01-C061-T01 · Scope statement:** Draft a scope note for “Threat scenarios” within Trust-boundary and capability model; separate required model statements, explicit exclusions and unresolved design decisions.
- [ ] **UC-M01.01-C061-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Threat scenarios”; record each producer, representation and missing-value meaning.
- [ ] **UC-M01.01-C061-T03 · Output inventory:** List the outputs of “Threat scenarios” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M01.01-C061-T04 · Field dictionary:** Create a field-and-term dictionary for “Threat scenarios”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M01.01-C061-T05 · Prerequisite contract:** Map “Threat scenarios” to the source component prerequisites (none declared; foundational work); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M01.01-C061-T06 · Authority map:** Identify who may produce, change and consume “Threat scenarios”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M01.01-C061-T07 · Invariant clause:** Add a normative clause for “Threat scenarios” that preserves “Each scenario names an affected asset and concrete boundary”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M01.01-C061-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Threat scenarios”; include the source counterexample “A scenario is dismissed solely because checksums match” and the intended safe disposition.
- [ ] **UC-M01.01-C061-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Scenario coverage and review effort per release” in the “Threat scenarios” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M01.01-C061-T10 · Contract review:** Review the “Threat scenarios” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M01.01-C062 · Delivery

**Original checklist item:** Build abuse scenarios for malicious cargo, a compromised guest and a mistaken operator.

- [ ] **UC-M01.01-C062-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Threat scenarios”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M01.01-C062-T02 · Change plan:** Break the source delivery for “Threat scenarios” into concrete edit targets and reviewable outputs; keep the UC-M01.01 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M01.01-C062-T03 · Core artifact:** Implement the smallest selected-profile change for “Threat scenarios” that realizes this source instruction: Build abuse scenarios for malicious cargo, a compromised guest and a mistaken operator.
- [ ] **UC-M01.01-C062-T04 · Concrete realization:** Trace “Threat scenarios” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M01.01-C062-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Threat scenarios” needed to preserve “Each scenario names an affected asset and concrete boundary”; record an enforcement gap where only a model exists.
- [ ] **UC-M01.01-C062-T06 · Dependency connection:** Connect the “Threat scenarios” specification to entry-point inventory, policy decisions and observed host enforcement; record code coverage separately where the design is not yet enforced.
- [ ] **UC-M01.01-C062-T07 · Resource behavior:** Account for “Scenario coverage and review effort per release” in “Threat scenarios”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M01.01-C062-T08 · Delivery check:** Walk the populated “Threat scenarios” model through a valid example and the source counterexample “A scenario is dismissed solely because checksums match”; record corrections and unresolved enforcement gaps.
- [ ] **UC-M01.01-C062-T09 · Patch review:** Review the “Threat scenarios” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M01.01-C062-T10 · Delivery handoff:** Publish the “Threat scenarios” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M01.01-C063 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Each scenario names an affected asset and concrete boundary. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M01.01-C063-T01 · Named property:** Create a stable property/check name under this parent for “Threat scenarios”; copy its required invariant exactly: “Each scenario names an affected asset and concrete boundary”.
- [ ] **UC-M01.01-C063-T02 · Observable terms:** Define each term in the “Threat scenarios” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M01.01-C063-T03 · Precondition set:** List the preconditions under which “Each scenario names an affected asset and concrete boundary” must hold for “Threat scenarios”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M01.01-C063-T04 · Transition coverage:** Map the “Threat scenarios” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M01.01-C063-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Threat scenarios”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M01.01-C063-T06 · Satisfying fixture:** Create a concrete “Threat scenarios” case that satisfies “Each scenario names an affected asset and concrete boundary”; record its expected observation before running the assertion or review.
- [ ] **UC-M01.01-C063-T07 · Violating fixture:** Create the source counterexample “A scenario is dismissed solely because checksums match” for “Threat scenarios”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M01.01-C063-T08 · Enforcement evidence:** Exercise the “Threat scenarios” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M01.01-C063-T09 · Regression linkage:** Link the “Threat scenarios” property to changes in entry-point inventory, policy decisions and observed host enforcement; record which dependency or contract changes require rerunning it.
- [ ] **UC-M01.01-C063-T10 · Property disposition:** Compare the satisfying and violating “Threat scenarios” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M01.01-C064 · Integration

**Original checklist item:** Integrate threat scenarios with entry-point inventory, policy decisions and observed host enforcement; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M01.01-C064-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Threat scenarios” across entry-point inventory, policy decisions and observed host enforcement; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M01.01-C064-T02 · Field mapping:** Map every “Threat scenarios” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M01.01-C064-T03 · Prerequisite identities:** Record the actual prerequisites for “Threat scenarios” (source dependency list: none declared; foundational work); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M01.01-C064-T04 · Ownership agreement:** Specify who owns “Threat scenarios” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M01.01-C064-T05 · Handoff implementation:** Connect “Threat scenarios” through the mapped seam using the real adapter or explicit specification reference; preserve “Each scenario names an affected asset and concrete boundary” across the handoff.
- [ ] **UC-M01.01-C064-T06 · Absent-input case:** Omit one required “Threat scenarios” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M01.01-C064-T07 · Stale-input case:** Supply an outdated “Threat scenarios” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M01.01-C064-T08 · Incompatible-input case:** Supply an incompatible “Threat scenarios” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M01.01-C064-T09 · Valid integration trace:** Run a valid “Threat scenarios” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M01.01-C064-T10 · Seam review:** Reconcile the “Threat scenarios” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M01.01-C065 · Valid-case test

**Original checklist item:** Construct a valid worked example for threat scenarios; evaluate it against predeclared expected decisions and, where enforcement exists, run the corresponding conformance fixture.

- [ ] **UC-M01.01-C065-T01 · Valid fixture choice:** Select one concrete valid worked example for “Threat scenarios”; enumerate the model inputs and the expected review decision before evaluating it.
- [ ] **UC-M01.01-C065-T02 · Expected-result oracle:** Specify the “Threat scenarios” expected result independently of the implementation output; include the property “Each scenario names an affected asset and concrete boundary” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M01.01-C065-T03 · Fixture material:** Create the concrete “Threat scenarios” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M01.01-C065-T04 · Target preparation:** Prepare the “Threat scenarios” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M01.01-C065-T05 · Initial-state record:** Record the initial “Threat scenarios” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M01.01-C065-T06 · Valid-path execution:** Evaluate the “Threat scenarios” example against the reviewed model; where a runtime mechanism exists, run its corresponding fixture and label those observations separately.
- [ ] **UC-M01.01-C065-T07 · Outcome comparison:** Compare every declared “Threat scenarios” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M01.01-C065-T08 · State and bounds check:** Inspect the “Threat scenarios” ownership/state effects and actual use of “Scenario coverage and review effort per release”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M01.01-C065-T09 · Repeatability check:** Repeat the same “Threat scenarios” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M01.01-C065-T10 · Positive evidence:** Attach the “Threat scenarios” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M01.01-C066 · Negative test

**Original checklist item:** Negative case: A scenario is dismissed solely because checksums match. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M01.01-C066-T01 · Adverse-case definition:** Create a test record for the exact “Threat scenarios” source counterexample: “A scenario is dismissed solely because checksums match”; state which precondition or invariant it challenges.
- [ ] **UC-M01.01-C066-T02 · Safe fixture boundary:** Define the contained test boundary for “Threat scenarios”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M01.01-C066-T03 · Valid control:** Construct a valid “Threat scenarios” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M01.01-C066-T04 · Minimal adverse input:** Derive the “Threat scenarios” adverse fixture from the control with the smallest documented change needed to reproduce “A scenario is dismissed solely because checksums match”; retain that change as reproducible data.
- [ ] **UC-M01.01-C066-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Threat scenarios”; require “Each scenario names an affected asset and concrete boundary” and forbid a false-success verdict.
- [ ] **UC-M01.01-C066-T06 · Adverse execution:** Evaluate the “Threat scenarios” adverse case through the actual review/contract gate; where implemented, also observe the runtime refusal and keep the two evidence classes separate.
- [ ] **UC-M01.01-C066-T07 · Effect inspection:** Inspect “Threat scenarios” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M01.01-C066-T08 · Refusal versus failure:** Confirm the “Threat scenarios” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M01.01-C066-T09 · Reset and retention:** Restore only the disposable “Threat scenarios” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M01.01-C066-T10 · Negative regression:** Register the “Threat scenarios” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M01.01-C067 · Change / failure test

**Original checklist item:** Exercise threat scenarios when an entry point or trusted actor is added after the model was reviewed; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M01.01-C067-T01 · Scenario record:** Write the “Threat scenarios” change/failure scenario exactly as supplied: an entry point or trusted actor is added after the model was reviewed; identify the property that must remain true: “Each scenario names an affected asset and concrete boundary”.
- [ ] **UC-M01.01-C067-T02 · Baseline capture:** Create a known-valid “Threat scenarios” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M01.01-C067-T03 · Injection map:** Locate the “Threat scenarios” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M01.01-C067-T04 · Disposition oracle:** Define the legal intermediate and final “Threat scenarios” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M01.01-C067-T05 · Controlled trigger:** Apply the controlled model-change scenario for “Threat scenarios”: an entry point or trusted actor is added after the model was reviewed; retain the exact before/after declarations. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M01.01-C067-T06 · Intermediate inspection:** Review which “Threat scenarios” claims, approvals and evidence references become stale after the change; keep unresolved enforcement gaps visible.
- [ ] **UC-M01.01-C067-T07 · Recovery path:** Revise or explicitly refuse the changed “Threat scenarios” model under the documented compatibility policy; re-review affected claims before restoring their approval.
- [ ] **UC-M01.01-C067-T08 · Stale-evidence cleanup:** Invalidate superseded “Threat scenarios” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M01.01-C067-T09 · Repeat and compare:** Repeat the selected “Threat scenarios” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M01.01-C067-T10 · Failure evidence:** Publish the “Threat scenarios” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M01.01-C068 · Bounds

**Original checklist item:** Define completeness and scaling criteria for scenario coverage and review effort per release; exercise larger inventories or fixture sets, and report uncovered scope instead of silently excluding it.

- [ ] **UC-M01.01-C068-T01 · Quantity inventory:** Create a measurement inventory for “Threat scenarios”: “Scenario coverage and review effort per release”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M01.01-C068-T02 · Measurement method:** Choose how to observe each “Threat scenarios” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M01.01-C068-T03 · Budget decision:** Select justified coverage and completeness limits for “Threat scenarios”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M01.01-C068-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Threat scenarios” cases for “Scenario coverage and review effort per release”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M01.01-C068-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Threat scenarios” limit; preserve “Each scenario names an affected asset and concrete boundary”.
- [ ] **UC-M01.01-C068-T06 · Normal measurement:** Run or review the normal “Threat scenarios” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M01.01-C068-T07 · At-limit measurement:** Exercise the “Threat scenarios” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M01.01-C068-T08 · Over-limit measurement:** Exercise the “Threat scenarios” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M01.01-C068-T09 · Uncovered-scope report:** List the “Threat scenarios” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M01.01-C068-T10 · Limit evidence:** Publish the selected “Threat scenarios” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M01.01-C069 · Diagnostics / review

**Original checklist item:** Record the rationale, unresolved assumptions, enforcement gaps and re-review triggers for threat scenarios; make design-only claims visibly distinct from observed behavior.

- [ ] **UC-M01.01-C069-T01 · Review inventory:** List the “Threat scenarios” decisions and claims requiring review; distinguish source requirements, implementation observations and engineering assumptions.
- [ ] **UC-M01.01-C069-T02 · Rationale record:** Write the rationale for the selected “Threat scenarios” representation or policy; link each choice to the requirement rather than an unexplained preference.
- [ ] **UC-M01.01-C069-T03 · Assumption ledger:** Record unresolved “Threat scenarios” assumptions, their owner and what observation or decision would resolve them; do not treat unknowns as approvals.
- [ ] **UC-M01.01-C069-T04 · Boundary map:** Map each “Threat scenarios” claim to an actual guard or explicit design/review gate; flag gaps against “Each scenario names an affected asset and concrete boundary”.
- [ ] **UC-M01.01-C069-T05 · Counterexample review:** Walk reviewers through the “Threat scenarios” counterexample “A scenario is dismissed solely because checksums match”; record whether the model detects it and whether any runtime guard was actually exercised.
- [ ] **UC-M01.01-C069-T06 · Review outcome vocabulary:** Define approved, blocked, superseded and untested review outcomes for “Threat scenarios”; ensure the wording cannot be read as runtime enforcement evidence.
- [ ] **UC-M01.01-C069-T07 · Re-review triggers:** List “Threat scenarios” invalidation triggers, including the source change scenario: an entry point or trusted actor is added after the model was reviewed; identify the affected claims and evidence.
- [ ] **UC-M01.01-C069-T08 · Sensitive-data review:** Inspect the “Threat scenarios” review record for secrets and unrelated user content; retain nonsecret references sufficient for reproducibility.
- [ ] **UC-M01.01-C069-T09 · Independent reading:** Have the “Threat scenarios” record read against the original acceptance criterion and entry-point inventory, policy decisions and observed host enforcement; record misunderstandings or missing evidence as corrections.
- [ ] **UC-M01.01-C069-T10 · Review disposition:** Publish the “Threat scenarios” rationale, versioned review outcome, unresolved gaps and explicit next decision; keep blockers open until supported evidence resolves them.

### UC-M01.01-C070 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for threat scenarios; label unexecuted checks as untested.

- [ ] **UC-M01.01-C070-T01 · Evidence inventory:** List the “Threat scenarios” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M01.01-C070-T02 · Artifact references:** Record the exact “Threat scenarios” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M01.01-C070-T03 · Fixture references:** Attach the “Threat scenarios” fixture IDs, input identities and oracle definition; preserve the source counterexample “A scenario is dismissed solely because checksums match” as a distinct evidence case.
- [ ] **UC-M01.01-C070-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Threat scenarios”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M01.01-C070-T05 · Environment record:** Record the actual “Threat scenarios” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M01.01-C070-T06 · Expected versus observed:** Pair every “Threat scenarios” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M01.01-C070-T07 · Failure and limit records:** Attach “Threat scenarios” change/failure and bounds evidence where required; include uncovered “Scenario coverage and review effort per release” and unresolved violations of “Each scenario names an affected asset and concrete boundary”.
- [ ] **UC-M01.01-C070-T08 · Evidence hygiene:** Check the “Threat scenarios” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M01.01-C070-T09 · Reproduction review:** Have the “Threat scenarios” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M01.01-C070-T10 · Acceptance linkage:** Link the “Threat scenarios” evidence to its parent and UC-M01.01 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 08. Enforcement mapping

**Source delivery:** Link each modeled restriction to its guard, host policy or explicit implementation gap.

**Source invariant:** A declaration is never labeled as enforced without evidence.

**Source negative case:** NETWORK=deny has no corresponding device or host restriction.

**Source bounded quantities:** Unmapped rules and stale enforcement references.

### UC-M01.01-C071 · Contract

**Original checklist item:** Specify the scope and representation of enforcement mapping; identify its producer, consumer, authority assumptions and explicitly unsupported cases.

- [ ] **UC-M01.01-C071-T01 · Scope statement:** Draft a scope note for “Enforcement mapping” within Trust-boundary and capability model; separate required model statements, explicit exclusions and unresolved design decisions.
- [ ] **UC-M01.01-C071-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Enforcement mapping”; record each producer, representation and missing-value meaning.
- [ ] **UC-M01.01-C071-T03 · Output inventory:** List the outputs of “Enforcement mapping” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M01.01-C071-T04 · Field dictionary:** Create a field-and-term dictionary for “Enforcement mapping”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M01.01-C071-T05 · Prerequisite contract:** Map “Enforcement mapping” to the source component prerequisites (none declared; foundational work); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M01.01-C071-T06 · Authority map:** Identify who may produce, change and consume “Enforcement mapping”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M01.01-C071-T07 · Invariant clause:** Add a normative clause for “Enforcement mapping” that preserves “A declaration is never labeled as enforced without evidence”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M01.01-C071-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Enforcement mapping”; include the source counterexample “NETWORK=deny has no corresponding device or host restriction” and the intended safe disposition.
- [ ] **UC-M01.01-C071-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Unmapped rules and stale enforcement references” in the “Enforcement mapping” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M01.01-C071-T10 · Contract review:** Review the “Enforcement mapping” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M01.01-C072 · Delivery

**Original checklist item:** Link each modeled restriction to its guard, host policy or explicit implementation gap.

- [ ] **UC-M01.01-C072-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Enforcement mapping”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M01.01-C072-T02 · Change plan:** Break the source delivery for “Enforcement mapping” into concrete edit targets and reviewable outputs; keep the UC-M01.01 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M01.01-C072-T03 · Core artifact:** Implement the smallest selected-profile change for “Enforcement mapping” that realizes this source instruction: Link each modeled restriction to its guard, host policy or explicit implementation gap.
- [ ] **UC-M01.01-C072-T04 · Concrete realization:** Trace “Enforcement mapping” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M01.01-C072-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Enforcement mapping” needed to preserve “A declaration is never labeled as enforced without evidence”; record an enforcement gap where only a model exists.
- [ ] **UC-M01.01-C072-T06 · Dependency connection:** Connect the “Enforcement mapping” specification to entry-point inventory, policy decisions and observed host enforcement; record code coverage separately where the design is not yet enforced.
- [ ] **UC-M01.01-C072-T07 · Resource behavior:** Account for “Unmapped rules and stale enforcement references” in “Enforcement mapping”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M01.01-C072-T08 · Delivery check:** Walk the populated “Enforcement mapping” model through a valid example and the source counterexample “NETWORK=deny has no corresponding device or host restriction”; record corrections and unresolved enforcement gaps.
- [ ] **UC-M01.01-C072-T09 · Patch review:** Review the “Enforcement mapping” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M01.01-C072-T10 · Delivery handoff:** Publish the “Enforcement mapping” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M01.01-C073 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: A declaration is never labeled as enforced without evidence. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M01.01-C073-T01 · Named property:** Create a stable property/check name under this parent for “Enforcement mapping”; copy its required invariant exactly: “A declaration is never labeled as enforced without evidence”.
- [ ] **UC-M01.01-C073-T02 · Observable terms:** Define each term in the “Enforcement mapping” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M01.01-C073-T03 · Precondition set:** List the preconditions under which “A declaration is never labeled as enforced without evidence” must hold for “Enforcement mapping”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M01.01-C073-T04 · Transition coverage:** Map the “Enforcement mapping” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M01.01-C073-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Enforcement mapping”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M01.01-C073-T06 · Satisfying fixture:** Create a concrete “Enforcement mapping” case that satisfies “A declaration is never labeled as enforced without evidence”; record its expected observation before running the assertion or review.
- [ ] **UC-M01.01-C073-T07 · Violating fixture:** Create the source counterexample “NETWORK=deny has no corresponding device or host restriction” for “Enforcement mapping”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M01.01-C073-T08 · Enforcement evidence:** Exercise the “Enforcement mapping” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M01.01-C073-T09 · Regression linkage:** Link the “Enforcement mapping” property to changes in entry-point inventory, policy decisions and observed host enforcement; record which dependency or contract changes require rerunning it.
- [ ] **UC-M01.01-C073-T10 · Property disposition:** Compare the satisfying and violating “Enforcement mapping” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M01.01-C074 · Integration

**Original checklist item:** Integrate enforcement mapping with entry-point inventory, policy decisions and observed host enforcement; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M01.01-C074-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Enforcement mapping” across entry-point inventory, policy decisions and observed host enforcement; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M01.01-C074-T02 · Field mapping:** Map every “Enforcement mapping” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M01.01-C074-T03 · Prerequisite identities:** Record the actual prerequisites for “Enforcement mapping” (source dependency list: none declared; foundational work); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M01.01-C074-T04 · Ownership agreement:** Specify who owns “Enforcement mapping” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M01.01-C074-T05 · Handoff implementation:** Connect “Enforcement mapping” through the mapped seam using the real adapter or explicit specification reference; preserve “A declaration is never labeled as enforced without evidence” across the handoff.
- [ ] **UC-M01.01-C074-T06 · Absent-input case:** Omit one required “Enforcement mapping” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M01.01-C074-T07 · Stale-input case:** Supply an outdated “Enforcement mapping” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M01.01-C074-T08 · Incompatible-input case:** Supply an incompatible “Enforcement mapping” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M01.01-C074-T09 · Valid integration trace:** Run a valid “Enforcement mapping” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M01.01-C074-T10 · Seam review:** Reconcile the “Enforcement mapping” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M01.01-C075 · Valid-case test

**Original checklist item:** Construct a valid worked example for enforcement mapping; evaluate it against predeclared expected decisions and, where enforcement exists, run the corresponding conformance fixture.

- [ ] **UC-M01.01-C075-T01 · Valid fixture choice:** Select one concrete valid worked example for “Enforcement mapping”; enumerate the model inputs and the expected review decision before evaluating it.
- [ ] **UC-M01.01-C075-T02 · Expected-result oracle:** Specify the “Enforcement mapping” expected result independently of the implementation output; include the property “A declaration is never labeled as enforced without evidence” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M01.01-C075-T03 · Fixture material:** Create the concrete “Enforcement mapping” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M01.01-C075-T04 · Target preparation:** Prepare the “Enforcement mapping” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M01.01-C075-T05 · Initial-state record:** Record the initial “Enforcement mapping” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M01.01-C075-T06 · Valid-path execution:** Evaluate the “Enforcement mapping” example against the reviewed model; where a runtime mechanism exists, run its corresponding fixture and label those observations separately.
- [ ] **UC-M01.01-C075-T07 · Outcome comparison:** Compare every declared “Enforcement mapping” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M01.01-C075-T08 · State and bounds check:** Inspect the “Enforcement mapping” ownership/state effects and actual use of “Unmapped rules and stale enforcement references”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M01.01-C075-T09 · Repeatability check:** Repeat the same “Enforcement mapping” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M01.01-C075-T10 · Positive evidence:** Attach the “Enforcement mapping” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M01.01-C076 · Negative test

**Original checklist item:** Negative case: NETWORK=deny has no corresponding device or host restriction. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M01.01-C076-T01 · Adverse-case definition:** Create a test record for the exact “Enforcement mapping” source counterexample: “NETWORK=deny has no corresponding device or host restriction”; state which precondition or invariant it challenges.
- [ ] **UC-M01.01-C076-T02 · Safe fixture boundary:** Define the contained test boundary for “Enforcement mapping”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M01.01-C076-T03 · Valid control:** Construct a valid “Enforcement mapping” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M01.01-C076-T04 · Minimal adverse input:** Derive the “Enforcement mapping” adverse fixture from the control with the smallest documented change needed to reproduce “NETWORK=deny has no corresponding device or host restriction”; retain that change as reproducible data.
- [ ] **UC-M01.01-C076-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Enforcement mapping”; require “A declaration is never labeled as enforced without evidence” and forbid a false-success verdict.
- [ ] **UC-M01.01-C076-T06 · Adverse execution:** Evaluate the “Enforcement mapping” adverse case through the actual review/contract gate; where implemented, also observe the runtime refusal and keep the two evidence classes separate.
- [ ] **UC-M01.01-C076-T07 · Effect inspection:** Inspect “Enforcement mapping” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M01.01-C076-T08 · Refusal versus failure:** Confirm the “Enforcement mapping” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M01.01-C076-T09 · Reset and retention:** Restore only the disposable “Enforcement mapping” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M01.01-C076-T10 · Negative regression:** Register the “Enforcement mapping” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M01.01-C077 · Change / failure test

**Original checklist item:** Exercise enforcement mapping when an entry point or trusted actor is added after the model was reviewed; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M01.01-C077-T01 · Scenario record:** Write the “Enforcement mapping” change/failure scenario exactly as supplied: an entry point or trusted actor is added after the model was reviewed; identify the property that must remain true: “A declaration is never labeled as enforced without evidence”.
- [ ] **UC-M01.01-C077-T02 · Baseline capture:** Create a known-valid “Enforcement mapping” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M01.01-C077-T03 · Injection map:** Locate the “Enforcement mapping” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M01.01-C077-T04 · Disposition oracle:** Define the legal intermediate and final “Enforcement mapping” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M01.01-C077-T05 · Controlled trigger:** Apply the controlled model-change scenario for “Enforcement mapping”: an entry point or trusted actor is added after the model was reviewed; retain the exact before/after declarations. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M01.01-C077-T06 · Intermediate inspection:** Review which “Enforcement mapping” claims, approvals and evidence references become stale after the change; keep unresolved enforcement gaps visible.
- [ ] **UC-M01.01-C077-T07 · Recovery path:** Revise or explicitly refuse the changed “Enforcement mapping” model under the documented compatibility policy; re-review affected claims before restoring their approval.
- [ ] **UC-M01.01-C077-T08 · Stale-evidence cleanup:** Invalidate superseded “Enforcement mapping” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M01.01-C077-T09 · Repeat and compare:** Repeat the selected “Enforcement mapping” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M01.01-C077-T10 · Failure evidence:** Publish the “Enforcement mapping” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M01.01-C078 · Bounds

**Original checklist item:** Define completeness and scaling criteria for unmapped rules and stale enforcement references; exercise larger inventories or fixture sets, and report uncovered scope instead of silently excluding it.

- [ ] **UC-M01.01-C078-T01 · Quantity inventory:** Create a measurement inventory for “Enforcement mapping”: “Unmapped rules and stale enforcement references”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M01.01-C078-T02 · Measurement method:** Choose how to observe each “Enforcement mapping” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M01.01-C078-T03 · Budget decision:** Select justified coverage and completeness limits for “Enforcement mapping”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M01.01-C078-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Enforcement mapping” cases for “Unmapped rules and stale enforcement references”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M01.01-C078-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Enforcement mapping” limit; preserve “A declaration is never labeled as enforced without evidence”.
- [ ] **UC-M01.01-C078-T06 · Normal measurement:** Run or review the normal “Enforcement mapping” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M01.01-C078-T07 · At-limit measurement:** Exercise the “Enforcement mapping” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M01.01-C078-T08 · Over-limit measurement:** Exercise the “Enforcement mapping” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M01.01-C078-T09 · Uncovered-scope report:** List the “Enforcement mapping” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M01.01-C078-T10 · Limit evidence:** Publish the selected “Enforcement mapping” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M01.01-C079 · Diagnostics / review

**Original checklist item:** Record the rationale, unresolved assumptions, enforcement gaps and re-review triggers for enforcement mapping; make design-only claims visibly distinct from observed behavior.

- [ ] **UC-M01.01-C079-T01 · Review inventory:** List the “Enforcement mapping” decisions and claims requiring review; distinguish source requirements, implementation observations and engineering assumptions.
- [ ] **UC-M01.01-C079-T02 · Rationale record:** Write the rationale for the selected “Enforcement mapping” representation or policy; link each choice to the requirement rather than an unexplained preference.
- [ ] **UC-M01.01-C079-T03 · Assumption ledger:** Record unresolved “Enforcement mapping” assumptions, their owner and what observation or decision would resolve them; do not treat unknowns as approvals.
- [ ] **UC-M01.01-C079-T04 · Boundary map:** Map each “Enforcement mapping” claim to an actual guard or explicit design/review gate; flag gaps against “A declaration is never labeled as enforced without evidence”.
- [ ] **UC-M01.01-C079-T05 · Counterexample review:** Walk reviewers through the “Enforcement mapping” counterexample “NETWORK=deny has no corresponding device or host restriction”; record whether the model detects it and whether any runtime guard was actually exercised.
- [ ] **UC-M01.01-C079-T06 · Review outcome vocabulary:** Define approved, blocked, superseded and untested review outcomes for “Enforcement mapping”; ensure the wording cannot be read as runtime enforcement evidence.
- [ ] **UC-M01.01-C079-T07 · Re-review triggers:** List “Enforcement mapping” invalidation triggers, including the source change scenario: an entry point or trusted actor is added after the model was reviewed; identify the affected claims and evidence.
- [ ] **UC-M01.01-C079-T08 · Sensitive-data review:** Inspect the “Enforcement mapping” review record for secrets and unrelated user content; retain nonsecret references sufficient for reproducibility.
- [ ] **UC-M01.01-C079-T09 · Independent reading:** Have the “Enforcement mapping” record read against the original acceptance criterion and entry-point inventory, policy decisions and observed host enforcement; record misunderstandings or missing evidence as corrections.
- [ ] **UC-M01.01-C079-T10 · Review disposition:** Publish the “Enforcement mapping” rationale, versioned review outcome, unresolved gaps and explicit next decision; keep blockers open until supported evidence resolves them.

### UC-M01.01-C080 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for enforcement mapping; label unexecuted checks as untested.

- [ ] **UC-M01.01-C080-T01 · Evidence inventory:** List the “Enforcement mapping” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M01.01-C080-T02 · Artifact references:** Record the exact “Enforcement mapping” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M01.01-C080-T03 · Fixture references:** Attach the “Enforcement mapping” fixture IDs, input identities and oracle definition; preserve the source counterexample “NETWORK=deny has no corresponding device or host restriction” as a distinct evidence case.
- [ ] **UC-M01.01-C080-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Enforcement mapping”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M01.01-C080-T05 · Environment record:** Record the actual “Enforcement mapping” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M01.01-C080-T06 · Expected versus observed:** Pair every “Enforcement mapping” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M01.01-C080-T07 · Failure and limit records:** Attach “Enforcement mapping” change/failure and bounds evidence where required; include uncovered “Unmapped rules and stale enforcement references” and unresolved violations of “A declaration is never labeled as enforced without evidence”.
- [ ] **UC-M01.01-C080-T08 · Evidence hygiene:** Check the “Enforcement mapping” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M01.01-C080-T09 · Reproduction review:** Have the “Enforcement mapping” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M01.01-C080-T10 · Acceptance linkage:** Link the “Enforcement mapping” evidence to its parent and UC-M01.01 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 09. Assumptions and exclusions

**Source delivery:** Record trusted host assumptions and threats excluded from the selected profile.

**Source invariant:** Unsupported threats remain visible in promotion decisions.

**Source negative case:** A host administrator is silently treated as an untrusted isolated tenant.

**Source bounded quantities:** Assumption count and review interval.

### UC-M01.01-C081 · Contract

**Original checklist item:** Specify the scope and representation of assumptions and exclusions; identify its producer, consumer, authority assumptions and explicitly unsupported cases.

- [ ] **UC-M01.01-C081-T01 · Scope statement:** Draft a scope note for “Assumptions and exclusions” within Trust-boundary and capability model; separate required model statements, explicit exclusions and unresolved design decisions.
- [ ] **UC-M01.01-C081-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Assumptions and exclusions”; record each producer, representation and missing-value meaning.
- [ ] **UC-M01.01-C081-T03 · Output inventory:** List the outputs of “Assumptions and exclusions” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M01.01-C081-T04 · Field dictionary:** Create a field-and-term dictionary for “Assumptions and exclusions”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M01.01-C081-T05 · Prerequisite contract:** Map “Assumptions and exclusions” to the source component prerequisites (none declared; foundational work); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M01.01-C081-T06 · Authority map:** Identify who may produce, change and consume “Assumptions and exclusions”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M01.01-C081-T07 · Invariant clause:** Add a normative clause for “Assumptions and exclusions” that preserves “Unsupported threats remain visible in promotion decisions”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M01.01-C081-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Assumptions and exclusions”; include the source counterexample “A host administrator is silently treated as an untrusted isolated tenant” and the intended safe disposition.
- [ ] **UC-M01.01-C081-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Assumption count and review interval” in the “Assumptions and exclusions” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M01.01-C081-T10 · Contract review:** Review the “Assumptions and exclusions” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M01.01-C082 · Delivery

**Original checklist item:** Record trusted host assumptions and threats excluded from the selected profile.

- [ ] **UC-M01.01-C082-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Assumptions and exclusions”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M01.01-C082-T02 · Change plan:** Break the source delivery for “Assumptions and exclusions” into concrete edit targets and reviewable outputs; keep the UC-M01.01 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M01.01-C082-T03 · Core artifact:** Create the “Assumptions and exclusions” model, schema or inventory that realizes this source instruction: Record trusted host assumptions and threats excluded from the selected profile.
- [ ] **UC-M01.01-C082-T04 · Concrete realization:** Populate “Assumptions and exclusions” with one concrete worked case; map every required entity or field to its source and flag any unmapped entry.
- [ ] **UC-M01.01-C082-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Assumptions and exclusions” needed to preserve “Unsupported threats remain visible in promotion decisions”; record an enforcement gap where only a model exists.
- [ ] **UC-M01.01-C082-T06 · Dependency connection:** Connect the “Assumptions and exclusions” specification to entry-point inventory, policy decisions and observed host enforcement; record code coverage separately where the design is not yet enforced.
- [ ] **UC-M01.01-C082-T07 · Resource behavior:** Account for “Assumption count and review interval” in “Assumptions and exclusions”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M01.01-C082-T08 · Delivery check:** Walk the populated “Assumptions and exclusions” model through a valid example and the source counterexample “A host administrator is silently treated as an untrusted isolated tenant”; record corrections and unresolved enforcement gaps.
- [ ] **UC-M01.01-C082-T09 · Patch review:** Review the “Assumptions and exclusions” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M01.01-C082-T10 · Delivery handoff:** Publish the “Assumptions and exclusions” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M01.01-C083 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Unsupported threats remain visible in promotion decisions. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M01.01-C083-T01 · Named property:** Create a stable property/check name under this parent for “Assumptions and exclusions”; copy its required invariant exactly: “Unsupported threats remain visible in promotion decisions”.
- [ ] **UC-M01.01-C083-T02 · Observable terms:** Define each term in the “Assumptions and exclusions” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M01.01-C083-T03 · Precondition set:** List the preconditions under which “Unsupported threats remain visible in promotion decisions” must hold for “Assumptions and exclusions”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M01.01-C083-T04 · Transition coverage:** Map the “Assumptions and exclusions” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M01.01-C083-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Assumptions and exclusions”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M01.01-C083-T06 · Satisfying fixture:** Create a concrete “Assumptions and exclusions” case that satisfies “Unsupported threats remain visible in promotion decisions”; record its expected observation before running the assertion or review.
- [ ] **UC-M01.01-C083-T07 · Violating fixture:** Create the source counterexample “A host administrator is silently treated as an untrusted isolated tenant” for “Assumptions and exclusions”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M01.01-C083-T08 · Enforcement evidence:** Exercise the “Assumptions and exclusions” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M01.01-C083-T09 · Regression linkage:** Link the “Assumptions and exclusions” property to changes in entry-point inventory, policy decisions and observed host enforcement; record which dependency or contract changes require rerunning it.
- [ ] **UC-M01.01-C083-T10 · Property disposition:** Compare the satisfying and violating “Assumptions and exclusions” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M01.01-C084 · Integration

**Original checklist item:** Integrate assumptions and exclusions with entry-point inventory, policy decisions and observed host enforcement; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M01.01-C084-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Assumptions and exclusions” across entry-point inventory, policy decisions and observed host enforcement; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M01.01-C084-T02 · Field mapping:** Map every “Assumptions and exclusions” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M01.01-C084-T03 · Prerequisite identities:** Record the actual prerequisites for “Assumptions and exclusions” (source dependency list: none declared; foundational work); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M01.01-C084-T04 · Ownership agreement:** Specify who owns “Assumptions and exclusions” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M01.01-C084-T05 · Handoff implementation:** Connect “Assumptions and exclusions” through the mapped seam using the real adapter or explicit specification reference; preserve “Unsupported threats remain visible in promotion decisions” across the handoff.
- [ ] **UC-M01.01-C084-T06 · Absent-input case:** Omit one required “Assumptions and exclusions” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M01.01-C084-T07 · Stale-input case:** Supply an outdated “Assumptions and exclusions” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M01.01-C084-T08 · Incompatible-input case:** Supply an incompatible “Assumptions and exclusions” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M01.01-C084-T09 · Valid integration trace:** Run a valid “Assumptions and exclusions” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M01.01-C084-T10 · Seam review:** Reconcile the “Assumptions and exclusions” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M01.01-C085 · Valid-case test

**Original checklist item:** Construct a valid worked example for assumptions and exclusions; evaluate it against predeclared expected decisions and, where enforcement exists, run the corresponding conformance fixture.

- [ ] **UC-M01.01-C085-T01 · Valid fixture choice:** Select one concrete valid worked example for “Assumptions and exclusions”; enumerate the model inputs and the expected review decision before evaluating it.
- [ ] **UC-M01.01-C085-T02 · Expected-result oracle:** Specify the “Assumptions and exclusions” expected result independently of the implementation output; include the property “Unsupported threats remain visible in promotion decisions” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M01.01-C085-T03 · Fixture material:** Create the concrete “Assumptions and exclusions” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M01.01-C085-T04 · Target preparation:** Prepare the “Assumptions and exclusions” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M01.01-C085-T05 · Initial-state record:** Record the initial “Assumptions and exclusions” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M01.01-C085-T06 · Valid-path execution:** Evaluate the “Assumptions and exclusions” example against the reviewed model; where a runtime mechanism exists, run its corresponding fixture and label those observations separately.
- [ ] **UC-M01.01-C085-T07 · Outcome comparison:** Compare every declared “Assumptions and exclusions” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M01.01-C085-T08 · State and bounds check:** Inspect the “Assumptions and exclusions” ownership/state effects and actual use of “Assumption count and review interval”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M01.01-C085-T09 · Repeatability check:** Repeat the same “Assumptions and exclusions” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M01.01-C085-T10 · Positive evidence:** Attach the “Assumptions and exclusions” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M01.01-C086 · Negative test

**Original checklist item:** Negative case: A host administrator is silently treated as an untrusted isolated tenant. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M01.01-C086-T01 · Adverse-case definition:** Create a test record for the exact “Assumptions and exclusions” source counterexample: “A host administrator is silently treated as an untrusted isolated tenant”; state which precondition or invariant it challenges.
- [ ] **UC-M01.01-C086-T02 · Safe fixture boundary:** Define the contained test boundary for “Assumptions and exclusions”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M01.01-C086-T03 · Valid control:** Construct a valid “Assumptions and exclusions” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M01.01-C086-T04 · Minimal adverse input:** Derive the “Assumptions and exclusions” adverse fixture from the control with the smallest documented change needed to reproduce “A host administrator is silently treated as an untrusted isolated tenant”; retain that change as reproducible data.
- [ ] **UC-M01.01-C086-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Assumptions and exclusions”; require “Unsupported threats remain visible in promotion decisions” and forbid a false-success verdict.
- [ ] **UC-M01.01-C086-T06 · Adverse execution:** Evaluate the “Assumptions and exclusions” adverse case through the actual review/contract gate; where implemented, also observe the runtime refusal and keep the two evidence classes separate.
- [ ] **UC-M01.01-C086-T07 · Effect inspection:** Inspect “Assumptions and exclusions” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M01.01-C086-T08 · Refusal versus failure:** Confirm the “Assumptions and exclusions” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M01.01-C086-T09 · Reset and retention:** Restore only the disposable “Assumptions and exclusions” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M01.01-C086-T10 · Negative regression:** Register the “Assumptions and exclusions” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M01.01-C087 · Change / failure test

**Original checklist item:** Exercise assumptions and exclusions when an entry point or trusted actor is added after the model was reviewed; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M01.01-C087-T01 · Scenario record:** Write the “Assumptions and exclusions” change/failure scenario exactly as supplied: an entry point or trusted actor is added after the model was reviewed; identify the property that must remain true: “Unsupported threats remain visible in promotion decisions”.
- [ ] **UC-M01.01-C087-T02 · Baseline capture:** Create a known-valid “Assumptions and exclusions” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M01.01-C087-T03 · Injection map:** Locate the “Assumptions and exclusions” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M01.01-C087-T04 · Disposition oracle:** Define the legal intermediate and final “Assumptions and exclusions” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M01.01-C087-T05 · Controlled trigger:** Apply the controlled model-change scenario for “Assumptions and exclusions”: an entry point or trusted actor is added after the model was reviewed; retain the exact before/after declarations. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M01.01-C087-T06 · Intermediate inspection:** Review which “Assumptions and exclusions” claims, approvals and evidence references become stale after the change; keep unresolved enforcement gaps visible.
- [ ] **UC-M01.01-C087-T07 · Recovery path:** Revise or explicitly refuse the changed “Assumptions and exclusions” model under the documented compatibility policy; re-review affected claims before restoring their approval.
- [ ] **UC-M01.01-C087-T08 · Stale-evidence cleanup:** Invalidate superseded “Assumptions and exclusions” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M01.01-C087-T09 · Repeat and compare:** Repeat the selected “Assumptions and exclusions” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M01.01-C087-T10 · Failure evidence:** Publish the “Assumptions and exclusions” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M01.01-C088 · Bounds

**Original checklist item:** Define completeness and scaling criteria for assumption count and review interval; exercise larger inventories or fixture sets, and report uncovered scope instead of silently excluding it.

- [ ] **UC-M01.01-C088-T01 · Quantity inventory:** Create a measurement inventory for “Assumptions and exclusions”: “Assumption count and review interval”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M01.01-C088-T02 · Measurement method:** Choose how to observe each “Assumptions and exclusions” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M01.01-C088-T03 · Budget decision:** Select justified coverage and completeness limits for “Assumptions and exclusions”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M01.01-C088-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Assumptions and exclusions” cases for “Assumption count and review interval”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M01.01-C088-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Assumptions and exclusions” limit; preserve “Unsupported threats remain visible in promotion decisions”.
- [ ] **UC-M01.01-C088-T06 · Normal measurement:** Run or review the normal “Assumptions and exclusions” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M01.01-C088-T07 · At-limit measurement:** Exercise the “Assumptions and exclusions” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M01.01-C088-T08 · Over-limit measurement:** Exercise the “Assumptions and exclusions” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M01.01-C088-T09 · Uncovered-scope report:** List the “Assumptions and exclusions” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M01.01-C088-T10 · Limit evidence:** Publish the selected “Assumptions and exclusions” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M01.01-C089 · Diagnostics / review

**Original checklist item:** Record the rationale, unresolved assumptions, enforcement gaps and re-review triggers for assumptions and exclusions; make design-only claims visibly distinct from observed behavior.

- [ ] **UC-M01.01-C089-T01 · Review inventory:** List the “Assumptions and exclusions” decisions and claims requiring review; distinguish source requirements, implementation observations and engineering assumptions.
- [ ] **UC-M01.01-C089-T02 · Rationale record:** Write the rationale for the selected “Assumptions and exclusions” representation or policy; link each choice to the requirement rather than an unexplained preference.
- [ ] **UC-M01.01-C089-T03 · Assumption ledger:** Record unresolved “Assumptions and exclusions” assumptions, their owner and what observation or decision would resolve them; do not treat unknowns as approvals.
- [ ] **UC-M01.01-C089-T04 · Boundary map:** Map each “Assumptions and exclusions” claim to an actual guard or explicit design/review gate; flag gaps against “Unsupported threats remain visible in promotion decisions”.
- [ ] **UC-M01.01-C089-T05 · Counterexample review:** Walk reviewers through the “Assumptions and exclusions” counterexample “A host administrator is silently treated as an untrusted isolated tenant”; record whether the model detects it and whether any runtime guard was actually exercised.
- [ ] **UC-M01.01-C089-T06 · Review outcome vocabulary:** Define approved, blocked, superseded and untested review outcomes for “Assumptions and exclusions”; ensure the wording cannot be read as runtime enforcement evidence.
- [ ] **UC-M01.01-C089-T07 · Re-review triggers:** List “Assumptions and exclusions” invalidation triggers, including the source change scenario: an entry point or trusted actor is added after the model was reviewed; identify the affected claims and evidence.
- [ ] **UC-M01.01-C089-T08 · Sensitive-data review:** Inspect the “Assumptions and exclusions” review record for secrets and unrelated user content; retain nonsecret references sufficient for reproducibility.
- [ ] **UC-M01.01-C089-T09 · Independent reading:** Have the “Assumptions and exclusions” record read against the original acceptance criterion and entry-point inventory, policy decisions and observed host enforcement; record misunderstandings or missing evidence as corrections.
- [ ] **UC-M01.01-C089-T10 · Review disposition:** Publish the “Assumptions and exclusions” rationale, versioned review outcome, unresolved gaps and explicit next decision; keep blockers open until supported evidence resolves them.

### UC-M01.01-C090 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for assumptions and exclusions; label unexecuted checks as untested.

- [ ] **UC-M01.01-C090-T01 · Evidence inventory:** List the “Assumptions and exclusions” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M01.01-C090-T02 · Artifact references:** Record the exact “Assumptions and exclusions” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M01.01-C090-T03 · Fixture references:** Attach the “Assumptions and exclusions” fixture IDs, input identities and oracle definition; preserve the source counterexample “A host administrator is silently treated as an untrusted isolated tenant” as a distinct evidence case.
- [ ] **UC-M01.01-C090-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Assumptions and exclusions”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M01.01-C090-T05 · Environment record:** Record the actual “Assumptions and exclusions” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M01.01-C090-T06 · Expected versus observed:** Pair every “Assumptions and exclusions” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M01.01-C090-T07 · Failure and limit records:** Attach “Assumptions and exclusions” change/failure and bounds evidence where required; include uncovered “Assumption count and review interval” and unresolved violations of “Unsupported threats remain visible in promotion decisions”.
- [ ] **UC-M01.01-C090-T08 · Evidence hygiene:** Check the “Assumptions and exclusions” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M01.01-C090-T09 · Reproduction review:** Have the “Assumptions and exclusions” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M01.01-C090-T10 · Acceptance linkage:** Link the “Assumptions and exclusions” evidence to its parent and UC-M01.01 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 10. Model review gate

**Source delivery:** Version the reviewed threat model and connect its findings to component acceptance.

**Source invariant:** An unresolved required boundary blocks the relevant promotion.

**Source negative case:** A release reuses approval after adding an unreviewed entry point.

**Source bounded quantities:** Open blocker count and model-to-release drift.

### UC-M01.01-C091 · Contract

**Original checklist item:** Specify the scope and representation of model review gate; identify its producer, consumer, authority assumptions and explicitly unsupported cases.

- [ ] **UC-M01.01-C091-T01 · Scope statement:** Draft a scope note for “Model review gate” within Trust-boundary and capability model; separate required model statements, explicit exclusions and unresolved design decisions.
- [ ] **UC-M01.01-C091-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Model review gate”; record each producer, representation and missing-value meaning.
- [ ] **UC-M01.01-C091-T03 · Output inventory:** List the outputs of “Model review gate” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M01.01-C091-T04 · Field dictionary:** Create a field-and-term dictionary for “Model review gate”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M01.01-C091-T05 · Prerequisite contract:** Map “Model review gate” to the source component prerequisites (none declared; foundational work); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M01.01-C091-T06 · Authority map:** Identify who may produce, change and consume “Model review gate”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M01.01-C091-T07 · Invariant clause:** Add a normative clause for “Model review gate” that preserves “An unresolved required boundary blocks the relevant promotion”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M01.01-C091-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Model review gate”; include the source counterexample “A release reuses approval after adding an unreviewed entry point” and the intended safe disposition.
- [ ] **UC-M01.01-C091-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Open blocker count and model-to-release drift” in the “Model review gate” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M01.01-C091-T10 · Contract review:** Review the “Model review gate” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M01.01-C092 · Delivery

**Original checklist item:** Version the reviewed threat model and connect its findings to component acceptance.

- [ ] **UC-M01.01-C092-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Model review gate”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M01.01-C092-T02 · Change plan:** Break the source delivery for “Model review gate” into concrete edit targets and reviewable outputs; keep the UC-M01.01 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M01.01-C092-T03 · Core artifact:** Implement the smallest selected-profile change for “Model review gate” that realizes this source instruction: Version the reviewed threat model and connect its findings to component acceptance.
- [ ] **UC-M01.01-C092-T04 · Concrete realization:** Trace “Model review gate” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M01.01-C092-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Model review gate” needed to preserve “An unresolved required boundary blocks the relevant promotion”; record an enforcement gap where only a model exists.
- [ ] **UC-M01.01-C092-T06 · Dependency connection:** Connect the “Model review gate” specification to entry-point inventory, policy decisions and observed host enforcement; record code coverage separately where the design is not yet enforced.
- [ ] **UC-M01.01-C092-T07 · Resource behavior:** Account for “Open blocker count and model-to-release drift” in “Model review gate”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M01.01-C092-T08 · Delivery check:** Walk the populated “Model review gate” model through a valid example and the source counterexample “A release reuses approval after adding an unreviewed entry point”; record corrections and unresolved enforcement gaps.
- [ ] **UC-M01.01-C092-T09 · Patch review:** Review the “Model review gate” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M01.01-C092-T10 · Delivery handoff:** Publish the “Model review gate” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M01.01-C093 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: An unresolved required boundary blocks the relevant promotion. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M01.01-C093-T01 · Named property:** Create a stable property/check name under this parent for “Model review gate”; copy its required invariant exactly: “An unresolved required boundary blocks the relevant promotion”.
- [ ] **UC-M01.01-C093-T02 · Observable terms:** Define each term in the “Model review gate” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M01.01-C093-T03 · Precondition set:** List the preconditions under which “An unresolved required boundary blocks the relevant promotion” must hold for “Model review gate”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M01.01-C093-T04 · Transition coverage:** Map the “Model review gate” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M01.01-C093-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Model review gate”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M01.01-C093-T06 · Satisfying fixture:** Create a concrete “Model review gate” case that satisfies “An unresolved required boundary blocks the relevant promotion”; record its expected observation before running the assertion or review.
- [ ] **UC-M01.01-C093-T07 · Violating fixture:** Create the source counterexample “A release reuses approval after adding an unreviewed entry point” for “Model review gate”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M01.01-C093-T08 · Enforcement evidence:** Exercise the “Model review gate” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M01.01-C093-T09 · Regression linkage:** Link the “Model review gate” property to changes in entry-point inventory, policy decisions and observed host enforcement; record which dependency or contract changes require rerunning it.
- [ ] **UC-M01.01-C093-T10 · Property disposition:** Compare the satisfying and violating “Model review gate” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M01.01-C094 · Integration

**Original checklist item:** Integrate model review gate with entry-point inventory, policy decisions and observed host enforcement; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M01.01-C094-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Model review gate” across entry-point inventory, policy decisions and observed host enforcement; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M01.01-C094-T02 · Field mapping:** Map every “Model review gate” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M01.01-C094-T03 · Prerequisite identities:** Record the actual prerequisites for “Model review gate” (source dependency list: none declared; foundational work); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M01.01-C094-T04 · Ownership agreement:** Specify who owns “Model review gate” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M01.01-C094-T05 · Handoff implementation:** Connect “Model review gate” through the mapped seam using the real adapter or explicit specification reference; preserve “An unresolved required boundary blocks the relevant promotion” across the handoff.
- [ ] **UC-M01.01-C094-T06 · Absent-input case:** Omit one required “Model review gate” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M01.01-C094-T07 · Stale-input case:** Supply an outdated “Model review gate” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M01.01-C094-T08 · Incompatible-input case:** Supply an incompatible “Model review gate” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M01.01-C094-T09 · Valid integration trace:** Run a valid “Model review gate” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M01.01-C094-T10 · Seam review:** Reconcile the “Model review gate” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M01.01-C095 · Valid-case test

**Original checklist item:** Construct a valid worked example for model review gate; evaluate it against predeclared expected decisions and, where enforcement exists, run the corresponding conformance fixture.

- [ ] **UC-M01.01-C095-T01 · Valid fixture choice:** Select one concrete valid worked example for “Model review gate”; enumerate the model inputs and the expected review decision before evaluating it.
- [ ] **UC-M01.01-C095-T02 · Expected-result oracle:** Specify the “Model review gate” expected result independently of the implementation output; include the property “An unresolved required boundary blocks the relevant promotion” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M01.01-C095-T03 · Fixture material:** Create the concrete “Model review gate” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M01.01-C095-T04 · Target preparation:** Prepare the “Model review gate” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M01.01-C095-T05 · Initial-state record:** Record the initial “Model review gate” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M01.01-C095-T06 · Valid-path execution:** Evaluate the “Model review gate” example against the reviewed model; where a runtime mechanism exists, run its corresponding fixture and label those observations separately.
- [ ] **UC-M01.01-C095-T07 · Outcome comparison:** Compare every declared “Model review gate” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M01.01-C095-T08 · State and bounds check:** Inspect the “Model review gate” ownership/state effects and actual use of “Open blocker count and model-to-release drift”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M01.01-C095-T09 · Repeatability check:** Repeat the same “Model review gate” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M01.01-C095-T10 · Positive evidence:** Attach the “Model review gate” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M01.01-C096 · Negative test

**Original checklist item:** Negative case: A release reuses approval after adding an unreviewed entry point. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M01.01-C096-T01 · Adverse-case definition:** Create a test record for the exact “Model review gate” source counterexample: “A release reuses approval after adding an unreviewed entry point”; state which precondition or invariant it challenges.
- [ ] **UC-M01.01-C096-T02 · Safe fixture boundary:** Define the contained test boundary for “Model review gate”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M01.01-C096-T03 · Valid control:** Construct a valid “Model review gate” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M01.01-C096-T04 · Minimal adverse input:** Derive the “Model review gate” adverse fixture from the control with the smallest documented change needed to reproduce “A release reuses approval after adding an unreviewed entry point”; retain that change as reproducible data.
- [ ] **UC-M01.01-C096-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Model review gate”; require “An unresolved required boundary blocks the relevant promotion” and forbid a false-success verdict.
- [ ] **UC-M01.01-C096-T06 · Adverse execution:** Evaluate the “Model review gate” adverse case through the actual review/contract gate; where implemented, also observe the runtime refusal and keep the two evidence classes separate.
- [ ] **UC-M01.01-C096-T07 · Effect inspection:** Inspect “Model review gate” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M01.01-C096-T08 · Refusal versus failure:** Confirm the “Model review gate” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M01.01-C096-T09 · Reset and retention:** Restore only the disposable “Model review gate” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M01.01-C096-T10 · Negative regression:** Register the “Model review gate” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M01.01-C097 · Change / failure test

**Original checklist item:** Exercise model review gate when an entry point or trusted actor is added after the model was reviewed; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M01.01-C097-T01 · Scenario record:** Write the “Model review gate” change/failure scenario exactly as supplied: an entry point or trusted actor is added after the model was reviewed; identify the property that must remain true: “An unresolved required boundary blocks the relevant promotion”.
- [ ] **UC-M01.01-C097-T02 · Baseline capture:** Create a known-valid “Model review gate” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M01.01-C097-T03 · Injection map:** Locate the “Model review gate” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M01.01-C097-T04 · Disposition oracle:** Define the legal intermediate and final “Model review gate” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M01.01-C097-T05 · Controlled trigger:** Apply the controlled model-change scenario for “Model review gate”: an entry point or trusted actor is added after the model was reviewed; retain the exact before/after declarations. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M01.01-C097-T06 · Intermediate inspection:** Review which “Model review gate” claims, approvals and evidence references become stale after the change; keep unresolved enforcement gaps visible.
- [ ] **UC-M01.01-C097-T07 · Recovery path:** Revise or explicitly refuse the changed “Model review gate” model under the documented compatibility policy; re-review affected claims before restoring their approval.
- [ ] **UC-M01.01-C097-T08 · Stale-evidence cleanup:** Invalidate superseded “Model review gate” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M01.01-C097-T09 · Repeat and compare:** Repeat the selected “Model review gate” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M01.01-C097-T10 · Failure evidence:** Publish the “Model review gate” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M01.01-C098 · Bounds

**Original checklist item:** Define completeness and scaling criteria for open blocker count and model-to-release drift; exercise larger inventories or fixture sets, and report uncovered scope instead of silently excluding it.

- [ ] **UC-M01.01-C098-T01 · Quantity inventory:** Create a measurement inventory for “Model review gate”: “Open blocker count and model-to-release drift”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M01.01-C098-T02 · Measurement method:** Choose how to observe each “Model review gate” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M01.01-C098-T03 · Budget decision:** Select justified coverage and completeness limits for “Model review gate”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M01.01-C098-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Model review gate” cases for “Open blocker count and model-to-release drift”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M01.01-C098-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Model review gate” limit; preserve “An unresolved required boundary blocks the relevant promotion”.
- [ ] **UC-M01.01-C098-T06 · Normal measurement:** Run or review the normal “Model review gate” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M01.01-C098-T07 · At-limit measurement:** Exercise the “Model review gate” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M01.01-C098-T08 · Over-limit measurement:** Exercise the “Model review gate” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M01.01-C098-T09 · Uncovered-scope report:** List the “Model review gate” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M01.01-C098-T10 · Limit evidence:** Publish the selected “Model review gate” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M01.01-C099 · Diagnostics / review

**Original checklist item:** Record the rationale, unresolved assumptions, enforcement gaps and re-review triggers for model review gate; make design-only claims visibly distinct from observed behavior.

- [ ] **UC-M01.01-C099-T01 · Review inventory:** List the “Model review gate” decisions and claims requiring review; distinguish source requirements, implementation observations and engineering assumptions.
- [ ] **UC-M01.01-C099-T02 · Rationale record:** Write the rationale for the selected “Model review gate” representation or policy; link each choice to the requirement rather than an unexplained preference.
- [ ] **UC-M01.01-C099-T03 · Assumption ledger:** Record unresolved “Model review gate” assumptions, their owner and what observation or decision would resolve them; do not treat unknowns as approvals.
- [ ] **UC-M01.01-C099-T04 · Boundary map:** Map each “Model review gate” claim to an actual guard or explicit design/review gate; flag gaps against “An unresolved required boundary blocks the relevant promotion”.
- [ ] **UC-M01.01-C099-T05 · Counterexample review:** Walk reviewers through the “Model review gate” counterexample “A release reuses approval after adding an unreviewed entry point”; record whether the model detects it and whether any runtime guard was actually exercised.
- [ ] **UC-M01.01-C099-T06 · Review outcome vocabulary:** Define approved, blocked, superseded and untested review outcomes for “Model review gate”; ensure the wording cannot be read as runtime enforcement evidence.
- [ ] **UC-M01.01-C099-T07 · Re-review triggers:** List “Model review gate” invalidation triggers, including the source change scenario: an entry point or trusted actor is added after the model was reviewed; identify the affected claims and evidence.
- [ ] **UC-M01.01-C099-T08 · Sensitive-data review:** Inspect the “Model review gate” review record for secrets and unrelated user content; retain nonsecret references sufficient for reproducibility.
- [ ] **UC-M01.01-C099-T09 · Independent reading:** Have the “Model review gate” record read against the original acceptance criterion and entry-point inventory, policy decisions and observed host enforcement; record misunderstandings or missing evidence as corrections.
- [ ] **UC-M01.01-C099-T10 · Review disposition:** Publish the “Model review gate” rationale, versioned review outcome, unresolved gaps and explicit next decision; keep blockers open until supported evidence resolves them.

### UC-M01.01-C100 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for model review gate; label unexecuted checks as untested.

- [ ] **UC-M01.01-C100-T01 · Evidence inventory:** List the “Model review gate” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M01.01-C100-T02 · Artifact references:** Record the exact “Model review gate” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M01.01-C100-T03 · Fixture references:** Attach the “Model review gate” fixture IDs, input identities and oracle definition; preserve the source counterexample “A release reuses approval after adding an unreviewed entry point” as a distinct evidence case.
- [ ] **UC-M01.01-C100-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Model review gate”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M01.01-C100-T05 · Environment record:** Record the actual “Model review gate” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M01.01-C100-T06 · Expected versus observed:** Pair every “Model review gate” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M01.01-C100-T07 · Failure and limit records:** Attach “Model review gate” change/failure and bounds evidence where required; include uncovered “Open blocker count and model-to-release drift” and unresolved violations of “An unresolved required boundary blocks the relevant promotion”.
- [ ] **UC-M01.01-C100-T08 · Evidence hygiene:** Check the “Model review gate” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M01.01-C100-T09 · Reproduction review:** Have the “Model review gate” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M01.01-C100-T10 · Acceptance linkage:** Link the “Model review gate” evidence to its parent and UC-M01.01 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

