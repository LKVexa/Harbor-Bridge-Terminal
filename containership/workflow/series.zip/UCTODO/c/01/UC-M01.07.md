# UC-M01.07 — Application semantics versus witness contract

**To-Do Pack 2.0.0 · Baseline UC-2.2.0 · 100 parent checks × 10 subtasks = 1,000 to-dos**

[Master index](../../INDEX.md) · [Workstream index](../../w/01.md)

| Field | Preserved source value |
|---|---|
| Workstream | 01. Architecture and executable contracts |
| Milestone | A |
| Priority | P0 |
| Source assessment | PARTIAL |
| Scope | core or selected profile |
| Dependencies | [UC-M01.02](../01/UC-M01.02.md), [UC-M01.06](../01/UC-M01.06.md) |
| Source checklist pack | 1.0.0 |
| Original reference labels | [S1], [S3]. |

## Original requirement

Distinguish sorting, metadata witnessing, dialect compilation and actual application execution. Define supported source languages and observable semantics.

**Original acceptance criterion:** A nontrivial application passes semantic input/output tests on its target; a row-sequence hash alone never satisfies execution.

**Source trace:** Original checklist `UC100/c/01/UC-M01.07.md` inside [s/checklists.zip](../../s/checklists.zip); exact parent records in [data/parents.jsonl](../../data/parents.jsonl). Original roadmap lines 115–125 are preserved in [s/roadmap.md](../../s/roadmap.md).

## How to use these lists

Every parent statement below is preserved verbatim. Its ten child tasks are proposed decomposition, not implemented capabilities or executed tests. Child IDs append `-T01` through `-T10` to the original parent ID. All begin unchecked / `TODO`. Design/review evidence does not establish runtime enforcement; observe the actual selected target where the parent requires it.

The source dependency graph and selected release profile determine applicability. The numbered child sequence is a local working order, not an added hard dependency graph. An unselected optional feature needs a recorded not-applicable rationale; missing prerequisites for selected work remain blockers. Numerical budgets, backends and trust mechanisms remain decisions unless fixed by the source. Test hostile cases only with synthetic inputs in authorized disposable environments.

## 01. Execution-kind taxonomy

**Source delivery:** Distinguish sorting, metadata witnessing, dialect compilation and application execution.

**Source invariant:** One execution kind cannot satisfy another kind's acceptance gate.

**Source negative case:** A metadata sort is presented as application execution.

**Source bounded quantities:** Execution-kind count and classification coverage.

### UC-M01.07-C001 · Contract

**Original checklist item:** Specify the scope and representation of execution-kind taxonomy; identify its producer, consumer, authority assumptions and explicitly unsupported cases.

- [ ] **UC-M01.07-C001-T01 · Scope statement:** Draft a scope note for “Execution-kind taxonomy” within Application semantics versus witness contract; separate required model statements, explicit exclusions and unresolved design decisions.
- [ ] **UC-M01.07-C001-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Execution-kind taxonomy”; record each producer, representation and missing-value meaning.
- [ ] **UC-M01.07-C001-T03 · Output inventory:** List the outputs of “Execution-kind taxonomy” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M01.07-C001-T04 · Field dictionary:** Create a field-and-term dictionary for “Execution-kind taxonomy”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M01.07-C001-T05 · Prerequisite contract:** Map “Execution-kind taxonomy” to the source component prerequisites (UC-M01.02, UC-M01.06); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M01.07-C001-T06 · Authority map:** Identify who may produce, change and consume “Execution-kind taxonomy”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M01.07-C001-T07 · Invariant clause:** Add a normative clause for “Execution-kind taxonomy” that preserves “One execution kind cannot satisfy another kind's acceptance gate”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M01.07-C001-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Execution-kind taxonomy”; include the source counterexample “A metadata sort is presented as application execution” and the intended safe disposition.
- [ ] **UC-M01.07-C001-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Execution-kind count and classification coverage” in the “Execution-kind taxonomy” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M01.07-C001-T10 · Contract review:** Review the “Execution-kind taxonomy” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M01.07-C002 · Delivery

**Original checklist item:** Distinguish sorting, metadata witnessing, dialect compilation and application execution.

- [ ] **UC-M01.07-C002-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Execution-kind taxonomy”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M01.07-C002-T02 · Change plan:** Break the source delivery for “Execution-kind taxonomy” into concrete edit targets and reviewable outputs; keep the UC-M01.07 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M01.07-C002-T03 · Core artifact:** Create the “Execution-kind taxonomy” model, schema or inventory that realizes this source instruction: Distinguish sorting, metadata witnessing, dialect compilation and application execution.
- [ ] **UC-M01.07-C002-T04 · Concrete realization:** Populate “Execution-kind taxonomy” with one concrete worked case; map every required entity or field to its source and flag any unmapped entry.
- [ ] **UC-M01.07-C002-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Execution-kind taxonomy” needed to preserve “One execution kind cannot satisfy another kind's acceptance gate”; record an enforcement gap where only a model exists.
- [ ] **UC-M01.07-C002-T06 · Dependency connection:** Connect the “Execution-kind taxonomy” specification to language admission, translation outputs and application-result oracles; record code coverage separately where the design is not yet enforced.
- [ ] **UC-M01.07-C002-T07 · Resource behavior:** Account for “Execution-kind count and classification coverage” in “Execution-kind taxonomy”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M01.07-C002-T08 · Delivery check:** Walk the populated “Execution-kind taxonomy” model through a valid example and the source counterexample “A metadata sort is presented as application execution”; record corrections and unresolved enforcement gaps.
- [ ] **UC-M01.07-C002-T09 · Patch review:** Review the “Execution-kind taxonomy” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M01.07-C002-T10 · Delivery handoff:** Publish the “Execution-kind taxonomy” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M01.07-C003 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: One execution kind cannot satisfy another kind's acceptance gate. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M01.07-C003-T01 · Named property:** Create a stable property/check name under this parent for “Execution-kind taxonomy”; copy its required invariant exactly: “One execution kind cannot satisfy another kind's acceptance gate”.
- [ ] **UC-M01.07-C003-T02 · Observable terms:** Define each term in the “Execution-kind taxonomy” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M01.07-C003-T03 · Precondition set:** List the preconditions under which “One execution kind cannot satisfy another kind's acceptance gate” must hold for “Execution-kind taxonomy”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M01.07-C003-T04 · Transition coverage:** Map the “Execution-kind taxonomy” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M01.07-C003-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Execution-kind taxonomy”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M01.07-C003-T06 · Satisfying fixture:** Create a concrete “Execution-kind taxonomy” case that satisfies “One execution kind cannot satisfy another kind's acceptance gate”; record its expected observation before running the assertion or review.
- [ ] **UC-M01.07-C003-T07 · Violating fixture:** Create the source counterexample “A metadata sort is presented as application execution” for “Execution-kind taxonomy”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M01.07-C003-T08 · Enforcement evidence:** Exercise the “Execution-kind taxonomy” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M01.07-C003-T09 · Regression linkage:** Link the “Execution-kind taxonomy” property to changes in language admission, translation outputs and application-result oracles; record which dependency or contract changes require rerunning it.
- [ ] **UC-M01.07-C003-T10 · Property disposition:** Compare the satisfying and violating “Execution-kind taxonomy” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M01.07-C004 · Integration

**Original checklist item:** Integrate execution-kind taxonomy with language admission, translation outputs and application-result oracles; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M01.07-C004-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Execution-kind taxonomy” across language admission, translation outputs and application-result oracles; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M01.07-C004-T02 · Field mapping:** Map every “Execution-kind taxonomy” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M01.07-C004-T03 · Prerequisite identities:** Record the actual prerequisites for “Execution-kind taxonomy” (source dependency list: UC-M01.02, UC-M01.06); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M01.07-C004-T04 · Ownership agreement:** Specify who owns “Execution-kind taxonomy” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M01.07-C004-T05 · Handoff implementation:** Connect “Execution-kind taxonomy” through the mapped seam using the real adapter or explicit specification reference; preserve “One execution kind cannot satisfy another kind's acceptance gate” across the handoff.
- [ ] **UC-M01.07-C004-T06 · Absent-input case:** Omit one required “Execution-kind taxonomy” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M01.07-C004-T07 · Stale-input case:** Supply an outdated “Execution-kind taxonomy” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M01.07-C004-T08 · Incompatible-input case:** Supply an incompatible “Execution-kind taxonomy” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M01.07-C004-T09 · Valid integration trace:** Run a valid “Execution-kind taxonomy” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M01.07-C004-T10 · Seam review:** Reconcile the “Execution-kind taxonomy” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M01.07-C005 · Valid-case test

**Original checklist item:** Construct a valid worked example for execution-kind taxonomy; evaluate it against predeclared expected decisions and, where enforcement exists, run the corresponding conformance fixture.

- [ ] **UC-M01.07-C005-T01 · Valid fixture choice:** Select one concrete valid worked example for “Execution-kind taxonomy”; enumerate the model inputs and the expected review decision before evaluating it.
- [ ] **UC-M01.07-C005-T02 · Expected-result oracle:** Specify the “Execution-kind taxonomy” expected result independently of the implementation output; include the property “One execution kind cannot satisfy another kind's acceptance gate” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M01.07-C005-T03 · Fixture material:** Create the concrete “Execution-kind taxonomy” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M01.07-C005-T04 · Target preparation:** Prepare the “Execution-kind taxonomy” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M01.07-C005-T05 · Initial-state record:** Record the initial “Execution-kind taxonomy” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M01.07-C005-T06 · Valid-path execution:** Evaluate the “Execution-kind taxonomy” example against the reviewed model; where a runtime mechanism exists, run its corresponding fixture and label those observations separately.
- [ ] **UC-M01.07-C005-T07 · Outcome comparison:** Compare every declared “Execution-kind taxonomy” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M01.07-C005-T08 · State and bounds check:** Inspect the “Execution-kind taxonomy” ownership/state effects and actual use of “Execution-kind count and classification coverage”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M01.07-C005-T09 · Repeatability check:** Repeat the same “Execution-kind taxonomy” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M01.07-C005-T10 · Positive evidence:** Attach the “Execution-kind taxonomy” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M01.07-C006 · Negative test

**Original checklist item:** Negative case: A metadata sort is presented as application execution. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M01.07-C006-T01 · Adverse-case definition:** Create a test record for the exact “Execution-kind taxonomy” source counterexample: “A metadata sort is presented as application execution”; state which precondition or invariant it challenges.
- [ ] **UC-M01.07-C006-T02 · Safe fixture boundary:** Define the contained test boundary for “Execution-kind taxonomy”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M01.07-C006-T03 · Valid control:** Construct a valid “Execution-kind taxonomy” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M01.07-C006-T04 · Minimal adverse input:** Derive the “Execution-kind taxonomy” adverse fixture from the control with the smallest documented change needed to reproduce “A metadata sort is presented as application execution”; retain that change as reproducible data.
- [ ] **UC-M01.07-C006-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Execution-kind taxonomy”; require “One execution kind cannot satisfy another kind's acceptance gate” and forbid a false-success verdict.
- [ ] **UC-M01.07-C006-T06 · Adverse execution:** Evaluate the “Execution-kind taxonomy” adverse case through the actual review/contract gate; where implemented, also observe the runtime refusal and keep the two evidence classes separate.
- [ ] **UC-M01.07-C006-T07 · Effect inspection:** Inspect “Execution-kind taxonomy” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M01.07-C006-T08 · Refusal versus failure:** Confirm the “Execution-kind taxonomy” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M01.07-C006-T09 · Reset and retention:** Restore only the disposable “Execution-kind taxonomy” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M01.07-C006-T10 · Negative regression:** Register the “Execution-kind taxonomy” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M01.07-C007 · Change / failure test

**Original checklist item:** Exercise execution-kind taxonomy when a witness still agrees after application behavior or the supported input domain changes; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M01.07-C007-T01 · Scenario record:** Write the “Execution-kind taxonomy” change/failure scenario exactly as supplied: a witness still agrees after application behavior or the supported input domain changes; identify the property that must remain true: “One execution kind cannot satisfy another kind's acceptance gate”.
- [ ] **UC-M01.07-C007-T02 · Baseline capture:** Create a known-valid “Execution-kind taxonomy” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M01.07-C007-T03 · Injection map:** Locate the “Execution-kind taxonomy” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M01.07-C007-T04 · Disposition oracle:** Define the legal intermediate and final “Execution-kind taxonomy” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M01.07-C007-T05 · Controlled trigger:** Apply the controlled model-change scenario for “Execution-kind taxonomy”: a witness still agrees after application behavior or the supported input domain changes; retain the exact before/after declarations. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M01.07-C007-T06 · Intermediate inspection:** Review which “Execution-kind taxonomy” claims, approvals and evidence references become stale after the change; keep unresolved enforcement gaps visible.
- [ ] **UC-M01.07-C007-T07 · Recovery path:** Revise or explicitly refuse the changed “Execution-kind taxonomy” model under the documented compatibility policy; re-review affected claims before restoring their approval.
- [ ] **UC-M01.07-C007-T08 · Stale-evidence cleanup:** Invalidate superseded “Execution-kind taxonomy” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M01.07-C007-T09 · Repeat and compare:** Repeat the selected “Execution-kind taxonomy” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M01.07-C007-T10 · Failure evidence:** Publish the “Execution-kind taxonomy” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M01.07-C008 · Bounds

**Original checklist item:** Define completeness and scaling criteria for execution-kind count and classification coverage; exercise larger inventories or fixture sets, and report uncovered scope instead of silently excluding it.

- [ ] **UC-M01.07-C008-T01 · Quantity inventory:** Create a measurement inventory for “Execution-kind taxonomy”: “Execution-kind count and classification coverage”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M01.07-C008-T02 · Measurement method:** Choose how to observe each “Execution-kind taxonomy” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M01.07-C008-T03 · Budget decision:** Select justified coverage and completeness limits for “Execution-kind taxonomy”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M01.07-C008-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Execution-kind taxonomy” cases for “Execution-kind count and classification coverage”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M01.07-C008-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Execution-kind taxonomy” limit; preserve “One execution kind cannot satisfy another kind's acceptance gate”.
- [ ] **UC-M01.07-C008-T06 · Normal measurement:** Run or review the normal “Execution-kind taxonomy” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M01.07-C008-T07 · At-limit measurement:** Exercise the “Execution-kind taxonomy” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M01.07-C008-T08 · Over-limit measurement:** Exercise the “Execution-kind taxonomy” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M01.07-C008-T09 · Uncovered-scope report:** List the “Execution-kind taxonomy” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M01.07-C008-T10 · Limit evidence:** Publish the selected “Execution-kind taxonomy” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M01.07-C009 · Diagnostics / review

**Original checklist item:** Record the rationale, unresolved assumptions, enforcement gaps and re-review triggers for execution-kind taxonomy; make design-only claims visibly distinct from observed behavior.

- [ ] **UC-M01.07-C009-T01 · Review inventory:** List the “Execution-kind taxonomy” decisions and claims requiring review; distinguish source requirements, implementation observations and engineering assumptions.
- [ ] **UC-M01.07-C009-T02 · Rationale record:** Write the rationale for the selected “Execution-kind taxonomy” representation or policy; link each choice to the requirement rather than an unexplained preference.
- [ ] **UC-M01.07-C009-T03 · Assumption ledger:** Record unresolved “Execution-kind taxonomy” assumptions, their owner and what observation or decision would resolve them; do not treat unknowns as approvals.
- [ ] **UC-M01.07-C009-T04 · Boundary map:** Map each “Execution-kind taxonomy” claim to an actual guard or explicit design/review gate; flag gaps against “One execution kind cannot satisfy another kind's acceptance gate”.
- [ ] **UC-M01.07-C009-T05 · Counterexample review:** Walk reviewers through the “Execution-kind taxonomy” counterexample “A metadata sort is presented as application execution”; record whether the model detects it and whether any runtime guard was actually exercised.
- [ ] **UC-M01.07-C009-T06 · Review outcome vocabulary:** Define approved, blocked, superseded and untested review outcomes for “Execution-kind taxonomy”; ensure the wording cannot be read as runtime enforcement evidence.
- [ ] **UC-M01.07-C009-T07 · Re-review triggers:** List “Execution-kind taxonomy” invalidation triggers, including the source change scenario: a witness still agrees after application behavior or the supported input domain changes; identify the affected claims and evidence.
- [ ] **UC-M01.07-C009-T08 · Sensitive-data review:** Inspect the “Execution-kind taxonomy” review record for secrets and unrelated user content; retain nonsecret references sufficient for reproducibility.
- [ ] **UC-M01.07-C009-T09 · Independent reading:** Have the “Execution-kind taxonomy” record read against the original acceptance criterion and language admission, translation outputs and application-result oracles; record misunderstandings or missing evidence as corrections.
- [ ] **UC-M01.07-C009-T10 · Review disposition:** Publish the “Execution-kind taxonomy” rationale, versioned review outcome, unresolved gaps and explicit next decision; keep blockers open until supported evidence resolves them.

### UC-M01.07-C010 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for execution-kind taxonomy; label unexecuted checks as untested.

- [ ] **UC-M01.07-C010-T01 · Evidence inventory:** List the “Execution-kind taxonomy” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M01.07-C010-T02 · Artifact references:** Record the exact “Execution-kind taxonomy” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M01.07-C010-T03 · Fixture references:** Attach the “Execution-kind taxonomy” fixture IDs, input identities and oracle definition; preserve the source counterexample “A metadata sort is presented as application execution” as a distinct evidence case.
- [ ] **UC-M01.07-C010-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Execution-kind taxonomy”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M01.07-C010-T05 · Environment record:** Record the actual “Execution-kind taxonomy” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M01.07-C010-T06 · Expected versus observed:** Pair every “Execution-kind taxonomy” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M01.07-C010-T07 · Failure and limit records:** Attach “Execution-kind taxonomy” change/failure and bounds evidence where required; include uncovered “Execution-kind count and classification coverage” and unresolved violations of “One execution kind cannot satisfy another kind's acceptance gate”.
- [ ] **UC-M01.07-C010-T08 · Evidence hygiene:** Check the “Execution-kind taxonomy” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M01.07-C010-T09 · Reproduction review:** Have the “Execution-kind taxonomy” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M01.07-C010-T10 · Acceptance linkage:** Link the “Execution-kind taxonomy” evidence to its parent and UC-M01.07 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 02. Supported language profiles

**Source delivery:** Define supported source languages and explicit feature subsets.

**Source invariant:** Unsupported language constructs cause an explicit refusal.

**Source negative case:** A compiler silently ignores an unsupported construct.

**Source bounded quantities:** Language feature count and input program size.

### UC-M01.07-C011 · Contract

**Original checklist item:** Specify the scope and representation of supported language profiles; identify its producer, consumer, authority assumptions and explicitly unsupported cases.

- [ ] **UC-M01.07-C011-T01 · Scope statement:** Draft a scope note for “Supported language profiles” within Application semantics versus witness contract; separate required model statements, explicit exclusions and unresolved design decisions.
- [ ] **UC-M01.07-C011-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Supported language profiles”; record each producer, representation and missing-value meaning.
- [ ] **UC-M01.07-C011-T03 · Output inventory:** List the outputs of “Supported language profiles” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M01.07-C011-T04 · Field dictionary:** Create a field-and-term dictionary for “Supported language profiles”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M01.07-C011-T05 · Prerequisite contract:** Map “Supported language profiles” to the source component prerequisites (UC-M01.02, UC-M01.06); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M01.07-C011-T06 · Authority map:** Identify who may produce, change and consume “Supported language profiles”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M01.07-C011-T07 · Invariant clause:** Add a normative clause for “Supported language profiles” that preserves “Unsupported language constructs cause an explicit refusal”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M01.07-C011-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Supported language profiles”; include the source counterexample “A compiler silently ignores an unsupported construct” and the intended safe disposition.
- [ ] **UC-M01.07-C011-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Language feature count and input program size” in the “Supported language profiles” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M01.07-C011-T10 · Contract review:** Review the “Supported language profiles” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M01.07-C012 · Delivery

**Original checklist item:** Define supported source languages and explicit feature subsets.

- [ ] **UC-M01.07-C012-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Supported language profiles”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M01.07-C012-T02 · Change plan:** Break the source delivery for “Supported language profiles” into concrete edit targets and reviewable outputs; keep the UC-M01.07 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M01.07-C012-T03 · Core artifact:** Create the “Supported language profiles” model, schema or inventory that realizes this source instruction: Define supported source languages and explicit feature subsets.
- [ ] **UC-M01.07-C012-T04 · Concrete realization:** Populate “Supported language profiles” with one concrete worked case; map every required entity or field to its source and flag any unmapped entry.
- [ ] **UC-M01.07-C012-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Supported language profiles” needed to preserve “Unsupported language constructs cause an explicit refusal”; record an enforcement gap where only a model exists.
- [ ] **UC-M01.07-C012-T06 · Dependency connection:** Connect the “Supported language profiles” specification to language admission, translation outputs and application-result oracles; record code coverage separately where the design is not yet enforced.
- [ ] **UC-M01.07-C012-T07 · Resource behavior:** Account for “Language feature count and input program size” in “Supported language profiles”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M01.07-C012-T08 · Delivery check:** Walk the populated “Supported language profiles” model through a valid example and the source counterexample “A compiler silently ignores an unsupported construct”; record corrections and unresolved enforcement gaps.
- [ ] **UC-M01.07-C012-T09 · Patch review:** Review the “Supported language profiles” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M01.07-C012-T10 · Delivery handoff:** Publish the “Supported language profiles” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M01.07-C013 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Unsupported language constructs cause an explicit refusal. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M01.07-C013-T01 · Named property:** Create a stable property/check name under this parent for “Supported language profiles”; copy its required invariant exactly: “Unsupported language constructs cause an explicit refusal”.
- [ ] **UC-M01.07-C013-T02 · Observable terms:** Define each term in the “Supported language profiles” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M01.07-C013-T03 · Precondition set:** List the preconditions under which “Unsupported language constructs cause an explicit refusal” must hold for “Supported language profiles”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M01.07-C013-T04 · Transition coverage:** Map the “Supported language profiles” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M01.07-C013-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Supported language profiles”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M01.07-C013-T06 · Satisfying fixture:** Create a concrete “Supported language profiles” case that satisfies “Unsupported language constructs cause an explicit refusal”; record its expected observation before running the assertion or review.
- [ ] **UC-M01.07-C013-T07 · Violating fixture:** Create the source counterexample “A compiler silently ignores an unsupported construct” for “Supported language profiles”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M01.07-C013-T08 · Enforcement evidence:** Exercise the “Supported language profiles” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M01.07-C013-T09 · Regression linkage:** Link the “Supported language profiles” property to changes in language admission, translation outputs and application-result oracles; record which dependency or contract changes require rerunning it.
- [ ] **UC-M01.07-C013-T10 · Property disposition:** Compare the satisfying and violating “Supported language profiles” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M01.07-C014 · Integration

**Original checklist item:** Integrate supported language profiles with language admission, translation outputs and application-result oracles; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M01.07-C014-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Supported language profiles” across language admission, translation outputs and application-result oracles; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M01.07-C014-T02 · Field mapping:** Map every “Supported language profiles” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M01.07-C014-T03 · Prerequisite identities:** Record the actual prerequisites for “Supported language profiles” (source dependency list: UC-M01.02, UC-M01.06); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M01.07-C014-T04 · Ownership agreement:** Specify who owns “Supported language profiles” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M01.07-C014-T05 · Handoff implementation:** Connect “Supported language profiles” through the mapped seam using the real adapter or explicit specification reference; preserve “Unsupported language constructs cause an explicit refusal” across the handoff.
- [ ] **UC-M01.07-C014-T06 · Absent-input case:** Omit one required “Supported language profiles” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M01.07-C014-T07 · Stale-input case:** Supply an outdated “Supported language profiles” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M01.07-C014-T08 · Incompatible-input case:** Supply an incompatible “Supported language profiles” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M01.07-C014-T09 · Valid integration trace:** Run a valid “Supported language profiles” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M01.07-C014-T10 · Seam review:** Reconcile the “Supported language profiles” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M01.07-C015 · Valid-case test

**Original checklist item:** Construct a valid worked example for supported language profiles; evaluate it against predeclared expected decisions and, where enforcement exists, run the corresponding conformance fixture.

- [ ] **UC-M01.07-C015-T01 · Valid fixture choice:** Select one concrete valid worked example for “Supported language profiles”; enumerate the model inputs and the expected review decision before evaluating it.
- [ ] **UC-M01.07-C015-T02 · Expected-result oracle:** Specify the “Supported language profiles” expected result independently of the implementation output; include the property “Unsupported language constructs cause an explicit refusal” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M01.07-C015-T03 · Fixture material:** Create the concrete “Supported language profiles” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M01.07-C015-T04 · Target preparation:** Prepare the “Supported language profiles” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M01.07-C015-T05 · Initial-state record:** Record the initial “Supported language profiles” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M01.07-C015-T06 · Valid-path execution:** Evaluate the “Supported language profiles” example against the reviewed model; where a runtime mechanism exists, run its corresponding fixture and label those observations separately.
- [ ] **UC-M01.07-C015-T07 · Outcome comparison:** Compare every declared “Supported language profiles” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M01.07-C015-T08 · State and bounds check:** Inspect the “Supported language profiles” ownership/state effects and actual use of “Language feature count and input program size”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M01.07-C015-T09 · Repeatability check:** Repeat the same “Supported language profiles” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M01.07-C015-T10 · Positive evidence:** Attach the “Supported language profiles” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M01.07-C016 · Negative test

**Original checklist item:** Negative case: A compiler silently ignores an unsupported construct. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M01.07-C016-T01 · Adverse-case definition:** Create a test record for the exact “Supported language profiles” source counterexample: “A compiler silently ignores an unsupported construct”; state which precondition or invariant it challenges.
- [ ] **UC-M01.07-C016-T02 · Safe fixture boundary:** Define the contained test boundary for “Supported language profiles”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M01.07-C016-T03 · Valid control:** Construct a valid “Supported language profiles” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M01.07-C016-T04 · Minimal adverse input:** Derive the “Supported language profiles” adverse fixture from the control with the smallest documented change needed to reproduce “A compiler silently ignores an unsupported construct”; retain that change as reproducible data.
- [ ] **UC-M01.07-C016-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Supported language profiles”; require “Unsupported language constructs cause an explicit refusal” and forbid a false-success verdict.
- [ ] **UC-M01.07-C016-T06 · Adverse execution:** Evaluate the “Supported language profiles” adverse case through the actual review/contract gate; where implemented, also observe the runtime refusal and keep the two evidence classes separate.
- [ ] **UC-M01.07-C016-T07 · Effect inspection:** Inspect “Supported language profiles” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M01.07-C016-T08 · Refusal versus failure:** Confirm the “Supported language profiles” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M01.07-C016-T09 · Reset and retention:** Restore only the disposable “Supported language profiles” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M01.07-C016-T10 · Negative regression:** Register the “Supported language profiles” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M01.07-C017 · Change / failure test

**Original checklist item:** Exercise supported language profiles when a witness still agrees after application behavior or the supported input domain changes; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M01.07-C017-T01 · Scenario record:** Write the “Supported language profiles” change/failure scenario exactly as supplied: a witness still agrees after application behavior or the supported input domain changes; identify the property that must remain true: “Unsupported language constructs cause an explicit refusal”.
- [ ] **UC-M01.07-C017-T02 · Baseline capture:** Create a known-valid “Supported language profiles” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M01.07-C017-T03 · Injection map:** Locate the “Supported language profiles” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M01.07-C017-T04 · Disposition oracle:** Define the legal intermediate and final “Supported language profiles” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M01.07-C017-T05 · Controlled trigger:** Apply the controlled model-change scenario for “Supported language profiles”: a witness still agrees after application behavior or the supported input domain changes; retain the exact before/after declarations. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M01.07-C017-T06 · Intermediate inspection:** Review which “Supported language profiles” claims, approvals and evidence references become stale after the change; keep unresolved enforcement gaps visible.
- [ ] **UC-M01.07-C017-T07 · Recovery path:** Revise or explicitly refuse the changed “Supported language profiles” model under the documented compatibility policy; re-review affected claims before restoring their approval.
- [ ] **UC-M01.07-C017-T08 · Stale-evidence cleanup:** Invalidate superseded “Supported language profiles” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M01.07-C017-T09 · Repeat and compare:** Repeat the selected “Supported language profiles” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M01.07-C017-T10 · Failure evidence:** Publish the “Supported language profiles” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M01.07-C018 · Bounds

**Original checklist item:** Define completeness and scaling criteria for language feature count and input program size; exercise larger inventories or fixture sets, and report uncovered scope instead of silently excluding it.

- [ ] **UC-M01.07-C018-T01 · Quantity inventory:** Create a measurement inventory for “Supported language profiles”: “Language feature count and input program size”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M01.07-C018-T02 · Measurement method:** Choose how to observe each “Supported language profiles” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M01.07-C018-T03 · Budget decision:** Select justified coverage and completeness limits for “Supported language profiles”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M01.07-C018-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Supported language profiles” cases for “Language feature count and input program size”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M01.07-C018-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Supported language profiles” limit; preserve “Unsupported language constructs cause an explicit refusal”.
- [ ] **UC-M01.07-C018-T06 · Normal measurement:** Run or review the normal “Supported language profiles” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M01.07-C018-T07 · At-limit measurement:** Exercise the “Supported language profiles” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M01.07-C018-T08 · Over-limit measurement:** Exercise the “Supported language profiles” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M01.07-C018-T09 · Uncovered-scope report:** List the “Supported language profiles” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M01.07-C018-T10 · Limit evidence:** Publish the selected “Supported language profiles” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M01.07-C019 · Diagnostics / review

**Original checklist item:** Record the rationale, unresolved assumptions, enforcement gaps and re-review triggers for supported language profiles; make design-only claims visibly distinct from observed behavior.

- [ ] **UC-M01.07-C019-T01 · Review inventory:** List the “Supported language profiles” decisions and claims requiring review; distinguish source requirements, implementation observations and engineering assumptions.
- [ ] **UC-M01.07-C019-T02 · Rationale record:** Write the rationale for the selected “Supported language profiles” representation or policy; link each choice to the requirement rather than an unexplained preference.
- [ ] **UC-M01.07-C019-T03 · Assumption ledger:** Record unresolved “Supported language profiles” assumptions, their owner and what observation or decision would resolve them; do not treat unknowns as approvals.
- [ ] **UC-M01.07-C019-T04 · Boundary map:** Map each “Supported language profiles” claim to an actual guard or explicit design/review gate; flag gaps against “Unsupported language constructs cause an explicit refusal”.
- [ ] **UC-M01.07-C019-T05 · Counterexample review:** Walk reviewers through the “Supported language profiles” counterexample “A compiler silently ignores an unsupported construct”; record whether the model detects it and whether any runtime guard was actually exercised.
- [ ] **UC-M01.07-C019-T06 · Review outcome vocabulary:** Define approved, blocked, superseded and untested review outcomes for “Supported language profiles”; ensure the wording cannot be read as runtime enforcement evidence.
- [ ] **UC-M01.07-C019-T07 · Re-review triggers:** List “Supported language profiles” invalidation triggers, including the source change scenario: a witness still agrees after application behavior or the supported input domain changes; identify the affected claims and evidence.
- [ ] **UC-M01.07-C019-T08 · Sensitive-data review:** Inspect the “Supported language profiles” review record for secrets and unrelated user content; retain nonsecret references sufficient for reproducibility.
- [ ] **UC-M01.07-C019-T09 · Independent reading:** Have the “Supported language profiles” record read against the original acceptance criterion and language admission, translation outputs and application-result oracles; record misunderstandings or missing evidence as corrections.
- [ ] **UC-M01.07-C019-T10 · Review disposition:** Publish the “Supported language profiles” rationale, versioned review outcome, unresolved gaps and explicit next decision; keep blockers open until supported evidence resolves them.

### UC-M01.07-C020 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for supported language profiles; label unexecuted checks as untested.

- [ ] **UC-M01.07-C020-T01 · Evidence inventory:** List the “Supported language profiles” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M01.07-C020-T02 · Artifact references:** Record the exact “Supported language profiles” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M01.07-C020-T03 · Fixture references:** Attach the “Supported language profiles” fixture IDs, input identities and oracle definition; preserve the source counterexample “A compiler silently ignores an unsupported construct” as a distinct evidence case.
- [ ] **UC-M01.07-C020-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Supported language profiles”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M01.07-C020-T05 · Environment record:** Record the actual “Supported language profiles” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M01.07-C020-T06 · Expected versus observed:** Pair every “Supported language profiles” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M01.07-C020-T07 · Failure and limit records:** Attach “Supported language profiles” change/failure and bounds evidence where required; include uncovered “Language feature count and input program size” and unresolved violations of “Unsupported language constructs cause an explicit refusal”.
- [ ] **UC-M01.07-C020-T08 · Evidence hygiene:** Check the “Supported language profiles” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M01.07-C020-T09 · Reproduction review:** Have the “Supported language profiles” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M01.07-C020-T10 · Acceptance linkage:** Link the “Supported language profiles” evidence to its parent and UC-M01.07 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 03. Observable semantics

**Source delivery:** Specify observable outputs, state effects and failure behavior for the first workload.

**Source invariant:** Correctness is judged against defined application behavior.

**Source negative case:** A program emits a valid witness but incorrect application output.

**Source bounded quantities:** Output bytes and semantic observation window.

### UC-M01.07-C021 · Contract

**Original checklist item:** Specify the scope and representation of observable semantics; identify its producer, consumer, authority assumptions and explicitly unsupported cases.

- [ ] **UC-M01.07-C021-T01 · Scope statement:** Draft a scope note for “Observable semantics” within Application semantics versus witness contract; separate required model statements, explicit exclusions and unresolved design decisions.
- [ ] **UC-M01.07-C021-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Observable semantics”; record each producer, representation and missing-value meaning.
- [ ] **UC-M01.07-C021-T03 · Output inventory:** List the outputs of “Observable semantics” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M01.07-C021-T04 · Field dictionary:** Create a field-and-term dictionary for “Observable semantics”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M01.07-C021-T05 · Prerequisite contract:** Map “Observable semantics” to the source component prerequisites (UC-M01.02, UC-M01.06); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M01.07-C021-T06 · Authority map:** Identify who may produce, change and consume “Observable semantics”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M01.07-C021-T07 · Invariant clause:** Add a normative clause for “Observable semantics” that preserves “Correctness is judged against defined application behavior”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M01.07-C021-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Observable semantics”; include the source counterexample “A program emits a valid witness but incorrect application output” and the intended safe disposition.
- [ ] **UC-M01.07-C021-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Output bytes and semantic observation window” in the “Observable semantics” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M01.07-C021-T10 · Contract review:** Review the “Observable semantics” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M01.07-C022 · Delivery

**Original checklist item:** Specify observable outputs, state effects and failure behavior for the first workload.

- [ ] **UC-M01.07-C022-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Observable semantics”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M01.07-C022-T02 · Change plan:** Break the source delivery for “Observable semantics” into concrete edit targets and reviewable outputs; keep the UC-M01.07 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M01.07-C022-T03 · Core artifact:** Create the “Observable semantics” model, schema or inventory that realizes this source instruction: Specify observable outputs, state effects and failure behavior for the first workload.
- [ ] **UC-M01.07-C022-T04 · Concrete realization:** Populate “Observable semantics” with one concrete worked case; map every required entity or field to its source and flag any unmapped entry.
- [ ] **UC-M01.07-C022-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Observable semantics” needed to preserve “Correctness is judged against defined application behavior”; record an enforcement gap where only a model exists.
- [ ] **UC-M01.07-C022-T06 · Dependency connection:** Connect the “Observable semantics” specification to language admission, translation outputs and application-result oracles; record code coverage separately where the design is not yet enforced.
- [ ] **UC-M01.07-C022-T07 · Resource behavior:** Account for “Output bytes and semantic observation window” in “Observable semantics”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M01.07-C022-T08 · Delivery check:** Walk the populated “Observable semantics” model through a valid example and the source counterexample “A program emits a valid witness but incorrect application output”; record corrections and unresolved enforcement gaps.
- [ ] **UC-M01.07-C022-T09 · Patch review:** Review the “Observable semantics” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M01.07-C022-T10 · Delivery handoff:** Publish the “Observable semantics” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M01.07-C023 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Correctness is judged against defined application behavior. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M01.07-C023-T01 · Named property:** Create a stable property/check name under this parent for “Observable semantics”; copy its required invariant exactly: “Correctness is judged against defined application behavior”.
- [ ] **UC-M01.07-C023-T02 · Observable terms:** Define each term in the “Observable semantics” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M01.07-C023-T03 · Precondition set:** List the preconditions under which “Correctness is judged against defined application behavior” must hold for “Observable semantics”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M01.07-C023-T04 · Transition coverage:** Map the “Observable semantics” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M01.07-C023-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Observable semantics”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M01.07-C023-T06 · Satisfying fixture:** Create a concrete “Observable semantics” case that satisfies “Correctness is judged against defined application behavior”; record its expected observation before running the assertion or review.
- [ ] **UC-M01.07-C023-T07 · Violating fixture:** Create the source counterexample “A program emits a valid witness but incorrect application output” for “Observable semantics”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M01.07-C023-T08 · Enforcement evidence:** Exercise the “Observable semantics” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M01.07-C023-T09 · Regression linkage:** Link the “Observable semantics” property to changes in language admission, translation outputs and application-result oracles; record which dependency or contract changes require rerunning it.
- [ ] **UC-M01.07-C023-T10 · Property disposition:** Compare the satisfying and violating “Observable semantics” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M01.07-C024 · Integration

**Original checklist item:** Integrate observable semantics with language admission, translation outputs and application-result oracles; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M01.07-C024-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Observable semantics” across language admission, translation outputs and application-result oracles; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M01.07-C024-T02 · Field mapping:** Map every “Observable semantics” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M01.07-C024-T03 · Prerequisite identities:** Record the actual prerequisites for “Observable semantics” (source dependency list: UC-M01.02, UC-M01.06); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M01.07-C024-T04 · Ownership agreement:** Specify who owns “Observable semantics” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M01.07-C024-T05 · Handoff implementation:** Connect “Observable semantics” through the mapped seam using the real adapter or explicit specification reference; preserve “Correctness is judged against defined application behavior” across the handoff.
- [ ] **UC-M01.07-C024-T06 · Absent-input case:** Omit one required “Observable semantics” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M01.07-C024-T07 · Stale-input case:** Supply an outdated “Observable semantics” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M01.07-C024-T08 · Incompatible-input case:** Supply an incompatible “Observable semantics” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M01.07-C024-T09 · Valid integration trace:** Run a valid “Observable semantics” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M01.07-C024-T10 · Seam review:** Reconcile the “Observable semantics” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M01.07-C025 · Valid-case test

**Original checklist item:** Construct a valid worked example for observable semantics; evaluate it against predeclared expected decisions and, where enforcement exists, run the corresponding conformance fixture.

- [ ] **UC-M01.07-C025-T01 · Valid fixture choice:** Select one concrete valid worked example for “Observable semantics”; enumerate the model inputs and the expected review decision before evaluating it.
- [ ] **UC-M01.07-C025-T02 · Expected-result oracle:** Specify the “Observable semantics” expected result independently of the implementation output; include the property “Correctness is judged against defined application behavior” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M01.07-C025-T03 · Fixture material:** Create the concrete “Observable semantics” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M01.07-C025-T04 · Target preparation:** Prepare the “Observable semantics” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M01.07-C025-T05 · Initial-state record:** Record the initial “Observable semantics” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M01.07-C025-T06 · Valid-path execution:** Evaluate the “Observable semantics” example against the reviewed model; where a runtime mechanism exists, run its corresponding fixture and label those observations separately.
- [ ] **UC-M01.07-C025-T07 · Outcome comparison:** Compare every declared “Observable semantics” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M01.07-C025-T08 · State and bounds check:** Inspect the “Observable semantics” ownership/state effects and actual use of “Output bytes and semantic observation window”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M01.07-C025-T09 · Repeatability check:** Repeat the same “Observable semantics” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M01.07-C025-T10 · Positive evidence:** Attach the “Observable semantics” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M01.07-C026 · Negative test

**Original checklist item:** Negative case: A program emits a valid witness but incorrect application output. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M01.07-C026-T01 · Adverse-case definition:** Create a test record for the exact “Observable semantics” source counterexample: “A program emits a valid witness but incorrect application output”; state which precondition or invariant it challenges.
- [ ] **UC-M01.07-C026-T02 · Safe fixture boundary:** Define the contained test boundary for “Observable semantics”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M01.07-C026-T03 · Valid control:** Construct a valid “Observable semantics” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M01.07-C026-T04 · Minimal adverse input:** Derive the “Observable semantics” adverse fixture from the control with the smallest documented change needed to reproduce “A program emits a valid witness but incorrect application output”; retain that change as reproducible data.
- [ ] **UC-M01.07-C026-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Observable semantics”; require “Correctness is judged against defined application behavior” and forbid a false-success verdict.
- [ ] **UC-M01.07-C026-T06 · Adverse execution:** Evaluate the “Observable semantics” adverse case through the actual review/contract gate; where implemented, also observe the runtime refusal and keep the two evidence classes separate.
- [ ] **UC-M01.07-C026-T07 · Effect inspection:** Inspect “Observable semantics” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M01.07-C026-T08 · Refusal versus failure:** Confirm the “Observable semantics” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M01.07-C026-T09 · Reset and retention:** Restore only the disposable “Observable semantics” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M01.07-C026-T10 · Negative regression:** Register the “Observable semantics” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M01.07-C027 · Change / failure test

**Original checklist item:** Exercise observable semantics when a witness still agrees after application behavior or the supported input domain changes; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M01.07-C027-T01 · Scenario record:** Write the “Observable semantics” change/failure scenario exactly as supplied: a witness still agrees after application behavior or the supported input domain changes; identify the property that must remain true: “Correctness is judged against defined application behavior”.
- [ ] **UC-M01.07-C027-T02 · Baseline capture:** Create a known-valid “Observable semantics” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M01.07-C027-T03 · Injection map:** Locate the “Observable semantics” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M01.07-C027-T04 · Disposition oracle:** Define the legal intermediate and final “Observable semantics” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M01.07-C027-T05 · Controlled trigger:** Apply the controlled model-change scenario for “Observable semantics”: a witness still agrees after application behavior or the supported input domain changes; retain the exact before/after declarations. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M01.07-C027-T06 · Intermediate inspection:** Review which “Observable semantics” claims, approvals and evidence references become stale after the change; keep unresolved enforcement gaps visible.
- [ ] **UC-M01.07-C027-T07 · Recovery path:** Revise or explicitly refuse the changed “Observable semantics” model under the documented compatibility policy; re-review affected claims before restoring their approval.
- [ ] **UC-M01.07-C027-T08 · Stale-evidence cleanup:** Invalidate superseded “Observable semantics” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M01.07-C027-T09 · Repeat and compare:** Repeat the selected “Observable semantics” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M01.07-C027-T10 · Failure evidence:** Publish the “Observable semantics” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M01.07-C028 · Bounds

**Original checklist item:** Define completeness and scaling criteria for output bytes and semantic observation window; exercise larger inventories or fixture sets, and report uncovered scope instead of silently excluding it.

- [ ] **UC-M01.07-C028-T01 · Quantity inventory:** Create a measurement inventory for “Observable semantics”: “Output bytes and semantic observation window”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M01.07-C028-T02 · Measurement method:** Choose how to observe each “Observable semantics” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M01.07-C028-T03 · Budget decision:** Select justified coverage and completeness limits for “Observable semantics”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M01.07-C028-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Observable semantics” cases for “Output bytes and semantic observation window”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M01.07-C028-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Observable semantics” limit; preserve “Correctness is judged against defined application behavior”.
- [ ] **UC-M01.07-C028-T06 · Normal measurement:** Run or review the normal “Observable semantics” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M01.07-C028-T07 · At-limit measurement:** Exercise the “Observable semantics” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M01.07-C028-T08 · Over-limit measurement:** Exercise the “Observable semantics” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M01.07-C028-T09 · Uncovered-scope report:** List the “Observable semantics” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M01.07-C028-T10 · Limit evidence:** Publish the selected “Observable semantics” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M01.07-C029 · Diagnostics / review

**Original checklist item:** Record the rationale, unresolved assumptions, enforcement gaps and re-review triggers for observable semantics; make design-only claims visibly distinct from observed behavior.

- [ ] **UC-M01.07-C029-T01 · Review inventory:** List the “Observable semantics” decisions and claims requiring review; distinguish source requirements, implementation observations and engineering assumptions.
- [ ] **UC-M01.07-C029-T02 · Rationale record:** Write the rationale for the selected “Observable semantics” representation or policy; link each choice to the requirement rather than an unexplained preference.
- [ ] **UC-M01.07-C029-T03 · Assumption ledger:** Record unresolved “Observable semantics” assumptions, their owner and what observation or decision would resolve them; do not treat unknowns as approvals.
- [ ] **UC-M01.07-C029-T04 · Boundary map:** Map each “Observable semantics” claim to an actual guard or explicit design/review gate; flag gaps against “Correctness is judged against defined application behavior”.
- [ ] **UC-M01.07-C029-T05 · Counterexample review:** Walk reviewers through the “Observable semantics” counterexample “A program emits a valid witness but incorrect application output”; record whether the model detects it and whether any runtime guard was actually exercised.
- [ ] **UC-M01.07-C029-T06 · Review outcome vocabulary:** Define approved, blocked, superseded and untested review outcomes for “Observable semantics”; ensure the wording cannot be read as runtime enforcement evidence.
- [ ] **UC-M01.07-C029-T07 · Re-review triggers:** List “Observable semantics” invalidation triggers, including the source change scenario: a witness still agrees after application behavior or the supported input domain changes; identify the affected claims and evidence.
- [ ] **UC-M01.07-C029-T08 · Sensitive-data review:** Inspect the “Observable semantics” review record for secrets and unrelated user content; retain nonsecret references sufficient for reproducibility.
- [ ] **UC-M01.07-C029-T09 · Independent reading:** Have the “Observable semantics” record read against the original acceptance criterion and language admission, translation outputs and application-result oracles; record misunderstandings or missing evidence as corrections.
- [ ] **UC-M01.07-C029-T10 · Review disposition:** Publish the “Observable semantics” rationale, versioned review outcome, unresolved gaps and explicit next decision; keep blockers open until supported evidence resolves them.

### UC-M01.07-C030 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for observable semantics; label unexecuted checks as untested.

- [ ] **UC-M01.07-C030-T01 · Evidence inventory:** List the “Observable semantics” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M01.07-C030-T02 · Artifact references:** Record the exact “Observable semantics” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M01.07-C030-T03 · Fixture references:** Attach the “Observable semantics” fixture IDs, input identities and oracle definition; preserve the source counterexample “A program emits a valid witness but incorrect application output” as a distinct evidence case.
- [ ] **UC-M01.07-C030-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Observable semantics”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M01.07-C030-T05 · Environment record:** Record the actual “Observable semantics” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M01.07-C030-T06 · Expected versus observed:** Pair every “Observable semantics” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M01.07-C030-T07 · Failure and limit records:** Attach “Observable semantics” change/failure and bounds evidence where required; include uncovered “Output bytes and semantic observation window” and unresolved violations of “Correctness is judged against defined application behavior”.
- [ ] **UC-M01.07-C030-T08 · Evidence hygiene:** Check the “Observable semantics” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M01.07-C030-T09 · Reproduction review:** Have the “Observable semantics” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M01.07-C030-T10 · Acceptance linkage:** Link the “Observable semantics” evidence to its parent and UC-M01.07 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 04. Input-domain definition

**Source delivery:** Define valid inputs and edge cases for semantic conformance.

**Source invariant:** Tests exercise the supported input domain rather than only trivial examples.

**Source negative case:** An empty input masks an incorrect implementation.

**Source bounded quantities:** Input ranges and fixture generation budget.

### UC-M01.07-C031 · Contract

**Original checklist item:** Specify the scope and representation of input-domain definition; identify its producer, consumer, authority assumptions and explicitly unsupported cases.

- [ ] **UC-M01.07-C031-T01 · Scope statement:** Draft a scope note for “Input-domain definition” within Application semantics versus witness contract; separate required model statements, explicit exclusions and unresolved design decisions.
- [ ] **UC-M01.07-C031-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Input-domain definition”; record each producer, representation and missing-value meaning.
- [ ] **UC-M01.07-C031-T03 · Output inventory:** List the outputs of “Input-domain definition” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M01.07-C031-T04 · Field dictionary:** Create a field-and-term dictionary for “Input-domain definition”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M01.07-C031-T05 · Prerequisite contract:** Map “Input-domain definition” to the source component prerequisites (UC-M01.02, UC-M01.06); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M01.07-C031-T06 · Authority map:** Identify who may produce, change and consume “Input-domain definition”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M01.07-C031-T07 · Invariant clause:** Add a normative clause for “Input-domain definition” that preserves “Tests exercise the supported input domain rather than only trivial examples”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M01.07-C031-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Input-domain definition”; include the source counterexample “An empty input masks an incorrect implementation” and the intended safe disposition.
- [ ] **UC-M01.07-C031-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Input ranges and fixture generation budget” in the “Input-domain definition” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M01.07-C031-T10 · Contract review:** Review the “Input-domain definition” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M01.07-C032 · Delivery

**Original checklist item:** Define valid inputs and edge cases for semantic conformance.

- [ ] **UC-M01.07-C032-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Input-domain definition”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M01.07-C032-T02 · Change plan:** Break the source delivery for “Input-domain definition” into concrete edit targets and reviewable outputs; keep the UC-M01.07 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M01.07-C032-T03 · Core artifact:** Create the “Input-domain definition” model, schema or inventory that realizes this source instruction: Define valid inputs and edge cases for semantic conformance.
- [ ] **UC-M01.07-C032-T04 · Concrete realization:** Populate “Input-domain definition” with one concrete worked case; map every required entity or field to its source and flag any unmapped entry.
- [ ] **UC-M01.07-C032-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Input-domain definition” needed to preserve “Tests exercise the supported input domain rather than only trivial examples”; record an enforcement gap where only a model exists.
- [ ] **UC-M01.07-C032-T06 · Dependency connection:** Connect the “Input-domain definition” specification to language admission, translation outputs and application-result oracles; record code coverage separately where the design is not yet enforced.
- [ ] **UC-M01.07-C032-T07 · Resource behavior:** Account for “Input ranges and fixture generation budget” in “Input-domain definition”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M01.07-C032-T08 · Delivery check:** Walk the populated “Input-domain definition” model through a valid example and the source counterexample “An empty input masks an incorrect implementation”; record corrections and unresolved enforcement gaps.
- [ ] **UC-M01.07-C032-T09 · Patch review:** Review the “Input-domain definition” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M01.07-C032-T10 · Delivery handoff:** Publish the “Input-domain definition” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M01.07-C033 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Tests exercise the supported input domain rather than only trivial examples. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M01.07-C033-T01 · Named property:** Create a stable property/check name under this parent for “Input-domain definition”; copy its required invariant exactly: “Tests exercise the supported input domain rather than only trivial examples”.
- [ ] **UC-M01.07-C033-T02 · Observable terms:** Define each term in the “Input-domain definition” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M01.07-C033-T03 · Precondition set:** List the preconditions under which “Tests exercise the supported input domain rather than only trivial examples” must hold for “Input-domain definition”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M01.07-C033-T04 · Transition coverage:** Map the “Input-domain definition” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M01.07-C033-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Input-domain definition”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M01.07-C033-T06 · Satisfying fixture:** Create a concrete “Input-domain definition” case that satisfies “Tests exercise the supported input domain rather than only trivial examples”; record its expected observation before running the assertion or review.
- [ ] **UC-M01.07-C033-T07 · Violating fixture:** Create the source counterexample “An empty input masks an incorrect implementation” for “Input-domain definition”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M01.07-C033-T08 · Enforcement evidence:** Exercise the “Input-domain definition” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M01.07-C033-T09 · Regression linkage:** Link the “Input-domain definition” property to changes in language admission, translation outputs and application-result oracles; record which dependency or contract changes require rerunning it.
- [ ] **UC-M01.07-C033-T10 · Property disposition:** Compare the satisfying and violating “Input-domain definition” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M01.07-C034 · Integration

**Original checklist item:** Integrate input-domain definition with language admission, translation outputs and application-result oracles; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M01.07-C034-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Input-domain definition” across language admission, translation outputs and application-result oracles; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M01.07-C034-T02 · Field mapping:** Map every “Input-domain definition” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M01.07-C034-T03 · Prerequisite identities:** Record the actual prerequisites for “Input-domain definition” (source dependency list: UC-M01.02, UC-M01.06); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M01.07-C034-T04 · Ownership agreement:** Specify who owns “Input-domain definition” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M01.07-C034-T05 · Handoff implementation:** Connect “Input-domain definition” through the mapped seam using the real adapter or explicit specification reference; preserve “Tests exercise the supported input domain rather than only trivial examples” across the handoff.
- [ ] **UC-M01.07-C034-T06 · Absent-input case:** Omit one required “Input-domain definition” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M01.07-C034-T07 · Stale-input case:** Supply an outdated “Input-domain definition” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M01.07-C034-T08 · Incompatible-input case:** Supply an incompatible “Input-domain definition” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M01.07-C034-T09 · Valid integration trace:** Run a valid “Input-domain definition” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M01.07-C034-T10 · Seam review:** Reconcile the “Input-domain definition” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M01.07-C035 · Valid-case test

**Original checklist item:** Construct a valid worked example for input-domain definition; evaluate it against predeclared expected decisions and, where enforcement exists, run the corresponding conformance fixture.

- [ ] **UC-M01.07-C035-T01 · Valid fixture choice:** Select one concrete valid worked example for “Input-domain definition”; enumerate the model inputs and the expected review decision before evaluating it.
- [ ] **UC-M01.07-C035-T02 · Expected-result oracle:** Specify the “Input-domain definition” expected result independently of the implementation output; include the property “Tests exercise the supported input domain rather than only trivial examples” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M01.07-C035-T03 · Fixture material:** Create the concrete “Input-domain definition” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M01.07-C035-T04 · Target preparation:** Prepare the “Input-domain definition” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M01.07-C035-T05 · Initial-state record:** Record the initial “Input-domain definition” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M01.07-C035-T06 · Valid-path execution:** Evaluate the “Input-domain definition” example against the reviewed model; where a runtime mechanism exists, run its corresponding fixture and label those observations separately.
- [ ] **UC-M01.07-C035-T07 · Outcome comparison:** Compare every declared “Input-domain definition” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M01.07-C035-T08 · State and bounds check:** Inspect the “Input-domain definition” ownership/state effects and actual use of “Input ranges and fixture generation budget”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M01.07-C035-T09 · Repeatability check:** Repeat the same “Input-domain definition” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M01.07-C035-T10 · Positive evidence:** Attach the “Input-domain definition” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M01.07-C036 · Negative test

**Original checklist item:** Negative case: An empty input masks an incorrect implementation. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M01.07-C036-T01 · Adverse-case definition:** Create a test record for the exact “Input-domain definition” source counterexample: “An empty input masks an incorrect implementation”; state which precondition or invariant it challenges.
- [ ] **UC-M01.07-C036-T02 · Safe fixture boundary:** Define the contained test boundary for “Input-domain definition”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M01.07-C036-T03 · Valid control:** Construct a valid “Input-domain definition” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M01.07-C036-T04 · Minimal adverse input:** Derive the “Input-domain definition” adverse fixture from the control with the smallest documented change needed to reproduce “An empty input masks an incorrect implementation”; retain that change as reproducible data.
- [ ] **UC-M01.07-C036-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Input-domain definition”; require “Tests exercise the supported input domain rather than only trivial examples” and forbid a false-success verdict.
- [ ] **UC-M01.07-C036-T06 · Adverse execution:** Evaluate the “Input-domain definition” adverse case through the actual review/contract gate; where implemented, also observe the runtime refusal and keep the two evidence classes separate.
- [ ] **UC-M01.07-C036-T07 · Effect inspection:** Inspect “Input-domain definition” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M01.07-C036-T08 · Refusal versus failure:** Confirm the “Input-domain definition” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M01.07-C036-T09 · Reset and retention:** Restore only the disposable “Input-domain definition” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M01.07-C036-T10 · Negative regression:** Register the “Input-domain definition” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M01.07-C037 · Change / failure test

**Original checklist item:** Exercise input-domain definition when a witness still agrees after application behavior or the supported input domain changes; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M01.07-C037-T01 · Scenario record:** Write the “Input-domain definition” change/failure scenario exactly as supplied: a witness still agrees after application behavior or the supported input domain changes; identify the property that must remain true: “Tests exercise the supported input domain rather than only trivial examples”.
- [ ] **UC-M01.07-C037-T02 · Baseline capture:** Create a known-valid “Input-domain definition” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M01.07-C037-T03 · Injection map:** Locate the “Input-domain definition” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M01.07-C037-T04 · Disposition oracle:** Define the legal intermediate and final “Input-domain definition” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M01.07-C037-T05 · Controlled trigger:** Apply the controlled model-change scenario for “Input-domain definition”: a witness still agrees after application behavior or the supported input domain changes; retain the exact before/after declarations. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M01.07-C037-T06 · Intermediate inspection:** Review which “Input-domain definition” claims, approvals and evidence references become stale after the change; keep unresolved enforcement gaps visible.
- [ ] **UC-M01.07-C037-T07 · Recovery path:** Revise or explicitly refuse the changed “Input-domain definition” model under the documented compatibility policy; re-review affected claims before restoring their approval.
- [ ] **UC-M01.07-C037-T08 · Stale-evidence cleanup:** Invalidate superseded “Input-domain definition” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M01.07-C037-T09 · Repeat and compare:** Repeat the selected “Input-domain definition” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M01.07-C037-T10 · Failure evidence:** Publish the “Input-domain definition” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M01.07-C038 · Bounds

**Original checklist item:** Define completeness and scaling criteria for input ranges and fixture generation budget; exercise larger inventories or fixture sets, and report uncovered scope instead of silently excluding it.

- [ ] **UC-M01.07-C038-T01 · Quantity inventory:** Create a measurement inventory for “Input-domain definition”: “Input ranges and fixture generation budget”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M01.07-C038-T02 · Measurement method:** Choose how to observe each “Input-domain definition” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M01.07-C038-T03 · Budget decision:** Select justified coverage and completeness limits for “Input-domain definition”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M01.07-C038-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Input-domain definition” cases for “Input ranges and fixture generation budget”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M01.07-C038-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Input-domain definition” limit; preserve “Tests exercise the supported input domain rather than only trivial examples”.
- [ ] **UC-M01.07-C038-T06 · Normal measurement:** Run or review the normal “Input-domain definition” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M01.07-C038-T07 · At-limit measurement:** Exercise the “Input-domain definition” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M01.07-C038-T08 · Over-limit measurement:** Exercise the “Input-domain definition” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M01.07-C038-T09 · Uncovered-scope report:** List the “Input-domain definition” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M01.07-C038-T10 · Limit evidence:** Publish the selected “Input-domain definition” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M01.07-C039 · Diagnostics / review

**Original checklist item:** Record the rationale, unresolved assumptions, enforcement gaps and re-review triggers for input-domain definition; make design-only claims visibly distinct from observed behavior.

- [ ] **UC-M01.07-C039-T01 · Review inventory:** List the “Input-domain definition” decisions and claims requiring review; distinguish source requirements, implementation observations and engineering assumptions.
- [ ] **UC-M01.07-C039-T02 · Rationale record:** Write the rationale for the selected “Input-domain definition” representation or policy; link each choice to the requirement rather than an unexplained preference.
- [ ] **UC-M01.07-C039-T03 · Assumption ledger:** Record unresolved “Input-domain definition” assumptions, their owner and what observation or decision would resolve them; do not treat unknowns as approvals.
- [ ] **UC-M01.07-C039-T04 · Boundary map:** Map each “Input-domain definition” claim to an actual guard or explicit design/review gate; flag gaps against “Tests exercise the supported input domain rather than only trivial examples”.
- [ ] **UC-M01.07-C039-T05 · Counterexample review:** Walk reviewers through the “Input-domain definition” counterexample “An empty input masks an incorrect implementation”; record whether the model detects it and whether any runtime guard was actually exercised.
- [ ] **UC-M01.07-C039-T06 · Review outcome vocabulary:** Define approved, blocked, superseded and untested review outcomes for “Input-domain definition”; ensure the wording cannot be read as runtime enforcement evidence.
- [ ] **UC-M01.07-C039-T07 · Re-review triggers:** List “Input-domain definition” invalidation triggers, including the source change scenario: a witness still agrees after application behavior or the supported input domain changes; identify the affected claims and evidence.
- [ ] **UC-M01.07-C039-T08 · Sensitive-data review:** Inspect the “Input-domain definition” review record for secrets and unrelated user content; retain nonsecret references sufficient for reproducibility.
- [ ] **UC-M01.07-C039-T09 · Independent reading:** Have the “Input-domain definition” record read against the original acceptance criterion and language admission, translation outputs and application-result oracles; record misunderstandings or missing evidence as corrections.
- [ ] **UC-M01.07-C039-T10 · Review disposition:** Publish the “Input-domain definition” rationale, versioned review outcome, unresolved gaps and explicit next decision; keep blockers open until supported evidence resolves them.

### UC-M01.07-C040 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for input-domain definition; label unexecuted checks as untested.

- [ ] **UC-M01.07-C040-T01 · Evidence inventory:** List the “Input-domain definition” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M01.07-C040-T02 · Artifact references:** Record the exact “Input-domain definition” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M01.07-C040-T03 · Fixture references:** Attach the “Input-domain definition” fixture IDs, input identities and oracle definition; preserve the source counterexample “An empty input masks an incorrect implementation” as a distinct evidence case.
- [ ] **UC-M01.07-C040-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Input-domain definition”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M01.07-C040-T05 · Environment record:** Record the actual “Input-domain definition” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M01.07-C040-T06 · Expected versus observed:** Pair every “Input-domain definition” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M01.07-C040-T07 · Failure and limit records:** Attach “Input-domain definition” change/failure and bounds evidence where required; include uncovered “Input ranges and fixture generation budget” and unresolved violations of “Tests exercise the supported input domain rather than only trivial examples”.
- [ ] **UC-M01.07-C040-T08 · Evidence hygiene:** Check the “Input-domain definition” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M01.07-C040-T09 · Reproduction review:** Have the “Input-domain definition” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M01.07-C040-T10 · Acceptance linkage:** Link the “Input-domain definition” evidence to its parent and UC-M01.07 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 05. Reference oracle

**Source delivery:** Select an independently reviewable expected-result oracle for the chosen workload.

**Source invariant:** The implementation does not generate its own unquestioned expected result.

**Source negative case:** A buggy compiler supplies both actual and expected outputs.

**Source bounded quantities:** Oracle runtime and reference dataset size.

### UC-M01.07-C041 · Contract

**Original checklist item:** Specify the scope and representation of reference oracle; identify its producer, consumer, authority assumptions and explicitly unsupported cases.

- [ ] **UC-M01.07-C041-T01 · Scope statement:** Draft a scope note for “Reference oracle” within Application semantics versus witness contract; separate required model statements, explicit exclusions and unresolved design decisions.
- [ ] **UC-M01.07-C041-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Reference oracle”; record each producer, representation and missing-value meaning.
- [ ] **UC-M01.07-C041-T03 · Output inventory:** List the outputs of “Reference oracle” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M01.07-C041-T04 · Field dictionary:** Create a field-and-term dictionary for “Reference oracle”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M01.07-C041-T05 · Prerequisite contract:** Map “Reference oracle” to the source component prerequisites (UC-M01.02, UC-M01.06); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M01.07-C041-T06 · Authority map:** Identify who may produce, change and consume “Reference oracle”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M01.07-C041-T07 · Invariant clause:** Add a normative clause for “Reference oracle” that preserves “The implementation does not generate its own unquestioned expected result”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M01.07-C041-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Reference oracle”; include the source counterexample “A buggy compiler supplies both actual and expected outputs” and the intended safe disposition.
- [ ] **UC-M01.07-C041-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Oracle runtime and reference dataset size” in the “Reference oracle” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M01.07-C041-T10 · Contract review:** Review the “Reference oracle” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M01.07-C042 · Delivery

**Original checklist item:** Select an independently reviewable expected-result oracle for the chosen workload.

- [ ] **UC-M01.07-C042-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Reference oracle”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M01.07-C042-T02 · Change plan:** Break the source delivery for “Reference oracle” into concrete edit targets and reviewable outputs; keep the UC-M01.07 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M01.07-C042-T03 · Core artifact:** Prepare the “Reference oracle” decision record for this source instruction: Select an independently reviewable expected-result oracle for the chosen workload.
- [ ] **UC-M01.07-C042-T04 · Concrete realization:** Evaluate the “Reference oracle” choice against its declared constraints; record the exact selected target/configuration and rejected alternatives, leaving unverified compatibility as a blocker.
- [ ] **UC-M01.07-C042-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Reference oracle” needed to preserve “The implementation does not generate its own unquestioned expected result”; record an enforcement gap where only a model exists.
- [ ] **UC-M01.07-C042-T06 · Dependency connection:** Connect the “Reference oracle” specification to language admission, translation outputs and application-result oracles; record code coverage separately where the design is not yet enforced.
- [ ] **UC-M01.07-C042-T07 · Resource behavior:** Account for “Oracle runtime and reference dataset size” in “Reference oracle”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M01.07-C042-T08 · Delivery check:** Walk the populated “Reference oracle” model through a valid example and the source counterexample “A buggy compiler supplies both actual and expected outputs”; record corrections and unresolved enforcement gaps.
- [ ] **UC-M01.07-C042-T09 · Patch review:** Review the “Reference oracle” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M01.07-C042-T10 · Delivery handoff:** Publish the “Reference oracle” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M01.07-C043 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: The implementation does not generate its own unquestioned expected result. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M01.07-C043-T01 · Named property:** Create a stable property/check name under this parent for “Reference oracle”; copy its required invariant exactly: “The implementation does not generate its own unquestioned expected result”.
- [ ] **UC-M01.07-C043-T02 · Observable terms:** Define each term in the “Reference oracle” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M01.07-C043-T03 · Precondition set:** List the preconditions under which “The implementation does not generate its own unquestioned expected result” must hold for “Reference oracle”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M01.07-C043-T04 · Transition coverage:** Map the “Reference oracle” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M01.07-C043-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Reference oracle”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M01.07-C043-T06 · Satisfying fixture:** Create a concrete “Reference oracle” case that satisfies “The implementation does not generate its own unquestioned expected result”; record its expected observation before running the assertion or review.
- [ ] **UC-M01.07-C043-T07 · Violating fixture:** Create the source counterexample “A buggy compiler supplies both actual and expected outputs” for “Reference oracle”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M01.07-C043-T08 · Enforcement evidence:** Exercise the “Reference oracle” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M01.07-C043-T09 · Regression linkage:** Link the “Reference oracle” property to changes in language admission, translation outputs and application-result oracles; record which dependency or contract changes require rerunning it.
- [ ] **UC-M01.07-C043-T10 · Property disposition:** Compare the satisfying and violating “Reference oracle” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M01.07-C044 · Integration

**Original checklist item:** Integrate reference oracle with language admission, translation outputs and application-result oracles; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M01.07-C044-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Reference oracle” across language admission, translation outputs and application-result oracles; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M01.07-C044-T02 · Field mapping:** Map every “Reference oracle” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M01.07-C044-T03 · Prerequisite identities:** Record the actual prerequisites for “Reference oracle” (source dependency list: UC-M01.02, UC-M01.06); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M01.07-C044-T04 · Ownership agreement:** Specify who owns “Reference oracle” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M01.07-C044-T05 · Handoff implementation:** Connect “Reference oracle” through the mapped seam using the real adapter or explicit specification reference; preserve “The implementation does not generate its own unquestioned expected result” across the handoff.
- [ ] **UC-M01.07-C044-T06 · Absent-input case:** Omit one required “Reference oracle” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M01.07-C044-T07 · Stale-input case:** Supply an outdated “Reference oracle” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M01.07-C044-T08 · Incompatible-input case:** Supply an incompatible “Reference oracle” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M01.07-C044-T09 · Valid integration trace:** Run a valid “Reference oracle” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M01.07-C044-T10 · Seam review:** Reconcile the “Reference oracle” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M01.07-C045 · Valid-case test

**Original checklist item:** Construct a valid worked example for reference oracle; evaluate it against predeclared expected decisions and, where enforcement exists, run the corresponding conformance fixture.

- [ ] **UC-M01.07-C045-T01 · Valid fixture choice:** Select one concrete valid worked example for “Reference oracle”; enumerate the model inputs and the expected review decision before evaluating it.
- [ ] **UC-M01.07-C045-T02 · Expected-result oracle:** Specify the “Reference oracle” expected result independently of the implementation output; include the property “The implementation does not generate its own unquestioned expected result” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M01.07-C045-T03 · Fixture material:** Create the concrete “Reference oracle” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M01.07-C045-T04 · Target preparation:** Prepare the “Reference oracle” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M01.07-C045-T05 · Initial-state record:** Record the initial “Reference oracle” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M01.07-C045-T06 · Valid-path execution:** Evaluate the “Reference oracle” example against the reviewed model; where a runtime mechanism exists, run its corresponding fixture and label those observations separately.
- [ ] **UC-M01.07-C045-T07 · Outcome comparison:** Compare every declared “Reference oracle” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M01.07-C045-T08 · State and bounds check:** Inspect the “Reference oracle” ownership/state effects and actual use of “Oracle runtime and reference dataset size”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M01.07-C045-T09 · Repeatability check:** Repeat the same “Reference oracle” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M01.07-C045-T10 · Positive evidence:** Attach the “Reference oracle” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M01.07-C046 · Negative test

**Original checklist item:** Negative case: A buggy compiler supplies both actual and expected outputs. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M01.07-C046-T01 · Adverse-case definition:** Create a test record for the exact “Reference oracle” source counterexample: “A buggy compiler supplies both actual and expected outputs”; state which precondition or invariant it challenges.
- [ ] **UC-M01.07-C046-T02 · Safe fixture boundary:** Define the contained test boundary for “Reference oracle”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M01.07-C046-T03 · Valid control:** Construct a valid “Reference oracle” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M01.07-C046-T04 · Minimal adverse input:** Derive the “Reference oracle” adverse fixture from the control with the smallest documented change needed to reproduce “A buggy compiler supplies both actual and expected outputs”; retain that change as reproducible data.
- [ ] **UC-M01.07-C046-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Reference oracle”; require “The implementation does not generate its own unquestioned expected result” and forbid a false-success verdict.
- [ ] **UC-M01.07-C046-T06 · Adverse execution:** Evaluate the “Reference oracle” adverse case through the actual review/contract gate; where implemented, also observe the runtime refusal and keep the two evidence classes separate.
- [ ] **UC-M01.07-C046-T07 · Effect inspection:** Inspect “Reference oracle” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M01.07-C046-T08 · Refusal versus failure:** Confirm the “Reference oracle” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M01.07-C046-T09 · Reset and retention:** Restore only the disposable “Reference oracle” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M01.07-C046-T10 · Negative regression:** Register the “Reference oracle” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M01.07-C047 · Change / failure test

**Original checklist item:** Exercise reference oracle when a witness still agrees after application behavior or the supported input domain changes; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M01.07-C047-T01 · Scenario record:** Write the “Reference oracle” change/failure scenario exactly as supplied: a witness still agrees after application behavior or the supported input domain changes; identify the property that must remain true: “The implementation does not generate its own unquestioned expected result”.
- [ ] **UC-M01.07-C047-T02 · Baseline capture:** Create a known-valid “Reference oracle” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M01.07-C047-T03 · Injection map:** Locate the “Reference oracle” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M01.07-C047-T04 · Disposition oracle:** Define the legal intermediate and final “Reference oracle” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M01.07-C047-T05 · Controlled trigger:** Apply the controlled model-change scenario for “Reference oracle”: a witness still agrees after application behavior or the supported input domain changes; retain the exact before/after declarations. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M01.07-C047-T06 · Intermediate inspection:** Review which “Reference oracle” claims, approvals and evidence references become stale after the change; keep unresolved enforcement gaps visible.
- [ ] **UC-M01.07-C047-T07 · Recovery path:** Revise or explicitly refuse the changed “Reference oracle” model under the documented compatibility policy; re-review affected claims before restoring their approval.
- [ ] **UC-M01.07-C047-T08 · Stale-evidence cleanup:** Invalidate superseded “Reference oracle” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M01.07-C047-T09 · Repeat and compare:** Repeat the selected “Reference oracle” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M01.07-C047-T10 · Failure evidence:** Publish the “Reference oracle” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M01.07-C048 · Bounds

**Original checklist item:** Define completeness and scaling criteria for oracle runtime and reference dataset size; exercise larger inventories or fixture sets, and report uncovered scope instead of silently excluding it.

- [ ] **UC-M01.07-C048-T01 · Quantity inventory:** Create a measurement inventory for “Reference oracle”: “Oracle runtime and reference dataset size”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M01.07-C048-T02 · Measurement method:** Choose how to observe each “Reference oracle” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M01.07-C048-T03 · Budget decision:** Select justified coverage and completeness limits for “Reference oracle”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M01.07-C048-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Reference oracle” cases for “Oracle runtime and reference dataset size”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M01.07-C048-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Reference oracle” limit; preserve “The implementation does not generate its own unquestioned expected result”.
- [ ] **UC-M01.07-C048-T06 · Normal measurement:** Run or review the normal “Reference oracle” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M01.07-C048-T07 · At-limit measurement:** Exercise the “Reference oracle” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M01.07-C048-T08 · Over-limit measurement:** Exercise the “Reference oracle” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M01.07-C048-T09 · Uncovered-scope report:** List the “Reference oracle” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M01.07-C048-T10 · Limit evidence:** Publish the selected “Reference oracle” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M01.07-C049 · Diagnostics / review

**Original checklist item:** Record the rationale, unresolved assumptions, enforcement gaps and re-review triggers for reference oracle; make design-only claims visibly distinct from observed behavior.

- [ ] **UC-M01.07-C049-T01 · Review inventory:** List the “Reference oracle” decisions and claims requiring review; distinguish source requirements, implementation observations and engineering assumptions.
- [ ] **UC-M01.07-C049-T02 · Rationale record:** Write the rationale for the selected “Reference oracle” representation or policy; link each choice to the requirement rather than an unexplained preference.
- [ ] **UC-M01.07-C049-T03 · Assumption ledger:** Record unresolved “Reference oracle” assumptions, their owner and what observation or decision would resolve them; do not treat unknowns as approvals.
- [ ] **UC-M01.07-C049-T04 · Boundary map:** Map each “Reference oracle” claim to an actual guard or explicit design/review gate; flag gaps against “The implementation does not generate its own unquestioned expected result”.
- [ ] **UC-M01.07-C049-T05 · Counterexample review:** Walk reviewers through the “Reference oracle” counterexample “A buggy compiler supplies both actual and expected outputs”; record whether the model detects it and whether any runtime guard was actually exercised.
- [ ] **UC-M01.07-C049-T06 · Review outcome vocabulary:** Define approved, blocked, superseded and untested review outcomes for “Reference oracle”; ensure the wording cannot be read as runtime enforcement evidence.
- [ ] **UC-M01.07-C049-T07 · Re-review triggers:** List “Reference oracle” invalidation triggers, including the source change scenario: a witness still agrees after application behavior or the supported input domain changes; identify the affected claims and evidence.
- [ ] **UC-M01.07-C049-T08 · Sensitive-data review:** Inspect the “Reference oracle” review record for secrets and unrelated user content; retain nonsecret references sufficient for reproducibility.
- [ ] **UC-M01.07-C049-T09 · Independent reading:** Have the “Reference oracle” record read against the original acceptance criterion and language admission, translation outputs and application-result oracles; record misunderstandings or missing evidence as corrections.
- [ ] **UC-M01.07-C049-T10 · Review disposition:** Publish the “Reference oracle” rationale, versioned review outcome, unresolved gaps and explicit next decision; keep blockers open until supported evidence resolves them.

### UC-M01.07-C050 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for reference oracle; label unexecuted checks as untested.

- [ ] **UC-M01.07-C050-T01 · Evidence inventory:** List the “Reference oracle” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M01.07-C050-T02 · Artifact references:** Record the exact “Reference oracle” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M01.07-C050-T03 · Fixture references:** Attach the “Reference oracle” fixture IDs, input identities and oracle definition; preserve the source counterexample “A buggy compiler supplies both actual and expected outputs” as a distinct evidence case.
- [ ] **UC-M01.07-C050-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Reference oracle”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M01.07-C050-T05 · Environment record:** Record the actual “Reference oracle” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M01.07-C050-T06 · Expected versus observed:** Pair every “Reference oracle” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M01.07-C050-T07 · Failure and limit records:** Attach “Reference oracle” change/failure and bounds evidence where required; include uncovered “Oracle runtime and reference dataset size” and unresolved violations of “The implementation does not generate its own unquestioned expected result”.
- [ ] **UC-M01.07-C050-T08 · Evidence hygiene:** Check the “Reference oracle” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M01.07-C050-T09 · Reproduction review:** Have the “Reference oracle” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M01.07-C050-T10 · Acceptance linkage:** Link the “Reference oracle” evidence to its parent and UC-M01.07 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 06. Arithmetic semantics

**Source delivery:** Document overflow, signedness and rounding behavior across supported execution paths.

**Source invariant:** Lowering preserves the selected arithmetic semantics.

**Source negative case:** A boundary integer changes meaning between source and native execution.

**Source bounded quantities:** Integer widths and arithmetic test combinations.

### UC-M01.07-C051 · Contract

**Original checklist item:** Specify the scope and representation of arithmetic semantics; identify its producer, consumer, authority assumptions and explicitly unsupported cases.

- [ ] **UC-M01.07-C051-T01 · Scope statement:** Draft a scope note for “Arithmetic semantics” within Application semantics versus witness contract; separate required model statements, explicit exclusions and unresolved design decisions.
- [ ] **UC-M01.07-C051-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Arithmetic semantics”; record each producer, representation and missing-value meaning.
- [ ] **UC-M01.07-C051-T03 · Output inventory:** List the outputs of “Arithmetic semantics” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M01.07-C051-T04 · Field dictionary:** Create a field-and-term dictionary for “Arithmetic semantics”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M01.07-C051-T05 · Prerequisite contract:** Map “Arithmetic semantics” to the source component prerequisites (UC-M01.02, UC-M01.06); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M01.07-C051-T06 · Authority map:** Identify who may produce, change and consume “Arithmetic semantics”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M01.07-C051-T07 · Invariant clause:** Add a normative clause for “Arithmetic semantics” that preserves “Lowering preserves the selected arithmetic semantics”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M01.07-C051-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Arithmetic semantics”; include the source counterexample “A boundary integer changes meaning between source and native execution” and the intended safe disposition.
- [ ] **UC-M01.07-C051-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Integer widths and arithmetic test combinations” in the “Arithmetic semantics” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M01.07-C051-T10 · Contract review:** Review the “Arithmetic semantics” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M01.07-C052 · Delivery

**Original checklist item:** Document overflow, signedness and rounding behavior across supported execution paths.

- [ ] **UC-M01.07-C052-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Arithmetic semantics”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M01.07-C052-T02 · Change plan:** Break the source delivery for “Arithmetic semantics” into concrete edit targets and reviewable outputs; keep the UC-M01.07 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M01.07-C052-T03 · Core artifact:** Create the “Arithmetic semantics” model, schema or inventory that realizes this source instruction: Document overflow, signedness and rounding behavior across supported execution paths.
- [ ] **UC-M01.07-C052-T04 · Concrete realization:** Populate “Arithmetic semantics” with one concrete worked case; map every required entity or field to its source and flag any unmapped entry.
- [ ] **UC-M01.07-C052-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Arithmetic semantics” needed to preserve “Lowering preserves the selected arithmetic semantics”; record an enforcement gap where only a model exists.
- [ ] **UC-M01.07-C052-T06 · Dependency connection:** Connect the “Arithmetic semantics” specification to language admission, translation outputs and application-result oracles; record code coverage separately where the design is not yet enforced.
- [ ] **UC-M01.07-C052-T07 · Resource behavior:** Account for “Integer widths and arithmetic test combinations” in “Arithmetic semantics”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M01.07-C052-T08 · Delivery check:** Walk the populated “Arithmetic semantics” model through a valid example and the source counterexample “A boundary integer changes meaning between source and native execution”; record corrections and unresolved enforcement gaps.
- [ ] **UC-M01.07-C052-T09 · Patch review:** Review the “Arithmetic semantics” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M01.07-C052-T10 · Delivery handoff:** Publish the “Arithmetic semantics” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M01.07-C053 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Lowering preserves the selected arithmetic semantics. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M01.07-C053-T01 · Named property:** Create a stable property/check name under this parent for “Arithmetic semantics”; copy its required invariant exactly: “Lowering preserves the selected arithmetic semantics”.
- [ ] **UC-M01.07-C053-T02 · Observable terms:** Define each term in the “Arithmetic semantics” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M01.07-C053-T03 · Precondition set:** List the preconditions under which “Lowering preserves the selected arithmetic semantics” must hold for “Arithmetic semantics”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M01.07-C053-T04 · Transition coverage:** Map the “Arithmetic semantics” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M01.07-C053-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Arithmetic semantics”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M01.07-C053-T06 · Satisfying fixture:** Create a concrete “Arithmetic semantics” case that satisfies “Lowering preserves the selected arithmetic semantics”; record its expected observation before running the assertion or review.
- [ ] **UC-M01.07-C053-T07 · Violating fixture:** Create the source counterexample “A boundary integer changes meaning between source and native execution” for “Arithmetic semantics”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M01.07-C053-T08 · Enforcement evidence:** Exercise the “Arithmetic semantics” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M01.07-C053-T09 · Regression linkage:** Link the “Arithmetic semantics” property to changes in language admission, translation outputs and application-result oracles; record which dependency or contract changes require rerunning it.
- [ ] **UC-M01.07-C053-T10 · Property disposition:** Compare the satisfying and violating “Arithmetic semantics” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M01.07-C054 · Integration

**Original checklist item:** Integrate arithmetic semantics with language admission, translation outputs and application-result oracles; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M01.07-C054-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Arithmetic semantics” across language admission, translation outputs and application-result oracles; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M01.07-C054-T02 · Field mapping:** Map every “Arithmetic semantics” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M01.07-C054-T03 · Prerequisite identities:** Record the actual prerequisites for “Arithmetic semantics” (source dependency list: UC-M01.02, UC-M01.06); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M01.07-C054-T04 · Ownership agreement:** Specify who owns “Arithmetic semantics” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M01.07-C054-T05 · Handoff implementation:** Connect “Arithmetic semantics” through the mapped seam using the real adapter or explicit specification reference; preserve “Lowering preserves the selected arithmetic semantics” across the handoff.
- [ ] **UC-M01.07-C054-T06 · Absent-input case:** Omit one required “Arithmetic semantics” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M01.07-C054-T07 · Stale-input case:** Supply an outdated “Arithmetic semantics” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M01.07-C054-T08 · Incompatible-input case:** Supply an incompatible “Arithmetic semantics” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M01.07-C054-T09 · Valid integration trace:** Run a valid “Arithmetic semantics” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M01.07-C054-T10 · Seam review:** Reconcile the “Arithmetic semantics” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M01.07-C055 · Valid-case test

**Original checklist item:** Construct a valid worked example for arithmetic semantics; evaluate it against predeclared expected decisions and, where enforcement exists, run the corresponding conformance fixture.

- [ ] **UC-M01.07-C055-T01 · Valid fixture choice:** Select one concrete valid worked example for “Arithmetic semantics”; enumerate the model inputs and the expected review decision before evaluating it.
- [ ] **UC-M01.07-C055-T02 · Expected-result oracle:** Specify the “Arithmetic semantics” expected result independently of the implementation output; include the property “Lowering preserves the selected arithmetic semantics” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M01.07-C055-T03 · Fixture material:** Create the concrete “Arithmetic semantics” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M01.07-C055-T04 · Target preparation:** Prepare the “Arithmetic semantics” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M01.07-C055-T05 · Initial-state record:** Record the initial “Arithmetic semantics” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M01.07-C055-T06 · Valid-path execution:** Evaluate the “Arithmetic semantics” example against the reviewed model; where a runtime mechanism exists, run its corresponding fixture and label those observations separately.
- [ ] **UC-M01.07-C055-T07 · Outcome comparison:** Compare every declared “Arithmetic semantics” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M01.07-C055-T08 · State and bounds check:** Inspect the “Arithmetic semantics” ownership/state effects and actual use of “Integer widths and arithmetic test combinations”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M01.07-C055-T09 · Repeatability check:** Repeat the same “Arithmetic semantics” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M01.07-C055-T10 · Positive evidence:** Attach the “Arithmetic semantics” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M01.07-C056 · Negative test

**Original checklist item:** Negative case: A boundary integer changes meaning between source and native execution. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M01.07-C056-T01 · Adverse-case definition:** Create a test record for the exact “Arithmetic semantics” source counterexample: “A boundary integer changes meaning between source and native execution”; state which precondition or invariant it challenges.
- [ ] **UC-M01.07-C056-T02 · Safe fixture boundary:** Define the contained test boundary for “Arithmetic semantics”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M01.07-C056-T03 · Valid control:** Construct a valid “Arithmetic semantics” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M01.07-C056-T04 · Minimal adverse input:** Derive the “Arithmetic semantics” adverse fixture from the control with the smallest documented change needed to reproduce “A boundary integer changes meaning between source and native execution”; retain that change as reproducible data.
- [ ] **UC-M01.07-C056-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Arithmetic semantics”; require “Lowering preserves the selected arithmetic semantics” and forbid a false-success verdict.
- [ ] **UC-M01.07-C056-T06 · Adverse execution:** Evaluate the “Arithmetic semantics” adverse case through the actual review/contract gate; where implemented, also observe the runtime refusal and keep the two evidence classes separate.
- [ ] **UC-M01.07-C056-T07 · Effect inspection:** Inspect “Arithmetic semantics” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M01.07-C056-T08 · Refusal versus failure:** Confirm the “Arithmetic semantics” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M01.07-C056-T09 · Reset and retention:** Restore only the disposable “Arithmetic semantics” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M01.07-C056-T10 · Negative regression:** Register the “Arithmetic semantics” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M01.07-C057 · Change / failure test

**Original checklist item:** Exercise arithmetic semantics when a witness still agrees after application behavior or the supported input domain changes; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M01.07-C057-T01 · Scenario record:** Write the “Arithmetic semantics” change/failure scenario exactly as supplied: a witness still agrees after application behavior or the supported input domain changes; identify the property that must remain true: “Lowering preserves the selected arithmetic semantics”.
- [ ] **UC-M01.07-C057-T02 · Baseline capture:** Create a known-valid “Arithmetic semantics” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M01.07-C057-T03 · Injection map:** Locate the “Arithmetic semantics” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M01.07-C057-T04 · Disposition oracle:** Define the legal intermediate and final “Arithmetic semantics” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M01.07-C057-T05 · Controlled trigger:** Apply the controlled model-change scenario for “Arithmetic semantics”: a witness still agrees after application behavior or the supported input domain changes; retain the exact before/after declarations. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M01.07-C057-T06 · Intermediate inspection:** Review which “Arithmetic semantics” claims, approvals and evidence references become stale after the change; keep unresolved enforcement gaps visible.
- [ ] **UC-M01.07-C057-T07 · Recovery path:** Revise or explicitly refuse the changed “Arithmetic semantics” model under the documented compatibility policy; re-review affected claims before restoring their approval.
- [ ] **UC-M01.07-C057-T08 · Stale-evidence cleanup:** Invalidate superseded “Arithmetic semantics” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M01.07-C057-T09 · Repeat and compare:** Repeat the selected “Arithmetic semantics” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M01.07-C057-T10 · Failure evidence:** Publish the “Arithmetic semantics” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M01.07-C058 · Bounds

**Original checklist item:** Define completeness and scaling criteria for integer widths and arithmetic test combinations; exercise larger inventories or fixture sets, and report uncovered scope instead of silently excluding it.

- [ ] **UC-M01.07-C058-T01 · Quantity inventory:** Create a measurement inventory for “Arithmetic semantics”: “Integer widths and arithmetic test combinations”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M01.07-C058-T02 · Measurement method:** Choose how to observe each “Arithmetic semantics” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M01.07-C058-T03 · Budget decision:** Select justified coverage and completeness limits for “Arithmetic semantics”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M01.07-C058-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Arithmetic semantics” cases for “Integer widths and arithmetic test combinations”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M01.07-C058-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Arithmetic semantics” limit; preserve “Lowering preserves the selected arithmetic semantics”.
- [ ] **UC-M01.07-C058-T06 · Normal measurement:** Run or review the normal “Arithmetic semantics” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M01.07-C058-T07 · At-limit measurement:** Exercise the “Arithmetic semantics” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M01.07-C058-T08 · Over-limit measurement:** Exercise the “Arithmetic semantics” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M01.07-C058-T09 · Uncovered-scope report:** List the “Arithmetic semantics” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M01.07-C058-T10 · Limit evidence:** Publish the selected “Arithmetic semantics” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M01.07-C059 · Diagnostics / review

**Original checklist item:** Record the rationale, unresolved assumptions, enforcement gaps and re-review triggers for arithmetic semantics; make design-only claims visibly distinct from observed behavior.

- [ ] **UC-M01.07-C059-T01 · Review inventory:** List the “Arithmetic semantics” decisions and claims requiring review; distinguish source requirements, implementation observations and engineering assumptions.
- [ ] **UC-M01.07-C059-T02 · Rationale record:** Write the rationale for the selected “Arithmetic semantics” representation or policy; link each choice to the requirement rather than an unexplained preference.
- [ ] **UC-M01.07-C059-T03 · Assumption ledger:** Record unresolved “Arithmetic semantics” assumptions, their owner and what observation or decision would resolve them; do not treat unknowns as approvals.
- [ ] **UC-M01.07-C059-T04 · Boundary map:** Map each “Arithmetic semantics” claim to an actual guard or explicit design/review gate; flag gaps against “Lowering preserves the selected arithmetic semantics”.
- [ ] **UC-M01.07-C059-T05 · Counterexample review:** Walk reviewers through the “Arithmetic semantics” counterexample “A boundary integer changes meaning between source and native execution”; record whether the model detects it and whether any runtime guard was actually exercised.
- [ ] **UC-M01.07-C059-T06 · Review outcome vocabulary:** Define approved, blocked, superseded and untested review outcomes for “Arithmetic semantics”; ensure the wording cannot be read as runtime enforcement evidence.
- [ ] **UC-M01.07-C059-T07 · Re-review triggers:** List “Arithmetic semantics” invalidation triggers, including the source change scenario: a witness still agrees after application behavior or the supported input domain changes; identify the affected claims and evidence.
- [ ] **UC-M01.07-C059-T08 · Sensitive-data review:** Inspect the “Arithmetic semantics” review record for secrets and unrelated user content; retain nonsecret references sufficient for reproducibility.
- [ ] **UC-M01.07-C059-T09 · Independent reading:** Have the “Arithmetic semantics” record read against the original acceptance criterion and language admission, translation outputs and application-result oracles; record misunderstandings or missing evidence as corrections.
- [ ] **UC-M01.07-C059-T10 · Review disposition:** Publish the “Arithmetic semantics” rationale, versioned review outcome, unresolved gaps and explicit next decision; keep blockers open until supported evidence resolves them.

### UC-M01.07-C060 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for arithmetic semantics; label unexecuted checks as untested.

- [ ] **UC-M01.07-C060-T01 · Evidence inventory:** List the “Arithmetic semantics” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M01.07-C060-T02 · Artifact references:** Record the exact “Arithmetic semantics” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M01.07-C060-T03 · Fixture references:** Attach the “Arithmetic semantics” fixture IDs, input identities and oracle definition; preserve the source counterexample “A boundary integer changes meaning between source and native execution” as a distinct evidence case.
- [ ] **UC-M01.07-C060-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Arithmetic semantics”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M01.07-C060-T05 · Environment record:** Record the actual “Arithmetic semantics” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M01.07-C060-T06 · Expected versus observed:** Pair every “Arithmetic semantics” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M01.07-C060-T07 · Failure and limit records:** Attach “Arithmetic semantics” change/failure and bounds evidence where required; include uncovered “Integer widths and arithmetic test combinations” and unresolved violations of “Lowering preserves the selected arithmetic semantics”.
- [ ] **UC-M01.07-C060-T08 · Evidence hygiene:** Check the “Arithmetic semantics” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M01.07-C060-T09 · Reproduction review:** Have the “Arithmetic semantics” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M01.07-C060-T10 · Acceptance linkage:** Link the “Arithmetic semantics” evidence to its parent and UC-M01.07 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 07. State-effect semantics

**Source delivery:** Describe allowed state changes and their commit conditions.

**Source invariant:** Failed execution does not masquerade as a completed state effect.

**Source negative case:** A partial state update is reported as a complete invocation.

**Source bounded quantities:** State footprint and side-effect count.

### UC-M01.07-C061 · Contract

**Original checklist item:** Specify the scope and representation of state-effect semantics; identify its producer, consumer, authority assumptions and explicitly unsupported cases.

- [ ] **UC-M01.07-C061-T01 · Scope statement:** Draft a scope note for “State-effect semantics” within Application semantics versus witness contract; separate required model statements, explicit exclusions and unresolved design decisions.
- [ ] **UC-M01.07-C061-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “State-effect semantics”; record each producer, representation and missing-value meaning.
- [ ] **UC-M01.07-C061-T03 · Output inventory:** List the outputs of “State-effect semantics” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M01.07-C061-T04 · Field dictionary:** Create a field-and-term dictionary for “State-effect semantics”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M01.07-C061-T05 · Prerequisite contract:** Map “State-effect semantics” to the source component prerequisites (UC-M01.02, UC-M01.06); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M01.07-C061-T06 · Authority map:** Identify who may produce, change and consume “State-effect semantics”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M01.07-C061-T07 · Invariant clause:** Add a normative clause for “State-effect semantics” that preserves “Failed execution does not masquerade as a completed state effect”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M01.07-C061-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “State-effect semantics”; include the source counterexample “A partial state update is reported as a complete invocation” and the intended safe disposition.
- [ ] **UC-M01.07-C061-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “State footprint and side-effect count” in the “State-effect semantics” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M01.07-C061-T10 · Contract review:** Review the “State-effect semantics” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M01.07-C062 · Delivery

**Original checklist item:** Describe allowed state changes and their commit conditions.

- [ ] **UC-M01.07-C062-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “State-effect semantics”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M01.07-C062-T02 · Change plan:** Break the source delivery for “State-effect semantics” into concrete edit targets and reviewable outputs; keep the UC-M01.07 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M01.07-C062-T03 · Core artifact:** Create the “State-effect semantics” model, schema or inventory that realizes this source instruction: Describe allowed state changes and their commit conditions.
- [ ] **UC-M01.07-C062-T04 · Concrete realization:** Populate “State-effect semantics” with one concrete worked case; map every required entity or field to its source and flag any unmapped entry.
- [ ] **UC-M01.07-C062-T05 · Invariant protection:** Add the actual guard, check or review criterion for “State-effect semantics” needed to preserve “Failed execution does not masquerade as a completed state effect”; record an enforcement gap where only a model exists.
- [ ] **UC-M01.07-C062-T06 · Dependency connection:** Connect the “State-effect semantics” specification to language admission, translation outputs and application-result oracles; record code coverage separately where the design is not yet enforced.
- [ ] **UC-M01.07-C062-T07 · Resource behavior:** Account for “State footprint and side-effect count” in “State-effect semantics”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M01.07-C062-T08 · Delivery check:** Walk the populated “State-effect semantics” model through a valid example and the source counterexample “A partial state update is reported as a complete invocation”; record corrections and unresolved enforcement gaps.
- [ ] **UC-M01.07-C062-T09 · Patch review:** Review the “State-effect semantics” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M01.07-C062-T10 · Delivery handoff:** Publish the “State-effect semantics” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M01.07-C063 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Failed execution does not masquerade as a completed state effect. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M01.07-C063-T01 · Named property:** Create a stable property/check name under this parent for “State-effect semantics”; copy its required invariant exactly: “Failed execution does not masquerade as a completed state effect”.
- [ ] **UC-M01.07-C063-T02 · Observable terms:** Define each term in the “State-effect semantics” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M01.07-C063-T03 · Precondition set:** List the preconditions under which “Failed execution does not masquerade as a completed state effect” must hold for “State-effect semantics”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M01.07-C063-T04 · Transition coverage:** Map the “State-effect semantics” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M01.07-C063-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “State-effect semantics”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M01.07-C063-T06 · Satisfying fixture:** Create a concrete “State-effect semantics” case that satisfies “Failed execution does not masquerade as a completed state effect”; record its expected observation before running the assertion or review.
- [ ] **UC-M01.07-C063-T07 · Violating fixture:** Create the source counterexample “A partial state update is reported as a complete invocation” for “State-effect semantics”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M01.07-C063-T08 · Enforcement evidence:** Exercise the “State-effect semantics” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M01.07-C063-T09 · Regression linkage:** Link the “State-effect semantics” property to changes in language admission, translation outputs and application-result oracles; record which dependency or contract changes require rerunning it.
- [ ] **UC-M01.07-C063-T10 · Property disposition:** Compare the satisfying and violating “State-effect semantics” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M01.07-C064 · Integration

**Original checklist item:** Integrate state-effect semantics with language admission, translation outputs and application-result oracles; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M01.07-C064-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “State-effect semantics” across language admission, translation outputs and application-result oracles; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M01.07-C064-T02 · Field mapping:** Map every “State-effect semantics” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M01.07-C064-T03 · Prerequisite identities:** Record the actual prerequisites for “State-effect semantics” (source dependency list: UC-M01.02, UC-M01.06); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M01.07-C064-T04 · Ownership agreement:** Specify who owns “State-effect semantics” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M01.07-C064-T05 · Handoff implementation:** Connect “State-effect semantics” through the mapped seam using the real adapter or explicit specification reference; preserve “Failed execution does not masquerade as a completed state effect” across the handoff.
- [ ] **UC-M01.07-C064-T06 · Absent-input case:** Omit one required “State-effect semantics” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M01.07-C064-T07 · Stale-input case:** Supply an outdated “State-effect semantics” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M01.07-C064-T08 · Incompatible-input case:** Supply an incompatible “State-effect semantics” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M01.07-C064-T09 · Valid integration trace:** Run a valid “State-effect semantics” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M01.07-C064-T10 · Seam review:** Reconcile the “State-effect semantics” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M01.07-C065 · Valid-case test

**Original checklist item:** Construct a valid worked example for state-effect semantics; evaluate it against predeclared expected decisions and, where enforcement exists, run the corresponding conformance fixture.

- [ ] **UC-M01.07-C065-T01 · Valid fixture choice:** Select one concrete valid worked example for “State-effect semantics”; enumerate the model inputs and the expected review decision before evaluating it.
- [ ] **UC-M01.07-C065-T02 · Expected-result oracle:** Specify the “State-effect semantics” expected result independently of the implementation output; include the property “Failed execution does not masquerade as a completed state effect” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M01.07-C065-T03 · Fixture material:** Create the concrete “State-effect semantics” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M01.07-C065-T04 · Target preparation:** Prepare the “State-effect semantics” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M01.07-C065-T05 · Initial-state record:** Record the initial “State-effect semantics” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M01.07-C065-T06 · Valid-path execution:** Evaluate the “State-effect semantics” example against the reviewed model; where a runtime mechanism exists, run its corresponding fixture and label those observations separately.
- [ ] **UC-M01.07-C065-T07 · Outcome comparison:** Compare every declared “State-effect semantics” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M01.07-C065-T08 · State and bounds check:** Inspect the “State-effect semantics” ownership/state effects and actual use of “State footprint and side-effect count”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M01.07-C065-T09 · Repeatability check:** Repeat the same “State-effect semantics” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M01.07-C065-T10 · Positive evidence:** Attach the “State-effect semantics” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M01.07-C066 · Negative test

**Original checklist item:** Negative case: A partial state update is reported as a complete invocation. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M01.07-C066-T01 · Adverse-case definition:** Create a test record for the exact “State-effect semantics” source counterexample: “A partial state update is reported as a complete invocation”; state which precondition or invariant it challenges.
- [ ] **UC-M01.07-C066-T02 · Safe fixture boundary:** Define the contained test boundary for “State-effect semantics”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M01.07-C066-T03 · Valid control:** Construct a valid “State-effect semantics” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M01.07-C066-T04 · Minimal adverse input:** Derive the “State-effect semantics” adverse fixture from the control with the smallest documented change needed to reproduce “A partial state update is reported as a complete invocation”; retain that change as reproducible data.
- [ ] **UC-M01.07-C066-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “State-effect semantics”; require “Failed execution does not masquerade as a completed state effect” and forbid a false-success verdict.
- [ ] **UC-M01.07-C066-T06 · Adverse execution:** Evaluate the “State-effect semantics” adverse case through the actual review/contract gate; where implemented, also observe the runtime refusal and keep the two evidence classes separate.
- [ ] **UC-M01.07-C066-T07 · Effect inspection:** Inspect “State-effect semantics” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M01.07-C066-T08 · Refusal versus failure:** Confirm the “State-effect semantics” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M01.07-C066-T09 · Reset and retention:** Restore only the disposable “State-effect semantics” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M01.07-C066-T10 · Negative regression:** Register the “State-effect semantics” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M01.07-C067 · Change / failure test

**Original checklist item:** Exercise state-effect semantics when a witness still agrees after application behavior or the supported input domain changes; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M01.07-C067-T01 · Scenario record:** Write the “State-effect semantics” change/failure scenario exactly as supplied: a witness still agrees after application behavior or the supported input domain changes; identify the property that must remain true: “Failed execution does not masquerade as a completed state effect”.
- [ ] **UC-M01.07-C067-T02 · Baseline capture:** Create a known-valid “State-effect semantics” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M01.07-C067-T03 · Injection map:** Locate the “State-effect semantics” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M01.07-C067-T04 · Disposition oracle:** Define the legal intermediate and final “State-effect semantics” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M01.07-C067-T05 · Controlled trigger:** Apply the controlled model-change scenario for “State-effect semantics”: a witness still agrees after application behavior or the supported input domain changes; retain the exact before/after declarations. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M01.07-C067-T06 · Intermediate inspection:** Review which “State-effect semantics” claims, approvals and evidence references become stale after the change; keep unresolved enforcement gaps visible.
- [ ] **UC-M01.07-C067-T07 · Recovery path:** Revise or explicitly refuse the changed “State-effect semantics” model under the documented compatibility policy; re-review affected claims before restoring their approval.
- [ ] **UC-M01.07-C067-T08 · Stale-evidence cleanup:** Invalidate superseded “State-effect semantics” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M01.07-C067-T09 · Repeat and compare:** Repeat the selected “State-effect semantics” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M01.07-C067-T10 · Failure evidence:** Publish the “State-effect semantics” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M01.07-C068 · Bounds

**Original checklist item:** Define completeness and scaling criteria for state footprint and side-effect count; exercise larger inventories or fixture sets, and report uncovered scope instead of silently excluding it.

- [ ] **UC-M01.07-C068-T01 · Quantity inventory:** Create a measurement inventory for “State-effect semantics”: “State footprint and side-effect count”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M01.07-C068-T02 · Measurement method:** Choose how to observe each “State-effect semantics” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M01.07-C068-T03 · Budget decision:** Select justified coverage and completeness limits for “State-effect semantics”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M01.07-C068-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “State-effect semantics” cases for “State footprint and side-effect count”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M01.07-C068-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “State-effect semantics” limit; preserve “Failed execution does not masquerade as a completed state effect”.
- [ ] **UC-M01.07-C068-T06 · Normal measurement:** Run or review the normal “State-effect semantics” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M01.07-C068-T07 · At-limit measurement:** Exercise the “State-effect semantics” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M01.07-C068-T08 · Over-limit measurement:** Exercise the “State-effect semantics” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M01.07-C068-T09 · Uncovered-scope report:** List the “State-effect semantics” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M01.07-C068-T10 · Limit evidence:** Publish the selected “State-effect semantics” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M01.07-C069 · Diagnostics / review

**Original checklist item:** Record the rationale, unresolved assumptions, enforcement gaps and re-review triggers for state-effect semantics; make design-only claims visibly distinct from observed behavior.

- [ ] **UC-M01.07-C069-T01 · Review inventory:** List the “State-effect semantics” decisions and claims requiring review; distinguish source requirements, implementation observations and engineering assumptions.
- [ ] **UC-M01.07-C069-T02 · Rationale record:** Write the rationale for the selected “State-effect semantics” representation or policy; link each choice to the requirement rather than an unexplained preference.
- [ ] **UC-M01.07-C069-T03 · Assumption ledger:** Record unresolved “State-effect semantics” assumptions, their owner and what observation or decision would resolve them; do not treat unknowns as approvals.
- [ ] **UC-M01.07-C069-T04 · Boundary map:** Map each “State-effect semantics” claim to an actual guard or explicit design/review gate; flag gaps against “Failed execution does not masquerade as a completed state effect”.
- [ ] **UC-M01.07-C069-T05 · Counterexample review:** Walk reviewers through the “State-effect semantics” counterexample “A partial state update is reported as a complete invocation”; record whether the model detects it and whether any runtime guard was actually exercised.
- [ ] **UC-M01.07-C069-T06 · Review outcome vocabulary:** Define approved, blocked, superseded and untested review outcomes for “State-effect semantics”; ensure the wording cannot be read as runtime enforcement evidence.
- [ ] **UC-M01.07-C069-T07 · Re-review triggers:** List “State-effect semantics” invalidation triggers, including the source change scenario: a witness still agrees after application behavior or the supported input domain changes; identify the affected claims and evidence.
- [ ] **UC-M01.07-C069-T08 · Sensitive-data review:** Inspect the “State-effect semantics” review record for secrets and unrelated user content; retain nonsecret references sufficient for reproducibility.
- [ ] **UC-M01.07-C069-T09 · Independent reading:** Have the “State-effect semantics” record read against the original acceptance criterion and language admission, translation outputs and application-result oracles; record misunderstandings or missing evidence as corrections.
- [ ] **UC-M01.07-C069-T10 · Review disposition:** Publish the “State-effect semantics” rationale, versioned review outcome, unresolved gaps and explicit next decision; keep blockers open until supported evidence resolves them.

### UC-M01.07-C070 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for state-effect semantics; label unexecuted checks as untested.

- [ ] **UC-M01.07-C070-T01 · Evidence inventory:** List the “State-effect semantics” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M01.07-C070-T02 · Artifact references:** Record the exact “State-effect semantics” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M01.07-C070-T03 · Fixture references:** Attach the “State-effect semantics” fixture IDs, input identities and oracle definition; preserve the source counterexample “A partial state update is reported as a complete invocation” as a distinct evidence case.
- [ ] **UC-M01.07-C070-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “State-effect semantics”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M01.07-C070-T05 · Environment record:** Record the actual “State-effect semantics” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M01.07-C070-T06 · Expected versus observed:** Pair every “State-effect semantics” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M01.07-C070-T07 · Failure and limit records:** Attach “State-effect semantics” change/failure and bounds evidence where required; include uncovered “State footprint and side-effect count” and unresolved violations of “Failed execution does not masquerade as a completed state effect”.
- [ ] **UC-M01.07-C070-T08 · Evidence hygiene:** Check the “State-effect semantics” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M01.07-C070-T09 · Reproduction review:** Have the “State-effect semantics” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M01.07-C070-T10 · Acceptance linkage:** Link the “State-effect semantics” evidence to its parent and UC-M01.07 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 08. Witness separation

**Source delivery:** Keep witness inputs and results separate from semantic output verdicts.

**Source invariant:** Row-sequence agreement alone never proves arbitrary program correctness.

**Source negative case:** A matching accumulator promotes a semantically failing program.

**Source bounded quantities:** Witness bytes and independent verdict fields.

### UC-M01.07-C071 · Contract

**Original checklist item:** Specify the scope and representation of witness separation; identify its producer, consumer, authority assumptions and explicitly unsupported cases.

- [ ] **UC-M01.07-C071-T01 · Scope statement:** Draft a scope note for “Witness separation” within Application semantics versus witness contract; separate required model statements, explicit exclusions and unresolved design decisions.
- [ ] **UC-M01.07-C071-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Witness separation”; record each producer, representation and missing-value meaning.
- [ ] **UC-M01.07-C071-T03 · Output inventory:** List the outputs of “Witness separation” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M01.07-C071-T04 · Field dictionary:** Create a field-and-term dictionary for “Witness separation”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M01.07-C071-T05 · Prerequisite contract:** Map “Witness separation” to the source component prerequisites (UC-M01.02, UC-M01.06); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M01.07-C071-T06 · Authority map:** Identify who may produce, change and consume “Witness separation”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M01.07-C071-T07 · Invariant clause:** Add a normative clause for “Witness separation” that preserves “Row-sequence agreement alone never proves arbitrary program correctness”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M01.07-C071-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Witness separation”; include the source counterexample “A matching accumulator promotes a semantically failing program” and the intended safe disposition.
- [ ] **UC-M01.07-C071-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Witness bytes and independent verdict fields” in the “Witness separation” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M01.07-C071-T10 · Contract review:** Review the “Witness separation” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M01.07-C072 · Delivery

**Original checklist item:** Keep witness inputs and results separate from semantic output verdicts.

- [ ] **UC-M01.07-C072-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Witness separation”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M01.07-C072-T02 · Change plan:** Break the source delivery for “Witness separation” into concrete edit targets and reviewable outputs; keep the UC-M01.07 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M01.07-C072-T03 · Core artifact:** Implement the smallest selected-profile change for “Witness separation” that realizes this source instruction: Keep witness inputs and results separate from semantic output verdicts.
- [ ] **UC-M01.07-C072-T04 · Concrete realization:** Trace “Witness separation” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M01.07-C072-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Witness separation” needed to preserve “Row-sequence agreement alone never proves arbitrary program correctness”; record an enforcement gap where only a model exists.
- [ ] **UC-M01.07-C072-T06 · Dependency connection:** Connect the “Witness separation” specification to language admission, translation outputs and application-result oracles; record code coverage separately where the design is not yet enforced.
- [ ] **UC-M01.07-C072-T07 · Resource behavior:** Account for “Witness bytes and independent verdict fields” in “Witness separation”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M01.07-C072-T08 · Delivery check:** Walk the populated “Witness separation” model through a valid example and the source counterexample “A matching accumulator promotes a semantically failing program”; record corrections and unresolved enforcement gaps.
- [ ] **UC-M01.07-C072-T09 · Patch review:** Review the “Witness separation” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M01.07-C072-T10 · Delivery handoff:** Publish the “Witness separation” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M01.07-C073 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: Row-sequence agreement alone never proves arbitrary program correctness. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M01.07-C073-T01 · Named property:** Create a stable property/check name under this parent for “Witness separation”; copy its required invariant exactly: “Row-sequence agreement alone never proves arbitrary program correctness”.
- [ ] **UC-M01.07-C073-T02 · Observable terms:** Define each term in the “Witness separation” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M01.07-C073-T03 · Precondition set:** List the preconditions under which “Row-sequence agreement alone never proves arbitrary program correctness” must hold for “Witness separation”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M01.07-C073-T04 · Transition coverage:** Map the “Witness separation” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M01.07-C073-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Witness separation”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M01.07-C073-T06 · Satisfying fixture:** Create a concrete “Witness separation” case that satisfies “Row-sequence agreement alone never proves arbitrary program correctness”; record its expected observation before running the assertion or review.
- [ ] **UC-M01.07-C073-T07 · Violating fixture:** Create the source counterexample “A matching accumulator promotes a semantically failing program” for “Witness separation”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M01.07-C073-T08 · Enforcement evidence:** Exercise the “Witness separation” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M01.07-C073-T09 · Regression linkage:** Link the “Witness separation” property to changes in language admission, translation outputs and application-result oracles; record which dependency or contract changes require rerunning it.
- [ ] **UC-M01.07-C073-T10 · Property disposition:** Compare the satisfying and violating “Witness separation” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M01.07-C074 · Integration

**Original checklist item:** Integrate witness separation with language admission, translation outputs and application-result oracles; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M01.07-C074-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Witness separation” across language admission, translation outputs and application-result oracles; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M01.07-C074-T02 · Field mapping:** Map every “Witness separation” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M01.07-C074-T03 · Prerequisite identities:** Record the actual prerequisites for “Witness separation” (source dependency list: UC-M01.02, UC-M01.06); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M01.07-C074-T04 · Ownership agreement:** Specify who owns “Witness separation” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M01.07-C074-T05 · Handoff implementation:** Connect “Witness separation” through the mapped seam using the real adapter or explicit specification reference; preserve “Row-sequence agreement alone never proves arbitrary program correctness” across the handoff.
- [ ] **UC-M01.07-C074-T06 · Absent-input case:** Omit one required “Witness separation” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M01.07-C074-T07 · Stale-input case:** Supply an outdated “Witness separation” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M01.07-C074-T08 · Incompatible-input case:** Supply an incompatible “Witness separation” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M01.07-C074-T09 · Valid integration trace:** Run a valid “Witness separation” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M01.07-C074-T10 · Seam review:** Reconcile the “Witness separation” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M01.07-C075 · Valid-case test

**Original checklist item:** Construct a valid worked example for witness separation; evaluate it against predeclared expected decisions and, where enforcement exists, run the corresponding conformance fixture.

- [ ] **UC-M01.07-C075-T01 · Valid fixture choice:** Select one concrete valid worked example for “Witness separation”; enumerate the model inputs and the expected review decision before evaluating it.
- [ ] **UC-M01.07-C075-T02 · Expected-result oracle:** Specify the “Witness separation” expected result independently of the implementation output; include the property “Row-sequence agreement alone never proves arbitrary program correctness” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M01.07-C075-T03 · Fixture material:** Create the concrete “Witness separation” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M01.07-C075-T04 · Target preparation:** Prepare the “Witness separation” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M01.07-C075-T05 · Initial-state record:** Record the initial “Witness separation” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M01.07-C075-T06 · Valid-path execution:** Evaluate the “Witness separation” example against the reviewed model; where a runtime mechanism exists, run its corresponding fixture and label those observations separately.
- [ ] **UC-M01.07-C075-T07 · Outcome comparison:** Compare every declared “Witness separation” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M01.07-C075-T08 · State and bounds check:** Inspect the “Witness separation” ownership/state effects and actual use of “Witness bytes and independent verdict fields”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M01.07-C075-T09 · Repeatability check:** Repeat the same “Witness separation” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M01.07-C075-T10 · Positive evidence:** Attach the “Witness separation” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M01.07-C076 · Negative test

**Original checklist item:** Negative case: A matching accumulator promotes a semantically failing program. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M01.07-C076-T01 · Adverse-case definition:** Create a test record for the exact “Witness separation” source counterexample: “A matching accumulator promotes a semantically failing program”; state which precondition or invariant it challenges.
- [ ] **UC-M01.07-C076-T02 · Safe fixture boundary:** Define the contained test boundary for “Witness separation”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M01.07-C076-T03 · Valid control:** Construct a valid “Witness separation” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M01.07-C076-T04 · Minimal adverse input:** Derive the “Witness separation” adverse fixture from the control with the smallest documented change needed to reproduce “A matching accumulator promotes a semantically failing program”; retain that change as reproducible data.
- [ ] **UC-M01.07-C076-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Witness separation”; require “Row-sequence agreement alone never proves arbitrary program correctness” and forbid a false-success verdict.
- [ ] **UC-M01.07-C076-T06 · Adverse execution:** Evaluate the “Witness separation” adverse case through the actual review/contract gate; where implemented, also observe the runtime refusal and keep the two evidence classes separate.
- [ ] **UC-M01.07-C076-T07 · Effect inspection:** Inspect “Witness separation” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M01.07-C076-T08 · Refusal versus failure:** Confirm the “Witness separation” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M01.07-C076-T09 · Reset and retention:** Restore only the disposable “Witness separation” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M01.07-C076-T10 · Negative regression:** Register the “Witness separation” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M01.07-C077 · Change / failure test

**Original checklist item:** Exercise witness separation when a witness still agrees after application behavior or the supported input domain changes; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M01.07-C077-T01 · Scenario record:** Write the “Witness separation” change/failure scenario exactly as supplied: a witness still agrees after application behavior or the supported input domain changes; identify the property that must remain true: “Row-sequence agreement alone never proves arbitrary program correctness”.
- [ ] **UC-M01.07-C077-T02 · Baseline capture:** Create a known-valid “Witness separation” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M01.07-C077-T03 · Injection map:** Locate the “Witness separation” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M01.07-C077-T04 · Disposition oracle:** Define the legal intermediate and final “Witness separation” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M01.07-C077-T05 · Controlled trigger:** Apply the controlled model-change scenario for “Witness separation”: a witness still agrees after application behavior or the supported input domain changes; retain the exact before/after declarations. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M01.07-C077-T06 · Intermediate inspection:** Review which “Witness separation” claims, approvals and evidence references become stale after the change; keep unresolved enforcement gaps visible.
- [ ] **UC-M01.07-C077-T07 · Recovery path:** Revise or explicitly refuse the changed “Witness separation” model under the documented compatibility policy; re-review affected claims before restoring their approval.
- [ ] **UC-M01.07-C077-T08 · Stale-evidence cleanup:** Invalidate superseded “Witness separation” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M01.07-C077-T09 · Repeat and compare:** Repeat the selected “Witness separation” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M01.07-C077-T10 · Failure evidence:** Publish the “Witness separation” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M01.07-C078 · Bounds

**Original checklist item:** Define completeness and scaling criteria for witness bytes and independent verdict fields; exercise larger inventories or fixture sets, and report uncovered scope instead of silently excluding it.

- [ ] **UC-M01.07-C078-T01 · Quantity inventory:** Create a measurement inventory for “Witness separation”: “Witness bytes and independent verdict fields”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M01.07-C078-T02 · Measurement method:** Choose how to observe each “Witness separation” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M01.07-C078-T03 · Budget decision:** Select justified coverage and completeness limits for “Witness separation”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M01.07-C078-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Witness separation” cases for “Witness bytes and independent verdict fields”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M01.07-C078-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Witness separation” limit; preserve “Row-sequence agreement alone never proves arbitrary program correctness”.
- [ ] **UC-M01.07-C078-T06 · Normal measurement:** Run or review the normal “Witness separation” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M01.07-C078-T07 · At-limit measurement:** Exercise the “Witness separation” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M01.07-C078-T08 · Over-limit measurement:** Exercise the “Witness separation” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M01.07-C078-T09 · Uncovered-scope report:** List the “Witness separation” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M01.07-C078-T10 · Limit evidence:** Publish the selected “Witness separation” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M01.07-C079 · Diagnostics / review

**Original checklist item:** Record the rationale, unresolved assumptions, enforcement gaps and re-review triggers for witness separation; make design-only claims visibly distinct from observed behavior.

- [ ] **UC-M01.07-C079-T01 · Review inventory:** List the “Witness separation” decisions and claims requiring review; distinguish source requirements, implementation observations and engineering assumptions.
- [ ] **UC-M01.07-C079-T02 · Rationale record:** Write the rationale for the selected “Witness separation” representation or policy; link each choice to the requirement rather than an unexplained preference.
- [ ] **UC-M01.07-C079-T03 · Assumption ledger:** Record unresolved “Witness separation” assumptions, their owner and what observation or decision would resolve them; do not treat unknowns as approvals.
- [ ] **UC-M01.07-C079-T04 · Boundary map:** Map each “Witness separation” claim to an actual guard or explicit design/review gate; flag gaps against “Row-sequence agreement alone never proves arbitrary program correctness”.
- [ ] **UC-M01.07-C079-T05 · Counterexample review:** Walk reviewers through the “Witness separation” counterexample “A matching accumulator promotes a semantically failing program”; record whether the model detects it and whether any runtime guard was actually exercised.
- [ ] **UC-M01.07-C079-T06 · Review outcome vocabulary:** Define approved, blocked, superseded and untested review outcomes for “Witness separation”; ensure the wording cannot be read as runtime enforcement evidence.
- [ ] **UC-M01.07-C079-T07 · Re-review triggers:** List “Witness separation” invalidation triggers, including the source change scenario: a witness still agrees after application behavior or the supported input domain changes; identify the affected claims and evidence.
- [ ] **UC-M01.07-C079-T08 · Sensitive-data review:** Inspect the “Witness separation” review record for secrets and unrelated user content; retain nonsecret references sufficient for reproducibility.
- [ ] **UC-M01.07-C079-T09 · Independent reading:** Have the “Witness separation” record read against the original acceptance criterion and language admission, translation outputs and application-result oracles; record misunderstandings or missing evidence as corrections.
- [ ] **UC-M01.07-C079-T10 · Review disposition:** Publish the “Witness separation” rationale, versioned review outcome, unresolved gaps and explicit next decision; keep blockers open until supported evidence resolves them.

### UC-M01.07-C080 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for witness separation; label unexecuted checks as untested.

- [ ] **UC-M01.07-C080-T01 · Evidence inventory:** List the “Witness separation” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M01.07-C080-T02 · Artifact references:** Record the exact “Witness separation” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M01.07-C080-T03 · Fixture references:** Attach the “Witness separation” fixture IDs, input identities and oracle definition; preserve the source counterexample “A matching accumulator promotes a semantically failing program” as a distinct evidence case.
- [ ] **UC-M01.07-C080-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Witness separation”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M01.07-C080-T05 · Environment record:** Record the actual “Witness separation” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M01.07-C080-T06 · Expected versus observed:** Pair every “Witness separation” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M01.07-C080-T07 · Failure and limit records:** Attach “Witness separation” change/failure and bounds evidence where required; include uncovered “Witness bytes and independent verdict fields” and unresolved violations of “Row-sequence agreement alone never proves arbitrary program correctness”.
- [ ] **UC-M01.07-C080-T08 · Evidence hygiene:** Check the “Witness separation” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M01.07-C080-T09 · Reproduction review:** Have the “Witness separation” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M01.07-C080-T10 · Acceptance linkage:** Link the “Witness separation” evidence to its parent and UC-M01.07 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 09. Nontrivial workload suite

**Source delivery:** Build a small application suite with meaningful branches, data and outputs.

**Source invariant:** At least one target application exercises real observable computation.

**Source negative case:** Only a no-op workload is used to claim execution support.

**Source bounded quantities:** Program size, cases and execution deadlines.

### UC-M01.07-C081 · Contract

**Original checklist item:** Specify the scope and representation of nontrivial workload suite; identify its producer, consumer, authority assumptions and explicitly unsupported cases.

- [ ] **UC-M01.07-C081-T01 · Scope statement:** Draft a scope note for “Nontrivial workload suite” within Application semantics versus witness contract; separate required model statements, explicit exclusions and unresolved design decisions.
- [ ] **UC-M01.07-C081-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Nontrivial workload suite”; record each producer, representation and missing-value meaning.
- [ ] **UC-M01.07-C081-T03 · Output inventory:** List the outputs of “Nontrivial workload suite” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M01.07-C081-T04 · Field dictionary:** Create a field-and-term dictionary for “Nontrivial workload suite”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M01.07-C081-T05 · Prerequisite contract:** Map “Nontrivial workload suite” to the source component prerequisites (UC-M01.02, UC-M01.06); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M01.07-C081-T06 · Authority map:** Identify who may produce, change and consume “Nontrivial workload suite”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M01.07-C081-T07 · Invariant clause:** Add a normative clause for “Nontrivial workload suite” that preserves “At least one target application exercises real observable computation”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M01.07-C081-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Nontrivial workload suite”; include the source counterexample “Only a no-op workload is used to claim execution support” and the intended safe disposition.
- [ ] **UC-M01.07-C081-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Program size, cases and execution deadlines” in the “Nontrivial workload suite” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M01.07-C081-T10 · Contract review:** Review the “Nontrivial workload suite” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M01.07-C082 · Delivery

**Original checklist item:** Build a small application suite with meaningful branches, data and outputs.

- [ ] **UC-M01.07-C082-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Nontrivial workload suite”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M01.07-C082-T02 · Change plan:** Break the source delivery for “Nontrivial workload suite” into concrete edit targets and reviewable outputs; keep the UC-M01.07 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M01.07-C082-T03 · Core artifact:** Implement the smallest selected-profile change for “Nontrivial workload suite” that realizes this source instruction: Build a small application suite with meaningful branches, data and outputs.
- [ ] **UC-M01.07-C082-T04 · Concrete realization:** Trace “Nontrivial workload suite” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M01.07-C082-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Nontrivial workload suite” needed to preserve “At least one target application exercises real observable computation”; record an enforcement gap where only a model exists.
- [ ] **UC-M01.07-C082-T06 · Dependency connection:** Connect the “Nontrivial workload suite” specification to language admission, translation outputs and application-result oracles; record code coverage separately where the design is not yet enforced.
- [ ] **UC-M01.07-C082-T07 · Resource behavior:** Account for “Program size, cases and execution deadlines” in “Nontrivial workload suite”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M01.07-C082-T08 · Delivery check:** Walk the populated “Nontrivial workload suite” model through a valid example and the source counterexample “Only a no-op workload is used to claim execution support”; record corrections and unresolved enforcement gaps.
- [ ] **UC-M01.07-C082-T09 · Patch review:** Review the “Nontrivial workload suite” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M01.07-C082-T10 · Delivery handoff:** Publish the “Nontrivial workload suite” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M01.07-C083 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: At least one target application exercises real observable computation. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M01.07-C083-T01 · Named property:** Create a stable property/check name under this parent for “Nontrivial workload suite”; copy its required invariant exactly: “At least one target application exercises real observable computation”.
- [ ] **UC-M01.07-C083-T02 · Observable terms:** Define each term in the “Nontrivial workload suite” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M01.07-C083-T03 · Precondition set:** List the preconditions under which “At least one target application exercises real observable computation” must hold for “Nontrivial workload suite”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M01.07-C083-T04 · Transition coverage:** Map the “Nontrivial workload suite” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M01.07-C083-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Nontrivial workload suite”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M01.07-C083-T06 · Satisfying fixture:** Create a concrete “Nontrivial workload suite” case that satisfies “At least one target application exercises real observable computation”; record its expected observation before running the assertion or review.
- [ ] **UC-M01.07-C083-T07 · Violating fixture:** Create the source counterexample “Only a no-op workload is used to claim execution support” for “Nontrivial workload suite”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M01.07-C083-T08 · Enforcement evidence:** Exercise the “Nontrivial workload suite” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M01.07-C083-T09 · Regression linkage:** Link the “Nontrivial workload suite” property to changes in language admission, translation outputs and application-result oracles; record which dependency or contract changes require rerunning it.
- [ ] **UC-M01.07-C083-T10 · Property disposition:** Compare the satisfying and violating “Nontrivial workload suite” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M01.07-C084 · Integration

**Original checklist item:** Integrate nontrivial workload suite with language admission, translation outputs and application-result oracles; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M01.07-C084-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Nontrivial workload suite” across language admission, translation outputs and application-result oracles; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M01.07-C084-T02 · Field mapping:** Map every “Nontrivial workload suite” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M01.07-C084-T03 · Prerequisite identities:** Record the actual prerequisites for “Nontrivial workload suite” (source dependency list: UC-M01.02, UC-M01.06); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M01.07-C084-T04 · Ownership agreement:** Specify who owns “Nontrivial workload suite” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M01.07-C084-T05 · Handoff implementation:** Connect “Nontrivial workload suite” through the mapped seam using the real adapter or explicit specification reference; preserve “At least one target application exercises real observable computation” across the handoff.
- [ ] **UC-M01.07-C084-T06 · Absent-input case:** Omit one required “Nontrivial workload suite” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M01.07-C084-T07 · Stale-input case:** Supply an outdated “Nontrivial workload suite” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M01.07-C084-T08 · Incompatible-input case:** Supply an incompatible “Nontrivial workload suite” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M01.07-C084-T09 · Valid integration trace:** Run a valid “Nontrivial workload suite” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M01.07-C084-T10 · Seam review:** Reconcile the “Nontrivial workload suite” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M01.07-C085 · Valid-case test

**Original checklist item:** Construct a valid worked example for nontrivial workload suite; evaluate it against predeclared expected decisions and, where enforcement exists, run the corresponding conformance fixture.

- [ ] **UC-M01.07-C085-T01 · Valid fixture choice:** Select one concrete valid worked example for “Nontrivial workload suite”; enumerate the model inputs and the expected review decision before evaluating it.
- [ ] **UC-M01.07-C085-T02 · Expected-result oracle:** Specify the “Nontrivial workload suite” expected result independently of the implementation output; include the property “At least one target application exercises real observable computation” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M01.07-C085-T03 · Fixture material:** Create the concrete “Nontrivial workload suite” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M01.07-C085-T04 · Target preparation:** Prepare the “Nontrivial workload suite” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M01.07-C085-T05 · Initial-state record:** Record the initial “Nontrivial workload suite” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M01.07-C085-T06 · Valid-path execution:** Evaluate the “Nontrivial workload suite” example against the reviewed model; where a runtime mechanism exists, run its corresponding fixture and label those observations separately.
- [ ] **UC-M01.07-C085-T07 · Outcome comparison:** Compare every declared “Nontrivial workload suite” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M01.07-C085-T08 · State and bounds check:** Inspect the “Nontrivial workload suite” ownership/state effects and actual use of “Program size, cases and execution deadlines”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M01.07-C085-T09 · Repeatability check:** Repeat the same “Nontrivial workload suite” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M01.07-C085-T10 · Positive evidence:** Attach the “Nontrivial workload suite” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M01.07-C086 · Negative test

**Original checklist item:** Negative case: Only a no-op workload is used to claim execution support. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M01.07-C086-T01 · Adverse-case definition:** Create a test record for the exact “Nontrivial workload suite” source counterexample: “Only a no-op workload is used to claim execution support”; state which precondition or invariant it challenges.
- [ ] **UC-M01.07-C086-T02 · Safe fixture boundary:** Define the contained test boundary for “Nontrivial workload suite”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M01.07-C086-T03 · Valid control:** Construct a valid “Nontrivial workload suite” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M01.07-C086-T04 · Minimal adverse input:** Derive the “Nontrivial workload suite” adverse fixture from the control with the smallest documented change needed to reproduce “Only a no-op workload is used to claim execution support”; retain that change as reproducible data.
- [ ] **UC-M01.07-C086-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Nontrivial workload suite”; require “At least one target application exercises real observable computation” and forbid a false-success verdict.
- [ ] **UC-M01.07-C086-T06 · Adverse execution:** Evaluate the “Nontrivial workload suite” adverse case through the actual review/contract gate; where implemented, also observe the runtime refusal and keep the two evidence classes separate.
- [ ] **UC-M01.07-C086-T07 · Effect inspection:** Inspect “Nontrivial workload suite” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M01.07-C086-T08 · Refusal versus failure:** Confirm the “Nontrivial workload suite” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M01.07-C086-T09 · Reset and retention:** Restore only the disposable “Nontrivial workload suite” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M01.07-C086-T10 · Negative regression:** Register the “Nontrivial workload suite” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M01.07-C087 · Change / failure test

**Original checklist item:** Exercise nontrivial workload suite when a witness still agrees after application behavior or the supported input domain changes; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M01.07-C087-T01 · Scenario record:** Write the “Nontrivial workload suite” change/failure scenario exactly as supplied: a witness still agrees after application behavior or the supported input domain changes; identify the property that must remain true: “At least one target application exercises real observable computation”.
- [ ] **UC-M01.07-C087-T02 · Baseline capture:** Create a known-valid “Nontrivial workload suite” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M01.07-C087-T03 · Injection map:** Locate the “Nontrivial workload suite” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M01.07-C087-T04 · Disposition oracle:** Define the legal intermediate and final “Nontrivial workload suite” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M01.07-C087-T05 · Controlled trigger:** Apply the controlled model-change scenario for “Nontrivial workload suite”: a witness still agrees after application behavior or the supported input domain changes; retain the exact before/after declarations. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M01.07-C087-T06 · Intermediate inspection:** Review which “Nontrivial workload suite” claims, approvals and evidence references become stale after the change; keep unresolved enforcement gaps visible.
- [ ] **UC-M01.07-C087-T07 · Recovery path:** Revise or explicitly refuse the changed “Nontrivial workload suite” model under the documented compatibility policy; re-review affected claims before restoring their approval.
- [ ] **UC-M01.07-C087-T08 · Stale-evidence cleanup:** Invalidate superseded “Nontrivial workload suite” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M01.07-C087-T09 · Repeat and compare:** Repeat the selected “Nontrivial workload suite” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M01.07-C087-T10 · Failure evidence:** Publish the “Nontrivial workload suite” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M01.07-C088 · Bounds

**Original checklist item:** Define completeness and scaling criteria for program size, cases and execution deadlines; exercise larger inventories or fixture sets, and report uncovered scope instead of silently excluding it.

- [ ] **UC-M01.07-C088-T01 · Quantity inventory:** Create a measurement inventory for “Nontrivial workload suite”: “Program size, cases and execution deadlines”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M01.07-C088-T02 · Measurement method:** Choose how to observe each “Nontrivial workload suite” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M01.07-C088-T03 · Budget decision:** Select justified coverage and completeness limits for “Nontrivial workload suite”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M01.07-C088-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Nontrivial workload suite” cases for “Program size, cases and execution deadlines”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M01.07-C088-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Nontrivial workload suite” limit; preserve “At least one target application exercises real observable computation”.
- [ ] **UC-M01.07-C088-T06 · Normal measurement:** Run or review the normal “Nontrivial workload suite” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M01.07-C088-T07 · At-limit measurement:** Exercise the “Nontrivial workload suite” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M01.07-C088-T08 · Over-limit measurement:** Exercise the “Nontrivial workload suite” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M01.07-C088-T09 · Uncovered-scope report:** List the “Nontrivial workload suite” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M01.07-C088-T10 · Limit evidence:** Publish the selected “Nontrivial workload suite” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M01.07-C089 · Diagnostics / review

**Original checklist item:** Record the rationale, unresolved assumptions, enforcement gaps and re-review triggers for nontrivial workload suite; make design-only claims visibly distinct from observed behavior.

- [ ] **UC-M01.07-C089-T01 · Review inventory:** List the “Nontrivial workload suite” decisions and claims requiring review; distinguish source requirements, implementation observations and engineering assumptions.
- [ ] **UC-M01.07-C089-T02 · Rationale record:** Write the rationale for the selected “Nontrivial workload suite” representation or policy; link each choice to the requirement rather than an unexplained preference.
- [ ] **UC-M01.07-C089-T03 · Assumption ledger:** Record unresolved “Nontrivial workload suite” assumptions, their owner and what observation or decision would resolve them; do not treat unknowns as approvals.
- [ ] **UC-M01.07-C089-T04 · Boundary map:** Map each “Nontrivial workload suite” claim to an actual guard or explicit design/review gate; flag gaps against “At least one target application exercises real observable computation”.
- [ ] **UC-M01.07-C089-T05 · Counterexample review:** Walk reviewers through the “Nontrivial workload suite” counterexample “Only a no-op workload is used to claim execution support”; record whether the model detects it and whether any runtime guard was actually exercised.
- [ ] **UC-M01.07-C089-T06 · Review outcome vocabulary:** Define approved, blocked, superseded and untested review outcomes for “Nontrivial workload suite”; ensure the wording cannot be read as runtime enforcement evidence.
- [ ] **UC-M01.07-C089-T07 · Re-review triggers:** List “Nontrivial workload suite” invalidation triggers, including the source change scenario: a witness still agrees after application behavior or the supported input domain changes; identify the affected claims and evidence.
- [ ] **UC-M01.07-C089-T08 · Sensitive-data review:** Inspect the “Nontrivial workload suite” review record for secrets and unrelated user content; retain nonsecret references sufficient for reproducibility.
- [ ] **UC-M01.07-C089-T09 · Independent reading:** Have the “Nontrivial workload suite” record read against the original acceptance criterion and language admission, translation outputs and application-result oracles; record misunderstandings or missing evidence as corrections.
- [ ] **UC-M01.07-C089-T10 · Review disposition:** Publish the “Nontrivial workload suite” rationale, versioned review outcome, unresolved gaps and explicit next decision; keep blockers open until supported evidence resolves them.

### UC-M01.07-C090 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for nontrivial workload suite; label unexecuted checks as untested.

- [ ] **UC-M01.07-C090-T01 · Evidence inventory:** List the “Nontrivial workload suite” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M01.07-C090-T02 · Artifact references:** Record the exact “Nontrivial workload suite” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M01.07-C090-T03 · Fixture references:** Attach the “Nontrivial workload suite” fixture IDs, input identities and oracle definition; preserve the source counterexample “Only a no-op workload is used to claim execution support” as a distinct evidence case.
- [ ] **UC-M01.07-C090-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Nontrivial workload suite”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M01.07-C090-T05 · Environment record:** Record the actual “Nontrivial workload suite” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M01.07-C090-T06 · Expected versus observed:** Pair every “Nontrivial workload suite” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M01.07-C090-T07 · Failure and limit records:** Attach “Nontrivial workload suite” change/failure and bounds evidence where required; include uncovered “Program size, cases and execution deadlines” and unresolved violations of “At least one target application exercises real observable computation”.
- [ ] **UC-M01.07-C090-T08 · Evidence hygiene:** Check the “Nontrivial workload suite” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M01.07-C090-T09 · Reproduction review:** Have the “Nontrivial workload suite” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M01.07-C090-T10 · Acceptance linkage:** Link the “Nontrivial workload suite” evidence to its parent and UC-M01.07 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

## 10. Semantic promotion gate

**Source delivery:** Require target-specific semantic evidence before claiming application support.

**Source invariant:** An unsupported target remains unqualified despite host-only results.

**Source negative case:** A host test is reused as evidence of guest execution correctness.

**Source bounded quantities:** Target matrix size and evidence freshness.

### UC-M01.07-C091 · Contract

**Original checklist item:** Specify the scope and representation of semantic promotion gate; identify its producer, consumer, authority assumptions and explicitly unsupported cases.

- [ ] **UC-M01.07-C091-T01 · Scope statement:** Draft a scope note for “Semantic promotion gate” within Application semantics versus witness contract; separate required model statements, explicit exclusions and unresolved design decisions.
- [ ] **UC-M01.07-C091-T02 · Input inventory:** Enumerate the inputs, declarations or observations consumed by “Semantic promotion gate”; record each producer, representation and missing-value meaning.
- [ ] **UC-M01.07-C091-T03 · Output inventory:** List the outputs of “Semantic promotion gate” and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.
- [ ] **UC-M01.07-C091-T04 · Field dictionary:** Create a field-and-term dictionary for “Semantic promotion gate”; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.
- [ ] **UC-M01.07-C091-T05 · Prerequisite contract:** Map “Semantic promotion gate” to the source component prerequisites (UC-M01.02, UC-M01.06); record the selected profile and which inputs must be supplied before this contract can be accepted.
- [ ] **UC-M01.07-C091-T06 · Authority map:** Identify who may produce, change and consume “Semantic promotion gate”; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.
- [ ] **UC-M01.07-C091-T07 · Invariant clause:** Add a normative clause for “Semantic promotion gate” that preserves “An unsupported target remains unqualified despite host-only results”; name the observation or review decision that will demonstrate compliance.
- [ ] **UC-M01.07-C091-T08 · Outcome table:** Define valid, unsupported and adverse outcomes for “Semantic promotion gate”; include the source counterexample “A host test is reused as evidence of guest execution correctness” and the intended safe disposition.
- [ ] **UC-M01.07-C091-T09 · Limit decisions:** List units, selection rationale and unresolved limits for “Target matrix size and evidence freshness” in the “Semantic promotion gate” contract; assign decisions rather than fabricating numerical budgets.
- [ ] **UC-M01.07-C091-T10 · Contract review:** Review the “Semantic promotion gate” input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.

### UC-M01.07-C092 · Delivery

**Original checklist item:** Require target-specific semantic evidence before claiming application support.

- [ ] **UC-M01.07-C092-T01 · Existing-work inventory:** Locate the existing code, specification, fixture or explicit absence for “Semantic promotion gate”; record the baseline path/revision without assuming this planning pack implements it.
- [ ] **UC-M01.07-C092-T02 · Change plan:** Break the source delivery for “Semantic promotion gate” into concrete edit targets and reviewable outputs; keep the UC-M01.07 requirement and original acceptance criterion as the scope boundary.
- [ ] **UC-M01.07-C092-T03 · Core artifact:** Implement the smallest selected-profile change for “Semantic promotion gate” that realizes this source instruction: Require target-specific semantic evidence before claiming application support.
- [ ] **UC-M01.07-C092-T04 · Concrete realization:** Trace “Semantic promotion gate” from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.
- [ ] **UC-M01.07-C092-T05 · Invariant protection:** Add the actual guard, check or review criterion for “Semantic promotion gate” needed to preserve “An unsupported target remains unqualified despite host-only results”; record an enforcement gap where only a model exists.
- [ ] **UC-M01.07-C092-T06 · Dependency connection:** Connect the “Semantic promotion gate” specification to language admission, translation outputs and application-result oracles; record code coverage separately where the design is not yet enforced.
- [ ] **UC-M01.07-C092-T07 · Resource behavior:** Account for “Target matrix size and evidence freshness” in “Semantic promotion gate”; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.
- [ ] **UC-M01.07-C092-T08 · Delivery check:** Walk the populated “Semantic promotion gate” model through a valid example and the source counterexample “A host test is reused as evidence of guest execution correctness”; record corrections and unresolved enforcement gaps.
- [ ] **UC-M01.07-C092-T09 · Patch review:** Review the “Semantic promotion gate” diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.
- [ ] **UC-M01.07-C092-T10 · Delivery handoff:** Publish the “Semantic promotion gate” artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.

### UC-M01.07-C093 · Invariant

**Original checklist item:** Add a named conformance check for this invariant: An unsupported target remains unqualified despite host-only results. Identify the enforcing code or explicit design/review gate and any remaining enforcement gap.

- [ ] **UC-M01.07-C093-T01 · Named property:** Create a stable property/check name under this parent for “Semantic promotion gate”; copy its required invariant exactly: “An unsupported target remains unqualified despite host-only results”.
- [ ] **UC-M01.07-C093-T02 · Observable terms:** Define each term in the “Semantic promotion gate” invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.
- [ ] **UC-M01.07-C093-T03 · Precondition set:** List the preconditions under which “An unsupported target remains unqualified despite host-only results” must hold for “Semantic promotion gate”; separate selected-profile conditions from unjustified exceptions.
- [ ] **UC-M01.07-C093-T04 · Transition coverage:** Map the “Semantic promotion gate” inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.
- [ ] **UC-M01.07-C093-T05 · Assertion artifact:** Implement the named assertion or explicit review rule for “Semantic promotion gate”; make an unavailable observation block the result instead of passing by default.
- [ ] **UC-M01.07-C093-T06 · Satisfying fixture:** Create a concrete “Semantic promotion gate” case that satisfies “An unsupported target remains unqualified despite host-only results”; record its expected observation before running the assertion or review.
- [ ] **UC-M01.07-C093-T07 · Violating fixture:** Create the source counterexample “A host test is reused as evidence of guest execution correctness” for “Semantic promotion gate”; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.
- [ ] **UC-M01.07-C093-T08 · Enforcement evidence:** Exercise the “Semantic promotion gate” guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.
- [ ] **UC-M01.07-C093-T09 · Regression linkage:** Link the “Semantic promotion gate” property to changes in language admission, translation outputs and application-result oracles; record which dependency or contract changes require rerunning it.
- [ ] **UC-M01.07-C093-T10 · Property disposition:** Compare the satisfying and violating “Semantic promotion gate” observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.

### UC-M01.07-C094 · Integration

**Original checklist item:** Integrate semantic promotion gate with language admission, translation outputs and application-result oracles; specify the actual exchanged fields or evidence references and test absent, stale or incompatible prerequisite inputs.

- [ ] **UC-M01.07-C094-T01 · Handoff map:** Draw or tabulate the producer-to-consumer handoff for “Semantic promotion gate” across language admission, translation outputs and application-result oracles; identify the receiving code or review gate, not just a folder location.
- [ ] **UC-M01.07-C094-T02 · Field mapping:** Map every “Semantic promotion gate” exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.
- [ ] **UC-M01.07-C094-T03 · Prerequisite identities:** Record the actual prerequisites for “Semantic promotion gate” (source dependency list: UC-M01.02, UC-M01.06); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.
- [ ] **UC-M01.07-C094-T04 · Ownership agreement:** Specify who owns “Semantic promotion gate” inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.
- [ ] **UC-M01.07-C094-T05 · Handoff implementation:** Connect “Semantic promotion gate” through the mapped seam using the real adapter or explicit specification reference; preserve “An unsupported target remains unqualified despite host-only results” across the handoff.
- [ ] **UC-M01.07-C094-T06 · Absent-input case:** Omit one required “Semantic promotion gate” prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.
- [ ] **UC-M01.07-C094-T07 · Stale-input case:** Supply an outdated “Semantic promotion gate” prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.
- [ ] **UC-M01.07-C094-T08 · Incompatible-input case:** Supply an incompatible “Semantic promotion gate” version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.
- [ ] **UC-M01.07-C094-T09 · Valid integration trace:** Run a valid “Semantic promotion gate” handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.
- [ ] **UC-M01.07-C094-T10 · Seam review:** Reconcile the “Semantic promotion gate” valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.

### UC-M01.07-C095 · Valid-case test

**Original checklist item:** Construct a valid worked example for semantic promotion gate; evaluate it against predeclared expected decisions and, where enforcement exists, run the corresponding conformance fixture.

- [ ] **UC-M01.07-C095-T01 · Valid fixture choice:** Select one concrete valid worked example for “Semantic promotion gate”; enumerate the model inputs and the expected review decision before evaluating it.
- [ ] **UC-M01.07-C095-T02 · Expected-result oracle:** Specify the “Semantic promotion gate” expected result independently of the implementation output; include the property “An unsupported target remains unqualified despite host-only results” and distinguish witness agreement from application correctness where relevant.
- [ ] **UC-M01.07-C095-T03 · Fixture material:** Create the concrete “Semantic promotion gate” inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.
- [ ] **UC-M01.07-C095-T04 · Target preparation:** Prepare the “Semantic promotion gate” prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.
- [ ] **UC-M01.07-C095-T05 · Initial-state record:** Record the initial “Semantic promotion gate” state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.
- [ ] **UC-M01.07-C095-T06 · Valid-path execution:** Evaluate the “Semantic promotion gate” example against the reviewed model; where a runtime mechanism exists, run its corresponding fixture and label those observations separately.
- [ ] **UC-M01.07-C095-T07 · Outcome comparison:** Compare every declared “Semantic promotion gate” output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.
- [ ] **UC-M01.07-C095-T08 · State and bounds check:** Inspect the “Semantic promotion gate” ownership/state effects and actual use of “Target matrix size and evidence freshness”; confirm the valid run stayed within the selected constraints.
- [ ] **UC-M01.07-C095-T09 · Repeatability check:** Repeat the same “Semantic promotion gate” case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.
- [ ] **UC-M01.07-C095-T10 · Positive evidence:** Attach the “Semantic promotion gate” fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.

### UC-M01.07-C096 · Negative test

**Original checklist item:** Negative case: A host test is reused as evidence of guest execution correctness. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M01.07-C096-T01 · Adverse-case definition:** Create a test record for the exact “Semantic promotion gate” source counterexample: “A host test is reused as evidence of guest execution correctness”; state which precondition or invariant it challenges.
- [ ] **UC-M01.07-C096-T02 · Safe fixture boundary:** Define the contained test boundary for “Semantic promotion gate”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M01.07-C096-T03 · Valid control:** Construct a valid “Semantic promotion gate” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M01.07-C096-T04 · Minimal adverse input:** Derive the “Semantic promotion gate” adverse fixture from the control with the smallest documented change needed to reproduce “A host test is reused as evidence of guest execution correctness”; retain that change as reproducible data.
- [ ] **UC-M01.07-C096-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Semantic promotion gate”; require “An unsupported target remains unqualified despite host-only results” and forbid a false-success verdict.
- [ ] **UC-M01.07-C096-T06 · Adverse execution:** Evaluate the “Semantic promotion gate” adverse case through the actual review/contract gate; where implemented, also observe the runtime refusal and keep the two evidence classes separate.
- [ ] **UC-M01.07-C096-T07 · Effect inspection:** Inspect “Semantic promotion gate” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M01.07-C096-T08 · Refusal versus failure:** Confirm the “Semantic promotion gate” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M01.07-C096-T09 · Reset and retention:** Restore only the disposable “Semantic promotion gate” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M01.07-C096-T10 · Negative regression:** Register the “Semantic promotion gate” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

### UC-M01.07-C097 · Change / failure test

**Original checklist item:** Exercise semantic promotion gate when a witness still agrees after application behavior or the supported input domain changes; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M01.07-C097-T01 · Scenario record:** Write the “Semantic promotion gate” change/failure scenario exactly as supplied: a witness still agrees after application behavior or the supported input domain changes; identify the property that must remain true: “An unsupported target remains unqualified despite host-only results”.
- [ ] **UC-M01.07-C097-T02 · Baseline capture:** Create a known-valid “Semantic promotion gate” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M01.07-C097-T03 · Injection map:** Locate the “Semantic promotion gate” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M01.07-C097-T04 · Disposition oracle:** Define the legal intermediate and final “Semantic promotion gate” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M01.07-C097-T05 · Controlled trigger:** Apply the controlled model-change scenario for “Semantic promotion gate”: a witness still agrees after application behavior or the supported input domain changes; retain the exact before/after declarations. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M01.07-C097-T06 · Intermediate inspection:** Review which “Semantic promotion gate” claims, approvals and evidence references become stale after the change; keep unresolved enforcement gaps visible.
- [ ] **UC-M01.07-C097-T07 · Recovery path:** Revise or explicitly refuse the changed “Semantic promotion gate” model under the documented compatibility policy; re-review affected claims before restoring their approval.
- [ ] **UC-M01.07-C097-T08 · Stale-evidence cleanup:** Invalidate superseded “Semantic promotion gate” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M01.07-C097-T09 · Repeat and compare:** Repeat the selected “Semantic promotion gate” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M01.07-C097-T10 · Failure evidence:** Publish the “Semantic promotion gate” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

### UC-M01.07-C098 · Bounds

**Original checklist item:** Define completeness and scaling criteria for target matrix size and evidence freshness; exercise larger inventories or fixture sets, and report uncovered scope instead of silently excluding it.

- [ ] **UC-M01.07-C098-T01 · Quantity inventory:** Create a measurement inventory for “Semantic promotion gate”: “Target matrix size and evidence freshness”; separate independent quantities and define units, counting boundaries and exclusions.
- [ ] **UC-M01.07-C098-T02 · Measurement method:** Choose how to observe each “Semantic promotion gate” quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.
- [ ] **UC-M01.07-C098-T03 · Budget decision:** Select justified coverage and completeness limits for “Semantic promotion gate”; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.
- [ ] **UC-M01.07-C098-T04 · Boundary fixtures:** Prepare normal, at-limit and over-limit “Semantic promotion gate” cases for “Target matrix size and evidence freshness”; document the generated input or inventory size and any infeasible case.
- [ ] **UC-M01.07-C098-T05 · Limit action:** Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded “Semantic promotion gate” limit; preserve “An unsupported target remains unqualified despite host-only results”.
- [ ] **UC-M01.07-C098-T06 · Normal measurement:** Run or review the normal “Semantic promotion gate” fixture and record actual consumption/coverage against the declared budget; retain the raw observation.
- [ ] **UC-M01.07-C098-T07 · At-limit measurement:** Exercise the “Semantic promotion gate” at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.
- [ ] **UC-M01.07-C098-T08 · Over-limit measurement:** Exercise the “Semantic promotion gate” over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.
- [ ] **UC-M01.07-C098-T09 · Uncovered-scope report:** List the “Semantic promotion gate” combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.
- [ ] **UC-M01.07-C098-T10 · Limit evidence:** Publish the selected “Semantic promotion gate” budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.

### UC-M01.07-C099 · Diagnostics / review

**Original checklist item:** Record the rationale, unresolved assumptions, enforcement gaps and re-review triggers for semantic promotion gate; make design-only claims visibly distinct from observed behavior.

- [ ] **UC-M01.07-C099-T01 · Review inventory:** List the “Semantic promotion gate” decisions and claims requiring review; distinguish source requirements, implementation observations and engineering assumptions.
- [ ] **UC-M01.07-C099-T02 · Rationale record:** Write the rationale for the selected “Semantic promotion gate” representation or policy; link each choice to the requirement rather than an unexplained preference.
- [ ] **UC-M01.07-C099-T03 · Assumption ledger:** Record unresolved “Semantic promotion gate” assumptions, their owner and what observation or decision would resolve them; do not treat unknowns as approvals.
- [ ] **UC-M01.07-C099-T04 · Boundary map:** Map each “Semantic promotion gate” claim to an actual guard or explicit design/review gate; flag gaps against “An unsupported target remains unqualified despite host-only results”.
- [ ] **UC-M01.07-C099-T05 · Counterexample review:** Walk reviewers through the “Semantic promotion gate” counterexample “A host test is reused as evidence of guest execution correctness”; record whether the model detects it and whether any runtime guard was actually exercised.
- [ ] **UC-M01.07-C099-T06 · Review outcome vocabulary:** Define approved, blocked, superseded and untested review outcomes for “Semantic promotion gate”; ensure the wording cannot be read as runtime enforcement evidence.
- [ ] **UC-M01.07-C099-T07 · Re-review triggers:** List “Semantic promotion gate” invalidation triggers, including the source change scenario: a witness still agrees after application behavior or the supported input domain changes; identify the affected claims and evidence.
- [ ] **UC-M01.07-C099-T08 · Sensitive-data review:** Inspect the “Semantic promotion gate” review record for secrets and unrelated user content; retain nonsecret references sufficient for reproducibility.
- [ ] **UC-M01.07-C099-T09 · Independent reading:** Have the “Semantic promotion gate” record read against the original acceptance criterion and language admission, translation outputs and application-result oracles; record misunderstandings or missing evidence as corrections.
- [ ] **UC-M01.07-C099-T10 · Review disposition:** Publish the “Semantic promotion gate” rationale, versioned review outcome, unresolved gaps and explicit next decision; keep blockers open until supported evidence resolves them.

### UC-M01.07-C100 · Evidence

**Original checklist item:** Attach implementation/specification references, fixture IDs, commands or seeds, expected and observed outcomes, environment and relevant subject digests for semantic promotion gate; label unexecuted checks as untested.

- [ ] **UC-M01.07-C100-T01 · Evidence inventory:** List the “Semantic promotion gate” claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.
- [ ] **UC-M01.07-C100-T02 · Artifact references:** Record the exact “Semantic promotion gate” implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.
- [ ] **UC-M01.07-C100-T03 · Fixture references:** Attach the “Semantic promotion gate” fixture IDs, input identities and oracle definition; preserve the source counterexample “A host test is reused as evidence of guest execution correctness” as a distinct evidence case.
- [ ] **UC-M01.07-C100-T04 · Reproduction recipe:** Write the commands, seeds or review procedure needed to reproduce “Semantic promotion gate”; include initial conditions and avoid invented executable paths.
- [ ] **UC-M01.07-C100-T05 · Environment record:** Record the actual “Semantic promotion gate” environment and selected host/backend/profile versions used; mark targets not executed here as untested.
- [ ] **UC-M01.07-C100-T06 · Expected versus observed:** Pair every “Semantic promotion gate” expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.
- [ ] **UC-M01.07-C100-T07 · Failure and limit records:** Attach “Semantic promotion gate” change/failure and bounds evidence where required; include uncovered “Target matrix size and evidence freshness” and unresolved violations of “An unsupported target remains unqualified despite host-only results”.
- [ ] **UC-M01.07-C100-T08 · Evidence hygiene:** Check the “Semantic promotion gate” bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.
- [ ] **UC-M01.07-C100-T09 · Reproduction review:** Have the “Semantic promotion gate” evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.
- [ ] **UC-M01.07-C100-T10 · Acceptance linkage:** Link the “Semantic promotion gate” evidence to its parent and UC-M01.07 original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.

