@echo off
setlocal
pushd "%~dp0" || exit /b 2
where py >nul 2>nul
if not errorlevel 1 goto run_py
where python >nul 2>nul
if not errorlevel 1 goto run_python
echo Python 3.10 or newer is required. Nothing has been installed.
set "RC=2"
goto finish
:run_py
py -3 -X utf8 -B "tools\validate.py" %*
set "RC=%ERRORLEVEL%"
goto finish
:run_python
python -X utf8 -B "tools\validate.py" %*
set "RC=%ERRORLEVEL%"
:finish
echo.
echo Planning-package validator exit code: %RC%
echo This does not build or test the unikernel.
popd
pause
endlocal & exit /b %RC%
