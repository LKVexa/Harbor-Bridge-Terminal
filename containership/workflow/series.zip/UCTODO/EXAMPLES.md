# Four example parent expansions

[Master index](INDEX.md) · Pack 2.0.0

These are repeated views of 40 children already included in the 96,000-task total. They illustrate a model negative case, transaction interruption, qualification reporting and operator-interface diagnostics. They are proposed tasks, not completed test results.

## UC-M01.01-C006 — Actor inventory

**Original checklist item:** Negative case: A cargo author claims an operator role in its manifest. Build a reproducible fixture and assert the documented refusal, containment, recovery or degraded outcome without false success.

- [ ] **UC-M01.01-C006-T01 · Adverse-case definition:** Create a test record for the exact “Actor inventory” source counterexample: “A cargo author claims an operator role in its manifest”; state which precondition or invariant it challenges.
- [ ] **UC-M01.01-C006-T02 · Safe fixture boundary:** Define the contained test boundary for “Actor inventory”. Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems. Record the allowed effects and stop conditions.
- [ ] **UC-M01.01-C006-T03 · Valid control:** Construct a valid “Actor inventory” control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.
- [ ] **UC-M01.01-C006-T04 · Minimal adverse input:** Derive the “Actor inventory” adverse fixture from the control with the smallest documented change needed to reproduce “A cargo author claims an operator role in its manifest”; retain that change as reproducible data.
- [ ] **UC-M01.01-C006-T05 · Refusal oracle:** Predeclare the expected refusal, containment, recovery or degraded outcome for “Actor inventory”; require “Display names do not confer authority” and forbid a false-success verdict.
- [ ] **UC-M01.01-C006-T06 · Adverse execution:** Evaluate the “Actor inventory” adverse case through the actual review/contract gate; where implemented, also observe the runtime refusal and keep the two evidence classes separate.
- [ ] **UC-M01.01-C006-T07 · Effect inspection:** Inspect “Actor inventory” state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.
- [ ] **UC-M01.01-C006-T08 · Refusal versus failure:** Confirm the “Actor inventory” result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.
- [ ] **UC-M01.01-C006-T09 · Reset and retention:** Restore only the disposable “Actor inventory” fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.
- [ ] **UC-M01.01-C006-T10 · Negative regression:** Register the “Actor inventory” counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.

## UC-M07.01-C007 — Transaction participant inventory

**Original checklist item:** Exercise transaction participant inventory when the process terminates between two participant mutations; check the invariant and record the final disposition, invalidated evidence and any remaining owned resources or review blockers.

- [ ] **UC-M07.01-C007-T01 · Scenario record:** Write the “Transaction participant inventory” change/failure scenario exactly as supplied: the process terminates between two participant mutations; identify the property that must remain true: “A successful transaction accounts for every affected resource”.
- [ ] **UC-M07.01-C007-T02 · Baseline capture:** Create a known-valid “Transaction participant inventory” baseline and record its subject identities, state and accepted evidence before introducing the scenario.
- [ ] **UC-M07.01-C007-T03 · Injection map:** Locate the “Transaction participant inventory” operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.
- [ ] **UC-M07.01-C007-T04 · Disposition oracle:** Define the legal intermediate and final “Transaction participant inventory” outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.
- [ ] **UC-M07.01-C007-T05 · Controlled trigger:** Introduce the controlled “Transaction participant inventory” scenario in the disposable fixture: the process terminates between two participant mutations; record its exact timing or changed input. Use an authorized isolated fixture and bounded execution/review scope.
- [ ] **UC-M07.01-C007-T06 · Intermediate inspection:** Inspect the “Transaction participant inventory” actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.
- [ ] **UC-M07.01-C007-T07 · Recovery path:** Run the documented recovery, cancellation, revalidation or explicit refusal for “Transaction participant inventory”; do not assume moving a file or retrying establishes recovery.
- [ ] **UC-M07.01-C007-T08 · Stale-evidence cleanup:** Invalidate superseded “Transaction participant inventory” evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.
- [ ] **UC-M07.01-C007-T09 · Repeat and compare:** Repeat the selected “Transaction participant inventory” scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.
- [ ] **UC-M07.01-C007-T10 · Failure evidence:** Publish the “Transaction participant inventory” before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.

## UC-M02.08-C009 — ABI probe inventory

**Original checklist item:** Report ABI probe inventory results with executed, failed, skipped and unavailable cases separated; preserve the underlying observations and do not manufacture missing measurements.

- [ ] **UC-M02.08-C009-T01 · Result inventory:** Enumerate the required “ABI probe inventory” qualification cases and intended targets before aggregating results; keep the planned denominator visible.
- [ ] **UC-M02.08-C009-T02 · Verdict schema:** Define separate executed-pass, executed-fail, skipped, unavailable and untested outcomes for “ABI probe inventory”; document how incomplete cases block relevant claims.
- [ ] **UC-M02.08-C009-T03 · Identity fields:** Attach the actual target, fixture, configuration and revision identifiers to each “ABI probe inventory” result; do not attribute host-only evidence to a guest or another OS.
- [ ] **UC-M02.08-C009-T04 · Observation capture:** Capture bounded raw “ABI probe inventory” observations and harness errors; retain enough information to verify the reported oracle comparison.
- [ ] **UC-M02.08-C009-T05 · Aggregation rules:** Implement the “ABI probe inventory” count/reduction rule so failures and missing measurements cannot disappear; preserve “Every claimed ABI capability has a conformance probe”.
- [ ] **UC-M02.08-C009-T06 · Failure visibility:** Feed a failing “ABI probe inventory” control through the report path; assert the exact failed case and underlying observation remain visible.
- [ ] **UC-M02.08-C009-T07 · Missing-result visibility:** Withhold a required “ABI probe inventory” measurement or target; verify the report uses unavailable/untested rather than a fabricated zero or passing value.
- [ ] **UC-M02.08-C009-T08 · Bounds and redaction:** Check “ABI probe inventory” report size and retention against “ABI surface size and probe count”; remove secrets while retaining fixture and subject references.
- [ ] **UC-M02.08-C009-T09 · Report reconciliation:** Reconcile the “ABI probe inventory” summary with every underlying case record; account for the full planned denominator and all omitted scope.
- [ ] **UC-M02.08-C009-T10 · Qualification handoff:** Publish the “ABI probe inventory” report with measured observations, coverage limits and blockers; state which actual targets remain unqualified.

## UC-M10.04-C009 — Health data model

**Original checklist item:** Provide explicit text and observed-state diagnostics for health data model; show stale data, denied authority and the affected generation without exposing secrets.

- [ ] **UC-M10.04-C009-T01 · Display-state inventory:** List current, stale, unavailable, denied and failed states for “Health data model”; identify the authoritative API/observation for each displayed value.
- [ ] **UC-M10.04-C009-T02 · Authority text:** Write explicit nonsecret “Health data model” text for actor permission, selected generation and affected scope; do not rely solely on color or animation.
- [ ] **UC-M10.04-C009-T03 · Freshness fields:** Show the “Health data model” observation age and source identity; distinguish last-known state from a current verified result.
- [ ] **UC-M10.04-C009-T04 · Failure text:** Define the “Health data model” error and blocked-reason text; retain the actual final disposition rather than replacing it with a generic healthy view.
- [ ] **UC-M10.04-C009-T05 · Permission behavior:** Test the “Health data model” view with denied authority; verify unavailable actions and explanatory text agree with the authoritative decision.
- [ ] **UC-M10.04-C009-T06 · Stale-state behavior:** Exercise “Health data model” when a workload stops while the view still has its last successful observation cached; ensure obsolete observations cannot imply current success.
- [ ] **UC-M10.04-C009-T07 · Sensitive-data check:** Inject only synthetic secret markers into the “Health data model” diagnostic path; verify none appear in the rendered view or exported text.
- [ ] **UC-M10.04-C009-T08 · Bounded updates:** Exercise “Health data model” update saturation within “Status fields and payload bytes”; verify important authority and final-outcome information remains visible.
- [ ] **UC-M10.04-C009-T09 · API reconciliation:** Compare the “Health data model” displayed text and available controls with actual management results; document discrepancies and preserve “One green status cannot stand in for all health dimensions”.
- [ ] **UC-M10.04-C009-T10 · UI diagnostic evidence:** Attach the “Health data model” state fixtures, observed text, API records and unresolved presentation errors; distinguish a mock view from a connected implementation.

