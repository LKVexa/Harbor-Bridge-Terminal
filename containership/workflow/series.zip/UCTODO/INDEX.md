# Unikernel Containership — Nested To-Do Index

**Pack 2.0.0 · UC-2.2.0 baseline · Source Checklist Pack 1.0.0**

**96 components · 9,600 unchanged parent checklist items · 96,000 new child tasks.** Each parent has exactly ten children; each component has 1,000 children. All remain unchecked / `TODO`.

Open one of the 96 component files below. [README](README.md) explains applicability and evidence; [ALL.md](ALL.md) is the large full-text view; [VALIDATION.md](VALIDATION.md) reports package checks. [SCHEMA.md](SCHEMA.md) documents the machine-readable records. This is a planning deliverable, not an implementation or runtime release.

| Workstream | Milestone | Components | Parents | To-dos |
|---|---|---:|---:|---:|
| [01. Architecture and executable contracts](w/01.md) | A | 8 | 800 | 8,000 |
| [02. Bootable unikernel guest](w/02.md) | B | 8 | 800 | 8,000 |
| [03. Host isolation and supervision](w/03.md) | C | 8 | 800 | 8,000 |
| [04. Build and artifact production](w/04.md) | B | 8 | 800 | 8,000 |
| [05. Workload orchestration and scheduling](w/05.md) | C | 8 | 800 | 8,000 |
| [06. Control plane, identity and policy](w/06.md) | C | 8 | 800 | 8,000 |
| [07. Persistence, transactions and recovery](w/07.md) | A | 8 | 800 | 8,000 |
| [08. Guest communication and data plane](w/08.md) | C | 8 | 800 | 8,000 |
| [09. Trust, integrity and adversarial security](w/09.md) | C | 8 | 800 | 8,000 |
| [10. Observability and operator experience](w/10.md) | C | 8 | 800 | 8,000 |
| [11. Optional multi-host federation](w/11.md) | D | 8 | 800 | 8,000 |
| [12. Qualification, packaging and release](w/12.md) | C | 8 | 800 | 8,000 |

## Component navigation

| Component | Workstream | Priority | File |
|---|---:|---|---|
| UC-M01.01 — Trust-boundary and capability model | 01 | P0 | [1,000 to-dos](c/01/UC-M01.01.md) |
| UC-M01.02 — Versioned runtime and guest contracts | 01 | P0 | [1,000 to-dos](c/01/UC-M01.02.md) |
| UC-M01.03 — Lifecycle state machine | 01 | P0 | [1,000 to-dos](c/01/UC-M01.03.md) |
| UC-M01.04 — Canonical manifest and schema evolution | 01 | P0 | [1,000 to-dos](c/01/UC-M01.04.md) |
| UC-M01.05 — Stable workload identity and generations | 01 | P1 | [1,000 to-dos](c/01/UC-M01.05.md) |
| UC-M01.06 — Closed-world source and dependency inventory | 01 | P0 | [1,000 to-dos](c/01/UC-M01.06.md) |
| UC-M01.07 — Application semantics versus witness contract | 01 | P0 | [1,000 to-dos](c/01/UC-M01.07.md) |
| UC-M01.08 — Artifact and dependency graph | 01 | P1 | [1,000 to-dos](c/01/UC-M01.08.md) |
| UC-M02.01 — Chosen library-OS integration | 02 | P0 | [1,000 to-dos](c/02/UC-M02.01.md) |
| UC-M02.02 — Boot ABI and startup path | 02 | P0 | [1,000 to-dos](c/02/UC-M02.02.md) |
| UC-M02.03 — Linker, image layout and permissions | 02 | P0 | [1,000 to-dos](c/02/UC-M02.03.md) |
| UC-M02.04 — Guest allocator and memory lifecycle | 02 | P0 | [1,000 to-dos](c/02/UC-M02.04.md) |
| UC-M02.05 — Guest execution loop and scheduling | 02 | P0 | [1,000 to-dos](c/02/UC-M02.05.md) |
| UC-M02.06 — Clock and entropy interfaces | 02 | P0 | [1,000 to-dos](c/02/UC-M02.06.md) |
| UC-M02.07 — Minimal console, block and transport drivers | 02 | P0 | [1,000 to-dos](c/02/UC-M02.07.md) |
| UC-M02.08 — Guest ABI conformance and panic reporting | 02 | P0 | [1,000 to-dos](c/02/UC-M02.08.md) |
| UC-M03.01 — Pluggable execution backend boundary | 03 | P0 | [1,000 to-dos](c/03/UC-M03.01.md) |
| UC-M03.02 — Real hypervisor or tender integration | 03 | P0 | [1,000 to-dos](c/03/UC-M03.02.md) |
| UC-M03.03 — Host process sandbox profile | 03 | P0 | [1,000 to-dos](c/03/UC-M03.03.md) |
| UC-M03.04 — Enforced default-deny networking | 03 | P0 | [1,000 to-dos](c/03/UC-M03.04.md) |
| UC-M03.05 — CPU, memory, I/O and process quotas | 03 | P0 | [1,000 to-dos](c/03/UC-M03.05.md) |
| UC-M03.06 — Supervisor, watchdog and child-tree cleanup | 03 | P0 | [1,000 to-dos](c/03/UC-M03.06.md) |
| UC-M03.07 — Privilege-separated resource broker | 03 | P0 | [1,000 to-dos](c/03/UC-M03.07.md) |
| UC-M03.08 — Host capability and isolation evidence | 03 | P0 | [1,000 to-dos](c/03/UC-M03.08.md) |
| UC-M04.01 — Locked toolchain and dependency closure | 04 | P0 | [1,000 to-dos](c/04/UC-M04.01.md) |
| UC-M04.02 — Hermetic and reproducible build recipe | 04 | P0 | [1,000 to-dos](c/04/UC-M04.02.md) |
| UC-M04.03 — Sandboxed build workers | 04 | P0 | [1,000 to-dos](c/04/UC-M04.03.md) |
| UC-M04.04 — Semantic translation validation | 04 | P0 | [1,000 to-dos](c/04/UC-M04.04.md) |
| UC-M04.05 — Immutable content-addressed image store | 04 | P0 | [1,000 to-dos](c/04/UC-M04.05.md) |
| UC-M04.06 — Software bill of materials and license inventory | 04 | P1 | [1,000 to-dos](c/04/UC-M04.06.md) |
| UC-M04.07 — Build provenance attestations | 04 | P0 | [1,000 to-dos](c/04/UC-M04.07.md) |
| UC-M04.08 — Authenticated image admission | 04 | P0 | [1,000 to-dos](c/04/UC-M04.08.md) |
| UC-M05.01 — Executable workload DAG planner | 05 | P0 | [1,000 to-dos](c/05/UC-M05.01.md) |
| UC-M05.02 — Resource-aware placement scheduler | 05 | P1 | [1,000 to-dos](c/05/UC-M05.02.md) |
| UC-M05.03 — Bounded queue and fairness control | 05 | P1 | [1,000 to-dos](c/05/UC-M05.03.md) |
| UC-M05.04 — Idempotent reconciliation controller | 05 | P0 | [1,000 to-dos](c/05/UC-M05.04.md) |
| UC-M05.05 — Workload readiness and liveness checks | 05 | P0 | [1,000 to-dos](c/05/UC-M05.05.md) |
| UC-M05.06 — Graceful stop and drain protocol | 05 | P0 | [1,000 to-dos](c/05/UC-M05.06.md) |
| UC-M05.07 — Safe restart and failure budget policy | 05 | P1 | [1,000 to-dos](c/05/UC-M05.07.md) |
| UC-M05.08 — Replica scaling and placement migration | 05 | P2 | [1,000 to-dos](c/05/UC-M05.08.md) |
| UC-M06.01 — Machine-stable management API | 06 | P1 | [1,000 to-dos](c/06/UC-M06.01.md) |
| UC-M06.02 — Operator and service authentication | 06 | P0 | [1,000 to-dos](c/06/UC-M06.02.md) |
| UC-M06.03 — Least-privilege authorization | 06 | P0 | [1,000 to-dos](c/06/UC-M06.03.md) |
| UC-M06.04 — Tenant and workspace isolation | 06 | P0 | [1,000 to-dos](c/06/UC-M06.04.md) |
| UC-M06.05 — Policy-as-code admission evaluator | 06 | P0 | [1,000 to-dos](c/06/UC-M06.05.md) |
| UC-M06.06 — Typed configuration and migration | 06 | P1 | [1,000 to-dos](c/06/UC-M06.06.md) |
| UC-M06.07 — Secret storage and injection boundary | 06 | P0 | [1,000 to-dos](c/06/UC-M06.07.md) |
| UC-M06.08 — Tamper-evident operator audit trail | 06 | P1 | [1,000 to-dos](c/06/UC-M06.08.md) |
| UC-M07.01 — Cross-resource durable transaction coordinator | 07 | P0 | [1,000 to-dos](c/07/UC-M07.01.md) |
| UC-M07.02 — Checkpoint and history rollover | 07 | P0 | [1,000 to-dos](c/07/UC-M07.02.md) |
| UC-M07.03 — Atomic multi-container tick commit | 07 | P0 | [1,000 to-dos](c/07/UC-M07.03.md) |
| UC-M07.04 — Strict state schema and decoder boundary | 07 | P0 | [1,000 to-dos](c/07/UC-M07.04.md) |
| UC-M07.05 — Workspace capacity reservation | 07 | P0 | [1,000 to-dos](c/07/UC-M07.05.md) |
| UC-M07.06 — Reachability-based garbage collection | 07 | P1 | [1,000 to-dos](c/07/UC-M07.06.md) |
| UC-M07.07 — Portable snapshots and state migrations | 07 | P1 | [1,000 to-dos](c/07/UC-M07.07.md) |
| UC-M07.08 — Verified rollback and recovery commands | 07 | P0 | [1,000 to-dos](c/07/UC-M07.08.md) |
| UC-M08.01 — Typed guest-host IPC ABI | 08 | P0 | [1,000 to-dos](c/08/UC-M08.01.md) |
| UC-M08.02 — Message framing and versioned serialization | 08 | P0 | [1,000 to-dos](c/08/UC-M08.02.md) |
| UC-M08.03 — Backpressure and bounded channels | 08 | P0 | [1,000 to-dos](c/08/UC-M08.03.md) |
| UC-M08.04 — Ordering, idempotency and replay semantics | 08 | P0 | [1,000 to-dos](c/08/UC-M08.04.md) |
| UC-M08.05 — Deadlines and cancellation propagation | 08 | P0 | [1,000 to-dos](c/08/UC-M08.05.md) |
| UC-M08.06 — Shared-memory or buffer grant safety | 08 | P1 | [1,000 to-dos](c/08/UC-M08.06.md) |
| UC-M08.07 — Optional policy-controlled network stack | 08 | P2 | [1,000 to-dos](c/08/UC-M08.07.md) |
| UC-M08.08 — Optional service discovery and routing | 08 | P2 | [1,000 to-dos](c/08/UC-M08.08.md) |
| UC-M09.01 — Independent key lifecycle | 09 | P0 | [1,000 to-dos](c/09/UC-M09.01.md) |
| UC-M09.02 — Anti-rollback update metadata | 09 | P0 | [1,000 to-dos](c/09/UC-M09.02.md) |
| UC-M09.03 — Verified executable-cache reads | 09 | P0 | [1,000 to-dos](c/09/UC-M09.03.md) |
| UC-M09.04 — Image-state-policy binding | 09 | P0 | [1,000 to-dos](c/09/UC-M09.04.md) |
| UC-M09.05 — Proof and digest assurance hierarchy | 09 | P0 | [1,000 to-dos](c/09/UC-M09.05.md) |
| UC-M09.06 — Native runtime memory-safety audit | 09 | P0 | [1,000 to-dos](c/09/UC-M09.06.md) |
| UC-M09.07 — Guest escape and side-channel assessment | 09 | P0 | [1,000 to-dos](c/09/UC-M09.07.md) |
| UC-M09.08 — Security advisory and dependency response | 09 | P1 | [1,000 to-dos](c/09/UC-M09.08.md) |
| UC-M10.01 — Structured bounded logs | 10 | P0 | [1,000 to-dos](c/10/UC-M10.01.md) |
| UC-M10.02 — Resource and latency metrics | 10 | P1 | [1,000 to-dos](c/10/UC-M10.02.md) |
| UC-M10.03 — End-to-end execution traces | 10 | P1 | [1,000 to-dos](c/10/UC-M10.03.md) |
| UC-M10.04 — Unified live health view | 10 | P1 | [1,000 to-dos](c/10/UC-M10.04.md) |
| UC-M10.05 — Capacity and saturation alarms | 10 | P0 | [1,000 to-dos](c/10/UC-M10.05.md) |
| UC-M10.06 — Replay and interactive debugger | 10 | P1 | [1,000 to-dos](c/10/UC-M10.06.md) |
| UC-M10.07 — Crash dumps and support bundle export | 10 | P1 | [1,000 to-dos](c/10/UC-M10.07.md) |
| UC-M10.08 — Operator UI with explicit authority cues | 10 | P2 | [1,000 to-dos](c/10/UC-M10.08.md) |
| UC-M11.01 — Authenticated worker identity | 11 | P2 | [1,000 to-dos](c/11/UC-M11.01.md) |
| UC-M11.02 — Secure inter-host transport | 11 | P2 | [1,000 to-dos](c/11/UC-M11.02.md) |
| UC-M11.03 — Durable consensus control store | 11 | P2 | [1,000 to-dos](c/11/UC-M11.03.md) |
| UC-M11.04 — Leases, fencing and ownership transfer | 11 | P2 | [1,000 to-dos](c/11/UC-M11.04.md) |
| UC-M11.05 — Partition and failure-domain placement | 11 | P2 | [1,000 to-dos](c/11/UC-M11.05.md) |
| UC-M11.06 — Distributed artifact and state replication | 11 | P2 | [1,000 to-dos](c/11/UC-M11.06.md) |
| UC-M11.07 — Rolling upgrades and compatibility negotiation | 11 | P2 | [1,000 to-dos](c/11/UC-M11.07.md) |
| UC-M11.08 — Multi-host disaster-recovery qualification | 11 | P2 | [1,000 to-dos](c/11/UC-M11.08.md) |
| UC-M12.01 — Real operating-system CI matrix | 12 | P0 | [1,000 to-dos](c/12/UC-M12.01.md) |
| UC-M12.02 — Parser fuzzing campaign | 12 | P0 | [1,000 to-dos](c/12/UC-M12.02.md) |
| UC-M12.03 — State-machine and property-based tests | 12 | P0 | [1,000 to-dos](c/12/UC-M12.03.md) |
| UC-M12.04 — Crash, disk-full and concurrency fault injection | 12 | P0 | [1,000 to-dos](c/12/UC-M12.04.md) |
| UC-M12.05 — Performance and capacity qualification | 12 | P1 | [1,000 to-dos](c/12/UC-M12.05.md) |
| UC-M12.06 — Optional OCI packaging/runtime conformance | 12 | P2 | [1,000 to-dos](c/12/UC-M12.06.md) |
| UC-M12.07 — Authenticated portable installer and updater | 12 | P1 | [1,000 to-dos](c/12/UC-M12.07.md) |
| UC-M12.08 — Evidence-based release promotion and runbooks | 12 | P0 | [1,000 to-dos](c/12/UC-M12.08.md) |

## Dependency-valid navigation order

This is the source order for finding prerequisites, not a requirement to implement unselected optional features.

`UC-M01.01`, `UC-M01.02`, `UC-M01.03`, `UC-M01.04`, `UC-M01.05`, `UC-M01.06`, `UC-M01.07`, `UC-M01.08`, `UC-M07.01`, `UC-M02.01`, `UC-M04.01`, `UC-M07.02`, `UC-M02.02`, `UC-M04.02`, `UC-M07.03`, `UC-M02.03`, `UC-M02.06`, `UC-M04.05`, `UC-M12.03`, `UC-M02.04`, `UC-M04.06`, `UC-M04.07`, `UC-M02.05`, `UC-M02.07`, `UC-M04.08`, `UC-M02.08`, `UC-M03.01`, `UC-M04.04`, `UC-M03.02`, `UC-M05.01`, `UC-M03.03`, `UC-M05.04`, `UC-M09.06`, `UC-M03.04`, `UC-M03.05`, `UC-M03.07`, `UC-M06.01`, `UC-M10.03`, `UC-M03.06`, `UC-M03.08`, `UC-M04.03`, `UC-M05.02`, `UC-M06.02`, `UC-M07.04`, `UC-M07.05`, `UC-M08.01`, `UC-M09.07`, `UC-M12.06`, `UC-M05.03`, `UC-M05.05`, `UC-M06.03`, `UC-M07.06`, `UC-M08.02`, `UC-M12.01`, `UC-M05.06`, `UC-M06.04`, `UC-M06.05`, `UC-M08.03`, `UC-M08.04`, `UC-M09.01`, `UC-M10.02`, `UC-M12.02`, `UC-M05.07`, `UC-M06.06`, `UC-M06.07`, `UC-M06.08`, `UC-M08.05`, `UC-M08.06`, `UC-M08.07`, `UC-M09.02`, `UC-M09.03`, `UC-M09.05`, `UC-M10.04`, `UC-M10.05`, `UC-M10.06`, `UC-M11.01`, `UC-M12.05`, `UC-M05.08`, `UC-M07.07`, `UC-M08.08`, `UC-M09.08`, `UC-M10.01`, `UC-M11.02`, `UC-M07.08`, `UC-M09.04`, `UC-M10.07`, `UC-M11.03`, `UC-M10.08`, `UC-M11.04`, `UC-M11.06`, `UC-M12.04`, `UC-M12.07`, `UC-M11.05`, `UC-M12.08`, `UC-M11.07`, `UC-M11.08`.
