#!/usr/bin/env python3
"""Read-only integrity/structure validation for this planning pack, not unikernel qualification."""
from __future__ import annotations
import argparse
import ast
from collections import Counter, defaultdict
import hashlib
import json
from pathlib import Path, PurePosixPath
import re
import sys
import unicodedata
import zipfile

PARENT_RE=re.compile(r'^### (UC-M\d{2}\.\d{2}-C\d{3}) · (.+)$')
CHILD_RE=re.compile(r'^- \[([ xX])\] \*\*(UC-M\d{2}\.\d{2}-C\d{3}-T\d{2}) · (.+?):\*\* (.+)$')
KINDS=['contract','delivery','invariant','integration','valid_case','negative_case','change_or_failure','bounds','diagnostics_or_review','evidence']
LABELS=['Contract','Delivery','Invariant','Integration','Valid-case test','Negative test','Change / failure test','Bounds','Diagnostics / review','Evidence']
ALLOWED_STATUS={'TODO','IN_PROGRESS','BLOCKED','DONE','NOT_APPLICABLE'}


def digest(path:Path)->str:
    h=hashlib.sha256()
    with path.open('rb') as fh:
        for block in iter(lambda:fh.read(1024*1024),b''):h.update(block)
    return h.hexdigest()


def load_jsonl(path:Path)->list:
    rows=[]
    with path.open(encoding='utf-8') as fh:
        for n,line in enumerate(fh,1):
            if not line.strip():raise ValueError(f'{path.name}: blank JSONL line {n}')
            try:r=json.loads(line)
            except json.JSONDecodeError as exc:raise ValueError(f'{path.name}:{n}: {exc}') from exc
            if not isinstance(r,dict):raise ValueError(f'{path.name}:{n}: expected object')
            rows.append(r)
    return rows


def within(root:Path,name:str)->Path:
    rel=PurePosixPath(name)
    if rel.is_absolute() or '..' in rel.parts or '\\' in name or ':' in name:
        raise ValueError(f'Unsafe package path: {name}')
    path=root.joinpath(*rel.parts)
    # Reject link-based aliases even when they happen to stay in root.
    p=path
    while p!=root:
        if p.is_symlink():raise ValueError(f'Linked package path: {name}')
        p=p.parent
    return path


def parse_md(path:Path):
    parents={};children={};links=[]; current=None;duplicates=[]
    for line in path.read_text(encoding='utf-8').splitlines():
        match=PARENT_RE.match(line)
        if match:
            current=match.group(1)
            if current in parents:duplicates.append(current)
            parents[current]={'label':match.group(2),'text':None,'children':[]}
        elif line.startswith('**Original checklist item:** '):
            if not current:raise ValueError(f'{path}: source statement without parent')
            parents[current]['text']=line[len('**Original checklist item:** '):]
        elif line.startswith('- ['):
            match=CHILD_RE.match(line)
            if not match:raise ValueError(f'{path}: malformed child checklist line')
            checked,sid,label,text=match.groups()
            if sid in children:duplicates.append(sid)
            if not current:raise ValueError(f'{path}: child without parent')
            children[sid]=(current,label,text,checked)
            parents[current]['children'].append(sid)
        for link in re.findall(r'\]\(([^)]+)\)',line):
            if not re.match(r'^[a-zA-Z][a-zA-Z0-9+.-]*:',link):links.append(link)
    return parents,children,links,duplicates


def validate(root:Path, structure_only:bool=False):
    checks=[]
    def check(name:str,ok:bool,detail:str=''):
        checks.append({'check':name,'status':'PASS' if ok else 'FAIL','detail':detail})
    m=json.loads((root/'data/manifest.json').read_text(encoding='utf-8'))
    sm=json.loads((root/'s/manifest.json').read_text(encoding='utf-8'))
    parents=load_jsonl(root/'data/parents.jsonl')
    children=load_jsonl(root/'data/subtasks.jsonl')
    trace=load_jsonl(root/'data/trace.jsonl')
    cs=m['components'];cids={c['id'] for c in cs}
    pm={p['id']:p for p in parents};cm={c['id']:c for c in cs};childmap={r['id']:r for r in children}
    check('Pack identity',m['schema']=='UC/NESTED_TODO_PACK/2' and m['pack_version']=='2.0.0' and m['baseline']=='UC-2.2.0' and m['source_checklist_pack_version']=='1.0.0')
    check('Source snapshots match recorded SHA-256',all(digest(within(root,s['path']))==s['sha256'] for s in m['sources']),f"{len(m['sources'])} preserved inputs")
    with zipfile.ZipFile(root/'s/checklists.zip') as z:
        check('Original checklist archive CRC',z.testzip() is None)
        check('Original JSONL retained byte-for-byte',z.read('UC100/data/tasks.jsonl')==(root/'data/parents.jsonl').read_bytes())
        check('Original manifest and roadmap retained',z.read('UC100/data/manifest.json')==(root/'s/manifest.json').read_bytes() and z.read('UC100/s/roadmap.md')==(root/'s/roadmap.md').read_bytes())
        archmaster=z.read('UC100/ALL.md').decode('utf-8')
        standalone=(root/'s/checklist.md').read_text(encoding='utf-8')
        normalized=standalone.replace('Preserved roadmap (included in the ZIP at `s/roadmap.md`)','[Preserved roadmap](s/roadmap.md)')
        check('Source master equivalence',normalized==archmaster,'The original standalone master differs only in 96 source-trace link descriptions; its bytes are preserved.')
        sourcehashes=[]
        for line in z.read('UC100/SHA256SUMS.txt').decode().splitlines():
            if line.strip():
                h,n=line.split('  ',1)
                sourcehashes.append(hashlib.sha256(z.read('UC100/'+n)).hexdigest()==h)
        check('Original archive member checksums',all(sourcehashes),f'{len(sourcehashes)} original checksum entries')
    check('All component metadata unchanged',cs==sm['components'],'Includes IDs, titles, descriptions, acceptance, scope, priorities, dependencies and focus definitions.')
    check('Component and workstream coverage',len(cs)==96 and len(cids)==96 and Counter(c['workstream'] for c in cs)=={w:8 for w in range(1,13)})
    check('Parent coverage and unique IDs',len(parents)==9600 and len(pm)==9600)
    check('Subtask coverage and unique IDs',len(children)==96000 and len(childmap)==96000)
    check('Parent grouping and numbering',all(p['component_id'] in cids and p['id']==f"{p['component_id']}-C{p['number']:03d}" and 1<=p['number']<=100 and p['focus_number']==(p['number']-1)//10+1 and p['kind']==KINDS[(p['number']-1)%10] for p in parents) and Counter(p['component_id'] for p in parents)=={cid:100 for cid in cids})
    counts=Counter(r['parent_id'] for r in children)
    check('Exactly ten children per original parent',counts=={pid:10 for pid in pm})
    check('Exactly 1,000 children per component',Counter(r['component_id'] for r in children)=={cid:1000 for cid in cids})
    check('Exactly 8,000 children per workstream',Counter(r['workstream'] for r in children)=={w:8000 for w in range(1,13)})
    check('Child-parent identity and classification',all(r['parent_id'] in pm and r['id']==f"{r['parent_id']}-T{r['number']:02d}" and 1<=r['number']<=10 and r['component_id']==pm[r['parent_id']]['component_id'] and r['focus_number']==pm[r['parent_id']]['focus_number'] and r['kind']==pm[r['parent_id']]['kind'] and r['workstream']==pm[r['parent_id']]['workstream'] for r in children))
    expected=[f'{p["id"]}-T{i:02d}' for p in parents for i in range(1,11)]
    check('Stable source ordering',list(childmap)==expected)
    check('All ten parent check types retained',Counter(p['kind'] for p in parents)=={k:960 for k in KINDS} and Counter(r['kind'] for r in children)=={k:9600 for k in KINDS})
    check('Editable tracking fields well formed',all(r['status'] in ALLOWED_STATUS and (r['owner'] is None or isinstance(r['owner'],str)) and isinstance(r['evidence'],list) and isinstance(r['notes'],str) and isinstance(r['text'],str) and len(r['text'])>40 and isinstance(r['deliverable'],str) and bool(r['deliverable']) for r in children))
    if not structure_only:
        check('Initial planning status is TODO',all(r['status']=='TODO' and r['owner'] is None and not r['evidence'] and not r['notes'] for r in children),'No implementation completion is claimed.')
    check('Focus context appears in every child',all(pm[r['parent_id']]['focus_title'] in r['text'] for r in children))
    check('Trace coverage and source hashes',len(trace)==9600 and len({r['parent_id'] for r in trace})==9600 and all(r['parent_id'] in pm and r['source_text_sha256']==hashlib.sha256(pm[r['parent_id']]['text'].encode('utf-8')).hexdigest() and r['child_count']==10 and r['first_child_id']==r['parent_id']+'-T01' and r['last_child_id']==r['parent_id']+'-T10' and r['component_path']==cm[r['component_id']]['path'] for r in trace))
    edges=sum(len(c['dependencies']) for c in cs)
    check('Dependency references unchanged',edges==212 and all(d in cids for c in cs for d in c['dependencies']))
    order=m['dependency_order']; pos={cid:i for i,cid in enumerate(order)}
    check('Dependency graph remains acyclic',len(order)==96 and set(order)==cids and all(pos[d]<pos[c['id']] for c in cs for d in c['dependencies']) and order==sm['dependency_order'])
    check('No added hard task dependencies',m['expansion_policy']['new_hard_dependencies'] is False and all('dependencies' not in r for r in children))
    all_md_parents={};all_md_children={};duplicate_md=[];link_problems=[];focus_counts=[];unticked=True
    for c in cs:
        path=within(root,c['path'])
        mp,mc,links,duplicates=parse_md(path)
        all_md_parents.update(mp);all_md_children.update(mc);duplicate_md.extend(duplicates)
        focus_counts.append(len(re.findall(r'^## \d{2}\. ',path.read_text(encoding='utf-8'),re.M))==10)
        if len(mp)!=100 or len(mc)!=1000:duplicate_md.append(c['id']+': count mismatch')
        if any(v[3]!=' ' for v in mc.values()):unticked=False
        for link in links:
            dest=(path.parent/link.split('#')[0]).resolve()
            if not dest.is_relative_to(root) or not dest.exists():link_problems.append(c['path']+': '+link)
    check('All 96 component Markdown files complete',len(all_md_parents)==9600 and len(all_md_children)==96000 and not duplicate_md and len(list((root/'c').glob('*/*.md')))==96)
    check('All 960 focus sections retained',all(focus_counts) and len(focus_counts)==96)
    check('Original parent text preserved in components',set(all_md_parents)==set(pm) and all(all_md_parents[pid]['text']==p['text'] and all_md_parents[pid]['label']==LABELS[KINDS.index(p['kind'])] for pid,p in pm.items()))
    check('Component Markdown and JSONL text agree',set(all_md_children)==set(childmap) and all(all_md_children[sid][:3]==(r['parent_id'],r['deliverable'],r['text']) for sid,r in childmap.items()))
    check('Child order under each Markdown parent',all(all_md_parents[pid]['children']==[f'{pid}-T{i:02d}' for i in range(1,11)] for pid in pm))
    mp,mc,links,dups=parse_md(root/'ALL.md')
    check('Master has every original parent exactly once',len(mp)==9600 and not dups and all(mp[pid]['text']==p['text'] for pid,p in pm.items()))
    check('Master contains the same 96,000 children',len(mc)==96000 and set(mc)==set(childmap) and all(mc[sid][:3]==all_md_children[sid][:3] for sid in childmap))
    if not structure_only:
        check('All shipped Markdown children unchecked',unticked and all(v[3]==' ' for v in mc.values()))
    for link in links:
        dest=(root/link.split('#')[0]).resolve()
        if not dest.is_relative_to(root) or not dest.exists():link_problems.append('ALL.md: '+link)
    for path in [root/'INDEX.md',root/'README.md',root/'SCHEMA.md',root/'EXAMPLES.md',*sorted((root/'w').glob('*.md'))]:
        for link in re.findall(r'\]\(([^)]+)\)',path.read_text(encoding='utf-8')):
            if re.match(r'^[a-zA-Z][a-zA-Z0-9+.-]*:',link):continue
            dest=(path.parent/link.split('#')[0]).resolve()
            if not dest.is_relative_to(root) or not dest.exists():link_problems.append(str(path.relative_to(root))+': '+link)
    check('Generated navigation links resolve',not link_problems,'; '.join(link_problems[:5]) or 'Only generated documents are checked; preserved originals keep their original links.')
    check('Twelve workstream indexes',len(list((root/'w').glob('*.md')))==12)
    paths=[p for p in root.rglob('*') if p.is_file()]
    rels=[p.relative_to(root).as_posix() for p in paths]
    folded=[unicodedata.normalize('NFC',x).casefold() for x in rels]
    devices={'CON','PRN','AUX','NUL',*(f'COM{i}' for i in range(1,10)),*(f'LPT{i}' for i in range(1,10))}
    unsafe=[]
    for rel in rels:
        for part in PurePosixPath(rel).parts:
            if part.rstrip(' .')!=part or re.search(r'[<>:"\\|?*\x00-\x1f]',part) or part.split('.')[0].upper() in devices:unsafe.append(rel)
    check('Filename and case-collision preflight',len(set(folded))==len(folded) and not unsafe and not any(p.is_symlink() for p in root.rglob('*')))
    maxrel=max(len('UCTODO/'+x) for x in rels)
    check('Short relative package paths',maxrel<120,f'Maximum root-inclusive path: {maxrel} characters; arbitrary extraction-root length is not qualified.')
    cmd=(root/'VALIDATE.cmd').read_bytes()
    check('Windows launcher byte format',cmd.startswith(b'@echo off\r\n') and not cmd.startswith(b'\xef\xbb\xbf') and all(x<128 for x in cmd) and b'\n' not in cmd.replace(b'\r\n',b''),'ASCII, CRLF, no BOM; native Windows execution not performed.')
    syntax=[]
    for p in (root/'tools').glob('*.py'):
        try:ast.parse(p.read_text(encoding='utf-8'));syntax.append(True)
        except SyntaxError:syntax.append(False)
    check('Helper Python syntax parses',bool(syntax) and all(syntax))
    if not structure_only:
        listing=[];all_valid=True
        for line in (root/'SHA256SUMS.txt').read_text(encoding='ascii').splitlines():
            if not re.fullmatch(r'[0-9a-f]{64}  .+',line):raise ValueError('Malformed package checksum record')
            h,n=line.split('  ',1);listing.append(n)
            p=within(root,n)
            all_valid=all_valid and p.is_file() and digest(p)==h
        check('Package checksum inventory is complete',len(listing)==len(set(listing)) and set(listing)==set(rels)-{'SHA256SUMS.txt'})
        check('All shipped file checksums match',all_valid,f'{len(listing)} files; SHA256SUMS.txt is intentionally not self-hashed.')
    return {'schema':'UC/TODO_VALIDATION/1','mode':'structure-only' if structure_only else 'release-integrity','result':'PASS' if all(c['status']=='PASS' for c in checks) else 'FAIL','checks_passed':sum(c['status']=='PASS' for c in checks),'checks_total':len(checks),'counts':{'components':len(cs),'parents':len(parents),'subtasks':len(children),'dependency_edges':edges,'files':len(paths),'max_path_chars_including_root':maxrel},'checks':checks,'scope':'Planning-data structure and integrity only; no unikernel runtime, guest boot, host isolation, native Windows or macOS execution is tested.'}


def main()->int:
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--root',type=Path,default=Path(__file__).resolve().parent.parent)
    ap.add_argument('--structure-only',action='store_true',help='Allow progress-state edits and skip pristine release-file checksum checks; parallel text views must still agree.')
    ap.add_argument('--json',action='store_true',help='Print machine-readable report to stdout; writes no files.')
    args=ap.parse_args()
    try:result=validate(args.root.resolve(),args.structure_only)
    except (OSError,ValueError,KeyError,TypeError,IndexError,zipfile.BadZipFile) as exc:
        print(f'VALIDATION ERROR: {exc}',file=sys.stderr);return 2
    if args.json:print(json.dumps(result,ensure_ascii=False,indent=2))
    else:
        print(f"{result['result']}: {result['checks_passed']}/{result['checks_total']} package checks")
        for c in result['checks']:print(f"[{c['status']}] {c['check']}"+(f" — {c['detail']}" if c['detail'] else ''))
        print(result['scope'])
    return 0 if result['result']=='PASS' else 1

if __name__=='__main__':
    if hasattr(sys.stdout,'reconfigure'):sys.stdout.reconfigure(encoding='utf-8',errors='replace')
    raise SystemExit(main())
