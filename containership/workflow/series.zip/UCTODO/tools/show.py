#!/usr/bin/env python3
"""Read one parent and its ten children without opening the complete master. No writes."""
from __future__ import annotations
import argparse
import json
from pathlib import Path
import re
import sys

def main()->int:
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('parent_id',help='For example UC-M07.01-C006')
    ap.add_argument('--root',type=Path,default=Path(__file__).resolve().parent.parent)
    ap.add_argument('--json',action='store_true')
    a=ap.parse_args()
    if not re.fullmatch(r'UC-M\d{2}\.\d{2}-C\d{3}',a.parent_id):ap.error('Expected a full parent ID such as UC-M07.01-C006')
    try:
        parent=None;rows=[]
        with (a.root/'data/parents.jsonl').open(encoding='utf-8') as fh:
            for line in fh:
                r=json.loads(line)
                if r['id']==a.parent_id:parent=r;break
        if parent is None:print('Parent ID not found.',file=sys.stderr);return 1
        with (a.root/'data/subtasks.jsonl').open(encoding='utf-8') as fh:
            for line in fh:
                r=json.loads(line)
                if r['parent_id']==a.parent_id:rows.append(r)
        if len(rows)!=10 or [r['id'] for r in rows]!=[a.parent_id+f'-T{i:02d}' for i in range(1,11)]:
            print('Invalid child coverage; run the validator.',file=sys.stderr);return 2
        if a.json:print(json.dumps({'parent':parent,'subtasks':rows},ensure_ascii=False,indent=2))
        else:
            print(f"# {a.parent_id} — {parent['focus_title']}\n\nOriginal checklist item: {parent['text']}\n")
            for r in rows:print(f"- [{'x' if r['status']=='DONE' else ' '}] {r['id']} · {r['deliverable']}: {r['text']} [{r['status']}]")
    except (OSError,ValueError,KeyError) as exc:print(f'READ ERROR: {exc}',file=sys.stderr);return 2
    return 0

if __name__=='__main__':
    if hasattr(sys.stdout,'reconfigure'):sys.stdout.reconfigure(encoding='utf-8',errors='replace')
    raise SystemExit(main())
