#!/usr/bin/env python3
"""Build a source-grounded nested to-do pack. Standard library only; no runtime execution."""
from __future__ import annotations
import argparse
import hashlib
import json
from pathlib import Path
import re
import shutil
import zipfile
from collections import Counter

VERSION = '2.0.0'
BASELINE = 'UC-2.2.0'
CREATED = '2026-09-22'
KINDS = ['contract','delivery','invariant','integration','valid_case','negative_case','change_or_failure','bounds','diagnostics_or_review','evidence']
LABELS = {'contract':'Contract','delivery':'Delivery','invariant':'Invariant','integration':'Integration','valid_case':'Valid-case test','negative_case':'Negative test','change_or_failure':'Change / failure test','bounds':'Bounds','diagnostics_or_review':'Diagnostics / review','evidence':'Evidence'}


def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def sentence(text: str) -> str:
    return text.rstrip('.!? ') + '.'


def source_data(zpath: Path):
    with zipfile.ZipFile(zpath) as z:
        bad=z.testzip()
        if bad:
            raise ValueError(f'Source ZIP CRC failure: {bad}')
        names=z.namelist()
        if len(names)!=len(set(names)):
            raise ValueError('Duplicate source ZIP entries')
        m=json.loads(z.read('UC100/data/manifest.json'))
        raw=z.read('UC100/data/tasks.jsonl')
        tasks=[json.loads(line) for line in raw.decode('utf-8').splitlines()]
        master=z.read('UC100/ALL.md')
        roadmap=z.read('UC100/s/roadmap.md')
        manifest_bytes=z.read('UC100/data/manifest.json')
        for line in z.read('UC100/SHA256SUMS.txt').decode('utf-8').splitlines():
            if not line.strip():
                continue
            h,n=line.split('  ',1)
            if sha(z.read('UC100/'+n))!=h:
                raise ValueError(f'Source checksum mismatch: {n}')
    master_text=master.decode('utf-8')
    master_parents={a:(b,c) for a,b,c in re.findall(r'^- \[ \] \*\*(UC-M\d{2}\.\d{2}-C\d{3}) · (.+?):\*\* (.+)$',master_text,re.M)}
    assert len(m['components'])==96 and len(tasks)==9600
    assert len({t['id'] for t in tasks})==9600
    for c in m['components']:
        group=[t for t in tasks if t['component_id']==c['id']]
        assert len(group)==100 and len(c['focus_areas'])==10
        for i,t in enumerate(group,1):
            assert t['id']==f"{c['id']}-C{i:03d}"
            assert t['kind']==KINDS[(i-1)%10]
            assert t['focus_title']==c['focus_areas'][(i-1)//10]['title']
            assert t['status']=='TODO'
            assert master_parents[t['id']]==(LABELS[t['kind']],t['text']), t['id']
    return m,tasks,raw,master,roadmap,manifest_bytes


def expand(c: dict, p: dict) -> list[tuple[str,str]]:
    """Ten different actions for the parent check type, with exact source focus parameters."""
    f=c['focus_areas'][p['focus_number']-1]
    focus=f['title']; title=c['title']; cid=c['id']
    delivery=sentence(f['delivery']); inv=sentence(f['invariant'])
    neg=sentence(f['negative_case']); bound=f['bounded_quantities']
    seam=c['expansion_profile']['integration_seam']
    change=c['expansion_profile']['change_or_failure_case']
    mode=c['expansion_profile']['mode']; kind=p['kind']
    dep=', '.join(c['dependencies']) or 'none declared; foundational work'
    ctx=f'“{focus}”'
    invariant=f'“{f["invariant"]}”'
    scenario=f'“{f["negative_case"]}”'
    quantities=f'“{bound}”'
    risk_clause='Use synthetic inputs and an authorized disposable target; do not exercise production or unrelated systems.'

    if kind=='contract':
        first={
            'model': f'Draft a scope note for {ctx} within {title}; separate required model statements, explicit exclusions and unresolved design decisions.',
            'implementation': f'Draft the operation boundary for {ctx} within {title}; identify its entry condition, completion condition and explicitly unsupported paths.',
            'qualification': f'Write the qualification question for {ctx}; identify the actual target, claimed capability and observations that can answer that question.',
            'ui': f'Describe the operator journey for {ctx}; name the selected workload, generation, permitted action and authoritative displayed outcome.',
        }[mode]
        return [
            ('Scope statement',first),
            ('Input inventory',f'Enumerate the inputs, declarations or observations consumed by {ctx}; record each producer, representation and missing-value meaning.'),
            ('Output inventory',f'List the outputs of {ctx} and their consumers; define observable completion and distinguish an unavailable result from a successful empty result.'),
            ('Field dictionary',f'Create a field-and-term dictionary for {ctx}; specify required versus optional entries, value meaning and compatibility assumptions without inventing target-specific constants.'),
            ('Prerequisite contract',f'Map {ctx} to the source component prerequisites ({dep}); record the selected profile and which inputs must be supplied before this contract can be accepted.'),
            ('Authority map',f'Identify who may produce, change and consume {ctx}; record ownership and the actual enforcement or review boundary rather than treating a declaration as authority.'),
            ('Invariant clause',f'Add a normative clause for {ctx} that preserves {invariant}; name the observation or review decision that will demonstrate compliance.'),
            ('Outcome table',f'Define valid, unsupported and adverse outcomes for {ctx}; include the source counterexample {scenario} and the intended safe disposition.'),
            ('Limit decisions',f'List units, selection rationale and unresolved limits for {quantities} in the {ctx} contract; assign decisions rather than fabricating numerical budgets.'),
            ('Contract review',f'Review the {ctx} input/output examples against its outcome table; version the accepted contract and record unresolved blockers separately from approval.'),
        ]

    if kind=='delivery':
        verb=f['delivery'].split()[0].lower().strip(',')
        if verb in {'define','specify','describe','document','state','declare','distinguish','classify','enumerate','list','inventory','identify','map','represent','record'}:
            build=(f'Create the {ctx} model, schema or inventory that realizes this source instruction: {delivery}',f'Populate {ctx} with one concrete worked case; map every required entity or field to its source and flag any unmapped entry.')
        elif verb in {'choose','select','pin','decide'}:
            build=(f'Prepare the {ctx} decision record for this source instruction: {delivery}',f'Evaluate the {ctx} choice against its declared constraints; record the exact selected target/configuration and rejected alternatives, leaving unverified compatibility as a blocker.')
        elif verb in {'test','exercise','run','verify','check','compare','measure','probe','retest','qualify','assess','simulate','inject','race','reproduce','attempt'}:
            build=(f'Create the {ctx} fixture or harness for this source instruction: {delivery}',f'Connect the {ctx} harness to its actual intended target, set the expected oracle before running it, and distinguish a mock/control run from a target run.')
        elif verb in {'publish','report','show','display','present','export','package','attach','collect','capture','quote'}:
            build=(f'Create the {ctx} output artifact for this source instruction: {delivery}',f'Populate the {ctx} artifact from identified observations; keep unknown, failed and unexecuted results distinct and exclude unapproved sensitive material.')
        else:
            build=(f'Implement the smallest selected-profile change for {ctx} that realizes this source instruction: {delivery}',f'Trace {ctx} from its real caller to the responsible mechanism; connect validation, ownership and final outcome without leaving a placeholder success path.')
        if mode=='model':
            connect=f'Connect the {ctx} specification to {seam}; record code coverage separately where the design is not yet enforced.'
            verify=f'Walk the populated {ctx} model through a valid example and the source counterexample {scenario}; record corrections and unresolved enforcement gaps.'
        elif mode=='qualification':
            connect=f'Connect the {ctx} qualification artifact to {seam}; record the target identity and what the harness actually exercises.'
            verify=f'Run a known-valid control and a deliberately failing control for {ctx}; confirm the harness distinguishes their observed outcomes.'
        elif mode=='ui':
            connect=f'Connect the {ctx} view or interaction to {seam}; do not substitute cached declarations or animation for observed status.'
            verify=f'Exercise the {ctx} view with current, stale and denied data; compare its text and enabled actions with the authoritative response.'
        else:
            connect=f'Connect the {ctx} implementation to {seam}; record the actual exchanged data and the missing-prerequisite behavior.'
            verify=f'Run the smallest real {ctx} path and its adverse fixture {scenario}; retain actual output, state effects and final disposition.'
        return [
            ('Existing-work inventory',f'Locate the existing code, specification, fixture or explicit absence for {ctx}; record the baseline path/revision without assuming this planning pack implements it.'),
            ('Change plan',f'Break the source delivery for {ctx} into concrete edit targets and reviewable outputs; keep the {cid} requirement and original acceptance criterion as the scope boundary.'),
            ('Core artifact',build[0]),
            ('Concrete realization',build[1]),
            ('Invariant protection',f'Add the actual guard, check or review criterion for {ctx} needed to preserve {invariant}; record an enforcement gap where only a model exists.'),
            ('Dependency connection',connect),
            ('Resource behavior',f'Account for {quantities} in {ctx}; implement or document bounded behavior at the selected limit rather than embedding unexplained constants.'),
            ('Delivery check',verify),
            ('Patch review',f'Review the {ctx} diff against its stated inputs, outputs and scope; remove accidental changes, unexplained defaults and unsupported success claims.'),
            ('Delivery handoff',f'Publish the {ctx} artifact references, executed checks and remaining blockers; link them to this parent checklist item without marking other parents complete automatically.'),
        ]

    if kind=='invariant':
        return [
            ('Named property',f'Create a stable property/check name under this parent for {ctx}; copy its required invariant exactly: {invariant}.'),
            ('Observable terms',f'Define each term in the {ctx} invariant using inspectable fields, state or review evidence; identify any claim that cannot yet be observed.'),
            ('Precondition set',f'List the preconditions under which {invariant} must hold for {ctx}; separate selected-profile conditions from unjustified exceptions.'),
            ('Transition coverage',f'Map the {ctx} inputs and transitions that can affect the property; identify the exact enforcement point or design/review gate for each path.'),
            ('Assertion artifact',f'Implement the named assertion or explicit review rule for {ctx}; make an unavailable observation block the result instead of passing by default.'),
            ('Satisfying fixture',f'Create a concrete {ctx} case that satisfies {invariant}; record its expected observation before running the assertion or review.'),
            ('Violating fixture',f'Create the source counterexample {scenario} for {ctx}; confirm that it falsifies the property or is refused by the real guard, not merely omitted from the fixture.'),
            ('Enforcement evidence',f'Exercise the {ctx} guard at its actual boundary where implemented; separate observed prevention from documentation-only conformance and retain the remaining gap.'),
            ('Regression linkage',f'Link the {ctx} property to changes in {seam}; record which dependency or contract changes require rerunning it.'),
            ('Property disposition',f'Compare the satisfying and violating {ctx} observations with the named assertion; record pass, fail or untested and attach the responsible artifact revision.'),
        ]

    if kind=='integration':
        return [
            ('Handoff map',f'Draw or tabulate the producer-to-consumer handoff for {ctx} across {seam}; identify the receiving code or review gate, not just a folder location.'),
            ('Field mapping',f'Map every {ctx} exchanged field or evidence reference to its meaning, source and destination; record transformations and reject unmapped mandatory data.'),
            ('Prerequisite identities',f'Record the actual prerequisites for {ctx} (source dependency list: {dep}); bind the handoff to the selected versions and profile without adding a hidden fallback dependency.'),
            ('Ownership agreement',f'Specify who owns {ctx} inputs, handles or review records before, during and after handoff; identify responsibility for cleanup or invalidation.'),
            ('Handoff implementation',f'Connect {ctx} through the mapped seam using the real adapter or explicit specification reference; preserve {invariant} across the handoff.'),
            ('Absent-input case',f'Omit one required {ctx} prerequisite input at the seam; assert the documented blocked/refused outcome without externally visible partial success.'),
            ('Stale-input case',f'Supply an outdated {ctx} prerequisite identity or evidence reference; verify the receiver detects staleness and records the final disposition.'),
            ('Incompatible-input case',f'Supply an incompatible {ctx} version, representation or selected capability at the seam; verify explicit refusal rather than silent coercion.'),
            ('Valid integration trace',f'Run a valid {ctx} handoff end to end; capture the sent and received nonsecret fields and verify the intended result at the actual consumer.'),
            ('Seam review',f'Reconcile the {ctx} valid and rejected cases with the field mapping; publish unresolved dependency blockers and link observed evidence to the source integration parent.'),
        ]

    if kind=='valid_case':
        first={
            'model':f'Select one concrete valid worked example for {ctx}; enumerate the model inputs and the expected review decision before evaluating it.',
            'qualification':f'Choose a known-valid control for {ctx}; document why it should pass and how it proves the harness reaches the intended target.',
            'ui':f'Select an authorized-operator example for {ctx} with current observed state; record the expected text, generation and enabled actions.',
            'implementation':f'Choose the smallest nontrivial supported {ctx} input; record the selected host/backend profile and expected final disposition.',
        }[mode]
        run={
            'model':f'Evaluate the {ctx} example against the reviewed model; where a runtime mechanism exists, run its corresponding fixture and label those observations separately.',
            'qualification':f'Run the {ctx} known-valid control on the identified target; retain enough observations to prove the correct target was exercised.',
            'ui':f'Drive the {ctx} operator interaction and collect the rendered text plus authoritative API result; avoid treating a visual success cue alone as evidence.',
            'implementation':f'Execute the {ctx} valid-path fixture on the selected real target; capture actual output, exit/review disposition and relevant state effects.',
        }[mode]
        return [
            ('Valid fixture choice',first),
            ('Expected-result oracle',f'Specify the {ctx} expected result independently of the implementation output; include the property {invariant} and distinguish witness agreement from application correctness where relevant.'),
            ('Fixture material',f'Create the concrete {ctx} inputs with stable fixture IDs and recorded source bytes or model values; keep them small enough to inspect.'),
            ('Target preparation',f'Prepare the {ctx} prerequisites and record exact component, target and configuration identities; retain missing prerequisites as blockers.'),
            ('Initial-state record',f'Record the initial {ctx} state, ownership and expected changes; isolate the fixture from unrelated work and define the post-test cleanup scope.'),
            ('Valid-path execution',run),
            ('Outcome comparison',f'Compare every declared {ctx} output and final status with the oracle; report mismatches explicitly rather than checking only that execution returned.'),
            ('State and bounds check',f'Inspect the {ctx} ownership/state effects and actual use of {quantities}; confirm the valid run stayed within the selected constraints.'),
            ('Repeatability check',f'Repeat the same {ctx} case from the recorded initial state; investigate differences and document any declared nondeterminism rather than silently normalizing it.'),
            ('Positive evidence',f'Attach the {ctx} fixture, oracle, commands or review procedure, observations and cleanup result; record an unexecuted target as untested.'),
        ]

    if kind=='negative_case':
        observe=(f'Evaluate the {ctx} adverse case through the actual review/contract gate; where implemented, also observe the runtime refusal and keep the two evidence classes separate.' if mode=='model' else
                 f'Exercise the {ctx} adverse case at the actual selected target or interface; retain the response, final status and bounded nonsecret observations.')
        return [
            ('Adverse-case definition',f'Create a test record for the exact {ctx} source counterexample: {scenario}; state which precondition or invariant it challenges.'),
            ('Safe fixture boundary',f'Define the contained test boundary for {ctx}. {risk_clause} Record the allowed effects and stop conditions.'),
            ('Valid control',f'Construct a valid {ctx} control with the same prerequisites; confirm it reaches the intended boundary so unrelated setup failure cannot masquerade as protection.'),
            ('Minimal adverse input',f'Derive the {ctx} adverse fixture from the control with the smallest documented change needed to reproduce {scenario}; retain that change as reproducible data.'),
            ('Refusal oracle',f'Predeclare the expected refusal, containment, recovery or degraded outcome for {ctx}; require {invariant} and forbid a false-success verdict.'),
            ('Adverse execution',observe),
            ('Effect inspection',f'Inspect {ctx} state, ownership and output after the adverse attempt; compare with the declared allowed effects and record any partial mutation or leaked resource.'),
            ('Refusal versus failure',f'Confirm the {ctx} result came from the intended protective boundary, not an unrelated crash, missing tool or unavailable backend; classify ambiguous evidence as unresolved.'),
            ('Reset and retention',f'Restore only the disposable {ctx} fixture state, preserve the failing input and observation, and verify a valid control still behaves as expected after reset.'),
            ('Negative regression',f'Register the {ctx} counterexample as a named regression with reproduction instructions, observed disposition and remaining risks; do not treat a skipped run as a pass.'),
        ]

    if kind=='change_or_failure':
        if mode=='model':
            trigger=f'Apply the controlled model-change scenario for {ctx}: {change}; retain the exact before/after declarations.'
            inspect=f'Review which {ctx} claims, approvals and evidence references become stale after the change; keep unresolved enforcement gaps visible.'
            recover=f'Revise or explicitly refuse the changed {ctx} model under the documented compatibility policy; re-review affected claims before restoring their approval.'
        else:
            trigger=f'Introduce the controlled {ctx} scenario in the disposable fixture: {change}; record its exact timing or changed input.'
            inspect=f'Inspect the {ctx} actual intermediate state, outstanding ownership and visible verdict after the injected change/failure; detect a mixed or unknown disposition.'
            recover=f'Run the documented recovery, cancellation, revalidation or explicit refusal for {ctx}; do not assume moving a file or retrying establishes recovery.'
        return [
            ('Scenario record',f'Write the {ctx} change/failure scenario exactly as supplied: {change}; identify the property that must remain true: {invariant}.'),
            ('Baseline capture',f'Create a known-valid {ctx} baseline and record its subject identities, state and accepted evidence before introducing the scenario.'),
            ('Injection map',f'Locate the {ctx} operation or review points affected by this scenario; choose observable interruption/change positions and record why each matters.'),
            ('Disposition oracle',f'Define the legal intermediate and final {ctx} outcomes before the test; name acceptable old/new state or explicit blocked/partial status without inventing silent success.'),
            ('Controlled trigger',trigger+' Use an authorized isolated fixture and bounded execution/review scope.'),
            ('Intermediate inspection',inspect),
            ('Recovery path',recover),
            ('Stale-evidence cleanup',f'Invalidate superseded {ctx} evidence and approvals; verify no earlier result or owned resource is incorrectly attributed to the recovered/current subject.'),
            ('Repeat and compare',f'Repeat the selected {ctx} scenario positions from a clean baseline; compare each final outcome with the oracle and retain every unexplained difference.'),
            ('Failure evidence',f'Publish the {ctx} before/after records, exact trigger, recovery observations, remaining resources and blockers; link each record to its tested target identity.'),
        ]

    if kind=='bounds':
        mode_note={
            'model':'coverage and completeness limits',
            'qualification':'campaign and target-resource budgets',
            'ui':'update, payload and presentation limits',
            'implementation':'resource and input limits',
        }[mode]
        return [
            ('Quantity inventory',f'Create a measurement inventory for {ctx}: {quantities}; separate independent quantities and define units, counting boundaries and exclusions.'),
            ('Measurement method',f'Choose how to observe each {ctx} quantity on the selected target or review corpus; record whether the result is measured, derived or unavailable.'),
            ('Budget decision',f'Select justified {mode_note} for {ctx}; record owner, target assumptions and rationale without substituting arbitrary numerical defaults.'),
            ('Boundary fixtures',f'Prepare normal, at-limit and over-limit {ctx} cases for {quantities}; document the generated input or inventory size and any infeasible case.'),
            ('Limit action',f'Define the exact refusal, stop, incomplete-coverage report or bounded-degradation behavior for each exceeded {ctx} limit; preserve {invariant}.'),
            ('Normal measurement',f'Run or review the normal {ctx} fixture and record actual consumption/coverage against the declared budget; retain the raw observation.'),
            ('At-limit measurement',f'Exercise the {ctx} at-limit fixture; compare the observed decision and consumption with the documented inclusive/exclusive boundary.'),
            ('Over-limit measurement',f'Exercise the {ctx} over-limit fixture within a bounded disposable test; verify the prescribed limit action and absence of a fabricated complete result.'),
            ('Uncovered-scope report',f'List the {ctx} combinations or surfaces not reached within budget; separate target failure, harness exhaustion and intentional profile exclusion.'),
            ('Limit evidence',f'Publish the selected {ctx} budget, units, fixtures, observed maxima and final outcomes; flag changed target assumptions as a reason to requalify the limits.'),
        ]

    if kind=='diagnostics_or_review':
        if mode=='model':
            return [
                ('Review inventory',f'List the {ctx} decisions and claims requiring review; distinguish source requirements, implementation observations and engineering assumptions.'),
                ('Rationale record',f'Write the rationale for the selected {ctx} representation or policy; link each choice to the requirement rather than an unexplained preference.'),
                ('Assumption ledger',f'Record unresolved {ctx} assumptions, their owner and what observation or decision would resolve them; do not treat unknowns as approvals.'),
                ('Boundary map',f'Map each {ctx} claim to an actual guard or explicit design/review gate; flag gaps against {invariant}.'),
                ('Counterexample review',f'Walk reviewers through the {ctx} counterexample {scenario}; record whether the model detects it and whether any runtime guard was actually exercised.'),
                ('Review outcome vocabulary',f'Define approved, blocked, superseded and untested review outcomes for {ctx}; ensure the wording cannot be read as runtime enforcement evidence.'),
                ('Re-review triggers',f'List {ctx} invalidation triggers, including the source change scenario: {change}; identify the affected claims and evidence.'),
                ('Sensitive-data review',f'Inspect the {ctx} review record for secrets and unrelated user content; retain nonsecret references sufficient for reproducibility.'),
                ('Independent reading',f'Have the {ctx} record read against the original acceptance criterion and {seam}; record misunderstandings or missing evidence as corrections.'),
                ('Review disposition',f'Publish the {ctx} rationale, versioned review outcome, unresolved gaps and explicit next decision; keep blockers open until supported evidence resolves them.'),
            ]
        if mode=='qualification':
            return [
                ('Result inventory',f'Enumerate the required {ctx} qualification cases and intended targets before aggregating results; keep the planned denominator visible.'),
                ('Verdict schema',f'Define separate executed-pass, executed-fail, skipped, unavailable and untested outcomes for {ctx}; document how incomplete cases block relevant claims.'),
                ('Identity fields',f'Attach the actual target, fixture, configuration and revision identifiers to each {ctx} result; do not attribute host-only evidence to a guest or another OS.'),
                ('Observation capture',f'Capture bounded raw {ctx} observations and harness errors; retain enough information to verify the reported oracle comparison.'),
                ('Aggregation rules',f'Implement the {ctx} count/reduction rule so failures and missing measurements cannot disappear; preserve {invariant}.'),
                ('Failure visibility',f'Feed a failing {ctx} control through the report path; assert the exact failed case and underlying observation remain visible.'),
                ('Missing-result visibility',f'Withhold a required {ctx} measurement or target; verify the report uses unavailable/untested rather than a fabricated zero or passing value.'),
                ('Bounds and redaction',f'Check {ctx} report size and retention against {quantities}; remove secrets while retaining fixture and subject references.'),
                ('Report reconciliation',f'Reconcile the {ctx} summary with every underlying case record; account for the full planned denominator and all omitted scope.'),
                ('Qualification handoff',f'Publish the {ctx} report with measured observations, coverage limits and blockers; state which actual targets remain unqualified.'),
            ]
        if mode=='ui':
            return [
                ('Display-state inventory',f'List current, stale, unavailable, denied and failed states for {ctx}; identify the authoritative API/observation for each displayed value.'),
                ('Authority text',f'Write explicit nonsecret {ctx} text for actor permission, selected generation and affected scope; do not rely solely on color or animation.'),
                ('Freshness fields',f'Show the {ctx} observation age and source identity; distinguish last-known state from a current verified result.'),
                ('Failure text',f'Define the {ctx} error and blocked-reason text; retain the actual final disposition rather than replacing it with a generic healthy view.'),
                ('Permission behavior',f'Test the {ctx} view with denied authority; verify unavailable actions and explanatory text agree with the authoritative decision.'),
                ('Stale-state behavior',f'Exercise {ctx} when {change}; ensure obsolete observations cannot imply current success.'),
                ('Sensitive-data check',f'Inject only synthetic secret markers into the {ctx} diagnostic path; verify none appear in the rendered view or exported text.'),
                ('Bounded updates',f'Exercise {ctx} update saturation within {quantities}; verify important authority and final-outcome information remains visible.'),
                ('API reconciliation',f'Compare the {ctx} displayed text and available controls with actual management results; document discrepancies and preserve {invariant}.'),
                ('UI diagnostic evidence',f'Attach the {ctx} state fixtures, observed text, API records and unresolved presentation errors; distinguish a mock view from a connected implementation.'),
            ]
        return [
            ('Event inventory',f'List the {ctx} start, success, refusal and failure events that an operator must distinguish; identify the emitting boundary for each.'),
            ('Diagnostic schema',f'Define nonsecret fields for {ctx} target identity, operation, outcome and failure reason; record which subject/generation fields are actually available.'),
            ('Failure mapping',f'Map each documented {ctx} refusal or error to a diagnostic outcome; include {scenario} and prohibit conversion into a success message.'),
            ('Emission path',f'Add the {ctx} event/diagnostic emission at the actual responsible boundary; preserve the original outcome if diagnostics themselves are unavailable.'),
            ('Redaction check',f'Test {ctx} diagnostics with synthetic sensitive markers; verify secret values and unrelated cargo are excluded while safe identifiers remain.'),
            ('Output budget',f'Set and exercise bounded {ctx} message size, rate and retention compatible with {quantities}; define truncation behavior that preserves the final reason.'),
            ('Success/refusal fixtures',f'Capture {ctx} diagnostics from a valid case and its source adverse fixture; verify target, outcome and failure reason distinguish them unambiguously.'),
            ('Diagnostic-path failure',f'Exercise unavailable or saturated diagnostic output for {ctx} in a disposable fixture; verify it cannot turn a failed operation into a reported pass.'),
            ('Operator review',f'Read the {ctx} record without hidden context and identify the affected target, final disposition and next documented action; repair ambiguous text.'),
            ('Diagnostic evidence',f'Publish redacted {ctx} event examples, schema, bounds and observed failure-path results; link each to its tested artifact and record unresolved visibility gaps.'),
        ]

    if kind=='evidence':
        return [
            ('Evidence inventory',f'List the {ctx} claims covered by this parent and the evidence required for each; separate specification review, byte integrity, witness, semantic and isolation claims where present.'),
            ('Artifact references',f'Record the exact {ctx} implementation/specification paths, revisions and relevant subject digests; explain any reference that cannot be resolved.'),
            ('Fixture references',f'Attach the {ctx} fixture IDs, input identities and oracle definition; preserve the source counterexample {scenario} as a distinct evidence case.'),
            ('Reproduction recipe',f'Write the commands, seeds or review procedure needed to reproduce {ctx}; include initial conditions and avoid invented executable paths.'),
            ('Environment record',f'Record the actual {ctx} environment and selected host/backend/profile versions used; mark targets not executed here as untested.'),
            ('Expected versus observed',f'Pair every {ctx} expected result with its actual observation and final verdict; leave missing observations explicitly missing instead of filling them with the expectation.'),
            ('Failure and limit records',f'Attach {ctx} change/failure and bounds evidence where required; include uncovered {quantities} and unresolved violations of {invariant}.'),
            ('Evidence hygiene',f'Check the {ctx} bundle for secrets, unrelated cargo, stale subjects and broken references; hashes identify bytes but do not by themselves establish trusted authority.'),
            ('Reproduction review',f'Have the {ctx} evidence reproduced or independently reviewed against its oracle where required; record what actually ran and any remaining limitations.'),
            ('Acceptance linkage',f'Link the {ctx} evidence to its parent and {cid} original acceptance criterion; retain failures, untested targets and residual risks as blockers rather than claiming component completion from checked boxes.'),
        ]
    raise ValueError(kind)


def write_text(path: Path,text: str):
    path.parent.mkdir(parents=True,exist_ok=True)
    path.write_text(text,encoding='utf-8',newline='\n')


def component_header(c:dict) -> str:
    deps=', '.join(f'[{x}](../{x[4:6]}/{x}.md)' for x in c['dependencies']) or c['dependencies_text']
    return f'''# {c['id']} — {c['title']}

**To-Do Pack {VERSION} · Baseline {BASELINE} · 100 parent checks × 10 subtasks = 1,000 to-dos**

[Master index](../../INDEX.md) · [Workstream index](../../w/{c['workstream']:02d}.md)

| Field | Preserved source value |
|---|---|
| Workstream | {c['workstream']:02d}. {c['workstream_title']} |
| Milestone | {c['milestone']} |
| Priority | {c['priority']} |
| Source assessment | {c['source_status']} |
| Scope | {c['scope']} |
| Dependencies | {deps} |
| Source checklist pack | 1.0.0 |
| Original reference labels | {c['basis']} |

## Original requirement

{c['description']}

**Original acceptance criterion:** {c['acceptance']}

**Source trace:** Original checklist `UC100/{c['path']}` inside [s/checklists.zip](../../s/checklists.zip); exact parent records in [data/parents.jsonl](../../data/parents.jsonl). Original roadmap lines {c['source_start_line']}–{c['source_end_line']} are preserved in [s/roadmap.md](../../s/roadmap.md).

## How to use these lists

Every parent statement below is preserved verbatim. Its ten child tasks are proposed decomposition, not implemented capabilities or executed tests. Child IDs append `-T01` through `-T10` to the original parent ID. All begin unchecked / `TODO`. Design/review evidence does not establish runtime enforcement; observe the actual selected target where the parent requires it.

The source dependency graph and selected release profile determine applicability. The numbered child sequence is a local working order, not an added hard dependency graph. An unselected optional feature needs a recorded not-applicable rationale; missing prerequisites for selected work remain blockers. Numerical budgets, backends and trust mechanisms remain decisions unless fixed by the source. Test hostile cases only with synthetic inputs in authorized disposable environments.

'''


def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--source',type=Path,required=True)
    ap.add_argument('--master',type=Path,help='Standalone source master; only the known source-trace link variation is accepted')
    ap.add_argument('--output',type=Path,required=True)
    args=ap.parse_args()
    out=args.output.resolve()
    if out.exists() and any(out.iterdir()):
        ap.error('Output must be new or empty; no existing work will be overwritten.')
    out.mkdir(parents=True,exist_ok=True)
    m,parents,raw,master,roadmap,sourcem=source_data(args.source)
    if args.master:
        standalone=args.master.read_bytes()
        normalized=standalone.decode('utf-8').replace('Preserved roadmap (included in the ZIP at `s/roadmap.md`)','[Preserved roadmap](s/roadmap.md)')
        if normalized!=master.decode('utf-8'):
            raise ValueError('Standalone source master differs beyond the documented source-trace link wording')
        master=standalone
    by_id={c['id']:c for c in m['components']}
    (out/'s').mkdir();(out/'data').mkdir()
    shutil.copyfile(args.source,out/'s/checklists.zip')
    (out/'s/checklist.md').write_bytes(master)
    (out/'s/roadmap.md').write_bytes(roadmap)
    (out/'s/manifest.json').write_bytes(sourcem)
    (out/'data/parents.jsonl').write_bytes(raw)
    subtasks=[]; components={}; maps=[]
    master_parts=[f'''# Unikernel Containership — 96,000 Nested To-Dos

**To-Do Pack {VERSION} · Runtime baseline {BASELINE} · Source checklist pack 1.0.0**

96 components × 100 original checklist items × 10 child tasks = **96,000 logical to-dos**.
This is a proposed planning expansion, not a runtime update, re-audit or execution report. Parent statements and component requirements remain the source authority. All children begin `TODO`. Master, component Markdown and JSONL are parallel views of the same logical child IDs, not additive counts. They do not automatically synchronize.

Original component dependencies are retained. Workstreams are categories rather than a serial waterfall; optional networking, OCI and multi-host federation remain conditional. A checked box is not implementation evidence. The short per-component files in the ZIP are the preferred editing view.

The source checklist archive, master and roadmap are preserved in the package. Source references and architecture URLs are inherited context, not newly researched claims. No upstream software is integrated by this pack.

''']
    for c in m['components']:
        parts=[component_header(c)]
        these=[p for p in parents if p['component_id']==c['id']]
        for fno,f in enumerate(c['focus_areas'],1):
            parts.append(f'''## {fno:02d}. {f['title']}

**Source delivery:** {sentence(f['delivery'])}

**Source invariant:** {sentence(f['invariant'])}

**Source negative case:** {sentence(f['negative_case'])}

**Source bounded quantities:** {f['bounded_quantities']}.

''')
            for p in [p for p in these if p['focus_number']==fno]:
                parts.append(f'''### {p['id']} · {LABELS[p['kind']]}

**Original checklist item:** {p['text']}

''')
                children=expand(c,p)
                assert len(children)==10
                for number,(deliverable,text) in enumerate(children,1):
                    sid=f"{p['id']}-T{number:02d}"
                    rec={'id':sid,'parent_id':p['id'],'component_id':c['id'],'workstream':c['workstream'],'focus_number':fno,'kind':p['kind'],'number':number,'deliverable':deliverable,'text':text,'status':'TODO','owner':None,'evidence':[],'notes':''}
                    subtasks.append(rec)
                    parts.append(f'- [ ] **{sid} · {deliverable}:** {text}\n')
                parts.append('\n')
                maps.append({'parent_id':p['id'],'component_id':c['id'],'kind':p['kind'],'focus_number':fno,'source_text_sha256':sha(p['text'].encode('utf-8')),'child_count':10,'first_child_id':p['id']+'-T01','last_child_id':p['id']+'-T10','component_path':c['path']})
        comp=''.join(parts)
        components[c['id']]=comp
        write_text(out/c['path'],comp)
        # Correct relative links when a component is embedded in the root-level master.
        master_copy=comp.replace('](../../','](').replace('](../','](c/')
        master_parts.append('\n---\n\n'+master_copy)
    write_text(out/'ALL.md',''.join(master_parts))
    with (out/'data/subtasks.jsonl').open('w',encoding='utf-8',newline='\n') as fh:
        for r in subtasks:
            fh.write(json.dumps(r,ensure_ascii=False,separators=(',',':'))+'\n')
    with (out/'data/trace.jsonl').open('w',encoding='utf-8',newline='\n') as fh:
        for r in maps:
            fh.write(json.dumps(r,ensure_ascii=False,separators=(',',':'))+'\n')
    index=[f'''# Unikernel Containership — Nested To-Do Index

**Pack {VERSION} · {BASELINE} baseline · Source Checklist Pack 1.0.0**

**96 components · 9,600 unchanged parent checklist items · 96,000 new child tasks.** Each parent has exactly ten children; each component has 1,000 children. All remain unchecked / `TODO`.

Open one of the 96 component files below. [README](README.md) explains applicability and evidence; [ALL.md](ALL.md) is the large full-text view; [VALIDATION.md](VALIDATION.md) reports package checks. [SCHEMA.md](SCHEMA.md) documents the machine-readable records. This is a planning deliverable, not an implementation or runtime release.

| Workstream | Milestone | Components | Parents | To-dos |
|---|---|---:|---:|---:|
''']
    for w in range(1,13):
        cs=[c for c in m['components'] if c['workstream']==w]
        index.append(f"| [{w:02d}. {cs[0]['workstream_title']}](w/{w:02d}.md) | {cs[0]['milestone']} | 8 | 800 | 8,000 |\n")
        wp=[f'''# {w:02d}. {cs[0]['workstream_title']}

[Master index](../INDEX.md) · Milestone **{cs[0]['milestone']}** · **8 components · 800 parents · 8,000 to-dos**

Follow the preserved component prerequisites and the selected profile; this category is not a mandatory serial phase. Source `PARTIAL` and `MISSING` are baseline assessments, not newly verified state. New children remain `TODO`.

| Component | Priority | Source status | Scope | Parents | To-dos |
|---|---|---|---|---:|---:|
''']
        for c in cs:
            wp.append(f"| [{c['id']} — {c['title']}](../{c['path']}) | {c['priority']} | {c['source_status']} | {c['scope']} | 100 | 1,000 |\n")
        wp.append('\n## Preserved prerequisite relationships\n\n')
        for c in cs:
            wp.append(f"**{c['id']}:** "+(', '.join(c['dependencies']) or 'None; foundational decision.')+'\n\n')
        write_text(out/f'w/{w:02d}.md',''.join(wp))
    index.append('\n## Component navigation\n\n| Component | Workstream | Priority | File |\n|---|---:|---|---|\n')
    for c in m['components']:
        index.append(f"| {c['id']} — {c['title']} | {c['workstream']:02d} | {c['priority']} | [1,000 to-dos]({c['path']}) |\n")
    index.append('\n## Dependency-valid navigation order\n\nThis is the source order for finding prerequisites, not a requirement to implement unselected optional features.\n\n'+', '.join(f'`{x}`' for x in m['dependency_order'])+'.\n')
    write_text(out/'INDEX.md',''.join(index))
    manifest={
        'schema':'UC/NESTED_TODO_PACK/2','pack_name':'Unikernel Containership — Nested To-Do Lists',
        'pack_version':VERSION,'baseline':BASELINE,'source_checklist_pack_version':m['pack_version'],'prepared_date':CREATED,
        'purpose':'Source-grounded proposed decomposition only; no runtime implementation, audit rerun, external verification or target test execution.',
        'expansion_policy':{'children_per_parent':10,'count_selected_by':'assistant default; user did not specify length','parent_text':'preserved exactly','task_templates':'parent-kind and source expansion mode, parameterized by source focus definitions','new_hard_dependencies':False,'status_sync':False,'inherited_architectural_references':'not freshly researched'},
        'counts':{'workstreams':12,'components':96,'focus_areas':960,'parent_checklist_items':9600,'subtasks':96000,'parents_per_component':100,'subtasks_per_parent':10,'subtasks_per_component':1000,'subtasks_per_workstream':8000,'source_dependency_edges':sum(len(c['dependencies']) for c in m['components'])},
        'sources':[
            {'role':'original_checklist_archive','original_filename':args.source.name,'path':'s/checklists.zip','sha256':sha(args.source.read_bytes())},
            {'role':'original_master_checklist','original_filename':args.master.name if args.master else 'UC100/ALL.md','path':'s/checklist.md','sha256':sha(master)},
            {'role':'original_component_manifest','path':'s/manifest.json','sha256':sha(sourcem)},
            {'role':'original_parent_records','path':'data/parents.jsonl','sha256':sha(raw)},
            {'role':'original_roadmap','path':'s/roadmap.md','sha256':sha(roadmap)},
        ],
        'task_status_counts':{'TODO':96000},'parent_kind_counts':dict(Counter(p['kind'] for p in parents)),
        'source_status_counts':m['source_status_counts'],'priority_component_counts':m['priority_component_counts'],
        'dependency_order':m['dependency_order'],'components':m['components'],
        'paths':{'master':'ALL.md','index':'INDEX.md','subtasks':'data/subtasks.jsonl','parents':'data/parents.jsonl','trace':'data/trace.jsonl'},
    }
    write_text(out/'data/manifest.json',json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
    (out/'tools').mkdir(exist_ok=True)
    shutil.copyfile(Path(__file__),out/'tools/build.py')
    print(json.dumps({'output':str(out),'components':len(components),'parents':len(parents),'subtasks':len(subtasks),'master_bytes':(out/'ALL.md').stat().st_size,'jsonl_bytes':(out/'data/subtasks.jsonl').stat().st_size},indent=2))

if __name__=='__main__':
    main()
