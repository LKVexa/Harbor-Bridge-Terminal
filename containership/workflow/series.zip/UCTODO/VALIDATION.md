# Unikernel Containership — Nested To-Do Pack Validation

**Pack 2.0.0 · Runtime baseline UC-2.2.0 · Source Checklist Pack 1.0.0 · September 22, 2026**

## Coverage observed

| Item | Observed count |
|---|---:|
| Workstreams | 12 |
| Components | 96 |
| Source focus areas | 960 |
| Original checklist parents | 9,600 |
| Child tasks per parent | 10 |
| Child tasks per component | 1,000 |
| Child tasks per workstream | 8,000 |
| Total unique child IDs | 96,000 |
| Original dependency edges | 212 |

All children are unchecked and start at `TODO`. The task IDs are unique; the count is not a claim of 96,000 unique prose formulations. Source `PARTIAL`/`MISSING`, scope, priorities and dependency relationships remain unchanged.

## Package validator

**Observed result: 41/41 package checks passed.** These checks cover planning-data structure and integrity, not runtime implementation readiness. A new input parse or content change must be validated again.

| Check | Result | Detail |
|---|---|---|
| Pack identity | PASS |  |
| Source snapshots match recorded SHA-256 | PASS | 5 preserved inputs |
| Original checklist archive CRC | PASS |  |
| Original JSONL retained byte-for-byte | PASS |  |
| Original manifest and roadmap retained | PASS |  |
| Source master equivalence | PASS | The original standalone master differs only in 96 source-trace link descriptions; its bytes are preserved. |
| Original archive member checksums | PASS | 117 original checksum entries |
| All component metadata unchanged | PASS | Includes IDs, titles, descriptions, acceptance, scope, priorities, dependencies and focus definitions. |
| Component and workstream coverage | PASS |  |
| Parent coverage and unique IDs | PASS |  |
| Subtask coverage and unique IDs | PASS |  |
| Parent grouping and numbering | PASS |  |
| Exactly ten children per original parent | PASS |  |
| Exactly 1,000 children per component | PASS |  |
| Exactly 8,000 children per workstream | PASS |  |
| Child-parent identity and classification | PASS |  |
| Stable source ordering | PASS |  |
| All ten parent check types retained | PASS |  |
| Editable tracking fields well formed | PASS |  |
| Initial planning status is TODO | PASS | No implementation completion is claimed. |
| Focus context appears in every child | PASS |  |
| Trace coverage and source hashes | PASS |  |
| Dependency references unchanged | PASS |  |
| Dependency graph remains acyclic | PASS |  |
| No added hard task dependencies | PASS |  |
| All 96 component Markdown files complete | PASS |  |
| All 960 focus sections retained | PASS |  |
| Original parent text preserved in components | PASS |  |
| Component Markdown and JSONL text agree | PASS |  |
| Child order under each Markdown parent | PASS |  |
| Master has every original parent exactly once | PASS |  |
| Master contains the same 96,000 children | PASS |  |
| All shipped Markdown children unchecked | PASS |  |
| Generated navigation links resolve | PASS | Only generated documents are checked; preserved originals keep their original links. |
| Twelve workstream indexes | PASS |  |
| Filename and case-collision preflight | PASS |  |
| Short relative package paths | PASS | Maximum root-inclusive path: 26 characters; arbitrary extraction-root length is not qualified. |
| Windows launcher byte format | PASS | ASCII, CRLF, no BOM; native Windows execution not performed. |
| Helper Python syntax parses | PASS |  |
| Package checksum inventory is complete | PASS |  |
| All shipped file checksums match | PASS | 127 files; SHA256SUMS.txt is intentionally not self-hashed. |

## Reproducibility and helper checks

The included generator was run again from the preserved source archive and standalone source master into a new directory. **All 113 core task/navigation files compared byte-for-byte equal**: the master, index, original parent records, child records, trace map, 96 component files and 12 workstream indexes. The support README, examples, validator, reports and release ZIP are packaging artifacts, not generated core task content. Regeneration may record the local source filename differently in the new manifest without changing task content.

The read helper returned exactly ten child records for `UC-M07.01-C006` (exit 0), refused an unknown parent (exit 1), and rejected an invalid path-shaped ID (exit 2).

Five controlled validator tests were run on a disposable copy:

| Case | Expected and observed result |
|---|---|
| Remove one JSONL child | Rejected; parent coverage and parallel-view checks failed |
| Change child text in only one Markdown view | Rejected; Markdown/JSONL and master parity failed |
| Change a progress checkbox only, structure-only mode | Accepted structurally; no status synchronization was claimed |
| Submit the same edited checkbox to release-integrity mode | Rejected; pristine checkbox and checksum checks failed |
| Insert malformed JSONL | Input error, exit 2; no false PASS |

These are **five tests of the packaging validator**, not the 96,000 proposed engineering tasks. Machine-readable observations are preserved in `data/quality.json`.

## Source comparison

The entire supplied checklist archive is preserved byte-for-byte. Its internal listed file checksums and ZIP CRC were checked. The standalone source master has the same 9,600 parent statements as the archived master; the only difference is the rendering of 96 source-trace link descriptions. Both originals are retained without silently rewriting either. Original parent JSONL, component manifest and roadmap bytes are preserved and hashed.

Every original parent statement is present above its children in the master and the appropriate component file. Every child record maps back to its source parent with the original parent-text SHA-256 in `data/trace.jsonl`. Source references and architecture URLs are inherited, not newly researched standards claims.

## Portability and environment

Observed Python environment: **CPython 3.13.5 on Linux x86-64**. All generated helper Python files parsed, and the read helper, generator and validator were executed in this environment. The package filenames are ASCII and case-collision-free; the longest root-inclusive relative path in this release is **26 characters**, such as a component path under `UCTODO/c/`. An arbitrarily deep extraction root is not guaranteed safe.

The optional Windows launcher is ASCII with CRLF line endings, no BOM and quoted script paths. It is not an installer. **Native Windows and macOS execution were not performed.** This pack does not validate guest boot, hypervisor isolation, production security, task implementation or the sufficiency of future completion evidence.

## Release checksums

`SHA256SUMS.txt` covers every shipped regular file except itself. Verify the extracted package with `python -X utf8 -B tools/validate.py`. After intentional progress changes, `--structure-only` checks relationships while leaving source snapshots immutable and requiring parallel text views to agree. A checksum verifies byte identity; it is not a digital signature or independent trust authority.

Final ZIP CRC, fresh-extraction validation and standalone-deliverable checks are recorded in the separately downloadable validation report. The release checksum list is computed after this report and auxiliary observations are written; no self-referential checksum claim is made.
